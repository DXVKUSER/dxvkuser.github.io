#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
HLS Proxy Kodi Mode v12.7 - Otimizado com Chunk Dinâmico e Estabilidade (Anti-Buffering)
Usa script.module.netunblock (DNS-over-HTTPS)
Executa via xbmcplugin.setResolvedUrl()
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
# import warnings # REMOVIDO: Linha que causava o erro de Attribute (requests.packages)
import os
import socket # Adicionado para tratar erros de socket
import http.server
import socketserver
import re # Necessário para reescrita de manifesto

from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

# Usa o requests do script.module.netunblock (com DNS-over-HTTPS)
from doh_client import requests
# Importa exceções específicas do requests para um tratamento de erro mais preciso e OTIMIZADO
from requests.exceptions import ConnectionError, Timeout, ReadTimeout, RequestException

# ---- Tentativa de importar Kodi ----
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
    import xbmcaddon
except ImportError:
    class MockKodi:
        def log(self, msg, level=None):
            print(msg)
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    xbmcvfs = None
    xbmcaddon = None


# ---------------- CONFIG OTIMIZADA ----------------

MAX_SEGMENT_RETRIES = 5  # Aumentamos para resiliência
MAX_MANIFEST_RETRIES = 3
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 20.0 # Timeout de leitura
DEFAULT_CHUNK_SIZE = 64 * 1024  # 64KB (Otimizado para Kodi)
PROXY_HOST = '127.0.0.1'
MIN_PORT = 10000
MAX_PORT = 10050
MAX_PORT_ATTEMPTS = 30
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
LOG_FILE = "hls_proxy.log"

# A linha de warnings.filterwarnings foi removida

# ---------------- FUNÇÕES DE SUPORTE ----------------

def kodi_log(msg, level=xbmc.LOGINFO):
    if xbmc:
        xbmc.log(f"[HLSProxy] {msg}", level=level)

def setup_logging():
    # Setup de logging simples para depuração fora do Kodi (opcional)
    if not xbmc and not os.path.exists(LOG_FILE):
        try:
            logging.basicConfig(filename=LOG_FILE, level=logging.DEBUG, 
                                format='%(asctime)s - %(levelname)s - %(message)s')
        except Exception as e:
            print(f"Erro ao configurar o logging: {e}")

class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    """Servidor multithread para lidar com múltiplas requisições HLS simultâneas."""
    daemon_threads = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.active_sessions = {}
        # Sessão base para requisições
        self.base_session = requests.Session()
        self.base_session.headers.update({'User-Agent': USER_AGENT})

class ProxyController:
    """Gerencia o ciclo de vida do proxy."""
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = 0
        self.lock = threading.Lock()

    def find_available_port(self):
        """Tenta encontrar uma porta livre para o proxy."""
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(MIN_PORT, MAX_PORT)
            try:
                # Tenta criar um socket, se conseguir, a porta está livre
                temp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                temp_socket.bind((PROXY_HOST, port))
                temp_socket.close()
                return port
            except OSError:
                continue
        return 0

    def start(self):
        """Inicia o servidor proxy em uma thread separada."""
        with self.lock:
            if self.server:
                kodi_log("Proxy HLS já está rodando.", xbmc.LOGDEBUG)
                return True

            self.active_port = self.find_available_port()
            if self.active_port == 0:
                kodi_log("Falha ao encontrar uma porta livre.", xbmc.LOGERROR)
                return False

            try:
                kodi_log(f"Iniciando Proxy HLS na porta: {self.active_port}", xbmc.LOGINFO)
                
                # Configura o Handler com a sessão base
                handler = self.create_handler(self.active_port)
                self.server = ThreadedHTTPServer((PROXY_HOST, self.active_port), handler)
                
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                
                kodi_log(f"Proxy HLS iniciado com sucesso na porta {self.active_port}.", xbmc.LOGINFO)
                return True

            except Exception as e:
                kodi_log(f"Erro ao iniciar o proxy HLS: {e}", xbmc.LOGERROR)
                self.server = None
                self.active_port = 0
                return False

    def stop(self):
        """Para o servidor proxy."""
        with self.lock:
            if self.server:
                kodi_log("Parando Proxy HLS...", xbmc.LOGINFO)
                self.server.shutdown()
                self.server.server_close()
                self.server = None
                self.active_port = 0
                kodi_log("Proxy HLS parado.", xbmc.LOGINFO)

    def create_handler(self, port):
        """Retorna o Handler configurado com o contexto do server."""
        class CustomHandler(HLSProxyHandler):
            def __init__(self, *args, **kwargs):
                self.server_port = port
                super().__init__(*args, **kwargs)
        return CustomHandler

class HLSProxyHandler(BaseHTTPRequestHandler):
    """Handler que trata requisições de manifestos e segmentos HLS."""
    def log_message(self, format, *args):
        # Desliga o logging padrão do BaseHTTPRequestHandler, que é muito verboso
        pass

    def get_passthrough_headers(self, session):
        """Obtém headers relevantes da sessão para a requisição de destino."""
        headers = {}
        if 'User-Agent' in session.headers:
            headers['User-Agent'] = session.headers['User-Agent']
        
        # Opcional: passa 'Accept' para manifestos
        if self.path.endswith('.m3u8') or self.path.endswith('.m3u'):
             headers['Accept'] = 'application/vnd.apple.mpegurl, */*'
        
        return headers

    def do_GET(self):
        """Handler para requisições GET (MANIFESTO e SEGMENTO)."""
        # 1. Parsing da URL e Session ID
        parsed_url = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed_url.query)
        target_url = params.get('url', [''])[0]
        session_id = params.get('session_id', [''])[0]
        
        if not target_url:
            self.send_error(400, "URL de destino ausente.")
            return

        # 2. Resolução do URL de Proxy
        if target_url.endswith('.m3u8') or target_url.endswith('.m3u'):
            self.handle_manifest(target_url, session_id)
        else:
            self.handle_segment(target_url, session_id)

    def handle_manifest(self, manifest_url, session_id):
        """Lida com a requisição do manifesto HLS e reescreve URLs."""
        try:
            # Reusa ou cria sessão base
            session = self.server.base_session
            
            # OTIMIZAÇÃO: verify=False para evitar problemas de certificado SSL
            response = session.get(manifest_url, headers=self.get_passthrough_headers(session), timeout=CONNECTION_TIMEOUT, verify=False)
            response.raise_for_status()

            # Processa o manifesto
            content = response.text
            # Garante que a base_url termina em barra, se for um diretório, para urljoin funcionar
            base_url = os.path.dirname(manifest_url.split('?')[0])

            def rewrite_url(match):
                """Callback para reescrever URLs de segmentos e sub-manifestos."""
                line = match.group(0)
                # Ignora linhas com #EXT
                if line.startswith('#'):
                    return line
                
                # Resolve a URL relativa para absoluta
                resolved_url = urllib.parse.urljoin(base_url + '/', line.strip())
                
                # Encapsula no proxy
                proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(resolved_url)}&session_id={session_id}"
                return proxy_segment_url
            
            # Regex para encontrar URLs que não começam com #EXT
            modified_content = re.sub(r'^[^\#\n]+', rewrite_url, content, flags=re.MULTILINE)
            
            # Headers de Resposta
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()
            
            self.wfile.write(modified_content.encode('utf-8'))
            
            kodi_log(f"Manifesto HLS reescrito para {session_id}.", xbmc.LOGDEBUG)

        except RequestException as e:
            kodi_log(f"Erro ao obter manifesto: {e}", xbmc.LOGERROR)
            self.send_error(500, f"Erro ao obter manifesto: {e}")
        except Exception as e:
            kodi_log(f"Erro inesperado no manifesto: {e}", xbmc.LOGERROR)
            self.send_error(500, f"Erro interno ao processar manifesto: {e}")

    def handle_segment(self, segment_url, session_id, retries=0):
        """Lida com a requisição de um segmento HLS com retry e tratamento otimizado."""
        
        # 1. Verifica se a sessão existe (para usar headers customizados)
        if session_id not in self.server.active_sessions:
            kodi_log(f"Sessão HLS {session_id} não encontrada. Usando sessão base.", xbmc.LOGWARNING)
            session = self.server.base_session
        else:
            session = self.server.active_sessions[session_id]

        # 2. Prepara o Request
        headers = self.get_passthrough_headers(session)
        # Otimização: Passa o Range header para suportar seeking/retoma
        headers['Range'] = self.headers.get('Range', '') 

        try:
            # Otimização: stream=True para streaming chunk-a-chunk. timeout (connect, read).
            response = session.get(
                segment_url, 
                headers=headers, 
                stream=True, 
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                verify=False # Não verificamos SSL para maior compatibilidade
            )
            response.raise_for_status()

            # 3. Headers de Resposta
            self.send_response(response.status_code)
            for key, value in response.headers.items():
                # Evita quebra de chunking/compressão pelo proxy e o Kodi
                if key.lower() not in ('transfer-encoding', 'content-encoding', 'content-length'):
                    self.send_header(key, value)
            
            # Otimização: Adicionar Header de Cache para segmentos (TTL curto, 5s)
            self.send_header('Cache-Control', 'max-age=5, public, must-revalidate')
            self.end_headers()

            # 4. Streaming do Conteúdo em Chunks
            chunk_size = DEFAULT_CHUNK_SIZE
            total_bytes = 0
            for chunk in response.iter_content(chunk_size=chunk_size):
                if not chunk:
                    break
                # Verifica se a conexão com o cliente (Kodi) ainda está ativa
                self.wfile.write(chunk)
                total_bytes += len(chunk)
            
            kodi_log(f"Segmento {os.path.basename(urllib.parse.urlparse(segment_url).path)} entregue ({total_bytes} bytes).", xbmc.LOGDEBUG)

        # 5. Tratamento de Erros e Retries (Aumento de Resiliência)
        except ReadTimeout as e:
            kodi_log(f"Timeout de leitura do segmento ({retries+1}/{MAX_SEGMENT_RETRIES}): {e}", xbmc.LOGWARNING)
            if retries < MAX_SEGMENT_RETRIES:
                time.sleep(RETRY_BACKOFF_FACTOR)
                return self.handle_segment(segment_url, session_id, retries + 1)
            else:
                self.send_error(504, "Gateway Timeout - Falha ao ler segmento após retries.")
        except ConnectionError as e:
            kodi_log(f"Erro de Conexão no Segmento ({retries+1}/{MAX_SEGMENT_RETRIES}): {e}", xbmc.LOGWARNING)
            if retries < MAX_SEGMENT_RETRIES:
                time.sleep(RETRY_BACKOFF_FACTOR)
                return self.handle_segment(segment_url, session_id, retries + 1)
            else:
                self.send_error(503, "Service Unavailable - Falha de conexão após retries.")
        except RequestException as e:
            if hasattr(e, 'response') and 400 <= e.response.status_code < 500:
                self.send_error(e.response.status_code, f"Erro de Cliente: {e}")
            else:
                kodi_log(f"Erro Inesperado na requisição do segmento: {e}", xbmc.LOGERROR)
                self.send_error(500, "Erro Interno do Proxy.")
        except socket.error as e:
            # Erro comum ao fechar a conexão no meio do streaming (normal no Kodi ao parar/interromper)
            kodi_log(f"Socket Error (Fechamento/Interrupção): {e}", xbmc.LOGDEBUG)
        except Exception as e:
            kodi_log(f"Erro Fatal ao processar segmento: {e}", xbmc.LOGERROR)
            self.send_error(500, "Erro Desconhecido.")


class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = ProxyController()
        # Assumir que o proxy é iniciado e parado pelo Kodi no ciclo de vida
        # Ou é gerenciado pela lógica do Addon principal.

    def get_url(self, target_url):
        """Retorna a URL do proxy para ser resolvida pelo Kodi."""
        # Garante que o proxy está rodando antes de retornar a URL
        if not self.proxy.start():
            kodi_log("Falha ao iniciar o proxy.", xbmc.LOGERROR)
            return target_url # Fallback para URL original (se o Kodi puder lidar)

        # Cria uma nova sessão para esta reprodução (útil para headers customizados por stream)
        session_id = f"sess_{int(time.time())}" 
        session = requests.Session()
        session.headers.update({'User-Agent': USER_AGENT})
        
        # Acessa self.proxy.server para registrar a sessão
        if hasattr(self.proxy, 'server') and self.proxy.server:
            self.proxy.server.active_sessions[session_id] = session
            
        return f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(target_url)}&session_id={session_id}"

    def play_stream(self, url, stream_type="video"):
        """Usa xbmcplugin.setResolvedUrl() (seguro no Android)"""
        try:
            proxy_url = self.get_url(url) 
            kodi_log(f"Reproduzindo via proxy seguro: {proxy_url}")

            if xbmcplugin and xbmcgui and self.handle is not None:
                listitem = xbmcgui.ListItem(path=proxy_url)
                listitem.setMimeType("application/vnd.apple.mpegurl")
                listitem.setContentLookup(False)
                xbmcplugin.setResolvedUrl(self.handle, True, listitem)
                kodi_log("Stream entregue ao player via setResolvedUrl()")
            else:
                print(f"[PLAY SIMULADO] {proxy_url}")
        except Exception as e:
            kodi_log(f"Erro em play_stream: {e}", xbmc.LOGERROR)

# ---------------- MAIN ----------------

def run_proxy():
    setup_logging()
    # Esta função é apenas para o modo de execução autônomo (não é o caso do Addon Kodi)
    try:
        # A lógica para execução autônoma é complexa e não é o foco
        pass 
    except Exception as e:
        kodi_log(f"Erro na execução principal do proxy: {e}", xbmc.LOGERROR)


if __name__ == '__main__':
    run_proxy()