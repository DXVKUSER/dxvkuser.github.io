import sys
import threading
import random
import logging
import urllib.parse
import time
import os
import http.server
import socketserver
import socket

# --- IMPORTAÇÕES DE REDE ---
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException, ConnectionError, HTTPError, Timeout, StreamConsumedError
# CORREÇÃO: Importar Retry a partir do pacote requests para garantir compatibilidade
from requests.packages.urllib3.util.retry import Retry

# Importações necessárias do Kodi para encontrar a dependência
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

# Flag para controlar se a dependência foi carregada
NETUNBLOCK_AVAILABLE = False
requests = None # Inicializa a variável 'requests' como None

try:
    # 1. Pega o objeto do addon da dependência pelo seu ID
    netunblock_addon = xbmcaddon.Addon(id='script.module.netunblock')
    
    # 2. Pega o caminho físico do addon no sistema de arquivos
    addon_path = netunblock_addon.getAddonInfo('path')
    
    if addon_path and os.path.exists(addon_path):
        # 3. Adiciona o caminho do addon ao sys.path
        if addon_path not in sys.path:
            sys.path.insert(0, addon_path)
        
        # 4. Agora que o caminho está visível, podemos importar o módulo
        from doh_client import requests
        
        # Se a importação for bem-sucedida, marcamos a flag como True
        NETUNBLOCK_AVAILABLE = True
        logging.info(f"[VOD-PROXY] Módulo 'script.module.netunblock' importado com sucesso de: {addon_path}")
    else:
        logging.error(f"[VOD-PROXY] O caminho para 'script.module.netunblock' não foi encontrado ou é inválido.")

except Exception as e:
    logging.error(f"[VOD-PROXY] ERRO FATAL: Não foi possível carregar a dependência 'script.module.netunblock'. Erro: {e}")
    xbmcgui.Dialog().notification(
        "Erro de Dependência", 
        "O módulo 'script.module.netunblock' não foi encontrado. Instale-o e ative-o.", 
        xbmcgui.NOTIFICATION_ERROR, 
        8000
    )

# ---------------- CONFIGURAÇÕES ----------------

DEFAULT_CHUNK_SIZE = 64 * 1024  # 64KB (Otimizado para Kodi)
MAX_RETRIES = 3
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 20.0
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 30
# O User-Agent do doh_client será sobrescrito para garantir compatibilidade
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
LOG_FILE = "vod_proxy.log"

# ---------------- LOGGING ----------------

def setup_logging():
    log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
    try:
        logging.basicConfig(
            level=logging.INFO,
            format='[VOD-PROXY] %(asctime)s - %(levelname)s - %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='[VOD-PROXY] %(message)s')

# ---------------- PREPARAÇÃO DA SESSÃO ----------------

def get_global_session():
    """
    Usa a sessão global já instanciada pelo 'doh_client' e a configura.
    A mágica do DNS sobre HTTPS (DoH) já foi ativada na importação do módulo.
    """
    if not NETUNBLOCK_AVAILABLE or requests is None:
        return None

    # CORREÇÃO ANTERIOR: O 'doh_client' já possui uma sessão instanciada como um atributo de classe.
    # Não devemos criar uma nova, mas sim usar a existente: 'requests.session'
    session_obj = requests.session

    # Configura Adapters e Retries para aumentar a robustez da sessão existente
    retry_strategy = Retry(
        total=MAX_RETRIES,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=20, pool_maxsize=20)
    
    try:
        session_obj.mount("https://", adapter)
        session_obj.mount("http://", adapter)
    except Exception as e:
        logging.error(f"[VOD-PROXY] Erro ao montar adaptadores na sessão: {e}")
        pass
    
    # Garantimos que o User-Agent seja o mais robusto possível
    session_obj.headers.update({'User-Agent': USER_AGENT})
    return session_obj

# Inicializa a sessão globalmente para ser reusada pelo Handler
GLOBAL_SESSION = get_global_session()

# ---------------- LÓGICA DO PROXY ----------------

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    session = GLOBAL_SESSION

    def log_message(self, format, *args):
        pass

    def do_HEAD(self):
        self._handle_request(method='HEAD')

    def do_GET(self):
        self._handle_request(method='GET')

    def _handle_request(self, method='GET'):
        target_url = None
        
        if self.session is None:
            logging.error("[VOD-PROXY] Sessão não está disponível. 'netunblock' falhou ao carregar?")
            self.send_error(503, "Proxy Service Unavailable (Session Error)")
            return

        try:
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            target_url = params.get('url', [None])[0]

            if not target_url:
                self.send_error(400, "URL parameter missing")
                return

            target_url = urllib.parse.unquote_plus(target_url)
            logging.info(f"[VOD-PROXY] Requisitando: {method} {target_url}")

            # --- MELHORIA: HEADERS OTIMIZADOS E REPASSADOS ---
            parsed_url = urllib.parse.urlparse(target_url)
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            
            # 1. Copia headers do cliente (Kodi)
            headers = {k: v for k, v in self.headers.items()}
            
            # 2. Define/Sobrescreve headers essenciais para parecer um navegador real
            headers['Referer'] = base_url
            headers['Accept'] = '*/*'
            headers['Accept-Language'] = 'en-US,en;q=0.9'
            headers['Accept-Encoding'] = 'gzip, deflate, br'
            headers['Connection'] = 'keep-alive'
            
            # Remove headers que são de conexão ou que a biblioteca de requisições cuida
            for h in ['Host', 'Content-Length']:
                if h in headers: del headers[h]
            # ---------------------------------------------------------------------

            # Requisição upstream usando a sessão com DoH ativo
            resp = self.session.request(
                method, 
                target_url, 
                headers=headers, 
                stream=True, 
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), 
                verify=False,
                allow_redirects=True
            )

            # 3. VERIFICAÇÃO DE BLOQUEIO (Content-Type)
            content_type = resp.headers.get('Content-Type', '').lower()
            
            if ('text/html' in content_type or 'text/plain' in content_type) and not (300 <= resp.status_code < 400):
                logging.error(f"[VOD-PROXY] Bloqueio de CDN/CloudFlare detectado. Status: {resp.status_code}. Content-Type: {content_type}")
                try:
                    response_snippet = resp.text[:500]
                    logging.error(f"[VOD-PROXY] Conteúdo da Resposta (início): {response_snippet}...")
                except Exception:
                    pass
                
                self.send_error(503, "Content Blocked (Returned HTML instead of Video Stream)")
                resp.close()
                return

            if resp.status_code >= 400:
                logging.error(f"[VOD-PROXY] Erro upstream {resp.status_code} para {target_url}")
                self.send_error(resp.status_code)
                resp.close()
                return

            self.send_response(resp.status_code)

            hop_by_hop = [
                'connection', 'keep-alive', 'proxy-authenticate', 
                'proxy-authorization', 'te', 'trailers', 
                'transfer-encoding', 'upgrade', 'content-encoding'
            ]

            for k, v in resp.headers.items():
                if k.lower() not in hop_by_hop:
                    self.send_header(k, v)

            if 'Content-Length' in resp.headers:
                self.send_header('Content-Length', resp.headers['Content-Length'])

            self.end_headers()

            if method == 'HEAD':
                resp.close()
                return

            # Streaming Direto
            try:
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.wfile.write(chunk)
            except (ConnectionError, socket.error) as e:
                logging.info(f"[VOD-PROXY] Conexão com o cliente (Kodi) fechada ou erro no stream: {e}")
            except Exception as e:
                logging.error(f"[VOD-PROXY] Erro inesperado no stream de dados: {e}")
            finally:
                resp.close()

        except Exception as e:
            logging.error(f"[VOD-PROXY] Erro fatal no handler: {e}", exc_info=True)
            try:
                self.send_error(502, "Bad Gateway")
            except:
                pass

class VODProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def start(self):
        if self._is_running: 
            return True
        self.stop()
        
        if GLOBAL_SESSION is None:
             logging.error("[VOD-PROXY] Impossível iniciar o proxy, a sessão global é inválida.")
             xbmcgui.Dialog().notification("VOD Proxy Error", "A dependência 'netunblock' não foi carregada.", xbmcgui.NOTIFICATION_ERROR)
             return False

        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 55000)
                self.server = ThreadedTCPServer((PROXY_HOST, port), VODProxyRequestHandler)
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                self.active_port = port
                self._is_running = True
                logging.info(f"[VOD-PROXY] Proxy iniciado com sucesso em http://{PROXY_HOST}:{port}")
                return True
            except OSError as e:
                logging.warning(f"[VOD-PROXY] Falha ao iniciar na porta {port}: {e}. Tentando outra...")
                continue
        
        logging.error("[VOD-PROXY] Não foi possível iniciar o VOD Proxy (sem portas livres após várias tentativas).")
        xbmcgui.Dialog().notification("VOD Proxy Error", "Não foi possível encontrar uma porta livre para o proxy.", xbmcgui.NOTIFICATION_ERROR)
        return False

    def stop(self):
        if not self._is_running:
            return
            
        self._is_running = False
        if self.server:
            try:
                logging.info("[VOD-PROXY] Desligando o servidor proxy...")
                self.server.shutdown()
                self.server.server_close()
                self.server_thread.join(timeout=5)
            except Exception as e:
                logging.error(f"[VOD-PROXY] Erro ao desligar o servidor proxy: {e}")
        self.server = None
        self.server_thread = None
        logging.info("[VOD-PROXY] Proxy desligado.")

class VODAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = VODProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        
        li = xbmcgui.ListItem(path=proxy_url)
        if title: 
            li.setLabel(title)
            li.setInfo('video', {'title': title})
        
        ext = url.lower().split('?')[0].split('.')[-1]
        mime_map = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'avi': 'video/x-msvideo', 'm3u8': 'application/vnd.apple.mpegurl', 'ts': 'video/mp2t'}
        li.setMimeType(mime_map.get(ext, 'application/octet-stream'))
        li.setProperty('IsPlayable', 'true')
        li.setContentLookup(False)

        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    if not NETUNBLOCK_AVAILABLE:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        xbmcplugin.endOfDirectory(handle)
        return

    try:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        addon = VODAddon(handle)
        
        params = {}
        if len(sys.argv) > 2:
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

        if params.get('action') == 'play_stream':
            addon.play_stream(
                params.get('stream_url'), 
                params.get('stream_type'), 
                params.get('title')
            )
        elif handle != -1:
            xbmcplugin.endOfDirectory(handle)
            
    except Exception as e:
        logging.error(f"[VOD-PROXY] Erro na função principal: {e}", exc_info=True)

if __name__ == '__main__':
    main()