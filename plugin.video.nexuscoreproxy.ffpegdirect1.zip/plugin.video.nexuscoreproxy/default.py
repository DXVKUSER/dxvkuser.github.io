#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
default.py — NEXUS CORE MPEG-TS & HLS Proxy
v3.5.0 — Stability / FFmpegDirect Optimized Edition

Pipeline otimizado:

MPEG-TS:
  URL original → tsproxy → HTTP local → inputstream.ffmpegdirect (curl) → Kodi

HLS:
  URL original → hlsproxy → manifesto local → inputstream.ffmpegdirect (ffmpeg/AVFormat) → Kodi

Melhorias aplicadas:
- TS: open_mode=curl, is_realtime_stream=true, mimetype=video/mp2t
- HLS: open_mode=ffmpeg, manifest_type=hls, is_realtime_stream=true, mimetype=application/x-mpegURL
- Separação rigorosa de propriedades TS vs HLS
- Sem timeshift forçado em live normal
- Sem catchup forçado
- Preservação completa de query strings
- Detecção robusta de URLs sem extensão
"""

import sys
import os
import re
import base64

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))

if _ADDON_DIR not in sys.path:
    sys.path.insert(0, _ADDON_DIR)

from urllib.parse import parse_qs, quote, urlparse, urlunparse


# ============================================================
# CONSTANTES
# ============================================================

FFMPEG_DIRECT = "inputstream.ffmpegdirect"
LOCALHOST = "127.0.0.1"

# MIME types oficiais conforme documentação do ffmpegdirect
TS_MIMETYPE = "video/mp2t"
HLS_MIMETYPE = "application/x-mpegURL"


# ============================================================
# DETECÇÃO DE TIPO DE URL
# ============================================================

_RE_NUMERIC_END = re.compile(r"/\d+$")
_RE_ALPHANUM_NOEXT = re.compile(r"/[A-Za-z0-9]{4,}/[A-Za-z0-9]{4,}/\d+$")


def _path_only(url):
    """Extrai apenas o path em minúsculas da URL."""
    try:
        return urlparse(url).path.lower()
    except Exception:
        return ""


def _is_hls(url):
    """Detecta HLS pela extensão .m3u8 ou .m3u."""
    path = _path_only(url)
    return path.endswith(".m3u8") or path.endswith(".m3u")


def _is_ts_explicit(url):
    """Detecta TS explícito pela extensão .ts."""
    return _path_only(url).endswith(".ts")


def _is_ts_no_ext(url):
    """Detecta TS sem extensão por padrões numéricos no path."""
    path = _path_only(url)
    return bool(
        _RE_NUMERIC_END.search(path) or
        _RE_ALPHANUM_NOEXT.search(path)
    )


def _url_type(url):
    """
    Classifica a URL em um dos tipos:
    - 'hls': manifesto HLS
    - 'ts_ext': TS com extensão .ts
    - 'ts_noext': TS sem extensão
    - 'unknown': não identificado
    """
    if _is_hls(url):
        return "hls"
    if _is_ts_explicit(url):
        return "ts_ext"
    if _is_ts_no_ext(url):
        return "ts_noext"
    return "unknown"


# ============================================================
# CONVERSÃO PARA MPEG-TS
# ============================================================

def _convert_to_ts(url):
    """
    Converte a URL para formato tratável pelo tsproxy.
    Preserva integralmente a query string original.
    """
    t = _url_type(url)
    parsed = urlparse(url)

    # TS já explícito: garante /live/ no path
    if t == "ts_ext":
        path_parts = [p for p in parsed.path.split("/") if p]
        if path_parts and path_parts[0].lower() != "live":
            path_parts.insert(0, "live")
            new_path = "/" + "/".join(path_parts)
            return urlunparse(parsed._replace(path=new_path))
        return url

    # Constrói path com /live/
    path_parts = [p for p in parsed.path.split("/") if p]
    if path_parts and path_parts[0].lower() != "live":
        path_parts.insert(0, "live")

    base_path = "/" + "/".join(path_parts)

    # HLS → TS: troca extensão
    if t == "hls":
        if base_path.lower().endswith(".m3u8"):
            new_path = base_path[:-5] + ".ts"
        else:
            new_path = base_path + ".ts"
    # URL sem extensão → TS: adiciona .ts
    else:
        if base_path.lower().endswith(".ts"):
            new_path = base_path
        else:
            new_path = base_path + ".ts"

    return urlunparse(parsed._replace(path=new_path))


# ============================================================
# CONVERSÃO PARA HLS
# ============================================================

def _convert_to_hls(url):
    """
    Converte a URL para .m3u8 para o hlsproxy.
    Preserva integralmente a query string original.
    """
    t = _url_type(url)
    parsed = urlparse(url)

    # Já é HLS
    if t == "hls":
        return url

    # TS explícito → M3U8: troca extensão
    if t == "ts_ext":
        path = parsed.path
        if path.lower().endswith(".ts"):
            path = path[:-3] + ".m3u8"
        return urlunparse(parsed._replace(path=path))

    # URL sem extensão → M3U8
    path_parts = [p for p in parsed.path.split("/") if p]
    if path_parts and path_parts[0].lower() != "live":
        path_parts.insert(0, "live")

    new_path = "/" + "/".join(path_parts) + ".m3u8"
    return urlunparse(parsed._replace(path=new_path))


# ============================================================
# LABELS
# ============================================================

_TYPE_LABELS = {
    "hls": "HLS (.m3u8)",
    "ts_ext": "MPEG-TS (.ts)",
    "ts_noext": "MPEG-TS (sem extensão)",
    "unknown": "stream",
}


def _url_type_label(url):
    """Retorna label amigável para o tipo de URL."""
    return _TYPE_LABELS.get(_url_type(url), "stream")


# ============================================================
# DIÁLOGO DE SELEÇÃO DO PROXY
# ============================================================

def _dialog_choose_proxy(url):
    """Exibe diálogo para o usuário escolher entre TS Proxy e HLS Proxy."""
    import xbmcgui

    label = _url_type_label(url)
    dialog = xbmcgui.Dialog()
    options = [
        "Proxy MPEG-TS  (tsproxy)",
        "Proxy HLS      (hlsproxy)",
    ]
    return dialog.select(
        f"NEXUS CORE — Escolha o Proxy [{label}]",
        options,
    )


# ============================================================
# CONFIGURAÇÃO FFMPEGDIRECT — MPEG-TS
# ============================================================

def _configure_ffmpegdirect_ts(li):
    """
    Configuração dedicada para MPEG-TS.

    Propriedades aplicadas:
    - inputstream = inputstream.ffmpegdirect
    - mimetype = video/mp2t
    - open_mode = curl (TS é aberto diretamente via cURL)
    - is_realtime_stream = true

    NÃO aplicar:
    - manifest_type (exclusivo para HLS/DASH/Smooth Streaming)
    - stream_mode = timeshift (reservado para buffer local de timeshift)
    - stream_mode = catchup (reservado para streams de arquivo/catchup)
    """
    li.setProperty("inputstream", FFMPEG_DIRECT)
    li.setMimeType(TS_MIMETYPE)
    li.setProperty("mimetype", TS_MIMETYPE)
    li.setProperty("inputstream.ffmpegdirect.open_mode", "curl")
    li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)


# ============================================================
# CONFIGURAÇÃO FFMPEGDIRECT — HLS
# ============================================================

def _configure_ffmpegdirect_hls(li):
    """
    Configuração dedicada para HLS.

    Propriedades aplicadas:
    - inputstream = inputstream.ffmpegdirect
    - mimetype = application/x-mpegURL
    - manifest_type = hls
    - open_mode = ffmpeg (AVFormat para parsing do manifesto e segmentos)
    - is_realtime_stream = true

    NÃO aplicar:
    - stream_mode = timeshift (não forçar em live normal)
    - stream_mode = catchup (não forçar sem necessidade)
    """
    li.setProperty("inputstream", FFMPEG_DIRECT)
    li.setMimeType(HLS_MIMETYPE)
    li.setProperty("mimetype", HLS_MIMETYPE)
    li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
    li.setProperty("inputstream.ffmpegdirect.open_mode", "curl")
    li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)


# ============================================================
# PLAY VIA TSPROXY
# ============================================================

def _play_ts(handle, url):
    """
    Reproduz stream MPEG-TS através do tsproxy local.
    Pipeline: URL → tsproxy → inputstream.ffmpegdirect (curl) → Kodi
    """
    import xbmcplugin
    import xbmcgui
    import xbmc

    url_final = _convert_to_ts(url)
    if url_final != url:
        xbmc.log(f"[NexusCore] Convertido para TS: {url_final}", xbmc.LOGINFO)
    xbmc.log(f"[NexusCore] tsproxy(v36-STDLIB) ← {url_final[:120]}", xbmc.LOGINFO)

    # Inicia o tsproxy
    try:
        import tsproxy
        proxy_port = tsproxy._ensure_server_running()
    except Exception as e:
        xbmc.log(f"[NexusCore] Falha ao iniciar tsproxy: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # URL local do proxy
    local_url = (
        f"http://{LOCALHOST}:{proxy_port}/stream"
        f"?url={quote(url_final, safe='')}"
    )
    xbmc.log(f"[NexusCore] tsproxy local: {local_url}", xbmc.LOGINFO)

    # Cria ListItem e aplica configuração TS dedicada
    li = xbmcgui.ListItem(path=local_url)
    _configure_ffmpegdirect_ts(li)

    xbmcplugin.setResolvedUrl(handle, True, li)


# ============================================================
# PLAY VIA HLSPROXY
# ============================================================

def _play_hls(handle, url):
    """
    Reproduz stream HLS através do hlsproxy local.
    Pipeline: URL → hlsproxy → inputstream.ffmpegdirect (ffmpeg/AVFormat) → Kodi
    """
    import xbmcplugin
    import xbmcgui
    import xbmc

    url_final = _convert_to_hls(url)
    if url_final != url:
        xbmc.log(f"[NexusCore] Convertido para HLS: {url_final}", xbmc.LOGINFO)
    xbmc.log(f"[NexusCore] hlsproxy + ffmpegdirect ← {url_final[:120]}", xbmc.LOGINFO)

    # Inicia o hlsproxy
    try:
        import hlsproxy
        proxy_port = hlsproxy._ensure_server_running()
    except Exception as e:
        xbmc.log(f"[NexusCore] Falha ao iniciar hlsproxy: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # Codifica URL em base64 URL-safe para o proxy
    raw = url_final.encode("utf-8")
    b64 = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    local_url = f"http://{LOCALHOST}:{proxy_port}/playlist/{b64}.m3u8"
    xbmc.log(f"[NexusCore] hlsproxy local: {local_url}", xbmc.LOGINFO)

    # Cria ListItem e aplica configuração HLS dedicada
    li = xbmcgui.ListItem(path=local_url)
    _configure_ffmpegdirect_hls(li)

    xbmcplugin.setResolvedUrl(handle, True, li)


# ============================================================
# ACTION: PLAY
# ============================================================

def _action_play(handle, params):
    """
    Ação principal de reprodução.
    Detecta o tipo de URL e oferece escolha do proxy quando necessário.
    """
    import xbmcplugin
    import xbmcgui
    import xbmc

    url = params.get("url", [None])[0]
    if not url:
        xbmc.log("[NexusCore] action=play sem parâmetro url", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    tipo = _url_type(url)
    xbmc.log(f"[NexusCore] action=play tipo={tipo} url={url[:120]}", xbmc.LOGINFO)

    # Verifica se o proxy foi especificado explicitamente
    proxy_type = params.get("proxy_type", [None])[0]

    if proxy_type == "ts":
        escolha = 0
    elif proxy_type == "hls":
        escolha = 1
    else:
        escolha = _dialog_choose_proxy(url)

    # Usuário cancelou
    if escolha == -1:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # MPEG-TS
    if escolha == 0:
        _play_ts(handle, url)
        return

    # HLS
    if escolha == 1:
        _play_hls(handle, url)
        return

    # Fallback
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


# ============================================================
# ROUTER PRINCIPAL
# ============================================================

def _router():
    """Roteador principal que interpreta os argumentos do Kodi."""
    if len(sys.argv) < 3:
        return

    try:
        handle = int(sys.argv[1])
    except Exception:
        return

    raw_params = sys.argv[2].lstrip("?")
    params = parse_qs(raw_params)
    action = params.get("action", [None])[0]

    if action == "play":
        _action_play(handle, params)
    else:
        try:
            import xbmcplugin
            import xbmcgui
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        except Exception:
            pass


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    _router()