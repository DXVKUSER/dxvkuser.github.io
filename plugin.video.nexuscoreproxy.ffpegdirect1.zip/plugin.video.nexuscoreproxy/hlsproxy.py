#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — NEXUS CORE HLS Proxy Engine
v1.8.1 — Path Parameters + STRICT Single Persistent Session (1 Conexão/Host)

Recursos:
  • SESSÃO ESTRITA (1 Conexão): Serialização de threads para evitar ban/erros 400/500 no provedor.
  • PATH PARAMETERS (Base64): Compatível com FFmpeg do Manjaro Linux
  • DEBUG LOG TOGGLE: Controle de logs silencioso por padrão
  • DoH (DNS-over-HTTPS) resolver no topo (sem recursão)
  • Sessão HTTP Persistente: Uma conexão keep-alive real por host
  • Cache de Playlist + Single-Flight: Evita requisições duplicadas
  • Detecção de Falso 200 OK: Manifesto vazio, páginas de erro HTML
  • Reconexão Automática: Sem interromper a reprodução
  • Zero-Error ao Kodi: Nunca envia status de erro ao player
  • Interceptação e proxy de chaves AES-128
"""

import sys
import os
import re
import socket
import ssl
import json
import time
import base64
import threading
import urllib.request
import urllib.error
import urllib.parse
import http.client
import http.server
import http.cookiejar
import socketserver
from urllib.parse import urlparse, urljoin, quote
from collections import defaultdict

# ════════════════════════════════════════════════════════════
# DEBUG LOG CONTROL
# ════════════════════════════════════════════════════════════

DEBUG_LOG_ENABLED = False

def set_debug_log(enabled: bool):
    """Função para ativar ou desativar os logs do Proxy."""
    global DEBUG_LOG_ENABLED
    DEBUG_LOG_ENABLED = enabled


def _log(msg, level='info'):
    if not DEBUG_LOG_ENABLED:
        return
    try:
        import xbmc
        levels = {
            'info':    xbmc.LOGINFO,
            'error':   xbmc.LOGERROR,
            'warning': xbmc.LOGWARNING,
        }
        xbmc.log(f'[NexusCore-HLS] {msg}', levels.get(level, xbmc.LOGINFO))
    except ImportError:
        pass

# ════════════════════════════════════════════════════════════
# BASE64 URL ENCODER/DECODER (Path Parameters Fix)
# ════════════════════════════════════════════════════════════

def _b64_encode_url(url: str) -> str:
    """Codifica a URL para Base64 URL-safe (sem '=', '+' ou '/')."""
    return base64.urlsafe_b64encode(url.encode('utf-8')).decode('utf-8').rstrip('=')


def _b64_decode_url(encoded: str) -> str:
    """Decodifica a URL Base64 URL-safe de volta para string."""
    padding = '=' * (-len(encoded) % 4)
    return base64.urlsafe_b64decode(encoded + padding).decode('utf-8')


# ════════════════════════════════════════════════════════════
# DoH RESOLVER
# ════════════════════════════════════════════════════════════

_RE_IPV4 = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
_RE_IPV6 = re.compile(r'^[0-9a-fA-F:]+$')

_DNS_CACHE      = {}
_DNS_CACHE_LOCK = threading.Lock()
_DNS_CACHE_TTL  = 300

_in_doh_resolution = threading.local()

DOH_SERVERS = [
    'https://dns.google/resolve',
    'https://cloudflare-dns.com/dns-query',
]

_orig_getaddrinfo = socket.getaddrinfo


def _is_ip(host):
    if not host:
        return False
    host = host.strip('[]')
    if _RE_IPV4.match(host):
        try:
            parts = host.split('.')
            return all(0 <= int(p) <= 255 for p in parts)
        except Exception:
            return False
    if ':' in host and _RE_IPV6.match(host):
        return True
    return False


def _doh_resolve(hostname, timeout=5):
    if _is_ip(hostname):
        return hostname

    now = time.time()
    with _DNS_CACHE_LOCK:
        cached = _DNS_CACHE.get(hostname)
        if cached and now - cached[1] < _DNS_CACHE_TTL:
            return cached[0]

    for doh_url in DOH_SERVERS:
        try:
            req_url = f'{doh_url}?name={quote(hostname)}&type=A'
            req = urllib.request.Request(req_url, headers={
                'Accept': 'application/dns-json',
                'User-Agent': 'NEXUS-CORE-DoH/1.0',
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if 'Answer' in data:
                    for ans in data['Answer']:
                        if ans.get('type') == 1:
                            ip = ans.get('data')
                            if ip and _is_ip(ip):
                                with _DNS_CACHE_LOCK:
                                    _DNS_CACHE[hostname] = (ip, now)
                                _log(f'DoH: {hostname} -> {ip}')
                                return ip
        except Exception as e:
            _log(f'DoH falhou ({doh_url}): {e}', 'warning')
            continue

    try:
        results = _orig_getaddrinfo(hostname, None)
        if results:
            ip = results[0][4][0]
            with _DNS_CACHE_LOCK:
                _DNS_CACHE[hostname] = (ip, now)
            _log(f'DNS local: {hostname} -> {ip}')
            return ip
    except Exception:
        pass

    _log(f'Não foi possível resolver: {hostname}', 'error')
    return hostname


def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if getattr(_in_doh_resolution, 'active', False):
        return _orig_getaddrinfo(host, port, family, type, proto, flags)

    if host and not _is_ip(host):
        try:
            _in_doh_resolution.active = True
            ip = _doh_resolve(host)
            if ip and _is_ip(ip):
                host = ip
        except Exception:
            pass
        finally:
            _in_doh_resolution.active = False

    return _orig_getaddrinfo(host, port, family, type, proto, flags)


socket.getaddrinfo = _patched_getaddrinfo
_log('DoH resolver ativado (socket.getaddrinfo patcheado com anti-recursão)')

# ════════════════════════════════════════════════════════════
# SSL CONTEXT
# ════════════════════════════════════════════════════════════

_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode   = ssl.CERT_NONE

_UA_FALLBACK = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# ════════════════════════════════════════════════════════════
# COOKIE STORE
# ════════════════════════════════════════════════════════════

_simple_cookies = {}
_cookie_lock    = threading.Lock()


def _get_cookie_header(url):
    netloc = urlparse(url).netloc
    parts = []
    with _cookie_lock:
        for domain, cookies in _simple_cookies.items():
            d = domain.lstrip('.')
            if d == netloc or netloc.endswith('.' + d) or d in netloc:
                for name, value in cookies.items():
                    parts.append(f'{name}={value}')
    return '; '.join(parts) if parts else None


def _save_cookies(url, set_cookie_headers):
    if not set_cookie_headers:
        return
    netloc = urlparse(url).netloc
    if isinstance(set_cookie_headers, str):
        set_cookie_headers = [set_cookie_headers]
    with _cookie_lock:
        for sc in set_cookie_headers:
            parts = sc.split(';')[0].split('=', 1)
            if len(parts) != 2:
                continue
            name  = parts[0].strip()
            value = parts[1].strip()
            domain = netloc
            for attr in sc.split(';')[1:]:
                a = attr.strip()
                if a.lower().startswith('domain='):
                    domain = a.split('=', 1)[1].strip()
                    break
            key_domain = domain.lstrip('.')
            if key_domain not in _simple_cookies:
                _simple_cookies[key_domain] = {}
            _simple_cookies[key_domain][name] = value


# ════════════════════════════════════════════════════════════
# FALSE 200 DETECTION
# ════════════════════════════════════════════════════════════

_HTML_ERROR_INDICATORS = [
    b'<html', b'<!doctype', b'<head>', b'<title>', b'<?xml',
    b'<body', b'<center>', b'<h1>', b'<h2>',
]

_TEXT_ERROR_INDICATORS = [
    b'error 500', b'error 404', b'error 403', b'error 400',
    b'internal server error', b'access denied', b'forbidden',
    b'service unavailable', b'maintenance mode', b'timeout',
    b'not found', b'unauthorized', b'bad request', b'overload',
    b'rate limit', b'too many requests', b'server error',
]


def _is_false_200(body, is_playlist=False):
    if not body or len(body) == 0:
        return True

    if is_playlist:
        text = body.decode('utf-8', errors='ignore').strip()
        if not text:
            return True
        if '#EXTM3U' not in text:
            return True
        if _is_empty_playlist(body):
            return True

    head = body[:1024].lower()

    for indicator in _HTML_ERROR_INDICATORS:
        if indicator in head:
            return True

    for indicator in _TEXT_ERROR_INDICATORS:
        if indicator in head:
            return True

    if not is_playlist and len(body) < 8:
        return True

    return False


def _is_empty_playlist(body):
    text = body.decode('utf-8', errors='ignore').replace('\r\n', '\n')
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('#'):
            continue
        return False
    return True


# ════════════════════════════════════════════════════════════
# PERSISTENT HTTP SESSION (STRICTLY Single Connection Per Host)
# ════════════════════════════════════════════════════════════

class HttpSession:
    def __init__(self):
        self._conns = {}
        self._locks = {}
        self._meta_lock = threading.Lock()

    def _get_lock(self, key):
        with self._meta_lock:
            if key not in self._locks:
                self._locks[key] = threading.RLock()
            return self._locks[key]

    def _get_conn(self, scheme, netloc, timeout):
        # A chave agora omite o 'channel'. Isso força 100% das requisições
        # para o mesmo host a usarem a MESMA conexão e entrarem na mesma FILA de Lock.
        key = (scheme, netloc)
        with self._meta_lock:
            conn = self._conns.get(key)
            if conn is None:
                if scheme == 'https':
                    conn = http.client.HTTPSConnection(
                        netloc, timeout=timeout, context=_ssl_ctx
                    )
                else:
                    conn = http.client.HTTPConnection(
                        netloc, timeout=timeout
                    )
                self._conns[key] = conn
            return conn

    def _kill_conn(self, key):
        with self._meta_lock:
            conn = self._conns.pop(key, None)
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    def _build_headers(self, url, extra=None):
        parsed = urlparse(url)
        h = {
            'Accept':          '*/*',
            'Accept-Language':  'en-US,en;q=0.5',
            'Connection':      'keep-alive',
            'Host':            parsed.netloc,
            'User-Agent':      _UA_FALLBACK,
        }

        if parsed.scheme == 'https':
            h['Origin']  = f'https://{parsed.netloc}'
            h['Referer'] = f'https://{parsed.netloc}/'
        else:
            h['Origin']  = f'http://{parsed.netloc}'
            h['Referer'] = f'http://{parsed.netloc}/'

        cookie_str = _get_cookie_header(url)
        if cookie_str:
            h['Cookie'] = cookie_str

        if extra:
            for k, v in extra.items():
                kl = k.lower()
                if kl not in ('host', 'connection', 'accept-encoding',
                              'user-agent', 'cookie'):
                    h[k] = v
        return h

    def fetch(self, url, extra_headers=None, timeout=30, retries=3,
              is_playlist=False, channel='meta'):
        current_url  = url
        last_body    = b''
        last_status  = 200
        last_headers = {}

        for _redirect_iter in range(10):
            parsed = urlparse(current_url)
            
            # CHAVE UNIFICADA - Garante que todo tipo de tráfego para o host entre no mesmo pool de 1 conexão
            key = (parsed.scheme, parsed.netloc)
            lock = self._get_lock(key)
            headers = self._build_headers(current_url, extra_headers)
            path = (parsed.path or '/') + (
                ('?' + parsed.query) if parsed.query else ''
            )

            is_redirect = False
            status = 0

            # O Lock garante que NENHUMA requisição simultânea vai para o mesmo servidor
            with lock:
                for attempt in range(retries):
                    try:
                        conn = self._get_conn(
                            parsed.scheme, parsed.netloc, timeout
                        )
                        
                        try:
                            conn.request('GET', path, headers=headers)
                            resp = conn.getresponse()
                        except (http.client.CannotSendRequest, http.client.ResponseNotReady, ConnectionError):
                            # Se a conexão antiga fechar ociosamente, nós a matamos e tentamos no mesmo loop
                            self._kill_conn(key)
                            conn = self._get_conn(parsed.scheme, parsed.netloc, timeout)
                            conn.request('GET', path, headers=headers)
                            resp = conn.getresponse()

                        status = resp.status
                        body   = resp.read()

                        resp_headers_list = resp.getheaders()
                        resp_headers = {}
                        set_cookies   = []
                        for k, v in resp_headers_list:
                            if k.lower() == 'set-cookie':
                                set_cookies.append(v)
                            else:
                                resp_headers[k] = v
                        
                        # Precisamos garantir a leitura total do body antes de liberar para a próxima requisição keep-alive
                        resp.close()

                        if set_cookies:
                            _save_cookies(current_url, set_cookies)

                        if resp_headers.get('Connection', '').lower() == 'close':
                            self._kill_conn(key)

                        if status in (301, 302, 307, 308):
                            location = resp_headers.get('Location', '')
                            if location:
                                current_url = urljoin(current_url, location)
                                _log(f'Redirect: -> {current_url[:120]}')
                                is_redirect = True
                                break
                            else:
                                raise Exception("Redirect sem Location header")

                        if status >= 400:
                            _log(
                                f'HTTP {status} upstream, '
                                f'retry {attempt + 1}/{retries}',
                                'warning'
                            )
                            self._kill_conn(key)
                            time.sleep(0.3 * (attempt + 1))
                            last_status  = status
                            last_body    = body
                            last_headers = resp_headers
                            continue

                        if _is_false_200(body, is_playlist):
                            _log(
                                f'Falso 200 OK detectado ({len(body)}b), '
                                f'retry {attempt + 1}/{retries}',
                                'warning'
                            )
                            self._kill_conn(key)
                            time.sleep(0.3 * (attempt + 1))
                            continue

                        return body, current_url, status, resp_headers

                    except Exception as e:
                        _log(
                            f'Fetch error retry {attempt + 1}/{retries}: {e}',
                            'warning'
                        )
                        self._kill_conn(key)
                        time.sleep(0.3 * (attempt + 1))

            if is_redirect:
                continue

            return last_body or b'', current_url, last_status, last_headers

        raise Exception("Muitos redirecionamentos")

    def close(self):
        with self._meta_lock:
            for conn in self._conns.values():
                try:
                    conn.close()
                except Exception:
                    pass
            self._conns.clear()
            self._locks.clear()


_session = HttpSession()

# ════════════════════════════════════════════════════════════
# PLAYLIST CACHE + SINGLE-FLIGHT
# ════════════════════════════════════════════════════════════

_playlist_cache     = {}
_playlist_cache_lock = threading.Lock()
_PLAYLIST_CACHE_TTL  = 2

_playlist_flight_locks = {}
_playlist_flight_meta  = threading.Lock()


def _get_flight_lock(url):
    with _playlist_flight_meta:
        if url not in _playlist_flight_locks:
            _playlist_flight_locks[url] = threading.Lock()
        return _playlist_flight_locks[url]


def _get_cached_playlist(url, allow_stale=False):
    with _playlist_cache_lock:
        entry = _playlist_cache.get(url)
        if entry:
            ts, body, final_url = entry
            if allow_stale or (time.time() - ts) < _PLAYLIST_CACHE_TTL:
                return (body, final_url)
    return None


def _set_cached_playlist(url, body, final_url):
    with _playlist_cache_lock:
        _playlist_cache[url] = (time.time(), body, final_url)


# ════════════════════════════════════════════════════════════
# KEY CACHE
# ════════════════════════════════════════════════════════════

_key_cache      = {}
_key_cache_lock = threading.Lock()


def _get_cached_key(url):
    with _key_cache_lock:
        return _key_cache.get(url)


def _set_cached_key(url, data):
    with _key_cache_lock:
        _key_cache[url] = data


# ════════════════════════════════════════════════════════════
# GLOBAL STATE
# ════════════════════════════════════════════════════════════

_PROXY_PORT   = None
_PROXY_SERVER = None
_PROXY_LOCK   = threading.Lock()


# ════════════════════════════════════════════════════════════
# HLS PROXY HTTP HANDLER
# ════════════════════════════════════════════════════════════

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):

    protocol_version = 'HTTP/1.1'
    timeout = 15

    def do_GET(self):
        parsed = urlparse(self.path)
        # Exemplo esperado: /playlist/CHAVE_BASE64.m3u8
        clean_path = parsed.path.strip('/')
        parts = clean_path.split('/', 1)
        
        endpoint = parts[0]
        encoded = parts[1] if len(parts) > 1 else ''
        
        if encoded.endswith('.m3u8'):
            encoded = encoded[:-5]
            
        if endpoint == 'favicon.ico' or not encoded:
            self._send_ok_empty()
            return
            
        try:
            original_url = _b64_decode_url(encoded)
        except Exception:
            self._send_ok_empty()
            return
            
        if endpoint in ('playlist', 'master.m3u8', 'playlist.m3u8', 'm3u8'):
            self._handle_playlist({'url': original_url})
        elif endpoint in ('seg', 'segment'):
            self._handle_segment({'url': original_url})
        elif endpoint == 'key':
            self._handle_key({'url': original_url})
        else:
            self._send_ok_empty()

    def do_HEAD(self):
        """HEAD sempre retorna 200 — nunca envia erro ao Kodi."""
        self._send_ok_empty()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin',  '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Content-Length', '0')
        self.end_headers()

    # ──────────────────────────────────────────────────────
    # HELPERS — Nunca envia erro ao Kodi
    # ──────────────────────────────────────────────────────

    def _get_kodi_headers(self):
        kodi_h = {}
        if 'Range' in self.headers:
            kodi_h['Range'] = self.headers['Range']
        return kodi_h

    def _send_ok_playlist(self, body):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send playlist error: {e}', 'warning')

    def _send_ok_segment(self, body, headers=None):
        try:
            self.send_response(200)
            ct = 'video/mp2t'
            if headers:
                ct = headers.get('Content-Type', ct)
            self.send_header('Content-Type', ct)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')

            if headers:
                cr = headers.get('Content-Range')
                if cr:
                    self.send_header('Content-Range', cr)

            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send segment error: {e}', 'warning')

    def _send_ok_key(self, data):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send key error: {e}', 'warning')

    def _send_ok_empty(self):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', '0')
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send empty error: {e}', 'warning')

    # ──────────────────────────────────────────────────────
    # PLAYLIST HANDLER
    # ──────────────────────────────────────────────────────

    def _handle_playlist(self, params):
        url = params.get('url')
        if not url:
            self._send_ok_playlist(b'#EXTM3U\n#EXT-X-ENDLIST\n')
            return

        flight_lock = _get_flight_lock(url)

        with flight_lock:
            cached = _get_cached_playlist(url)
            if cached:
                body, final_url = cached
                rewritten = self._rewrite_playlist(
                    body.decode('utf-8', errors='replace'), final_url
                )
                self._send_ok_playlist(rewritten.encode('utf-8'))
                return

            max_outer_retries = 3
            for outer in range(max_outer_retries):
                try:
                    body, final_url, status, headers = _session.fetch(
                        url,
                        extra_headers=self._get_kodi_headers(),
                        timeout=15,
                        retries=3,
                        is_playlist=True,
                        channel='meta',
                    )

                    if body and not _is_false_200(body, is_playlist=True) \
                       and not _is_empty_playlist(body):
                        _set_cached_playlist(url, body, final_url)
                        rewritten = self._rewrite_playlist(
                            body.decode('utf-8', errors='replace'), final_url
                        )
                        self._send_ok_playlist(rewritten.encode('utf-8'))
                        return
                    else:
                        _log(
                            f'Playlist inválido/empty, '
                            f'tentativa externa {outer + 1}/{max_outer_retries}',
                            'warning'
                        )
                        time.sleep(0.5 * (outer + 1))

                except Exception as e:
                    _log(
                        f'Playlist fetch error, '
                        f'tentativa {outer + 1}/{max_outer_retries}: {e}',
                        'warning'
                    )
                    time.sleep(0.5 * (outer + 1))

            stale = _get_cached_playlist(url, allow_stale=True)
            if stale:
                _log('Servindo playlist do cache stale', 'warning')
                body, final_url = stale
                rewritten = self._rewrite_playlist(
                    body.decode('utf-8', errors='replace'), final_url
                )
                self._send_ok_playlist(rewritten.encode('utf-8'))
                return

            _log('Playlist esgotado — enviando playlist terminal', 'warning')
            self._send_ok_playlist(b'#EXTM3U\n#EXT-X-ENDLIST\n')

    def _rewrite_playlist(self, content, base_url):
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        lines   = content.split('\n')
        result  = []
        prev_tag = None

        for line in lines:
            stripped = line.strip()

            if not stripped:
                result.append('')
                continue

            if stripped.startswith('#'):
                if '#EXT-X-STREAM-INF' in stripped:
                    prev_tag = 'stream'
                elif '#EXTINF' in stripped:
                    prev_tag = 'segment'

                if 'URI="' in stripped:
                    stripped = self._rewrite_uri_in_tag(stripped, base_url)

                result.append(stripped)
                continue

            absolute = urljoin(base_url, stripped)
            b64_url  = _b64_encode_url(absolute)

            if prev_tag == 'stream':
                proxy_url = f'http://127.0.0.1:{_PROXY_PORT}/playlist/{b64_url}.m3u8'
            else:
                proxy_url = f'http://127.0.0.1:{_PROXY_PORT}/seg/{b64_url}'

            result.append(proxy_url)

        return '\n'.join(result)

    def _rewrite_uri_in_tag(self, line, base_url):
        def replace_uri(match):
            original = match.group(1)
            if original.startswith('data:'):
                return f'URI="{original}"'

            absolute = urljoin(base_url, original)
            b64_url  = _b64_encode_url(absolute)

            if '#EXT-X-KEY' in line or '#EXT-X-SESSION-KEY' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/key/{b64_url}"'
            elif '#EXT-X-MAP' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg/{b64_url}"'
            elif '#EXT-X-MEDIA' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/playlist/{b64_url}.m3u8"'
            else:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg/{b64_url}"'

        return re.sub(r'URI="([^"]+)"', replace_uri, line)

    # ──────────────────────────────────────────────────────
    # SEGMENT HANDLER
    # ──────────────────────────────────────────────────────

    def _handle_segment(self, params):
        url = params.get('url')
        if not url:
            self._send_ok_empty()
            return

        max_outer_retries = 3
        for outer in range(max_outer_retries):
            try:
                body, final_url, status, headers = _session.fetch(
                    url,
                    extra_headers=self._get_kodi_headers(),
                    timeout=30,
                    retries=3,
                    is_playlist=False,
                    channel='data',
                )

                if body and len(body) > 0 \
                   and not _is_false_200(body, is_playlist=False):
                    self._send_ok_segment(body, headers)
                    return
                else:
                    _log(
                        f'Segment inválido/empty ({len(body)}b), '
                        f'tentativa {outer + 1}/{max_outer_retries}',
                        'warning'
                    )
                    time.sleep(0.3 * (outer + 1))

            except Exception as e:
                _log(
                    f'Segment fetch error, '
                    f'tentativa {outer + 1}/{max_outer_retries}: {e}',
                    'warning'
                )
                time.sleep(0.3 * (outer + 1))

        _log(f'Segment esgotado — enviando vazio: {url[:80]}', 'warning')
        self._send_ok_empty()

    # ──────────────────────────────────────────────────────
    # KEY HANDLER (AES-128)
    # ──────────────────────────────────────────────────────

    def _handle_key(self, params):
        url = params.get('url')
        if not url:
            self._send_ok_key(b'\x00' * 16)
            return

        cached_key = _get_cached_key(url)
        if cached_key:
            self._send_ok_key(cached_key)
            return

        max_outer_retries = 3
        for outer in range(max_outer_retries):
            try:
                body, final_url, status, headers = _session.fetch(
                    url,
                    extra_headers=self._get_kodi_headers(),
                    timeout=15,
                    retries=3,
                    is_playlist=False,
                    channel='meta',
                )

                if body and len(body) >= 16 \
                   and not _is_false_200(body, is_playlist=False):
                    key_hex = body[:16].hex()
                    _log(
                        f'AES-128 Key: {len(body)}b '
                        f'hex={key_hex[:32]}... <- {url[:80]}'
                    )
                    _set_cached_key(url, body)
                    self._send_ok_key(body)
                    return
                else:
                    _log(
                        f'Key inválida ({len(body)}b), '
                        f'tentativa {outer + 1}/{max_outer_retries}',
                        'warning'
                    )
                    time.sleep(0.3 * (outer + 1))

            except Exception as e:
                _log(
                    f'Key fetch error, '
                    f'tentativa {outer + 1}/{max_outer_retries}: {e}',
                    'warning'
                )
                time.sleep(0.3 * (outer + 1))

        _log(f'Key esgotada — enviando zeros: {url[:80]}', 'warning')
        self._send_ok_key(b'\x00' * 16)

    def log_message(self, format, *args):
        pass


# ════════════════════════════════════════════════════════════
# THREADED HTTP SERVER
# ════════════════════════════════════════════════════════════

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads      = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        """
        Sobrescreve o handler de erros do SocketServer para silenciar 
        o log de ConnectionResetError e BrokenPipeError no Kodi.
        """
        e_type, e_value, e_tb = sys.exc_info()
        if e_type in (ConnectionResetError, BrokenPipeError, ssl.SSLError, TimeoutError):
            return
        if DEBUG_LOG_ENABLED:
            _log(f"Erro no SocketServer: {e_type.__name__}: {e_value}", 'error')


# ════════════════════════════════════════════════════════════
# SERVER MANAGEMENT
# ════════════════════════════════════════════════════════════

def _ensure_server_running():
    global _PROXY_PORT, _PROXY_SERVER
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None and _PROXY_PORT is not None:
            return _PROXY_PORT

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', 0))
        _PROXY_PORT = sock.getsockname()[1]
        sock.close()

        _PROXY_SERVER = ThreadingHTTPServer(
            ('127.0.0.1', _PROXY_PORT), HLSProxyHandler
        )

        thread = threading.Thread(
            target=_PROXY_SERVER.serve_forever, daemon=True
        )
        thread.start()

        _log(f'HLS Proxy server iniciado na porta {_PROXY_PORT}')
        return _PROXY_PORT


def _stop_server():
    global _PROXY_SERVER, _PROXY_PORT
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None:
            _PROXY_SERVER.shutdown()
            _PROXY_SERVER.server_close()
            _PROXY_SERVER = None
            _PROXY_PORT   = None
            _log('HLS Proxy server parado')
    _session.close()


# ════════════════════════════════════════════════════════════
# KODI ADDON INTERFACE
# ════════════════════════════════════════════════════════════

class HLSAddon:
    def __init__(self, addon_handle=None):
        self.addon_handle = addon_handle

    def play_stream(self, url):
        import xbmc
        import xbmcplugin
        import xbmcgui

        port = _ensure_server_running()
        b64_url = _b64_encode_url(url)
        # A URL agora usa Path Parameters em vez de Query String
        proxy_url = f'http://127.0.0.1:{port}/playlist/{b64_url}.m3u8'

        _log(f'play_stream: {url[:120]}')
        _log(f'proxy_url: {proxy_url[:150]}')

        li = xbmcgui.ListItem(path=proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)

        if self.addon_handle is not None:
            xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
        else:
            xbmc.Player().play(proxy_url, li)