#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tsproxy.py — NEXUS CORE MPEG-TS SUTURE ENGINE (SINGLE USER MODE)
# Autor: Deivid Silva
# Correção: Pool de conexão única por host + sessão persistente

import http.server
import socketserver
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue
import collections
import json
import ipaddress
import xbmc

# ─────────────────────────────────────────────
#  LOG SWITCH (True = ligado / False = desligado)
# ─────────────────────────────────────────────
_LOG_ENABLED = False

def set_log_enabled(enabled: bool):
    """Ativa (True) ou desativa (False) todo o log do tsproxy."""
    global _LOG_ENABLED
    _LOG_ENABLED = bool(enabled)

def _log(msg, level=xbmc.LOGDEBUG):
    if not _LOG_ENABLED:
        return
    try:
        xbmc.log(msg, level)
    except Exception:
        pass

# ─────────────────────────────────────────────
#  CONSTANTES MPEG-TS
# ─────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

def _build_null_burst(count: int = 24) -> bytes:
    burst = bytearray()
    for i in range(count):
        cc = i & 0x0F
        hdr = bytearray([0x47, 0x1F, 0xFF, 0x10 | cc])
        burst.extend(hdr)
        burst.extend(b'\xFF' * 184)
    return bytes(burst)

NULL_PUMP_BURST    = _build_null_burst(24)
NULL_PUMP_INTERVAL = 0.100
NULL_PUMP_MAX_SECS = 2.0

CHUNK_SIZE = TS_PACKET_SIZE * 348  # 65424 bytes

MAX_SYNC_ATTEMPTS_PER_CYCLE = 5000
MAX_OUTPUT_BUFFER   = 48
SYNC_CONFIRM_PACKETS = 50

SUTURE_MAX_ACCUM = 5 * 1024 * 1024

# ─────────────────────────────────────────────
#  CONNECTION POOL (UMA CONEXÃO POR HOST)
# ─────────────────────────────────────────────
class SingleHostConnectionPool:
    """
    Pool de conexão única por host.
    Mantém uma ÚNICA conexão HTTP aberta por host de origem.
    Reutiliza a mesma sessão para evitar múltiplos usuários.
    """
    def __init__(self):
        self._pools = {}  # hostname -> {'session': ..., 'lock': ..., 'last_used': ...}
        self._master_lock = threading.Lock()
        self._cleanup_interval = 60  # limpar conexões inativas
        self._last_cleanup = time.time()

    def _cleanup_inactive(self):
        """Remove conexões inativas por mais de 5 minutos"""
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return
        
        self._last_cleanup = now
        inactive_threshold = 300  # 5 minutos
        
        with self._master_lock:
            dead_hosts = []
            for hostname, pool_info in self._pools.items():
                if now - pool_info['last_used'] > inactive_threshold:
                    dead_hosts.append(hostname)
            
            for hostname in dead_hosts:
                pool_info = self._pools.pop(hostname, None)
                if pool_info:
                    try:
                        pool_info['session'].close()
                    except Exception:
                        pass
                    _log(f"[Pool] Conexão inativa para {hostname} removida", xbmc.LOGINFO)

    def get_session_for_host(self, hostname: str):
        """
        Obtém sessão ÚNICA para um hostname.
        Cria se não existir; reutiliza se existir.
        """
        self._cleanup_inactive()
        
        with self._master_lock:
            if hostname not in self._pools:
                # Criar nova sessão única para este host
                session = urllib.request.build_opener(
                    urllib.request.HTTPHandler(debuglevel=0),
                    urllib.request.HTTPSHandler(debuglevel=0),
                    NoRedirectHandler()
                )
                self._pools[hostname] = {
                    'session': session,
                    'lock': threading.Lock(),
                    'last_used': time.time()
                }
                _log(f"[Pool] Nova sessão criada para {hostname}", xbmc.LOGINFO)
            
            pool_info = self._pools[hostname]
            pool_info['last_used'] = time.time()
            return pool_info['session'], pool_info['lock']

    def invalidate_host(self, hostname: str):
        """Invalida a sessão para um hostname (ex: após erro 401/403)"""
        with self._master_lock:
            pool_info = self._pools.pop(hostname, None)
            if pool_info:
                try:
                    pool_info['session'].close()
                except Exception:
                    pass
                _log(f"[Pool] Sessão para {hostname} invalidada", xbmc.LOGWARNING)

    def close_all(self):
        """Fecha todas as conexões"""
        with self._master_lock:
            for hostname, pool_info in self._pools.items():
                try:
                    pool_info['session'].close()
                except Exception:
                    pass
            self._pools.clear()
            _log(f"[Pool] Todas as conexões fechadas", xbmc.LOGINFO)

_global_pool = SingleHostConnectionPool()

# ─────────────────────────────────────────────
#  DNS-over-HTTPS RESOLVER
# ─────────────────────────────────────────────
_DOH_PROVIDERS = [
    "https://dns.google/resolve",
    "https://dns.cloudflare.com/dns-query",
    "https://1.1.1.1/dns-query",
    "https://1.0.0.1/dns-query",
]
_DOH_CACHE = collections.OrderedDict()
_DOH_CACHE_MAX = 20
_DOH_CACHE_LOCK = threading.Lock()
_DOH_TIMEOUT = 3.0
_DOH_SYS_FALLBACK_TTL = 30

def _doh_is_ip_address(value: str) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

def _doh_resolve_system_dns(hostname: str, timeout: float = 1.5):
    result = [None]
    def _do_resolve():
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
            for _family, _, _, _, sockaddr in infos:
                ip = sockaddr[0]
                if ip:
                    result[0] = ip
                    break
        except Exception:
            pass
    t = threading.Thread(target=_do_resolve, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]

def _doh_resolve_provider(hostname: str, provider: str, timeout: float = _DOH_TIMEOUT):
    try:
        query = urllib.parse.urlencode({"name": hostname, "type": "A"})
        req = urllib.request.Request(
            f"{provider}?{query}",
            headers={"Accept": "application/dns-json", "User-Agent": "Mozilla/5.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8", "ignore"))
        if data.get("Status", -1) != 0:
            return None
        for answer in data.get("Answer", []):
            if answer.get("type") == 1:
                ip = str(answer.get("data", "")).strip()
                ttl = int(answer.get("TTL", 60))
                try:
                    ipaddress.IPv4Address(ip)
                    return ip, ttl
                except ValueError:
                    continue
    except Exception:
        pass
    return None

def resolve_host_doh(hostname: str):
    if not hostname or _doh_is_ip_address(hostname):
        return hostname
    now = time.time()
    with _DOH_CACHE_LOCK:
        entry = _DOH_CACHE.get(hostname)
        if entry:
            ip, expiry = entry
            if now < expiry:
                return ip
            del _DOH_CACHE[hostname]

    for provider in _DOH_PROVIDERS:
        result = _doh_resolve_provider(hostname, provider)
        if result:
            ip, ttl = result
            with _DOH_CACHE_LOCK:
                if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                    _DOH_CACHE.popitem(last=False)
                _DOH_CACHE[hostname] = (ip, now + 86400)
            return ip

    sys_ip = _doh_resolve_system_dns(hostname, timeout=1.5)
    if sys_ip:
        with _DOH_CACHE_LOCK:
            if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                _DOH_CACHE.popitem(last=False)
            _DOH_CACHE[hostname] = (sys_ip, now + _DOH_SYS_FALLBACK_TTL)
        return sys_ip
    return None

def rewrite_url_with_doh(url: str):
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host or _doh_is_ip_address(host):
        return url, ""
    ip = resolve_host_doh(host)
    if not ip:
        return url, ""
    port = parsed.port
    new_netloc = f"{ip}:{port}" if port else ip
    return urllib.parse.urlunparse(parsed._replace(netloc=new_netloc)), host

def invalidate_doh_cache(hostname: str):
    if hostname:
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.pop(hostname, None)

# ─────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)

# ─────────────────────────────────────────────
#  TsBuffer
# ─────────────────────────────────────────────
class TsBuffer:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = False
        self._pids_pending_discontinuity = set()

    def reset_stream_state(self):
        self._buf.clear()
        self._aligned = False
        self._cc_map.clear()
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = True
        self._pids_pending_discontinuity = set()

    def arm_discontinuity(self):
        self._armed_discontinuity = True

    def clear_partial_buffer(self):
        self._buf.clear()
        self._aligned = False

    def _confirm_sync(self, data, idx: int, length: int) -> bool:
        checkpoints_needed = SYNC_CONFIRM_PACKETS
        confirmed = 0
        for k in range(checkpoints_needed):
            pos = idx + k * TS_PACKET_SIZE
            if pos >= length:
                break
            if data[pos] != TS_SYNC_BYTE:
                return False
            confirmed += 1
        min_needed = min(checkpoints_needed, max(2, (length - idx) // TS_PACKET_SIZE))
        if confirmed < min_needed:
            return False
        return True

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                self._last_sync_idx = length
                return -1
            self._sync_attempts += 1
            if self._confirm_sync(data, idx, length):
                self._last_sync_idx = idx + TS_PACKET_SIZE
                return idx
            idx += 1
        self._last_sync_idx = idx
        return -1

    def _set_discontinuity_bit(self, packet: bytearray) -> bool:
        afc = (packet[3] & 0x30) >> 4
        if afc in (2, 3) and len(packet) >= 6 and packet[4] > 0:
            packet[5] |= 0x80
            return True
        return False

    def _process_packets(self, data: bytearray):
        n = len(data) // TS_PACKET_SIZE
        out = bytearray()
        mv = memoryview(data)
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            packet_view = mv[offset:offset + TS_PACKET_SIZE]
            if packet_view[0] != TS_SYNC_BYTE:
                self._error_count += 1
                self._aligned = False
                leftover = bytearray(mv[offset:])
                return out, leftover
            packet = bytearray(packet_view)
            pid = ((packet[1] & 0x1F) << 8) | packet[2]
            afc = (packet[3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            cc = packet[3] & 0x0F
            
            if pid == 0x1FFF:
                out.extend(packet)
                continue

            if self._armed_discontinuity:
                self._pids_pending_discontinuity.add(pid)

            if has_payload:
                self._cc_map[pid] = cc

            if pid in self._pids_pending_discontinuity:
                self._set_discontinuity_bit(packet)
                self._pids_pending_discontinuity.discard(pid)

            out.extend(packet)
            
        if self._armed_discontinuity and n > 0:
            self._armed_discontinuity = False
        return out, bytearray()

    def feed(self, raw: bytes) -> bytes:
        if not raw:
            return b''
        self._buf.extend(raw)
        result = bytearray()
        while True:
            if not self._aligned:
                self._sync_attempts = 0
                self._last_sync_idx = 0
                idx = self._find_sync(self._buf)
                if idx == -1:
                    if len(self._buf) > TS_PACKET_SIZE * 100:
                        keep_tail = TS_PACKET_SIZE * 2
                        del self._buf[:-keep_tail]
                    return bytes(result)
                if idx > 0:
                    del self._buf[:idx]
                self._aligned = True
            buf_len = len(self._buf)
            usable = buf_len - (buf_len % TS_PACKET_SIZE)
            if usable == 0:
                return bytes(result)
            payload = self._buf[:usable]
            del self._buf[:usable]
            processed, leftover = self._process_packets(payload)
            if processed:
                result.extend(processed)
            if leftover:
                self._buf[0:0] = leftover
                continue
            return bytes(result)

# ─────────────────────────────────────────────
#  SutureManager
# ─────────────────────────────────────────────
class SutureManager:
    def __init__(self):
        self._recent_hashes = collections.deque(maxlen=2000)

    @staticmethod
    def _get_packet_hash(pkt) -> int:
        if len(pkt) < 188:
            return None
        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if pid == 0x1FFF:
            return None
        afc = (pkt[3] & 0x30) >> 4
        if afc in (1, 3):
            payload_start = 4
            if afc == 3:
                if len(pkt) < 5:
                    return None
                adapt_len = pkt[4]
                payload_start = 5 + adapt_len
            if payload_start + 16 <= 188:
                return hash(bytes(pkt[payload_start:payload_start + 16]))
        return None

    def add_played(self, data: bytes):
        if not data:
            return
        mv = memoryview(data)
        n = len(data) // 188
        for i in range(n):
            offset = i * 188
            h = self._get_packet_hash(mv[offset:offset + 188])
            if h is not None:
                self._recent_hashes.append(h)

    def get_target(self) -> tuple:
        if len(self._recent_hashes) < 3:
            return None
        return (self._recent_hashes[-3], self._recent_hashes[-2], self._recent_hashes[-1])

    def clear(self):
        self._recent_hashes.clear()

# ─────────────────────────────────────────────
#  SutureSearchState
# ─────────────────────────────────────────────
class SutureSearchState:
    def __init__(self):
        self.accum = bytearray()
        self.hashes = []
        self.last_scanned = 0
        self._buf = bytearray()
        self._aligned = False
        self._packet_count = 0

    def feed(self, raw: bytes):
        self._buf.extend(raw)
        
        if not self._aligned:
            idx = self._buf.find(TS_SYNC_BYTE)
            if idx == -1:
                self._buf.clear()
                return
            if len(self._buf) < idx + TS_PACKET_SIZE * 2:
                return
            
            if self._buf[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE and \
               self._buf[idx + TS_PACKET_SIZE * 2] == TS_SYNC_BYTE:
                del self._buf[:idx]
                self._aligned = True
            else:
                del self._buf[:idx + 1]
                return
                
        usable = len(self._buf) - (len(self._buf) % TS_PACKET_SIZE)
        if usable == 0:
            return
            
        aligned_raw = bytes(self._buf[:usable])
        del self._buf[:usable]
        
        self.accum.extend(aligned_raw)
        n = usable // TS_PACKET_SIZE
        mv = memoryview(aligned_raw)
        
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            pkt = mv[offset:offset + TS_PACKET_SIZE]
            h = SutureManager._get_packet_hash(pkt)
            if h is not None:
                self.hashes.append((self._packet_count, h))
            self._packet_count += 1

    def find_suture(self, target: tuple) -> int:
        if not target or len(self.hashes) < 3:
            self.last_scanned = len(self.hashes)
            return -1
            
        start_idx = max(0, self.last_scanned - 2)
        
        for i in range(start_idx, len(self.hashes) - 2):
            if self.hashes[i][1] == target[0] and \
               self.hashes[i+1][1] == target[1] and \
               self.hashes[i+2][1] == target[2]:
                self.last_scanned = i + 3
                return self.hashes[i+2][0] + 1
        
        self.last_scanned = len(self.hashes)
        return -1

    def clear(self):
        self.accum = bytearray()
        self.hashes = []
        self.last_scanned = 0
        self._buf = bytearray()
        self._aligned = False
        self._packet_count = 0

# ─────────────────────────────────────────────
#  OutputBuffer
# ─────────────────────────────────────────────
class OutputBuffer:
    def __init__(self, max_packets: int = MAX_OUTPUT_BUFFER):
        self._queue = queue.Queue(maxsize=max_packets)
        self._lock = threading.Lock()
        self._align_residual = bytearray()

    def put(self, data: bytes) -> bool:
        if not data:
            return True
        with self._lock:
            self._align_residual.extend(data)
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                return True
            chunk = bytes(self._align_residual[:usable])
            del self._align_residual[:usable]
            try:
                self._queue.put_nowait(chunk)
                return True
            except queue.Full:
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._queue.put_nowait(chunk)
                except queue.Full:
                    pass
                return True

    def clear(self):
        with self._lock:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    break
            self._align_residual.clear()

    def flush_to_writer(self, writer_func) -> bool:
        while True:
            try:
                data = self._queue.get_nowait()
                if data:
                    remainder = len(data) % TS_PACKET_SIZE
                    if remainder:
                        data = data[:-remainder]
                    if data and not writer_func(data):
                        return False
            except queue.Empty:
                return True

    def drain_residual(self, writer_func) -> bool:
        with self._lock:
            if not self._align_residual:
                return True
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                self._align_residual.clear()
                return True
            chunk = bytes(self._align_residual[:usable])
            self._align_residual.clear()
        if chunk:
            return writer_func(chunk)
        return True

# ─────────────────────────────────────────────
#  REDIRECT HANDLER
# ─────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

# ─────────────────────────────────────────────
#  SERVIDOR HTTP PROXY
# ─────────────────────────────────────────────
class TSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        _log(f"[NexusCore-TSProxy] {format % args}", xbmc.LOGDEBUG)

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        remainder = len(data) % TS_PACKET_SIZE
        if remainder:
            data = data[:-remainder]
        if not data:
            return True
        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError, ConnectionAbortedError):
            return False

    def _null_pump(self, duration: float) -> bool:
        actual_duration = min(duration, NULL_PUMP_MAX_SECS)
        cycles = max(1, int(actual_duration / NULL_PUMP_INTERVAL))
        for _ in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            time.sleep(NULL_PUMP_INTERVAL)
        return True

    def _calculate_backoff(self, reconnect_num: int) -> float:
        if reconnect_num <= 2:
            return 0.3 + reconnect_num * 0.25
        elif reconnect_num <= 6:
            return 0.8 + (reconnect_num - 2) * 0.4
        return min(4.0, 2.4 + (reconnect_num - 6) * 0.2)

    def _resolve_url(self, url: str, ua: str, hostname: str, session_lock: threading.Lock) -> str:
        """
        Resolve URL com tratamento de redirects.
        Usa a sessão única do pool.
        """
        curr = url
        for _ in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                fetch_url, doh_host = rewrite_url_with_doh(curr)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                }
                if not doh_host:
                    fetch_url = curr
                req = urllib.request.Request(fetch_url, headers=headers)
                
                with session_lock:
                    session = _global_pool.get_session_for_host(hostname)[0]
                    try:
                        with session.open(req, timeout=8) as resp:
                            if resp.code in (301, 302, 303, 307, 308):
                                loc = resp.headers.get('Location')
                                if loc:
                                    curr = urllib.parse.urljoin(curr, loc)
                                    continue
                            return curr
                    except Exception:
                        if doh_host:
                            invalidate_doh_cache(doh_host)
                        raise
            except Exception:
                break
        return curr

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(400)
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        # Extrair hostname da URL original
        parsed_original = urllib.parse.urlparse(original_url)
        hostname = parsed_original.hostname or parsed_original.netloc
        
        # Obter sessão única para este hostname
        session, session_lock = _global_pool.get_session_for_host(hostname)
        
        resolved_url = original_url
        ua = _pick_ua()
        reconnect_num = 0
        ts_buf = TsBuffer()
        output_buf = OutputBuffer()
        last_useful_payload = time.time()

        suture_mgr = SutureManager()
        has_played_data = False
        is_suture_searching = False
        search_state = None

        _log(f"[NexusCore-TSProxy] Iniciando stream de {hostname}", xbmc.LOGINFO)

        while True:
            output_buf.clear()
            last_useful_payload = time.time()

            try:
                parsed = urllib.parse.urlparse(resolved_url)
                fetch_url, doh_host = rewrite_url_with_doh(resolved_url)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Referer': original_url,
                    'Connection': 'keep-alive',
                }
                if not doh_host:
                    fetch_url = resolved_url
                req = urllib.request.Request(fetch_url, headers=headers)

                with session_lock:
                    # Usar a MESMA sessão do pool
                    with session.open(req, timeout=12) as response:
                        if reconnect_num == 0:
                            _log(f"[NexusCore-TSProxy] ✓ Conectado (sessão única) -> {ua[:40]}...", xbmc.LOGINFO)
                        else:
                            _log(f"[NexusCore-TSProxy] ✓ Reconectado #{reconnect_num} (sessão reutilizada)", xbmc.LOGINFO)
                            reconnect_num = max(0, reconnect_num - 2)

                        if has_played_data and not is_suture_searching:
                            is_suture_searching = True
                            search_state = SutureSearchState()
                            _log("[NexusCore-TSProxy] ⊙ Buscando sutura...", xbmc.LOGINFO)

                        while True:
                            try:
                                raw = response.read(CHUNK_SIZE)
                            except Exception:
                                break

                            if not raw:
                                break

                            if is_suture_searching:
                                search_state.feed(raw)
                                target = suture_mgr.get_target()
                                suture_idx = search_state.find_suture(target)

                                if suture_idx != -1:
                                    skip = suture_idx * TS_PACKET_SIZE
                                    _log(f"[NexusCore-TSProxy] ✓ Sutura encontrada! Pulando {skip} bytes.", xbmc.LOGINFO)
                                    remaining = bytes(search_state.accum[skip:])
                                    search_state = None
                                    is_suture_searching = False
                                    
                                    ts_buf.clear_partial_buffer()
                                    ts_buf.arm_discontinuity()
                                    payload = ts_buf.feed(remaining)
                                    if payload:
                                        output_buf.put(payload)
                                        if not output_buf.flush_to_writer(self._safe_write):
                                            return
                                        suture_mgr.add_played(payload)
                                else:
                                    if len(search_state.accum) > SUTURE_MAX_ACCUM:
                                        _log("[NexusCore-TSProxy] ⚠ Sutura nao encontrada. Retomando do live edge.", xbmc.LOGWARNING)
                                        all_raw = bytes(search_state.accum)
                                        search_state = None
                                        is_suture_searching = False
                                        
                                        ts_buf.clear_partial_buffer()
                                        ts_buf.arm_discontinuity()
                                        payload = ts_buf.feed(all_raw)
                                        if payload:
                                            output_buf.put(payload)
                                            if not output_buf.flush_to_writer(self._safe_write):
                                                return
                                            suture_mgr.add_played(payload)
                            else:
                                payload = ts_buf.feed(raw)
                                if payload:
                                    last_useful_payload = time.time()
                                    output_buf.put(payload)
                                    if not output_buf.flush_to_writer(self._safe_write):
                                        return
                                    suture_mgr.add_played(payload)
                                    has_played_data = True
                                else:
                                    last_useful_payload = time.time()

            except urllib.error.HTTPError as e:
                if e.code in (401, 403):
                    _global_pool.invalidate_host(hostname)
                    _log(f"[NexusCore-TSProxy] ✗ Auth error {e.code} - invalidando sessão", xbmc.LOGWARNING)
                elif e.code == 429:
                    _log(f"[NexusCore-TSProxy] ✗ Rate limit {e.code} #{reconnect_num} - aguardando...", xbmc.LOGWARNING)
                else:
                    _log(f"[NexusCore-TSProxy] ✗ HTTP {e.code} #{reconnect_num}", xbmc.LOGWARNING)
            except Exception as e:
                err_name = type(e).__name__
                err_msg = str(e)[:80]
                _log(f"[NexusCore-TSProxy] ✗ {err_name} #{reconnect_num}: {err_msg}", xbmc.LOGWARNING)
                _doh_host_failed = locals().get('doh_host')
                if _doh_host_failed:
                    invalidate_doh_cache(_doh_host_failed)

            if is_suture_searching:
                _log("[NexusCore-TSProxy] ⚠ Conexao caiu durante busca. Reiniciando busca.", xbmc.LOGWARNING)
                is_suture_searching = False
                search_state = None

            if not output_buf.flush_to_writer(self._safe_write):
                return
            if not output_buf.drain_residual(self._safe_write):
                return

            reconnect_num += 1
            ua = _pick_ua()
            backoff = self._calculate_backoff(reconnect_num)

            if not self._null_pump(backoff):
                return

            try:
                new_url = self._resolve_url(original_url, ua, hostname, session_lock)
                if new_url != resolved_url:
                    resolved_url = new_url
                    _log(f"[NexusCore-TSProxy] ↻ Token atualizado #{reconnect_num}", xbmc.LOGINFO)
            except Exception:
                pass

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

_server_instance = None
_server_thread = None
_lock = threading.Lock()

def _ensure_server_running():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance is None:
            port = 0
            _server_instance = ThreadingHTTPServer(('127.0.0.1', port), TSProxyHandler)
            _server_thread = threading.Thread(target=_server_instance.serve_forever, daemon=True)
            _server_thread.start()
            actual_port = _server_instance.server_address[1]
            _log(f"[NexusCore-TSProxy] ✓ Servidor iniciado na porta {actual_port}", xbmc.LOGINFO)
            return actual_port
        return _server_instance.server_address[1]

def get_proxy_url(stream_url: str, port: int = None) -> str:
    """
    Gera a URL do proxy para um stream IPTV.
    
    Uso:
        proxy_url = get_proxy_url('http://seu-servidor.com/stream.m3u8')
        # Retorna: http://127.0.0.1:PORTA?url=...
    """
    if port is None:
        port = _ensure_server_running()
    encoded_url = urllib.parse.quote(stream_url, safe='')
    return f"http://127.0.0.1:{port}/?url={encoded_url}"

def shutdown_proxy():
    """Encerra o proxy e fecha todas as conexões"""
    global _server_instance, _server_thread
    with _lock:
        if _server_instance:
            _server_instance.shutdown()
            _server_instance = None
            _server_thread = None
    _global_pool.close_all()
    _log("[NexusCore-TSProxy] ✓ Proxy encerrado", xbmc.LOGINFO)