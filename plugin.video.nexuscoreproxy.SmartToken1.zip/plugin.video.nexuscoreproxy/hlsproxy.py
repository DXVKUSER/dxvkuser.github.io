#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — NEXUS CORE HLS Proxy Engine
v1.7.0 — Smart Token Renewal & Anti-Token-Exhaustion

Correções:
  • Smart Token Renewal: Em 403/404/410, descarta URL resolvida e volta à
    "URL Porta de Entrada" para gerar nova sessão limpa
  • CookieJar por sessão (não global) — sem contaminação cross-session
  • Rotação de User-Agent ofuscado em todas as reconexões
  • StreamSession: mapeia segmentos → entry URL para recuperação
  • Limpeza de DNS cache na renovação (força novo edge server)
  • Anti-False 200 OK (detecção de HTML e manifestos vazios)
  • Zero Erros ao Kodi Player (HTTP 200 OK garantido)
"""

import sys
import os
import re
import socket
import ssl
import json
import time
import random
import threading
import urllib.request
import urllib.error
import urllib.parse
import http.client
import http.server
import http.cookiejar
import socketserver
from urllib.parse import urlparse, urljoin, quote, unquote

# ════════════════════════════════════════════════════════════
# LOGGING
# ════════════════════════════════════════════════════════════

def _log(msg, level='info'):
    try:
        import xbmc
        levels = {
            'info':    xbmc.LOGINFO,
            'error':   xbmc.LOGERROR,
            'warning': xbmc.LOGWARNING,
        }
        xbmc.log(f'[NexusCore-HLS] {msg}', levels.get(level, xbmc.LOGINFO))
    except ImportError:
        print(f'[NexusCore-HLS] [{level}] {msg}')

# ════════════════════════════════════════════════════════════
# DoH RESOLVER (DNS-over-HTTPS)
# ════════════════════════════════════════════════════════════

_RE_IPV4 = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
_RE_IPV6 = re.compile(r'^[0-9a-fA-F:]+$')

_DNS_CACHE      = {}
_DNS_CACHE_LOCK = threading.Lock()
_DNS_CACHE_TTL  = 300

_in_doh_resolution = threading.local()

DOH_SERVERS = [
    'https://dns.google/resolve',
    'https://cloudflare-dns.com/dns-query',
]

_orig_getaddrinfo = socket.getaddrinfo


def _is_ip(host):
    if not host:
        return False
    host = host.strip('[]')
    if _RE_IPV4.match(host):
        try:
            parts = host.split('.')
            return all(0 <= int(p) <= 255 for p in parts)
        except Exception:
            return False
    if ':' in host and _RE_IPV6.match(host):
        return True
    return False


def _doh_resolve(hostname, timeout=5):
    if _is_ip(hostname):
        return hostname

    now = time.time()
    with _DNS_CACHE_LOCK:
        cached = _DNS_CACHE.get(hostname)
        if cached and now - cached[1] < _DNS_CACHE_TTL:
            return cached[0]

    for doh_url in DOH_SERVERS:
        try:
            req_url = f'{doh_url}?name={quote(hostname)}&type=A'
            req = urllib.request.Request(req_url, headers={
                'Accept': 'application/dns-json',
                'User-Agent': 'NEXUS-CORE-DoH/1.0',
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if 'Answer' in data:
                    for ans in data['Answer']:
                        if ans.get('type') == 1:
                            ip = ans.get('data')
                            if ip and _is_ip(ip):
                                with _DNS_CACHE_LOCK:
                                    _DNS_CACHE[hostname] = (ip, now)
                                _log(f'DoH: {hostname} → {ip}')
                                return ip
        except Exception as e:
            _log(f'DoH falhou ({doh_url}): {e}', 'warning')
            continue

    try:
        results = _orig_getaddrinfo(hostname, None)
        if results:
            ip = results[0][4][0]
            with _DNS_CACHE_LOCK:
                _DNS_CACHE[hostname] = (ip, now)
            _log(f'DNS local: {hostname} → {ip}')
            return ip
    except Exception:
        pass

    _log(f'Não foi possível resolver: {hostname}', 'error')
    return hostname


def _clear_dns_cache(hostname=None):
    """Limpa cache DNS para forçar nova resolução (Smart Token Renewal)."""
    with _DNS_CACHE_LOCK:
        if hostname:
            if hostname in _DNS_CACHE:
                del _DNS_CACHE[hostname]
                _log(f'DNS cache limpo para: {hostname}')
        else:
            _DNS_CACHE.clear()
            _log('DNS cache totalmente limpo')


def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if getattr(_in_doh_resolution, 'active', False):
        return _orig_getaddrinfo(host, port, family, type, proto, flags)

    if host and not _is_ip(host):
        try:
            _in_doh_resolution.active = True
            ip = _doh_resolve(host)
            if ip and _is_ip(ip):
                host = ip
        except Exception:
            pass
        finally:
            _in_doh_resolution.active = False

    return _orig_getaddrinfo(host, port, family, type, proto, flags)


socket.getaddrinfo = _patched_getaddrinfo
_log('DoH resolver ativado (socket.getaddrinfo patcheado com anti-recursão)')

# ════════════════════════════════════════════════════════════
# SSL CONTEXT
# ════════════════════════════════════════════════════════════

_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode    = ssl.CERT_NONE

# ════════════════════════════════════════════════════════════
# OBFUSCATED USER-AGENT POOL (Rotação em todas as reconexões)
# ════════════════════════════════════════════════════════════

_UA_POOL = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 OPR/118.0.0.0',
    'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:115.0) Gecko/20100101 Firefox/115.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
]


def _get_random_ua():
    """Retorna um User-Agent ofuscado aleatório do pool."""
    return random.choice(_UA_POOL)

# ════════════════════════════════════════════════════════════
# GLOBAL STATE
# ════════════════════════════════════════════════════════════

_PROXY_PORT   = None
_PROXY_SERVER = None
_PROXY_LOCK   = threading.Lock()

# ════════════════════════════════════════════════════════════
# MANUAL REDIRECT HANDLER (Preserva Tokens na URL Final)
# ════════════════════════════════════════════════════════════

class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

    def http_error_301(self, req, fp, code, msg, headers): return fp
    def http_error_302(self, req, fp, code, msg, headers): return fp
    def http_error_307(self, req, fp, code, msg, headers): return fp
    def http_error_308(self, req, fp, code, msg, headers): return fp


def _build_opener(cookie_jar=None):
    """Constrói um opener isolado com cookie jar próprio (sem global)."""
    if cookie_jar is None:
        cookie_jar = http.cookiejar.CookieJar()

    opener = urllib.request.OpenerDirector()
    opener.add_handler(urllib.request.HTTPSHandler(context=_ssl_ctx))
    opener.add_handler(urllib.request.HTTPHandler())
    opener.add_handler(NoRedirectHandler())
    opener.add_handler(urllib.request.HTTPCookieProcessor(cookie_jar))
    return opener


def _open_no_redirect(url, timeout=15, extra_headers=None, user_agent=None, opener=None):
    """Abre URL sem seguir redirects automaticamente. Usa opener fornecido ou cria efêmero."""
    if opener is None:
        opener = _build_opener()

    parsed = urlparse(url)
    ua = user_agent or _get_random_ua()

    headers = {
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Host': parsed.netloc,
        'User-Agent': ua,
    }

    if extra_headers:
        for k, v in extra_headers.items():
            if k.lower() not in ['host', 'connection', 'accept-encoding', 'user-agent']:
                headers[k] = v

    if parsed.scheme == 'https':
        headers['Origin']  = f'{parsed.scheme}://{parsed.netloc}'
        headers['Referer'] = f'{parsed.scheme}://{parsed.netloc}/'
    else:
        headers['Origin']  = f'http://{parsed.netloc}'
        headers['Referer'] = f'http://{parsed.netloc}/'

    req = urllib.request.Request(url, headers=headers)
    return opener.open(req, timeout=timeout)

# ════════════════════════════════════════════════════════════
# TOKEN EXPIRED EXCEPTION (Smart Token Renewal Trigger)
# ════════════════════════════════════════════════════════════

class TokenExpiredError(Exception):
    """Erro 403/404/410 recebido — Token expirado, requires session renewal."""
    def __init__(self, status, url):
        self.status = status
        self.url = url
        super().__init__(f'HTTP {status}: Token expirado em {url[:80]}')

# ════════════════════════════════════════════════════════════
# ANTI-FALSE 200 OK VALIDATION
# ════════════════════════════════════════════════════════════

def _is_valid_manifest(data_bytes):
    """Verifica se os dados são um manifesto M3U8 válido (não HTML ou vazio)."""
    if not data_bytes or len(data_bytes.strip()) == 0:
        return False

    sample = data_bytes[:1024].decode('utf-8', errors='ignore').strip()

    if sample.lower().startswith('<!doctype html') or '<html' in sample.lower() or '<head' in sample.lower():
        return False

    if '#EXTM3U' in sample or '#EXTINF' in sample or '#EXT-X-STREAM-INF' in sample:
        return True

    return False

# ════════════════════════════════════════════════════════════
# STREAM SESSION MANAGER (Smart Token Renewal Core)
# ════════════════════════════════════════════════════════════

class StreamSession:
    """
    Mantém uma sessão de stream para uma Entry URL.

    - CookieJar próprio (sem contaminação cross-session)
    - Mapeia segmentos por sequence number para recuperação
    - Em 403/404/410: limpa cookies, rotaciona UA, limpa DNS, re-fetch
    """

    def __init__(self, entry_url, session_id):
        self.entry_url          = entry_url
        self.session_id         = session_id
        self.lock               = threading.Lock()
        self.last_refresh       = 0
        self.segments           = {}   # seq_number -> full_url
        self.final_playlist_url = None
        self.user_agent         = _get_random_ua()
        self.cookie_jar         = http.cookiejar.CookieJar()
        self.refresh_count      = 0
        self.recovery_count     = 0

    def _extract_seq(self, url):
        """Extrai o número de sequência de uma URL de segmento."""
        # Padrão: channel_seq.ts (ex: 36966_350.ts)
        m = re.search(r'_(\d+)\.(?:ts|m4s|aac|mp4)', url, re.IGNORECASE)
        if m:
            return m.group(1)
        # Fallback: número antes de .ts
        m = re.search(r'/(\d+)\.ts', url, re.IGNORECASE)
        if m:
            return m.group(1)
        return None

    def _build_opener(self):
        """Constrói opener com cookie jar da sessão."""
        return _build_opener(self.cookie_jar)

    def _purge_session_state(self):
        """Limpa TODOS os estado de sessão para forçar nova sessão limpa."""
        # Limpa cookies (session contamination fix)
        self.cookie_jar = http.cookiejar.CookieJar()
        # Rotaciona User-Agent
        self.user_agent = _get_random_ua()
        # Limpa DNS cache para entry URL e URL final
        try:
            parsed_entry = urlparse(self.entry_url)
            if parsed_entry.hostname:
                _clear_dns_cache(parsed_entry.hostname)
        except Exception:
            pass
        if self.final_playlist_url:
            try:
                parsed_final = urlparse(self.final_playlist_url)
                if parsed_final.hostname:
                    _clear_dns_cache(parsed_final.hostname)
            except Exception:
                pass
        _log(f'[Session {self.session_id}] Estado purgado: cookies limpos, UA rotacionado, DNS limpo')

    def _refresh_internal(self, force=False):
        """Lógica interna de refresh. Deve ser chamada com lock."""
        now = time.time()
        if not force and self.last_refresh and now - self.last_refresh < 1.5:
            return True

        # Em force, purgar estado para sessão completamente limpa
        if force:
            self._purge_session_state()

        try:
            opener = self._build_opener()
            raw, final_url = _fetch_with_redirects_internal(
                self.entry_url,
                timeout=10,
                extra_headers=None,
                max_retries=2,
                is_playlist=True,
                user_agent=self.user_agent,
                opener=opener,
            )
            self.final_playlist_url = final_url
            content = raw.decode('utf-8', errors='replace')

            # Parse e cacheia URLs de segmentos
            new_segments = {}
            lines = content.split('\n')
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#'):
                    absolute = urljoin(final_url, line)
                    seq = self._extract_seq(absolute)
                    if seq:
                        new_segments[seq] = absolute

            if new_segments:
                self.segments = new_segments
                self.last_refresh = time.time()
                self.refresh_count += 1
                _log(f'[Session {self.session_id}] Sessão renovada: {len(new_segments)} segmentos mapeados. '
                     f'UA: ...{self.user_agent[-30:]} | Refresh #{self.refresh_count}')
                return True
            else:
                _log(f'[Session {self.session_id}] Renovação não retornou segmentos', 'warning')
                return False

        except Exception as e:
            _log(f'[Session {self.session_id}] Falha ao renovar sessão: {e}', 'warning')
            return False

    def refresh(self, force=False):
        """Renova a playlist para obter tokens frescos."""
        with self.lock:
            return self._refresh_internal(force=force)

    def recover_segment(self, failed_url):
        """
        Smart Token Renewal: chamado quando segmento falha com 403/404/410.

        1. Purga estado da sessão (cookies, DNS, UA)
        2. Re-fetch playlist da Entry URL
        3. Mapeia segmento falhado por sequence number
        4. Retorna nova URL ou None
        """
        seq = self._extract_seq(failed_url)
        _log(f'[Session {self.session_id}] 🔑 Smart Token Renewal: seq={seq} | URL falhada: {failed_url[:100]}')

        with self.lock:
            self._refresh_internal(force=True)
            self.recovery_count += 1

            if seq and seq in self.segments:
                new_url = self.segments[seq]
                _log(f'[Session {self.session_id}] ✅ Recuperação bem-sucedida: seq={seq} → nova URL obtida')
                return new_url

        _log(f'[Session {self.session_id}] ❌ Recuperação falhou: seq={seq} não encontrado na nova playlist', 'warning')
        return None


# Registry de sessões
_SESSIONS          = {}   # session_id -> StreamSession
_SESSIONS_BY_ENTRY = {}   # entry_url -> session_id
_SESSIONS_LOCK     = threading.Lock()


def _get_or_create_session(entry_url):
    """Obtém sessão existente ou cria nova para uma Entry URL."""
    with _SESSIONS_LOCK:
        sid = _SESSIONS_BY_ENTRY.get(entry_url)
        if sid and sid in _SESSIONS:
            return _SESSIONS[sid], sid

        sid = f'sess_{int(time.time() * 1000)}_{random.randint(1000, 9999)}'
        session = StreamSession(entry_url, sid)
        _SESSIONS[sid] = session
        _SESSIONS_BY_ENTRY[entry_url] = sid

        # Cleanup: mantém no máximo 15 sessões
        if len(_SESSIONS) > 15:
            oldest = sorted(_SESSIONS.items(), key=lambda x: x[1].last_refresh)[:5]
            for old_sid, _ in oldest:
                if old_sid in _SESSIONS:
                    old_entry = _SESSIONS[old_sid].entry_url
                    del _SESSIONS[old_sid]
                    if old_entry in _SESSIONS_BY_ENTRY:
                        del _SESSIONS_BY_ENTRY[old_entry]

        _log(f'[Session {sid}] Nova sessão criada para: {entry_url[:80]}')
        return session, sid


def _get_session(sid):
    """Obtém sessão por ID."""
    if not sid:
        return None
    with _SESSIONS_LOCK:
        return _SESSIONS.get(sid)

# ════════════════════════════════════════════════════════════
# FETCH WITH REDIRECTS (Core com Smart Token Renewal)
# ════════════════════════════════════════════════════════════

def _fetch_with_redirects_internal(url, timeout=10, extra_headers=None, max_retries=3,
                                    is_playlist=False, user_agent=None, opener=None):
    """
    Fetch com redirects manuais, retries e validação anti-falso-200.
    Rotaciona UA em cada tentativa.
    Em 403/404/410: levanta TokenExpiredError para trigger de renovação.
    """
    if opener is None:
        opener = _build_opener()

    last_exception = None

    for attempt in range(1, max_retries + 1):
        current_ua = user_agent if (attempt == 1 and user_agent) else _get_random_ua()
        try:
            current_url = url
            max_redirects = 10

            for _ in range(max_redirects):
                resp = _open_no_redirect(current_url, timeout, extra_headers,
                                         user_agent=current_ua, opener=opener)
                status = resp.status if hasattr(resp, 'status') else resp.code

                if status in (301, 302, 307, 308):
                    location = resp.headers.get('Location')
                    resp.close()
                    if location:
                        current_url = urljoin(current_url, location)
                        _log(f'Redirect manual: → {current_url[:120]}')
                        continue
                    else:
                        raise Exception("Redirect sem Location header")

                elif status in (403, 404, 410):
                    resp.close()
                    # Token expirado — fail fast para Smart Token Renewal
                    raise TokenExpiredError(status, current_url)

                elif status >= 400:
                    resp.close()
                    raise urllib.error.HTTPError(current_url, status, "Upstream Error",
                                                 resp.headers, None)
                else:
                    data = resp.read()
                    resp.close()

                    if is_playlist and not _is_valid_manifest(data):
                        _log(f'Falso 200 OK (Tentativa {attempt}/{max_retries}): {current_url[:100]}', 'warning')
                        raise ValueError("Manifesto inválido ou HTML retornado com 200 OK")

                    return data, current_url

        except TokenExpiredError:
            raise  # Propaga imediatamente para renovação de sessão

        except Exception as e:
            last_exception = e
            _log(f'Tentativa {attempt}/{max_retries} falhou para {url[:80]}: {e}', 'warning')
            if attempt < max_retries:
                time.sleep(0.4 * attempt)
            else:
                raise e

    raise last_exception or Exception("Falha desconhecida em _fetch_with_redirects_internal")


def _fetch_with_redirects(url, timeout=10, extra_headers=None, max_retries=3, is_playlist=False):
    """Fetch stateless (sem sessão). Para keys e outros recursos."""
    opener = _build_opener()
    return _fetch_with_redirects_internal(url, timeout, extra_headers, max_retries,
                                           is_playlist, opener=opener)


def _stream_with_redirects(url, timeout=15, extra_headers=None, max_retries=1,
                            user_agent=None, opener=None):
    """
    Abre stream para segmentos. Fail-fast em 403/404/410 para Smart Token Renewal.
    Não faz retries extensivos — delega recovery ao chamador.
    """
    if opener is None:
        opener = _build_opener()

    current_ua = user_agent or _get_random_ua()

    for attempt in range(1, max_retries + 1):
        try:
            current_url = url
            max_redirects = 10

            if attempt > 1:
                current_ua = _get_random_ua()

            for _ in range(max_redirects):
                resp = _open_no_redirect(current_url, timeout, extra_headers,
                                         user_agent=current_ua, opener=opener)
                status = resp.status if hasattr(resp, 'status') else resp.code

                if status in (301, 302, 307, 308):
                    location = resp.headers.get('Location')
                    resp.close()
                    if location:
                        current_url = urljoin(current_url, location)
                        _log(f'Redirect stream: → {current_url[:120]}')
                        continue
                    else:
                        raise Exception("Redirect sem Location header")

                elif status in (403, 404, 410):
                    resp.close()
                    raise TokenExpiredError(status, current_url)

                elif status >= 400:
                    resp.close()
                    raise urllib.error.HTTPError(current_url, status, "Upstream Error",
                                                 resp.headers, None)
                else:
                    return resp

        except TokenExpiredError:
            raise  # Propaga para Smart Token Renewal

        except Exception as e:
            _log(f'Stream tentativa {attempt}/{max_retries} falhou: {e}', 'warning')
            if attempt < max_retries:
                time.sleep(0.3 * attempt)
            else:
                raise e

    raise Exception("Falha ao inicializar stream do segmento")


# ════════════════════════════════════════════════════════════
# HLS PROXY HTTP HANDLER
# ════════════════════════════════════════════════════════════

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):

    protocol_version = 'HTTP/1.1'

    def do_GET(self):
        parsed = urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        path   = parsed.path.rstrip('/')

        if path in ('/playlist', '/master.m3u8', '/playlist.m3u8', '/m3u8'):
            self._handle_playlist(params)
        elif path in ('/seg', '/segment'):
            self._handle_segment(params)
        elif path == '/key':
            self._handle_key(params)
        elif path == '/favicon.ico':
            self._send_fallback_200(b'', 'image/x-icon')
        else:
            if 'url' in params:
                self._handle_playlist(params)
            else:
                self._send_fallback_playlist()

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin',  '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.end_headers()

    def _get_kodi_headers(self):
        kodi_h = {}
        if 'Range' in self.headers:
            kodi_h['Range'] = self.headers['Range']
        return kodi_h

    def _send_fallback_200(self, body=b'', content_type='application/octet-stream'):
        """Envia HTTP 200 OK garantido para evitar erros no player."""
        try:
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if body:
                self.wfile.write(body)
        except Exception as e:
            _log(f'Erro ao enviar resposta fallback: {e}', 'warning')

    def _send_fallback_playlist(self):
        """Playlist M3U8 viva em loop para manter o Kodi aguardando."""
        dummy_m3u8 = (
            "#EXTM3U\n"
            "#EXT-X-VERSION:3\n"
            "#EXT-X-TARGETDURATION:2\n"
            "#EXT-X-MEDIA-SEQUENCE:0\n"
            "#EXTINF:2.0,\n"
            f"http://127.0.0.1:{_PROXY_PORT}/seg?url=retry\n"
        ).encode('utf-8')
        self._send_fallback_200(dummy_m3u8, 'application/vnd.apple.mpegurl')

    # ─── PLAYLIST HANDLER ───────────────────────────────────

    def _handle_playlist(self, params):
        url = params.get('url', [None])[0]
        if not url:
            self._send_fallback_playlist()
            return

        # Obtém ou cria sessão para esta Entry URL
        session, sid = _get_or_create_session(url)

        max_playlist_attempts = 3

        for attempt in range(1, max_playlist_attempts + 1):
            try:
                # Em tentativas > 1, força purge completo (Smart Token Renewal)
                if attempt > 1:
                    _log(f'[Playlist] Tentativa {attempt}/{max_playlist_attempts}: purgando sessão para nova sessão limpa')
                    with session.lock:
                        session._purge_session_state()

                # Fetch playlist usando opener da sessão
                opener = session._build_opener()
                raw, final_url = _fetch_with_redirects_internal(
                    url,
                    timeout=10,
                    extra_headers=self._get_kodi_headers(),
                    max_retries=2,
                    is_playlist=True,
                    user_agent=session.user_agent,
                    opener=opener,
                )

                content = raw.decode('utf-8', errors='replace')
                session.final_playlist_url = final_url
                session.last_refresh = time.time()

                # Cacheia segmentos da playlist
                lines = content.split('\n')
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        absolute = urljoin(final_url, line)
                        seq = session._extract_seq(absolute)
                        if seq:
                            session.segments[seq] = absolute

                # Rewrite com session ID embutido
                rewritten = self._rewrite_playlist(content, final_url, sid)
                body = rewritten.encode('utf-8')

                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Cache-Control', 'no-cache, no-store')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(body)
                return

            except TokenExpiredError as e:
                _log(f'[Playlist] Token expirado (tentativa {attempt}/{max_playlist_attempts}): {e}', 'warning')
                if attempt < max_playlist_attempts:
                    # Próxima iteração fará purge completo
                    continue
                else:
                    _log('[Playlist] Todas as tentativas de renovação falharam. Enviando fallback.', 'warning')
                    self._send_fallback_playlist()
                    return

            except Exception as e:
                _log(f'[Playlist] Erro (tentativa {attempt}/{max_playlist_attempts}): {e}', 'warning')
                if attempt < max_playlist_attempts:
                    # Força purge na próxima tentativa
                    with session.lock:
                        session._purge_session_state()
                    time.sleep(0.5 * attempt)
                    continue
                else:
                    _log(f'Playlist com erro silenciado (Recuperação Proativa): {e}', 'warning')
                    self._send_fallback_playlist()
                    return

    def _rewrite_playlist(self, content, base_url, session_id):
        """Reescreve o manifesto preservando tokens e embutindo session ID."""
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        lines   = content.split('\n')
        result  = []
        prev_tag = None

        for line in lines:
            stripped = line.strip()

            if not stripped:
                result.append('')
                continue

            if stripped.startswith('#'):
                if '#EXT-X-STREAM-INF' in stripped:
                    prev_tag = 'stream'
                elif '#EXTINF' in stripped:
                    prev_tag = 'segment'

                if 'URI="' in stripped:
                    stripped = self._rewrite_uri_in_tag(stripped, base_url, session_id)

                result.append(stripped)
                continue

            absolute = urljoin(base_url, stripped)
            quoted   = quote(absolute, safe='')

            # Embute session ID para Smart Token Renewal nos segmentos
            if prev_tag == 'stream':
                proxy_url = f'http://127.0.0.1:{_PROXY_PORT}/playlist?url={quoted}&sid={session_id}'
            else:
                proxy_url = f'http://127.0.0.1:{_PROXY_PORT}/seg?url={quoted}&sid={session_id}'

            result.append(proxy_url)

        return '\n'.join(result)

    def _rewrite_uri_in_tag(self, line, base_url, session_id):
        def replace_uri(match):
            original = match.group(1)
            if original.startswith('data:'):
                return f'URI="{original}"'

            absolute = urljoin(base_url, original)
            quoted   = quote(absolute, safe='')
            sid_param = f'&sid={session_id}'

            if '#EXT-X-KEY' in line or '#EXT-X-SESSION-KEY' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/key?url={quoted}{sid_param}"'
            elif '#EXT-X-MAP' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg?url={quoted}{sid_param}"'
            elif '#EXT-X-MEDIA' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/playlist?url={quoted}{sid_param}"'
            else:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg?url={quoted}{sid_param}"'

        return re.sub(r'URI="([^"]+)"', replace_uri, line)

    # ─── SEGMENT HANDLER (com Smart Token Renewal) ──────────

    def _handle_segment(self, params):
        url = params.get('url', [None])[0]
        sid = params.get('sid', [None])[0]

        if not url or url == 'retry':
            self._send_fallback_200(b'\x47' + (b'\x00' * 187), 'video/mp2t')
            return

        # Obtém sessão para Smart Token Renewal
        session = _get_session(sid)

        resp = None
        max_recovery = 3

        for recovery_attempt in range(1, max_recovery + 1):
            current_url = url
            # Rotaciona UA em TODAS as tentativas
            current_ua = _get_random_ua()

            try:
                opener = session._build_opener() if session else _build_opener()

                resp = _stream_with_redirects(
                    current_url,
                    timeout=15,
                    extra_headers=self._get_kodi_headers(),
                    user_agent=current_ua,
                    opener=opener,
                    max_retries=1,  # Fail-fast para Token Renewal
                )
                # Sucesso — proceed to stream
                break

            except TokenExpiredError as e:
                _log(f'[Segment] 🔑 Token expirado (recuperação {recovery_attempt}/{max_recovery}): {e}', 'warning')

                if session and recovery_attempt < max_recovery:
                    # Smart Token Renewal: descarta URL, volta à Entry URL
                    new_url = session.recover_segment(current_url)
                    if new_url and new_url != current_url:
                        _log(f'[Segment] ✅ Nova URL obtida: {new_url[:120]}')
                        url = new_url  # Usa nova URL na próxima iteração
                        continue
                    else:
                        _log(f'[Segment] ❌ Não foi possível renovar URL do segmento', 'warning')
                        break
                else:
                    _log(f'[Segment] ❌ Máximo de recuperações atingido', 'warning')
                    break

            except Exception as e:
                _log(f'[Segment] Falha (recuperação {recovery_attempt}/{max_recovery}): {e}', 'warning')

                if recovery_attempt < max_recovery:
                    # Tenta recovery via sessão
                    if session:
                        new_url = session.recover_segment(current_url)
                        if new_url and new_url != current_url:
                            url = new_url
                            continue
                    time.sleep(0.3 * recovery_attempt)
                else:
                    break

        if resp is None:
            # Todas as tentativas falharam — envia frame TS neutro
            _log(f'[Segment] Todas as recuperações falharam. Enviando frame neutro.', 'warning')
            self._send_fallback_200(b'\x47' + (b'\x00' * 187), 'video/mp2t')
            return

        # Stream do segmento para o Kodi
        try:
            self.send_response(200)
            content_type = resp.headers.get('Content-Type', 'video/mp2t')
            self.send_header('Content-Type', content_type)
            self.send_header('Access-Control-Allow-Origin', '*')

            content_range = resp.headers.get('Content-Range')
            if content_range:
                self.send_header('Content-Range', content_range)

            content_length = resp.headers.get('Content-Length')
            if content_length:
                self.send_header('Content-Length', content_length)
            else:
                self.send_header('Connection', 'close')
                self.close_connection = True

            self.end_headers()

            try:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:
                _log(f'Interrupção no streaming de segmento: {e}', 'warning')
            finally:
                resp.close()

        except Exception as e:
            _log(f'Erro ao entregar segmento ao Kodi: {e}', 'error')
            if resp:
                try:
                    resp.close()
                except Exception:
                    pass

    # ─── KEY HANDLER ────────────────────────────────────────

    def _handle_key(self, params):
        url = params.get('url', [None])[0]
        if not url:
            self._send_fallback_200(b'\x00' * 16, 'application/octet-stream')
            return

        try:
            data, _ = _fetch_with_redirects(url, extra_headers=self._get_kodi_headers())

            key_hex = data[:16].hex() if len(data) >= 16 else data.hex()
            _log(f'AES-128 Key extraída: {len(data)} bytes hex={key_hex[:32]}... ← {url[:80]}')

            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(data)

        except Exception as e:
            _log(f'Erro na captura da chave AES (Retornando chave neutra): {e}', 'error')
            self._send_fallback_200(b'\x00' * 16, 'application/octet-stream')

    def log_message(self, format, *args):
        pass


# ════════════════════════════════════════════════════════════
# THREADED HTTP SERVER
# ════════════════════════════════════════════════════════════

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads      = True
    allow_reuse_address = True


# ════════════════════════════════════════════════════════════
# SERVER MANAGEMENT
# ════════════════════════════════════════════════════════════

def _ensure_server_running():
    global _PROXY_PORT, _PROXY_SERVER
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None and _PROXY_PORT is not None:
            return _PROXY_PORT

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', 0))
        _PROXY_PORT = sock.getsockname()[1]
        sock.close()

        _PROXY_SERVER = ThreadingHTTPServer(('127.0.0.1', _PROXY_PORT), HLSProxyHandler)

        thread = threading.Thread(target=_PROXY_SERVER.serve_forever, daemon=True)
        thread.start()

        _log(f'HLS Proxy server iniciado na porta {_PROXY_PORT}')
        return _PROXY_PORT


def _stop_server():
    global _PROXY_SERVER, _PROXY_PORT
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None:
            _PROXY_SERVER.shutdown()
            _PROXY_SERVER.server_close()
            _PROXY_SERVER = None
            _PROXY_PORT   = None
            _log('HLS Proxy server parado')


# ════════════════════════════════════════════════════════════
# KODI ADDON INTERFACE
# ════════════════════════════════════════════════════════════

class HLSAddon:
    def __init__(self, addon_handle=None):
        self.addon_handle = addon_handle

    def play_stream(self, url):
        import xbmc
        import xbmcplugin
        import xbmcgui

        port = _ensure_server_running()
        proxy_url = f'http://127.0.0.1:{port}/playlist?url={quote(url, safe="")}'

        _log(f'play_stream: {url[:120]}')
        _log(f'proxy_url: {proxy_url[:150]}')

        li = xbmcgui.ListItem(path=proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)

        if self.addon_handle is not None:
            xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
        else:
            xbmc.Player().play(proxy_url, li)