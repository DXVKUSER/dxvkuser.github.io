#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import threading
import logging
import urllib.parse
import warnings
import requests
import socket
import re
import sys
import random
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

# Configurações de Estabilidade para Android/Adreno
PROXY_HOST = "127.0.0.1"
TIMEOUT_CONNECT = 20
TIMEOUT_READ = 45 

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="[HLS-PROXY] %(message)s")

try:
    import xbmcgui
    import xbmcplugin
    KODI = True
except ImportError:
    KODI = False

# Sessão com pool persistente
session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=25, pool_maxsize=25)
session.mount('http://', adapter)
session.mount('https://', adapter)

user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 10; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0",
]

class HLSProxyHandler(BaseHTTPRequestHandler):
    # HTTP/1.0 para forçar entrega contínua
    protocol_version = 'HTTP/1.0'

    def log_message(self, format, *args): return 

    def get_base_headers(self, url, ua=None, xff=None):
        p = urllib.parse.urlparse(url)
        headers = {
            "User-Agent": ua or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
            "Accept": "*/*",
            "Connection": "close",
            "Host": p.netloc,
            "Origin": f"{p.scheme}://{p.netloc}",
            "Referer": f"{p.scheme}://{p.netloc}/",
        }
        if xff:
            headers["X-Forwarded-For"] = xff
        return headers

    def get_headers(self, url):
        return self.get_base_headers(url)

    def get_rotated_headers(self, url):
        ua = random.choice(user_agents)
        xff = ".".join(str(random.randint(1, 254)) for _ in range(4))
        return self.get_base_headers(url, ua=ua, xff=xff)

    def fetch_redirects(self, url, stream=False, custom_headers=None):
        """
        Gerencia requisições com redirecionamento manual.
        """
        curr_url = url
        for _ in range(5):
            if custom_headers:
                headers = custom_headers.copy()
                p = urllib.parse.urlparse(curr_url)
                headers["Host"] = p.netloc
                headers["Origin"] = f"{p.scheme}://{p.netloc}"
                headers["Referer"] = f"{p.scheme}://{p.netloc}/"
            else:
                headers = self.get_headers(curr_url)
            
            try:
                r = session.get(curr_url, headers=headers, 
                                timeout=(TIMEOUT_CONNECT, TIMEOUT_READ), 
                                verify=False, allow_redirects=False, stream=stream)
                
                if r.status_code in (301, 302, 307, 308):
                    location = r.headers.get('Location')
                    if location:
                        curr_url = urllib.parse.urljoin(curr_url, location)
                        continue
                    else:
                        return None
                
                return r
            except Exception as e:
                return None
        return None

    def do_GET(self):
        try:
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            target_url = query.get("url", [None])[0]
            if not target_url: return
            
            target_url = urllib.parse.unquote_plus(target_url)

            if ".m3u" in target_url.lower():
                self.handle_m3u8(target_url)
            else:
                self.handle_stream(target_url)
        except:
            pass 

    def handle_m3u8(self, url):
        """
        CORREÇÃO CRÍTICA: Removido o cache do manifesto.
        Para TV ao vivo, o manifesto muda constantemente. 
        Usar cache faz o player pedir segmentos expirados, causando travamento após minutos.
        """
        r = self.fetch_redirects(url, stream=False)

        if not r or r.status_code != 200 or "#EXTM3U" not in r.text:
            self.send_error(404)
            return

        if r.encoding is None:
            r.encoding = 'utf-8'
            
        base_url = r.url.rsplit("/", 1)[0] + "/"
        lines = r.text.splitlines()
        output = []
        for line in lines:
            line = line.strip()
            if not line: continue
            if line.startswith("#"):
                if "#EXT-X-KEY" in line:
                    line = self.proxy_key_url(line, base_url)
                output.append(line)
            else:
                abs_url = urllib.parse.urljoin(base_url, line)
                output.append(self.make_proxy_url(abs_url))

        if not output:
            self.send_error(502)
            return

        content = "\n".join(output).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.send_header("Content-Length", len(content))
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate") # Força navegador/player a não cachear localmente
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write(content)

    def handle_stream(self, url):
        r = self.fetch_redirects(url, stream=True)
        if not r or r.status_code != 200:
            self.send_error(503)
            return

        self.send_response(200)
        
        content_type = r.headers.get('Content-Type', 'video/mp2t')
        self.send_header('Content-Type', content_type)
        
        self.end_headers()
        try:
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    self.wfile.write(chunk)
        except:
            pass
        finally:
            r.close()

    def proxy_key_url(self, line, base_url):
        match = re.search(r'URI=["\'](.*?)["\']', line)
        if match:
            original_uri = match.group(1)
            abs_key_url = urllib.parse.urljoin(base_url, original_uri)
            return line.replace(original_uri, self.make_proxy_url(abs_key_url))
        return line

    def make_proxy_url(self, url):
        return f"http://{PROXY_HOST}:{self.server.server_port}/?url={urllib.parse.quote_plus(url)}"

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Removemos resolved_cache e lock pois não usamos mais cache de manifesto

class HLSAddon:
    def __init__(self, handle=None):
        self.handle = int(handle) if handle and str(handle).isdigit() else 0
        self.port = self.find_free_port()
        self.server = ThreadedHTTPServer((PROXY_HOST, self.port), HLSProxyHandler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def find_free_port(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('', 0))
        port = s.getsockname()[1]
        s.close()
        return port

    def play_stream(self, stream_url, stream_type=None):
        proxy_url = f"http://{PROXY_HOST}:{self.port}/?url={urllib.parse.quote_plus(stream_url)}"
        if KODI:
            list_item = xbmcgui.ListItem(path=proxy_url)
            list_item.setProperty("IsPlayable", "true")
            # Força o Kodi a usar o Inputstream FFmpeg
            list_item.setInfo('video', {'Title': 'Reproduzindo...'})
            xbmcplugin.setResolvedUrl(self.handle, True, list_item)