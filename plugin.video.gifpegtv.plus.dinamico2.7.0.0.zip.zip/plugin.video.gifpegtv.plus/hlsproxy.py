# -*- coding: utf-8 -*-
"""
HLS proxy with dynamic stability/adaptation features.
This version prefers the requests implementation from the
script.module.netunblock (doh_client.requests) when available,
and falls back to the system 'requests' module otherwise.

Behavior:
- If doh_client.requests exists, use it and expose .exceptions from the real requests module (if present)
  to maintain compatibility with code that catches requests.exceptions.RequestException.
- When using doh_client.requests (which provides classmethods), create a small session-wrapper that exposes
  get/post/head/... and headers to the rest of the proxy.
- If the real requests module is available, use HTTPAdapter pooling.
- Robust to environments where requests or adapters are missing (Kodi add-on ecosystems).
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import json
import re
import socket
import types
from collections import defaultdict, deque

# ---------------- REQUESTS IMPORT (prefer doh_client.requests) ----------------
# Try to import doh_client (script.module.netunblock) first
_requests_impl = None
_HTTPAdapter = None
_RequestException = Exception  # fallback

try:
    # doh_client defines a class `requests` with classmethods and an underlying session.
    from doh_client import requests as doh_requests  # type: ignore
    try:
        # try to also import the real requests module to reuse its exceptions and adapters
        import requests as real_requests  # type: ignore
    except Exception:
        real_requests = None

    # ensure doh_requests has exceptions namespace for compatibility
    if real_requests is not None and not hasattr(doh_requests, 'exceptions'):
        try:
            doh_requests.exceptions = real_requests.exceptions
        except Exception:
            # best effort; if this fails, we'll leave doh_requests without exceptions
            pass

    # build a session-wrapper that exposes the common interface used in the proxy:
    # - get/post/put/delete/head methods
    # - headers dict (for User-Agent access)
    # - close and mount methods (no-op if not supported)
    def _session_from_doh(doh):
        sess = types.SimpleNamespace()
        # prefer calling the classmethods directly; doh_requests.get is callable
        sess.get = getattr(doh, 'get', lambda *a, **k: (_ for _ in ()).throw(Exception("doh client get not available")))
        sess.post = getattr(doh, 'post', lambda *a, **k: (_ for _ in ()).throw(Exception("doh client post not available")))
        sess.put = getattr(doh, 'put', lambda *a, **k: (_ for _ in ()).throw(Exception("doh client put not available")))
        sess.delete = getattr(doh, 'delete', lambda *a, **k: (_ for _ in ()).throw(Exception("doh client delete not available")))
        sess.head = getattr(doh, 'head', lambda *a, **k: (_ for _ in ()).throw(Exception("doh client head not available")))
        sess.headers = {'User-Agent': getattr(doh, 'agent', "Mozilla/5.0")}
        sess.close = lambda: None
        sess.mount = lambda *a, **k: None
        return sess

    _requests_impl = doh_requests
    _HTTPAdapter = getattr(real_requests.adapters, 'HTTPAdapter', None) if real_requests is not None else None
    _RequestException = getattr(doh_requests, 'exceptions', None).RequestException if (hasattr(doh_requests, 'exceptions') and getattr(doh_requests, 'exceptions') is not None) else (getattr(real_requests, 'exceptions', None).RequestException if real_requests is not None and hasattr(real_requests, 'exceptions') else Exception)
    _use_doh = True
except Exception:
    # doh_client not available: fall back to standard requests
    try:
        import requests as real_requests  # type: ignore
        _requests_impl = real_requests
        try:
            from requests.adapters import HTTPAdapter  # type: ignore
            _HTTPAdapter = HTTPAdapter
        except Exception:
            _HTTPAdapter = None
        _RequestException = getattr(real_requests, 'exceptions', Exception).RequestException if hasattr(real_requests, 'exceptions') else Exception
        _use_doh = False
    except Exception:
        # worst-case: nothing available, create a minimal shim to avoid attribute errors
        class _DummyRequests:
            def get(self, *a, **k):
                raise RuntimeError("No HTTP client available")
        _requests_impl = _DummyRequests()
        _HTTPAdapter = None
        _RequestException = Exception
        _use_doh = False

# Expose requests name used in the rest of the code
requests = _requests_impl
HTTPAdapter = _HTTPAdapter
RequestException = _RequestException

# If we are using doh_client.requests, create an http_session wrapper from it.
def _create_wrapper_or_real_session(version):
    """
    If requests has Session attribute, create a real Session and mount adapters.
    Else if requests is doh_client.requests-style class, build a session wrapper.
    """
    try:
        # Standard requests.Session available
        if hasattr(requests, 'Session') and callable(getattr(requests, 'Session')):
            s = requests.Session()
            s.headers.update({'User-Agent': f"Mozilla/5.0 HLSProxy/{version}"})
            if HTTPAdapter is not None:
                try:
                    adapter = HTTPAdapter(pool_connections=100, pool_maxsize=200, max_retries=0)
                    s.mount('http://', adapter)
                    s.mount('https://', adapter)
                except Exception:
                    pass
            return s
        # doh_client.requests style (class with classmethods)
        # Build wrapper that calls the doh_client methods
        if hasattr(requests, 'get') and not hasattr(requests, 'Session'):
            # requests is likely doh_client.requests class
            return _session_from_doh(requests)
    except Exception:
        pass
    # final fallback: minimal shim that raises on network operations
    return types.SimpleNamespace(get=lambda *a, **k: (_ for _ in ()).throw(RequestException("No HTTP session available")),
                                 post=lambda *a, **k: (_ for _ in ()).throw(RequestException("No HTTP session available")),
                                 headers={'User-Agent': f"Mozilla/5.0 HLSProxy/{version}"},
                                 close=lambda: None,
                                 mount=lambda *a, **k: None)

# ---------------- Kodi shims (for non-Kodi testing) ----------------
try:
    from kodi_six import xbmc, xbmcgui, xbmcplugin  # type: ignore
except Exception:
    xbmc = types.SimpleNamespace(translatePath=lambda p: os.getcwd(), LOGNOTICE=None)
    xbmcgui = types.SimpleNamespace(ListItem=lambda *a, **k: types.SimpleNamespace(setProperty=lambda *a, **k: None, setInfo=lambda *a, **k: None, setMimeType=lambda *a, **k: None))
    xbmcplugin = types.SimpleNamespace(setResolvedUrl=lambda *a, **k: None, endOfDirectory=lambda *a, **k: None)

# ---------------- CONFIG & CONSTANTS ----------------
RETRY_BACKOFF_FACTOR_BASE = 0.05
DEFAULT_CONNECTION_TIMEOUT = 10
DEFAULT_STREAM_TIMEOUT = 20.0
DEFAULT_CHUNK_SIZE = 1024 * 128
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
USER_AGENT_BASE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
LOG_FILE = "hls_proxy_persistent.log"
LOG_LEVEL = logging.INFO
DEFAULT_TARGET_DURATION = 10
DEFAULT_MAX_SEGMENT_RETRIES = 1

MIN_CHUNK_SIZE = 64 * 1024
MAX_CHUNK_SIZE = 1024 * 1024
MIN_MANIFEST_CACHE = 0.5
MAX_MANIFEST_CACHE = 60
DEFAULT_PREFETCH_COUNT = 2
ORIGIN_MAX_CONCURRENCY = 6
GLOBAL_MAX_CONCURRENCY = 40
CIRCUIT_BREAKER_FAILURE_THRESHOLD = 5
CIRCUIT_BREAKER_WINDOW = 60
CIRCUIT_BREAKER_COOLDOWN = 30
EWMA_ALPHA = 0.2

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- LOGGING ----------------
def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=LOG_LEVEL,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[logging.FileHandler(log_path, mode='a', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=LOG_LEVEL, format='%(asctime)s - %(levelname)s - %(message)s')

def clamp(lo, v, hi):
    return max(lo, min(v, hi))

def _obfuscate_url(url):
    if not isinstance(url, str):
        return "URL inválida"
    try:
        parsed = urllib.parse.urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}/..."
    except Exception:
        return "URL malformada"

# ---------------- ORIGIN / CIRCUIT / STATS ----------------
class CircuitState:
    CLOSED = 'closed'
    OPEN = 'open'
    HALF_OPEN = 'half_open'

class OriginStats:
    def __init__(self):
        self.lock = threading.Lock()
        self.ewma_bps = None
        self.ewma_latency = None
        self.success_count = 0
        self.failure_count = 0
        self.errors = deque()
        self.circuit_state = CircuitState.CLOSED
        self.circuit_open_until = 0.0
        self.semaphore = threading.Semaphore(ORIGIN_MAX_CONCURRENCY)
        self.prefetch_cache = {}
        self.etag = None
        self.last_modified = None
        self.playlist_type = None
        self.low_latency = False

    def record_sample(self, bytes_received, elapsed):
        with self.lock:
            sample_bps = (bytes_received / max(elapsed, 0.0001))
            sample_latency = elapsed
            if self.ewma_bps is None:
                self.ewma_bps = sample_bps
            else:
                self.ewma_bps = EWMA_ALPHA * sample_bps + (1 - EWMA_ALPHA) * self.ewma_bps
            if self.ewma_latency is None:
                self.ewma_latency = sample_latency
            else:
                self.ewma_latency = EWMA_ALPHA * sample_latency + (1 - EWMA_ALPHA) * self.ewma_latency

    def record_success(self):
        with self.lock:
            self.success_count += 1

    def record_failure(self):
        now = time.time()
        with self.lock:
            self.failure_count += 1
            self.errors.append(now)
            while self.errors and now - self.errors[0] > CIRCUIT_BREAKER_WINDOW:
                self.errors.popleft()
            if len(self.errors) >= CIRCUIT_BREAKER_FAILURE_THRESHOLD:
                self.open_circuit()

    def open_circuit(self):
        now = time.time()
        self.circuit_state = CircuitState.OPEN
        self.circuit_open_until = now + CIRCUIT_BREAKER_COOLDOWN
        logging.warning(f"Circuit opened for origin, cooldown until {self.circuit_open_until}")

    def may_request(self):
        now = time.time()
        with self.lock:
            if self.circuit_state == CircuitState.OPEN:
                if now >= self.circuit_open_until:
                    self.circuit_state = CircuitState.HALF_OPEN
                    logging.info("Circuit transitioning to HALF_OPEN for origin")
                    return True
                return False
            return True

    def record_half_open_result(self, success):
        with self.lock:
            if success:
                self.circuit_state = CircuitState.CLOSED
                self.errors.clear()
                logging.info("Circuit CLOSED after successful half-open probe")
            else:
                self.open_circuit()

# ---------------- HELPERS ----------------
def extract_target_duration(manifest_content):
    if not manifest_content:
        return DEFAULT_TARGET_DURATION
    match = re.search(r'#EXT-X-TARGETDURATION:(\d+)', manifest_content)
    if match:
        try:
            return int(match.group(1))
        except Exception:
            return DEFAULT_TARGET_DURATION
    logging.warning("Tag #EXT-X-TARGETDURATION não encontrada. Usando fallback.")
    return DEFAULT_TARGET_DURATION

def calculate_num_segments(manifest_content):
    if not manifest_content:
        return 0
    segments = [line for line in manifest_content.splitlines() if line.strip() and not line.startswith('#')]
    return len(segments)

def detect_playlist_type(manifest_content):
    if not manifest_content:
        return None
    m = re.search(r'#EXT-X-PLAYLIST-TYPE:(\w+)', manifest_content)
    if m:
        return m.group(1).upper()
    return None

def detect_low_latency(manifest_content):
    if not manifest_content:
        return False
    return '#EXT-X-PART' in manifest_content or '#EXT-X-SERVER-CONTROL' in manifest_content

def manifest_cache_age_for(target_duration, playlist_type=None, low_latency=False):
    if playlist_type == 'VOD':
        return clamp(MIN_MANIFEST_CACHE, max(30, target_duration * 2), MAX_MANIFEST_CACHE)
    if low_latency:
        return clamp(MIN_MANIFEST_CACHE, target_duration * 0.25, max(1, target_duration))
    return clamp(MIN_MANIFEST_CACHE, target_duration * 0.5, max(1, target_duration * 1.5))

# ---------------- SESSION CREATION ----------------
def _create_new_session(version):
    """
    Create a session. If using standard requests.Session, create one with adapters.
    If using doh_client.requests, return a wrapper that delegates to doh_client classmethods.
    """
    return _create_wrapper_or_real_session(version)

# ---------------- HANDLER & SERVER ----------------
class _TCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        self.request_queue_size = 200
        super().__init__(server_address, RequestHandlerClass, bind_and_activate)

class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    current_version = 90
    max_version = 200
    http_session = _create_new_session(current_version)
    manifest_cache = {}
    origin_stats = defaultdict(OriginStats)
    global_semaphore = threading.Semaphore(GLOBAL_MAX_CONCURRENCY)
    cache_lock = threading.Lock()
    metrics_lock = threading.Lock()
    metrics = {
        'manifests_served': 0,
        'segments_served': 0,
        'manifest_fetch_errors': 0,
        'segment_fetch_errors': 0,
    }

    @classmethod
    def get_current_user_agent(cls):
        try:
            if cls.http_session and hasattr(cls.http_session, 'headers'):
                return cls.http_session.headers.get('User-Agent', USER_AGENT_BASE + "90.0.0.0 Safari/537.36")
        except Exception:
            pass
        return USER_AGENT_BASE + "90.0.0.0 Safari/537.36"

    @classmethod
    def rotate_user_agent_and_refresh_session(cls):
        with cls.cache_lock:
            cls.current_version += 1
            if cls.current_version > cls.max_version:
                cls.current_version = 90
            try:
                if cls.http_session and hasattr(cls.http_session, 'close'):
                    cls.http_session.close()
            except Exception:
                pass
            cls.http_session = _create_new_session(cls.current_version)
            cls.manifest_cache.clear()
        logging.warning(f"Sessão HTTP e User-Agent rotacionados para versão: {cls.current_version}")

    def log_message(self, format, *args):
        return

    def get_forward_headers(self):
        headers = {
            'User-Agent': self.get_current_user_agent(),
            'Connection': 'keep-alive',
        }
        for h in ['Authorization', 'Cookie', 'Range', 'Referer']:
            if h in self.headers:
                headers[h] = self.headers[h]
        return headers

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        url = None
        try:
            if self.path.startswith('/metrics'):
                return self._handle_metrics()

            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            encoded_headers = params.get('headers', [None])[0]

            if not url:
                self.send_error(400)
                return

            headers = self.get_forward_headers()

            if encoded_headers:
                try:
                    decoded_headers = urllib.parse.unquote_plus(encoded_headers)
                    custom_headers = json.loads(decoded_headers)
                    if isinstance(custom_headers, dict):
                        headers.update(custom_headers)
                except Exception as e:
                    logging.error(f"Erro ao decodificar headers personalizados: {e}")

            parsed_url = urllib.parse.urlparse(url)
            origin = f"{parsed_url.scheme}://{parsed_url.netloc}"
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, origin, headers, head_only)
            else:
                self._handle_segment(url, origin, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado GET ({_obfuscate_url(url)}): {e}")
            self.rotate_user_agent_and_refresh_session()
            try:
                self.send_error(500)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

    def _handle_metrics(self):
        with self.metrics_lock:
            out = json.dumps(self.metrics)
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.end_headers()
        try:
            self.wfile.write(out.encode('utf-8'))
        except Exception:
            pass

    def _get_cached_manifest(self, url):
        with self.cache_lock:
            if url in self.manifest_cache:
                (content, final_url, timestamp, conn_timeout, stream_timeout, num_segments,
                 etag, last_modified, playlist_type, low_latency, cache_age) = self.manifest_cache[url]
                if time.time() - timestamp < cache_age:
                    logging.info(f"Usando manifesto em cache para {_obfuscate_url(url)} (age {time.time() - timestamp:.1f}s < {cache_age}s)")
                    return content, final_url, conn_timeout, stream_timeout, num_segments, etag, last_modified, playlist_type, low_latency, cache_age
            return (None,) * 10

    def _set_cached_manifest(self, url, content, final_url, conn_timeout, stream_timeout, num_segments,
                             etag, last_modified, playlist_type, low_latency):
        cache_age = manifest_cache_age_for(conn_timeout / 1.5 if conn_timeout else DEFAULT_TARGET_DURATION,
                                           playlist_type,
                                           low_latency)
        with self.cache_lock:
            self.manifest_cache[url] = (content, final_url, time.time(), conn_timeout, stream_timeout, num_segments,
                                       etag, last_modified, playlist_type, low_latency, cache_age)
            logging.info(f"Manifesto armazenado em cache para {_obfuscate_url(url)} (cache_age={cache_age}s, num_segments={num_segments})")

    def _handle_manifest(self, url, origin, headers, head_only):
        try:
            manifest_content = None
            base_url = url
            conn_timeout = DEFAULT_CONNECTION_TIMEOUT
            stream_timeout = DEFAULT_STREAM_TIMEOUT
            num_segments = 0
            etag = None
            last_modified = None
            playlist_type = None
            low_latency = False

            cached = self._get_cached_manifest(url)
            (cached_content, cached_final_url, cached_conn, cached_stream, cached_num_segments,
             cached_etag, cached_last_modified, cached_playlist_type, cached_low_latency, cached_cache_age) = cached

            origin_stat = self.origin_stats[origin]

            if cached_content and not head_only:
                manifest_content = cached_content
                base_url = cached_final_url
                conn_timeout = cached_conn
                stream_timeout = cached_stream
                num_segments = cached_num_segments
                etag = cached_etag
                last_modified = cached_last_modified
                playlist_type = cached_playlist_type
                low_latency = cached_low_latency
                logging.info(f"Manifesto obtido do cache local para {_obfuscate_url(url)}")
            else:
                if not origin_stat.may_request():
                    logging.warning(f"Origin {origin} blocked by circuit breaker.")
                    self.send_error(503)
                    return

                acquired_global = self.global_semaphore.acquire(timeout=5)
                if not acquired_global:
                    logging.warning("Global concurrency limit reached.")
                    self.send_error(503)
                    return
                acquired_origin = origin_stat.semaphore.acquire(timeout=5)
                if not acquired_origin:
                    self.global_semaphore.release()
                    logging.warning("Origin concurrency limit reached.")
                    self.send_error(503)
                    return

                try:
                    logging.info(f"Baixando manifesto de {_obfuscate_url(url)}")
                    max_retries = DEFAULT_MAX_SEGMENT_RETRIES
                    backoff_factor = RETRY_BACKOFF_FACTOR_BASE
                    if etag:
                        headers['If-None-Match'] = etag
                    if last_modified:
                        headers['If-Modified-Since'] = last_modified

                    r = None
                    for attempt in range(max_retries + 1):
                        try:
                            t0 = time.time()
                            if not hasattr(self.http_session, 'get'):
                                raise RequestException("HTTP session not available")
                            r = self.http_session.get(url, headers=headers, timeout=DEFAULT_CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                            latency = time.time() - t0
                            if getattr(r, 'status_code', None) == 304 and cached_content:
                                logging.info("Manifest 304 Not Modified - usando cache")
                                manifest_content = cached_content
                                base_url = cached_final_url
                                conn_timeout = cached_conn
                                stream_timeout = cached_stream
                                num_segments = cached_num_segments
                                etag = cached_etag
                                last_modified = cached_last_modified
                                origin_stat.record_success()
                                break
                            if hasattr(r, 'raise_for_status'):
                                r.raise_for_status()
                            content_len = len(getattr(r, 'content', b'') or b'')
                            origin_stat.record_sample(content_len, latency)
                            origin_stat.record_success()
                            break
                        except Exception as e:
                            origin_stat.record_failure()
                            if attempt == max_retries:
                                raise
                            jitter = random.uniform(0, 0.1 * backoff_factor)
                            sleep_for = clamp(0.05, backoff_factor * (2 ** attempt) + jitter, 5)
                            logging.warning(f"Retry {attempt+1}/{max_retries} for manifest: {e}; sleeping {sleep_for:.2f}s")
                            time.sleep(sleep_for)

                    if r is None:
                        raise RuntimeError("Falha desconhecida ao obter manifesto")

                    manifest_content = getattr(r, 'text', None) or (getattr(r, 'content', b'').decode('utf-8', errors='ignore') if getattr(r, 'content', None) else None)
                    base_url = getattr(r, 'url', base_url)
                    etag = getattr(r, 'headers', {}).get('ETag') if getattr(r, 'headers', None) else None
                    last_modified = getattr(r, 'headers', {}).get('Last-Modified') if getattr(r, 'headers', None) else None

                    target_duration = extract_target_duration(manifest_content)
                    conn_timeout = target_duration * 1.5
                    stream_timeout = target_duration * 2.5
                    num_segments = calculate_num_segments(manifest_content)
                    playlist_type = detect_playlist_type(manifest_content)
                    low_latency = detect_low_latency(manifest_content)

                    backoff_factor = RETRY_BACKOFF_FACTOR_BASE * (1 + num_segments / 100)

                    if not head_only:
                        self._set_cached_manifest(url, manifest_content, base_url, conn_timeout, stream_timeout, num_segments,
                                                  etag, last_modified, playlist_type, low_latency)

                    with origin_stat.lock:
                        if etag:
                            origin_stat.etag = etag
                        if last_modified:
                            origin_stat.last_modified = last_modified
                        origin_stat.playlist_type = playlist_type
                        origin_stat.low_latency = low_latency

                finally:
                    try:
                        origin_stat.semaphore.release()
                    except Exception:
                        pass
                    try:
                        self.global_semaphore.release()
                    except Exception:
                        pass

            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            if '#EXT-X-VERSION:3' not in (manifest_content or ''):
                self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            if head_only:
                return

            proxy_base_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/"
            encoded_headers_param = ""
            if 'headers' in urllib.parse.parse_qs(self.path.split('?', 1)[1]):
                encoded_headers_param = f"&headers={urllib.parse.parse_qs(self.path.split('?', 1)[1])['headers'][0]}"

            new_manifest_lines = []
            segment_urls = []
            for line in (manifest_content or "").splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith('#'):
                    new_manifest_lines.append(line)
                else:
                    full_segment_url = urllib.parse.urljoin(base_url, stripped)
                    segment_urls.append(full_segment_url)
                    proxy_segment_url = f"{proxy_base_url}?url={urllib.parse.quote_plus(full_segment_url)}{encoded_headers_param}"
                    new_manifest_lines.append(proxy_segment_url)

            try:
                self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante envio do manifesto.")
                return

            with self.metrics_lock:
                self.metrics['manifests_served'] += 1

            prefetch_count = DEFAULT_PREFETCH_COUNT
            threading.Thread(target=self._background_prefetch, args=(origin, segment_urls[:prefetch_count], headers), daemon=True).start()

            logging.info("Manifesto enviado com sucesso. Sessão HTTP mantida.")
        except Exception as e:
            logging.error(f"Erro ao manipular manifesto ({_obfuscate_url(url)}): {e}")
            with self.metrics_lock:
                self.metrics['manifest_fetch_errors'] += 1
            self.rotate_user_agent_and_refresh_session()
            try:
                self.send_error(502)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

    def _background_prefetch(self, origin, segment_urls, headers):
        origin_stat = self.origin_stats[origin]
        for seg in segment_urls:
            with origin_stat.lock:
                entry = origin_stat.prefetch_cache.get(seg)
                if entry and time.time() - entry[1] < 30:
                    continue
            if not origin_stat.may_request():
                continue
            acquired = origin_stat.semaphore.acquire(timeout=1)
            if not acquired:
                continue
            try:
                if not hasattr(self.http_session, 'get'):
                    continue
                r = self.http_session.get(seg, headers=headers, stream=True, timeout=DEFAULT_STREAM_TIMEOUT, verify=False)
                if hasattr(r, 'raise_for_status'):
                    r.raise_for_status()
                data = getattr(r, 'content', None) or b''
                with origin_stat.lock:
                    origin_stat.prefetch_cache[seg] = (data, time.time())
                logging.info(f"Prefetched segment {_obfuscate_url(seg)} ({len(data)} bytes)")
            except Exception:
                logging.debug(f"Prefetch failed for {_obfuscate_url(seg)}")
            finally:
                try:
                    origin_stat.semaphore.release()
                except Exception:
                    pass

    def _handle_segment(self, url, origin, headers, head_only):
        origin_stat = self.origin_stats[origin]
        try:
            parsed_url = urllib.parse.urlparse(url)
            manifest_key = None
            with self.cache_lock:
                for cached_url in list(self.manifest_cache.keys()):
                    try:
                        if parsed_url.path.startswith(urllib.parse.urlparse(cached_url).path):
                            manifest_key = cached_url
                            break
                    except Exception:
                        continue

            conn_timeout = DEFAULT_CONNECTION_TIMEOUT
            stream_timeout = DEFAULT_STREAM_TIMEOUT
            num_segments = 0
            if manifest_key:
                with self.cache_lock:
                    (_, _, _, conn_timeout, stream_timeout, num_segments,
                     _, _, _, _, _) = self.manifest_cache.get(manifest_key, (None,) * 11)

            if not origin_stat.may_request():
                logging.warning(f"Origin {origin} blocked by circuit breaker for segments.")
                self.send_error(503)
                return

            acquired_global = self.global_semaphore.acquire(timeout=5)
            if not acquired_global:
                logging.warning("Global concurrency limit reached for segment.")
                self.send_error(503)
                return
            acquired_origin = origin_stat.semaphore.acquire(timeout=5)
            if not acquired_origin:
                self.global_semaphore.release()
                logging.warning("Origin concurrency limit reached for segment.")
                self.send_error(503)
                return

            with origin_stat.lock:
                pref = origin_stat.prefetch_cache.pop(url, None)
            if pref and not head_only:
                data, ts = pref
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                self.send_header('Pragma', 'no-cache')
                self.send_header('Expires', '0')
                self.end_headers()
                try:
                    self.wfile.write(data)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    logging.warning("Cliente fechou conexão durante segmento prefetched.")
                    return
                with self.metrics_lock:
                    self.metrics['segments_served'] += 1
                origin_stat.record_success()
                return

            max_retries = max(DEFAULT_MAX_SEGMENT_RETRIES, 1 + num_segments // 20)
            backoff_factor = RETRY_BACKOFF_FACTOR_BASE * (1 + num_segments / 50)

            chunk_size = DEFAULT_CHUNK_SIZE
            with origin_stat.lock:
                if origin_stat.ewma_bps:
                    est_segment_dur = max(1.0, conn_timeout if conn_timeout else DEFAULT_TARGET_DURATION)
                    desired_chunks = 8
                    cs = int((origin_stat.ewma_bps * est_segment_dur / 8) / desired_chunks)
                    chunk_size = clamp(MIN_CHUNK_SIZE, cs, MAX_CHUNK_SIZE)

            logging.info(f"Segmento: max_retries={max_retries}, backoff={backoff_factor:.4f}, chunk_size={chunk_size}")

            client_range = headers.get('Range')
            resume_offset = None
            bytes_sent = 0
            r = None

            for attempt in range(max_retries + 1):
                try:
                    req_headers = dict(headers)
                    if resume_offset:
                        req_headers['Range'] = f"bytes={resume_offset}-"
                    elif client_range:
                        req_headers['Range'] = client_range

                    t0 = time.time()
                    if not hasattr(self.http_session, 'get'):
                        raise RequestException("HTTP session not available")
                    r = self.http_session.get(url, headers=req_headers, stream=True, timeout=stream_timeout, verify=False, allow_redirects=True)
                    if getattr(r, 'status_code', None) in (404, 403):
                        logging.warning(f"Segmento erro ({r.status_code}): {_obfuscate_url(url)}. Refresh de sessão.")
                        origin_stat.record_failure()
                        self.rotate_user_agent_and_refresh_session()
                        self.send_error(r.status_code)
                        return
                    if hasattr(r, 'raise_for_status'):
                        r.raise_for_status()
                    latency = time.time() - t0
                    content_length = int(r.headers.get('Content-Length', 0) or 0) if getattr(r, 'headers', None) else 0
                    origin_stat.record_sample(content_length, latency)
                    origin_stat.record_success()
                    break
                except Exception as e:
                    origin_stat.record_failure()
                    if attempt == max_retries:
                        raise
                    jitter = random.uniform(0, 0.1 * backoff_factor)
                    sleep_for = clamp(0.05, backoff_factor * (2 ** attempt) + jitter, 5)
                    logging.warning(f"Retry {attempt+1}/{max_retries} for segment {_obfuscate_url(url)}: {e}; sleeping {sleep_for:.2f}s")
                    time.sleep(sleep_for)
                    if bytes_sent > 0:
                        resume_offset = bytes_sent

            if r is None:
                raise RuntimeError("Failed to get segment")

            self.send_response(r.status_code)
            for header, value in getattr(r, 'headers', {}).items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                    self.send_header(header, value)
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.end_headers()

            if head_only:
                return

            start_time = time.time()
            for chunk in r.iter_content(chunk_size=chunk_size):
                if not chunk:
                    continue
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                    bytes_sent += len(chunk)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    logging.warning("Cliente fechou conexão durante segmento.")
                    origin_stat.record_failure()
                    return
                if origin_stat.ewma_latency and origin_stat.ewma_latency > 1.0:
                    time.sleep(0.001)

            elapsed = max(0.0001, time.time() - start_time)
            origin_stat.record_sample(bytes_sent, elapsed)

            try:
                if hasattr(r, 'close'):
                    r.close()
            except Exception:
                pass

            with self.metrics_lock:
                self.metrics['segments_served'] += 1
            return

        except Exception as e:
            logging.error(f"Erro geral no segmento {_obfuscate_url(url)}: {e}")
            with self.metrics_lock:
                self.metrics['segment_fetch_errors'] += 1
            origin_stat.record_failure()
            self.rotate_user_agent_and_refresh_session()
            try:
                self.send_error(500)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return
        finally:
            try:
                origin_stat.semaphore.release()
            except Exception:
                pass
            try:
                self.global_semaphore.release()
            except Exception:
                pass

# ---------------- MANAGER ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None
        self.handler_class = HLSProxyRequestHandler

    def start(self):
        if self.thread and self.thread.is_alive():
            logging.info(f"Proxy já rodando na porta {self.active_port}")
            return True
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = _TCPServer((PROXY_HOST, port), self.handler_class)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy HLS persistente iniciado na porta {self.active_port}")
                logging.info(f"User-Agent inicial: {self.handler_class.get_current_user_agent()}")
                return True
            except OSError as e:
                logging.warning(f"Porta {port} ocupada ou erro de socket: {e}")
                continue
        logging.error("Não foi possível iniciar o proxy.")
        return False

    def stop(self):
        if self.server:
            logging.info("Parando servidor proxy.")
            self.server.shutdown()
            self.server.server_close()
            try:
                if self.handler_class.http_session and hasattr(self.handler_class.http_session, 'close'):
                    self.handler_class.http_session.close()
            except Exception:
                pass
            with self.handler_class.cache_lock:
                self.handler_class.manifest_cache.clear()
                for origin, osobj in list(self.handler_class.origin_stats.items()):
                    with osobj.lock:
                        osobj.prefetch_cache.clear()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1)
            logging.info("Thread do proxy encerrada.")
        self.server = None
        self.thread = None
        self.active_port = None

# ---------------- ADDON INTERFACE ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None, headers=None):
        if not self.proxy.start():
            logging.error("Falha ao iniciar HLS Proxy.")
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"

        if headers and isinstance(headers, dict):
            encoded_headers = urllib.parse.quote_plus(json.dumps(headers))
            proxy_url += f"&headers={encoded_headers}"

        li = xbmcgui.ListItem(path=proxy_url)
        try:
            li.setProperty("IsPlayable", "true")
        except Exception:
            pass

        info_labels = {}
        if title:
            info_labels['title'] = title

        if stype == "live":
            try:
                li.setMimeType("application/vnd.apple.mpegurl")
            except Exception:
                pass
            try:
                li.setProperty("IsLive", "true")
            except Exception:
                pass
            info_labels['duration'] = 3600

        if info_labels:
            try:
                li.setInfo(type='video', infoLabels=info_labels)
            except Exception:
                pass

        xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- MAIN ----------------
def main():
    setup_logging()
    try:
        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            headers_str = args.get('headers', [None])[0]

            custom_headers = None
            if headers_str:
                try:
                    custom_headers = json.loads(urllib.parse.unquote_plus(headers_str))
                except Exception as e:
                    logging.error(f"Erro ao analisar headers: {e}")

            if stream_url:
                addon.play_stream(stream_url, stream_type, title, custom_headers)
            else:
                logging.error("URL do stream não fornecida.")
                xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        logging.error(f"Erro main: {e}")

if __name__ == '__main__':
    main()