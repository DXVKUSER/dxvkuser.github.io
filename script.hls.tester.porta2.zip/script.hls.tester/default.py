import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
import re
import queue
import json
from collections import OrderedDict
from typing import Optional, Dict, Any, List, Tuple, Type, Union
from concurrent.futures import ThreadPoolExecutor

# ==============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO ---
# Otimizado para Reconexão Imediata na Primeira Falha
# ==============================================================================

# --- Estratégia de Reconexão e Falha ---
MAX_CONSECUTIVE_SEGMENT_FAILURES = 1
MAX_STICKY_SEGMENT_RETRIES = 0

# --- Configurações do Fetcher (Requisições HTTP) ---
FETCHER_MAX_RETRIES = 0
RETRY_BACKOFF_FACTOR = 0.0
CONNECTION_TIMEOUT = 4.0
STREAM_TIMEOUT = 5.0
DEFAULT_CHUNK_SIZE = 50 * 1024
MAX_SEGMENT_SIZE_MB = 20
MAX_SEGMENT_SIZE_BYTES = MAX_SEGMENT_SIZE_MB * 1024 * 1024

# --- Configurações de Pré-busca (Pre-fetching) ---
PREFETCH_SEGMENTS_COUNT = 3

# --- Configurações do Proxy e Addon ---
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'

# Definindo o range de portas para o proxy HLS (portas privadas/efêmeras)
HLS_PROXY_PORT_RANGE_START = 49152 # Início do range de portas privadas/efêmeras
HLS_PROXY_PORT_RANGE_END = 65535   # Fim do range de portas privadas/efêmeras
HLS_PROXY_MAX_PORT_ATTEMPTS = 50   # Número de tentativas para encontrar uma porta livre para o proxy HLS

LIMIT_COOLDOWN_SECONDS = 5

# --- Configurações de Spoofing e Rede ---
SPOOF_X_FORWARDED_FOR = False
FIXED_X_FORWARDED_FOR_IP = "8.8.8.8"
# User-Agent a ser usado consistentemente (apenas para teste/depuração)
FIXED_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"

# --- Configuração de Logging ---
LOG_MAX_BYTES = 1048576 * 1
LOG_BACKUP_COUNT = 1
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
LOG_LEVEL = logging.INFO

# --- Constantes ---
_SENSITIVE_HEADERS = {'Content-Length', 'Connection'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}


# ==============================================================================
# --- INICIALIZAÇÃO DO LOGGING ---
# ==============================================================================
def setup_logging():
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

setup_logging()


# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================
def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def join_host_port(host: str, port: int) -> str:
    return f'[{host}]:{port}' if ':' in host and is_valid_ip(host) else f'{host}:{port}'

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str, user_agent: str, referer_override: Optional[str] = None) -> Dict[str, str]:
    headers = {
        "User-Agent": user_agent,
        "Accept": "*/*"
    }

    if referer_override:
        parsed_referer = urllib.parse.urlparse(referer_override)
        referer_base = f"{parsed_referer.scheme}://{parsed_referer.netloc}"
        headers["Referer"] = referer_base
        headers["Origin"] = referer_base
    else:
        parsed_url = urllib.parse.urlparse(url)
        origin_base = f"{parsed_url.scheme}://{parsed_url.netloc}"
        headers["Referer"] = origin_base
        headers["Origin"] = origin_base
    
    return headers

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith(('.m3u8', '.m3u')): return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'): return 'video/mp2t'
    if path.endswith('.aac'): return 'audio/aac'
    if path.endswith('.mp4'): return 'video/mp4'
    if path.endswith('.mp3'): return 'audio/mpeg'
    if path.endswith('.webm'): return 'video/webm'
    if path.endswith('.ogg'): return 'application/ogg'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content: return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u": return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
                "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid"]
    return any(keyword in txt for keyword in keywords)


# ==============================================================================
# --- RESOLUTOR DE DNS (CUSTOMIZADO PARA CLOUDFLARE DOH) ---
# ==============================================================================
class DoHDNSResolver:
    """Resolve nomes de host para IPs usando DNS-over-HTTPS (DoH)."""
    def __init__(self, cache_ttl: int = 60, doh_urls: List[str] = None):
        self._cache: Dict[str, Tuple[str, float]] = {}
        self._lock = threading.Lock()
        self.cache_ttl = cache_ttl
        self.doh_urls = doh_urls or ['https://1.1.1.1/dns-query']
        self._current_doh_index = 0
        self.session = requests.Session()

    def _query_doh(self, hostname: str) -> Optional[str]:
        headers, params = {"Accept": "application/dns-json"}, {"name": hostname, "type": "A"}
        for _ in range(len(self.doh_urls)):
            current_url = self.doh_urls[self._current_doh_index]
            try:
                response = self.session.get(current_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False)
                response.raise_for_status()
                data = response.json()
                if data and 'Answer' in data:
                    for answer in data['Answer']:
                        if answer['type'] == 1:
                            self._current_doh_index = (self._current_doh_index + 1) % len(self.doh_urls)
                            return answer['data']
            except (requests.exceptions.RequestError, json.JSONDecodeError) as e:
                logging.warning(f"[DoHDNSResolver] Erro ao consultar {current_url}: {e}")
            self._current_doh_index = (self._current_doh_index + 1) % len(self.doh_urls)
        return None

    def resolve(self, hostname: str) -> Optional[str]:
        if is_valid_ip(hostname): return hostname
        with self._lock:
            cached_entry = self._cache.get(hostname)
            if cached_entry and time.time() < cached_entry[1]: return cached_entry[0]
        ip = self._query_doh(hostname)
        if ip:
            with self._lock: self._cache[hostname] = (ip, time.time() + self.cache_ttl)
        return ip

    def clear_cache_for_host(self, hostname: str):
        with self._lock:
            if hostname in self._cache:
                del self._cache[hostname]
                logging.info(f"[RECONEXÃO] Cache de DNS limpo para o host: {hostname}")

    def clear_cache(self):
        with self._lock: self._cache.clear()


# ==============================================================================
# --- CACHE DE DADOS E FETCHER ---
# ==============================================================================
class RotatingChunkCache:
    """Cache LRU para segmentos de vídeo."""
    def __init__(self_obj, max_chunks: int = 15):
        self_obj.max_chunks, self_obj.lock = max_chunks, threading.Lock()
        self_obj.chunks: OrderedDict[str, bytes] = OrderedDict()
    def get(self_obj, url: str) -> Optional[bytes]:
        with self_obj.lock:
            data = self_obj.chunks.get(url)
            if data: self_obj.chunks.move_to_end(url)
            return data
    def add(self_obj, url: str, data: bytes):
        with self_obj.lock:
            if url in self_obj.chunks: self_obj.chunks.pop(url)
            self_obj.chunks[url] = data
            if len(self_obj.chunks) > self_obj.max_chunks: self_obj.chunks.popitem(last=False)
    def clear(self_obj):
        with self_obj.lock: self_obj.chunks.clear()
    def has(self_obj, url: str) -> bool:
        with self_obj.lock: return url in self_obj.chunks

class UpstreamFetcher:
    """Busca conteúdo da fonte original."""
    def __init__(self, session: requests.Session, dns_resolver: 'DoHDNSResolver', proxy_manager: 'HLSProxyManager'):
        self.session, self.dns_resolver, self.proxy_manager = session, dns_resolver, proxy_manager
    
    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        # Passa o URL base do manifesto original como referer_override
        # E o user_agent consistente da sessão do proxy manager
        headers = get_player_headers(url, self.proxy_manager._user_agent, self.proxy_manager._initial_stream_base_url)

        # Removemos a resolução de DNS explícita e a reconstrução da URL aqui.
        # A biblioteca requests fará a resolução de DNS internamente para a URL fornecida.
        # O cabeçalho 'Host' é definido implicitamente pela URL que a requests resolve.
        
        logging.info(f"HEADERS ENVIADOS para {url}: {headers}") # Log dos cabeçalhos enviados

        try:
            resp = self.session.get(url, stream=stream, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                                    headers=headers, allow_redirects=True, verify=False)
            resp.raise_for_status()
            return resp
        except requests.RequestError as e:
            raise e


class ManifestRewriter:
    """Reescreve um manifesto M3U8 para apontar para o proxy."""
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj, self.proxy_base_url = m3u8.loads(content, uri=manifest_url), proxy_base_url
    def rewrite(self) -> str:
        items = (getattr(self.m3u8_obj, 'playlists', []) + getattr(self.m3u8_obj, 'media', []) +
                 getattr(self.m3u8_obj, 'segments', []))
        for item in items:
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri and not item.key.uri.startswith("data:"):
                item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()


# ==============================================================================
# --- PROXY HTTP ---
# ==============================================================================
class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, request, client_address, server, proxy_manager: 'HLSProxyManager'):
        self.proxy_manager = proxy_manager
        self.chunk_cache = proxy_manager.chunk_cache
        self.fetcher = proxy_manager.fetcher
        super().__init__(request, client_address, server)

    def log_message(self, format: str, *args: Any): pass

    def _send_response(self, status_code: int, content: bytes, content_type: str):
        try:
            self.send_response(status_code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            if content: self.wfile.write(content)
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            logging.info(f"[{self.address_string()}] Cliente desconectou.")

    def basename(self,p):
        """Returns the final component of a pathname"""
        i = p.rfind('/') + 1
        return p[i:]
    
    def convert_to_m3u8(self,url):
        if '|' in url:
            url = url.split('|')[0]
        elif '%7C' in url:
            url = url.split('%7C')[0]
        if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
            parsed_url = urllib.parse.urlparse(url)
            try:
                host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                file = self.basename(url)
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                else:
                    url = url + '.m3u8'
            except:
                pass
        return url 

    def do_GET(self):
        try:
            original_url = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get('url', [''])[0]
            if not original_url: return self.send_error(400, "Parâmetro 'url' ausente")
            
            # --- CHAMA A FUNÇÃO convert_to_m3u8 AQUI ---
            # Isso garante que o URL seja processado antes de qualquer outra lógica.
            original_url = self.convert_to_m3u8(original_url)
            # ------------------------------------------

            # Se for a primeira vez que este proxy manager está a ser usado para um stream,
            # definimos o URL base original (scheme://netloc).
            if self.proxy_manager._initial_stream_base_url is None:
                parsed_original_url = urllib.parse.urlparse(original_url)
                self.proxy_manager._initial_stream_base_url = f"{parsed_original_url.scheme}://{parsed_original_url.netloc}"

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            logging.info(f"[{self.address_string()}] Cliente desconectou.")
        except Exception as e:
            logging.error(f"[{self.address_string()}] Erro geral no proxy: {e}", exc_info=True)
            if not self.wfile.closed: self.send_error(500, "Erro interno")

    def _handle_manifest(self, url: str):
        if self.proxy_manager.is_in_cooldown(url):
            return self._send_response(200, b"#EXTM3U\n", 'application/vnd.apple.mpegurl')
        try:
            response = self.fetcher.fetch(url)
            content = response.text
            if is_manifest_limit_error(content):
                self.proxy_manager.record_limit_hit(url); self.proxy_manager.force_reconnection(url)
                return self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")
            proxy_base = f"http://{join_host_port(self.server.server_address[0], self.server.server_address[1])}/?url="
            rewritten_content = ManifestRewriter(content, response.url, proxy_base).rewrite()
            self.proxy_manager.set_latest_manifest(content, response.url)
            self.proxy_manager.clear_limit_hit(url)
            self._send_response(200, rewritten_content.encode('utf-8'), 'application/vnd.apple.mpegurl')
        except Exception as e:
            logging.error(f"Falha ao processar manifesto {url}: {e}. Forçando reconexão.")
            self.proxy_manager.force_reconnection(url)
            self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

    def _handle_segment(self, url: str):
        mime_type = safe_mime_type(url)
        cached_segment = self.chunk_cache.get(url)
        if cached_segment:
            self.proxy_manager.reset_failure_count()
            self.proxy_manager.trigger_prefetch(url)
            return self._send_response(200, cached_segment, mime_type)
        try:
            response = self.fetcher.fetch(url, stream=True)
            segment_data = bytearray()
            for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                segment_data.extend(chunk)
                if len(segment_data) > MAX_SEGMENT_SIZE_BYTES:
                    raise IOError(f"Segmento excedeu {MAX_SEGMENT_SIZE_MB}MB.")
            final_data = bytes(segment_data)
            self.chunk_cache.add(url, final_data)
            self.proxy_manager.reset_failure_count()
            self._send_response(200, final_data, mime_type)
            self.proxy_manager.trigger_prefetch(url)
        except Exception as e:
            logging.warning(f"Falha ao baixar segmento {url}: {e}")
            self.proxy_manager.increment_failure_count()
            if self.proxy_manager.should_force_reconnect():
                logging.error(f"PRIMEIRA FALHA DE SEGMENTO. FORÇANDO RECONEXÃO IMEDIATA.")
                self.proxy_manager.force_reconnection(url)
            self.send_error(503, "Segmento indisponível.")

class HLSProxyManager:
    def __init__(self):
        self.server: Optional[socketserver.ThreadingTCPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None

        self._management_server: Optional[socketserver.ThreadingTCPServer] = None
        self._management_server_thread: Optional[threading.Thread] = None
        self._management_api_port: Optional[int] = None

        self._http_session: requests.Session = self._create_http_session()
        self.dns_resolver = DoHDNSResolver(doh_urls=['https://1.1.1.1/dns-query', 'https://dns.nextdns.io'])
        self.chunk_cache = RotatingChunkCache(max_chunks=15)
        self._user_agent: str = FIXED_USER_AGENT # Usar User-Agent fixo
        self.fetcher = UpstreamFetcher(self._http_session, self.dns_resolver, self) 
        self.prefetch_executor = ThreadPoolExecutor(max_workers=PREFETCH_SEGMENTS_COUNT, thread_name_prefix='Prefetcher')
        self._failure_lock, self._consecutive_failures = threading.Lock(), 0
        self._limit_hits: Dict[str, float] = {}
        self._manifest_lock = threading.Lock()
        self._latest_manifest_content: Optional[str] = None
        self._latest_manifest_url: Optional[str] = None
        self._initial_stream_base_url: Optional[str] = None # Atributo para o URL base original (scheme://netloc)

    def _create_http_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({'Connection': 'keep-alive'})
        session.trust_env = False
        return session

    def reset_http_session(self):
        logging.info("[RECONEXÃO] Recriando sessão HTTP e limpando cache DNS.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher.session = self._http_session
        self.dns_resolver.clear_cache()
        self._initial_stream_base_url = None # Resetar o URL base na reconexão
        self._user_agent = FIXED_USER_AGENT # Manter o User-Agent fixo
        logging.info(f"User-Agent da sessão redefinido para: {self._user_agent}")

    def force_reconnection(self, url: Optional[str] = None):
        logging.info(f"[RECONEXÃO] Forçando reconexão completa. URL base: {url}")
        self.reset_failure_count()
        self.chunk_cache.clear()
        if url:
            parsed_url = urllib.parse.urlparse(url)
            if parsed_url.hostname: self.dns_resolver.clear_cache_for_host(parsed_url.hostname)
        self.reset_http_session()

    def increment_failure_count(self):
        with self._failure_lock: self._consecutive_failures += 1
    def reset_failure_count(self):
        with self._failure_lock: self._consecutive_failures = 0
    def should_force_reconnect(self) -> bool:
        with self._failure_lock: return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES
    
    def record_limit_hit(self, url: str): self._limit_hits[self._get_base_url(url)] = time.time()
    def is_in_cooldown(self, url: str) -> bool:
        hit_time = self._limit_hits.get(self._get_base_url(url))
        return hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS
    def clear_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        if base_url in self._limit_hits: del self._limit_hits[base_url]
    @staticmethod
    def _get_base_url(url: str) -> str:
        parts = urllib.parse.urlparse(url)
        return f"{parts.scheme}://{parts.netloc}"

    def set_latest_manifest(self, content: str, url: str):
        with self._manifest_lock:
            self._latest_manifest_content, self._latest_manifest_url = content, url

    def _prefetch_segment(self, segment_url: str):
        try:
            response = self.fetcher.fetch(segment_url, stream=False)
            segment_data = response.content
            if len(segment_data) > MAX_SEGMENT_SIZE_BYTES: return
            self.chunk_cache.add(segment_url, segment_data)
            logging.info(f"[Prefetch] Sucesso ao pré-carregar {segment_url}")
        except Exception as e:
            logging.warning(f"[Prefetch] Falha ao pré-carregar {segment_url}: {e}")

    def trigger_prefetch(self, current_segment_url: str):
        if PREFETCH_SEGMENTS_COUNT <= 0: return
        with self._manifest_lock:
            if not self._latest_manifest_content: return
            manifest_content, manifest_uri = self._latest_manifest_content, self._latest_manifest_url
        try:
            m3u8_obj = m3u8.loads(manifest_content, uri=manifest_uri)
            if not m3u8_obj.segments: return
            all_uris = [s.absolute_uri for s in m3u8_obj.segments]
            try: current_index = all_uris.index(current_segment_url)
            except ValueError: return
            for i in range(1, PREFETCH_SEGMENTS_COUNT + 1):
                next_index = current_index + i
                if next_index < len(all_uris):
                    url_to_prefetch = all_uris[next_index]
                    if not self.chunk_cache.has(url_to_prefetch):
                        self.prefetch_executor.submit(self._prefetch_segment, url_to_prefetch)
        except Exception as e:
            logging.error(f"[Prefetch] Erro ao processar manifesto: {e}", exc_info=False)

    def _start_management_server(self):
        if self._management_server: return

        global API_HOST, MANAGEMENT_API_PORT_RANGE_START, MANAGEMENT_API_PORT_RANGE_END, MANAGEMENT_API_MAX_PORT_ATTEMPTS

        # ALTERADO: Aumenta o número de tentativas para a API de gerenciamento
        management_attempts = MANAGEMENT_API_MAX_PORT_ATTEMPTS # Usando a constante definida

        for attempt in range(management_attempts):
            port = random.randint(MANAGEMENT_API_PORT_RANGE_START, MANAGEMENT_API_PORT_RANGE_END)
            server_address = (API_HOST, port)
            try:
                # Passa o proxy_manager para o handler para acesso aos dados
                handler_factory = functools.partial(ProxyManagementHandler, proxy_manager=self)
                httpd = CustomHTTPServer(server_address, handler_factory)
                
                logging.info(f"Management API server starting on http://{server_address[0]}:{server_address[1]}/ (Attempt {attempt + 1}/{management_attempts})")
                self._management_server = httpd
                self._management_api_port = port
                self._management_server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
                self._management_server_thread.start()
                logging.info(f"Management API server successfully started on port {self._management_api_port}.")
                return
            except OSError as e:
                if e.errno == 98: # Address already in use
                    logging.warning(f"Management API: Port {port} already in use. Attempt {attempt + 1}/{management_attempts}. Trying another port.")
                    time.sleep(0.2) # Pequena pausa antes de tentar outra porta
                else:
                    logging.error(f"Management API: Error starting server on port {port}: {e}", exc_info=True)
                    raise
            except Exception as e:
                logging.error(f"Management API: Unexpected error starting server on port {port}: {e}", exc_info=True)
                raise
        logging.error("Management API: Failed to start server after multiple port attempts.")
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o servidor de gerenciamento",5000)')

    def _stop_management_server(self):
        if self._management_server:
            logging.info("Shutting down Management API server.")
            self._management_server.shutdown()
            self._management_server.server_close()
            self._management_server = None
        if self._management_server_thread and self._management_server_thread.is_alive():
            self._management_server_thread.join(timeout=2)
        self._management_api_port = None
        logging.info("Management API server stopped.")


    def start(self) -> Optional[int]:
        if self.server: return self.active_port
        
        self.reset_http_session()
        self.chunk_cache.clear()
        self.reset_failure_count()
        self._limit_hits.clear()
        
        # Inicia o servidor de gerenciamento antes do proxy HLS
        self._start_management_server()

        handler_factory = functools.partial(HLSProxyHandler, proxy_manager=self)
        
        # ALTERADO: Lógica de porta rotativa para o proxy HLS
        # Tenta um número definido de portas aleatórias dentro do range privado.
        for attempt in range(HLS_PROXY_MAX_PORT_ATTEMPTS):
            port = random.randint(HLS_PROXY_PORT_RANGE_START, HLS_PROXY_PORT_RANGE_END)
            try:
                server = socketserver.ThreadingTCPServer((PROXY_HOST, port), handler_factory)
                server.allow_reuse_address = True
                self.server, self.active_port = server, port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy iniciado em {PROXY_HOST}:{port} (Tentativa {attempt + 1}/{HLS_PROXY_MAX_PORT_ATTEMPTS}).")
                return port
            except OSError as e:
                if e.errno == 98: # Address already in use
                    logging.warning(f"Falha ao iniciar proxy na porta {port}: [Errno 98] Address already in use. Tentativa {attempt + 1}/{HLS_PROXY_MAX_PORT_ATTEMPTS}. Tentando outra porta.")
                    time.sleep(0.1) # Pequena pausa antes de tentar outra porta
                else:
                    logging.error(f"Falha ao iniciar proxy na porta {port}: {e}. Verifique se a porta está em uso ou há permissões.", exc_info=True)
                    break # Saia do loop se for um erro diferente de "Address already in use"
            except Exception as e:
                logging.error(f"Erro inesperado ao iniciar proxy na porta {port}: {e}", exc_info=True)
                break

        logging.error(f"Não foi possível iniciar o proxy HLS após {HLS_PROXY_MAX_PORT_ATTEMPTS} tentativas.")
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy HLS. Nenhuma porta livre encontrada.",5000)')
        return None

    def stop(self):
        logging.info("Iniciando parada total do Proxy HLS e recursos.")
        if self.server:
            logging.info(f"Desligando servidor HLS Proxy na porta {self.active_port}.")
            self.server.shutdown(); self.server.server_close(); self.server = None
        if self.server_thread and self.server_thread.is_alive(): 
            logging.info("Aguardando thread do servidor HLS Proxy finalizar.")
            self.server_thread.join(timeout=2)
        
        logging.info("Encerrando ThreadPoolExecutor do Prefetcher.")
        self.prefetch_executor.shutdown(wait=False)
        self.prefetch_executor = ThreadPoolExecutor(max_workers=PREFETCH_SEGMENTS_COUNT, thread_name_prefix='Prefetcher') # Recria o executor para futuras utilizações

        self.chunk_cache.clear(); 
        self.reset_http_session(); 
        self.active_port = None
        self.reset_failure_count(); 
        self._limit_hits.clear()
        self._initial_stream_base_url = None # Garantir que o URL base seja redefinido
        self._user_agent = FIXED_USER_AGENT # Manter o User-Agent fixo
        
        # Para o servidor de gerenciamento ao parar o proxy
        self._stop_management_server()

        logging.info("Proxy parado e recursos liberados completamente.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port: return None
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/?url={urllib.parse.quote_plus(original_url)}"


# ==============================================================================
# --- WEB API SERVER & LÓGICA DO ADDON KODI (Corrigido) ---
# ==============================================================================
global_proxy_manager: Optional[HLSProxyManager] = None
# API_HOST é definida globalmente, mas a porta é gerenciada internamente no HLSProxyManager para o servidor de gerenciamento.
API_HOST = '127.0.0.1' 

# ALTERADO: Porta do servidor de gerenciamento para começar a partir de 60000
MANAGEMENT_API_PORT_RANGE_START = 60000
MANAGEMENT_API_PORT_RANGE_END = 65535 # Final do range de portas privadas/efêmeras

# Aumentar o número máximo de tentativas para o servidor de gerenciamento
MANAGEMENT_API_MAX_PORT_ATTEMPTS = 50 

class CustomHTTPServer(http.server.HTTPServer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.allow_reuse_address = True

class ProxyManagementHandler(http.server.SimpleHTTPRequestHandler):
    # Adiciona o proxy_manager como um atributo da classe, para ser passado no __init__
    def __init__(self, request, client_address, server, proxy_manager: 'HLSProxyManager'):
        self.proxy_manager = proxy_manager
        super().__init__(request, client_address, server)

    def log_message(self, format: str, *args: Any): pass
    def do_GET(self):
        if self.path == '/status': self._send_json_response(self.get_status())
        elif self.path == '/':
            try:
                with open(os.path.join(os.path.dirname(__file__), 'index.html'), 'rb') as f:
                    self.send_response(200); self.send_header('Content-type', 'text/html'); self.end_headers(); self.wfile.write(f.read())
            except FileNotFoundError: self.send_error(404, "index.html not found.")
        else: self.send_error(404, "Not Found")
    def do_POST(self):
        # Ações agora acessam o proxy_manager via self.proxy_manager
        actions = {'/start': (self.proxy_manager.start, "Proxy started"),
                   '/stop': (self.proxy_manager.stop, "Proxy stopped"),
                   '/reconnect': (lambda: self.proxy_manager.force_reconnection(), "Forced reconnection"),
                   '/clear_cache': (self.proxy_manager.chunk_cache.clear, "Chunk cache cleared")}
        if self.path in actions: self._handle_action(*actions[self.path])
        else: self.send_error(404)
    
    def get_status(self):
        # Acessa o proxy_manager via self.proxy_manager
        if self.proxy_manager:
            is_running = self.proxy_manager.server is not None
            # Usa self.proxy_manager._management_api_port para a porta do gerenciamento
            return {"is_running": is_running, 
                    "active_proxy_port": self.proxy_manager.active_port,
                    "active_management_port": self.proxy_manager._management_api_port,
                    "consecutive_failures": getattr(self.proxy_manager, '_consecutive_failures', 0)}
        return {"is_running": False, "active_proxy_port": None, "active_management_port": None, "consecutive_failures": 0, "message": "Proxy manager not initialized."}
    
    def _send_json_response(self, data, status_code=200):
        self.send_response(status_code); self.send_header('Content-type', 'application/json'); self.end_headers(); self.wfile.write(json.dumps(data).encode('utf-8'))
    def _handle_action(self, action_func, success_message):
        # proxy_manager agora é self.proxy_manager
        if not self.proxy_manager: self._send_json_response({"success": False, "message": "Proxy manager not initialized."}, 500); return
        try:
            result = action_func()
            response_data = {"success": True, "message": success_message}
            if self.path == '/start' and result is not None: response_data["port"] = result
            self._send_json_response(response_data)
        except Exception as e: logging.error(f"API Error: {e}", exc_info=True); self._send_json_response({"success": False, "message": str(e)}, 500)

# A função start_management_server original foi movida para dentro de HLSProxyManager como _start_management_server


class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event, proxy_manager: 'HLSProxyManager'):
        super().__init__(); self.stop_event, self.proxy_manager = stop_event, proxy_manager
    def onPlayBackEnded(self): 
        logging.info("Evento: onPlayBackEnded - Parando o proxy.")
        self.stop_event.set(); self.proxy_manager.stop()
    def onPlayBackError(self): 
        logging.info("Evento: onPlayBackError - Parando o proxy.")
        self.stop_event.set(); self.proxy_manager.stop()
    def onPlayBackStopped(self): 
        logging.info("Evento: onPlayBackStopped - Parando o proxy.")
        self.stop_event.set(); self.proxy_manager.stop()

class HLSProxyAddon:
    def __init__(self, handle: int, proxy_manager: 'HLSProxyManager'):
        self.handle, self.proxy_manager = handle, proxy_manager
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event, self.proxy_manager)
    def play_stream(self, url: str, channel_name: Optional[str] = None):
        # Resetar _initial_stream_base_url ao iniciar um novo stream
        self.proxy_manager._initial_stream_base_url = None
        
        logging.info(f"Tentando iniciar proxy para reproduzir {channel_name or url}")
        if not self.proxy_manager.start():
            logging.error("Falha ao iniciar o proxy. Não é possível reproduzir o stream.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        proxy_url = self.proxy_manager.get_proxy_url(url)
        list_item = xbmcgui.ListItem(path=proxy_url, label=f"{channel_name or 'Stream'} [COLOR cyan](HLS TESTER)[/COLOR]")
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        logging.info(f"Kodi resolvido para: {proxy_url}")
        self.playback_stop_event.clear()
    def show_test_streams(self):
        streams = [("Big Buck Bunny (VOD)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
                   ("Live Test (Low Latency)", "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8")]
        for name, url in streams:
            item = xbmcgui.ListItem(label=name)
            item.setProperty('IsPlayable', 'true')
            plugin_url = f"plugin://{ADDON_ID}/?{urllib.parse.urlencode({'action': 'play', 'url': url, 'title': name})}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, item, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    global global_proxy_manager
    try:
        # Inicializa o proxy manager uma única vez.
        # Se já estiver inicializado de uma sessão anterior, ele será reutilizado.
        if global_proxy_manager is None:
            logging.info("Inicializando HLSProxyManager global pela primeira vez.")
            global_proxy_manager = HLSProxyManager()
            # O servidor de gerenciamento agora é iniciado e parado pelo proxy_manager.start() e .stop()
            # Não precisamos chamá-lo separadamente aqui.
            
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get('action')
        addon = HLSProxyAddon(handle, global_proxy_manager)

        # Se o addon está sendo iniciado (não é uma ação de 'play'), garantir que o proxy manager está parado
        # para que uma nova sessão limpa possa ser iniciada na próxima reprodução.
        # Isso ajuda a liberar portas de instâncias anteriores.
        if action is None: # Se não há ação específica (provavelmente ao carregar o addon no menu)
            logging.info("Addon iniciado sem ação de reprodução. Parando qualquer proxy existente.")
            global_proxy_manager.stop() # Garante que tudo esteja limpo antes de listar os itens
            addon.show_test_streams()
        elif action == 'play':
            url, title = params.get('url'), params.get('title')
            if url: addon.play_stream(url, title)
    except Exception as e:
        logging.error(f"Erro na execução principal: {e}", exc_info=True)

if __name__ == '__main__':
    main()
