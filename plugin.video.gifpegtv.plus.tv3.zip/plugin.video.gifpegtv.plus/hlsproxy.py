import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import math # Adicionado para arredondamento
from socketserver import ThreadingMixIn

# Importa a biblioteca requests original e seus componentes necessários
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Importa o wrapper do requests do netunblock com um apelido para evitar conflitos
# Assumindo que 'doh_client' é um módulo customizado ou parte do ambiente.
try:
    from doh_client import requests as doh_requests
except ImportError:
    # Fallback: Se doh_client não estiver disponível, usa o requests padrão
    doh_requests = requests

# Dependências específicas do Kodi (assumidas)
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    # Mocks para execução fora do ambiente Kodi
    class MockKodi:
        def translatePath(self, path): return "/tmp/"
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    
# ---------------- CONFIG ----------------
MAX_SEGMENT_RETRIES = 15
RETRY_BACKOFF_FACTOR = 0.1
CONNECTION_TIMEOUT = 10
STREAM_TIMEOUT = 20.0       # Timeout base para segmentos
DEFAULT_CHUNK_SIZE = 1024 * 64 # Chunk size base (64KB)
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"
MANIFEST_RETRY_DELAY = 0.1
MAX_CONSECUTIVE_SEGMENT_ERRORS = 5

# Template do User-Agent para Rotação
USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.{version} Safari/537.36"

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# --- CORRIGIDO: Dummy TS Content (Segmento AAC silencioso de 1s) ---
TS_PACKET_SIZE = 188 
HEADER_HEX = (
    "474000100000b00d00000001e00e0000e02000000001e0310000e0414741001001d6800"
    "0000021c100000000147412110" 
)
try:
    HEADER_BYTES = bytes.fromhex(HEADER_HEX)
except ValueError as e:
    logging.critical(f"Erro na string HEADER_HEX, usando fallback: {e}")
    HEADER_BYTES = b'\x47' * 52 
FILLER_LENGTH = TS_PACKET_SIZE - len(HEADER_BYTES)
SILENT_AAC_TS_PACKET = HEADER_BYTES + (b'\xff' * FILLER_LENGTH)
SILENT_AAC_TS_CONTENT = SILENT_AAC_TS_PACKET * 5 

# ---------------- UTILS ----------------
def setup_logging():
    """Configura o sistema de logging do Python para um arquivo específico do Kodi."""
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    
    session = doh_requests.session
    retry_strategy = Retry(
        total=MAX_SEGMENT_RETRIES,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504, 403]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    
    error_counter = {}
    manifest_duration = 1.0 
    
    # Variáveis de estado dinâmico (por sessão)
    network_quality = {}
    dynamic_chunk_size = {}
    dynamic_stream_timeout = {}
    last_segment_times = {}
    last_segment_sizes = {} 
    
    session_ua_versions = {}
    session_manifest_refresh = {} 
    
    # NOVO: Buffer para armazenar o último segmento bem-sucedido
    last_successful_segment_content = {}
    
    MAX_TIMES_TO_AVERAGE = 10
    
    DUMMY_SEGMENT_CONTENT_TEMPLATE = SILENT_AAC_TS_CONTENT 
    DEFAULT_DUMMY_SIZE_BYTES = 50 * 1024 

    def log_message(self, format, *args):
        """Sobrescreve log_message para usar nosso logger."""
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    def _get_session_user_agent(self, session_id):
        """Pega o User-Agent formatado atual para a sessão."""
        version = HLSProxyRequestHandler.session_ua_versions.get(session_id, random.randint(1000, 5000))
        return USER_AGENT_TEMPLATE.format(version=version)

    def _rotate_session_user_agent(self, session_id):
        """Incrementa a versão do User-Agent para a sessão em +1."""
        current_version = HLSProxyRequestHandler.session_ua_versions.get(session_id, random.randint(1000, 5000))
        new_version = current_version + 1
        HLSProxyRequestHandler.session_ua_versions[session_id] = new_version
        logging.warning(f"Falha detectada. Rotacionando User-Agent para versão {new_version} (Sessão: {session_id})")

    def _reset_session_and_retry(self, session_id):
        logging.info(f"Reiniciando sessão HTTP para recuperação de conexão. (Sessão: {session_id})")
        self._rotate_session_user_agent(session_id)
        HLSProxyRequestHandler.session = doh_requests.session
        HLSProxyRequestHandler.adapter = HTTPAdapter(max_retries=HLSProxyRequestHandler.retry_strategy)
        HLSProxyRequestHandler.session.mount('http://', HLSProxyRequestHandler.adapter)
        HLSProxyRequestHandler.session.mount('https://', HLSProxyRequestHandler.adapter)
        HLSProxyRequestHandler.session_manifest_refresh[session_id] = time.time()
        
    def _get_dynamic_silent_segment(self, session_id):
        segment_sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])
        if segment_sizes:
            avg_size = sum(segment_sizes) / len(segment_sizes)
            target_size = max(int(avg_size * 0.8), self.DEFAULT_DUMMY_SIZE_BYTES)
        else:
            target_size = self.DEFAULT_DUMMY_SIZE_BYTES
        
        content = self.DUMMY_SEGMENT_CONTENT_TEMPLATE
        if len(content) < target_size:
            repeat_factor = (target_size // len(content)) + 1
            content = self.SILENT_AAC_TS_PACKET * repeat_factor
        
        final_content = content[:target_size]
        logging.info(f"Gerando Segmento Silencioso: Tamanho Alvo {target_size // 1024}KB (Sessão: {session_id})")
        return final_content, len(final_content)

    def _send_silent_segment(self, session_id):
        silent_content, content_length = self._get_dynamic_silent_segment(session_id)
        logging.warning(f"Enviando segmento silencioso de {content_length // 1024}KB para manter o player vivo. (Sessão: {session_id})")
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(content_length))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            self.wfile.write(silent_content)
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou conexão durante envio do segmento silencioso.")
        except Exception as e:
            logging.error(f"Erro ao enviar segmento silencioso: {e}")

    def _get_forward_headers(self, session_id):
        ua = self._get_session_user_agent(session_id)
        headers = {'User-Agent': ua, 'Connection': 'keep-alive'}
        if 'Authorization' in self.headers: headers['Authorization'] = self.headers['Authorization']
        if 'Cookie' in self.headers: headers['Cookie'] = self.headers['Cookie']
        return headers

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_response(200)
                self.end_headers()
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_response(200)
                self.end_headers()
                return

            headers = self._get_forward_headers(session_id)
            parsed_url = urllib.parse.urlparse(url)
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, head_only, session_id)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado GET: {e}")
            try:
                self.send_response(200)
                self.end_headers()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante erro inesperado.")
                return

    def _handle_manifest(self, url, headers, head_only, session_id):
        should_refresh = HLSProxyRequestHandler.session_manifest_refresh.pop(session_id, None)
        if should_refresh is not None:
             logging.info(f"Forçando refresh do manifesto para sessão: {session_id}")

        try:
            r = None
            for attempt in range(MAX_SEGMENT_RETRIES):
                try:
                    manifest_headers = self._get_forward_headers(session_id)
                    manifest_headers.update(headers) 
                    r = self.session.get(url, headers=manifest_headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                    break
                except requests.exceptions.RequestException as e:
                    logging.warning(f"Erro ao baixar manifesto (tentativa {attempt+1}): {e} (Sessão: {session_id})")
                    self._rotate_session_user_agent(session_id) 
                    if attempt < MAX_SEGMENT_RETRIES - 1:
                        time.sleep(MANIFEST_RETRY_DELAY)
                        continue
            
            if r is None or r.status_code != 200:
                logging.error(f"Falha total ao obter manifesto. Gerando um fallback. (Sessão: {session_id})")
                manifest_content = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:10\n#EXTINF:10.0,\nplaceholder.ts\n#EXT-X-ENDLIST"
                base_url = url
            else:
                manifest_content = r.text
                base_url = r.url

            # Lógica para calcular a duração média dos segmentos
            total_duration = 0.0
            segment_count = 0
            for line in manifest_content.splitlines():
                if line.startswith('#EXTINF:'):
                    try:
                        duration = float(line.split('#EXTINF:')[1].split(',')[0])
                        total_duration += duration
                        segment_count += 1
                    except (IndexError, ValueError):
                        pass

            if segment_count > 0:
                HLSProxyRequestHandler.manifest_duration = max(total_duration / segment_count, 1.0)
            
            # NOVO: Lógica para gerar o manifesto com TARGETDURATION dinâmico
            session_times = HLSProxyRequestHandler.last_segment_times.get(session_id, [])
            if session_times:
                avg_duration = sum(session_times) / len(session_times)
                # Adiciona uma margem de segurança de 20% e arredonda para cima
                dynamic_target_duration = math.ceil(avg_duration * 1.2)
            else:
                # Usa a duração do manifesto ou um padrão se não há dados de segmento ainda
                dynamic_target_duration = math.ceil(HLSProxyRequestHandler.manifest_duration * 1.2)

            new_manifest_lines = []
            target_duration_set = False
            
            for line in manifest_content.splitlines():
                stripped = line.strip()
                if stripped.startswith('#EXT-X-TARGETDURATION:'):
                    new_manifest_lines.append(f"#EXT-X-TARGETDURATION:{dynamic_target_duration}")
                    target_duration_set = True
                elif stripped.upper() == '#EXT-X-ENDLIST':
                    continue # Remove o endlist para simular live
                elif not stripped or stripped.startswith('#'):
                    new_manifest_lines.append(line)
                else:
                    full_segment_url = urllib.parse.urljoin(base_url, stripped)
                    proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&session_id={session_id}"
                    new_manifest_lines.append(proxy_segment_url)

            if not target_duration_set:
                # Se não encontrou a tag, insere após a primeira linha (geralmente #EXTM3U)
                new_manifest_lines.insert(1, f"#EXT-X-TARGETDURATION:{dynamic_target_duration}")

            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()

            if head_only:
                return

            try:
                self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante envio do manifesto.")
                return

        except Exception as e:
            logging.error(f"Erro fatal ao manipular manifesto ({session_id}): {e}")
            try:
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.end_headers()
                manifest_content = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:10\n#EXTINF:10.0,\nplaceholder.ts\n#EXT-X-ENDLIST"
                self.wfile.write(manifest_content.encode('utf-8'))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return
    
    def _handle_segment(self, url, session_id, headers, head_only):
        retries = 0
        consecutive_errors = self.error_counter.get(session_id, 0)
        self._initialize_session_quality(session_id)
        current_chunk_size = HLSProxyRequestHandler.dynamic_chunk_size.get(session_id, DEFAULT_CHUNK_SIZE)
        current_timeout = HLSProxyRequestHandler.dynamic_stream_timeout.get(session_id, STREAM_TIMEOUT)
        
        while retries < MAX_SEGMENT_RETRIES:
            start_time = time.time()
            segment_buffer = bytearray()
            try:
                with self.session.get(url, headers=headers, stream=True, timeout=current_timeout, verify=False) as r:
                    if r.status_code == 404:
                        raise requests.exceptions.HTTPError(f"404 Client Error: Not Found for url: {url}")

                    self.error_counter[session_id] = 0
                    
                    self.send_response(200)
                    for header, value in r.headers.items():
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.send_header(header, value)
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()

                    if head_only:
                        content_length = int(r.headers.get('Content-Length', '0'))
                        self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=content_length)
                        return

                    for chunk in r.iter_content(chunk_size=current_chunk_size):
                        if not chunk: continue
                        segment_buffer.extend(chunk)
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                            logging.warning(f"Cliente fechou conexão. (Sessão: {session_id})")
                            return
                        except Exception as e:
                            logging.error(f"Erro ao escrever chunk: {e} (Sessão: {session_id})")
                            raise # Re-levanta para ser pego pelo except externo

                    # SUCESSO: Salva o conteúdo do segmento no buffer
                    if len(segment_buffer) > 0:
                        HLSProxyRequestHandler.last_successful_segment_content[session_id] = {
                            'content': bytes(segment_buffer),
                            'content_type': r.headers.get('Content-Type', 'video/mp2t'),
                            'content_length': len(segment_buffer)
                        }
                        logging.info(f"Segmento baixado e armazenado no buffer ({len(segment_buffer)} bytes). (Sessão: {session_id})")

                    self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=len(segment_buffer))
                    return # Sucesso, sai do loop de tentativas
            
            except requests.exceptions.RequestException as e:
                retries += 1
                is_timeout = isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectTimeout))
                logging.warning(f"Erro req segmento {url}: {e}, retry {retries}/{MAX_SEGMENT_RETRIES} (Sessão: {session_id})")
                self._update_network_quality(session_id, start_time, time.time(), success=False, is_timeout=is_timeout, size_bytes=0)
                
                # NOVO: Tenta repetir o último segmento bem-sucedido
                last_segment_data = HLSProxyRequestHandler.last_successful_segment_content.get(session_id)
                if last_segment_data:
                    logging.warning(f"Falha ao buscar novo segmento. Repetindo o último segmento bem-sucedido. (Sessão: {session_id})")
                    try:
                        self.send_response(200)
                        self.send_header('Content-Type', last_segment_data['content_type'])
                        self.send_header('Content-Length', str(last_segment_data['content_length']))
                        self.send_header('Cache-Control', 'no-cache')
                        self.end_headers()
                        self.wfile.write(last_segment_data['content'])
                        self.wfile.flush()
                        # Não reseta a sessão ainda, apenas continua o loop de retry
                        time.sleep(min(2 ** retries * 0.2, 2))
                        continue # Vai para a próxima tentativa
                    except Exception as write_e:
                        logging.error(f"Falha ao repetir segmento do buffer: {write_e}. (Sessão: {session_id})")
                        # Se falhar ao escrever, cai para a estratégia de recuperação total

                # Se não há buffer ou falhou ao usar o buffer, aciona recuperação total
                if retries >= MAX_CONSECUTIVE_SEGMENT_ERRORS or retries >= MAX_SEGMENT_RETRIES:
                    logging.error(f"Muitas falhas consecutivas ou máximo de tentativas atingido. Acionando recuperação total! (Sessão: {session_id})")
                    self._send_silent_segment(session_id)
                    self._reset_session_and_retry(session_id)
                    return
                
                time.sleep(min(2 ** retries * 0.2, 2))

            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning(f"Cliente desconectado antes do fim. (Sessão: {session_id})")
                return
            except Exception as e:
                logging.error(f"Erro geral segmento {url}: {e} (Sessão: {session_id})")
                self._reset_session_and_retry(session_id)
                return

        logging.error(f"Segmento falhou de forma irrecuperável após todas as tentativas. (Sessão: {session_id})")
        self._send_silent_segment(session_id)
        
    def _initialize_session_quality(self, session_id):
        if session_id not in HLSProxyRequestHandler.network_quality:
            HLSProxyRequestHandler.network_quality[session_id] = "good"
            HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
            HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            HLSProxyRequestHandler.last_segment_times[session_id] = []
            HLSProxyRequestHandler.last_segment_sizes[session_id] = [] 
            HLSProxyRequestHandler.session_ua_versions[session_id] = random.randint(1000, 5000)
            # Inicializa o buffer de segmento como vazio
            HLSProxyRequestHandler.last_successful_segment_content[session_id] = None

    def _update_network_quality(self, session_id, start_time, end_time, success, is_timeout=False, size_bytes=0):
        self._initialize_session_quality(session_id)
        duration = end_time - start_time
        session_times = HLSProxyRequestHandler.last_segment_times.get(session_id, [])
        session_sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])
        
        if success:
            session_times.append(duration)
            if size_bytes > 0: session_sizes.append(size_bytes)
        else:
            penalty_time = HLSProxyRequestHandler.manifest_duration * 1.5 
            session_times.append(penalty_time)
            logging.warning(f"Falha de segmento registrada. Duração/Penalidade: {penalty_time:.2f}s (Sessão: {session_id})")

        while len(session_times) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE: session_times.pop(0)
        while len(session_sizes) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE: session_sizes.pop(0)
        
        HLSProxyRequestHandler.last_segment_times[session_id] = session_times
        HLSProxyRequestHandler.last_segment_sizes[session_id] = session_sizes

        if not session_times: return 

        avg_time = sum(session_times) / len(session_times)
        current_quality = HLSProxyRequestHandler.network_quality.get(session_id, "good")
        new_quality = current_quality
        segment_len = HLSProxyRequestHandler.manifest_duration

        if avg_time < (segment_len * 0.5): new_quality = "good"
        elif avg_time < (segment_len * 1.5): new_quality = "medium"
        else: new_quality = "bad"

        if new_quality != current_quality:
            logging.info(f"Qualidade da rede mudou de '{current_quality}' para '{new_quality}' (Média tempo: {avg_time:.2f}s) (Sessão: {session_id})")
            HLSProxyRequestHandler.network_quality[session_id] = new_quality
            if new_quality == "good":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = 1024 * 128
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT * 1.2 
            elif new_quality == "medium":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            elif new_quality == "bad":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = 1024 * 16
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT * 0.7 

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()

# ---------------- MANAGER ----------------
class ThreadingHTTPServer(ThreadingMixIn, http.server.HTTPServer):
    pass

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy resiliente iniciado na porta {self.active_port}")
                return True
            except OSError:
                continue
        logging.error("Não foi possível iniciar o proxy em nenhuma porta.")
        return False

class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            if xbmcplugin: xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        session_id = f"stream_{int(time.time())}_{random.randint(1000, 9999)}"
        logging.info(f"Iniciando stream com session_id: {session_id}")
        
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&session_id={session_id}"
        
        if xbmcgui and xbmcplugin:
            li = xbmcgui.ListItem(path=proxy_url, label=title or "Proxy HLS")
            li.setProperty("IsPlayable", "true")
            if stype == "live":
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setProperty("IsLive", "true")
            xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    try:
        if len(sys.argv) < 2:
            logging.error("O script precisa ser chamado pelo Kodi com argumentos.")
            return
        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]
        if action == 'play_stream':
            stream_url = args.get('url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(stream_url, stream_type, title)
        elif xbmcplugin:
            xbmcplugin.endOfDirectory(h)
    except Exception as e:
        logging.error(f"Erro main: {e}")

if __name__ == '__main__':
    main()