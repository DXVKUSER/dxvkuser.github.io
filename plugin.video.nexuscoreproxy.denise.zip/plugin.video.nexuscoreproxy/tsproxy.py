import asyncio
import urllib.request
import urllib.parse
import urllib.error
import socket
import time
import random
import threading
import struct
from concurrent.futures import ThreadPoolExecutor

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES MPEG-TS
# ─────────────────────────────────────────────────────────────────────────────
TS_PACKET_SIZE  = 188
TS_SYNC_BYTE    = 0x47

_NULL_HDR       = bytes([0x47, 0x1F, 0xFF, 0x10])
TS_NULL_PACKET  = _NULL_HDR + b'\xFF' * 184

NULL_PUMP_BURST    = TS_NULL_PACKET * 96
NULL_PUMP_INTERVAL = 0.065

# Mínimo de pacotes válidos antes de liberar para o Kodi
MIN_VALID_PACKETS = 7

# Triple-sync: confirma 0x47 em idx, idx+188, idx+376
SYNC_WINDOW_SIZE            = 3
MAX_SYNC_ATTEMPTS_PER_CYCLE = 3

HOST = "127.0.0.1"
PORT = 8010  # porta padrão — sobrescrita por _ensure_server_running() se em uso

# Faixa de portas candidatas (tentadas em ordem aleatória se a anterior falhar)
_PORT_CANDIDATES = list(range(8080, 8100))

# Stall: se nenhum payload válido chegar em X segundos → reconectar
STALL_TIMEOUT = 4.5

# Buffer de saída: MIN=1 envia imediatamente, MAX=2 fila mínima
# O Kodi gerencia o buffer internamente — não acumulamos no proxy
MIN_OUTPUT_BUFFER = 1
MAX_OUTPUT_BUFFER = 2

# Tail buffer para sutura: guarda os últimos N pacotes da sessão anterior
TAIL_BUFFER_PACKETS = 64   # 64 × 188 = ~12 KB

# IDR Gate: assinaturas de I-frame no payload PES
# H.264: 00 00 01 65 / H.265: 00 00 01 26 / MPEG2: 00 00 01 00
_IDR_SIGNATURES = (
    b'\x00\x00\x01\x65',   # H.264 IDR slice
    b'\x00\x00\x01\x26',   # H.265 IDR_W_RADL / IDR_N_LP
    b'\x00\x00\x01\x00',   # MPEG-2 picture start (I-frame)
)

# PTS: se o PTS não avançar além deste limiar em STALL_TIMEOUT → stall de PTS
PTS_STALL_THRESHOLD = 90_000   # 1 segundo em unidades de 90 kHz

# Adaptive chunk: tamanho inicial e limites
CHUNK_INITIAL = 65_536
CHUNK_MIN     = 16_384
CHUNK_MAX     = 131_072

# Whitelist de PIDs essenciais que nunca serão descartados
# 0x0000=PAT, 0x0001=CAT, 0x0011=SDT, 0x0012=EIT, 0x1FFF=null
_PID_WHITELIST_STATIC = {0x0000, 0x0001, 0x0011, 0x0012, 0x1FFF}

# Pool de threads para I/O bloqueante (urllib upstream)
_EXECUTOR = ThreadPoolExecutor(max_workers=32)

# ─────────────────────────────────────────────────────────────────────────────
#  Sessão ativa global — garante que só uma sessão de streaming esteja viva.
#  Ao chegar nova conexão, a sessão anterior é cancelada antes de iniciar.
# ─────────────────────────────────────────────────────────────────────────────
_active_session_task = None
_active_session_lock = None

def _get_session_lock():
    global _active_session_lock
    if _active_session_lock is None:
        _active_session_lock = asyncio.Lock()
    return _active_session_lock

# ─────────────────────────────────────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 9 — PID Filter / Whitelist dinâmica
#  Parseia PAT → PMT para descobrir PIDs de vídeo/áudio e descarta o resto.
# ─────────────────────────────────────────────────────────────────────────────
class PidFilter:
    """
    Aprende dinamicamente os PIDs de vídeo e áudio lendo PAT → PMT.
    Descarta PIDs privados/desconhecidos que CDNs injetam como lixo.
    Nunca descarta PIDs da whitelist estática (PAT, SDT, etc.).
    """
    def __init__(self):
        self._allowed = set(_PID_WHITELIST_STATIC)
        self._pmt_pids = set()
        self._learned = False
        self._pmt_buf = {}

    def reset(self):
        self._allowed  = set(_PID_WHITELIST_STATIC)
        self._pmt_pids = set()
        self._learned  = False
        self._pmt_buf  = {}

    def _parse_pat(self, payload):
        """Lê PAT e registra PID de cada PMT."""
        if len(payload) < 8:
            return
        sec_len = ((payload[1] & 0x0F) << 8) | payload[2]
        end = min(3 + sec_len - 4, len(payload))
        i = 8
        while i + 4 <= end:
            prog = (payload[i] << 8) | payload[i + 1]
            pid  = ((payload[i + 2] & 0x1F) << 8) | payload[i + 3]
            if prog != 0:
                self._pmt_pids.add(pid)
                self._allowed.add(pid)
            i += 4

    def _parse_pmt(self, pid, payload):
        """Lê PMT e registra PIDs de vídeo/áudio."""
        if len(payload) < 12:
            return
        sec_len  = ((payload[1] & 0x0F) << 8) | payload[2]
        prog_info_len = ((payload[10] & 0x0F) << 8) | payload[11]
        i = 12 + prog_info_len
        end = min(3 + sec_len - 4, len(payload))
        while i + 5 <= end:
            epid = ((payload[i + 1] & 0x1F) << 8) | payload[i + 2]
            es_info_len = ((payload[i + 3] & 0x0F) << 8) | payload[i + 4]
            self._allowed.add(epid)
            i += 5 + es_info_len
        self._learned = True

    def _accumulate_section(self, pid, pkt):
        """Acumula seção multi-pacote e retorna quando completa."""
        pusi   = (pkt[1] & 0x40) != 0
        afc    = (pkt[3] & 0x30) >> 4
        hdr    = 4
        if afc in (2, 3):
            hdr += 1 + pkt[4]
        if hdr >= TS_PACKET_SIZE:
            return None

        payload_data = bytes(pkt[hdr:])

        if pusi:
            ptr = payload_data[0]
            self._pmt_buf[pid] = bytearray(payload_data[1 + ptr:])
        else:
            if pid not in self._pmt_buf:
                return None
            self._pmt_buf[pid].extend(payload_data)

        if pid not in self._pmt_buf or len(self._pmt_buf[pid]) < 3:
            return None

        buf = self._pmt_buf[pid]
        sec_len = ((buf[1] & 0x0F) << 8) | buf[2]
        total   = 3 + sec_len
        if len(buf) >= total:
            result = bytes(buf[:total])
            del self._pmt_buf[pid]
            return result
        return None

    def filter(self, data):
        """
        Filtra pacotes por PID.
        PIDs não na whitelist são substituídos por null packets
        (manter alinhamento de 188 bytes).
        """
        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        out = bytearray()

        for i in range(n):
            off = i * TS_PACKET_SIZE
            pkt = mv[off: off + TS_PACKET_SIZE]

            if pkt[0] != TS_SYNC_BYTE:
                out.extend(pkt)
                continue

            pid = ((pkt[1] & 0x1F) << 8) | pkt[2]

            if pid == 0x0000:
                sec = self._accumulate_section(pid, pkt)
                if sec:
                    self._parse_pat(sec)
                out.extend(pkt)
                continue

            if pid in self._pmt_pids:
                sec = self._accumulate_section(pid, pkt)
                if sec:
                    self._parse_pmt(pid, sec)
                out.extend(pkt)
                continue

            if pid in self._allowed:
                out.extend(pkt)
                continue

            if self._learned:
                out.extend(TS_NULL_PACKET)
            else:
                out.extend(pkt)

        return out


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 5 — Tail Buffer (sutura entre sessões)
# ─────────────────────────────────────────────────────────────────────────────
class TailBuffer:
    """
    Guarda os últimos TAIL_BUFFER_PACKETS pacotes da sessão anterior.
    Na reconexão, localiza onde o novo stream 'encaixa' via rfind,
    descartando sobreposição e evitando repetição de conteúdo.
    """
    def __init__(self, capacity=TAIL_BUFFER_PACKETS):
        self._capacity = capacity
        self._buf = bytearray()

    def push(self, data):
        """Atualiza o tail com os dados mais recentes."""
        self._buf.extend(data)
        max_size = self._capacity * TS_PACKET_SIZE
        if len(self._buf) > max_size:
            del self._buf[: len(self._buf) - max_size]

    def find_stitch(self, new_data):
        """
        Retorna o índice em new_data a partir do qual o conteúdo é realmente
        novo (não presente no tail). Retorna 0 se não houver sobreposição.
        """
        if not self._buf or len(new_data) < TS_PACKET_SIZE:
            return 0

        fp_size = min(4 * TS_PACKET_SIZE, len(self._buf))
        fingerprint = bytes(self._buf[-fp_size:])

        idx = new_data.find(fingerprint)
        if idx != -1:
            skip = idx + fp_size
            skip = skip - (skip % TS_PACKET_SIZE)
            return min(skip, len(new_data))
        return 0

    def clear(self):
        self._buf.clear()


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 4 — PCR Restamping
# ─────────────────────────────────────────────────────────────────────────────
class PcrRestamper:
    """
    Recarimba o PCR após reconexão para continuar de onde parou,
    evitando descontinuidade de timestamp que o Kodi interpreta como corrupção.
    """
    def __init__(self):
        self._last_pcr = None
        self._offset   = 0
        self._active = False

    def reset(self, last_pcr):
        """Chamado no início de cada reconexão com o último PCR conhecido."""
        self._last_pcr = last_pcr
        self._offset   = 0
        self._active   = (last_pcr is not None)

    def _read_pcr(self, pkt, off):
        """Lê PCR base de um pacote TS. Retorna None se não houver PCR."""
        if pkt[off + 3] & 0x20 == 0:
            return None
        af_len = pkt[off + 4]
        if af_len < 6:
            return None
        flags = pkt[off + 5]
        if not (flags & 0x10):
            return None
        b = pkt[off + 6: off + 11]
        pcr_base = (b[0] << 25) | (b[1] << 17) | (b[2] << 9) | (b[3] << 1) | (b[4] >> 7)
        return pcr_base

    def _write_pcr(self, pkt, off, pcr_base):
        """Escreve PCR base (33 bits) no pacote."""
        pcr_base &= 0x1_FFFF_FFFF
        ext = 0
        pkt[off + 6]  = (pcr_base >> 25) & 0xFF
        pkt[off + 7]  = (pcr_base >> 17) & 0xFF
        pkt[off + 8]  = (pcr_base >>  9) & 0xFF
        pkt[off + 9]  = (pcr_base >>  1) & 0xFF
        pkt[off + 10] = ((pcr_base & 0x01) << 7) | 0x7E | ((ext >> 8) & 0x01)
        pkt[off + 11] = ext & 0xFF

    def stamp(self, data):
        """
        Percorre os pacotes e recarimba PCRs para manter continuidade.
        Só ativo após a primeira reconexão.
        """
        if not self._active:
            n  = len(data) // TS_PACKET_SIZE
            mv = memoryview(data)
            for i in range(n - 1, -1, -1):
                off = i * TS_PACKET_SIZE
                pcr = self._read_pcr(mv, off)
                if pcr is not None:
                    self._last_pcr = pcr
                    break
            return data

        n   = len(data) // TS_PACKET_SIZE
        out = bytearray(data)
        mv  = memoryview(data)
        first_new_pcr = None

        for i in range(n):
            off = i * TS_PACKET_SIZE
            pcr = self._read_pcr(mv, off)
            if pcr is None:
                continue

            if first_new_pcr is None:
                first_new_pcr = pcr
                if self._last_pcr is not None:
                    self._offset = (self._last_pcr - pcr + 3 * 3003) & 0x1_FFFF_FFFF

            new_pcr = (pcr + self._offset) & 0x1_FFFF_FFFF
            self._write_pcr(out, off, new_pcr)
            self._last_pcr = new_pcr

        return out

    @property
    def last_pcr(self):
        return self._last_pcr


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 6 — Detecção de PTS Stall
# ─────────────────────────────────────────────────────────────────────────────
class PtsMonitor:
    """
    Monitora se o PTS (Presentation Timestamp) continua avançando.
    Se o PTS parar de avançar por mais de STALL_TIMEOUT, indica stream
    congelado no CDN sem queda de conexão.
    """
    def __init__(self):
        self._last_pts  = None
        self._last_time = 0.0
        self._video_pid = None

    def reset(self):
        self._last_pts  = None
        self._last_time = 0.0

    def set_video_pid(self, pid):
        self._video_pid = pid

    def _extract_pts(self, pkt, off):
        """Extrai PTS do PES header se presente."""
        afc     = (pkt[off + 3] & 0x30) >> 4
        hdr_end = 4
        if afc in (2, 3):
            hdr_end += 1 + pkt[off + 4]
        if hdr_end + 9 >= TS_PACKET_SIZE:
            return None
        if (pkt[off + hdr_end]     != 0x00 or
            pkt[off + hdr_end + 1] != 0x00 or
            pkt[off + hdr_end + 2] != 0x01):
            return None
        pts_dts_flags = pkt[off + hdr_end + 7] >> 6
        if pts_dts_flags == 0:
            return None
        p = off + hdr_end + 9
        if p + 5 > TS_PACKET_SIZE:
            return None
        pts = (
            ((pkt[p]     & 0x0E) << 29) |
            ((pkt[p + 1]       ) << 22) |
            ((pkt[p + 2] & 0xFE) << 14) |
            ((pkt[p + 3]       ) <<  7) |
            ((pkt[p + 4] & 0xFE) >>  1)
        )
        return pts

    def feed(self, data):
        """
        Alimenta dados e retorna True se o PTS está progredindo normalmente.
        Retorna False se detectar stall de PTS.
        """
        if self._video_pid is None:
            return True

        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        now = time.monotonic()

        for i in range(n):
            off = i * TS_PACKET_SIZE
            if mv[off] != TS_SYNC_BYTE:
                continue
            pid = ((mv[off + 1] & 0x1F) << 8) | mv[off + 2]
            if pid != self._video_pid:
                continue
            pusi = (mv[off + 1] & 0x40) != 0
            if not pusi:
                continue
            pts = self._extract_pts(mv, off)
            if pts is None:
                continue

            if self._last_pts is None:
                self._last_pts  = pts
                self._last_time = now
                return True

            delta = (pts - self._last_pts) & 0x1_FFFF_FFFF
            if delta > PTS_STALL_THRESHOLD:
                self._last_pts  = pts
                self._last_time = now
            elif now - self._last_time > STALL_TIMEOUT:
                return False

        return True


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 7 — CC Rewriter (reescreve CC após reconexão)
# ─────────────────────────────────────────────────────────────────────────────
class CcRewriter:
    """
    Reescreve o Continuity Counter de cada PID para continuar
    sequencialmente após sutura, evitando que o Kodi descarte pacotes
    por erro de CC.
    """
    def __init__(self):
        self._cc_out = {}
        self._active = False

    def reset(self, cc_snapshot):
        self._cc_out = dict(cc_snapshot)
        self._active = True

    def rewrite(self, data):
        if not self._active:
            return data

        n   = len(data) // TS_PACKET_SIZE
        out = bytearray(data)

        for i in range(n):
            off = i * TS_PACKET_SIZE
            if out[off] != TS_SYNC_BYTE:
                continue

            pid = ((out[off + 1] & 0x1F) << 8) | out[off + 2]
            if pid == 0x1FFF:
                continue

            afc        = (out[off + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)

            if not has_payload:
                continue

            next_cc = (self._cc_out.get(pid, 15) + 1) & 0x0F
            self._cc_out[pid] = next_cc
            out[off + 3] = (out[off + 3] & 0xF0) | next_cc

        return out


# ─────────────────────────────────────────────────────────────────────────────
#  TsBuffer — Alinhamento, validação de CC, extração de PIDs de vídeo
# ─────────────────────────────────────────────────────────────────────────────
class TsBuffer:
    def __init__(self):
        self._buf           = bytearray()
        self._aligned       = False
        self._held          = bytearray()
        self._held_count    = 0
        self._cc_map        = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count   = 0
        self._total_packets = 0
        self.video_pid      = None

    def reset(self):
        self._buf.clear()
        self._aligned       = False
        self._held.clear()
        self._held_count    = 0
        self._cc_map.clear()
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count   = 0
        self._total_packets = 0

    @property
    def cc_snapshot(self):
        return dict(self._cc_map)

    def _find_sync(self, data):
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1

        idx = self._last_sync_idx if self._last_sync_idx < length else 0

        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                return -1

            self._sync_attempts += 1

            if idx + TS_PACKET_SIZE * SYNC_WINDOW_SIZE <= length:
                valid = all(
                    data[idx + TS_PACKET_SIZE * k] == TS_SYNC_BYTE
                    for k in range(1, SYNC_WINDOW_SIZE)
                )
                if valid:
                    self._last_sync_idx = idx
                    return idx
            elif idx + TS_PACKET_SIZE <= length:
                if data[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE:
                    self._last_sync_idx = idx
                    return idx

            idx += 1

        return -1

    def _validate_continuity(self, data):
        if not data:
            return data

        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        valid_packets = []
        severe_errors = 0

        for i in range(n):
            offset = i * TS_PACKET_SIZE

            if mv[offset] != TS_SYNC_BYTE:
                self._error_count += 1
                if self._error_count > 3:
                    self._aligned = False
                    return data[:offset]
                continue

            pid = ((mv[offset + 1] & 0x1F) << 8) | mv[offset + 2]

            if pid == 0x1FFF:
                valid_packets.append(i)
                continue

            cc          = mv[offset + 3] & 0x0F
            afc         = (mv[offset + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)

            if pid in self._cc_map and has_payload:
                expected_cc = (self._cc_map[pid] + 1) & 0x0F
                if cc == expected_cc:
                    self._cc_map[pid] = cc
                    valid_packets.append(i)
                elif cc == self._cc_map[pid]:
                    self._error_count += 1
                    continue
                else:
                    self._cc_map[pid] = cc
                    valid_packets.append(i)
                    self._error_count += 1
                    if self._error_count > 10:
                        severe_errors += 1
            else:
                self._cc_map[pid] = cc
                valid_packets.append(i)

        if severe_errors > 5:
            self._aligned = False
            return data[:valid_packets[0] * TS_PACKET_SIZE] if valid_packets else bytearray()

        if len(valid_packets) == n:
            return data

        result = bytearray()
        for idx in valid_packets:
            start = idx * TS_PACKET_SIZE
            result.extend(data[start:start + TS_PACKET_SIZE])
        return result

    def feed(self, raw):
        if raw:
            self._buf.extend(raw)

        if not self._aligned:
            self._sync_attempts = 0
            idx = self._find_sync(self._buf)
            if idx == -1:
                if len(self._buf) > TS_PACKET_SIZE * 100:
                    self._buf.clear()
                return b''
            if idx > 0:
                del self._buf[:idx]
            self._aligned = True

        buf_len = len(self._buf)
        usable  = buf_len - (buf_len % TS_PACKET_SIZE)
        if usable == 0:
            return b''

        payload = self._buf[:usable]
        del self._buf[:usable]

        payload = self._validate_continuity(payload)
        if not payload:
            return b''

        self._total_packets += len(payload) // TS_PACKET_SIZE

        if self._held_count < MIN_VALID_PACKETS:
            pkts = len(payload) // TS_PACKET_SIZE
            self._held.extend(payload)
            self._held_count += pkts
            if self._held_count >= MIN_VALID_PACKETS:
                out = bytes(self._held)
                self._held.clear()
                return out
            return b''

        return bytes(payload)


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 1 — IDR Gate
#  Detecta I-frame antes de liberar dados para o Kodi após reconexão.
# ─────────────────────────────────────────────────────────────────────────────
class IdrGate:
    """
    Bloqueia a saída de dados até encontrar um IDR frame (I-frame).
    Elimina artefatos visuais ("Grinch") quando o Kodi começa a
    decodificar no meio de um GOP.
    """
    def __init__(self):
        self._open   = False
        self._active = False

    def arm(self):
        """Armar o gate para a próxima reconexão."""
        self._open   = False
        self._active = True

    def disarm(self):
        """Desarmar (primeira conexão — não bloquear)."""
        self._open   = True
        self._active = False

    @property
    def is_open(self):
        return self._open

    def _has_idr(self, data):
        """Verifica se há assinatura de IDR no payload."""
        for sig in _IDR_SIGNATURES:
            if sig in data:
                return True
        return False

    def filter(self, data):
        """
        Filtra dados pelo gate.
        - Se desarmado (primeira conexão): passa tudo.
        - Se armado e IDR ainda não encontrado: descarta e busca IDR.
        - Quando encontra IDR: abre o gate e passa o restante do chunk.
        """
        if not self._active or self._open:
            return data

        if not self._has_idr(data):
            return b''

        self._open = True

        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        for i in range(n):
            off = i * TS_PACKET_SIZE
            chunk = bytes(mv[off: off + TS_PACKET_SIZE])
            if self._has_idr(chunk):
                return data[off:]

        return data


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 2 — Null keepalive paralelo (task asyncio)
# ─────────────────────────────────────────────────────────────────────────────
async def _keepalive_task(
    writer,
    stop_event,
    slow_event,
):
    """
    Injeta null packets enquanto o stream está lento (sem dados válidos).
    Ativado via slow_event; desativado via stop_event.
    """
    while not stop_event.is_set():
        await asyncio.sleep(NULL_PUMP_INTERVAL)
        if slow_event.is_set() and not stop_event.is_set():
            try:
                writer.write(NULL_PUMP_BURST)
                await writer.drain()
            except (BrokenPipeError, ConnectionResetError, OSError):
                stop_event.set()
                return


# ─────────────────────────────────────────────────────────────────────────────
#  HANDLER DE REDIRECT
# ─────────────────────────────────────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers): return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


# ─────────────────────────────────────────────────────────────────────────────
#  SESSION MANAGER
# ─────────────────────────────────────────────────────────────────────────────
class SessionManager:
    def __init__(self):
        self._opener     = None
        self._last_clean = 0.0

    def get_session(self):
        now = time.time()
        if self._opener is None or now - self._last_clean > 30:
            self._opener = urllib.request.build_opener(
                urllib.request.HTTPHandler(),
                urllib.request.HTTPSHandler(),
                NoRedirectHandler,
            )
            self._last_clean = now
        return self._opener


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS BLOQUEANTES (executor)
# ─────────────────────────────────────────────────────────────────────────────
def _resolve_url_sync(url, ua):
    curr = url
    for _ in range(5):
        try:
            parsed = urllib.parse.urlparse(curr)
            req = urllib.request.Request(curr, headers={
                'User-Agent': ua,
                'Accept':     '*/*',
                'Host':       parsed.netloc,
                'Connection': 'keep-alive',
            })
            opener = urllib.request.build_opener(NoRedirectHandler)
            with opener.open(req, timeout=10) as resp:
                if resp.code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get('Location', '')
                    if loc:
                        curr = urllib.parse.urljoin(curr, loc)
                        continue
            return curr
        except Exception:
            break
    return curr


def _open_upstream_sync(url, ua, original_url, session_mgr):
    parsed = urllib.parse.urlparse(url)
    req = urllib.request.Request(url, headers={
        'User-Agent':   ua,
        'Accept':       '*/*',
        'Host':         parsed.netloc,
        'Referer':      original_url,
        'Connection':   'keep-alive',
        'Icy-MetaData': '0',
    })
    return session_mgr.get_session().open(req, timeout=15)


def _read_chunk_sync(response, size):
    return response.read(size)


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 8 — Adaptive Chunk Size
# ─────────────────────────────────────────────────────────────────────────────
class AdaptiveChunk:
    """
    Ajusta o tamanho do chunk de leitura dinamicamente:
    - Stream estável (poucos erros) → chunk maior → menos overhead de syscall
    - Stream instável (muitos erros) → chunk menor → menor latência de reação
    """
    def __init__(self):
        self._size        = CHUNK_INITIAL
        self._ok_streak   = 0
        self._err_streak  = 0

    def reset(self):
        self._size       = CHUNK_INITIAL
        self._ok_streak  = 0
        self._err_streak = 0

    def on_success(self):
        self._err_streak = 0
        self._ok_streak += 1
        if self._ok_streak >= 10:
            self._size      = min(self._size * 2, CHUNK_MAX)
            self._ok_streak = 0

    def on_error(self):
        self._ok_streak  = 0
        self._err_streak += 1
        if self._err_streak >= 3:
            self._size       = max(self._size // 2, CHUNK_MIN)
            self._err_streak = 0

    @property
    def size(self):
        return self._size


# ─────────────────────────────────────────────────────────────────────────────
#  BACKOFF
# ─────────────────────────────────────────────────────────────────────────────
def _calculate_backoff(reconnect_num, error_type='network'):
    base_delays = {
        'network': 0.15,
        'http':    0.30,
        'timeout': 0.20,
        'reset':   0.10,
    }
    base = base_delays.get(error_type, 0.20)
    if reconnect_num <= 2:
        return base * reconnect_num
    elif reconnect_num <= 5:
        return base * (reconnect_num ** 1.2)
    else:
        return min(2.5, base * (reconnect_num ** 1.3))


# ─────────────────────────────────────────────────────────────────────────────
#  ASYNC HTTP SERVER PURO
# ─────────────────────────────────────────────────────────────────────────────
async def _parse_request(reader):
    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=10.0)
        request_line = request_line.decode('utf-8', errors='replace').strip()
        if not request_line:
            return None, None
        # CORREÇÃO: split() sem argumentos lida com múltiplos espaços ou tabs
        parts = request_line.split()
        if len(parts) < 2:
            return None, None
        method, path = parts[0], parts[1]
        while True:
            line = await asyncio.wait_for(reader.readline(), timeout=5.0)
            if line in (b'\r\n', b'\n', b''):
                break
            if not line:  # EOF inesperado, evita loop infinito
                break
        return method, path
    except Exception:
        return None, None


async def _send_headers(writer, status=200):
    headers = (
        f"HTTP/1.1 {status} OK\r\n"
        "Content-Type: video/mp2t\r\n"
        "Connection: keep-alive\r\n"
        "Cache-Control: no-cache, no-store, must-revalidate\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "\r\n"
    )
    writer.write(headers.encode())
    await writer.drain()


async def _safe_write(writer, data):
    if not data:
        return True
    try:
        writer.write(data)
        await writer.drain()
        return True
    except (BrokenPipeError, ConnectionResetError, OSError):
        return False


async def _null_pump(writer, cycles=4):
    for _ in range(cycles):
        if not await _safe_write(writer, NULL_PUMP_BURST):
            return False
        await asyncio.sleep(NULL_PUMP_INTERVAL)
    return True


async def _adaptive_null_pump(writer, reconnect_time):
    if reconnect_time < 0.5:
        return await _null_pump(writer, cycles=1)
    elif reconnect_time < 2.0:
        return await _null_pump(writer, cycles=2)
    else:
        return await _null_pump(writer, cycles=4)


# ─────────────────────────────────────────────────────────────────────────────
#  MELHORIA 3 — Token Renewal Proativo
# ─────────────────────────────────────────────────────────────────────────────
class TokenRenewer:
    """
    Monitora o tempo de vida médio do token e agenda renovação proativa
    antes da expiração, evitando erros 403/404 durante a reprodução.
    """
    def __init__(self):
        self._connect_times = []
        self._last_connect  = 0.0
        self._avg_lifetime  = 0.0
        self._renewal_ratio = 0.80

    def on_connect(self):
        now = time.monotonic()
        if self._last_connect > 0:
            lifetime = now - self._last_connect
            self._connect_times.append(lifetime)
            if len(self._connect_times) > 5:
                self._connect_times.pop(0)
            self._avg_lifetime = sum(self._connect_times) / len(self._connect_times)
        self._last_connect = now

    def should_renew(self):
        """Retorna True se está na hora de renovar proativamente."""
        if self._avg_lifetime < 10.0:
            return False
        elapsed = time.monotonic() - self._last_connect
        return elapsed >= self._avg_lifetime * self._renewal_ratio

    @property
    def avg_lifetime(self):
        return self._avg_lifetime


# ─────────────────────────────────────────────────────────────────────────────
#  CORE: STREAM LOOP ASYNC
#  Integra todas as 9 melhorias
# ─────────────────────────────────────────────────────────────────────────────
async def _stream_loop(writer, original_url):
    loop          = asyncio.get_event_loop()
    resolved_url  = original_url
    ua            = _pick_ua()
    reconnect_num = 0
    error_type    = 'network'

    # Componentes
    ts_buf      = TsBuffer()
    pid_filter  = PidFilter()
    tail_buf    = TailBuffer()
    pcr_stamp   = PcrRestamper()
    pts_mon     = PtsMonitor()
    cc_rewriter = CcRewriter()
    idr_gate    = IdrGate()
    chunk_ctrl  = AdaptiveChunk()
    token_ren   = TokenRenewer()
    session_mgr = SessionManager()

    # Buffer de saída
    output_q = asyncio.Queue(maxsize=MAX_OUTPUT_BUFFER)

    # Keepalive paralelo
    stop_event  = asyncio.Event()
    slow_event  = asyncio.Event()
    ka_task     = asyncio.ensure_future(
        _keepalive_task(writer, stop_event, slow_event)
    )

    # Primeira conexão: IDR gate desarmado (não bloquear)
    idr_gate.disarm()

    # CORREÇÃO: removido await asyncio.sleep(0.5) que causava timeout no Kodi
    # (o Kodi fecha a conexão se não receber dados em ~70-100ms após o GET).
    # Os headers já foram enviados por _run_handle antes de entrar aqui,
    # portanto não é necessário aguardar antes de iniciar o loop.

    try:
        while True:
            ts_buf.reset()
            pts_mon.reset()

            # Esvaziar fila de saída
            while not output_q.empty():
                try:
                    output_q.get_nowait()
                except asyncio.QueueEmpty:
                    break

            last_useful_payload = loop.time()
            response = None
            slow_event.clear()

            try:
                # Abrir conexão upstream
                response = await loop.run_in_executor(
                    _EXECUTOR,
                    _open_upstream_sync,
                    resolved_url, ua, original_url, session_mgr,
                )

                token_ren.on_connect()

                if reconnect_num == 0:
                    print(f"[ZeroSutura] Conectado → {ua[:25]}...")
                else:
                    print(f"[ZeroSutura] Reconectado #{reconnect_num} → {ua[:25]}...")
                    reconnect_num = max(0, reconnect_num - 2)

                first_payload_this_session = True

                # Loop de leitura
                while True:
                    # MELHORIA 3: renovação proativa de token
                    if token_ren.should_renew():
                        print(f"[+] Renovação proativa de token "
                              f"(vida média {token_ren.avg_lifetime:.0f}s)")
                        try:
                            new_url = await loop.run_in_executor(
                                _EXECUTOR, _resolve_url_sync, original_url, ua,
                            )
                            if new_url != resolved_url:
                                resolved_url = new_url
                        except Exception:
                            pass
                        token_ren.on_connect()

                    # MELHORIA 8: chunk adaptativo
                    raw = await loop.run_in_executor(
                        _EXECUTOR,
                        _read_chunk_sync,
                        response, chunk_ctrl.size,
                    )

                    if not raw:
                        break

                    chunk_ctrl.on_success()
                    payload = ts_buf.feed(raw)

                    if not payload:
                        slow_event.set()
                        if loop.time() - last_useful_payload > STALL_TIMEOUT:
                            print("[!] Stream stall detectado - forçando reconexão")
                            break
                        continue

                    slow_event.clear()
                    last_useful_payload = loop.time()

                    ba = bytearray(payload)

                    # MELHORIA 5: sutura na primeira chegada de dados
                    if first_payload_this_session and reconnect_num == 0:
                        first_payload_this_session = False
                    elif first_payload_this_session:
                        first_payload_this_session = False
                        skip = tail_buf.find_stitch(ba)
                        if skip > 0:
                            print(f"[~] Sutura: descartando {skip // TS_PACKET_SIZE} "
                                  f"pacotes sobrepostos")
                            ba = ba[skip:]
                        if not ba:
                            continue

                    # MELHORIA 9: filtro de PID
                    ba = pid_filter.filter(ba)
                    if not ba:
                        continue

                    # MELHORIA 4: PCR restamping
                    ba = pcr_stamp.stamp(ba)

                    # MELHORIA 7: CC rewrite (só após reconexão)
                    ba = cc_rewriter.rewrite(ba)

                    # MELHORIA 6: detecção de PTS stall
                    if ts_buf.video_pid is not None:
                        pts_mon.set_video_pid(ts_buf.video_pid)
                    if not pts_mon.feed(ba):
                        print("[!] PTS stall detectado - forçando reconexão")
                        break

                    payload_out = bytes(ba)

                    # MELHORIA 1: IDR gate
                    payload_out = idr_gate.filter(payload_out)
                    if not payload_out:
                        continue

                    # Atualizar tail buffer
                    tail_buf.push(payload_out)

                    # Enfileirar para saída
                    try:
                        output_q.put_nowait(payload_out)
                    except asyncio.QueueFull:
                        pass

                    # Enviar imediatamente — MIN_OUTPUT_BUFFER=1 garante que
                    # cada chunk é despachado sem acúmulo no proxy.
                    # O Kodi gerencia o buffer internamente.
                    while output_q.qsize() >= MIN_OUTPUT_BUFFER:
                        try:
                            out = output_q.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                        if not await _safe_write(writer, out):
                            print("[ZeroSutura] Kodi encerrou a conexão.")
                            stop_event.set()
                            try:
                                response.close()
                            except Exception:
                                pass
                            return

            except urllib.error.HTTPError as e:
                print(f"[!] HTTP {e.code} #{reconnect_num}")
                error_type = 'http'
                chunk_ctrl.on_error()
            except urllib.error.URLError as e:
                print(f"[!] URLError #{reconnect_num}: {e.reason}")
                reason = str(e.reason).lower()
                error_type = ('timeout' if 'timeout' in reason
                              else 'reset' if 'reset' in reason
                              else 'network')
                chunk_ctrl.on_error()
            except TimeoutError:
                print(f"[!] Timeout #{reconnect_num}")
                error_type = 'timeout'
                chunk_ctrl.on_error()
            except ConnectionResetError:
                print(f"[!] Connection reset #{reconnect_num}")
                error_type = 'reset'
                chunk_ctrl.on_error()
            except BrokenPipeError:
                stop_event.set()
                return
            except OSError as e:
                print(f"[!] OSError #{reconnect_num}: {e}")
                error_type = 'network'
                chunk_ctrl.on_error()
            except Exception as e:
                print(f"[!] Erro #{reconnect_num}: {type(e).__name__}: {e}")
                error_type = 'network'
                chunk_ctrl.on_error()
            finally:
                if response is not None:
                    try:
                        response.close()
                    except Exception:
                        pass

            # ── Preparar reconexão ─────────────────────────────────────────
            last_pcr    = pcr_stamp.last_pcr
            cc_snapshot = ts_buf.cc_snapshot

            reconnect_num += 1
            ua = _pick_ua()

            idr_gate.arm()
            pcr_stamp.reset(last_pcr)
            cc_rewriter.reset(cc_snapshot)

            backoff = _calculate_backoff(reconnect_num, error_type)

            slow_event.set()
            if not await _adaptive_null_pump(writer, reconnect_time=backoff):
                stop_event.set()
                return

            extra_cycles = int(backoff / NULL_PUMP_INTERVAL) + 1
            if not await _null_pump(writer, cycles=extra_cycles):
                stop_event.set()
                return
            slow_event.clear()

            try:
                new_url = await loop.run_in_executor(
                    _EXECUTOR, _resolve_url_sync, original_url, ua,
                )
                if new_url != resolved_url:
                    resolved_url = new_url
                    print(f"[+] Token atualizado #{reconnect_num}")
            except Exception:
                pass

    finally:
        stop_event.set()
        try:
            await ka_task
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  ZeroSuturaProxy — handler de conexão (mantém o nome original)
# ─────────────────────────────────────────────────────────────────────────────
class ZeroSuturaProxy:
    async def handle(self, reader, writer):
        global _active_session_task
        peer = writer.get_extra_info('peername', ('?', 0))
        try:
            method, path = await _parse_request(reader)

            # CORREÇÃO: Fechar silenciosamente em vez de enviar HTTP 400
            # para requisições vazias/malformadas, impedindo que o Kodi
            # cacheie o erro e bloqueie a reprodução do canal.
            if not method or not path:
                writer.close()
                return

            # CORREÇÃO: O Kodi frequentemente envia requisições HEAD antes do GET
            # para validar a conexão. Se recusarmos o HEAD com 400, ele falha.
            if method.upper() not in ('GET', 'HEAD'):
                writer.write(b"HTTP/1.1 405 Method Not Allowed\r\n\r\n")
                await writer.drain()
                return

            query        = urllib.parse.urlparse(path).query
            params       = urllib.parse.parse_qs(query)
            original_url = params.get('url', [None])[0]

            if not original_url:
                writer.close()
                return

            # Responder adequadamente ao HEAD request apenas com os headers
            if method.upper() == 'HEAD':
                await _send_headers(writer)
                return

            # ── Encerrar sessão anterior antes de iniciar nova ────────────────
            async with _get_session_lock():
                old_task = _active_session_task
                if old_task is not None and not old_task.done():
                    print("[ZeroSutura] Nova conexão detectada — encerrando sessão anterior.")
                    old_task.cancel()
                    try:
                        await asyncio.wait_for(asyncio.shield(old_task), timeout=2.0)
                    except (asyncio.CancelledError, asyncio.TimeoutError):
                        pass

                loop = asyncio.get_event_loop()
                my_task = loop.create_task(_run_handle(writer, original_url))
                _active_session_task = my_task

            await my_task

        except (BrokenPipeError, ConnectionResetError, asyncio.CancelledError):
            pass
        except Exception as e:
            print(f"[ZeroSutura] handle error {peer}: {type(e).__name__}: {e}")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass


async def _run_handle(writer, original_url):
    """Wrapper da sessão de streaming — separado para ser cancelável."""
    try:
        # Passo 1: headers HTTP imediatamente — o Kodi fecha em ~70-100ms
        # se não receber nada (erro 52 / "Server returned nothing").
        await _send_headers(writer)

        # Passo 2: primeiro burst de null packets SEM sleep — garante que
        # o Kodi recebe dados imediatamente enquanto o upstream ainda está
        # sendo aberto no executor (operação bloqueante ~100-400ms).
        writer.write(NULL_PUMP_BURST)
        await writer.drain()

        # Passo 3: mais um ciclo de keepalive para cobrir o tempo de conexão
        # com o CDN antes de entrar no stream loop.
        await _null_pump(writer, cycles=1)

        await _stream_loop(writer, original_url)
    except asyncio.CancelledError:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  SERVIDOR ASYNC
# ─────────────────────────────────────────────────────────────────────────────
async def _run_server():
    proxy = ZeroSuturaProxy()

    async def _conn(r, w):
        await proxy.handle(r, w)

    server = await asyncio.start_server(
        _conn, HOST, PORT,
        reuse_address=True,
        backlog=256,
    )
    print(f"[ZeroSutura Async] Proxy rodando em http://{HOST}:{PORT}/stream?url=<URL>")
    async with server:
        await server.serve_forever()


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

# Referência global à thread do servidor — usada para detectar thread pendurada
_server_thread = None


def _port_is_available(port):
    """Retorna True se a porta está livre para bind."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((HOST, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _port_accepts_connection(port):
    """Retorna True se já há algo escutando e aceitando conexões na porta."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5)
    try:
        s.connect((HOST, port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def _pick_free_port():
    """
    Retorna uma porta livre na faixa _PORT_CANDIDATES.
    Embaralha a lista para distribuir aleatoriamente e evitar colisão
    entre múltiplas instâncias do addon iniciando simultaneamente.
    Retorna None se todas estiverem ocupadas.
    """
    candidates = list(_PORT_CANDIDATES)
    random.shuffle(candidates)
    for p in candidates:
        if _port_is_available(p):
            return p
    # Fallback: pedir ao SO uma porta efêmera livre
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((HOST, 0))
        p = s.getsockname()[1]
        s.close()
        return p
    except OSError:
        return None


def _ensure_server_running():
    """
    Garante que o servidor proxy está rodando e retorna a porta ativa.

    Fluxo:
    1. Se PORT atual já aceita conexões → retorna PORT (servidor vivo).
    2. Se a thread anterior está pendurada (viva mas porta não responde)
       → detecta e sobe nova thread em porta livre.
    3. Se nunca foi iniciado → escolhe porta livre e inicia.
    4. Após start_server, valida com connect TCP real antes de retornar.
    """
    global PORT, _server_thread

    # ── 1. Servidor já está vivo na porta atual ───────────────────────────────
    if _port_accepts_connection(PORT):
        return PORT

    # ── 2. Thread pendurada: está viva mas não serve conexões ─────────────────
    if _server_thread is not None and _server_thread.is_alive():
        print(f"[ZeroSutura] Thread anterior pendurada na porta {PORT} "
              f"— subindo nova instância em porta diferente.")
        # Não podemos matar a thread, mas podemos usar outra porta.
        # Remover PORT atual dos candidatos para não tentar a mesma porta.
        candidates_sem_atual = [p for p in _PORT_CANDIDATES if p != PORT]
        nova_porta = None
        random.shuffle(candidates_sem_atual)
        for p in candidates_sem_atual:
            if _port_is_available(p):
                nova_porta = p
                break
        if nova_porta is None:
            nova_porta = _pick_free_port()
        if nova_porta is None:
            print("[ZeroSutura] ERRO: nenhuma porta livre disponível!")
            return PORT
        PORT = nova_porta

    # ── 3. Primeira inicialização ou porta mudou ───────────────────────────────
    else:
        nova_porta = _pick_free_port()
        if nova_porta is None:
            print("[ZeroSutura] ERRO: nenhuma porta livre disponível!")
            return PORT
        PORT = nova_porta

    ready  = threading.Event()
    failed = threading.Event()

    def _thread():
        # Criar um NOVO event loop exclusivo para esta thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # Limpar referência obsoleta de "running loop" que pode ter
        # vazado do thread pai via threading.local() no ambiente Kodi/Android.
        try:
            asyncio._set_running_loop(None)
        except (AttributeError, TypeError):
            pass

        async def _start():
            proxy = ZeroSuturaProxy()

            async def _conn(r, w):
                await proxy.handle(r, w)

            try:
                server = await asyncio.start_server(
                    _conn, HOST, PORT,
                    reuse_address=True,
                    backlog=256,
                )
            except OSError as e:
                print(f"[ZeroSutura] Falha ao bind na porta {PORT}: {e}")
                failed.set()
                ready.set()
                return

            print(f"[ZeroSutura] Servidor bind OK na porta {PORT}")
            ready.set()
            async with server:
                await server.serve_forever()

        try:
            loop.run_until_complete(_start())
        except Exception as e:
            print(f"[ZeroSutura] Server thread error: {e}")
            failed.set()
            ready.set()

    t = threading.Thread(target=_thread, daemon=True, name=f"ZeroSutura-{PORT}")
    t.start()
    _server_thread = t

    # Aguardar o servidor sinalizar que fez o bind
    ready.wait(timeout=5.0)

    if failed.is_set():
        print(f"[ZeroSutura] Bind falhou na porta {PORT}")
        return PORT

    # ── 4. Validação TCP real: confirmar que o servidor aceita conexões ────────
    # O asyncio.start_server() pode retornar antes do socket estar
    # completamente pronto para accept() em Android/Termux.
    # Tentamos até 20 vezes com 50ms de intervalo (total até 1s).
    for attempt in range(20):
        if _port_accepts_connection(PORT):
            print(f"[ZeroSutura] Porta {PORT} validada após {attempt + 1} tentativa(s).")
            return PORT
        time.sleep(0.05)

    print(f"[ZeroSutura] AVISO: porta {PORT} não validou após 1s — retornando mesmo assim.")
    return PORT


if __name__ == "__main__":
    try:
        asyncio.run(_run_server())
    except KeyboardInterrupt:
        print("[ZeroSutura] Encerrado.")