# -*- coding: utf-8 -*-

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import os
from resources.lib.api import XtreamAPI

# Importa HLSProxy
from proxy import HLSProxyAddon

# Importa o cliente requests do netunblock.
from doh_client import requests

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADULT_KEYWORDS = ['adult', 'xxx', '+18', 'private']

REMOTE_MENU_URL = "https://raw.githubusercontent.com/DXVKUSER/SRTORRENT/refs/heads/main/testando.json"

def get_setting(setting_id):
    return ADDON.getSetting(setting_id)

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_dir(name, query, icon='https://i.imgur.com/FBK5qFX.png', fanart='https://i.imgur.com/KMlkWXm.jpeg', is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
    url = build_url(query)
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def get_remote_menu():
    try:
        xbmc.log(f"[ADDON] Baixando menu remoto: {REMOTE_MENU_URL}", level=xbmc.LOGINFO)
        response = requests.get(REMOTE_MENU_URL, timeout=15)
        response.raise_for_status()
        data = json.loads(response.text)
        if not isinstance(data, list) or not data:
            xbmc.log("[ADDON] Menu remoto vazio ou inválido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro", "Menu remoto vazio ou inválido.")
            return []
        return data
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro ao baixar menu remoto: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Conexão", "Não foi possível baixar o menu remoto.")
        return []
    except (ValueError, json.JSONDecodeError):
        xbmc.log("[ADDON] Menu remoto não é JSON válido.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Menu", "O arquivo JSON remoto está inválido.")
        return []

def servers_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Servidores[/COLOR]")
    menu = get_remote_menu()
    for categoria in menu:
        cat_name = categoria.get("categoria", "Sem Nome")
        icon = categoria.get("icon", "https://i.imgur.com/SJITntP.png")
        fanart = categoria.get("fanart", "https://i.imgur.com/gaaKYUP.jpeg")
        add_dir(f"[COLORwhite]{cat_name}[/COLOR]", {'action': 'category_menu', 'category_name': cat_name}, icon=icon, fanart=fanart, is_folder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def category_menu(category_name):
    menu = get_remote_menu()
    category = next((c for c in menu if c.get("categoria") == category_name), None)
    if not category:
        xbmcgui.Dialog().ok("Erro", f"[COLORwhite]Categoria '{category_name}' não encontrada[/COLOR].")
        return

    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[COLORwhite]{category_name}[/COLOR]")
    servidores = category.get("servidores", [])
    for i, server in enumerate(servidores):
        name = server.get("nome", "Servidor")
        imagem = server.get("icon", "https://i.imgur.com/SJITntP.png")
        add_dir(f"[COLORwhite]{name}[/COLOR]", {'action': 'server_home', 'category_name': category_name, 'server_index': i}, icon=imagem, fanart=imagem, is_folder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def main_menu(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Menu Principal[/COLOR]")
    add_dir("[COLORwhite]TV[/COLOR]", {'action': 'list_live_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("[COLORwhite]Filmes[/COLOR]", {'action': 'list_vod_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("[COLORwhite]Séries[/COLOR]", {'action': 'list_series_categories', 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_live_categories(api, server, username, password, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Categorias Ao Vivo[/COLOR]")
    categories = api.get_live_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    
    adult_filter_enabled = get_setting('adult_filter') == 'true'

    filtered_categories = []
    for category in categories:
        cat_name = category['category_name']
        if adult_filter_enabled and any(keyword in cat_name.lower() for keyword in ADULT_KEYWORDS):
            continue
        filtered_categories.append(category)

    for category in filtered_categories:
        add_dir(f"[COLORwhite]{category['category_name']}[/COLOR]", {'action': 'list_live_streams', 'category_id': category['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_live_streams(api, category_id, server, username, password, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Canais Ao Vivo[/COLOR]")
    streams = api.get_live_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    
    adult_filter_enabled = get_setting('adult_filter') == 'true'

    for stream in streams:
        title = stream.get('name', 'Sem Título')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        stream_desc = stream.get('stream_type', '')

        if adult_filter_enabled and any(keyword in title.lower() for keyword in ADULT_KEYWORDS):
            continue

        li = xbmcgui.ListItem(label=f"[COLORwhite]{title}[/COLOR]")
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": title, "plot": f"Canal: {title}\nTipo: {stream_desc}", "genre": "Live"})

        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'live', 'category_name': category_name, 'server_index': server_index})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_categories(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Categorias Filmes (VOD)[/COLOR]")
    categories = api.get_vod_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    adult_filter_enabled = get_setting('adult_filter') == 'true'

    filtered_categories = []
    for category in categories:
        cat_name = category['category_name']
        if adult_filter_enabled and any(keyword in cat_name.lower() for keyword in ADULT_KEYWORDS):
            continue
        filtered_categories.append(category)

    for category in filtered_categories:
        add_dir(f"[COLORwhite]{category['category_name']}[/COLOR]", {'action': 'list_vod_streams', 'category_id': category['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_streams(api, category_id, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Filmes (VOD)[/COLOR]")
    streams = api.get_vod_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    
    adult_filter_enabled = get_setting('adult_filter') == 'true'

    for stream in streams:
        title = stream.get('name', 'Sem Título')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        stream_desc = stream.get('stream_type', '')

        if adult_filter_enabled and any(keyword in title.lower() for keyword in ADULT_KEYWORDS):
            continue

        li = xbmcgui.ListItem(label=f"[COLORwhite]{title}[/COLOR]")
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": title, "plot": f"Filme: {title}\nTipo: {stream_desc}", "genre": "VOD"})

        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'category_name': category_name, 'server_index': server_index})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_series_categories(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Categorias Séries[/COLOR]")
    categories = api.get_series_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    adult_filter_enabled = get_setting('adult_filter') == 'true'

    filtered_categories = []
    for category in categories:
        cat_name = category['category_name']
        if adult_filter_enabled and any(keyword in cat_name.lower() for keyword in ADULT_KEYWORDS):
            continue
        filtered_categories.append(category)

    for category in filtered_categories:
        add_dir(f"[COLORwhite]{category['category_name']}[/COLOR]", {'action': 'list_series', 'category_id': category['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series(api, category_id, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Séries[/COLOR]")
    series_list = api.get_series(category_id)
    if series_list is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    adult_filter_enabled = get_setting('adult_filter') == 'true'

    for series in series_list:
        title = series.get('name', 'Sem Título')
        series_id = series.get('series_id')
        series_icon = series.get('cover', 'DefaultVideo.png')

        if adult_filter_enabled and any(keyword in title.lower() for keyword in ADULT_KEYWORDS):
            continue

        add_dir(f"[COLORwhite]{title}[/COLOR]", {'action': 'list_episodes', 'series_id': series_id, 'category_name': category_name, 'server_index': server_index}, series_icon, series_icon)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_episodes(api, series_id, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Episódios[/COLOR]")
    series_info = api.get_series_info(series_id)
    if series_info is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes_by_season = series_info.get('episodes', {})
    for season_number, episodes in episodes_by_season.items():
        season_title = f"[COLORwhite]Temporada {season_number}[/COLOR]"
        add_dir(season_title, {'action': 'list_episodes_for_season', 'series_id': series_id, 'season_number': season_number, 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes_for_season(api, series_id, season_number, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[COLORwhite]Episódios[/COLOR]")
    series_info = api.get_series_info(series_id)
    if series_info is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes = series_info.get('episodes', {}).get(season_number, [])
    
    adult_filter_enabled = get_setting('adult_filter') == 'true'
    
    for episode in episodes:
        episode_num = episode.get('episode_num')
        episode_title = episode.get('title', f"Episódio {episode_num}")
        episode_id = episode.get('id')
        episode_icon = episode.get('info', {}).get('cover', 'DefaultVideo.png')

        if adult_filter_enabled and any(keyword in episode_title.lower() for keyword in ADULT_KEYWORDS):
            continue

        li = xbmcgui.ListItem(label=f"[COLORwhite]{episode_title}[/COLOR]")
        li.setArt({'thumb': episode_icon, 'icon': episode_icon})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": episode_title, "genre": "Series"})

        url = build_url({'action': 'play_stream', 'stream_id': episode_id, 'stream_type': 'series', 'category_name': category_name, 'server_index': server_index})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def resolve_and_play_stream(api, stream_id, stream_type):
    stream_url = None
    if stream_type == 'live':
        stream_url = api.get_live_stream_url(stream_id)
        if stream_url:
            proxy_addon = HLSProxyAddon(ADDON_HANDLE)
            proxy_addon.play_stream(stream_url)
        else:
            xbmcgui.Dialog().ok("Erro", "Não foi possível obter a URL do stream ao vivo.")
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)
    elif stream_type == 'vod':
        stream_url = api.get_vod_stream_url(stream_id)
        if stream_url:
            play_direct_stream(stream_url)
        else:
            xbmcgui.Dialog().ok("Erro", "Não foi possível obter a URL do filme.")
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)
    elif stream_type == 'series':
        stream_url = api.get_series_stream_url(stream_id)
        if stream_url:
            play_direct_stream(stream_url)
        else:
            xbmcgui.Dialog().ok("Erro", "Não foi possível obter a URL do episódio.")
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)
    else:
        xbmcgui.Dialog().ok("Erro", "Tipo de stream desconhecido.")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)

def play_direct_stream(url):
    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True, listitem=li)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if action is None:
        servers_menu()
        return

    if action == 'category_menu':
        category_menu(params.get('category_name'))
        return

    category_name = params.get('category_name')
    server_index = params.get('server_index')

    if not category_name or server_index is None:
        xbmcgui.Dialog().ok("Erro", "Servidor não selecionado.")
        return

    try:
        menu = get_remote_menu()
        category = next((c for c in menu if c.get("categoria") == category_name), None)
        if not category:
            xbmcgui.Dialog().ok("Erro", "Categoria do servidor não encontrada no menu remoto.")
            return

        server_info = category['servidores'][int(server_index)]
        server = server_info.get('dns')
        username = server_info.get('username')
        password = server_info.get('password')

        if not all([server, username, password]):
            xbmcgui.Dialog().ok("Erro", "Credenciais inválidas para o servidor.")
            return
    except (IndexError, ValueError):
        xbmcgui.Dialog().ok("Erro", "Índice de servidor inválido.")
        return

    api = XtreamAPI(server, username, password)

    if action == 'server_home':
        main_menu(api, category_name, server_index)
    elif action == 'list_live_categories':
        list_live_categories(api, server, username, password, category_name, server_index)
    elif action == 'list_live_streams':
        list_live_streams(api, params['category_id'], server, username, password, category_name, server_index)
    elif action == 'list_vod_categories':
        list_vod_categories(api, category_name, server_index)
    elif action == 'list_vod_streams':
        list_vod_streams(api, params['category_id'], category_name, server_index)
    elif action == 'list_series_categories':
        list_series_categories(api, category_name, server_index)
    elif action == 'list_series':
        list_series(api, params['category_id'], category_name, server_index)
    elif action == 'list_episodes':
        list_episodes(api, params['series_id'], category_name, server_index)
    elif action == 'list_episodes_for_season':
        list_episodes_for_season(api, params['series_id'], params['season_number'], category_name, server_index)
    elif action == 'play_stream':
        resolve_and_play_stream(api, params['stream_id'], params['stream_type'])
    elif action == 'play_direct':
        play_direct_stream(params['url'])

if __name__ == '__main__':
    router(sys.argv[2][1:])