# -*- coding: utf-8 -*-
import os
import re
import sys
import time
import random
import socket
import threading
import base64
import binascii
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, quote, unquote, parse_qs, urljoin

import xbmc
import xbmcgui
import xbmcplugin

try:
    import requests
    from requests.adapters import HTTPAdapter
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

# --- CONFIGURAÇÃO HÍBRIDA (Estável + Manjaro Fix) ---
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
]

CONFIG = {
    "HOST": "127.0.0.1",
    "PORT": None,
    "MAX_REDIRECTS": 5,
    "RETRY_ATTEMPTS": 2,         # Mantido baixo como na versão estável
    "TS_CHUNK_SIZE": 65536,      # 64KB
    "CONNECT_TIMEOUT": 10,
    "READ_TIMEOUT": 30,
    "SESSION_TIMEOUT": 60
}

# Regex pré-compilada para performance
RE_URI_KEY = re.compile(r'URI="([^"]+)"')

# --- FUNÇÕES BASE64 (FIX MANJARRO) ---
def encode_url(url):
    """Codifica a URL em Base64 para uso no caminho."""
    return base64.urlsafe_b64encode(url.encode('utf-8')).decode('utf-8').rstrip('=')

def decode_url(encoded):
    """Decodifica a URL Base64."""
    padding = 4 - len(encoded) % 4
    if padding != 4:
        encoded += '=' * padding
    try:
        return base64.urlsafe_b64decode(encoded).decode('utf-8')
    except (binascii.Error, ValueError):
        return None

class SessionManager:
    def __init__(self):
        self._session = None
        self._lock = threading.Lock()
        self._last_used = 0
    
    def get_session(self):
        with self._lock:
            if (self._session is None or 
                time.time() - self._last_used > CONFIG['SESSION_TIMEOUT']):
                
                if self._session:
                    try:
                        self._session.close()
                    except:
                        pass
                
                self._session = requests.Session()
                self._session.verify = False
                
                # Pool otimizado para uso simples
                adapter = HTTPAdapter(
                    pool_connections=5, 
                    pool_maxsize=10,
                    max_retries=0 
                )
                
                self._session.mount('http://', adapter)
                self._session.mount('https://', adapter)
                
                self._session.headers.update({
                    'User-Agent': random.choice(USER_AGENTS),
                    'Accept': '*/*',
                })
            
            self._last_used = time.time()
            return self._session
    
    def close(self):
        with self._lock:
            if self._session:
                try:
                    self._session.close()
                except:
                    pass
                self._session = None

session_manager = SessionManager()

class HLSProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1" # 1.1 é mais eficiente que 1.0 para localhost
    
    def log_message(self, format, *args):
        # Log apenas erros
        if '200' not in args[1] and '304' not in args[1]:
            xbmc.log(f"[HLSProxy] {format % args}", xbmc.LOGWARNING)
    
    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            path_only = parsed.path
            
            # --- MANJARRO FIX: ROTEAMENTO POR CAMINHO ---
            target_url = None
            handler_func = None
            
            if path_only.startswith('/playlist/'):
                token = path_only[len('/playlist/'):].replace('.m3u8', '')
                target_url = decode_url(token)
                handler_func = self.handle_m3u8
                
            elif path_only.startswith('/segment/'):
                token = path_only[len('/segment/'):].replace('.ts', '')
                target_url = decode_url(token)
                handler_func = self.handle_ts
                
            elif path_only.startswith('/key/'):
                token = path_only[len('/key/'):].split('.')[0]
                target_url = decode_url(token)
                handler_func = self.handle_key
            
            # Roteamento de compatibilidade (Query String - Fallback)
            else:
                qs = parse_qs(parsed.query)
                url = unquote(qs.get('url', [''])[0])
                parent = unquote(qs.get('parent', [''])[0]) or url
                if url:
                    target_url = url
                    # Detecta tipo pela query string antiga se necessário
                    if 'm3u8' in path_only:
                        handler_func = lambda u: self.handle_m3u8(u, parent)
                    elif 'ts' in path_only or 'key' in path_only:
                        handler_func = lambda u: self.handle_ts(u, parent) # Simplificado
            
            if not target_url or not handler_func:
                self.send_error(404, "Invalid Path")
                return
            
            handler_func(target_url)
                
        except Exception as e:
            xbmc.log(f"[HLSProxy] Erro: {str(e)}", xbmc.LOGERROR)
            try:
                self.send_error(500, "Internal Error")
            except:
                pass
    
    def _fetch_url(self, url, referer=None, stream=False, max_retries=2):
        """Fetch simplificado (Zero Overhead)"""
        session = session_manager.get_session()
        
        for attempt in range(max_retries):
            try:
                headers = {
                    'Host': urlparse(url).netloc,
                    'Referer': referer or f"{urlparse(url).scheme}://{urlparse(url).netloc}/"
                }
                
                resp = session.get(
                    url,
                    headers=headers,
                    timeout=(CONFIG['CONNECT_TIMEOUT'], CONFIG['READ_TIMEOUT']),
                    stream=stream,
                    allow_redirects=True
                )
                
                if resp.status_code == 200:
                    return resp
                elif resp.status_code in (301, 302, 307, 308):
                    new_url = resp.headers.get('Location')
                    if new_url:
                        url = urljoin(url, new_url)
                        continue
                    else:
                        return None
                else:
                    resp.close()
                    if attempt < max_retries - 1:
                        time.sleep(0.1 * (attempt + 1))
                    continue
                    
            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(0.1 * (attempt + 1))
                    session_manager.close()
                    session = session_manager.get_session()
                else:
                    return None
        return None
    
    def handle_m3u8(self, url, parent=None):
        # Lógica Estável: Sem Prefetch, Sem Cache
        resp = self._fetch_url(url, referer=parent, stream=False)
        if not resp:
            self.send_error(502, "Bad Gateway")
            return
        
        try:
            final_url = resp.url
            base_url = final_url.rsplit('/', 1)[0] + '/'
            content = resp.text
            
            lines = content.splitlines()
            output_lines = []
            
            proxy_host = f"http://{self.headers.get('Host', CONFIG['HOST'])}"
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                if line.startswith('#'):
                    if line.startswith('#EXT-X-KEY'):
                        match = RE_URI_KEY.search(line)
                        if match:
                            key_url = match.group(1)
                            abs_key_url = urljoin(base_url, key_url)
                            # MANJARRO FIX: Reescreve URI para Path Parameter
                            proxy_key = f'{proxy_host}/key/{encode_url(abs_key_url)}.key'
                            line = line.replace(f'URI="{key_url}"', f'URI="{proxy_key}"')
                    
                    output_lines.append(line)
                    continue
                
                abs_url = urljoin(base_url, line)
                
                if '.m3u8' in line:
                    # MANJARRO FIX: Reescreve URL para /playlist/BASE64.m3u8
                    proxy_url = f'{proxy_host}/playlist/{encode_url(abs_url)}.m3u8'
                else:
                    # MANJARRO FIX: Reescreve URL para /segment/BASE64.ts
                    proxy_url = f'{proxy_host}/segment/{encode_url(abs_url)}.ts'
                
                output_lines.append(proxy_url)
            
            output = '\n'.join(output_lines) + '\n'
            data = output.encode('utf-8')
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'close') # Fecha após enviar a playlist
            self.end_headers()
            self.wfile.write(data)
            self.wfile.flush()
            
        except Exception as e:
            xbmc.log(f"[HLSProxy] Erro m3u8: {e}", xbmc.LOGERROR)
            self.send_error(500, "Processing Error")
        finally:
            resp.close()
    
    def handle_ts(self, url, parent=None):
        # Lógica Estável: Streaming Direto (Zero-Copy), Sem Cache
        resp = self._fetch_url(url, referer=parent, stream=True)
        if not resp:
            self.send_error(404, "Not Found")
            return
        
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Accept-Ranges', 'none')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'close')
            self.end_headers()
            
            # Itera diretamente no stream (Zero Copy)
            for chunk in resp.iter_content(chunk_size=CONFIG['TS_CHUNK_SIZE']):
                if chunk:
                    self.wfile.write(chunk)
            
        except Exception as e:
            # Ignora erro de conexão quebrada pelo cliente (stop playback)
            if 'BrokenPipe' not in str(e):
                xbmc.log(f"[HLSProxy] Erro TS: {e}", xbmc.LOGERROR)
        finally:
            resp.close()
    
    def handle_key(self, url, parent=None):
        resp = self._fetch_url(url, referer=parent, stream=False)
        if not resp:
            self.send_error(404, "Key Not Found")
            return
        
        try:
            content = resp.content
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(content)
        finally:
            resp.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 50
    
    def server_bind(self):
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        super().server_bind()

class HLSAddon(object):
    _instance = None
    _is_running = False
    _lock = threading.Lock()
    
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(HLSAddon, cls).__new__(cls)
        return cls._instance
    
    def __init__(self, handle=None, *args, **kwargs):
        self.handle = handle
        
        with HLSAddon._lock:
            if not HLSAddon._is_running:
                self.start_server()
    
    def start_server(self):
        for _ in range(20):
            port = random.randint(18000, 28000)
            try:
                server = ThreadedHTTPServer((CONFIG['HOST'], port), HLSProxyHandler)
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                
                CONFIG['PORT'] = port
                HLSAddon._is_running = True
                
                xbmc.log(f'[HLSProxy] Servidor iniciado em {CONFIG["HOST"]}:{port}', xbmc.LOGINFO)
                return True
                
            except (OSError, socket.error):
                continue
        
        xbmc.log('[HLSProxy] Falha ao iniciar servidor', xbmc.LOGERROR)
        return False
    
    def play_stream(self, stream_url, title=None, headers=None, channel_id=None, epg_id=None):
        if not CONFIG['PORT']:
            xbmc.log('[HLSProxy] Servidor não disponível', xbmc.LOGERROR)
            return False
        
        # MANJARRO FIX: Usa formato de caminho /playlist/BASE64.m3u8
        proxy_url = f"http://{CONFIG['HOST']}:{CONFIG['PORT']}/playlist/{encode_url(stream_url)}.m3u8"
        
        li = xbmcgui.ListItem()
        li.setPath(proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        li.setProperty('IsPlayable', 'true')
        
        if headers:
            header_str = '&'.join([f"{k}={quote(v)}" for k, v in headers.items()])
            li.setPath(f"{proxy_url}|{header_str}")
        
        try:
            handle = int(self.handle) if self.handle is not None else int(sys.argv[1])
            xbmcplugin.setResolvedUrl(handle, True, li)
            xbmc.log(f'[HLSProxy] Reprodução iniciada (Estável + Manjaro Fix)', xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f'[HLSProxy] Erro ao iniciar reprodução: {e}', xbmc.LOGERROR)
            return False

# Instância global
proxy_addon = HLSAddon()