#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — NEXUS CORE HLS Proxy Engine (Immortal Edition for Kodi)
v7.3 - Full DoH Reference Logic + CDN IP Tracking
"""

import os
import sys
import re
import time
import json
import base64
import socket
import ssl
import select
import threading
import gzip
import zlib
import random
import urllib.request
import http.client
from collections import defaultdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, urlunparse, urljoin, parse_qs, urlencode, quote

# ─── KODI IMPORTS ───
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    _KODI = True
except ImportError:
    _KODI = False

# ═══════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════
DEBUG               = False
DOH_ENABLED         = True
DOH_CACHE_TTL       = 300.0
CONNECT_TIMEOUT     = 3.0
READ_TIMEOUT        = 10.0
STREAM_TIMEOUT      = 120
MAX_RETRIES         = 3
MANIFEST_RETRY_DELAY= 0.2
BACKOFF_BASE        = 0.4
BACKOFF_MAX         = 8.0
PLAYLIST_CACHE_TTL  = 2.0
KEY_CACHE_TTL       = 60.0
SEG_CACHE_TTL       = 90.0
SEG_STALE_MAX_AGE   = 45.0
CACHE_MAX_ENTRIES   = 50
REF_MAX_ATTEMPTS    = 2
MIN_INTER_REQUEST_DELAY = 0.05
MANIFEST_STAGNATION_THRESHOLD = 3
MAX_CONSECUTIVE_ERRORS = 5
SERVER_HOST         = '127.0.0.1'

USER_AGENTS = [
    "Kodi/21.0 (Linux; Android 13) XBMC/21.0 Git:20240101-abc1234",
    "Kodi/20.5 (Windows NT 10.0; Win64; x64) XBMC/20.5 Git:20231215-9a8b7c6",
    "VLC/3.0.20 LibVLC/3.0.20",
    "okhttp/4.12.0",
    "ExoPlayerLib/2.19.1 (Linux;Android 13) ExoPlayerCronetHttp/2.19.1",
    "Lavf/58.76.100",
    "GStreamer/1.22.0",
    "AppleCoreMedia/1.0.0.21F90 (Macintosh; U; Intel Mac OS X 14_5; en_us)"
]
ACCEPT_LANGUAGES = [
    "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7",
    "pt-BR,pt;q=0.8,en;q=0.5",
    "es-ES,es;q=0.9,pt-BR;q=0.8,en;q=0.7",
]
ACCEPT_ENCODINGS = [
    "gzip, deflate",
    "identity",
    "gzip",
]

# ═══════════════════════════════════════════════════════════
#  LOGGING
# ═══════════════════════════════════════════════════════════
def _log(msg, level='info'):
    if not DEBUG and level == 'debug':
        return
    tag = '[NexusCore-HLS]'
    if _KODI:
        lv = xbmc.LOGERROR if level == 'error' else xbmc.LOGINFO
        try:
            xbmc.log(f'{tag} {msg}', lv)
        except:
            pass
    else:
        stream = sys.stderr if level == 'error' else sys.stdout
        print(f'{tag} [{level}] {msg}', file=stream)

def set_debug(enabled):
    global DEBUG
    DEBUG = bool(enabled)

# ═══════════════════════════════════════════════════════════
#  DoH RESOLVER (Cache, Hits, Invalidation, UDP/DoH Fallback)
# ═══════════════════════════════════════════════════════════
class DoHResolver:
    DOH_SERVERS = [
        'https://cloudflare-dns.com/dns-query',
        'https://dns.google/resolve',
    ]
    FALLBACK_DNS = [("1.1.1.1", 53), ("8.8.8.8", 53), ("9.9.9.9", 53)]

    def __init__(self):
        self._cache = {}
        self._lock = threading.Lock()
        self._ctx = ssl.create_default_context()
        self._ctx.check_hostname = False
        self._ctx.verify_mode = ssl.CERT_NONE

    def _is_ip(self, host):
        if not host: return True
        try:
            socket.inet_aton(host)
            return True
        except:
            try:
                socket.inet_pton(socket.AF_INET6, host)
                return True
            except:
                return False

    def resolve(self, host):
        if not host or self._is_ip(host):
            return host

        with self._lock:
            cached = self._cache.get(host)
            if cached:
                ip, exp = cached
                if time.time() < exp:
                    _log(f"[DOH] Cache hit: {host} -> {ip}", 'debug')
                    return ip
                else:
                    del self._cache[host]

        ip = self._query_doh(host) or self._query_udp(host) or self._query_sys(host)

        if ip:
            with self._lock:
                self._cache[host] = (ip, time.time() + DOH_CACHE_TTL)
            _log(f"[DOH] Resolvido: {host} -> {ip}", 'info')
            return ip
        _log(f"[DOH] Falha TOTAL ao resolver {host}", 'error')
        return None

    def invalidate(self, host):
        if not host: return
        with self._lock:
            if host in self._cache:
                del self._cache[host]
                _log(f"[DOH] Cache invalidado para {host}", 'debug')

    def _query_doh(self, host):
        for server in self.DOH_SERVERS:
            try:
                req = urllib.request.Request(
                    f'{server}?name={host}&type=A',
                    headers={'Accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                )
                with urllib.request.urlopen(req, timeout=2, context=self._ctx) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    for ans in data.get('Answer', []):
                        if ans.get('type') == 1:
                            return ans['data']
            except:
                continue
        return None

    def _query_udp(self, host):
        for dns_ip, dns_port in self.FALLBACK_DNS:
            try:
                qid = random.randint(0, 65535)
                packet = bytearray([qid >> 8, qid & 0xff, 1, 0, 1, 0, 0, 0, 0, 0])
                for part in host.split('.'):
                    packet.append(len(part))
                    packet.extend(part.encode())
                packet.extend([0, 0, 1, 0, 1])
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2)
                sock.sendto(bytes(packet), (dns_ip, dns_port))
                data, _ = sock.recvfrom(512)
                sock.close()
                
                idx = data.find(b'\x00\x01\x00\x01', 12)
                if idx != -1:
                    ip_start = idx + 14
                    return socket.inet_ntoa(data[ip_start:ip_start+4])
            except:
                continue
        return None

    def _query_sys(self, host):
        try:
            return socket.gethostbyname(host)
        except:
            return None

DOH_RESOLVER = DoHResolver()

# ─── MONKEY-PATCH DO SOCKET (Force Resolve + SNI Fix) ───
DOH_BYPASS_HOSTS = {'cloudflare-dns.com', 'dns.google', '1.1.1.1', '8.8.8.8', '9.9.9.9', '1.0.0.1', '8.8.4.4'}

_orig_getaddrinfo = socket.getaddrinfo
def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if host and isinstance(host, str) and host not in DOH_BYPASS_HOSTS:
        if not DOH_RESOLVER._is_ip(host):
            ip = DOH_RESOLVER.resolve(host)
            if ip:
                return _orig_getaddrinfo(ip, port, family, type, proto, flags)
    return _orig_getaddrinfo(host, port, family, type, proto, flags)
socket.getaddrinfo = _patched_getaddrinfo

# ═══════════════════════════════════════════════════════════
#  HOST CONNECTION MANAGER (Strict 1-Conn Lock + CDN Detect)
# ═══════════════════════════════════════════════════════════
class HostConnection:
    _ERROR_COOLDOWNS = {
        429: 4.0, 500: 1.2, 502: 1.2, 503: 2.0,
        400: 0.4, 403: 3.0, 404: 0.2,
    }
    _ROTATE_ON_HTTP = {403, 429, 401}

    def __init__(self, host_key):
        self.host_key = host_key
        self._lock = threading.Lock()
        self._session_ua = random.choice(USER_AGENTS)
        self._session_lang = random.choice(ACCEPT_LANGUAGES)
        self._session_enc = random.choice(ACCEPT_ENCODINGS)
        self._last_request_time = 0.0
        self._consecutive_errors = 0
        self._cooldown_until = 0.0
        self._last_seen_ip = None # Controle de mudança de CDN
        self._last_manifest_sig = None
        self._stagnant_count = 0
        self._rotation_count = 0

    def _rotate_identity(self):
        try:
            idx = USER_AGENTS.index(self._session_ua)
            self._session_ua = USER_AGENTS[(idx + 1) % len(USER_AGENTS)]
        except:
            self._session_ua = random.choice(USER_AGENTS)
        self._session_lang = ACCEPT_LANGUAGES[self._rotation_count % len(ACCEPT_LANGUAGES)]
        self._session_enc = ACCEPT_ENCODINGS[self._rotation_count % len(ACCEPT_ENCODINGS)]
        self._rotation_count += 1
        _log(f"[HOST:{self.host_key}] Identity rotated #{self._rotation_count}. UA={self._session_ua[:35]}...", 'info')

    def _note_cdn(self, resolved_ip):
        # Detecção de mudança de IP (CDN Failover)
        if resolved_ip and self._last_seen_ip and resolved_ip != self._last_seen_ip:
            _log(f"[CDN] Host {self.host_key} mudou IP: old={self._last_seen_ip} new={resolved_ip}", 'info')
        if resolved_ip:
            self._last_seen_ip = resolved_ip

    def _get_headers(self, parsed_url, request_headers=None):
        hdrs = {
            'User-Agent': self._session_ua,
            'Accept': '*/*',
            'Accept-Language': self._session_lang,
            'Accept-Encoding': self._session_enc,
            'Connection': 'close',
        }
        if request_headers:
            rh = request_headers.get('Range') or request_headers.get('range')
            if rh: hdrs['Range'] = rh
        return hdrs

    def request(self, method, url, headers=None):
        with self._lock:
            if time.time() < self._cooldown_until:
                wait = self._cooldown_until - time.time()
                time.sleep(wait)

            delay_target = MIN_INTER_REQUEST_DELAY * random.uniform(1.0, 1.3)
            elapsed = time.time() - self._last_request_time
            if elapsed < delay_target:
                time.sleep(delay_target - elapsed)

            current_url = url
            self._last_request_time = time.time()

            for attempt in range(MAX_RETRIES):
                parsed = urlparse(current_url)
                req_hdrs = self._get_headers(parsed, headers)
                
                # Resolve explicitamente para logar mudança de IP (CDN)
                resolved_ip = DOH_RESOLVER.resolve(parsed.hostname)
                self._note_cdn(resolved_ip)

                try:
                    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
                    # O monkey-patch irá usar o IP resolvido transparentemente
                    if parsed.scheme == 'https':
                        ctx = ssl.create_default_context()
                        ctx.check_hostname = False
                        ctx.verify_mode = ssl.CERT_NONE
                        ctx.set_alpn_protocols(['http/1.1'])
                        conn = http.client.HTTPSConnection(parsed.hostname, port, timeout=READ_TIMEOUT, context=ctx)
                    else:
                        conn = http.client.HTTPConnection(parsed.hostname, port, timeout=READ_TIMEOUT)
                    
                    path = parsed.path or '/'
                    if parsed.query: path += '?' + parsed.query
                    
                    conn.request(method, path, headers=req_hdrs)
                    resp = conn.getresponse()
                    
                    if resp.status in (301, 302, 307, 308):
                        location = resp.getheader('location')
                        resp.read()
                        conn.close()
                        if location:
                            current_url = urljoin(current_url, location)
                            continue

                    data = resp.read()
                    conn.close()
                    
                    enc = resp.getheader('Content-Encoding', '')
                    if enc:
                        if 'gzip' in enc:
                            try: data = gzip.decompress(data)
                            except: pass
                        elif 'deflate' in enc:
                            try: data = zlib.decompress(data)
                            except: data = zlib.decompress(data, -zlib.MAX_WBITS)

                    if resp.status in self._ERROR_COOLDOWNS:
                        self._consecutive_errors += 1
                        if resp.status in self._ROTATE_ON_HTTP: self._rotate_identity()
                        cooldown = min(self._ERROR_COOLDOWNS[resp.status] * (1.5 ** (self._consecutive_errors - 1)), BACKOFF_MAX)
                        self._cooldown_until = time.time() + cooldown
                        _log(f"[HOST:{self.host_key}] HTTP {resp.status} (erro #{self._consecutive_errors}), cd {cooldown:.1f}s", 'error')
                    elif resp.status >= 400:
                        self._consecutive_errors += 1
                    else:
                        self._consecutive_errors = 0

                    if self._consecutive_errors >= MAX_CONSECUTIVE_ERRORS:
                        _log(f"[HOST:{self.host_key}] {self._consecutive_errors} erros consecutivos! Resetando...", 'error')
                        self._rotate_identity()
                        DOH_RESOLVER.invalidate(parsed.hostname)
                        self._consecutive_errors = 0
                        self._cooldown_until = 0.0

                    resp_headers = {k.lower(): v for k, v in resp.getheaders()}
                    
                    class MockResp:
                        def __init__(self, s, h, c, u):
                            self.status_code = s
                            self.headers = h
                            self.content = c
                            self.url = u
                            
                    return MockResp(resp.status, resp_headers, data, current_url)

                except Exception as e:
                    self._consecutive_errors += 1
                    cooldown = min(BACKOFF_BASE * (2 ** min(self._consecutive_errors - 1, 5)), BACKOFF_MAX)
                    self._cooldown_until = time.time() + cooldown
                    self._rotate_identity()
                    DOH_RESOLVER.invalidate(parsed.hostname) # Invalida DoH em falha de rede
                    _log(f"[HOST:{self.host_key}] Erro rede: {type(e).__name__}: {e}, cd {cooldown:.1f}s", 'error')
                    time.sleep(cooldown)
                    
                    if self._consecutive_errors >= MAX_CONSECUTIVE_ERRORS:
                        self._consecutive_errors = 0
                        self._cooldown_until = 0.0

                    if attempt == MAX_RETRIES - 1:
                        raise
            return None

    def check_manifest_stagnation(self, signature):
        if not signature: return False
        if signature == self._last_manifest_sig:
            self._stagnant_count += 1
        else:
            self._last_manifest_sig = signature
            self._stagnant_count = 0
            return False

        if self._stagnant_count >= MANIFEST_STAGNATION_THRESHOLD:
            _log(f"[HOST:{self.host_key}] Manifesto estagnado! Forçando reset", 'error')
            self._stagnant_count = 0
            self._last_manifest_sig = None
            self._rotate_identity()
            DOH_RESOLVER.invalidate(self.host_key.split(':')[0])
            return True
        return False

class HostConnectionManager:
    def __init__(self):
        self._hosts = {}
        self._lock = threading.Lock()

    def get_host(self, url):
        parsed = urlparse(url)
        host = parsed.hostname or 'unknown'
        port = parsed.port or (443 if parsed.scheme == 'https' else 80)
        key = f"{host}:{port}"
        with self._lock:
            if key not in self._hosts:
                self._hosts[key] = HostConnection(key)
                _log(f"[POOL] Novo pool criado para host: {key}", 'info')
            return self._hosts[key]

    def request(self, method, url, headers=None):
        host_conn = self.get_host(url)
        return host_conn.request(method, url, headers)

HOST_MANAGER = HostConnectionManager()

# ═══════════════════════════════════════════════════════════
#  REF SYSTEM & SMART CACHE
# ═══════════════════════════════════════════════════════════
_seg_to_m3u8 = {}
_url_to_entry = {}
_ref_lock = threading.Lock()

def _register_ref(url, parent_url, entry_url=None):
    with _ref_lock:
        _seg_to_m3u8[url] = parent_url
        if entry_url is not None:
            _url_to_entry[url] = entry_url
        elif parent_url in _url_to_entry:
            _url_to_entry[url] = _url_to_entry[parent_url]
        elif parent_url == url:
            _url_to_entry[url] = url
        else:
            _url_to_entry[url] = parent_url

class SmartCache:
    def __init__(self):
        self._data = {}
        self._locks = {}
        self._global = threading.Lock()

    def get_lock(self, key):
        with self._global:
            if key not in self._locks:
                self._locks[key] = threading.Lock()
            return self._locks[key]

    def _evict(self):
        if len(self._data) > CACHE_MAX_ENTRIES:
            oldest = min(self._data, key=lambda k: self._data[k][1])
            del self._data[oldest]

    def get(self, key, ttl):
        with self._global:
            entry = self._data.get(key)
            if entry and time.time() - entry[1] < ttl:
                return entry[0]
            if entry:
                del self._data[key]
        return None

    def get_stale(self, key, max_age):
        with self._global:
            entry = self._data.get(key)
            if entry:
                age = time.time() - entry[1]
                if age < max_age:
                    return entry[0]
        return None

    def set(self, key, value):
        with self._global:
            self._evict()
            self._data[key] = (value, time.time())

    def clear(self):
        with self._global:
            self._data.clear()

CACHE = SmartCache()

# ═══════════════════════════════════════════════════════════
#  HLS PARSING & REWRITING
# ═══════════════════════════════════════════════════════════
def _is_valid_m3u8(content: bytes) -> bool:
    if not content or len(content) < 10: return False
    try:
        text = content.decode('utf-8', errors='ignore')
    except:
        return False
    return text.strip().startswith('#EXTM3U')

def _is_valid_segment(content: bytes, url: str) -> bool:
    if not content or len(content) < 32: return False
    if content[:1] in (b'<', b'#'): return False
    return True

def rewrite_m3u8_content(content: bytes, base_url: str, proxy_base: str, ref_url: str = None) -> bytes:
    try:
        content_str = content.decode('utf-8', errors='replace').replace('\r\n', '\n').replace('\r', '\n')
    except:
        return content
        
    lines = content_str.split('\n')
    new_lines = []
    ref_suffix = f'&ref={quote(ref_url, safe="")}' if ref_url else ''
    
    for line in lines:
        stripped = line.strip()
        if not stripped:
            new_lines.append('')
            continue
        if stripped.startswith('#'):
            if 'URI=' in stripped:
                def _replace(match):
                    q, uri = match.group(1), match.group(2)
                    if proxy_base in uri: return match.group(0)
                    abs_url = urljoin(base_url, uri)
                    return f'URI={q}{proxy_base}{quote(abs_url, safe="")}{ref_suffix}{q}'
                new_lines.append(re.sub(r'URI=(["\'])([^"\']+)\1', _replace, stripped))
            else:
                new_lines.append(stripped)
            continue
        if proxy_base in stripped:
            new_lines.append(stripped)
            continue
        abs_url = urljoin(base_url, stripped)
        _register_ref(abs_url, base_url, ref_url or base_url)
        new_lines.append(f"{proxy_base}{quote(abs_url, safe='')}{ref_suffix}")
    return '\n'.join(new_lines).encode('utf-8')

def detect_content_type(url: str, content: bytes) -> str:
    path = url.lower().split('?')[0]
    if path.endswith('.m3u8'): return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'): return 'video/MP2T'
    if path.endswith('.m4s'): return 'video/iso.segment'
    if path.endswith('.mp4'): return 'video/mp4'
    if path.endswith('.key'): return 'application/octet-stream'
    return 'application/octet-stream'

def _extract_filename(url: str) -> str:
    try: return urlparse(url).path.split('/')[-1].split('?')[0]
    except: return ''

def _find_segment_in_manifest(filename: str, manifest_str: str, final_url: str) -> str:
    if not filename or not manifest_str: return None
    candidates = [l.strip() for l in manifest_str.splitlines() if l.strip() and not l.strip().startswith('#')]
    if not candidates: return None
    for stripped in candidates:
        if filename in stripped:
            return urljoin(final_url, stripped)
    for stripped in candidates:
        try:
            abs_url = urljoin(final_url, stripped)
            cand_name = _extract_filename(abs_url)
        except: continue
        if cand_name and cand_name == filename:
            return abs_url
    return None

# ═══════════════════════════════════════════════════════════
#  FETCH MANIFEST & REF RECOVERY
# ═══════════════════════════════════════════════════════════
def _fetch_manifest(url: str):
    try:
        resp = HOST_MANAGER.request("GET", url, headers={"Accept": "application/vnd.apple.mpegurl, */*"})
        if resp.status_code != 200: return None, None
        content = resp.content
        if not _is_valid_m3u8(content): return None, None
        return content, str(resp.url)
    except:
        return None, None

def _resolve_seg_via_ref(ref_manifest_url: str, seg_url: str):
    filename = _extract_filename(seg_url)
    if not filename: return None
    content, final_url = _fetch_manifest(ref_manifest_url)
    if not content:
        cached_man = CACHE.get(ref_manifest_url, 999999)
        if not cached_man: return None
        content, final_url = cached_man, ref_manifest_url
    else:
        CACHE.set(ref_manifest_url, content)
    try:
        manifest_str = content.decode('utf-8', errors='replace')
    except:
        return None
    resolved = _find_segment_in_manifest(filename, manifest_str, final_url or ref_manifest_url)
    if resolved and resolved != seg_url:
        return resolved
    return None

# ═══════════════════════════════════════════════════════════
#  HLS PROXY HTTP SERVER
# ═══════════════════════════════════════════════════════════
_server = None
_server_port = None
_server_lock = threading.Lock()

class _HLSServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class _ProxyHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    timeout = STREAM_TIMEOUT
    rbufsize = -1
    wbufsize = 0

    def handle_one_request(self):
        try: return super().handle_one_request()
        except (ConnectionResetError, BrokenPipeError, socket.timeout, OSError):
            self.close_connection = True

    def log_message(self, *args, **kwargs): pass

    @property
    def _proxy_base(self):
        return f'http://{SERVER_HOST}:{_server_port}/proxy?url='

    def _send_simple(self, status, body=b'', content_type='application/octet-stream'):
        self.close_connection = True
        try:
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.flush()
            if body and self.command != 'HEAD':
                self.wfile.write(body)
                self.wfile.flush()
        except: pass

    def do_GET(self):
        self.close_connection = True
        try: self._handle_get()
        except: self._send_simple(404, b'', 'application/octet-stream')

    def do_HEAD(self):
        self.do_GET()

    def _handle_get(self):
        path = self.path
        if path.startswith('/proxy?'):
            params = parse_qs(path[7:])
            if 'url' in params:
                original_url = params['url'][0]
                ref_manifest_url = params['ref'][0] if 'ref' in params else None
                
                if original_url.lower().split('?')[0].endswith(('.m3u8', '.m3u')):
                    self._serve_playlist(original_url)
                else:
                    self._serve_segment(original_url, ref_manifest_url)
                return
        self._send_simple(200, b'NEXUS CORE HLS Proxy OK', 'text/plain')

    def _serve_playlist(self, original_url):
        cached = CACHE.get(original_url, PLAYLIST_CACHE_TTL)
        if cached:
            rewritten = rewrite_m3u8_content(cached.encode('utf-8') if isinstance(cached, str) else cached, original_url, self._proxy_base, ref_url=original_url)
            self._send_simple(200, rewritten, 'application/vnd.apple.mpegurl')
            return

        lock = CACHE.get_lock(original_url)
        with lock:
            cached = CACHE.get(original_url, PLAYLIST_CACHE_TTL)
            if cached:
                rewritten = rewrite_m3u8_content(cached.encode('utf-8') if isinstance(cached, str) else cached, original_url, self._proxy_base, ref_url=original_url)
                self._send_simple(200, rewritten, 'application/vnd.apple.mpegurl')
                return

            content, final_url = None, None
            for attempt in range(MAX_RETRIES):
                content, final_url = _fetch_manifest(original_url)
                if content: break
                if attempt < MAX_RETRIES - 1:
                    time.sleep(MANIFEST_RETRY_DELAY)

            if not content:
                stale = CACHE.get_stale(original_url, SEG_STALE_MAX_AGE)
                if stale:
                    _log(f"[M3U8] Usando cache expirado: {original_url[:80]}", 'info')
                    rewritten = rewrite_m3u8_content(stale.encode('utf-8') if isinstance(stale, str) else stale, original_url, self._proxy_base, ref_url=original_url)
                    self._send_simple(200, rewritten, 'application/vnd.apple.mpegurl')
                    return
                dummy = b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:2.0,\ndummy.ts\n"
                self._send_simple(200, dummy, 'application/vnd.apple.mpegurl')
                return

            CACHE.set(original_url, content.decode('utf-8', errors='ignore'))
            
            try:
                content_str = content.decode('utf-8', errors='replace')
                seq_match = re.search(r'#EXT-X-MEDIA-SEQUENCE:(\d+)', content_str)
                if seq_match:
                    last_seg = next((l.strip() for l in reversed(content_str.splitlines()) if l.strip() and not l.strip().startswith('#')), '')
                    sig = f"{seq_match.group(1)}|{_extract_filename(last_seg)}"
                    host_conn = HOST_MANAGER.get_host(original_url)
                    if host_conn.check_manifest_stagnation(sig):
                        content, final_url = _fetch_manifest(original_url)
                        if content:
                            CACHE.set(original_url, content.decode('utf-8', errors='ignore'))
            except: pass

            rewritten = rewrite_m3u8_content(content, final_url or original_url, self._proxy_base, ref_url=original_url)
            self._send_simple(200, rewritten, 'application/vnd.apple.mpegurl')

    def _serve_segment(self, original_url, ref_manifest_url):
        cached = CACHE.get(original_url, SEG_CACHE_TTL)
        if cached is not None:
            if len(cached) == 0:
                self._send_simple(200, b'', 'video/MP2T')
                return
            self._send_simple(200, cached, detect_content_type(original_url, cached))
            return

        lock = CACHE.get_lock(original_url)
        with lock:
            cached = CACHE.get(original_url, SEG_CACHE_TTL)
            if cached is not None:
                if len(cached) == 0:
                    self._send_simple(200, b'', 'video/MP2T')
                    return
                self._send_simple(200, cached, detect_content_type(original_url, cached))
                return

            try:
                resp = HOST_MANAGER.request("GET", original_url, headers={"Accept": "video/MP2T, */*"})
                if resp.status_code == 200 and resp.content and _is_valid_segment(resp.content, original_url):
                    CACHE.set(original_url, resp.content)
                    self._send_simple(200, resp.content, detect_content_type(original_url, resp.content))
                    return
            except Exception as e:
                _log(f"[SEG] Erro rede: {type(e).__name__}: {e} - {original_url[:80]}", 'error')

            if ref_manifest_url:
                recovered_url = _resolve_seg_via_ref(ref_manifest_url, original_url)
                if recovered_url and recovered_url != original_url:
                    _log(f"[SEG][REF] URL renovada: {recovered_url[:80]}", 'info')
                    try:
                        resp2 = HOST_MANAGER.request("GET", recovered_url, headers={"Accept": "video/MP2T, */*"})
                        if resp2.status_code == 200 and resp2.content and _is_valid_segment(resp2.content, recovered_url):
                            CACHE.set(original_url, resp2.content)
                            self._send_simple(200, resp2.content, detect_content_type(original_url, resp2.content))
                            return
                    except: pass

            stale = CACHE.get_stale(original_url, SEG_STALE_MAX_AGE)
            if stale and len(stale) > 0:
                _log(f"[SEG] Servindo cache expirado após falha: {original_url[:80]}", 'info')
                self._send_simple(200, stale, detect_content_type(original_url, stale))
                return

            _log(f"[SEG] Pulando segmento: {original_url[:80]}", 'error')
            CACHE.set(original_url, b'')
            self._send_simple(200, b'', 'video/MP2T')

# ═══════════════════════════════════════════════════════════
#  KODI ADDON API
# ═══════════════════════════════════════════════════════════
def _ensure_server():
    global _server, _server_port
    with _server_lock:
        if _server and _server_port:
            return _server_port
        test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        test_sock.bind((SERVER_HOST, 0))
        port = test_sock.getsockname()[1]
        test_sock.close()

        _server = _HLSServer((SERVER_HOST, port), _ProxyHandler)
        t = threading.Thread(target=_server.serve_forever, daemon=True)
        t.start()
        _server_port = port
        return port

def _shutdown_server():
    global _server, _server_port
    with _server_lock:
        if _server:
            try:
                _server.shutdown()
                _server.server_close()
            except: pass
            _server = None
            _server_port = None

import atexit
atexit.register(_shutdown_server)

class HLSAddon:
    def __init__(self, addon_handle=None):
        self.handle = addon_handle

    def play_stream(self, url):
        try:
            port = _ensure_server()
        except Exception:
            if _KODI and self.handle is not None:
                try:
                    li = xbmcgui.ListItem(path=url)
                    li.setMimeType('application/vnd.apple.mpegurl')
                    li.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(self.handle, True, li)
                except:
                    xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        _register_ref(url, url, entry_url=url)

        if url.lower().split('?')[0].endswith(('.ts', '.mp4', '.m4s', '.mkv')):
            proxy_url = f'http://{SERVER_HOST}:{port}/proxy?url={quote(url, safe="")}'
            mime_type = 'video/mp2t'
        else:
            proxy_url = f'http://{SERVER_HOST}:{port}/proxy?url={quote(url, safe="")}'
            mime_type = 'application/vnd.apple.mpegurl'

        if _KODI and self.handle is not None:
            try:
                li = xbmcgui.ListItem(path=proxy_url)
                li.setMimeType(mime_type)
                li.setContentLookup(False)
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.setResolvedUrl(self.handle, True, li)
            except:
                try: xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                except: pass

def play(url, handle=None):
    addon = HLSAddon(addon_handle=handle)
    addon.play_stream(url)

def get_proxy_url(url):
    port = _ensure_server()
    _register_ref(url, url, entry_url=url)
    return f'http://{SERVER_HOST}:{port}/proxy?url={quote(url, safe="")}'

def shutdown():
    _shutdown_server()

if __name__ == '__main__':
    DEBUG = True
    print('NEXUS CORE HLS Proxy v7.3 — Immortal Edition')
    print('=' * 60)
    port = _ensure_server()
    print(f'Server running on port: {port}')
    print(f'Features: Full DoH Logic, Strict 1-Conn Lock, CDN Track')
    print('=' * 60)
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        print('\nShutting down...')
        shutdown()
        print('Done.')