#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tsproxy.py — NEXUS CORE MPEG-TS SUTURE ENGINE (Immortal DoH Edition)
# Versão: 32.4 — Fix: Relógio do Watchdog de Sutura Persistente Entre Trocas + Backoff Escalonado por Streak
#

from __future__ import annotations
import http.server
import socketserver
import urllib.parse
import socket
import ssl
import http.client
import threading
import time
import random
import queue
import collections
import json
import ipaddress
import sys
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional, Tuple

# ─────────────────────────────────────────────
#  LOG SWITCH
# ─────────────────────────────────────────────
_LOG_ENABLED = False

try:
    import xbmc
    _HAS_XBMC = True
except Exception:
    xbmc = None
    _HAS_XBMC = False

_LOG_LEVELS = {}
if _HAS_XBMC:
    _LOG_LEVELS = {
        "DEBUG": xbmc.LOGDEBUG,
        "INFO": xbmc.LOGINFO,
        "WARNING": xbmc.LOGWARNING,
        "ERROR": xbmc.LOGERROR,
    }

def set_log_enabled(enabled: bool):
    global _LOG_ENABLED
    _LOG_ENABLED = bool(enabled)

def _log(msg, level="INFO"):
    if not _LOG_ENABLED:
        return
    try:
        if _HAS_XBMC:
            lvl = _LOG_LEVELS.get(level, xbmc.LOGDEBUG)
            xbmc.log(f"[NexusCore-TS] {msg}", lvl)
        else:
            print(f"[NexusCore-TS] {msg}", file=sys.stderr)
    except Exception:
        pass

# ─────────────────────────────────────────────
#  CONSTANTES E CONFIG GLOBAL
# ─────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47

TS_CHUNK_SIZE = TS_PACKET_SIZE * 348
TS_MAX_OUTPUT_BUFFER = 10
TS_MAX_SYNC_ATTEMPTS_PER_CYCLE = 5000
TS_SYNC_CONFIRM_PACKETS = 20

TS_CONSECUTIVE_EOF_BACKOFF_START = 2
TS_CONSECUTIVE_EOF_BACKOFF_STEP = 1.5
TS_CONSECUTIVE_EOF_BACKOFF_MAX = 10.0

TS_AUTH_FAILURE_RESET_BYTES = 256 * 1024
TS_SUTURE_DEADLINE_CIRCUIT_THRESHOLD = 2
TS_SUTURE_SEARCH_HEARTBEAT_INTERVAL = 5.0

TS_PARALLEL_WORKERS = 3
TS_WORKER_QUEUE_SIZE = 60
TS_WORKER_STALL_THRESHOLD = 10.0
TS_COORDINATOR_URL_REFRESH = 30.0
TS_WORKER_STAGGER_DELAY = 0.15
TS_READ_CHUNK_DEADLINE = 10.0
TS_SUTURE_SEARCH_DEADLINE = 20.0
TS_SUTURE_WINDOW_LIMIT = 512 * 1024
TS_TAIL_SIZE = 128 * 1024
TS_MIN_DISCONTINUITY_SPACING = 2.5
TS_AUTH_FAILURE_CIRCUIT_THRESHOLD = 3
TS_AUTH_FAILURE_CIRCUIT_WAIT = 8.0
TS_BACKOFF_MAX_SECONDS = 30.0

USER_AGENTS = [
    "Kodi/21.0 (Linux; Android 13) XBMC/21.0 Git:20240101-abc1234",
    "Kodi/20.5 (Windows NT 10.0; Win64; x64) XBMC/20.5 Git:20231215-9a8b7c6",
    "VLC/3.0.20 LibVLC/3.0.20",
    "okhttp/4.12.0",
    "ExoPlayerLib/2.19.1 (Linux;Android 13) ExoPlayerCronetHttp/2.19.1",
    "Lavf/58.76.100",
    "GStreamer/1.22.0",
    "AppleCoreMedia/1.0.0.21F90 (Macintosh; U; Intel Mac OS X 14_5; en_us)"
]
ACCEPT_LANGUAGES = [
    "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7",
    "pt-BR,pt;q=0.8,en;q=0.5",
    "es-ES,es;q=0.9,pt-BR;q=0.8,en;q=0.7",
]
ACCEPT_ENCODINGS = [
    "gzip, deflate",
    "identity",
    "gzip",
]

# ─────────────────────────────────────────────
#  DoH RESOLVER (Cache, Hits, Invalidation, UDP/DoH Fallback)
# ─────────────────────────────────────────────
class DoHResolver:
    DOH_SERVERS = [
        'https://cloudflare-dns.com/dns-query',
        'https://dns.google/resolve',
    ]
    FALLBACK_DNS = [("1.1.1.1", 53), ("8.8.8.8", 53), ("9.9.9.9", 53)]

    def __init__(self):
        self._cache = {}
        self._lock = threading.Lock()
        self._ctx = ssl.create_default_context()
        self._ctx.check_hostname = False
        self._ctx.verify_mode = ssl.CERT_NONE

    def _is_ip(self, host):
        if not host: return True
        try:
            socket.inet_aton(host)
            return True
        except:
            try:
                socket.inet_pton(socket.AF_INET6, host)
                return True
            except:
                return False

    def resolve(self, host):
        if not host or self._is_ip(host):
            return host

        with self._lock:
            cached = self._cache.get(host)
            if cached:
                ip, exp = cached
                if time.time() < exp:
                    _log(f"[DOH] Cache hit: {host} -> {ip}", "DEBUG")
                    return ip
                else:
                    del self._cache[host]

        ip = self._query_doh(host) or self._query_udp(host) or self._query_sys(host)

        if ip:
            with self._lock:
                self._cache[host] = (ip, time.time() + 300.0)
            _log(f"[DOH] Resolvido: {host} -> {ip}", "INFO")
            return ip
        _log(f"[DOH] Falha TOTAL ao resolver {host}", "ERROR")
        return None

    def invalidate(self, host):
        if not host: return
        with self._lock:
            if host in self._cache:
                del self._cache[host]
                _log(f"[DOH] Cache invalidado para {host}", "DEBUG")

    def _query_doh(self, host):
        for server in self.DOH_SERVERS:
            try:
                req = urllib.request.Request(
                    f'{server}?name={host}&type=A',
                    headers={'Accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                )
                # Aumentado para 3.0s para dar tempo ao DoH
                with urllib.request.urlopen(req, timeout=3.0, context=self._ctx) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    for ans in data.get('Answer', []):
                        if ans.get('type') == 1:
                            return ans['data']
            except:
                continue
        return None

    def _query_udp(self, host):
        for dns_ip, dns_port in self.FALLBACK_DNS:
            try:
                qid = random.randint(0, 65535)
                packet = bytearray([qid >> 8, qid & 0xff, 1, 0, 1, 0, 0, 0, 0, 0])
                for part in host.split('.'):
                    packet.append(len(part))
                    packet.extend(part.encode())
                packet.extend([0, 0, 1, 0, 1])
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                # Reduzido para 1.0s para falhar mais rápido e ir para o DNS do sistema
                sock.settimeout(1.0)
                sock.sendto(bytes(packet), (dns_ip, dns_port))
                data, _ = sock.recvfrom(512)
                sock.close()
                
                idx = data.find(b'\x00\x01\x00\x01', 12)
                if idx != -1:
                    ip_start = idx + 14
                    return socket.inet_ntoa(data[ip_start:ip_start+4])
            except:
                continue
        return None

    def _query_sys(self, host):
        try:
            return socket.gethostbyname(host)
        except:
            return None

DOH_RESOLVER = DoHResolver()

# ─── MONKEY-PATCH DO SOCKET (Force Resolve + SNI Fix) ───
DOH_BYPASS_HOSTS = {'cloudflare-dns.com', 'dns.google', '1.1.1.1', '8.8.8.8', '9.9.9.9', '1.0.0.1', '8.8.4.4'}

_orig_getaddrinfo = socket.getaddrinfo
def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if host and isinstance(host, str) and host not in DOH_BYPASS_HOSTS:
        if not DOH_RESOLVER._is_ip(host):
            ip = DOH_RESOLVER.resolve(host)
            if ip:
                return _orig_getaddrinfo(ip, port, family, type, proto, flags)
    return _orig_getaddrinfo(host, port, family, type, proto, flags)
socket.getaddrinfo = _patched_getaddrinfo

# ─────────────────────────────────────────────
#  HTTP CLIENT & REDIRECT RESOLVER
# ─────────────────────────────────────────────
def _ts_build_headers(ua: str, lang: str, enc: str, referer: str = None, host: str = None) -> dict:
    headers = {
        'User-Agent': ua, 'Accept': '*/*',
        'Accept-Language': lang,
        'Accept-Encoding': enc, 'Connection': 'keep-alive',
        'Cache-Control': 'no-cache, no-store', 'Pragma': 'no-cache',
        'DNT': '1',
    }
    if referer:
        headers['Referer'] = referer
        headers['Origin'] = '/'.join(referer.split('/')[:3])
    if host:
        headers['Host'] = host
    return headers

class _TsNoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

def _ts_create_worker_opener():
    return urllib.request.build_opener(
        urllib.request.HTTPHandler(debuglevel=0),
        urllib.request.HTTPSHandler(debuglevel=0),
        _TsNoRedirectHandler()
    )

_TS_RESOLVED_URL_CACHE: Dict[str, Tuple[str, float, Optional[str]]] = {}
_TS_RESOLVED_URL_CACHE_LOCK = threading.Lock()
_TS_RESOLVED_URL_CACHE_TTL = 8.0
_TS_RESOLVED_URL_CACHE_MAX = 50

def _ts_get_cached_resolved_url(original_url: str):
    now = time.time()
    with _TS_RESOLVED_URL_CACHE_LOCK:
        entry = _TS_RESOLVED_URL_CACHE.get(original_url)
        if entry:
            resolved, expiry, host = entry
            if now < expiry: return resolved, host
            del _TS_RESOLVED_URL_CACHE[original_url]
    return None, None

def _ts_set_cached_resolved_url(original_url: str, resolved_url: str, host: str):
    with _TS_RESOLVED_URL_CACHE_LOCK:
        if len(_TS_RESOLVED_URL_CACHE) >= _TS_RESOLVED_URL_CACHE_MAX:
            oldest_key = next(iter(_TS_RESOLVED_URL_CACHE))
            del _TS_RESOLVED_URL_CACHE[oldest_key]
        _TS_RESOLVED_URL_CACHE[original_url] = (resolved_url, time.time() + _TS_RESOLVED_URL_CACHE_TTL, host)

def _ts_invalidate_cached_resolved_url(original_url: str):
    with _TS_RESOLVED_URL_CACHE_LOCK:
        _TS_RESOLVED_URL_CACHE.pop(original_url, None)

def _ts_resolve_url_sync(ua: str, lang: str, enc: str, url: str) -> str:
    cached_resolved, cached_host = _ts_get_cached_resolved_url(url)
    if cached_resolved is not None:
        return cached_resolved

    curr = url
    for hop in range(5):
        try:
            parsed = urllib.parse.urlparse(curr)
            headers = _ts_build_headers(ua, lang, enc, referer=url, host=parsed.hostname)
            
            opener = _ts_create_worker_opener()
            req = urllib.request.Request(curr, headers=headers)
            # AUMENTADO PARA 10.0s PARA DAR TEMPO AO DOH RESOLVER
            with opener.open(req, timeout=10.0) as resp:
                if resp.status in (301, 302, 303, 307, 308):
                    loc = resp.headers.get('Location')
                    if loc:
                        curr = urllib.parse.urljoin(curr, loc)
                        continue
                break
        except Exception as e:
            _log(f"Resolve falhou no hop {hop + 1}/5: {type(e).__name__}: {str(e)[:80]}", "ERROR")
            break

    final_host = urllib.parse.urlparse(curr).hostname
    _ts_set_cached_resolved_url(url, curr, final_host)
    return curr

# ─────────────────────────────────────────────
#  TsBuffer — alinhamento e sutura de discontinuidade
# ─────────────────────────────────────────────
def _ts_strict_align(data: bytes) -> bytes:
    if not data: return b''
    remainder = len(data) % TS_PACKET_SIZE
    if remainder: return bytes(data[:-remainder])
    return bytes(data)

def _ts_build_null_burst(count: int = 24) -> bytes:
    burst = bytearray()
    for i in range(count):
        cc = i & 0x0F
        hdr = bytearray([0x47, 0x1F, 0xFF, 0x10 | cc])
        burst.extend(hdr)
        burst.extend(b'\xFF' * 184)
    return bytes(burst)

TS_NULL_PUMP_BURST = _ts_build_null_burst(24)

def _ts_mark_discontinuity(packet: bytearray) -> bool:
    afc = (packet[3] & 0x30) >> 4
    if afc in (2, 3) and len(packet) > 5 and packet[4] > 0:
        packet[5] |= 0x80
        return True
    return False

class TsBuffer:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = False
        self._pids_pending_discontinuity = set()

    def clear_partial_buffer(self):
        self._buf.clear()
        self._aligned = False

    def arm_discontinuity(self):
        self._armed_discontinuity = True
        self._pids_pending_discontinuity = set(self._cc_map.keys())

    def _confirm_sync(self, data, idx: int, length: int) -> bool:
        checkpoints_needed = TS_SYNC_CONFIRM_PACKETS
        confirmed = 0
        for k in range(checkpoints_needed):
            pos = idx + k * TS_PACKET_SIZE
            if pos >= length: break
            if data[pos] != TS_SYNC_BYTE: return False
            confirmed += 1
        min_needed = min(checkpoints_needed, max(2, (length - idx) // TS_PACKET_SIZE))
        return confirmed >= min_needed

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= TS_MAX_SYNC_ATTEMPTS_PER_CYCLE: return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < TS_MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                self._last_sync_idx = length
                return -1
            self._sync_attempts += 1
            if self._confirm_sync(data, idx, length):
                self._last_sync_idx = idx + TS_PACKET_SIZE
                return idx
            idx += 1
        self._last_sync_idx = idx
        return -1

    def _process_packets(self, data: bytearray):
        n = len(data) // TS_PACKET_SIZE
        out = bytearray()
        mv = memoryview(data)
        armed_this_batch = self._armed_discontinuity
        seen_this_batch = set()
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            packet_view = mv[offset:offset + TS_PACKET_SIZE]
            if packet_view[0] != TS_SYNC_BYTE:
                self._error_count += 1
                self._aligned = False
                leftover = bytearray(mv[offset:])
                return out, leftover
            packet = bytearray(packet_view)
            pid = ((packet[1] & 0x1F) << 8) | packet[2]
            afc = (packet[3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            cc = packet[3] & 0x0F

            if pid == 0x1FFF:
                out.extend(packet)
                continue

            if armed_this_batch and pid not in seen_this_batch:
                self._pids_pending_discontinuity.add(pid)
                seen_this_batch.add(pid)

            if has_payload:
                self._cc_map[pid] = cc

            # FIX v32.2: só remove da fila de pendência se a marcação realmente
            # aconteceu. Pacotes com afc=1 (payload puro, sem adaptation field)
            # não têm onde gravar o bit — antes eram descartados da fila mesmo
            # assim, perdendo o discontinuity_indicator pro Kodi pra sempre.
            # Agora o PID fica pendente até aparecer um pacote com adaptation
            # field (afc 2/3) pra receber a marcação.
            if pid in self._pids_pending_discontinuity:
                if _ts_mark_discontinuity(packet):
                    self._pids_pending_discontinuity.discard(pid)

            out.extend(packet)

        if self._armed_discontinuity and n > 0:
            self._armed_discontinuity = False
        return out, bytearray()

    def feed(self, raw: bytes) -> bytes:
        if not raw: return b''
        self._buf.extend(raw)
        result = bytearray()
        while True:
            if not self._aligned:
                self._sync_attempts = 0
                self._last_sync_idx = 0
                idx = self._find_sync(self._buf)
                if idx == -1:
                    if len(self._buf) > TS_PACKET_SIZE * 100:
                        keep_tail = TS_PACKET_SIZE * 2
                        del self._buf[:-keep_tail]
                    return bytes(result)
                if idx > 0:
                    del self._buf[:idx]
                self._aligned = True
            buf_len = len(self._buf)
            usable = buf_len - (buf_len % TS_PACKET_SIZE)
            if usable == 0:
                return bytes(result)
            payload = self._buf[:usable]
            del self._buf[:usable]
            processed, leftover = self._process_packets(payload)
            if processed:
                result.extend(_ts_strict_align(processed))
            if leftover:
                self._buf = leftover + self._buf
                continue
            return _ts_strict_align(result)

# ─────────────────────────────────────────────
#  TsStreamContext — estado de uma sessão
# ─────────────────────────────────────────────
class TsStreamContext:
    def __init__(self, original_url: str, hostname: str):
        self.original_url = original_url
        self.resolved_url = original_url
        self.hostname = hostname
        self.ua = random.choice(USER_AGENTS)
        self.lang = random.choice(ACCEPT_LANGUAGES)
        self.enc = random.choice(ACCEPT_ENCODINGS)
        self.ts_buf = TsBuffer()
        self.active = True
        self.has_played_data = False
        self.last_useful_payload = time.time()
        self.created_at = time.time()
        self.total_bytes_streamed = 0
        self.last_discontinuity_at = None
        self.last_resolved_host = None
        self.cdn_switch_count = 0
        self.consecutive_auth_failures = 0
        self.bytes_since_connect = 0

        self.stream_tail = bytearray()
        self._tail_lock = threading.Lock()
        self.out_queue: "queue.Queue[Optional[bytes]]" = queue.Queue(maxsize=TS_MAX_OUTPUT_BUFFER)

    def rotate_identity(self):
        try:
            idx = USER_AGENTS.index(self.ua)
            self.ua = USER_AGENTS[(idx + 1) % len(USER_AGENTS)]
        except:
            self.ua = random.choice(USER_AGENTS)
        self.lang = random.choice(ACCEPT_LANGUAGES)
        self.enc = random.choice(ACCEPT_ENCODINGS)
        _log(f"Identity rotated. New UA: {self.ua[:35]}...", "INFO")

    def add_played(self, data: bytes):
        if not data: return
        with self._tail_lock:
            self.stream_tail.extend(data)
            if len(self.stream_tail) > TS_TAIL_SIZE:
                del self.stream_tail[:-TS_TAIL_SIZE]

    def get_tail(self) -> bytes:
        with self._tail_lock:
            return bytes(self.stream_tail)

    def update_activity(self):
        self.last_useful_payload = time.time()

    def push_output(self, data: bytes):
        if not self.active: return
        try:
            self.out_queue.put_nowait(data)
        except queue.Full:
            try: self.out_queue.get_nowait()
            except queue.Empty: pass
            try: self.out_queue.put_nowait(data)
            except queue.Full: pass

# ─────────────────────────────────────────────
#  TsStreamWorker — 1 conexão paralela
# ─────────────────────────────────────────────
class TsStreamWorker:
    def __init__(self, worker_id: int, ctx: TsStreamContext):
        self.worker_id = worker_id
        self.ctx = ctx
        self.queue: "queue.Queue[bytes]" = queue.Queue(maxsize=TS_WORKER_QUEUE_SIZE)
        self.thread: Optional[threading.Thread] = None
        self.active = False
        self.stopped = False
        self.response = None
        self.leftover = bytearray()
        self.reconnect_num = 0
        self.last_data_at = 0.0
        self.bytes_read = 0
        self.is_connected = False
        self.last_error = None
        self.last_error_code: Optional[int] = None
        self.consecutive_eof = 0
        self.target_host: Optional[str] = None
        self._lock = threading.Lock()

    def start(self):
        self.active = True
        self.last_data_at = time.time()
        self.thread = threading.Thread(target=self._run, daemon=True, name=f"ts-worker-{self.worker_id}")
        self.thread.start()

    def stop(self):
        self.active = False
        self.stopped = True
        self._close_connection()

    def _close_connection(self):
        if self.response:
            try: self.response.close()
            except Exception: pass
            self.response = None
        self.is_connected = False

    def _calculate_backoff(self) -> float:
        base = 0.5
        capped_n = min(self.reconnect_num, 8)
        raw = base * (2 ** capped_n)
        jitter = raw * random.uniform(-0.2, 0.2)
        backoff = max(0.3, min(raw + jitter, TS_BACKOFF_MAX_SECONDS))

        if self.consecutive_eof >= TS_CONSECUTIVE_EOF_BACKOFF_START:
            eof_extra = min(
                TS_CONSECUTIVE_EOF_BACKOFF_MAX,
                (self.consecutive_eof - TS_CONSECUTIVE_EOF_BACKOFF_START + 1) * TS_CONSECUTIVE_EOF_BACKOFF_STEP
            )
            if eof_extra > backoff:
                backoff = eof_extra

        if self.last_error_code in (401, 403, 404, 406, 410, 451):
            if TS_AUTH_FAILURE_CIRCUIT_WAIT > backoff:
                backoff = TS_AUTH_FAILURE_CIRCUIT_WAIT

        return backoff

    def _run(self):
        while self.active and not self.stopped:
            self.last_error = None
            self.last_error_code = None
            try:
                self._connect_and_read()
            except urllib.error.HTTPError as e:
                self.last_error = e
                self.last_error_code = e.code
                _log(f"Worker-{self.worker_id} HTTP {e.code}", "DEBUG")
                # FIX v32.3: alinhado ao set completo de has_auth_error() —
                # antes só girava identidade em 403/429/401, deixando
                # 404/406/410/451 sem nenhuma tentativa de fingerprint novo
                # no worker individual (esperava só o refresh do coordinator)
                if e.code in (401, 403, 404, 406, 410, 429, 451):
                    self.ctx.rotate_identity()
                    if self.target_host: DOH_RESOLVER.invalidate(self.target_host)
            except Exception as e:
                self.last_error = e
                _log(f"Worker-{self.worker_id} {type(e).__name__}: {str(e)[:60]}", "DEBUG")
                self.ctx.rotate_identity()
                if self.target_host: DOH_RESOLVER.invalidate(self.target_host)

            self.is_connected = False
            self._close_connection()

            if not self.active or self.stopped: break

            self.reconnect_num += 1
            backoff = self._calculate_backoff()
            time.sleep(backoff)

    def _connect_and_read(self):
        ctx = self.ctx
        url_to_fetch = ctx.resolved_url or ctx.original_url
        parsed = urllib.parse.urlparse(url_to_fetch)

        opener = _ts_create_worker_opener()
        headers = _ts_build_headers(ctx.ua, ctx.lang, ctx.enc, referer=ctx.original_url, host=parsed.hostname)
        req = urllib.request.Request(url_to_fetch, headers=headers)
        self.target_host = parsed.hostname

        try:
            # AUMENTADO PARA 10.0s PARA DAR TEMPO AO DOH RESOLVER
            self.response = opener.open(req, timeout=10.0)
        except Exception:
            if self.target_host: DOH_RESOLVER.invalidate(self.target_host)
            raise

        try:
            self.response.fp.raw._sock.settimeout(TS_READ_CHUNK_DEADLINE)
        except Exception:
            pass

        self.is_connected = True
        self.leftover = bytearray()
        first_read = True

        while self.active and not self.stopped:
            try:
                raw, self.leftover = self._read_aligned_chunk(self.response, self.leftover)
            except socket.timeout:
                break
            except Exception:
                break

            if not raw:
                if first_read:
                    self.consecutive_eof += 1
                else:
                    self.consecutive_eof = 0
                break

            first_read = False
            self.consecutive_eof = 0
            self.last_data_at = time.time()
            self.bytes_read += len(raw)
            ctx.total_bytes_streamed += len(raw)

            try:
                self.queue.put_nowait(raw)
            except queue.Full:
                try: self.queue.get_nowait()
                except queue.Empty: pass
                try: self.queue.put_nowait(raw)
                except queue.Full: pass

        self.is_connected = False
        self._close_connection()

    def _read_aligned_chunk(self, response, leftover: bytearray):
        result_q: "queue.Queue" = queue.Queue(maxsize=1)

        def _do_read():
            try:
                data = response.read(TS_CHUNK_SIZE - len(leftover))
                try: result_q.put_nowait(('ok', data))
                except queue.Full: pass
            except Exception as e:
                try: result_q.put_nowait(('error', e))
                except queue.Full: pass

        reader_thread = threading.Thread(target=_do_read, daemon=True)
        reader_thread.start()
        try:
            kind, payload = result_q.get(timeout=TS_READ_CHUNK_DEADLINE)
        except queue.Empty:
            try: response.fp.raw._sock.shutdown(socket.SHUT_RDWR)
            except Exception: pass
            raise socket.timeout(f"leitura upstream sem completar em {TS_READ_CHUNK_DEADLINE:.0f}s")

        if kind == 'error':
            raise payload
        raw = payload
        if not raw:
            return b'', bytearray()

        data = leftover + raw
        leftover.clear()
        idx = data.find(TS_SYNC_BYTE)
        if idx == -1:
            return b'', bytearray()
        data = data[idx:]
        usable = len(data) - (len(data) % TS_PACKET_SIZE)
        if usable == 0:
            leftover.extend(data)
            return b'', leftover
        aligned = data[:usable]
        if usable < len(data):
            leftover.extend(data[usable:])
        return bytes(aligned), leftover

    def has_data(self) -> bool:
        return not self.queue.empty()

    def get(self, timeout: float = 0.05):
        try:
            return self.queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def is_stalled(self) -> bool:
        return (time.time() - self.last_data_at) > TS_WORKER_STALL_THRESHOLD

    def has_auth_error(self) -> bool:
        return self.last_error_code in (401, 403, 404, 406, 410, 451)

# ─────────────────────────────────────────────
#  TsParallelCoordinator — orquestra sutura e workers paralelos
# ─────────────────────────────────────────────
class TsParallelCoordinator:
    def __init__(self, ctx: TsStreamContext, num_workers: int = None):
        self.ctx = ctx
        self.num_workers = num_workers or TS_PARALLEL_WORKERS
        self.workers: List[TsStreamWorker] = []
        self.primary: Optional[TsStreamWorker] = None

        self.resync_buf = bytearray()
        self.need_suture = False
        self.suture_search_started_at = None
        self.consecutive_suture_deadline_hits = 0
        self.last_suture_heartbeat = 0.0

        self._last_url_check = time.time()
        self._last_auth_check = 0.0
        # FIX v32.2: edge-trigger para o episódio de "todos os workers em auth-fail".
        # Sem isso, enquanto os 3 workers ficam dormindo no backoff com
        # last_error_code de auth ainda setado, essa checagem (a cada 2s)
        # re-disparava a cada ciclo do loop, invalidando DoH e resetando
        # resolved_url pra URL original repetidamente durante o mesmo episódio
        # — isso apagava o resultado do resolve em background antes dele
        # "grudar", prolongando a fome de dados até o Kodi desistir.
        self._auth_invalidated_episode = False
        self._stop_flag = threading.Event()
        self._runner_thread: Optional[threading.Thread] = None

        self._url_resolve_thread: Optional[threading.Thread] = None
        self._url_resolve_in_progress = threading.Event()

    def start(self):
        for i in range(self.num_workers):
            w = TsStreamWorker(i, self.ctx)
            w.start()
            self.workers.append(w)
            if i < self.num_workers - 1:
                time.sleep(TS_WORKER_STAGGER_DELAY)
        _log(f"{self.num_workers} workers paralelos iniciados para {self.ctx.hostname}", "INFO")
        self._runner_thread = threading.Thread(target=self._run_loop, daemon=True, name="ts-coordinator")
        self._runner_thread.start()

    def stop(self):
        self._stop_flag.set()
        for w in self.workers:
            w.stop()
        for w in self.workers:
            if w.thread:
                w.thread.join(timeout=3.0)
        if self._runner_thread:
            self._runner_thread.join(timeout=3.0)

    def _find_best_worker(self) -> Optional[TsStreamWorker]:
        best, best_size = None, 0
        for w in self.workers:
            if not w.active or w.stopped: continue
            size = w.queue.qsize()
            if size > best_size:
                best, best_size = w, size
        return best

    def _switch_primary(self, new_worker: TsStreamWorker, reason: str = ""):
        old_id = self.primary.worker_id if self.primary else "?"
        was_already_searching = self.need_suture
        self.primary = new_worker
        self.ctx.ts_buf.clear_partial_buffer()

        if self.ctx.has_played_data:
            self.ctx.ts_buf.arm_discontinuity()
            self.ctx.last_discontinuity_at = time.time()
            self.need_suture = True
            self.resync_buf = bytearray()
            # FIX v32.4: só reinicia o relógio do watchdog (20s) ao ENTRAR
            # numa busca nova. Se já estávamos buscando (troca de worker no
            # meio de uma sutura ainda não resolvida — cascata de "failover
            # por stall" pegando sobras de dados velhos de outros workers),
            # preserva o started_at original. Sem isso, cada hop reiniciava
            # o cronômetro do zero e o give-up de 20s+2-strikes nunca
            # acumulava — a busca podia continuar indefinidamente sem cair
            # no fallback de aceitar descontinuidade e liberar algo real.
            if not was_already_searching:
                self.suture_search_started_at = time.time()
                self.last_suture_heartbeat = 0.0
        else:
            self.need_suture = False

        _log(f"Switch worker-{old_id} -> worker-{new_worker.worker_id} ({reason})", "INFO")

    def _check_auth_failures(self):
        now = time.time()
        if now - self._last_auth_check < 2.0: return
        self._last_auth_check = now
        auth_failing = [w for w in self.workers if w.has_auth_error()]
        all_failing = len(auth_failing) >= self.num_workers

        # FIX v32.2: level-triggered -> edge-triggered. Só invalida/renova 1x
        # por episódio (na transição pra "todos falhando"); enquanto o episódio
        # persiste, deixa a URL recém-resolvida em background ter chance de
        # ser usada pelos workers antes de qualquer novo reset. O episódio só
        # é considerado encerrado (podendo disparar de novo) quando pelo menos
        # 1 worker sai do estado de auth-failure.
        if not all_failing:
            self._auth_invalidated_episode = False
            return

        if self._auth_invalidated_episode:
            return

        self._auth_invalidated_episode = True
        self.ctx.consecutive_auth_failures += 1
        is_first_episode_in_streak = (self.ctx.consecutive_auth_failures == 1)
        _log(f"Todos os {self.num_workers} workers com erro de auth (streak #{self.ctx.consecutive_auth_failures}) — renovando URL + identidade", "ERROR")
        _ts_invalidate_cached_resolved_url(self.ctx.original_url)
        self.ctx.resolved_url = self.ctx.original_url
        # Reconectar com a MESMA identidade que acabou de falhar em auth nos
        # 3 workers ao mesmo tempo tem pouca chance de dar certo de novo —
        # gira UA/Accept-Language/Accept-Encoding junto com a URL, sempre.
        self.ctx.rotate_identity()
        for w in self.workers:
            if w.target_host:
                DOH_RESOLVER.invalidate(w.target_host)
            # FIX v32.4: só zera o backoff acumulado na 1ª falha do streak —
            # dá uma chance rápida pra URL+identidade nova. Se o streak
            # continuar (servidor seguindo rejeitando), NÃO reseta de novo:
            # deixa o backoff exponencial de cada worker crescer normalmente.
            # Resetar em toda falha (comportamento da v32.3) fazia o proxy
            # bater no servidor com mais frequência bem na hora que ele já
            # está rejeitando — tende a piorar/prolongar bloqueios por abuso
            # em vez de ajudar, exatamente o oposto do que backoff é pra fazer.
            if is_first_episode_in_streak:
                w.reconnect_num = 0
        self._last_url_check = now - TS_COORDINATOR_URL_REFRESH - 1.0

    def _try_resolve_url(self):
        now = time.time()
        if now - self._last_url_check < TS_COORDINATOR_URL_REFRESH: return
        if self._url_resolve_in_progress.is_set(): return
        self._last_url_check = now
        self._url_resolve_in_progress.set()

        def _resolve_bg():
            try:
                new_url = _ts_resolve_url_sync(self.ctx.ua, self.ctx.lang, self.ctx.enc, self.ctx.original_url)
                if new_url != self.ctx.resolved_url:
                    new_host = urllib.parse.urlparse(new_url).hostname
                    switched = bool(self.ctx.last_resolved_host and new_host and new_host != self.ctx.last_resolved_host)
                    if switched:
                        self.ctx.cdn_switch_count += 1
                        _log(f"CDN switch: {self.ctx.last_resolved_host} -> {new_host} (#{self.ctx.cdn_switch_count})", "ERROR")
                    self.ctx.resolved_url = new_url
                    self.ctx.last_resolved_host = new_host
            except Exception as e:
                _log(f"Falha ao re-resolver URL: {type(e).__name__}: {str(e)[:60]}", "ERROR")
            finally:
                self._url_resolve_in_progress.clear()

        self._url_resolve_thread = threading.Thread(target=_resolve_bg, daemon=True, name="ts-url-resolve")
        self._url_resolve_thread.start()

    def _process_suture(self, raw: bytes) -> Optional[bytes]:
        self.resync_buf.extend(raw)
        if len(self.resync_buf) > TS_SUTURE_WINDOW_LIMIT:
            excess = len(self.resync_buf) - TS_SUTURE_WINDOW_LIMIT
            del self.resync_buf[:excess]

        if self.suture_search_started_at:
            elapsed = time.time() - self.suture_search_started_at
            if elapsed >= TS_SUTURE_SEARCH_DEADLINE:
                self.consecutive_suture_deadline_hits += 1
                if self.consecutive_suture_deadline_hits >= TS_SUTURE_DEADLINE_CIRCUIT_THRESHOLD:
                    _log(f"Sutura excedeu {TS_SUTURE_SEARCH_DEADLINE:.0f}s — aceitando descontinuidade", "ERROR")
                    self.need_suture = False
                    self.consecutive_suture_deadline_hits = 0
                    remaining = bytes(self.resync_buf)
                    self.resync_buf = bytearray()
                    self.ctx.ts_buf.clear_partial_buffer()
                    self.ctx.ts_buf.arm_discontinuity()
                    self.ctx.last_discontinuity_at = time.time()
                    return self._finalize_payload(self.ctx.ts_buf.feed(remaining))
                else:
                    replacement = self._find_best_worker()
                    if replacement and replacement != self.primary:
                        self._switch_primary(replacement, "suture deadline")
                    return None

            if elapsed - self.last_suture_heartbeat >= TS_SUTURE_SEARCH_HEARTBEAT_INTERVAL:
                _log(f"Buscando sutura ({elapsed:.1f}s, janela: {len(self.resync_buf)}B)", "DEBUG")
                self.last_suture_heartbeat = elapsed

        tail = self.ctx.get_tail()
        if len(tail) >= 512:
            needle = tail[-512:]
            suture_idx = self.resync_buf.find(needle)
            if suture_idx != -1:
                suture_point = suture_idx + 512
                _log(f"Sutura encontrada! Pulando {suture_point} bytes já reproduzidos.", "INFO")
                self.need_suture = False
                self.consecutive_suture_deadline_hits = 0
                remaining = bytes(self.resync_buf[suture_point:])
                self.resync_buf = bytearray()
                return self._finalize_payload(self.ctx.ts_buf.feed(remaining))
        elif len(tail) > 0:
            _log(f"Tail muito pequeno ({len(tail)}B) — aceitando descontinuidade", "ERROR")
            self.need_suture = False
            self.consecutive_suture_deadline_hits = 0
            remaining = bytes(self.resync_buf)
            self.resync_buf = bytearray()
            self.ctx.ts_buf.clear_partial_buffer()
            self.ctx.ts_buf.arm_discontinuity()
            self.ctx.last_discontinuity_at = time.time()
            return self._finalize_payload(self.ctx.ts_buf.feed(remaining))

        return None

    def _finalize_payload(self, payload: bytes) -> Optional[bytes]:
        if not payload: return None
        payload = _ts_strict_align(payload)
        self.ctx.add_played(payload)
        self.ctx.has_played_data = True
        self.ctx.update_activity()
        self.ctx.bytes_since_connect += len(payload)
        if self.ctx.bytes_since_connect >= TS_AUTH_FAILURE_RESET_BYTES:
            self.ctx.consecutive_auth_failures = 0
        return payload

    def _process_normal(self, raw: bytes) -> Optional[bytes]:
        payload = self.ctx.ts_buf.feed(raw)
        if payload:
            return self._finalize_payload(payload)
        self.ctx.update_activity()
        return None

    def _run_loop(self):
        last_null_pump = 0.0
        while self.ctx.active and not self._stop_flag.is_set():
            self._check_auth_failures()
            self._try_resolve_url()

            if self.primary is None or not self.primary.active or self.primary.stopped:
                best = self._find_best_worker()
                if best:
                    self._switch_primary(best, "atribuição inicial")
                else:
                    now = time.time()
                    if now - last_null_pump > 1.0:
                        self.ctx.push_output(TS_NULL_PUMP_BURST)
                        last_null_pump = now
                    time.sleep(0.05)
                    continue

            raw = self.primary.get(timeout=0.1)

            if raw is None:
                if self.primary.is_stalled():
                    replacement = self._find_best_worker()
                    if replacement and replacement != self.primary and replacement.has_data():
                        self._switch_primary(replacement, "failover por stall")
                        continue
                    if not self.primary.is_connected and not self.primary.active:
                        self.primary = None
                        continue
                now = time.time()
                if now - last_null_pump > 1.0:
                    self.ctx.push_output(TS_NULL_PUMP_BURST)
                    last_null_pump = now
                continue

            if self.need_suture:
                result = self._process_suture(raw)
            else:
                result = self._process_normal(raw)

            if result:
                self.ctx.push_output(result)

# ─────────────────────────────────────────────
#  SERVIDOR HTTP PROXY (KODI INTEGRATION)
# ─────────────────────────────────────────────
class TSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        _log(f"[NexusCore-TSProxy] {format % args}", "DEBUG")

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, OSError):
            self.close_connection = True

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError, ConnectionAbortedError):
            return False

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(400)
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Connection', 'keep-alive')
        self.end_headers()

        parsed_original = urllib.parse.urlparse(original_url)
        hostname = parsed_original.hostname or parsed_original.netloc

        ctx = TsStreamContext(original_url, hostname)
        
        try:
            ctx.resolved_url = _ts_resolve_url_sync(ctx.ua, ctx.lang, ctx.enc, ctx.original_url)
            ctx.last_resolved_host = urllib.parse.urlparse(ctx.resolved_url).hostname
        except Exception:
            pass

        coordinator = TsParallelCoordinator(ctx, TS_PARALLEL_WORKERS)
        coordinator.start()

        _log(f"Iniciando stream TS de {hostname} ({TS_PARALLEL_WORKERS} workers)", "INFO")

        try:
            while ctx.active:
                try:
                    chunk = ctx.out_queue.get(timeout=15.0)
                    if chunk:
                        if not self._safe_write(chunk):
                            break
                except queue.Empty:
                    if not ctx.active:
                        break
                    if not self._safe_write(TS_NULL_PUMP_BURST):
                        break
        finally:
            ctx.active = False
            coordinator.stop()
            _log(f"Stream finalizado: {hostname} (bytes: {ctx.total_bytes_streamed}, CDN switches: {ctx.cdn_switch_count})", "INFO")

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

_server_instance = None
_server_thread = None
_lock = threading.Lock()

def _ensure_server_running():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance is None:
            port = 0
            _server_instance = ThreadingHTTPServer(('127.0.0.1', port), TSProxyHandler)
            _server_thread = threading.Thread(target=_server_instance.serve_forever, daemon=True)
            _server_thread.start()
            actual_port = _server_instance.server_address[1]
            _log(f"✓ Servidor Single Session iniciado na porta {actual_port}", "INFO")
            return actual_port
        return _server_instance.server_address[1]

def get_proxy_url(stream_url: str, port: int = None) -> str:
    if port is None:
        port = _ensure_server_running()
    encoded_url = urllib.parse.quote(stream_url, safe='')
    return f"http://127.0.0.1:{port}/?url={encoded_url}"

def shutdown_proxy():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance:
            _server_instance.shutdown()
            _server_instance.server_close()
            _server_instance = None
            _server_thread = None