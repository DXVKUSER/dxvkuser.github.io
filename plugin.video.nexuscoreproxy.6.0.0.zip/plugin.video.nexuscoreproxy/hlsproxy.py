# -*- coding: utf-8 -*-
"""
==============================================================================
 HLS / IPTV Proxy  -  Versao 3.8.2-stable
==============================================================================
# NEXUS CORE HLS
# Author: Deivid Silva
==============================================================================
"""

import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import urllib3
import base64
import time
import random
import socket
import ssl
import os
import logging
import ipaddress
import gc
from collections import OrderedDict
from typing import Dict, Tuple, Optional, List
from concurrent.futures import ThreadPoolExecutor

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Regex global (usado por varios modulos)
_EXT_X_KEY_RE = re.compile(r'#EXT-X-KEY:([^\r\n]*)')
_URI_RE = re.compile(r'URI=(["\'])(.*?)\1')


# ---------------------------------------------------------------
# CONFIGURACAO DE LOGGING (OTIMIZADO PARA LOW-MEMORY)
# ---------------------------------------------------------------
def setup_proxy_logging():
    try:
        logger = logging.getLogger('HLSProxy')
        logger.setLevel(logging.WARNING)
        if not logger.handlers:
            console = logging.StreamHandler()
            console.setLevel(logging.WARNING)
            console.setFormatter(logging.Formatter(
                '[HLSProxy] %(levelname)s: %(message)s'))
            logger.addHandler(console)
        return logger
    except Exception:
        return logging.getLogger('HLSProxy')


logger = setup_proxy_logging()

# DEBUG LOG - defina True para ativar, False para silenciar
DEBUG_LOG = False


def _log_info(msg):
    if DEBUG_LOG:
        try: logger.info(msg)
        except Exception: pass

def _log_warn(msg):
    if DEBUG_LOG:
        try: logger.warning(msg)
        except Exception: pass

def _log_err(msg):
    if DEBUG_LOG:
        try: logger.error(msg)
        except Exception: pass


# ---------------------------------------------------------------
# PACKETS FILLER ESTÁTICOS (PRE-ALOCADOS NA RAM)
# ---------------------------------------------------------------
_NULL_PACKET = b'\x47\x1F\xFF\x10' + (b'\xFF' * 184)
_FOUR_NULL_PACKETS = _NULL_PACKET * 4

def generate_ts_filler(num_packets: int = 4) -> bytes:
    """Retorna pacotes pre-alocados para evitar overhead de CPU e GC."""
    if num_packets == 4:
        return _FOUR_NULL_PACKETS
    return _NULL_PACKET * num_packets


# ---------------------------------------------------------------
# DNS-over-HTTPS RESOLVER (OTIMIZADO O(1))
# ---------------------------------------------------------------
_DOH_PROVIDERS = ["https://cloudflare-dns.com/dns-query"]
_DOH_CACHE = OrderedDict()  # Otimizado para remocao FIFO O(1)
_DOH_CACHE_MAX = 20
_DOH_CACHE_LOCK = threading.Lock()

_DOH_SESSION = requests.Session()
_DOH_SESSION.verify = False
_DOH_SESSION.headers.update({
    "Accept": "application/dns-json",
    "User-Agent": "Mozilla/5.0",
})


def _is_ip_address(value: str) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def _resolve_system_dns(hostname: str, timeout: float = 1.5) -> Optional[str]:
    result: List[Optional[str]] = [None]

    def _do_resolve():
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
            for _family, _, _, _, sockaddr in infos:
                ip = sockaddr[0]
                if ip:
                    result[0] = ip
                    break
        except Exception as e:
            _log_info(f"system DNS thread failed for {hostname}: {e}")

    t = threading.Thread(target=_do_resolve, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]


def _resolve_doh(hostname: str, provider: str, timeout: float = 2.0) -> Optional[Tuple[str, int]]:
    try:
        r = _DOH_SESSION.get(provider, params={"name": hostname, "type": "A"}, timeout=timeout)
        if r.status_code != 200:
            return None
        data = r.json()
        if data.get("Status", -1) != 0:
            return None
        for answer in data.get("Answer", []):
            if answer.get("type") == 1:
                ip = answer["data"].strip()
                ttl = int(answer.get("TTL", 60))
                try:
                    ipaddress.IPv4Address(ip)
                    return ip, ttl
                except ValueError:
                    continue
    except Exception as e:
        _log_info(f"DoH provider {provider} failed for {hostname}: {e}")
    return None


def resolve_host_doh(hostname: str) -> Optional[str]:
    if not hostname or _is_ip_address(hostname):
        return hostname

    now = time.time()
    with _DOH_CACHE_LOCK:
        entry = _DOH_CACHE.get(hostname)
        if entry:
            ip, expiry = entry
            if now < expiry:
                return ip
            del _DOH_CACHE[hostname]

    sys_ip = _resolve_system_dns(hostname, timeout=1.5)
    if sys_ip:
        with _DOH_CACHE_LOCK:
            if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                _DOH_CACHE.popitem(last=False)  # Remocao O(1)
            _DOH_CACHE[hostname] = (sys_ip, now + 86400)
        return sys_ip

    for provider in _DOH_PROVIDERS:
        result = _resolve_doh(hostname, provider)
        if result:
            ip, ttl = result
            with _DOH_CACHE_LOCK:
                if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                    _DOH_CACHE.popitem(last=False)  # Remocao O(1)
                _DOH_CACHE[hostname] = (ip, now + 86400)
            return ip
    return None


def rewrite_url_with_doh(url: str) -> Tuple[str, str]:
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host or _is_ip_address(host):
        return url, ""

    ip = resolve_host_doh(host)
    if not ip:
        return url, ""

    port = parsed.port
    new_netloc = f"{ip}:{port}" if port else ip
    return urllib.parse.urlunparse(parsed._replace(netloc=new_netloc)), host


def invalidate_doh_cache(hostname: str):
    if hostname:
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.pop(hostname, None)


# ---------------------------------------------------------------
# PLAYER PROFILES
# ---------------------------------------------------------------
PLAYER_PROFILES = {
    'exoplayer': {'ua': 'ExoPlayer/Lavf60.3.100', 'accept': '*/*', 'connection': 'keep-alive'},
    'vlc': {'ua': 'VLC/3.0.20 Vetinari', 'accept': '*/*', 'connection': 'keep-alive'},
    'kodi': {'ua': 'Lavf/60.3.100', 'accept': '*/*', 'connection': 'keep-alive'}
}

DEVICE_PROFILES = [
    {'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0', 'accept': '*/*', 'accept_language': 'en-US,en;q=0.9', 'connection': 'keep-alive'},
    {'ua': 'VLC/3.0.20 LibVLC/3.0.20', 'accept': '*/*', 'accept_language': '', 'connection': 'close'},
    {'ua': 'Lavf/60.3.100', 'accept': '*/*', 'accept_language': '', 'connection': 'close'},
]


# ---------------------------------------------------------------
# TLS FINGERPRINT SPOOFER
# ---------------------------------------------------------------
class TLSContextRotator:
    def __init__(self):
        self._cached_context = None

    def create_context(self) -> ssl.SSLContext:
        if self._cached_context is not None:
            return self._cached_context

        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2

        try: ctx.set_ciphers('DEFAULT:@SECLEVEL=0')
        except ssl.SSLError:
            try: ctx.set_ciphers('DEFAULT:@SECLEVEL=1')
            except ssl.SSLError: pass

        self._cached_context = ctx
        return ctx


class TLSAdapter(requests.adapters.HTTPAdapter):
    def __init__(self, ssl_context, **kwargs):
        self.ssl_context = ssl_context
        super().__init__(**kwargs)

    def init_poolmanager(self, *args, **kwargs):
        kwargs['ssl_context'] = self.ssl_context
        return super().init_poolmanager(*args, **kwargs)

    def proxy_manager_for(self, proxy, **proxy_kwargs):
        proxy_kwargs['ssl_context'] = self.ssl_context
        return super().proxy_manager_for(proxy, **proxy_kwargs)


# ---------------------------------------------------------------
# ADAPTIVE BACKOFF
# ---------------------------------------------------------------
class AdaptiveBackoff:
    _STRATEGIES = [
        lambda n, base: base * (2 ** min(n, 6)) * random.uniform(0.5, 1.5),
        lambda n, base: base * (n ** 1.3) * random.uniform(0.7, 1.4),
        lambda n, base: base * random.uniform(0.5, min(15, n * 1.8)),
    ]

    def calculate(self, retry_num, error_type='network', was_blocked=False,
                  content_kind='playlist'):
        base_delays = {'network': 0.15, 'http': 0.3, 'timeout': 0.2, 'reset': 0.1, 'blocked': 1.5, 'forbidden': 2.5}
        base = base_delays.get(error_type, 0.2)
        if was_blocked:
            base = max(base, 1.0)
        delay = max(0.05, random.choice(self._STRATEGIES)(retry_num, base) + random.gauss(0, 0.02))
        # FIX v3.8.0: Para segmentos, cap de 3s (antes 8s).
        # Backoff longo trava o buffer do Kodi — falha rapida e retry imediato
        # e preferivel para streams live.
        if content_kind == 'segment':
            return min(3.0, delay)
        return min(8.0, delay)


# ---------------------------------------------------------------
# BLOCK DETECTION & PLAYLIST VALIDATION
# ---------------------------------------------------------------
def detect_block_response(response, content_kind='playlist'):
    if response.status_code in (403, 429, 451, 401):
        return True, f'http_{response.status_code}'

    if content_kind == 'playlist' and response.status_code == 200:
        content_type = response.headers.get('Content-Type', '').lower()
        if 'text/html' in content_type or 'application/json' in content_type:
            if 'mpegurl' in content_type or 'm3u' in content_type:
                return False, ''
            return True, 'wrong_content_type'
    return False, ''


def is_valid_playlist(content: bytes) -> bool:
    return content and len(content) >= 20 and b'#EXTM3U' in content[:500]


def is_raw_mpeg_ts(content: bytes) -> bool:
    if not content or len(content) < 188:
        return content and len(content) >= 4 and content[0] == 0x47
    return content[0] == 0x47


def make_synthetic_playlist_for_ts(ts_url: str, target_duration: int = 6) -> bytes:
    return f"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:{target_duration}\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:{target_duration}.0,\n{ts_url}".encode('utf-8')


def looks_like_html_error(content: bytes) -> bool:
    if not content or len(content) < 20:
        return False
    head = content[:300].lower()
    return b'<!doctype html' in head or b'<html' in head


# ---------------------------------------------------------------
# CACHES OTIMIZADOS EM MEMÓRIA (ORDENADOS / COMPLEXIDADE O(1))
# ---------------------------------------------------------------
class ShadowPlaylistCache:
    def __init__(self):
        self._store = OrderedDict()
        self._lock = threading.Lock()

    def update(self, playlist_url: str, content: bytes, media_sequence: int, target_duration: int):
        with self._lock:
            if len(self._store) >= 5:
                self._store.popitem(last=False)  # Remocao instantanea do mais antigo
            self._store[playlist_url] = {'content': content, 'timestamp': time.time()}

    def get(self, playlist_url: str) -> Optional[bytes]:
        with self._lock:
            entry = self._store.get(playlist_url)
            if entry and (time.time() - entry['timestamp'] < 300):
                return entry['content']
        return None

    def clear(self, playlist_url: str = None):
        with self._lock:
            if playlist_url: self._store.pop(playlist_url, None)
            else: self._store.clear()


shadow_playlist_cache = ShadowPlaylistCache()


class LastGoodSegmentCache:
    def __init__(self):
        self._content: Optional[bytes] = None
        self._timestamp: float = 0
        self._lock = threading.Lock()

    def update(self, content: bytes):
        if not content or len(content) < 188:
            return
        with self._lock:
            self._content = content[:512 * 1024] if len(content) > 512 * 1024 else content
            self._timestamp = time.time()

    def get(self) -> Optional[bytes]:
        with self._lock:
            if self._content and (time.time() - self._timestamp < 60):
                return self._content
        return None


last_good_segment = LastGoodSegmentCache()


class PlaylistStallDetector:
    def __init__(self):
        self._states = OrderedDict()
        self._lock = threading.Lock()

    def update(self, playlist_url: str, media_sequence: int, target_duration: int) -> bool:
        now = time.time()
        td = target_duration or 6
        with self._lock:
            state = self._states.get(playlist_url)
            if not state:
                if len(self._states) >= 10:
                    self._states.popitem(last=False)
                self._states[playlist_url] = {'last_sequence': media_sequence, 'last_change_time': now, 'target_duration': td}
                return False

            if media_sequence != state['last_sequence']:
                state['last_sequence'] = media_sequence
                state['last_change_time'] = now
                return False

            if now - state['last_change_time'] >= (td * 3):
                state['last_change_time'] = now
                return True
        return False

    def clear(self, playlist_url: str = None):
        with self._lock:
            if playlist_url: self._states.pop(playlist_url, None)
            else: self._states.clear()


stall_detector = PlaylistStallDetector()


class StreamAnalyzer:
    def __init__(self):
        self.states = OrderedDict()
        self.lock = threading.Lock()

    def update_playlist(self, base_url, target_duration, media_sequence, seg_urls):
        with self.lock:
            if base_url not in self.states:
                if len(self.states) >= 5:
                    self.states.popitem(last=False)
                self.states[base_url] = {'target_duration': target_duration or 6, 'last_update': time.time()}
            state = self.states[base_url]
            state['last_update'] = time.time()
            return seg_urls[-3:] if len(seg_urls) > 3 else seg_urls

    def update_segment_size(self, base_url, size_bytes):
        with self.lock:
            if base_url in self.states:
                self.states[base_url]['last_size'] = size_bytes

    def get_prefetch_count(self, base_url):
        return 0


analyzer = StreamAnalyzer()


# ---------------------------------------------------------------
# FIX CRITICO: NORMALIZADOR DE MEDIA-SEQUENCE
# Garante que a sequência entregue ao Kodi seja sempre monotonicamente
# crescente, evitando "Media sequence changed unexpectedly" e freeze.
# O CDN pode resetar o contador (ex: 1269->145) entre polls — o proxy
# absorve o reset e mantém a sequência contínua para o Kodi.
# ---------------------------------------------------------------
class MediaSequenceNormalizer:
    def __init__(self):
        self._lock = threading.Lock()
        # Por URL de playlist: (ultimo_seq_cdn, offset_acumulado, seq_proxy)
        self._state: Dict[str, dict] = {}

    def normalize(self, playlist_url: str, cdn_seq: int) -> int:
        with self._lock:
            st = self._state.get(playlist_url)
            if st is None:
                # Primeira vez: inicia o proxy-seq a partir do cdn_seq
                self._state[playlist_url] = {
                    'last_cdn_seq': cdn_seq,
                    'proxy_seq': cdn_seq,
                    'offset': 0,
                }
                return cdn_seq

            last = st['last_cdn_seq']
            # CDN avançou normalmente
            if cdn_seq >= last:
                advance = cdn_seq - last
                st['proxy_seq'] += advance
                st['last_cdn_seq'] = cdn_seq
            else:
                # CDN RESETOU (ex: 1269->145) — absorve sem afetar o Kodi
                # Incrementa o proxy-seq por 1 para indicar progresso
                st['proxy_seq'] += 1
                st['last_cdn_seq'] = cdn_seq
                _log_warn(f"[SeqNorm] CDN seq reset {last}->{cdn_seq}, proxy_seq={st['proxy_seq']}")

            return st['proxy_seq']

    def clear(self, playlist_url: str = None):
        with self._lock:
            if playlist_url:
                self._state.pop(playlist_url, None)
            else:
                self._state.clear()


media_seq_normalizer = MediaSequenceNormalizer()


# ---------------------------------------------------------------
# v3.8.1 / OTIMIZADO EM v3.8.2: MANIFEST REFERENCE CACHE (REF)
#
# Segunda camada de recuperacao de segmentos, complementar ao
# TokenRefresher. Sempre que rewrite_manifest() processa uma playlist,
# cada segmento absoluto encontrado tem sua referencia registrada aqui:
# de qual manifest (original e final) ele veio e qual referer foi usado
# para buscar aquele manifest. Isso permite, em caso de falha de um
# segmento, re-baixar o manifest de origem e localizar a URL renovada
# do mesmo segmento (por pathname, ignorando querystring/token).
#
# Estrutura: dict simples (nao precisa de ordem), chave = segment_url,
# valor = {'manifest_original', 'manifest_final', 'referer', 'timestamp'}.
# Acesso O(1). Protegido por Lock para uso concorrente entre threads
# (o servidor e ThreadingHTTPServer, varias requests simultaneas).
# TTL: 45s (dentro da faixa recomendada de 30-60s).
# Cache 100% em memoria, nunca persistido em disco.
#
# OTIMIZACAO v3.8.2:
#   1) register() agora faz "dirty check" O(1) antes de escrever: se a
#      entrada ja existe, ainda esta com menos da metade do TTL de idade
#      E o manifest_original nao mudou, o registro e um NO-OP (apenas
#      "toca" o timestamp), evitando reconstrucao do dict entry a cada
#      poll de playlist para segmentos que ja estavam corretos.
#   2) A cada _REGISTER_SAMPLE_INTERVAL chamadas de register() (independente
#      de cheio ou nao), roda uma varredura amortizada de expirados —
#      isso evita que canais de baixo trafego acumulem entradas mortas
#      indefinidamente sem nunca bater o limite de _MAX_ENTRIES.
# ---------------------------------------------------------------
class ManifestReferenceCache:
    _TTL_SECONDS = 45.0
    _MAX_ENTRIES = 400  # protege contra crescimento sem limite
    _REGISTER_SAMPLE_INTERVAL = 64  # varredura amortizada a cada N registros

    def __init__(self):
        self._store: Dict[str, dict] = {}
        self._lock = threading.Lock()
        self._register_count = 0  # contador interno para amostragem de limpeza

    def register(self, segment_url: str, manifest_original: str,
                 manifest_final: str, referer: Optional[str]):
        """Registra/atualiza a referencia de um segmento. O(1) amortizado.

        OTIMIZACAO v3.8.2: se a entrada ja existe, ainda esta "fresca"
        (idade < metade do TTL) e aponta para o mesmo manifest_original,
        evita reescrever o dict entry inteiro — apenas atualiza o timestamp.
        Isso reduz drasticamente trabalho redundante em streams estaveis,
        onde a mesma playlist e reprocessada a cada poll (2-6s) e a grande
        maioria dos segmentos ja estao corretamente registrados.
        """
        if not segment_url:
            return
        now = time.time()
        with self._lock:
            existing = self._store.get(segment_url)
            if (existing is not None
                    and existing['manifest_original'] == manifest_original
                    and (now - existing['timestamp']) < (self._TTL_SECONDS * 0.5)):
                # Dirty check: nada mudou e a entrada ainda esta bem viva —
                # apenas "toca" o timestamp (extensao barata do TTL) sem
                # realocar o dicionario de valores.
                existing['timestamp'] = now
                self._maybe_sample_cleanup_locked(now)
                return

            # Auto-limpeza leve: se o dict cresceu demais, remove um
            # punhado das entradas mais antigas antes de inserir a nova.
            if len(self._store) >= self._MAX_ENTRIES:
                self._evict_expired_locked(now)
                if len(self._store) >= self._MAX_ENTRIES:
                    # ainda cheio (tudo valido) — remove as 50 mais antigas
                    oldest = sorted(self._store.items(), key=lambda kv: kv[1]['timestamp'])[:50]
                    for old_key, _ in oldest:
                        self._store.pop(old_key, None)

            self._store[segment_url] = {
                'segment_url': segment_url,
                'manifest_original': manifest_original,
                'manifest_final': manifest_final,
                'referer': referer,
                'timestamp': now,
            }
            self._maybe_sample_cleanup_locked(now)

    def _maybe_sample_cleanup_locked(self, now: float):
        """Roda uma varredura de expirados a cada _REGISTER_SAMPLE_INTERVAL
        chamadas de register(), independente do cache estar cheio.
        Deve ser chamado com o lock ja adquirido. Custo amortizado: O(n)
        apenas 1 a cada N escritas, nunca no caminho de leitura (lookup).
        """
        self._register_count += 1
        if (self._register_count % self._REGISTER_SAMPLE_INTERVAL) == 0:
            self._evict_expired_locked(now)

    def lookup(self, segment_url: str) -> Optional[dict]:
        """Consulta a referencia de um segmento. O(1). Remove se expirada."""
        if not segment_url:
            return None
        now = time.time()
        with self._lock:
            entry = self._store.get(segment_url)
            if not entry:
                return None
            if (now - entry['timestamp']) >= self._TTL_SECONDS:
                self._store.pop(segment_url, None)
                return None
            return entry

    def _evict_expired_locked(self, now: float):
        """Remove entradas expiradas. Deve ser chamado com o lock ja adquirido."""
        expired_keys = [k for k, v in self._store.items()
                         if (now - v['timestamp']) >= self._TTL_SECONDS]
        for k in expired_keys:
            self._store.pop(k, None)

    def cleanup_expired(self):
        """Varredura publica de limpeza (O(n) no numero de entradas atuais,
        chamada oportunisticamente, nunca no caminho quente de reproducao)."""
        now = time.time()
        with self._lock:
            self._evict_expired_locked(now)

    def clear(self):
        with self._lock:
            self._store.clear()
            self._register_count = 0


manifest_reference_cache = ManifestReferenceCache()


def find_manifest_reference(segment_url: str) -> Optional[Tuple[str, str, Optional[str]]]:
    """
    Consulta o ManifestReferenceCache (REF) para um segment_url.
    Retorna (manifest_original, manifest_final, referer) se existir e nao
    estiver expirado, caso contrario None. Complexidade O(1).
    """
    entry = manifest_reference_cache.lookup(segment_url)
    if not entry:
        return None
    return entry['manifest_original'], entry['manifest_final'], entry['referer']


# Cache de playlist de curtissima duracao (2-3s) usado exclusivamente pelo
# heal_segment_using_ref(), para evitar baixar o mesmo manifest repetidas
# vezes quando varios segmentos falham em sequencia dentro de uma janela
# curta. Independente do _playlist_cache do TokenRefresher (nao remove nem
# substitui nada existente).
_REF_HEAL_PLAYLIST_TTL = 2.5
_ref_heal_playlist_cache: Dict[str, Tuple[float, bytes, str]] = {}
_ref_heal_playlist_lock = threading.Lock()

# OTIMIZACAO v3.8.2: dedupe de fetch concorrente por manifest_original.
# Antes, se N segmentos falhassem "ao mesmo tempo" (blip de CDN ou troca
# de qualidade), cada thread checava o cache curto, via vazio, e disparava
# seu proprio download do MESMO manifest — desperdicio de rede e CPU.
# Agora existe um Lock por manifest_original (criado sob demanda), entao
# apenas a primeira thread busca; as demais aguardam nesse lock e, ao
# adquiri-lo, encontram o cache ja preenchido pela primeira (double-checked
# locking classico). O dict de locks e limitado/limpo de forma simples
# para nao crescer sem controle.
_ref_heal_fetch_locks: Dict[str, threading.Lock] = {}
_ref_heal_fetch_locks_guard = threading.Lock()
_REF_HEAL_FETCH_LOCKS_MAX = 50


def _get_ref_heal_fetch_lock(manifest_original: str) -> threading.Lock:
    with _ref_heal_fetch_locks_guard:
        lock = _ref_heal_fetch_locks.get(manifest_original)
        if lock is None:
            if len(_ref_heal_fetch_locks) >= _REF_HEAL_FETCH_LOCKS_MAX:
                # limpeza simples: descarta um item arbitrario (nao critico,
                # apenas evita crescimento ilimitado; na pior hipotese duas
                # threads relativas a manifests diferentes usam o mesmo lock
                # por uma janela curta, o que e apenas uma serializacao extra
                # inofensiva, nunca incorretude).
                _ref_heal_fetch_locks.pop(next(iter(_ref_heal_fetch_locks)), None)
            lock = threading.Lock()
            _ref_heal_fetch_locks[manifest_original] = lock
        return lock


def _ref_heal_fetch_manifest(manifest_original: str, referer: Optional[str]) -> Optional[Tuple[bytes, str]]:
    """Baixa (ou reaproveita do cache curto) o manifest usado para localizar
    a nova URL de um segmento. Usa fetch_response() como pedido.

    OTIMIZACAO v3.8.2: dedupe entre threads concorrentes via lock por
    manifest_original (double-checked locking), evitando N downloads
    identicos quando N segmentos falham na mesma janela de tempo.
    """
    now = time.time()
    with _ref_heal_playlist_lock:
        cached = _ref_heal_playlist_cache.get(manifest_original)
        if cached and (now - cached[0]) < _REF_HEAL_PLAYLIST_TTL:
            return cached[1], cached[2]

    fetch_lock = _get_ref_heal_fetch_lock(manifest_original)
    with fetch_lock:
        # Re-checa apos adquirir o lock: outra thread pode ja ter
        # preenchido o cache enquanto esperavamos.
        now = time.time()
        with _ref_heal_playlist_lock:
            cached = _ref_heal_playlist_cache.get(manifest_original)
            if cached and (now - cached[0]) < _REF_HEAL_PLAYLIST_TTL:
                return cached[1], cached[2]

        r, final_url = fetch_response(manifest_original, referer, max_retries=1,
                                       consistent_ua=True, content_kind='playlist')
        if not r:
            return None
        try:
            content = _read_response_full(r)
        except Exception:
            content = b''
        if not content or not is_valid_playlist(content):
            return None

        with _ref_heal_playlist_lock:
            # limpeza simples para nao crescer sem limite (janela e curta,
            # entao poucos manifests distintos coexistem por vez)
            if len(_ref_heal_playlist_cache) >= 30:
                oldest_key = min(_ref_heal_playlist_cache, key=lambda k: _ref_heal_playlist_cache[k][0])
                _ref_heal_playlist_cache.pop(oldest_key, None)
            _ref_heal_playlist_cache[manifest_original] = (now, content, final_url)

        return content, final_url


def _segment_match_key(url: str) -> str:
    """Normaliza uma URL de segmento para comparacao ignorando querystring:
    usa apenas o pathname/nome do arquivo (ultimo componente do path)."""
    try:
        path = urllib.parse.urlparse(url).path
    except Exception:
        path = url
    if not path:
        return url
    return path.rsplit('/', 1)[-1]


def heal_segment_using_ref(segment_url: str) -> Optional[str]:
    """
    Segunda camada de recuperacao (REF), usada somente apos fetch_response()
    e TokenRefresher() falharem para um segmento.

    Fluxo:
      1. Consulta ManifestReferenceCache para achar de qual manifest esse
         segmento veio (e qual referer foi usado — v3.8.2: propagado de
         verdade em vez de sempre None).
      2. Baixa novamente esse manifest (com cache curto de ~2.5s e dedupe
         de fetch concorrente entre threads — v3.8.2).
      3. Reprocessa o manifest e localiza o mesmo segmento comparando apenas
         o nome do arquivo/pathname, ignorando querystring/token.
      4. Retorna a URL absoluta renovada do segmento, ou None se nao
         encontrar referencia ou nao localizar o segmento no novo manifest.

    O(1) para o lookup no REF; o custo real (rede) so ocorre em caso de
    falha, nunca durante reproducao normal.
    """
    ref = find_manifest_reference(segment_url)
    if not ref:
        return None
    manifest_original, _manifest_final_old, referer = ref

    fetched = _ref_heal_fetch_manifest(manifest_original, referer)
    if not fetched:
        return None
    content, new_final_url = fetched

    target_key = _segment_match_key(segment_url)
    if not target_key:
        return None

    try:
        lines = (line.strip() for line in content.decode('utf-8', errors='ignore').split('\n') if line)
    except Exception:
        return None

    for line in lines:
        if line.startswith("#"):
            # OTIMIZACAO v3.8.2: curto-circuito imediato para qualquer tag —
            # nenhuma tag de metadado (#EXT-X-KEY, #EXT-X-MAP, #EXTINF, etc.)
            # e candidata a segmento, entao nem entra na logica de urljoin.
            continue
        abs_url = urllib.parse.urljoin(new_final_url, line)
        if _segment_match_key(abs_url) == target_key:
            return abs_url

    return None


# ---------------------------------------------------------------
# GESTÃO GERENCIADA DE CACHE LRU ADAPTATIVO
# ---------------------------------------------------------------
backoff_engine = AdaptiveBackoff()
prefetch_executor = ThreadPoolExecutor(max_workers=2)
URL_CACHE = OrderedDict()
URL_CACHE_MAX = 10
SEGMENT_LRU = OrderedDict()
CACHE_LOCK = threading.Lock()

_SEGMENT_CACHE_MIN = 2
_SEGMENT_CACHE_MAX = 8

def _get_adaptive_segment_cache_size() -> int:
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemAvailable:'):
                    if (int(line.split()[1]) // 1024) >= 20:
                        return _SEGMENT_CACHE_MAX
                    return 3
    except Exception: pass
    return _SEGMENT_CACHE_MIN


PROXY_VERSION = "3.8.2-stable"


# ---------------------------------------------------------------
# FIX CRITICO: CANCEL TOKEN POR CANAL
# Permite cancelar requests de um canal anterior quando o usuário
# troca de canal, evitando threads e conexões penduradas.
# ---------------------------------------------------------------
class ChannelCancelToken:
    """Token de cancelamento por sessão de canal."""
    def __init__(self):
        self._lock = threading.Lock()
        self._cancelled = False

    def cancel(self):
        with self._lock:
            self._cancelled = True

    @property
    def is_cancelled(self) -> bool:
        with self._lock:
            return self._cancelled


# Token global do canal ativo. Substituído a cada play_stream().
_current_cancel_token: Optional[ChannelCancelToken] = None
_cancel_token_lock = threading.Lock()


def get_cancel_token() -> Optional[ChannelCancelToken]:
    with _cancel_token_lock:
        return _current_cancel_token


def new_cancel_token() -> ChannelCancelToken:
    global _current_cancel_token
    with _cancel_token_lock:
        if _current_cancel_token is not None:
            _current_cancel_token.cancel()
        _current_cancel_token = ChannelCancelToken()
        return _current_cancel_token


# ---------------------------------------------------------------
# SESSÃO HTTP GERAL
# ---------------------------------------------------------------
class ProxySession:
    def __init__(self):
        self.current_profile = 'kodi'
        self.session_lock = threading.Lock()
        self.blocked_count = 0
        self._tls_rotator = TLSContextRotator()
        # FIX: flag para evitar reset durante shutdown
        self._shutting_down = False
        self.init_session()

    def init_session(self):
        with self.session_lock:
            self.session = requests.Session()
            self.session.verify = False
            ssl_ctx = self._tls_rotator.create_context()

            tls_adapter = TLSAdapter(ssl_context=ssl_ctx, pool_connections=10, pool_maxsize=10)
            self.session.mount('https://', tls_adapter)
            self.session.mount('http://', requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=10))

    def force_reset(self):
        # FIX: Não faz reset se estiver encerrando
        if self._shutting_down:
            return
        old_session = None
        with self.session_lock:
            old_session = self.session
        # FIX: fecha a sessão FORA do lock para não bloquear requests em curso
        if old_session:
            try:
                old_session.close()
            except Exception:
                pass
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.clear()
        self.init_session()
        gc.collect()

    def shutdown(self):
        """Encerra a sessão de forma segura."""
        self._shutting_down = True
        try:
            self.session.close()
        except Exception:
            pass

    def set_profile(self, profile_name):
        if profile_name in PLAYER_PROFILES:
            self.current_profile = profile_name

    def mark_blocked(self):
        self.blocked_count += 1
        if self.blocked_count >= 2:
            self.force_reset()
            self.blocked_count = 0

    def mark_success(self):
        if self.blocked_count > 0:
            self.blocked_count -= 1

    def get_headers(self, url, referer=None, reconnect_num=0, consistent_ua=False):
        parsed = urllib.parse.urlparse(url)
        device = PLAYER_PROFILES.get(self.current_profile, PLAYER_PROFILES['kodi']) if (consistent_ua or self.blocked_count == 0) else random.choice(DEVICE_PROFILES)

        netloc = parsed.netloc
        scheme = parsed.scheme or 'https'

        headers = {
            'User-Agent': device.get('ua', 'Lavf/60.3.100'),
            'Accept': device.get('accept', '*/*'),
            'Accept-Language': device.get('accept_language', 'en-US,en;q=0.9'),
            'Host': netloc,
            'Origin': f"{scheme}://{netloc}",
            'Connection': device.get('connection', 'keep-alive'),
            'Referer': referer or f"{scheme}://{netloc}/"
        }
        if self.current_profile in ('kodi', 'vlc'):
            headers['Icy-MetaData'] = '0'
        return headers


proxy_session = ProxySession()


def get_base_url_for_segment(url):
    with CACHE_LOCK:
        for cached_url, f_url in list(URL_CACHE.items()):
            if url.startswith(str(f_url).rsplit('/', 1)[0]):
                return f_url
    return None


_REDIRECT_STATUSES = (301, 302, 303, 307, 308)
_MAX_REDIRECTS = 8

# FIX CRITICO: Lock global removido.
# Antes: _IPTV_CONNECTION_LOCK serializava TODAS as requests (playlist + segmento).
# Isso causava starvation quando o Kodi pedia playlist e segmento simultaneamente.
# Agora cada request corre de forma independente com seu próprio timeout.


# FIX v3.8.0: Timeouts separados por tipo de conteudo.
# Segmentos: connect=5s, read=20s (logs mostram CDN levando 8-12s por segmento).
# Playlist: connect=3s, read=8s (arquivo pequeno, deve ser rapido).
# Key: connect=6s, read=10s (inalterado, critico para decriptografia).
_TIMEOUT_SEGMENT = (5.0, 20.0)
_TIMEOUT_PLAYLIST = (3.0, 8.0)
_TIMEOUT_KEY = (6.0, 10.0)


def _get_content_timeout(content_kind: str, timeout_connect: float, timeout_read: float):
    """Retorna (connect, read) otimizados por tipo, respeitando overrides explícitos."""
    if content_kind == 'segment':
        return (_TIMEOUT_SEGMENT[0] if timeout_connect == 3.0 else timeout_connect,
                _TIMEOUT_SEGMENT[1] if timeout_read == 6.0 else timeout_read)
    if content_kind == 'key':
        return (_TIMEOUT_KEY[0] if timeout_connect == 3.0 else timeout_connect,
                _TIMEOUT_KEY[1] if timeout_read == 6.0 else timeout_read)
    return (_TIMEOUT_PLAYLIST[0] if timeout_connect == 3.0 else timeout_connect,
            _TIMEOUT_PLAYLIST[1] if timeout_read == 6.0 else timeout_read)


def fetch_response(url, referer=None, max_retries=2, force_ua_rotate=False,
                   consistent_ua=False, timeout_connect=3.0, timeout_read=6.0,
                   content_kind='playlist', cancel_token=None):
    # FIX: sem lock global — cada request é independente
    # FIX v3.8.0: timeout ajustado por content_kind
    tc, tr = _get_content_timeout(content_kind, timeout_connect, timeout_read)
    return _fetch_response_impl(url, referer, max_retries, force_ua_rotate,
                                consistent_ua, tc, tr,
                                content_kind, cancel_token)


def _fetch_response_impl(url, referer=None, max_retries=2, force_ua_rotate=False,
                         consistent_ua=False, timeout_connect=3.0, timeout_read=6.0,
                         content_kind='playlist', cancel_token=None):
    current_url = url
    current_referer = referer
    retry_count = 0
    was_blocked = False
    error_type = 'network'

    while retry_count <= max_retries:
        # FIX: Verifica cancelamento antes de cada tentativa
        if cancel_token and cancel_token.is_cancelled:
            _log_info(f"fetch_response: request cancelada para {url}")
            return None, current_url

        if retry_count > 0:
            delay = backoff_engine.calculate(retry_count, error_type, was_blocked)
            time.sleep(delay)

        redirect_count = 0
        while redirect_count < _MAX_REDIRECTS:
            # FIX: Verifica cancelamento dentro do loop de redirect também
            if cancel_token and cancel_token.is_cancelled:
                return None, current_url

            try:
                if force_ua_rotate and retry_count > 0:
                    _orig_bc = proxy_session.blocked_count
                    proxy_session.blocked_count = max(1, _orig_bc)
                    headers = proxy_session.get_headers(current_url, current_referer, retry_count)
                    proxy_session.blocked_count = _orig_bc
                else:
                    headers = proxy_session.get_headers(current_url, current_referer, retry_count, consistent_ua=consistent_ua)

                fetch_url, doh_host = rewrite_url_with_doh(current_url)
                if doh_host:
                    headers['Host'] = doh_host
                    scheme_orig = urllib.parse.urlparse(current_url).scheme or 'https'
                    headers['Origin'] = f"{scheme_orig}://{doh_host}"
                    headers['Referer'] = current_referer or f"{scheme_orig}://{doh_host}/"
                else:
                    fetch_url = current_url

                # FIX: Copia a sessão de forma thread-safe sem segurar o lock durante a request
                with proxy_session.session_lock:
                    s = proxy_session.session

                r = s.get(fetch_url, headers=headers,
                          timeout=(timeout_connect, timeout_read),
                          allow_redirects=False, stream=True)

                if r.status_code in _REDIRECT_STATUSES:
                    location = r.headers.get('Location')
                    r.close()
                    if not location: return None, current_url
                    current_referer = current_url
                    current_url = urllib.parse.urljoin(current_url, location)
                    new_host = urllib.parse.urlparse(current_url).hostname
                    if new_host: invalidate_doh_cache(new_host)
                    redirect_count += 1
                    continue

                is_blocked, block_reason = detect_block_response(r, content_kind)
                if is_blocked:
                    r.close()
                    proxy_session.mark_blocked()
                    was_blocked = True
                    error_type = 'forbidden'
                    blocked_host = urllib.parse.urlparse(current_url).hostname
                    if blocked_host: invalidate_doh_cache(blocked_host)
                    retry_count += 1
                    break

                if r.status_code == 200:
                    proxy_session.mark_success()
                    return r, current_url

                if r.status_code in (500, 502, 503, 504, 429):
                    r.close()
                    error_type = 'http'
                    retry_count += 1
                    break

                r.close()
                return None, current_url

            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                failed_host = urllib.parse.urlparse(current_url).hostname
                if failed_host: invalidate_doh_cache(failed_host)
                error_type = 'network'
                retry_count += 1
                break
            except Exception:
                return None, current_url
        else:
            break
    return None, current_url


# ---------------------------------------------------------------
# HLS TOKEN REFRESH
# ---------------------------------------------------------------
class TokenRefresher:
    def __init__(self):
        self._playlist_cache = OrderedDict()
        self._cache_lock = threading.Lock()

    def refresh_segment_url(self, original_playlist_url, failed_url):
        now = time.time()
        with self._cache_lock:
            if original_playlist_url in self._playlist_cache:
                ts, urls = self._playlist_cache[original_playlist_url]
                if now - ts < 3.0:
                    return self._match_segment(urls, failed_url)

        try:
            r, final_url = fetch_response(original_playlist_url, None, max_retries=1,
                                          consistent_ua=True, content_kind='playlist')
            if r and r.status_code == 200 and b"#EXTM3U" in r.content[:100]:
                new_urls = []
                for line in r.iter_lines():
                    if not line: continue
                    line_str = line.decode('utf-8', errors='ignore').strip()
                    if not line_str.startswith("#"):
                        new_urls.append(urllib.parse.urljoin(final_url, line_str))
                    elif line_str.startswith("#EXT-X-KEY"):
                        m = _URI_RE.search(line_str)
                        if m and not m.group(2).startswith("data:"):
                            new_urls.append(urllib.parse.urljoin(final_url, m.group(2)))

                with self._cache_lock:
                    if len(self._playlist_cache) >= 5:
                        self._playlist_cache.popitem(last=False)
                    self._playlist_cache[original_playlist_url] = (now, new_urls)
                r.close()
                return self._match_segment(new_urls, failed_url)
        except Exception: pass
        return None

    def _match_segment(self, new_urls, failed_url):
        failed_path = urllib.parse.urlparse(failed_url).path
        for url in new_urls:
            if urllib.parse.urlparse(url).path == failed_path:
                return url
        return None


token_refresher = TokenRefresher()


def url_variants(url: str) -> List[str]:
    variants = [url]
    parsed = urllib.parse.urlparse(url)
    path = parsed.path
    if path.endswith('.ts'):
        variants.append(urllib.parse.urlunparse(parsed._replace(path=path[:-3] + '.m3u8')))
    elif path.endswith('.m3u8'):
        variants.append(urllib.parse.urlunparse(parsed._replace(path=path[:-5] + '.ts')))
    return variants


_IPTV_TS_SENTINEL = b"__IPTV_TS_DIRECT__"

# FIX CRITICO: Leitura COMPLETA do conteúdo da playlist.
# Antes: _PLAYLIST_PEEK_BYTES = 4096 limitava a leitura a 4KB, truncando
# playlists grandes (com muitos segmentos ou tokens longos na URL).
# Agora: lê até 512KB — suficiente para qualquer playlist HLS real.
_PLAYLIST_MAX_BYTES = 512 * 1024


def _read_response_full(r, max_bytes: int = _PLAYLIST_MAX_BYTES) -> bytes:
    """
    FIX: Lê o corpo completo da resposta (até max_bytes).
    A versão anterior (_read_response_head) lia apenas 4096 bytes e fechava
    a conexão, causando playlists truncadas.
    """
    buf = bytearray()
    try:
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                buf.extend(chunk)
                if len(buf) >= max_bytes:
                    break
    except Exception:
        pass
    finally:
        try:
            r.close()
        except Exception:
            pass
    return bytes(buf)


def _classify_playlist_response(r, final_url: str, label: str) -> Tuple[Optional[bytes], str]:
    # FIX: usa leitura completa em vez de peek de 4KB
    content = _read_response_full(r)
    if not content:
        return None, final_url
    if is_raw_mpeg_ts(content):
        return _IPTV_TS_SENTINEL, final_url
    if is_valid_playlist(content):
        return content, final_url
    return None, final_url


def fetch_playlist_with_smart_retry(url: str, referer: str,
                                    cancel_token=None) -> Tuple[Optional[bytes], str]:
    tok = cancel_token or get_cancel_token()

    r, final_url = fetch_response(url, referer, consistent_ua=True,
                                   cancel_token=tok)
    if r:
        result, final_url = _classify_playlist_response(r, final_url, "attempt-1")
        if result is not None:
            return result, final_url

    if tok and tok.is_cancelled:
        return None, url

    host = urllib.parse.urlparse(url).hostname
    if host: invalidate_doh_cache(host)

    for variant in url_variants(url)[1:]:
        if tok and tok.is_cancelled:
            return None, url
        r, final_url = fetch_response(variant, referer, max_retries=1,
                                       consistent_ua=True, cancel_token=tok)
        if r:
            result, final_url = _classify_playlist_response(r, final_url, "variant")
            if result is not None:
                return result, final_url

    if tok and tok.is_cancelled:
        return None, url

    proxy_session.force_reset()
    r, final_url = fetch_response(url, referer, max_retries=1,
                                   consistent_ua=True, cancel_token=tok)
    if r:
        result, final_url = _classify_playlist_response(r, final_url, "after-reset")
        if result is not None:
            return result, final_url

    if tok and tok.is_cancelled:
        return None, url

    proxy_session.blocked_count = 1
    r, final_url = fetch_response(url, referer, max_retries=1, cancel_token=tok)
    proxy_session.blocked_count = 0
    if r:
        result, final_url = _classify_playlist_response(r, final_url, "ua-rotate")
        if result is not None:
            return result, final_url

    shadow = shadow_playlist_cache.get(url)
    if shadow:
        return shadow, url
    return None, url


def prefetch_worker(url, referer, base_url):
    return


# ---------------------------------------------------------------
# FIX CRITICO: PARSER / REESCRITOR DE MANIFESTO COM SEQ NORMALIZADA
# Reescreve EXT-X-MEDIA-SEQUENCE com valor normalizado para o Kodi,
# evitando "Media sequence changed unexpectedly" e freezes.
#
# v3.8.1: Alem de reescrever, agora tambem registra silenciosamente
# (via ManifestReferenceCache.register, O(1) por segmento) a origem de
# cada segmento absoluto encontrado — sem alterar nenhuma URL entregue
# ao Kodi, sem parametros extras, sem querystring adicional. Essa
# gravacao e um efeito colateral interno, invisivel externamente.
#
# v3.8.2: rewrite_manifest() ganhou o parametro opcional `playlist_referer`
# (mantendo compatibilidade retroativa: tem default None, entao qualquer
# chamador antigo que so passava os 4 argumentos originais continua
# funcionando identico). Quando fornecido, esse e o referer REAL usado
# para buscar a playlist atual, e passa a ser gravado no REF em vez de
# sempre None — permitindo que heal_segment_using_ref() rebaixe o
# manifest de origem com o Referer correto (importante para CDNs que
# validam esse header). O caminho de chamada em handle_playlist() foi
# atualizado para repassar o referer que ele mesmo recebeu.
# ---------------------------------------------------------------
def rewrite_manifest(content: bytes, final_url: str, original_url: str,
                     make_proxy_url_fn, playlist_referer: Optional[str] = None
                     ) -> Tuple[bytes, List[str], int, int]:
    output: List[str] = []
    ts_urls: List[str] = []
    target_duration = 6
    media_sequence = 0

    # Iterador direto em strings economizando arrays intermitentes na RAM
    lines = (line.strip() for line in content.decode('utf-8', errors='ignore').split('\n') if line)

    for line in lines:
        if line.startswith("#EXT-X-TARGETDURATION"):
            try: target_duration = int(line.split(":")[1].strip())
            except Exception: pass

        elif line.startswith("#EXT-X-MEDIA-SEQUENCE"):
            try:
                cdn_seq = int(line.split(":")[1].strip())
            except Exception:
                cdn_seq = 0
            media_sequence = cdn_seq
            # FIX CRITICO: Substitui a sequência CDN pela sequência normalizada
            # do proxy para garantir que o Kodi nunca veja um valor regressivo.
            proxy_seq = media_seq_normalizer.normalize(original_url, cdn_seq)
            output.append(f"#EXT-X-MEDIA-SEQUENCE:{proxy_seq}")
            continue

        if not line.startswith("#"):
            abs_url = urllib.parse.urljoin(final_url, line)
            # v3.8.1: registra a referencia do segmento no REF (O(1) amortizado
            # apos a otimizacao de dirty-check da v3.8.2). Nao afeta a URL
            # entregue ao Kodi (make_proxy_url_fn continua gerando exatamente
            # a mesma URL de sempre). v3.8.2: agora grava o referer real da
            # playlist (playlist_referer) em vez de sempre None.
            try:
                manifest_reference_cache.register(abs_url, original_url, final_url, playlist_referer)
            except Exception:
                pass
            output.append(make_proxy_url_fn("segment", abs_url, final_url, original_url))
            ts_urls.append(abs_url)
            continue

        if line.startswith("#EXT-X-KEY"):
            m = _URI_RE.search(line)
            if m and not m.group(2).startswith("data:"):
                quote_char = m.group(1)
                original_uri = m.group(2)
                proxy_key = make_proxy_url_fn("key", urllib.parse.urljoin(final_url, original_uri), final_url, original_url)
                line = line.replace(f"URI={quote_char}{original_uri}{quote_char}", f"URI={quote_char}{proxy_key}{quote_char}")
            output.append(line)
            continue

        output.append(line)

    return "\n".join(output).encode('utf-8'), ts_urls, target_duration, media_sequence


# ---------------------------------------------------------------
# HANDLER HTTP CORE
# ---------------------------------------------------------------
class ProxyHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format, *args): pass

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, BrokenPipeError, socket.timeout, ConnectionAbortedError):
            pass

    def do_GET(self):
        try:
            parsed_q = urllib.parse.urlparse(self.path)
            qs = urllib.parse.parse_qs(parsed_q.query)

            if 'type' in qs and 'url' in qs:
                t = (qs['type'][0] or '').lower()
                target_url = qs['url'][0]
                referer = qs.get('referer', [None])[0]
                original_url = qs.get('original', [target_url])[0]
                if t == 'playlist': self.handle_playlist(target_url, referer, original_url)
                elif t == 'segment': self.handle_segment(target_url, referer, original_url)
                elif t == 'key': self.handle_key(target_url, referer, original_url)
                else: self._send_never_fail_response("segment", None, referer)
                return

            parts = self.path.strip("/").split("/")
            if len(parts) < 2:
                self._send_never_fail_response("playlist", None, None)
                return

            prefix = parts[0]
            if prefix in PLAYER_PROFILES:
                proxy_session.set_profile(prefix)
                parts = parts[1:]
                if len(parts) < 2:
                    self._send_never_fail_response("playlist", None, None)
                    return
                prefix = parts[0]

            b64_data = parts[1].rsplit(".", 1)[0]
            try:
                decoded = base64.urlsafe_b64decode(b64_data + '==').decode('utf-8', errors='ignore')
            except Exception:
                self._send_never_fail_response(prefix, None, None)
                return

            decoded_parts = decoded.split("|")
            target_url = decoded_parts[0]
            referer = decoded_parts[1] if len(decoded_parts) > 1 and decoded_parts[1] else None
            original_url = decoded_parts[2] if len(decoded_parts) > 2 and decoded_parts[2] else target_url

            if prefix == "playlist": self.handle_playlist(target_url, referer, original_url)
            elif prefix == "segment": self.handle_segment(target_url, referer, original_url)
            elif prefix == "key": self.handle_key(target_url, referer, original_url)
            else: self._send_never_fail_response("segment", None, referer)
        except Exception:
            try: self._send_never_fail_response("segment", None, None)
            except Exception: pass

    def _send_never_fail_response(self, prefix: str, playlist_url: Optional[str], referer: Optional[str]):
        if prefix == "playlist":
            shadow = shadow_playlist_cache.get(playlist_url) if playlist_url else None
            if shadow:
                self._write_response(200, 'application/vnd.apple.mpegurl', shadow)
            else:
                filler_url = f"http://127.0.0.1:{self.server.server_address[1]}/segment/filler.ts\n"
                dummy = b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:6\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:6.0,\n" + filler_url.encode('utf-8')
                self._write_response(200, 'application/vnd.apple.mpegurl', dummy)
        elif prefix in ("segment", "ts"):
            last_seg = last_good_segment.get()
            self._write_response(200, 'video/mp2t', last_seg if last_seg else generate_ts_filler(4))
        elif prefix == "key":
            self._write_response(200, 'application/octet-stream', b'\x00' * 16)
        else:
            self._write_response(200, 'video/mp2t', generate_ts_filler(4))

    def _write_response(self, status: int, content_type: str, body: bytes):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', len(body))
        self.send_header('X-Proxy-Version', PROXY_VERSION)
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        try: self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError): pass

    def handle_playlist(self, url, referer, original_url):
        # Passa o token de cancelamento do canal ativo para a fetch
        tok = get_cancel_token()
        content, final_url = fetch_playlist_with_smart_retry(url, referer, cancel_token=tok)

        if tok and tok.is_cancelled:
            # Canal foi trocado enquanto buscávamos — retorna 503 silenciosamente
            self._write_response(503, 'text/plain', b'channel changed')
            return

        if not content:
            self._send_never_fail_response("playlist", url, referer)
            return

        if content is _IPTV_TS_SENTINEL:
            proxy_seg_url = self.make_proxy_url("segment", final_url, referer or url, original_url)
            synthetic = make_synthetic_playlist_for_ts(proxy_seg_url)
            shadow_playlist_cache.update(url, synthetic, 0, 6)
            self._write_response(200, 'application/vnd.apple.mpegurl', synthetic)
            return

        if not is_valid_playlist(content):
            shadow = shadow_playlist_cache.get(url)
            if shadow and is_valid_playlist(shadow): content = shadow
            else:
                self._write_response(200, 'application/vnd.apple.mpegurl', content)
                return

        with CACHE_LOCK:
            if len(URL_CACHE) >= URL_CACHE_MAX:
                URL_CACHE.popitem(last=False)
            URL_CACHE[url] = final_url

        # v3.8.2: repassa o referer real desta playlist para o REF poder
        # gravar corretamente quem foi usado para buscar cada segmento.
        rewritten, ts_urls, target_duration, media_sequence = rewrite_manifest(
            content, final_url, original_url, self.make_proxy_url,
            playlist_referer=referer)
        # FIX v3.8.0: NÃO filtra segmentos pelo analyzer.
        # Antes: filtered_ts = analyzer.update_playlist(...) retornava apenas
        # os últimos 3 segmentos. O Kodi pode pedir qualquer segmento da playlist
        # (especialmente o 1º ao iniciar), e se estivesse fora do set filtrado
        # recebia null-packet → stall imediato.
        analyzer.update_playlist(final_url, target_duration, media_sequence, ts_urls)
        shadow_playlist_cache.update(url, content, media_sequence, target_duration)

        if stall_detector.update(url, media_sequence, target_duration):
            proxy_session.force_reset()
            invalidate_doh_cache(urllib.parse.urlparse(url).hostname or "")

        # FIX v3.8.0: Entrega a playlist reescrita completa sem filtrar segmentos.
        self._write_response(200, 'application/vnd.apple.mpegurl', rewritten)

    def handle_segment(self, url, referer, original_url):
        if url.endswith("/segment/filler.ts") or url == "filler.ts":
            self._write_response(200, 'video/mp2t', generate_ts_filler(4))
            return

        # FIX: Verifica cancelamento antes de buscar o segmento
        tok = get_cancel_token()
        if tok and tok.is_cancelled:
            self._write_response(503, 'text/plain', b'channel changed')
            return

        with CACHE_LOCK:
            cached = SEGMENT_LRU.get(url)
        if cached:
            self._write_response(200, 'video/mp2t', cached)
            return

        t_start = time.time()
        # FIX v3.8.0: max_retries=3 para segmentos (era 2 via default).
        # Backoff curto (max 3s) para não travar o buffer do Kodi.
        r, final_seg_url = fetch_response(url, referer, content_kind='segment',
                                           max_retries=3, cancel_token=tok)
        t_ttfb = time.time()

        # FIX: Verifica cancelamento após a fetch (pode ter demorado)
        if tok and tok.is_cancelled:
            if r:
                try: r.close()
                except Exception: pass
            self._write_response(503, 'text/plain', b'channel changed')
            return

        if not r:
            new_seg_url = token_refresher.refresh_segment_url(original_url, url)
            if new_seg_url:
                r, final_seg_url = fetch_response(new_seg_url, referer,
                                                   content_kind='segment',
                                                   cancel_token=tok)

        # v3.8.1/v3.8.2: segunda camada de recuperacao (REF). So e acionada
        # se fetch_response() direto E o TokenRefresher() ja tiverem
        # falhado. Nao substitui o TokenRefresher, apenas complementa —
        # consulta o ManifestReferenceCache, rebaixa o manifest de origem
        # (agora com o Referer real, e com dedupe entre threads) e localiza
        # a URL renovada do mesmo segmento.
        if not r:
            healed_url = heal_segment_using_ref(url)
            if healed_url:
                r, final_seg_url = fetch_response(healed_url, referer,
                                                   content_kind='segment',
                                                   cancel_token=tok)

        if not r and original_url and original_url != url:
            r_orig, renewed_url = fetch_response(original_url, referer,
                                                  content_kind='segment',
                                                  consistent_ua=True,
                                                  max_retries=2,
                                                  cancel_token=tok)
            if r_orig:
                r = r_orig
                final_seg_url = renewed_url

        if not r:
            self._send_never_fail_response("segment", None, referer)
            return

        latency = t_ttfb - t_start
        content_length_hdr = r.headers.get('Content-Length', '')
        try: content_length = int(content_length_hdr)
        except (ValueError, TypeError): content_length = -1

        if content_length < 0 or content_length > 50 * 1024 * 1024:
            self._stream_pipe_to_kodi(r, url, latency, None, cancel_token=tok)
            return

        downloaded = bytearray()
        try:
            for chunk in r.iter_content(chunk_size=4096):
                if chunk: downloaded.extend(chunk)
                # FIX: verifica cancelamento durante download do segmento
                if tok and tok.is_cancelled:
                    break
        except (BrokenPipeError, ConnectionResetError): pass
        finally: r.close()

        if tok and tok.is_cancelled:
            self._write_response(503, 'text/plain', b'channel changed')
            return

        content_bytes = bytes(downloaded) if downloaded else b''
        if not content_bytes or looks_like_html_error(content_bytes):
            self._send_never_fail_response("segment", None, referer)
            return

        self._write_response(200, 'video/mp2t', content_bytes)
        last_good_segment.update(content_bytes)

        with CACHE_LOCK:
            cache_limit = _get_adaptive_segment_cache_size()
            SEGMENT_LRU[url] = content_bytes
            while len(SEGMENT_LRU) > cache_limit:
                SEGMENT_LRU.popitem(last=False)

    def _stream_pipe_to_kodi(self, r, url, latency, base_url, cancel_token=None):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Transfer-Encoding', 'chunked')
            self.send_header('X-Proxy-Version', PROXY_VERSION)
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'close')
            self.end_headers()
        except Exception:
            try: r.close()
            except Exception: pass
            return

        total_bytes = 0
        chunk_count = 0
        try:
            for chunk in r.iter_content(chunk_size=4096):
                if not chunk: continue
                # FIX: cancela stream pipe se o canal trocou
                if cancel_token and cancel_token.is_cancelled:
                    break
                if chunk_count == 0 and looks_like_html_error(chunk): break
                try:
                    self.wfile.write(f"{len(chunk):X}\r\n".encode('ascii'))
                    self.wfile.write(chunk)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
                except Exception: break
                total_bytes += len(chunk)
                chunk_count += 1
        except Exception: pass
        finally:
            try: r.close()
            except Exception: pass

        try:
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except Exception: pass

    def handle_key(self, url, referer, original_url):
        tok = get_cancel_token()
        r, final_key_url = fetch_response(url, referer, consistent_ua=True,
                                           content_kind='key',
                                           timeout_connect=6.0, timeout_read=10.0,
                                           max_retries=3, cancel_token=tok)
        if not r:
            new_key_url = token_refresher.refresh_segment_url(original_url, url)
            if new_key_url:
                r, final_key_url = fetch_response(new_key_url, referer,
                                                   consistent_ua=True,
                                                   content_kind='key',
                                                   timeout_connect=6.0,
                                                   timeout_read=10.0,
                                                   max_retries=2,
                                                   cancel_token=tok)

        if not r:
            self._send_never_fail_response("key", None, referer)
            return

        try: key_content = r.content
        except Exception: key_content = b''
        finally: r.close()

        if not key_content or looks_like_html_error(key_content) or len(key_content) > 1024:
            self._send_never_fail_response("key", None, referer)
            return

        self._write_response(200, 'application/octet-stream', key_content)

    def make_proxy_url(self, prefix, url, referer, original_url=""):
        profile_prefix = f"{proxy_session.current_profile}/" if proxy_session.current_profile != 'kodi' else ""
        payload = f"{url}|{referer or ''}|{original_url or ''}".encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        ext = ".m3u8" if prefix == "playlist" else ".ts" if prefix == "segment" else ".key"
        return f"http://127.0.0.1:{self.server.server_address[1]}/{profile_prefix}{prefix}/{b64}{ext}"


# ---------------------------------------------------------------
# SERVIDOR E ADDON CORE (MANTIDOS E INALTERADOS)
# ---------------------------------------------------------------
class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class HLSAddon:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if not cls._instance:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self, addon_handle=None):
        if self._initialized: return
        self.addon_handle = addon_handle
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), ProxyHTTPRequestHandler)
        self.port = self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self._initialized = True

    def play_stream(self, original_url, listitem=None, profile='kodi'):
        proxy_session.set_profile(profile)

        # FIX CRITICO: Cria novo token de cancelamento.
        # Isso invalida automaticamente todas as requests pendentes do
        # canal anterior (playlist, segmentos, keys) antes de limpar
        # o cache e iniciar o novo canal.
        new_cancel_token()

        with CACHE_LOCK:
            SEGMENT_LRU.clear()
            URL_CACHE.clear()
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.clear()
        with analyzer.lock:
            analyzer.states.clear()

        shadow_playlist_cache.clear()
        stall_detector.clear()
        # FIX: Limpa também o normalizador de sequência ao trocar de canal
        media_seq_normalizer.clear()
        # FIX v3.8.0: Limpa last_good_segment ao trocar de canal.
        # Sem isso, _send_never_fail_response entregava frames do canal anterior
        # como fallback, causando decode error (PPS inválido) e PTS jumps massivos.
        last_good_segment._content = None
        last_good_segment._timestamp = 0
        # v3.8.1: Limpa o ManifestReferenceCache (REF) ao trocar de canal —
        # referencias do canal anterior nao fazem sentido no novo.
        manifest_reference_cache.clear()
        with _ref_heal_playlist_lock:
            _ref_heal_playlist_cache.clear()
        # v3.8.2: tambem limpa os locks de dedupe de fetch do REF ao trocar
        # de canal, evitando reter locks referentes a manifests do canal
        # anterior indefinidamente.
        with _ref_heal_fetch_locks_guard:
            _ref_heal_fetch_locks.clear()

        # FIX: force_reset protegido — só faz reset de sessão, não shutdown
        proxy_session.force_reset()

        prefix = f"{profile}/" if profile != 'kodi' else ""
        payload = f"{original_url}||{original_url}".encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        proxy_url = f"http://127.0.0.1:{self.port}/{prefix}playlist/{b64}.m3u8"

        try:
            import xbmcplugin, xbmcgui, xbmc
            if not listitem: listitem = xbmcgui.ListItem(path=proxy_url)
            else: listitem.setPath(proxy_url)

            listitem.setProperty("IsPlayable", "true")
            try: listitem.getVideoInfoTag().setPlot("HLS Proxy Stream")
            except Exception:
                try: listitem.setInfo('video', {'plot': 'HLS Proxy Stream'})
                except Exception: pass

            handle = int(self.addon_handle) if self.addon_handle else -1
            if handle >= 0: xbmcplugin.setResolvedUrl(handle, True, listitem)
            else: xbmc.Player().play(proxy_url, listitem)
        except Exception:
            return proxy_url

    def stop(self):
        # FIX: Cancela requests ativas antes de encerrar o servidor
        new_cancel_token()  # invalida requests pendentes
        proxy_session.shutdown()
        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception:
            pass

    def get_port(self):
        return self.port


if __name__ == "__main__":
    addon = HLSAddon()
    port = addon.get_port()
    print(f"HLS Proxy v{PROXY_VERSION} ativo em http://127.0.0.1:{port}/")
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        addon.stop()