import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import urllib3
import base64
import time
import random
import socket
from collections import OrderedDict
import logging
from logging.handlers import RotatingFileHandler
import os
from concurrent.futures import ThreadPoolExecutor

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------
# CONFIGURAÇÃO DE LOGGING
# ---------------------------------------------------------------
def setup_proxy_logging():
    log_dir = os.path.join(os.path.expanduser("~"), ".kodi", "userdata", "addon_data", "plugin.video.hlsproxy")
    try:
        os.makedirs(log_dir, exist_ok=True)
        logger = logging.getLogger('HLSProxy')
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = RotatingFileHandler(
                os.path.join(log_dir, "proxy.log"), 
                maxBytes=2*1024*1024, 
                backupCount=2
            )
            handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
            logger.addHandler(handler)
        return logger
    except Exception:
        return logging.getLogger('HLSProxy')

logger = setup_proxy_logging()

# ---------------------------------------------------------------
# PLAYER PROFILES
# ---------------------------------------------------------------
PLAYER_PROFILES = {
    'exoplayer': {
        'ua': 'ExoPlayer/Lavf60.3.100',
        'accept': '*/*',
        'connection': 'keep-alive'
    },
    'vlc': {
        'ua': 'VLC/3.0.20 Vetinari',
        'accept': '*/*',
        'connection': 'keep-alive'
    },
    'kodi': {
        'ua': 'Lavf/60.3.100',
        'accept': '*/*',
        'connection': 'keep-alive'
    }
}

# ---------------------------------------------------------------
# STREAM ANALYZER - Live Edge, Prefetch & ADAPTIVE RECONNECT
# ---------------------------------------------------------------
class StreamAnalyzer:
    def __init__(self):
        self.states = {}
        self.lock = threading.Lock()

    def update_playlist(self, base_url, target_duration, media_sequence, seg_urls):
        with self.lock:
            if base_url not in self.states:
                self.states[base_url] = {
                    'target_duration': target_duration or 6,
                    'bitrate_bps': 0,
                    'last_size': 0,
                    'last_update': time.time(),
                    'latencies': [],
                    'speeds_bps': []
                }
            
            state = self.states[base_url]
            if target_duration:
                state['target_duration'] = target_duration

            # Live Edge agressivo
            if len(seg_urls) > 4:
                seg_urls = seg_urls[-4:]

            return seg_urls

    def update_segment_size(self, base_url, size_bytes):
        with self.lock:
            if base_url not in self.states:
                return
            state = self.states[base_url]
            state['last_size'] = size_bytes
            if state['target_duration'] > 0:
                # Transforma em bytes por segundo (bitrate / 8)
                state['bitrate_bps'] = size_bytes / state['target_duration']

    def update_network_metrics(self, base_url, latency, download_time, size_bytes):
        with self.lock:
            if base_url not in self.states or download_time <= 0:
                return
            
            state = self.states[base_url]
            speed_bps = size_bytes / download_time

            state['latencies'].append(latency)
            state['speeds_bps'].append(speed_bps)

            # Manter apenas as últimas 5 amostras para análise em tempo real
            if len(state['latencies']) > 5:
                state['latencies'].pop(0)
                state['speeds_bps'].pop(0)

    def check_proactive_reconnect(self, base_url):
        """
        Adaptive Reconnect Intelligence:
        Decide proativamente se a sessão deve ser reiniciada baseado em métricas.
        """
        with self.lock:
            if base_url not in self.states:
                return False
            
            state = self.states[base_url]
            if len(state['latencies']) < 3:
                return False

            lats = state['latencies']
            speeds = state['speeds_bps']
            req_bitrate = state['bitrate_bps']

            avg_lat = sum(lats) / len(lats)
            avg_speed = sum(speeds) / len(speeds)
            jitter = sum(abs(l - avg_lat) for l in lats) / len(lats)

            reconnect = False
            reason = ""

            # Regra 1: Velocidade de download caindo perto do limite (menos de 1.2x de folga)
            if req_bitrate > 0 and avg_speed < (req_bitrate * 1.2):
                reconnect = True
                reason = f"Bitrate Risk (Speed: {avg_speed/1024:.0f}KB/s, Req: {req_bitrate/1024:.0f}KB/s)"
            
            # Regra 2: Latência do servidor aumentou para mais de 2 segundos (TTFB lento)
            elif avg_lat > 2.0:
                reconnect = True
                reason = f"High Latency ({avg_lat:.2f}s)"
            
            # Regra 3: Jitter alto (conexão pipocando)
            elif jitter > 1.2:
                reconnect = True
                reason = f"High Jitter ({jitter:.2f}s)"

            if reconnect:
                # Limpa as métricas para não entrar em loop de reconexão
                state['latencies'].clear()
                state['speeds_bps'].clear()
                logger.info(f"🔄 Adaptive Reconnect Triggered! Reason: {reason}")
                return True
            
            return False

    def get_prefetch_count(self, base_url):
        with self.lock:
            if base_url not in self.states:
                return 2
            state = self.states[base_url]
            if state['bitrate_bps'] <= 0 or state['last_size'] <= 0:
                return 2

            target_buffer_seconds = 12
            bytes_per_seg = state['last_size']
            segs_needed = int((state['bitrate_bps'] * target_buffer_seconds) / bytes_per_seg)
            return max(1, min(segs_needed, 5))

analyzer = StreamAnalyzer()

# ---------------------------------------------------------------
# CACHE E RECURSOS
# ---------------------------------------------------------------
prefetch_executor = ThreadPoolExecutor(max_workers=4)
URL_CACHE = OrderedDict()
SEGMENT_LRU = OrderedDict()
CACHE_LOCK = threading.Lock()
MAX_SEGMENT_CACHE = 5

PROXY_VERSION = "1.2.0-adaptive-reconnect"

# ---------------------------------------------------------------
# SESSÃO HTTP (Com suporte a Hard Reset)
# ---------------------------------------------------------------
class ProxySession:
    def __init__(self):
        self.current_profile = 'kodi'
        self.session_lock = threading.Lock()
        self.init_session()

    def init_session(self):
        with self.session_lock:
            self.session = requests.Session()
            self.session.verify = False
            adapter = requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=20)
            self.session.mount('http://', adapter)
            self.session.mount('https://', adapter)

    def force_reset(self):
        """Fecha todas as conexões ativas e recria o pool (Evita rotas travadas)"""
        with self.session_lock:
            try:
                self.session.close()
            except:
                pass
        self.init_session()

    def set_profile(self, profile_name):
        if profile_name in PLAYER_PROFILES:
            self.current_profile = profile_name

    def get_headers(self, url, referer=None):
        parsed = urllib.parse.urlparse(url)
        profile = PLAYER_PROFILES[self.current_profile]
        headers = {
            'User-Agent': profile['ua'],
            'Accept': profile['accept'],
            'Host': parsed.netloc,
            'Origin': f"{parsed.scheme}://{parsed.netloc}",
            'Connection': profile['connection'],
            'Referer': referer or f"{parsed.scheme}://{parsed.netloc}/"
        }
        return headers

proxy_session = ProxySession()

# ---------------------------------------------------------------
# HELPER: Encontrar Base URL do Cache
# ---------------------------------------------------------------
def get_base_url_for_segment(url):
    with CACHE_LOCK:
        for cached_url, f_url in list(URL_CACHE.items()):
            if url.startswith(str(f_url).rsplit('/', 1)[0]):
                return f_url
    return None

# ---------------------------------------------------------------
# FETCH COM RETRY E REDIRECT
# ---------------------------------------------------------------
def fetch_response(url, referer=None, max_retries=2):
    current_url, current_referer = url, referer
    for _ in range(5):  # Max redirects
        retry_count = 0
        while retry_count <= max_retries:
            try:
                headers = proxy_session.get_headers(current_url, current_referer)
                
                with proxy_session.session_lock:
                    s = proxy_session.session
                
                r = s.get(
                    current_url, 
                    headers=headers, 
                    timeout=(3.5, 10), 
                    allow_redirects=False, 
                    stream=True
                )

                if r.status_code in (301, 302, 303, 307, 308):
                    location = r.headers.get('Location')
                    r.close()
                    if not location:
                        return None, current_url
                    current_referer = current_url
                    current_url = urllib.parse.urljoin(current_url, location)
                    break

                if r.status_code == 200:
                    return r, current_url

                if r.status_code in (500, 502, 503, 504, 429) and retry_count < max_retries:
                    r.close()
                    retry_count += 1
                    time.sleep(min((2 ** retry_count) * 0.4, 1.8))
                    continue

                r.close()
                return None, current_url

            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                if retry_count < max_retries:
                    retry_count += 1
                    time.sleep(0.6)
                else:
                    return None, current_url
            except Exception as e:
                logger.error(f"Fetch fatal error: {e}")
                return None, current_url
        else:
            break
    return None, current_url

# ---------------------------------------------------------------
# PREFETCH WORKER
# ---------------------------------------------------------------
def prefetch_worker(url, referer, base_url):
    with CACHE_LOCK:
        if url in SEGMENT_LRU:
            return

    t_start = time.time()
    r, _ = fetch_response(url, referer)
    t_ttfb = time.time()
    latency = t_ttfb - t_start

    if not r:
        return

    downloaded = bytearray()
    try:
        for chunk in r.iter_content(chunk_size=32768):
            if chunk:
                downloaded.extend(chunk)
    except Exception:
        pass
    finally:
        r.close()

    t_end = time.time()
    download_time = t_end - t_ttfb

    if downloaded:
        size = len(downloaded)
        analyzer.update_segment_size(base_url, size)
        analyzer.update_network_metrics(base_url, latency, download_time, size)
        
        with CACHE_LOCK:
            SEGMENT_LRU[url] = bytes(downloaded)
            if len(SEGMENT_LRU) > MAX_SEGMENT_CACHE:
                SEGMENT_LRU.popitem(last=False)

# ---------------------------------------------------------------
# HANDLER HTTP
# ---------------------------------------------------------------
class ProxyHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format, *args):
        pass

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, BrokenPipeError, socket.timeout, ConnectionAbortedError):
            pass

    def do_GET(self):
        try:
            parts = self.path.strip("/").split("/")
            if len(parts) < 2:
                self.send_error(404)
                return

            prefix = parts[0]
            if prefix in PLAYER_PROFILES:
                proxy_session.set_profile(prefix)
                parts = parts[1:]
                prefix = parts[0]

            b64_data = parts[1].rsplit(".", 1)[0]
            try:
                decoded_bytes = base64.urlsafe_b64decode(b64_data + '==')
                decoded = decoded_bytes.decode('utf-8')
            except Exception as e:
                logger.error(f"Base64 decode error: {e}")
                self.send_error(400)
                return

            target_url, referer = (decoded.split("|", 1) + [None])[:2]

            if prefix == "playlist":
                self.handle_playlist(target_url, referer)
            elif prefix == "segment":
                self.handle_segment(target_url, referer)
            elif prefix == "key":
                self.handle_key(target_url, referer)
            else:
                self.handle_continuous_ts(target_url, referer)
        except Exception as e:
            logger.error(f"Request handler error: {e}")
            try:
                self.send_error(500)
            except:
                pass

    def handle_playlist(self, url, referer):
        r, final_url = fetch_response(url, referer)
        if not r:
            self.send_error(503)
            return

        with CACHE_LOCK:
            URL_CACHE[url] = final_url

        try:
            content = r.content
        finally:
            r.close()

        if b"#EXTM3U" not in content[:200]:
            self.handle_continuous_ts(url, referer)
            return

        lines = content.decode('utf-8', errors='ignore').splitlines()
        output = []
        ts_urls = []
        target_duration = 6
        media_sequence = 0

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith("#EXT-X-TARGETDURATION"):
                try:
                    target_duration = int(line.split(":")[1].strip())
                except:
                    pass
            elif line.startswith("#EXT-X-MEDIA-SEQUENCE"):
                try:
                    media_sequence = int(line.split(":")[1].strip())
                except:
                    pass

            if not line.startswith("#"):
                abs_url = urllib.parse.urljoin(final_url, line)
                proxy_url = self.make_proxy_url("segment", abs_url, final_url)
                output.append(proxy_url)
                ts_urls.append(abs_url)
            elif "#EXT-X-KEY" in line:
                m = re.search(r'URI=(["\'])(.*?)\1', line)
                if m:
                    original_uri = m.group(2)
                    if not original_uri.startswith("data:"):
                        key_url = urllib.parse.urljoin(final_url, original_uri)
                        proxy_key = self.make_proxy_url("key", key_url, final_url)
                        line = line.replace(original_uri, proxy_key)
                output.append(line)
            else:
                output.append(line)

        filtered_ts = analyzer.update_playlist(final_url, target_duration, media_sequence, ts_urls)

        final_output = []
        for line in output:
            if not line.startswith("#") and "/segment/" in line:
                try:
                    b64_part = line.split("/segment/")[1].rsplit(".", 1)[0]
                    decoded_seg = base64.urlsafe_b64decode(b64_part + '==').decode('utf-8').split("|")[0]
                    if decoded_seg in filtered_ts:
                        final_output.append(line)
                except:
                    final_output.append(line)
            else:
                final_output.append(line)

        prefetch_count = analyzer.get_prefetch_count(final_url)
        for ts in filtered_ts[:prefetch_count]:
            prefetch_executor.submit(prefetch_worker, ts, final_url, final_url)

        response = "\n".join(final_output).encode('utf-8')

        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Content-Length', len(response))
        self.send_header('X-Proxy-Version', PROXY_VERSION)
        self.end_headers()
        self.wfile.write(response)

    def handle_segment(self, url, referer):
        # 1. Verifica cache primário
        with CACHE_LOCK:
            content = SEGMENT_LRU.get(url)

        if content:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', len(content))
            self.send_header('X-Proxy-Version', PROXY_VERSION)
            self.end_headers()
            self.wfile.write(content)
            return

        # 2. ADAPTIVE RECONNECT CHECK ANTES DO FETCH
        base_url = get_base_url_for_segment(url)
        if base_url and analyzer.check_proactive_reconnect(base_url):
            proxy_session.force_reset()

        # 3. Cronômetro de Redes (Métricas Preditivas)
        t_start = time.time()
        r, _ = fetch_response(url, referer)
        t_ttfb = time.time()
        latency = t_ttfb - t_start

        if not r:
            self.send_error(404)
            return

        cl = r.headers.get('Content-Length')
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        if cl:
            self.send_header('Content-Length', cl)
        self.send_header('X-Proxy-Version', PROXY_VERSION)
        self.end_headers()

        downloaded = bytearray()
        try:
            for chunk in r.iter_content(chunk_size=32768):
                if chunk:
                    self.wfile.write(chunk)
                    downloaded.extend(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            r.close()

        t_end = time.time()
        download_time = t_end - t_ttfb

        if downloaded:
            size = len(downloaded)
            if base_url:
                analyzer.update_segment_size(base_url, size)
                analyzer.update_network_metrics(base_url, latency, download_time, size)

            with CACHE_LOCK:
                SEGMENT_LRU[url] = bytes(downloaded)
                if len(SEGMENT_LRU) > MAX_SEGMENT_CACHE:
                    SEGMENT_LRU.popitem(last=False)

    def handle_key(self, url, referer):
        r, _ = fetch_response(url, referer)
        if not r:
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        cl = r.headers.get('Content-Length')
        if cl:
            self.send_header('Content-Length', cl)
        self.send_header('X-Proxy-Version', PROXY_VERSION)
        self.end_headers()

        try:
            self.wfile.write(r.content)
        finally:
            r.close()

    def handle_continuous_ts(self, url, referer):
        r, _ = fetch_response(url, referer)
        if not r:
            self.send_error(503)
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Transfer-Encoding', 'chunked')
        self.send_header('X-Proxy-Version', PROXY_VERSION)
        self.end_headers()

        CHUNK_SIZE = 32768
        MIN_WRITE_INTERVAL = 0.012

        try:
            for chunk in r.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                t_start = time.time()
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (socket.timeout, BrokenPipeError, ConnectionResetError):
                    return
                except Exception:
                    return

                elapsed = time.time() - t_start
                sleep_time = max(0, MIN_WRITE_INTERVAL - elapsed)
                if sleep_time > 0:
                    time.sleep(sleep_time)
        except Exception as e:
            logger.error(f"Continuous TS error: {e}")
        finally:
            r.close()

    def make_proxy_url(self, prefix, url, referer):
        profile_prefix = f"{proxy_session.current_profile}/" if proxy_session.current_profile != 'kodi' else ""
        payload = f"{url}|{referer or ''}".encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        ext = ".m3u8" if prefix == "playlist" else ".ts" if prefix == "segment" else ".key"
        return f"http://127.0.0.1:{self.server.server_address[1]}/{profile_prefix}{prefix}/{b64}{ext}"

# ---------------------------------------------------------------
# SERVIDOR E ADDON
# ---------------------------------------------------------------
class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class HLSAddon:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if not cls._instance:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self, addon_handle=None):
        if self._initialized:
            return
        self.addon_handle = addon_handle
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), ProxyHTTPRequestHandler)
        self.port = self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self._initialized = True

    def play_stream(self, original_url, listitem=None, profile='kodi'):
        proxy_session.set_profile(profile)

        # Limpeza completa de cache anterior (incluindo estados do analyzer)
        with CACHE_LOCK:
            SEGMENT_LRU.clear()
            URL_CACHE.clear()
        
        with analyzer.lock:
            analyzer.states.clear()

        # Garante conexão zerada no play
        proxy_session.force_reset()

        prefix = f"{profile}/" if profile != 'kodi' else ""
        payload = f"{original_url}|".encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        proxy_url = f"http://127.0.0.1:{self.port}/{prefix}playlist/{b64}.m3u8"

        try:
            import xbmcplugin, xbmcgui, xbmc
            if not listitem:
                listitem = xbmcgui.ListItem(path=proxy_url)
            else:
                listitem.setPath(proxy_url)

            listitem.setProperty("IsPlayable", "true")
            listitem.setInfo('video', {'plot': 'HLS Proxy Stream'})

            handle = int(self.addon_handle) if self.addon_handle else -1
            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, True, listitem)
            else:
                xbmc.Player().play(proxy_url, listitem)
        except Exception as e:
            logger.error(f"Kodi play error: {e}")
            return proxy_url

    def stop(self):
        try:
            self.server.shutdown()
            self.server.server_close()
        except:
            pass

    def get_port(self):
        return self.port