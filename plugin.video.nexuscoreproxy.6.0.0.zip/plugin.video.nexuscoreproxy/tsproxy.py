# NEXUS CORE MPEG-TS
# Author: Deivid Silva
# Optimized for Performance (Zero-Copy & Fast Joins)

import http.server
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import json
from collections import deque

# ==========================================
# CLOUDFLARE DoH RESOLVER (CORRIGIDO)
# ==========================================
_original_getaddrinfo = socket.getaddrinfo

def is_ip_address(host):
    try:
        socket.inet_aton(host)
        return True
    except OSError:
        pass
    if ':' in host: # Simple check for IPv6
        return True
    return False

def doh_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    # Ignora IPs, localhost e o próprio domínio da Cloudflare para evitar recursão infinita
    if is_ip_address(host) or host in ('localhost', '127.0.0.1', 'cloudflare-dns.com'):
        return _original_getaddrinfo(host, port, family, type, proto, flags)
        
    try:
        req = urllib.request.Request(
            f"https://cloudflare-dns.com/dns-query?name={host}&type=A",
            headers={"Accept": "application/dns-json"}
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode('utf-8'))
            if data.get("Status") == 0 and "Answer" in data:
                for answer in data["Answer"]:
                    if answer["type"] == 1: # A record (IPv4)
                        ip = answer["data"]
                        return [(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, '', (ip, port))]
    except Exception as e:
        print(f"[DoH] Falha ao resolver {host} via Cloudflare: {e}")
        pass
        
    # Fallback to standard resolution if DoH fails or doesn't return A record
    return _original_getaddrinfo(host, port, family, type, proto, flags)

# Apply socket patch
socket.getaddrinfo = doh_getaddrinfo
# ==========================================

TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

_NULL_HDR      = bytes([0x47, 0x1F, 0xFF, 0x10])
TS_NULL_PACKET = _NULL_HDR + b'\xFF' * 184

NULL_PUMP_BURST    = TS_NULL_PACKET * 96
NULL_PUMP_INTERVAL = 0.065

MIN_VALID_PACKETS           = 20 # Regra 2: Mínimo de 20 pacotes consecutivos
SYNC_WINDOW_SIZE            = 32 # Regra 2: Validar 10 posições (1880 bytes)
MAX_SYNC_ATTEMPTS_PER_CYCLE = 7

HOST = "127.0.0.1"
PORT = 8076

STALL_TIMEOUT = 4.0

# Adaptação dinâmica no TailBuffer
SUTURE_TAIL_BYTES_MIN = 13 * 1024 * 1024
SUTURE_TAIL_BYTES_MAX = 32 * 1024 * 1024

SUTURE_SEARCH_SECS  = 14.0
SUTURE_CONFIRM_PKTS = 50 # Regra 7: Sutura exige coincidência de 50 pacotes

# Tolerância para oscilação de B-Frames (aprox 3 segundos em base 90kHz)
PTS_REGRESSION_THRESHOLD = 90000 * 3

_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)

# ==========================================
# PARSERS E EXTRATORES TS/PES/PCR
# ==========================================

def extract_ts_fingerprint(packet: memoryview):
    """
    Extrai PID, CC, PTS e PCR. Otimizado para receber memoryview.
    """
    if len(packet) != TS_PACKET_SIZE or packet[0] != TS_SYNC_BYTE:
        return None
    
    pid = ((packet[1] & 0x1F) << 8) | packet[2]
    pusi = (packet[1] & 0x40) != 0
    cc = packet[3] & 0x0F
    afc = (packet[3] & 0x30) >> 4

    pcr = None
    pts = None
    payload_start = 4

    if afc in (2, 3):
        afl = packet[4]
        payload_start = 5 + afl
        if afl > 0 and (packet[5] & 0x10): 
            if payload_start <= TS_PACKET_SIZE and len(packet) >= 11:
                pcr_base = (packet[6] << 25) | (packet[7] << 17) | (packet[8] << 9) | (packet[9] << 1) | (packet[10] >> 7)
                pcr = pcr_base

    has_payload = afc in (1, 3)
    if has_payload and pusi and payload_start + 9 <= TS_PACKET_SIZE:
        if packet[payload_start] == 0x00 and packet[payload_start+1] == 0x00 and packet[payload_start+2] == 0x01:
            pts_flag = (packet[payload_start+7] & 0x80) != 0
            if pts_flag and payload_start + 14 <= TS_PACKET_SIZE:
                pb = packet[payload_start+9 : payload_start+14]
                pts = (((pb[0] & 0x0E) >> 1) << 30) | (pb[1] << 22) | (((pb[2] & 0xFE) >> 1) << 15) | (pb[3] << 7) | ((pb[4] & 0xFE) >> 1)

    return (pid, cc, pts, pcr, has_payload, pusi)


class LastDeliveredTracker:
    """Regra 6: Rastreador Anti-Duplicação REAL (PTS + PCR + Offset Lógico)"""
    def __init__(self, history_size=25000):
        self._highest_pts = {}
        self._highest_pcr = {}
        self._last_delivery_signature = {}

    def filter_payload(self, data: bytes) -> bytes:
        if not data:
            return b''
        
        mv_data = memoryview(data)
        valid_chunks = []
        
        for i in range(0, len(mv_data), TS_PACKET_SIZE):
            pkt = mv_data[i:i+TS_PACKET_SIZE]
            if len(pkt) != TS_PACKET_SIZE or pkt[0] != TS_SYNC_BYTE:
                continue
                
            fp = extract_ts_fingerprint(pkt)
            if not fp:
                continue
                
            pid, cc, pts, pcr, has_payload, pusi = fp
            
            is_dup = False
            if has_payload and pid != 0x1FFF:
                sig = (cc, pusi, has_payload)
                if pid in self._last_delivery_signature and self._last_delivery_signature[pid] == sig:
                    pts_match = (pts is not None and pts == self._highest_pts.get(pid))
                    pcr_match = (pcr is not None and pcr == self._highest_pcr.get(pid))
                    if pts_match and pcr_match:
                        is_dup = True
                
                if not is_dup:
                    self._last_delivery_signature[pid] = sig

            if is_dup:
                continue

            if pts is not None:
                last_pts = self._highest_pts.get(pid, -1)
                if last_pts != -1 and pts < last_pts and (last_pts - pts) > PTS_REGRESSION_THRESHOLD and (last_pts - pts) < 0x0FFFFFFF:
                    continue 
                if last_pts == -1 or pts > last_pts or (last_pts - pts) >= 0x0FFFFFFF:
                    self._highest_pts[pid] = pts

            if pcr is not None:
                last_pcr = self._highest_pcr.get(pid, -1)
                if last_pcr != -1 and pcr < last_pcr and (last_pcr - pcr) > PTS_REGRESSION_THRESHOLD and (last_pcr - pcr) < 0x0FFFFFFF:
                    continue
                if last_pcr == -1 or pcr > last_pcr or (last_pcr - pcr) >= 0x0FFFFFFF:
                    self._highest_pcr[pid] = pcr
            
            valid_chunks.append(pkt)
            
        return b''.join(valid_chunks)


class TailBuffer:
    __slots__ = ('_buf', '_cap', '_max_cap', '_write_pos', '_filled', '_lock')

    def __init__(self, min_capacity: int = SUTURE_TAIL_BYTES_MIN, max_capacity: int = SUTURE_TAIL_BYTES_MAX):
        self._cap       = min_capacity
        self._max_cap   = max_capacity
        self._buf       = bytearray(self._max_cap)
        self._write_pos = 0
        self._filled    = 0
        self._lock      = threading.Lock()

    def reset(self):
        with self._lock:
            self._write_pos = 0
            self._filled    = 0

    def expand_if_needed(self, incoming_len: int):
        if self._cap < self._max_cap and self._filled >= self._cap:
            self._cap = min(self._max_cap, self._cap + incoming_len * 2)

    def append(self, data: bytes):
        if not data:
            return
        trim = len(data) % TS_PACKET_SIZE
        if trim:
            data = data[:-trim]
        if not data:
            return
            
        with self._lock:
            self.expand_if_needed(len(data))
            n = len(data)
            if n >= self._cap:
                data = data[-self._cap:]
                n = self._cap
                self._buf[:n] = data
                self._write_pos = 0
                self._filled = self._cap
                return

            space = self._cap - self._write_pos
            if n <= space:
                self._buf[self._write_pos : self._write_pos + n] = data
                self._write_pos = (self._write_pos + n) % self._cap
            else:
                self._buf[self._write_pos:self._cap] = data[:space]
                remainder = n - space
                self._buf[:remainder] = data[space:]
                self._write_pos = remainder

            self._filled = min(self._filled + n, self._cap)

    def snapshot(self) -> bytes:
        with self._lock:
            if self._filled == 0:
                return b''
            if self._filled < self._cap:
                raw = bytes(self._buf[:self._filled])
            else:
                raw = bytes(self._buf[self._write_pos:self._cap]) + bytes(self._buf[:self._write_pos])

        trim = len(raw) % TS_PACKET_SIZE
        if trim:
            raw = raw[:-trim]
        return raw


def _pkt_seed_fingerprint(data: memoryview, offset: int):
    if offset + TS_PACKET_SIZE > len(data):
        return None
    pkt = data[offset:offset+TS_PACKET_SIZE]
    if pkt[0] != TS_SYNC_BYTE:
        return None
    pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
    cc = pkt[3] & 0x0F
    afc = (pkt[3] & 0x30) >> 4
    pusi = (pkt[1] & 0x40) != 0
    
    payload_start = 4
    if afc in (2, 3):
        payload_start = 5 + pkt[4]
        
    deep_hash = 0
    if payload_start < TS_PACKET_SIZE:
        # Conversão rápida para tobytes() para o hash
        deep_hash = hash(pkt[payload_start:payload_start+8].tobytes()) 
    
    return (pid, cc, pusi, deep_hash)


def find_suture_cut(tail: bytes, incoming: bytes) -> int:
    if not tail or not incoming:
        return 0

    tail_pkts     = len(tail) // TS_PACKET_SIZE
    incoming_pkts = len(incoming) // TS_PACKET_SIZE

    if tail_pkts == 0 or incoming_pkts == 0:
        return 0

    mv_tail = memoryview(tail)
    mv_incoming = memoryview(incoming)

    deadline = time.monotonic() + SUTURE_SEARCH_SECS
    confirm  = SUTURE_CONFIRM_PKTS 

    incoming_seeds = []
    incoming_index = {}
    
    for i in range(incoming_pkts):
        if i & 511 == 0 and time.monotonic() > deadline:
            return 0
        seed = _pkt_seed_fingerprint(mv_incoming, i * TS_PACKET_SIZE)
        incoming_seeds.append(seed)
        if seed:
            incoming_index.setdefault(seed, []).append(i)

    if not incoming_index:
        return 0

    tail_seeds = []
    for i in range(tail_pkts):
        if i & 2047 == 0 and time.monotonic() > deadline:
            return 0
        tail_seeds.append(_pkt_seed_fingerprint(mv_tail, i * TS_PACKET_SIZE))

    for window_end in range(tail_pkts, confirm - 1, -1):
        if time.monotonic() > deadline:
            return 0

        window_start = window_end - confirm
        first_seed = tail_seeds[window_start]
        
        if not first_seed or first_seed not in incoming_index:
            continue

        for inc_pos in incoming_index[first_seed]:
            match = True
            for j in range(1, confirm):
                if inc_pos + j >= incoming_pkts or tail_seeds[window_start + j] != incoming_seeds[inc_pos + j]:
                    match = False
                    break

            if match:
                cut_pkt  = inc_pos + confirm
                cut_byte = cut_pkt * TS_PACKET_SIZE

                if cut_byte >= len(incoming):
                    return -1
                return cut_byte

    return 0


class SutureAccumulator:
    MIN_PKTS = SUTURE_CONFIRM_PKTS * 4
    MAX_ACCUM_BYTES = 2 * 1024 * 1024

    def __init__(self):
        self._accum  = bytearray()
        self._active = False

    def start(self):
        self._accum.clear()
        self._active = True

    def stop(self):
        self._active = False
        self._accum.clear()

    @property
    def active(self) -> bool:
        return self._active

    def feed(self, chunk: bytes, tail: TailBuffer) -> bytes:
        if not self._active:
            return chunk

        self._accum.extend(chunk)

        if len(self._accum) > self.MAX_ACCUM_BYTES:
            self._active = False
            usable = len(self._accum) - (len(self._accum) % TS_PACKET_SIZE)
            out = bytes(self._accum[:usable])
            self._accum.clear()
            return out

        usable = len(self._accum) - (len(self._accum) % TS_PACKET_SIZE)
        snap = tail.snapshot()
        
        if not snap:
            self._active = False
            out = bytes(self._accum[:usable])
            self._accum.clear()
            return out

        if usable // TS_PACKET_SIZE < self.MIN_PKTS:
            return b''

        incoming = bytes(self._accum[:usable])
        del self._accum[:usable]

        cut = find_suture_cut(snap, incoming)

        if cut == -1:
            return b''

        self._active = False
        self._accum.clear()

        if cut == 0:
            return incoming

        return incoming[cut:]


class TsBuffer:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._held = bytearray()
        self._held_count = 0
        self._cc_map = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        
        self._found_pusi = False
        self._found_pat = False
        self._found_pmt = False
        self._found_iframe = False

    def reset_soft(self):
        self._buf.clear()
        self._aligned = False
        self._held.clear()
        self._held_count = 0
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._found_pusi = False
        self._found_pat = False
        self._found_pmt = False
        self._found_iframe = False

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                return -1
            self._sync_attempts += 1
            
            if idx + TS_PACKET_SIZE * SYNC_WINDOW_SIZE <= length:
                sync_valid = True
                for offset in range(TS_PACKET_SIZE, TS_PACKET_SIZE * SYNC_WINDOW_SIZE, TS_PACKET_SIZE):
                    if data[idx + offset] != TS_SYNC_BYTE:
                        sync_valid = False
                        break
                if sync_valid:
                    self._last_sync_idx = idx
                    return idx
            elif idx + TS_PACKET_SIZE * 2 <= length:
                if data[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE:
                    self._last_sync_idx = idx
                    return idx
            idx += 1
        return -1

    def _validate_continuity_and_state(self, data: bytearray) -> bytearray:
        if not data:
            return data
        n = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        valid_packets = []
        severe_errors = 0
        
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            if mv[offset] != TS_SYNC_BYTE:
                self._error_count += 1
                if self._error_count > 3:
                    self._aligned = False
                    return data[:offset]
                continue
            
            pid = ((mv[offset + 1] & 0x1F) << 8) | mv[offset + 2]
            pusi = (mv[offset + 1] & 0x40) != 0
            cc = mv[offset + 3] & 0x0F
            afc = (mv[offset + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            
            if pid in self._cc_map and has_payload and pid != 0x1FFF:
                expected_cc = (self._cc_map[pid] + 1) & 0x0F
                if cc == expected_cc:
                    self._cc_map[pid] = cc
                elif cc == self._cc_map[pid]:
                    continue 
                else:
                    self._cc_map[pid] = cc
                    self._error_count += 1
                    severe_errors += 1
            else:
                self._cc_map[pid] = cc

            if pusi and has_payload:
                self._found_pusi = True
                
            if pid == 0x0000 and has_payload:
                self._found_pat = True
            elif self._found_pat and not self._found_pmt:
                self._found_pmt = True
            
            if has_payload and not self._found_iframe:
                payload_start = 4
                if afc in (2, 3):
                    payload_start = 5 + mv[offset + 4]
                if payload_start < TS_PACKET_SIZE:
                    if mv[offset + payload_start : offset + min(payload_start + 4, TS_PACKET_SIZE)] == b'\x00\x00\x01\x65':
                        self._found_iframe = True
                    elif mv[offset + payload_start + 3] & 0x7E in (0x26, 0x27):
                        self._found_iframe = True

            valid_packets.append(mv[offset:offset + TS_PACKET_SIZE])
                
        if severe_errors > 5:
            self._aligned = False
            return data[:len(valid_packets) * TS_PACKET_SIZE] if valid_packets else bytearray()
            
        if len(valid_packets) == n:
            return data
            
        return bytearray(b''.join(valid_packets))

    def feed(self, raw: bytes):
        if raw:
            self._buf.extend(raw)
            
        if not self._aligned:
            self._sync_attempts = 0
            idx = self._find_sync(self._buf)
            if idx == -1:
                if len(self._buf) > TS_PACKET_SIZE * 100:
                    self._buf.clear()
                return b''
            if idx > 0:
                del self._buf[:idx]
            self._aligned = True
            
        buf_len = len(self._buf)
        usable = buf_len - (buf_len % TS_PACKET_SIZE)
        if usable == 0:
            return b''
            
        payload = self._buf[:usable]
        del self._buf[:usable]
        payload = self._validate_continuity_and_state(payload)
        
        if not payload:
            return b''
            
        can_release = True
        if not self._found_pusi:
            can_release = False
        if not self._found_pat or not self._found_pmt:
            can_release = False
        if not self._found_iframe:
            can_release = False
            
        if not can_release or self._held_count < MIN_VALID_PACKETS:
            pkts = len(payload) // TS_PACKET_SIZE
            self._held.extend(payload)
            self._held_count += pkts
            if self._held_count >= MIN_VALID_PACKETS and can_release:
                out = bytes(self._held)
                self._held.clear()
                return out
            return b''
            
        return bytes(payload)


class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers): return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


class SessionManager:
    def __init__(self):
        self._session   = None
        self._last_clean = time.time()

    def get_session(self):
        if self._session is None or time.time() - self._last_clean > 30:
            if self._session:
                try: self._session.close()
                except Exception: pass
            self._session = urllib.request.build_opener(
                urllib.request.HTTPHandler(),
                urllib.request.HTTPSHandler(),
                NoRedirectHandler,
            )
            self._last_clean = time.time()
        return self._session


class SafeThreadingHTTPServer(http.server.ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        import sys
        exc_type, _, _ = sys.exc_info()
        if exc_type and issubclass(exc_type, (ConnectionResetError, BrokenPipeError, ConnectionAbortedError, OSError)):
            return
        super().handle_error(request, client_address)


def _ensure_server_running():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.5)
    try:
        sock.connect((HOST, PORT))
        return PORT
    except Exception:
        pass
    finally:
        sock.close()

    srv = SafeThreadingHTTPServer((HOST, PORT), ZeroSuturaProxy)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    time.sleep(0.7)
    return PORT


class ZeroSuturaProxy(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args): return

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        try:
            if len(data) % TS_PACKET_SIZE != 0:
                trim = len(data) % TS_PACKET_SIZE
                data = data[:-trim]
                if not data: return True
            
            mv = memoryview(data)
            num_pkts = len(mv) // TS_PACKET_SIZE
            for i in range(num_pkts):
                if mv[i * TS_PACKET_SIZE] != TS_SYNC_BYTE:
                    return False 
            
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError):
            return False

    def _null_pump(self, cycles: int = 4) -> bool:
        for _ in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            time.sleep(NULL_PUMP_INTERVAL)
        return True

    def _adaptive_null_pump(self, reconnect_time: float) -> bool:
        if reconnect_time < 0.5:
            return self._null_pump(cycles=1)
        elif reconnect_time < 2.0:
            return self._null_pump(cycles=2)
        else:
            return self._null_pump(cycles=4)

    def _resolve_url(self, url: str, ua: str) -> str:
        curr = url
        for _ in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                req = urllib.request.Request(curr, headers={
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc if parsed.netloc else '',
                    'Connection': 'keep-alive',
                })
                session = SessionManager()
                opener = session.get_session()
                with opener.open(req, timeout=10) as resp:
                    if resp.code in (301, 302, 303, 307, 308):
                        loc = resp.headers.get('Location', '')
                        if loc:
                            curr = urllib.parse.urljoin(curr, loc)
                            continue
                    return curr
            except Exception:
                break
        return curr

    def _calculate_backoff(self, reconnect_num: int, error_type: str = 'network') -> float:
        base_delays = {'network': 0.15, 'http': 0.3, 'timeout': 0.2, 'reset': 0.1}
        base = base_delays.get(error_type, 0.2)
        if reconnect_num <= 2:
            return base * reconnect_num
        elif reconnect_num <= 5:
            return base * (reconnect_num ** 1.2)
        else:
            return min(2.5, base * (reconnect_num ** 1.3))

    def do_GET(self):
        query       = urllib.parse.urlparse(self.path).query
        params      = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'keep-alive')
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'keep-alive')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        time.sleep(0.5)

        resolved_url        = original_url
        ua                  = _pick_ua()
        reconnect_num       = 0
        error_type          = 'network'
        last_useful_payload = time.time()
        
        ts_buf              = TsBuffer()
        tail_buf            = TailBuffer()
        suture_acc          = SutureAccumulator()
        session_mgr         = SessionManager()
        delivered_tracker   = LastDeliveredTracker()

        while True:
            ts_buf.reset_soft() 
            last_useful_payload = time.time()

            if reconnect_num > 0:
                suture_acc.start()
            else:
                suture_acc.stop()

            try:
                parsed = urllib.parse.urlparse(resolved_url)
                req = urllib.request.Request(resolved_url, headers={
                    'User-Agent':   ua,
                    'Accept':       '*/*',
                    'Host':         parsed.netloc if parsed.netloc else '',
                    'Referer':      original_url,
                    'Connection':   'keep-alive',
                    'Icy-MetaData': '0',
                })

                opener = session_mgr.get_session()

                with opener.open(req, timeout=15) as response:
                    if reconnect_num == 0:
                        print(f"[ZeroSutura] Conectado → {ua[:30]}...")
                    else:
                        print(f"[ZeroSutura] Reconexão #{reconnect_num} OK → sutura ativa")
                        reconnect_num = max(0, reconnect_num - 2)

                    while True:
                        raw = response.read(65536)

                        if not raw:
                            break

                        payload = ts_buf.feed(raw)

                        if not payload:
                            if time.time() - last_useful_payload > STALL_TIMEOUT:
                                print("[!] Stream stall — forçando reconexão")
                                break
                            continue

                        if suture_acc.active:
                            payload = suture_acc.feed(payload, tail_buf)
                            if not payload:
                                last_useful_payload = time.time()
                                continue

                        payload = delivered_tracker.filter_payload(payload)

                        if not payload:
                            continue

                        last_useful_payload = time.time()
                        tail_buf.append(payload)

                        if not self._safe_write(payload):
                            print("[ZeroSutura] Kodi encerrou a conexão.")
                            return

            except urllib.error.HTTPError as e:
                error_type = 'http'
            except urllib.error.URLError as e:
                reason = str(e.reason).lower()
                error_type = 'timeout' if 'timeout' in reason else ('reset' if 'reset' in reason else 'network')
            except socket.timeout:
                error_type = 'timeout'
            except ConnectionResetError:
                error_type = 'reset'
            except (BrokenPipeError, OSError) as e:
                error_type = 'network'
                if isinstance(e, BrokenPipeError):
                    return
            except Exception as e:
                error_type = 'network'

            reconnect_num += 1
            ua      = _pick_ua()
            backoff = self._calculate_backoff(reconnect_num, error_type)

            if not self._adaptive_null_pump(reconnect_time=backoff):
                return
            if not self._null_pump(cycles=max(1, int(backoff / NULL_PUMP_INTERVAL))):
                return

            try:
                new_url = self._resolve_url(original_url, ua)
                if new_url != resolved_url:
                    resolved_url = new_url
                    print(f"[+] Token atualizado #{reconnect_num}")
            except Exception:
                pass


if __name__ == "__main__":
    port = _ensure_server_running()
    print(f"[ZeroSutura v5.1-Suture Optimized] Proxy rodando em http://{HOST}:{port}/stream?url=<URL>")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("[ZeroSutura] Encerrado.")