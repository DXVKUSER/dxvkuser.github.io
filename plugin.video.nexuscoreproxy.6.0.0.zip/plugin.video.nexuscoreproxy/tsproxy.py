import http.server
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue
import ssl
import json
import struct
import hashlib
import os
from collections import defaultdict, deque
from typing import Dict, Tuple, Optional, List
from http.cookiejar import CookieJar, MozillaCookieJar

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES MPEG-TS (mantidas)
# ─────────────────────────────────────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

_NULL_HDR      = bytes([0x47, 0x1F, 0xFF, 0x10])
TS_NULL_PACKET = _NULL_HDR + b'\xFF' * 184

NULL_PUMP_BURST    = TS_NULL_PACKET * 96
NULL_PUMP_INTERVAL = 0.065

MIN_VALID_PACKETS = 15
SYNC_WINDOW_SIZE = 120
MAX_SYNC_ATTEMPTS_PER_CYCLE = 5

HOST = "127.0.0.1"
PORT = 8080

STALL_TIMEOUT = 4.0
MIN_OUTPUT_BUFFER = 24
MAX_OUTPUT_BUFFER = 96

PID_CLEANUP_AGE = 600
PAT_PID = 0x0000
CAT_PID = 0x0001
NIT_PID = 0x0010
PMT_PID_THRESHOLD = 0x001F

MAX_DUPLICATE_TOLERANCE = 0
MAX_CONTINUITY_ERRORS = 3
LOOP_DETECTION_WINDOW = 500
REPEATED_PAYLOAD_THRESHOLD = 3
CC_HISTORY_SIZE = 50
SYNC_LOSS_THRESHOLD = 5

# ─────────────────────────────────────────────────────────────────────────────
#  PERFIS DE DISPOSITIVO COMPLETOS (IDENTIDADE ROBUSTA)
# ─────────────────────────────────────────────────────────────────────────────

class DeviceProfile:
    """
    Perfil de dispositivo completo que simula um cliente real.
    Cada perfil tem UA, headers, capacidades e comportamento consistentes.
    """
    
    _PROFILES = [
        # ── Kodi Profiles ──
        {
            'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0',
            'accept': '*/*',
            'accept_language': 'en-US,en;q=0.9',
            'accept_encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'client_type': 'kodi',
            'extra_headers': {
                'X-Kodi-Version': '21.0',
                'X-Client-Capabilities': 'streaming',
            },
            'read_pattern': 'steady',  # steady, burst, variable
            'chunk_size_range': (32768, 65536),
        },
        {
            'ua': 'Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 Chrome/120.0 Kodi/21.1',
            'accept': '*/*',
            'accept_language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'accept_encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'client_type': 'kodi_android',
            'extra_headers': {
                'X-Kodi-Version': '21.1',
                'X-Device-Model': 'SM-S918B',
            },
            'read_pattern': 'burst',
            'chunk_size_range': (16384, 49152),
        },
        {
            'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 Kodi/20.5',
            'accept': '*/*',
            'accept_language': 'en-US,en;q=0.9',
            'accept_encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'client_type': 'kodi_macos',
            'extra_headers': {
                'X-Kodi-Version': '20.5',
            },
            'read_pattern': 'steady',
            'chunk_size_range': (32768, 65536),
        },
        # ── VLC Profiles ──
        {
            'ua': 'VLC/3.0.20 LibVLC/3.0.20',
            'accept': '*/*',
            'accept_language': '',
            'accept_encoding': 'gzip, deflate',
            'connection': 'close',
            'client_type': 'vlc',
            'extra_headers': {
                'Icy-MetaData': '1',
            },
            'read_pattern': 'variable',
            'chunk_size_range': (4096, 32768),
        },
        {
            'ua': 'VLC/3.0.18 LibVLC/3.0.18',
            'accept': '*/*',
            'accept_language': '',
            'accept_encoding': 'gzip, deflate',
            'connection': 'close',
            'client_type': 'vlc',
            'extra_headers': {
                'Icy-MetaData': '1',
            },
            'read_pattern': 'variable',
            'chunk_size_range': (8192, 49152),
        },
        # ── FFmpeg/Lavf Profiles ──
        {
            'ua': 'Lavf/60.3.100',
            'accept': '*/*',
            'accept_language': '',
            'accept_encoding': '',
            'connection': 'close',
            'client_type': 'ffmpeg',
            'extra_headers': {},
            'read_pattern': 'steady',
            'chunk_size_range': (32768, 65536),
        },
        {
            'ua': 'Lavf/58.76.100',
            'accept': '*/*',
            'accept_language': '',
            'accept_encoding': '',
            'connection': 'close',
            'client_type': 'ffmpeg',
            'extra_headers': {},
            'read_pattern': 'steady',
            'chunk_size_range': (32768, 65536),
        },
        # ── ExoPlayer (Android) ──
        {
            'ua': 'ExoPlayer/2.19.1 (Linux;Android 14;Pixel 8 Pro)',
            'accept': '*/*',
            'accept_language': 'en-US,en;q=0.9',
            'accept_encoding': '',
            'connection': 'keep-alive',
            'client_type': 'exoplayer',
            'extra_headers': {
                'X-ExoPlayer-Version': '2.19.1',
            },
            'read_pattern': 'burst',
            'chunk_size_range': (16384, 49152),
        },
        {
            'ua': 'ExoPlayer/2.18.7 (Linux;Android 12;SM-A536B)',
            'accept': '*/*',
            'accept_language': 'pt-BR,pt;q=0.9',
            'accept_encoding': '',
            'connection': 'keep-alive',
            'client_type': 'exoplayer',
            'extra_headers': {
                'X-ExoPlayer-Version': '2.18.7',
            },
            'read_pattern': 'burst',
            'chunk_size_range': (16384, 32768),
        },
        # ── Smart TV Profiles ──
        {
            'ua': 'Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.36 Chrome/87.0 Safari/537.36',
            'accept': '*/*',
            'accept_language': 'en-US,en;q=0.9',
            'accept_encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'client_type': 'smartv_lg',
            'extra_headers': {
                'X-Device-Type': 'SmartTV',
            },
            'read_pattern': 'steady',
            'chunk_size_range': (32768, 65536),
        },
        {
            'ua': 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 7.0) AppleWebKit/537.36 Chrome/102 Safari/537.36',
            'accept': '*/*',
            'accept_language': 'pt-BR,pt;q=0.9',
            'accept_encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'client_type': 'smartv_samsung',
            'extra_headers': {
                'X-Device-Type': 'SmartTV',
            },
            'read_pattern': 'steady',
            'chunk_size_range': (32768, 65536),
        },
        # ── Browser Chrome ──
        {
            'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'accept_language': 'en-US,en;q=0.9',
            'accept_encoding': 'gzip, deflate, br',
            'connection': 'keep-alive',
            'client_type': 'chrome',
            'extra_headers': {
                'Sec-Fetch-Dest': 'video',
                'Sec-Fetch-Mode': 'no-cors',
                'Sec-Fetch-Site': 'cross-site',
                'Range': 'bytes=0-',
            },
            'read_pattern': 'burst',
            'chunk_size_range': (16384, 65536),
        },
        {
            'ua': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'accept_language': 'en-US,en;q=0.9',
            'accept_encoding': 'gzip, deflate, br',
            'connection': 'keep-alive',
            'client_type': 'chrome_linux',
            'extra_headers': {
                'Sec-Fetch-Dest': 'video',
                'Sec-Fetch-Mode': 'no-cors',
                'Sec-Fetch-Site': 'cross-site',
            },
            'read_pattern': 'variable',
            'chunk_size_range': (16384, 65536),
        },
        # ── Firefox ──
        {
            'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
            'accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'accept_language': 'en-US,en;q=0.5',
            'accept_encoding': 'gzip, deflate',
            'connection': 'keep-alive',
            'client_type': 'firefox',
            'extra_headers': {
                'Sec-Fetch-Dest': 'video',
                'Sec-Fetch-Mode': 'no-cors',
                'Sec-Fetch-Site': 'cross-site',
            },
            'read_pattern': 'burst',
            'chunk_size_range': (16384, 49152),
        },
    ]

    @classmethod
    def random(cls) -> dict:
        """Retorna um perfil aleatório completo."""
        return random.choice(cls._PROFILES).copy()

    @classmethod
    def different_from(cls, previous_type: str) -> dict:
        """Retorna um perfil DIFERENTE do tipo anterior."""
        candidates = [p for p in cls._PROFILES if p['client_type'] != previous_type]
        if not candidates:
            candidates = cls._PROFILES
        return random.choice(candidates).copy()


# ─────────────────────────────────────────────────────────────────────────────
#  TOR / PROXY ROTATION (OPCIONAL)
# ─────────────────────────────────────────────────────────────────────────────

class ProxyRotator:
    """
    Sistema de rotação de proxies para evitar bloqueio por IP.
    Suporta SOCKS5 (Tor), HTTP proxies e lista de proxies.
    """
    
    def __init__(self, proxy_list: List[str] = None, tor_port: int = 9050):
        self._proxy_list = proxy_list or []
        self._tor_port = tor_port
        self._current_idx = 0
        self._proxy_stats: Dict[str, dict] = {}
        self._tor_available = self._check_tor()
        self._last_tor_renew = 0
        
    def _check_tor(self) -> bool:
        """Verifica se Tor está disponível."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect(('127.0.0.1', self._tor_port))
            sock.close()
            return True
        except Exception:
            return False

    def renew_tor_ip(self) -> bool:
        """Solicita novo IP ao Tor via control port."""
        try:
            control_port = 9051
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect(('127.0.0.1', control_port))
            sock.sendall(b'AUTHENTICATE ""\r\nSIGNAL NEWNYM\r\nQUIT\r\n')
            resp = sock.recv(1024)
            sock.close()
            self._last_tor_renew = time.time()
            time.sleep(2)  # Aguardar Tor trocar circuito
            return b'250' in resp
        except Exception:
            return False

    def get_proxy_handler(self) -> Optional[urllib.request.ProxyHandler]:
        """Retorna um ProxyHandler com o próximo proxy disponível."""
        if self._tor_available:
            return urllib.request.ProxyHandler({
                'http': f'socks5://127.0.0.1:{self._tor_port}',
                'https': f'socks5://127.0.0.1:{self._tor_port}',
            })
        
        if self._proxy_list:
            proxy = self._proxy_list[self._current_idx % len(self._proxy_list)]
            self._current_idx += 1
            return urllib.request.ProxyHandler({
                'http': proxy,
                'https': proxy,
            })
        
        return None

    def should_rotate(self, reconnect_num: int) -> bool:
        """Decide se deve rotacionar proxy."""
        if reconnect_num <= 1:
            return False
        if self._tor_available and reconnect_num % 3 == 0:
            return True
        if self._proxy_list and reconnect_num % 2 == 0:
            return True
        return False


# ─────────────────────────────────────────────────────────────────────────────
#  TLS FINGERPRINT SPOOFER
# ─────────────────────────────────────────────────────────────────────────────

class TLSContextRotator:
    """
    Rotação de contextos TLS para evitar fingerprinting.
    Cada reconexão usa um contexto SSL com parâmetros ligeiramente diferentes.
    """
    
    _CIPHER_SUITES = [
        'ECDHE+AESGCM',
        'ECDHE+CHACHA20',
        'DHE+AESGCM',
        'ECDHE+AES256',
        'DHE+AES256',
    ]
    
    def __init__(self):
        self._context_counter = 0
    
    def create_context(self) -> ssl.SSLContext:
        """Cria um contexto SSL com parâmetros variados."""
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        # Variar opções TLS
        options = ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1
        if self._context_counter % 3 == 0:
            options |= ssl.OP_NO_TLSv1_1
        if self._context_counter % 5 == 0:
            options |= ssl.OP_NO_TLSv1_2
        
        ctx.options = options
        
        # Variar protocolo mínimo
        min_protocols = [ssl.TLSVersion.TLSv1_2, ssl.TLSVersion.TLSv1_3]
        ctx.minimum_version = min_protocols[self._context_counter % len(min_protocols)]
        
        self._context_counter += 1
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
#  SESSION FACTORY AVANÇADA (ANTI-FINGERPRINTING)
# ─────────────────────────────────────────────────────────────────────────────

class SessionFactory:
    """
    Fábrica de sessões HTTP com rotação completa de identidade.
    Cada sessão tem: UA único, headers consistentes, cookies, TLS context.
    """
    
    def __init__(self, use_tor: bool = False, proxy_list: List[str] = None):
        self._cookie_jar = CookieJar()
        self._tls_rotator = TLSContextRotator()
        self._proxy_rotator = ProxyRotator(proxy_list=proxy_list)
        self._session_count = 0
        self._last_profile_type = ''
        self._use_tor = use_tor
        
        # Estatísticas
        self._blocked_count = 0
        self._success_count = 0
        self._last_block_time = 0
    
    def create_session(self, force_new_identity: bool = False) -> Tuple[urllib.request.OpenerDirector, dict]:
        """
        Cria uma nova sessão HTTP com identidade fresca.
        Retorna (opener, profile).
        """
        # Escolher perfil
        if force_new_identity:
            profile = DeviceProfile.different_from(self._last_profile_type)
        else:
            profile = DeviceProfile.random()
        
        self._last_profile_type = profile['client_type']
        
        # Construir handlers
        handlers = []
        
        # TLS context rotacionado
        ssl_ctx = self._tls_rotator.create_context()
        handlers.append(urllib.request.HTTPSHandler(context=ssl_ctx))
        handlers.append(urllib.request.HTTPHandler())
        handlers.append(NoRedirectHandler())
        
        # Proxy rotation
        if self._use_tor or self._proxy_rotator._proxy_list:
            proxy_handler = self._proxy_rotator.get_proxy_handler()
            if proxy_handler:
                handlers.append(proxy_handler)
        
        # Cookie processor
        cookie_processor = urllib.request.HTTPCookieProcessor(self._cookie_jar)
        handlers.append(cookie_processor)
        
        opener = urllib.request.build_opener(*handlers)
        
        self._session_count += 1
        return opener, profile
    
    def mark_blocked(self):
        """Registra que a sessão atual foi bloqueada."""
        self._blocked_count += 1
        self._last_block_time = time.time()
        
        # Se usando Tor, renovar IP
        if self._use_tor:
            self._proxy_rotator.renew_tor_ip()
    
    def mark_success(self):
        """Registra que a sessão teve sucesso."""
        self._success_count += 1
        # Diminuir contador de bloqueios gradualmente
        if self._blocked_count > 0:
            self._blocked_count -= 1
    
    def should_force_new_identity(self) -> bool:
        """Decide se precisa de identidade completamente nova."""
        # Se foi bloqueado recentemente
        if self._blocked_count >= 2 and time.time() - self._last_block_time < 30:
            return True
        # A cada N sessões, forçar mudança
        if self._session_count % 5 == 0:
            return True
        return False


# ─────────────────────────────────────────────────────────────────────────────
#  URL TOKEN REFRESH INTELIGENTE
# ─────────────────────────────────────────────────────────────────────────────

class TokenRefresher:
    """
    Sistema inteligente de atualização de tokens/URLs.
    Analisa a URL para determinar estratégia de refresh.
    """
    
    def __init__(self):
        self._token_history: deque = deque(maxlen=20)
        self._last_refresh = 0
        self._refresh_count = 0
    
    def _extract_token_parts(self, url: str) -> dict:
        """Extrai componentes da URL que podem ser tokens."""
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)
        
        parts = {
            'has_token': False,
            'token_keys': [],
            'domain': parsed.netloc,
            'path': parsed.path,
        }
        
        # Detectar parâmetros que parecem tokens
        token_patterns = ['token', 'key', 'auth', 'sig', 'sign', 'hash', 
                          'session', 'id', 'ticket', 'nonce', 'ts', 'time',
                          'expires', 'exp', 'jwt', 'access', 'secret']
        
        for key in query:
            for pattern in token_patterns:
                if pattern in key.lower():
                    parts['has_token'] = True
                    parts['token_keys'].append(key)
        
        return parts
    
    def _add_cache_buster(self, url: str) -> str:
        """Adiciona parâmetro anti-cache à URL."""
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)
        
        # Adicionar cache buster com nome variado
        buster_names = ['_', 't', 'ts', 'nocache', 'rand', 'r']
        buster_name = random.choice(buster_names)
        query[buster_name] = [str(int(time.time() * 1000) + random.randint(0, 9999))]
        
        new_query = urllib.parse.urlencode(query, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))
    
    def refresh_url(self, original_url: str, current_url: str, 
                    opener: urllib.request.OpenerDirector, 
                    profile: dict) -> str:
        """
        Tenta obter uma URL fresca com token atualizado.
        Estratégias múltiplas em cascata.
        """
        self._refresh_count += 1
        url_info = self._extract_token_parts(original_url)
        
        # Estratégia 1: Seguir redirects a partir da URL original
        try:
            curr = original_url
            for _ in range(5):
                parsed = urllib.parse.urlparse(curr)
                headers = self._build_refresh_headers(parsed, profile)
                
                req = urllib.request.Request(curr, headers=headers)
                
                with opener.open(req, timeout=10) as resp:
                    if resp.code in (301, 302, 303, 307, 308):
                        loc = resp.headers.get('Location', '')
                        if loc:
                            curr = urllib.parse.urljoin(curr, loc)
                            continue
                    elif resp.code == 200:
                        # Verificar se é redirect via HTML/meta
                        content_type = resp.headers.get('Content-Type', '')
                        if 'text' in content_type:
                            body = resp.read(4096).decode('utf-8', errors='ignore')
                            import re
                            match = re.search(r'(?:content|http-equiv).*?url=(.*?)["\']', body, re.I)
                            if match:
                                curr = urllib.parse.urljoin(curr, match.group(1))
                                continue
                        
                        if curr != current_url:
                            self._last_refresh = time.time()
                            return curr
                    return curr
        except Exception:
            pass
        
        # Estratégia 2: Adicionar cache buster
        if url_info['has_token']:
            return self._add_cache_buster(current_url)
        
        # Estratégia 3: Reconstruir URL base com timestamp
        if self._refresh_count % 3 == 0:
            return self._add_cache_buster(current_url)
        
        return current_url
    
    def _build_refresh_headers(self, parsed, profile: dict) -> dict:
        """Constroi headers para request de refresh."""
        return {
            'User-Agent': profile['ua'],
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': profile.get('accept_language', 'en-US,en;q=0.9'),
            'Accept-Encoding': profile.get('accept_encoding', 'gzip, deflate'),
            'Host': parsed.netloc,
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
        }


# ─────────────────────────────────────────────────────────────────────────────
#  ADAPTIVE BACKOFF COM JITTER (ANTI-PATTERN DETECTION)
# ─────────────────────────────────────────────────────────────────────────────

class AdaptiveBackoff:
    """
    Backoff adaptativo com jitter que evade detecção de padrões.
    Simula comportamento humano e varia timing de forma imprevisível.
    """
    
    # Diferentes estratégias de backoff
    _STRATEGIES = {
        'exponential_jitter': lambda n, base: base * (2 ** min(n, 6)) * random.uniform(0.5, 1.5),
        'polynomial_jitter': lambda n, base: base * (n ** 1.3) * random.uniform(0.7, 1.4),
        'fibonacci_jitter': lambda n, base: base * _fib(n) * random.uniform(0.6, 1.5),
        'random_walk': lambda n, base: base * random.uniform(0.5, min(15, n * 1.8)),
        'decorrelated': lambda n, base: min(30, base * random.uniform(1, 2 ** min(n, 5))),
    }
    
    def __init__(self):
        self._history: deque = deque(maxlen=50)
        self._last_strategy = None
        self._consecutive_blocks = 0
        self._last_block_time = 0
    
    def calculate(self, reconnect_num: int, error_type: str = 'network',
                  was_blocked: bool = False) -> float:
        """
        Calcula tempo de espera antes da reconexão.
        Varia estratégia para não criar padrão detectável.
        """
        
        if was_blocked:
            self._consecutive_blocks += 1
            self._last_block_time = time.time()
        else:
            self._consecutive_blocks = max(0, self._consecutive_blocks - 1)
        
        # Base delays por tipo de erro
        base_delays = {
            'network': 0.15,
            'http': 0.3,
            'timeout': 0.2,
            'reset': 0.1,
            'blocked': 1.0,
            'rate_limit': 2.0,
            'forbidden': 3.0,
        }
        
        base = base_delays.get(error_type, 0.2)
        
        # Se foi bloqueado explicitamente, aumentar base
        if was_blocked:
            base = max(base, 1.0 + self._consecutive_blocks * 0.5)
        
        # Escolher estratégia diferente da última
        strategies = list(self._STRATEGIES.keys())
        if self._last_strategy and len(strategies) > 1:
            strategies = [s for s in strategies if s != self._last_strategy]
        
        strategy_name = random.choice(strategies)
        strategy_fn = self._STRATEGIES[strategy_name]
        self._last_strategy = strategy_name
        
        # Calcular delay
        delay = strategy_fn(reconnect_num, base)
        
        # Cap máximo
        max_delay = 15.0 if not was_blocked else 30.0
        delay = min(delay, max_delay)
        
        # Garantir mínimo
        delay = max(delay, 0.05)
        
        # Adicionar micro-jitter adicional (simula variação de rede)
        delay += random.gauss(0, 0.02)
        delay = max(0.01, delay)
        
        # Registrar no histórico
        self._history.append({
            'time': time.time(),
            'delay': delay,
            'reconnect_num': reconnect_num,
            'error_type': error_type,
            'strategy': strategy_name,
        })
        
        return delay
    
    def get_pre_connect_delay(self) -> float:
        """
        Delay ANTES de conectar (simula tempo de setup do player).
        Ajuda a parecer mais natural.
        """
        # Tempo de "buffering" que players reais têm
        delays = [0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.8, 1.0]
        weights = [0.3, 0.25, 0.15, 0.1, 0.08, 0.05, 0.04, 0.02, 0.01]
        return random.choices(delays, weights=weights, k=1)[0]


def _fib(n: int) -> int:
    """Fibonacci rápido para backoff."""
    if n <= 0: return 1
    if n == 1: return 1
    a, b = 1, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


# ─────────────────────────────────────────────────────────────────────────────
#  RECONNECTION STATS TRACKER
# ─────────────────────────────────────────────────────────────────────────────

class ReconnectionTracker:
    """
    Rastreia estatísticas de reconexão para detectar padrões de bloqueio
    e ajustar comportamento automaticamente.
    """
    
    def __init__(self):
        self._events: deque = deque(maxlen=100)
        self._block_patterns: Dict[str, int] = defaultdict(int)
        self._successful_profiles: Dict[str, int] = defaultdict(int)
        self._failed_profiles: Dict[str, int] = defaultdict(int)
        self._error_codes: Dict[int, int] = defaultdict(int)
    
    def record_attempt(self, profile_type: str, error_type: str, 
                       error_code: int = 0, was_blocked: bool = False):
        """Registra uma tentativa de reconexão."""
        event = {
            'time': time.time(),
            'profile': profile_type,
            'error_type': error_type,
            'error_code': error_code,
            'was_blocked': was_blocked,
        }
        self._events.append(event)
        
        if was_blocked:
            self._block_patterns[profile_type] += 1
            self._failed_profiles[profile_type] += 1
        else:
            self._successful_profiles[profile_type] += 1
        
        if error_code:
            self._error_codes[error_code] += 1
    
    def get_best_profile(self) -> str:
        """Retorna o tipo de perfil com mais sucesso."""
        if not self._successful_profiles:
            return ''
        
        best = max(self._successful_profiles.items(), key=lambda x: x[1])
        return best[0]
    
    def is_being_rate_limited(self) -> bool:
        """Detecta se está sendo rate-limited baseado no padrão de erros."""
        if len(self._events) < 5:
            return False
        
        recent = list(self._events)[-10:]
        block_count = sum(1 for e in recent if e.get('was_blocked'))
        return block_count >= 5
    
    def get_recommended_delay_multiplier(self) -> float:
        """Retorna multiplicador de delay baseado no histórico."""
        if self.is_being_rate_limited():
            return 3.0
        
        recent = list(self._events)[-5:]
        errors = sum(1 for e in recent if e.get('was_blocked'))
        
        if errors >= 3:
            return 2.0
        elif errors >= 2:
            return 1.5
        elif errors >= 1:
            return 1.2
        return 1.0


# ─────────────────────────────────────────────────────────────────────────────
#  TsBuffer (MANTIDO IGUAL - já está otimizado)
# ─────────────────────────────────────────────────────────────────────────────
class TsBuffer:
    """
    Buffer MPEG-TS com detecção agressiva de loops e repetições.
    Foco em NUNCA reenviar pacotes já transmitidos.
    """
    
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._held = bytearray()
        self._held_count = 0
        
        self._cc_map: Dict[int, int] = {}
        self._cc_history: Dict[int, deque] = {}
        self._pid_activity: Dict[int, float] = {}
        self._pid_discontinuities: Dict[int, int] = {}
        self._pid_type_cache: Dict[int, str] = {}
        
        self._persistent_cc_context: Dict[int, Tuple[int, float]] = {}
        
        self._recent_payload_hashes = deque(maxlen=LOOP_DETECTION_WINDOW)
        self._payload_hash_counter: Dict[str, int] = {}
        self._loop_detected = False
        self._last_output_hash = None
        
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._total_packets = 0
        self._rejected_packets = 0
        self._duplicate_packets = 0
        self._discontinuity_events = 0
        self._loop_detection_count = 0
        self._forced_resyncs = 0
        
        self._frozen_detection_counter = 0
        self._last_unique_payload_hash = None

    def reset(self, preserve_context: bool = False):
        self._buf.clear()
        self._aligned = False
        self._held.clear()
        self._held_count = 0
        
        if not preserve_context:
            self._cc_map.clear()
            self._cc_history.clear()
            self._pid_activity.clear()
            self._pid_discontinuities.clear()
        
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._frozen_detection_counter = 0
        self._last_unique_payload_hash = None
        self._last_output_hash = None
        self._loop_detected = False
        self._recent_payload_hashes.clear()
        self._payload_hash_counter.clear()

    def _classify_pid(self, pid: int) -> str:
        if pid in self._pid_type_cache:
            return self._pid_type_cache[pid]
        
        if pid == PAT_PID:
            pid_type = 'psi_critical'
        elif pid == CAT_PID or pid == NIT_PID:
            pid_type = 'psi_important'
        elif pid <= PMT_PID_THRESHOLD:
            pid_type = 'psi'
        else:
            pid_type = 'media'
        
        self._pid_type_cache[pid] = pid_type
        return pid_type

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                return -1
            
            self._sync_attempts += 1
            
            if idx + TS_PACKET_SIZE * 5 <= length:
                sync_valid = True
                for offset in range(TS_PACKET_SIZE, TS_PACKET_SIZE * 5, TS_PACKET_SIZE):
                    if data[idx + offset] != TS_SYNC_BYTE:
                        sync_valid = False
                        break
                
                if sync_valid:
                    if idx + TS_PACKET_SIZE * SYNC_WINDOW_SIZE <= length:
                        for offset in range(TS_PACKET_SIZE * 5, 
                                            TS_PACKET_SIZE * min(SYNC_WINDOW_SIZE, 20), 
                                            TS_PACKET_SIZE):
                            if data[idx + offset] != TS_SYNC_BYTE:
                                sync_valid = False
                                break
                    
                    if sync_valid:
                        self._last_sync_idx = idx
                        return idx
            
            idx += 1
        
        return -1

    def _detect_loop(self, data: bytes) -> bool:
        if len(data) < TS_PACKET_SIZE * 3:
            return False
        
        payload_hash = hashlib.sha256(data[:TS_PACKET_SIZE * 5]).hexdigest()
        
        if payload_hash in self._payload_hash_counter:
            self._payload_hash_counter[payload_hash] += 1
            
            if self._payload_hash_counter[payload_hash] >= REPEATED_PAYLOAD_THRESHOLD:
                self._loop_detected = True
                self._loop_detection_count += 1
                return True
        else:
            self._payload_hash_counter.clear()
            self._payload_hash_counter[payload_hash] = 1
        
        self._recent_payload_hashes.append(payload_hash)
        
        return False

    def _check_cc_loop(self, pid: int, cc: int) -> bool:
        if pid not in self._cc_history:
            self._cc_history[pid] = deque(maxlen=CC_HISTORY_SIZE)
        
        history = self._cc_history[pid]
        history.append(cc)
        
        if len(history) >= 10:
            last_5 = list(history)[-5:]
            if len(set(last_5)) == 1:
                return True
            
            if len(history) >= 6:
                recent = list(history)[-6:]
                if recent[:3] == recent[3:]:
                    return True
        
        return False

    def _extract_packet_info(self, data: memoryview, offset: int) -> Optional[dict]:
        try:
            pid = ((data[offset + 1] & 0x1F) << 8) | data[offset + 2]
            cc = data[offset + 3] & 0x0F
            afc = (data[offset + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            transport_error = (data[offset + 1] & 0x80) != 0
            pusi = (data[offset + 1] & 0x40) != 0
            
            return {
                'pid': pid,
                'cc': cc,
                'afc': afc,
                'has_payload': has_payload,
                'transport_error': transport_error,
                'pusi': pusi,
                'pid_type': self._classify_pid(pid)
            }
        except IndexError:
            return None

    def _advanced_continuity_check(self, info: dict, pid: int, cc: int) -> Tuple[bool, str]:
        if self._check_cc_loop(pid, cc):
            return False, 'cc_loop_detected'
        
        if pid not in self._cc_map:
            self._cc_map[pid] = cc
            self._pid_activity[pid] = time.time()
            return True, 'first_seen'
        
        expected_cc = (self._cc_map[pid] + 1) & 0x0F
        
        if cc == expected_cc:
            self._cc_map[pid] = cc
            self._pid_activity[pid] = time.time()
            self._pid_discontinuities[pid] = 0
            return True, 'perfect'
        
        if cc == self._cc_map[pid]:
            self._duplicate_packets += 1
            return False, 'duplicate_rejected'
        
        discontinuities = self._pid_discontinuities.get(pid, 0)
        pid_type = info['pid_type']
        
        if pid_type == 'psi_critical':
            if discontinuities >= 1:
                self._forced_resyncs += 1
                return False, 'critical_discontinuity_rejected'
        elif pid_type == 'media' and info.get('pusi', False):
            if discontinuities >= 2:
                return False, 'media_pusi_rejected'
        elif pid_type == 'media':
            if discontinuities >= 2:
                return False, 'media_rejected'
        else:
            if discontinuities >= 1:
                return False, 'other_rejected'
        
        self._cc_map[pid] = cc
        self._pid_activity[pid] = time.time()
        self._pid_discontinuities[pid] = discontinuities + 1
        self._discontinuity_events += 1
        return True, 'discontinuity_accepted'

    def _detect_frozen_stream(self, payload: bytes) -> bool:
        if len(payload) < TS_PACKET_SIZE * 3:
            return False
        
        payload_hash = hashlib.sha256(payload[:TS_PACKET_SIZE * 5]).hexdigest()
        
        if payload_hash == self._last_unique_payload_hash:
            self._frozen_detection_counter += 1
            if self._frozen_detection_counter > 10:
                return True
        else:
            self._last_unique_payload_hash = payload_hash
            self._frozen_detection_counter = 0
        
        return False

    def _cleanup_stale_pids(self):
        current_time = time.time()
        stale_pids = []
        
        for pid, last_active in self._pid_activity.items():
            if current_time - last_active > PID_CLEANUP_AGE:
                stale_pids.append(pid)
        
        for pid in stale_pids:
            if pid in self._cc_map:
                self._persistent_cc_context[pid] = (
                    self._cc_map[pid],
                    current_time
                )
            self._cc_map.pop(pid, None)
            self._pid_activity.pop(pid, None)
            self._pid_discontinuities.pop(pid, None)
            self._cc_history.pop(pid, None)

    def _restore_context(self):
        current_time = time.time()
        restored_count = 0
        
        for pid, (cc, timestamp) in list(self._persistent_cc_context.items()):
            if current_time - timestamp < 120:
                if pid not in self._cc_map:
                    self._cc_map[pid] = cc
                    self._pid_activity[pid] = current_time
                    restored_count += 1
            else:
                del self._persistent_cc_context[pid]
        
        return restored_count

    def feed(self, raw: bytes, is_reconnection: bool = False) -> bytes:
        if is_reconnection:
            self._restore_context()
        
        if raw:
            self._buf.extend(raw)
        
        if self._total_packets > 0 and self._total_packets % 1000 == 0:
            self._cleanup_stale_pids()
        
        if not self._aligned:
            self._sync_attempts = 0
            idx = self._find_sync(self._buf)
            if idx == -1:
                if len(self._buf) > TS_PACKET_SIZE * 300:
                    self._buf.clear()
                return b''
            if idx > 0:
                del self._buf[:idx]
            self._aligned = True
        
        buf_len = len(self._buf)
        usable = buf_len - (buf_len % TS_PACKET_SIZE)
        if usable == 0:
            return b''
        
        payload = self._buf[:usable]
        del self._buf[:usable]
        
        validated_payload = self._validate_continuity_advanced(payload)
        
        if not validated_payload:
            return b''
        
        if self._detect_loop(validated_payload):
            print(f"[!] LOOP DETECTADO - Forçando ressincronização")
            self._aligned = False
            self._loop_detection_count += 1
            return b''
        
        if self._detect_frozen_stream(validated_payload):
            print(f"[!] Stream congelado detectado - Forçando ressincronização")
            self._aligned = False
            return b''
        
        self._total_packets += len(validated_payload) // TS_PACKET_SIZE
        
        if self._held_count < MIN_VALID_PACKETS:
            pkts = len(validated_payload) // TS_PACKET_SIZE
            self._held.extend(validated_payload)
            self._held_count += pkts
            
            if self._held_count >= MIN_VALID_PACKETS:
                out = bytes(self._held)
                
                if self._detect_loop(out):
                    print(f"[!] LOOP no buffer de aquecimento - Resetando")
                    self._held.clear()
                    self._held_count = 0
                    return b''
                
                self._held.clear()
                return out
            return b''
        
        return bytes(validated_payload)

    def _validate_continuity_advanced(self, data: bytearray) -> bytearray:
        if not data:
            return data
        
        n = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        valid_packets = []
        severe_errors = 0
        critical_pid_errors = 0
        consecutive_rejects = 0
        
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            
            if mv[offset] != TS_SYNC_BYTE:
                self._error_count += 1
                consecutive_rejects += 1
                if consecutive_rejects > 3 or self._error_count > SYNC_LOSS_THRESHOLD:
                    self._aligned = False
                    return data[:offset]
                continue
            
            info = self._extract_packet_info(mv, offset)
            if info is None:
                consecutive_rejects += 1
                continue
            
            if info['transport_error']:
                self._error_count += 1
                consecutive_rejects += 1
                continue
            
            pid = info['pid']
            
            if pid == 0x1FFF:
                valid_packets.append(i)
                consecutive_rejects = 0
                continue
            
            if info['has_payload']:
                is_valid, reason = self._advanced_continuity_check(info, pid, info['cc'])
                
                if is_valid:
                    valid_packets.append(i)
                    consecutive_rejects = 0
                    
                    if reason.startswith('discontinuity'):
                        if info['pid_type'] == 'psi_critical':
                            critical_pid_errors += 1
                        else:
                            severe_errors += 1
                else:
                    self._rejected_packets += 1
                    consecutive_rejects += 1
                    
                    if consecutive_rejects > 10:
                        self._aligned = False
                        return data[:offset]
            else:
                valid_packets.append(i)
                consecutive_rejects = 0
        
        if critical_pid_errors > 2 or severe_errors > 8:
            self._aligned = False
            return data[:valid_packets[0] * TS_PACKET_SIZE] if valid_packets else bytearray()
        
        if len(valid_packets) == n:
            return data
        else:
            result = bytearray()
            for idx in valid_packets:
                start = idx * TS_PACKET_SIZE
                result.extend(data[start:start + TS_PACKET_SIZE])
            return result


# ─────────────────────────────────────────────────────────────────────────────
#  OUTPUT BUFFER
# ─────────────────────────────────────────────────────────────────────────────
class OutputBuffer:
    def __init__(self, min_packets=MIN_OUTPUT_BUFFER, max_packets=MAX_OUTPUT_BUFFER):
        self._queue = queue.Queue(maxsize=max_packets)
        self._min_packets = min_packets
        self._packet_time = 0.0007
    
    def put(self, data: bytes) -> bool:
        try:
            self._queue.put(data, block=False)
            return True
        except queue.Full:
            return False
    
    def get(self) -> bytes:
        try:
            return self._queue.get_nowait()
        except queue.Empty:
            return b''
    
    def size(self) -> int:
        return self._queue.qsize()
    
    def clear(self):
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break


# ─────────────────────────────────────────────────────────────────────────────
#  HANDLERS E HELPERS
# ─────────────────────────────────────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers): return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


# ─────────────────────────────────────────────────────────────────────────────
#  SERVER
# ─────────────────────────────────────────────────────────────────────────────
def _ensure_server_running():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.5)
    try:
        sock.connect((HOST, PORT))
        return PORT
    except Exception:
        pass
    finally:
        sock.close()

    srv = http.server.ThreadingHTTPServer((HOST, PORT), ZeroSuturaProxy)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    time.sleep(0.7)
    return PORT


# ─────────────────────────────────────────────────────────────────────────────
#  PROXY HANDLER - COM RECONEXÃO AVANÇADA ANTI-BLOQUEIO
# ─────────────────────────────────────────────────────────────────────────────
class ZeroSuturaProxy(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args): 
        return

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError):
            return False

    def _null_pump(self, cycles: int = 4) -> bool:
        for _ in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            time.sleep(NULL_PUMP_INTERVAL)
        return True

    def _adaptive_null_pump(self, reconnect_time: float) -> bool:
        """Bomba de nulls adaptativa com VARIAÇÃO de timing."""
        if reconnect_time < 0.5:
            cycles = 1
        elif reconnect_time < 2.0:
            cycles = 2
        else:
            cycles = 4
        
        for i in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            # Jitter no intervalo entre pumps
            jitter = random.uniform(0.8, 1.2)
            time.sleep(NULL_PUMP_INTERVAL * jitter)
        return True

    def _build_request_headers(self, url: str, profile: dict, 
                                original_url: str,
                                reconnect_num: int) -> dict:
        """
        Constrói headers HTTP completos e variados para cada reconexão.
        Simula comportamento de player real com headers consistentes ao perfil.
        """
        parsed = urllib.parse.urlparse(url)
        
        # Headers base do perfil
        headers = {
            'User-Agent': profile['ua'],
            'Accept': profile.get('accept', '*/*'),
            'Host': parsed.netloc,
        }
        
        # Accept-Language (do perfil ou variado)
        if profile.get('accept_language'):
            headers['Accept-Language'] = profile['accept_language']
        
        # Accept-Encoding (do perfil)
        if profile.get('accept_encoding'):
            headers['Accept-Encoding'] = profile['accept_encoding']
        
        # Connection - variar entre keep-alive e close
        connection = profile.get('connection', 'keep-alive')
        # A cada 3 reconexões, usar close (mais realista)
        if reconnect_num > 0 and reconnect_num % 3 == 0:
            connection = 'close'
        headers['Connection'] = connection
        
        # Referer - estratégia variada
        if reconnect_num == 0:
            headers['Referer'] = original_url
        elif reconnect_num % 2 == 0:
            # Às vezes enviar referer da própria URL
            headers['Referer'] = url
        else:
            # Às vezes não enviar referer (como players nativos)
            pass
        
        # Icy-MetaData - variar
        if profile.get('client_type') in ('vlc', 'kodi', 'kodi_android', 'kodi_macos'):
            headers['Icy-MetaData'] = random.choice(['0', '1'])
        
        # Range header - simular resumo de playback
        if reconnect_num > 0 and random.random() < 0.4:
            headers['Range'] = 'bytes=0-'
        
        # Extra headers do perfil
        for k, v in profile.get('extra_headers', {}).items():
            headers[k] = v
        
        # Headers anti-cache variados
        if random.random() < 0.5:
            headers['Cache-Control'] = 'no-cache'
        if random.random() < 0.3:
            headers['Pragma'] = 'no-cache'
        
        # Origin header (para streams cross-origin)
        if profile.get('client_type') in ('chrome', 'chrome_linux', 'firefox'):
            origin_parsed = urllib.parse.urlparse(original_url)
            headers['Origin'] = f'{origin_parsed.scheme}://{origin_parsed.netloc}'
        
        # Randomização da ORDEM dos headers (evita fingerprinting por ordem)
        # urllib não preserva ordem nativamente, mas tentamos
        return headers

    def _get_chunk_size(self, profile: dict, reconnect_num: int) -> int:
        """
        Tamanho variado de chunk de leitura.
        Simula diferentes padrões de consumo de players.
        """
        pattern = profile.get('read_pattern', 'steady')
        min_sz, max_sz = profile.get('chunk_size_range', (32768, 65536))
        
        if pattern == 'steady':
            return random.randint(min_sz, max_sz)
        elif pattern == 'burst':
            # Alternar entre leituras grandes e pequenas
            if random.random() < 0.3:
                return random.randint(4096, min_sz)
            else:
                return random.randint(min_sz, max_sz)
        elif pattern == 'variable':
            return random.randint(8192, max_sz)
        
        return random.randint(min_sz, max_sz)

    def _detect_block_response(self, response) -> Tuple[bool, str]:
        """
        Detecta se a resposta é um bloqueio disfarçado.
        Muitos servidores retornam 200 com conteúdo de erro.
        """
        content_type = response.headers.get('Content-Type', '')
        content_length = response.headers.get('Content-Length', '')
        
        # Se o Content-Type não é vídeo/stream
        if content_type and 'video' not in content_type and 'octet' not in content_type:
            if 'text' in content_type or 'html' in content_type:
                return True, 'html_response'
        
        # Se Content-Length é muito pequeno para ser stream
        try:
            if content_length and int(content_length) < 1000:
                return True, 'tiny_response'
        except ValueError:
            pass
        
        return False, ''

    def _preflight_check(self, url: str, opener, profile: dict) -> Optional[str]:
        """
        Request HEAD/GET leve antes da conexão principal.
        Verifica se a URL está acessível e obtém redirect atualizado.
        Alguns servidores respondem diferente para HEAD vs GET,
        então usamos GET com Range para minimizar transferência.
        """
        try:
            parsed = urllib.parse.urlparse(url)
            req = urllib.request.Request(url, headers={
                'User-Agent': profile['ua'],
                'Accept': '*/*',
                'Host': parsed.netloc,
                'Range': 'bytes=0-1023',  # Pedir só 1KB
                'Connection': 'close',
            })
            
            with opener.open(req, timeout=8) as resp:
                if resp.code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get('Location', '')
                    if loc:
                        return urllib.parse.urljoin(url, loc)
                elif resp.code == 200:
                    # Verificar se é vídeo real
                    is_blocked, reason = self._detect_block_response(resp)
                    if is_blocked:
                        print(f"[!] Preflight detectou bloqueio: {reason}")
                        return None
                elif resp.code in (403, 429, 451):
                    print(f"[!] Preflight bloqueado: HTTP {resp.code}")
                    return None
            
            return url
        except Exception:
            return url  # Se falhou, tentar direto mesmo

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'keep-alive')
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'keep-alive')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        # ── Inicialização dos sistemas avançados ──
        session_factory = SessionFactory(
            use_tor=False,  # Mude para True se tiver Tor
            proxy_list=None  # Adicione lista de proxies se tiver
        )
        backoff_engine = AdaptiveBackoff()
        token_refresher = TokenRefresher()
        tracker = ReconnectionTracker()
        
        ts_buf = TsBuffer()
        output_buf = OutputBuffer()
        
        resolved_url = original_url
        current_profile = DeviceProfile.random()
        reconnect_num = 0
        consecutive_failures = 0
        last_useful_payload = time.time()
        error_type = 'network'
        was_blocked = False
        total_bytes_received = 0

        # Delay inicial de "buffering" (simula player real)
        time.sleep(random.uniform(0.3, 0.8))

        while True:
            # ── Reset do buffer TS ──
            if reconnect_num > 0:
                ts_buf.reset(preserve_context=True)
            else:
                ts_buf.reset()
            
            output_buf.clear()
            last_useful_payload = time.time()
            
            # ── Decidir se precisa de identidade nova ──
            force_new = session_factory.should_force_new_identity()
            if was_blocked:
                force_new = True
            
            # ── Criar sessão com identidade fresca ──
            opener, current_profile = session_factory.create_session(
                force_new_identity=force_new
            )
            
            # ── Calcular e aplicar backoff ──
            if reconnect_num > 0:
                delay = backoff_engine.calculate(
                    reconnect_num, error_type, was_blocked
                )
                
                # Multiplicador baseado no tracker
                delay *= tracker.get_recommended_delay_multiplier()
                
                # Pre-connect delay (simula tempo de setup)
                pre_delay = backoff_engine.get_pre_connect_delay()
                
                # Bomba de nulls durante o backoff
                if not self._adaptive_null_pump(reconnect_time=pre_delay):
                    return
                
                time.sleep(delay)
                
                if not self._null_pump(cycles=max(1, int(delay / NULL_PUMP_INTERVAL))):
                    return
            
            # ── Atualizar token/URL ──
            if reconnect_num > 0:
                try:
                    new_url = token_refresher.refresh_url(
                        original_url, resolved_url, opener, current_profile
                    )
                    if new_url != resolved_url:
                        resolved_url = new_url
                        print(f"[+] URL/Token atualizado #{reconnect_num}")
                except Exception:
                    pass
            
            # ── Preflight check (a cada 3 reconexões) ──
            if reconnect_num > 0 and reconnect_num % 3 == 0:
                preflight_result = self._preflight_check(
                    resolved_url, opener, current_profile
                )
                if preflight_result is None:
                    # Bloqueado no preflight - mudar identidade completamente
                    was_blocked = True
                    tracker.record_attempt(
                        current_profile['client_type'], 'blocked', 0, True
                    )
                    session_factory.mark_blocked()
                    reconnect_num += 1
                    consecutive_failures += 1
                    continue
                elif preflight_result != resolved_url:
                    resolved_url = preflight_result
            
            # ── Construir headers variados ──
            headers = self._build_request_headers(
                resolved_url, current_profile, original_url, reconnect_num
            )
            
            try:
                req = urllib.request.Request(resolved_url, headers=headers)
                
                # Timeout variado (simula diferentes condições de rede)
                timeout = random.choice([12, 15, 18, 20])
                
                with opener.open(req, timeout=timeout) as response:
                    # ── Verificar resposta ──
                    is_blocked, block_reason = self._detect_block_response(response)
                    
                    if is_blocked:
                        print(f"[!] Bloqueio detectado na resposta: {block_reason}")
                        was_blocked = True
                        session_factory.mark_blocked()
                        tracker.record_attempt(
                            current_profile['client_type'], 'blocked', 
                            response.code, True
                        )
                        reconnect_num += 1
                        consecutive_failures += 1
                        continue
                    
                    if reconnect_num == 0:
                        print(f"[ZeroSutra] Conectado → {current_profile['client_type']} / {current_profile['ua'][:30]}...")
                    else:
                        print(f"[ZeroSutra] Reconectado #{reconnect_num} → {current_profile['client_type']}")
                    
                    # Sucesso - resetar contadores
                    session_factory.mark_success()
                    consecutive_failures = 0
                    was_blocked = False
                    
                    # Diminuir reconnect_num gradualmente em sucesso
                    if reconnect_num > 0:
                        reconnect_num = max(0, reconnect_num - 2)
                    
                    # ── Loop de leitura com chunk size variado ──
                    chunk_size = self._get_chunk_size(current_profile, reconnect_num)
                    read_count = 0
                    
                    while True:
                        # Variar chunk size periodicamente
                        if read_count % 20 == 0:
                            chunk_size = self._get_chunk_size(
                                current_profile, reconnect_num
                            )
                        
                        raw = response.read(chunk_size)
                        read_count += 1

                        if not raw:
                            # Stream terminou normalmente ou EOF do servidor
                            print(f"[!] Fim do stream (EOF) após {read_count} reads")
                            break

                        total_bytes_received += len(raw)
                        payload = ts_buf.feed(
                            raw, 
                            is_reconnection=(reconnect_num > 0 and reconnect_num <= 2)
                        )
                        
                        if payload:
                            last_useful_payload = time.time()
                            output_buf.put(payload)
                            
                            while output_buf.size() >= MIN_OUTPUT_BUFFER:
                                output_data = output_buf.get()
                                if output_data:
                                    if not self._safe_write(output_data):
                                        print("[ZeroSutra] Cliente encerrou a conexão.")
                                        return
                        else:
                            if time.time() - last_useful_payload > STALL_TIMEOUT:
                                print("[!] Stream stall - forçando reconexão")
                                break
                        
                        # Micro-pause variado (simula jitter de rede real)
                        if read_count % 5 == 0:
                            time.sleep(random.uniform(0.001, 0.01))

            except urllib.error.HTTPError as e:
                error_code = e.code
                
                # Classificar tipo de erro
                if error_code == 403:
                    error_type = 'forbidden'
                    was_blocked = True
                    session_factory.mark_blocked()
                    print(f"[!] FORBIDDEN 403 #{reconnect_num} - Bloqueio detectado")
                elif error_code == 429:
                    error_type = 'rate_limit'
                    was_blocked = True
                    session_factory.mark_blocked()
                    print(f"[!] RATE LIMIT 429 #{reconnect_num}")
                elif error_code == 451:
                    error_type = 'forbidden'
                    was_blocked = True
                    print(f"[!] UNAVAILABLE 451 #{reconnect_num} - Bloqueio legal")
                elif error_code in (401, 407):
                    error_type = 'blocked'
                    was_blocked = True
                    session_factory.mark_blocked()
                    print(f"[!] AUTH REQUIRED {error_code} #{reconnect_num}")
                elif error_code in (500, 502, 503, 504):
                    error_type = 'http'
                    print(f"[!] SERVER ERROR {error_code} #{reconnect_num}")
                else:
                    error_type = 'http'
                    print(f"[!] HTTP {error_code} #{reconnect_num}")
                
                tracker.record_attempt(
                    current_profile['client_type'], error_type, error_code, was_blocked
                )

            except urllib.error.URLError as e:
                reason = str(e.reason).lower()
                if 'timeout' in reason:
                    error_type = 'timeout'
                elif 'reset' in reason:
                    error_type = 'reset'
                elif 'refused' in reason:
                    error_type = 'reset'
                    was_blocked = True  # Connection refused pode ser bloqueio
                elif 'blocked' in reason or 'denied' in reason:
                    error_type = 'blocked'
                    was_blocked = True
                else:
                    error_type = 'network'
                
                print(f"[!] URLError #{reconnect_num}: {e.reason}")
                tracker.record_attempt(
                    current_profile['client_type'], error_type, 0, was_blocked
                )

            except socket.timeout:
                error_type = 'timeout'
                print(f"[!] Timeout #{reconnect_num}")
                tracker.record_attempt(
                    current_profile['client_type'], error_type, 0, False
                )

            except ConnectionResetError:
                error_type = 'reset'
                # Connection reset frequente = possível bloqueio
                consecutive_failures += 1
                if consecutive_failures >= 3:
                    was_blocked = True
                print(f"[!] Connection reset #{reconnect_num}")
                tracker.record_attempt(
                    current_profile['client_type'], error_type, 0, was_blocked
                )

            except (BrokenPipeError, OSError) as e:
                error_type = 'network'
                if isinstance(e, BrokenPipeError):
                    print("[ZeroSutra] Cliente encerrou (BrokenPipe).")
                    return
                print(f"[!] Erro conexão #{reconnect_num}: {type(e).__name__}")
                tracker.record_attempt(
                    current_profile['client_type'], error_type, 0, False
                )

            except Exception as e:
                error_type = 'network'
                print(f"[!] Erro #{reconnect_num}: {type(e).__name__}")
                tracker.record_attempt(
                    current_profile['client_type'], error_type, 0, False
                )

            # ── RECONEXÃO ──
            reconnect_num += 1
            consecutive_failures += 1
            
            # Se muitas falhas consecutivas, forçar troca de identidade
            if consecutive_failures >= 4:
                was_blocked = True
                session_factory.mark_blocked()
                print(f"[!] {consecutive_failures} falhas consecutivas - Forçando nova identidade")
            
            # Limite de segurança
            if reconnect_num > 100:
                print(f"[!] Limite de reconexões atingido ({reconnect_num})")
                return


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = _ensure_server_running()
    print(f"[ZeroSutra v38 Anti-Block] Proxy em http://{HOST}:{port}/stream?url=<URL>")
    print(f"[+] Sistemas ativos: DeviceProfile, AdaptiveBackoff, TokenRefresher, TLSRotation")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("[ZeroSutra] Encerrado.")