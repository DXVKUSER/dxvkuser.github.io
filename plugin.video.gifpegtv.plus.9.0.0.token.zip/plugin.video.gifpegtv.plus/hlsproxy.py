#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — Proxy HLS/MPEG-TS com melhorias contra travamentos
Melhorias principais implementadas:
 - Evita resolver (seguir redirects) por segmento quando token já presente
 - Resolve e cacheia o manifesto / base do stream (pré-resolve no play_stream)
 - Aumenta chunk size e timeouts para reduzir I/O overhead
 - Lógica refinada de retry: se resolved_url falhar por token/timeout, tenta original para renovar token
 - Manejo mais robusto de BrokenPipe / cliente desconectado
 - Não removei HLSAddon (mantive compatibilidade com addon.py)
"""
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
from socketserver import ThreadingMixIn
import socketserver

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests import Session

# Tentativa de importar libs do Kodi (fingir se não existir)
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except Exception:
    class MockKodi:
        def translatePath(self, path): return "/tmp/"
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None

# ---------------- CONFIG ----------------
MAX_SEGMENT_RETRIES = 3
RETRY_BACKOFF_FACTOR = 0.15
CONNECTION_TIMEOUT = 8.0
STREAM_TIMEOUT = 25.0
DEFAULT_CHUNK_SIZE = 1024 * 128   # 128 KB por chunk (aumentado)
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"
MANIFEST_RETRY_DELAY = 0.12
MAX_CONSECUTIVE_SEGMENT_ERRORS = 8

# User-Agent template
USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.{version} Safari/537.36"

# Cache de URLs resolvidas (manifest/base) (original_url -> (resolved_url, expires_at))
RESOLVED_CACHE_TTL = 300  # TTL para manifiesto/base (5 minutos)
# NOTA: evitamos cache por-segmento (segmentos com token) para não gerar overhead.

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Dummy TS Content (segmento silencioso)
TS_PACKET_SIZE = 188
SILENT_AAC_TS_PACKET = b'\x47' + (b'\x00' * 187)  # minimal filler packet
SILENT_AAC_TS_CONTENT = SILENT_AAC_TS_PACKET * 10

# ---------------- LOGGING ----------------
def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(levelname)s: %(message)s',
            handlers=[logging.FileHandler(log_path, mode='a', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

# ---------------- SESSÃO HTTP ----------------
def _create_new_session(pool_maxsize=50):
    """Cria sessão requests com um pool maior e estratégia de retry."""
    s = Session()
    # Retry para erros transitórios
    retry_strategy = Retry(
        total=3,
        read=3,
        connect=3,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(pool_connections=pool_maxsize, pool_maxsize=pool_maxsize, max_retries=retry_strategy)
    s.mount('http://', adapter)
    s.mount('https://', adapter)
    return s, adapter

# Sessão global (reutilizada)
GLOBAL_SESSION, GLOBAL_ADAPTER = _create_new_session()

# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    # Estado compartilhado
    session = GLOBAL_SESSION
    adapter = GLOBAL_ADAPTER

    # caches & locks
    resolved_cache = {}  # original_manifest_url -> (resolved_url, expires_at)
    resolved_cache_lock = threading.Lock()

    # estatísticas por sessão
    error_counter = {}
    manifest_duration = 6.0
    network_quality = {}
    dynamic_chunk_size = {}
    dynamic_stream_timeout = {}
    last_segment_times = {}
    last_segment_sizes = {}
    session_ua_versions = {}
    session_manifest_refresh = {}

    MAX_TIMES_TO_AVERAGE = 8
    DUMMY_SEGMENT_CONTENT = SILENT_AAC_TS_CONTENT
    DEFAULT_DUMMY_SIZE_BYTES = 40 * 1024

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    # ---------------- utilitários de sessão/UA ----------------
    def _get_session_user_agent(self, session_id):
        version = HLSProxyRequestHandler.session_ua_versions.get(session_id)
        if version is None:
            version = random.randint(1000, 9000)
            HLSProxyRequestHandler.session_ua_versions[session_id] = version
        return USER_AGENT_TEMPLATE.format(version=version)

    def _rotate_session_user_agent(self, session_id):
        new_version = HLSProxyRequestHandler.session_ua_versions.get(session_id, random.randint(1000,9000)) + 1
        HLSProxyRequestHandler.session_ua_versions[session_id] = new_version
        logging.info(f"Rotacionando UA -> v{new_version} (sess: {session_id})")

    def _reset_session_and_retry(self, session_id):
        logging.critical(f"Reiniciando sessão HTTP (sess: {session_id})")
        self._rotate_session_user_agent(session_id)
        new_session, new_adapter = _create_new_session()
        HLSProxyRequestHandler.session = new_session
        HLSProxyRequestHandler.adapter = new_adapter
        HLSProxyRequestHandler.session_manifest_refresh[session_id] = time.time()
        self.error_counter[session_id] = 0

    def _get_forward_headers(self, session_id):
        ua = self._get_session_user_agent(session_id)
        headers = {
            'User-Agent': ua,
            'Connection': 'keep-alive',
        }
        # Replicar auth/cookies do cliente se houver
        if 'Authorization' in self.headers:
            headers['Authorization'] = self.headers['Authorization']
        if 'Cookie' in self.headers:
            headers['Cookie'] = self.headers['Cookie']
        return headers

    # ---------------- cache resolvido (manifest/base) ----------------
    @classmethod
    def _get_cached_resolved(cls, original_url):
        with cls.resolved_cache_lock:
            entry = cls.resolved_cache.get(original_url)
            if not entry:
                return None
            resolved, expires_at = entry
            if time.time() > expires_at:
                try:
                    del cls.resolved_cache[original_url]
                except KeyError:
                    pass
                return None
            return resolved

    @classmethod
    def _set_cached_resolved(cls, original_url, resolved_url, ttl=RESOLVED_CACHE_TTL):
        with cls.resolved_cache_lock:
            expires_at = time.time() + ttl
            cls.resolved_cache[original_url] = (resolved_url, expires_at)
            logging.info(f"Cache atualizado (manifest/base): {original_url} -> {resolved_url} (ttl={ttl}s)")

    def resolve_and_cache(self, original_url, session_id, force_refresh=False):
        """
        Resolve somente URL de manifesto/base (seguindo redirects) para obter URL final.
        Se cache válido existir, retorna-o (a menos que force_refresh=True).
        Importante: NÃO usar para cada segmento — evitamos overhead quando segmento já tem token.
        """
        if not force_refresh:
            cached = self._get_cached_resolved(original_url)
            if cached:
                logging.info(f"Usando resolved cache para manifest/base: {original_url} (sess: {session_id})")
                return cached

        headers = self._get_forward_headers(session_id)
        requester = requests.get

        for attempt in range(3):
            try:
                logging.info(f"Tentando resolver manifest/base: {original_url} (tent {attempt+1}/3) (sess: {session_id})")
                r = requester(original_url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                final_url = r.url if r is not None else original_url
                if r.status_code in (403, 404):
                    logging.warning(f"Resolver manifesto retornou {r.status_code}. Rotacionando UA.")
                    self._rotate_session_user_agent(session_id)
                    if attempt < 2:
                        time.sleep(MANIFEST_RETRY_DELAY * (2 ** attempt))
                        continue
                    self._reset_session_and_retry(session_id)
                    raise requests.exceptions.HTTPError(f"{r.status_code} ao resolver manifesto")
                # Se houve redirect (final_url diferente), salvamos; caso contrário salvamos original (ttl curta)
                if final_url and final_url != original_url:
                    self._set_cached_resolved(original_url, final_url)
                    return final_url
                # fallback: cache curto
                self._set_cached_resolved(original_url, original_url, ttl=60)
                return original_url
            except requests.exceptions.RequestException as e:
                logging.warning(f"Erro ao resolver manifesto {original_url}: {e}")
                self._rotate_session_user_agent(session_id)
                time.sleep(min(RETRY_BACKOFF_FACTOR * (2 ** attempt), 2.0))
                continue

        logging.error(f"Falha completa ao resolver manifesto: {original_url}")
        return original_url

    # ---------------- GET / HEAD ----------------
    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?',1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400)
                return

            headers = self._get_forward_headers(session_id)
            parsed = urllib.parse.urlparse(url)
            path_lower = parsed.path.lower()

            # Se for manifesto/playlist
            if path_lower.endswith(('.m3u8', '.m3u')) or 'manifest' in parsed.query.lower():
                self._handle_manifest(url, headers, head_only, session_id)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado em do_GET: {e}")
            try:
                self.send_error(500, message="Proxy Internal Error")
            except Exception:
                pass

    # ---------------- MANIFEST HANDLER (rewrite) ----------------
    def _handle_manifest(self, url, headers, head_only, session_id):
        """
        - Faz pre-resolve do manifesto (cache) para extrair base/resolved_manifest.
        - Reescreve linhas de URL do manifesto para apontar ao proxy.
        - Evita resolver cada segmento individualmente (apenas usa a URL tal qual se tiver token).
        """
        try:
            # Forçar refresh se marcador de nova sessão
            if HLSProxyRequestHandler.session_manifest_refresh.pop(session_id, None):
                logging.info(f"Manifest fetch com sessão renovada (sess: {session_id})")

            # Preferir cache para HEAD rápido
            if head_only:
                cached = self._get_cached_resolved(url)
                if cached:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Cache-Control', 'no-cache')
                    self.end_headers()
                    return

            # Baixa manifesto (seguindo redirects) e determina base_url
            r = requests.get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
            if r.status_code in (403, 404):
                logging.warning(f"Manifesto retornou {r.status_code} (sess: {session_id})")
                # tenta reset de sessão/UA e re-raise
                self._rotate_session_user_agent(session_id)
                self._reset_session_and_retry(session_id)
                r.raise_for_status()

            r.raise_for_status()
            manifest_text = r.text
            resolved_manifest_url = r.url

            # Salva resolved manifest / base na cache (útil para pre-resolve)
            self._set_cached_resolved(url, resolved_manifest_url)

            # Determina base para resoluções relativas
            base_url = resolved_manifest_url
            # calc base join root for relative segments:
            parsed_base = urllib.parse.urlparse(base_url)
            base_root = f"{parsed_base.scheme}://{parsed_base.netloc}"
            base_path = base_url.rsplit('/',1)[0] + '/'

            # calcula duração média dos segmentos (para dummy segment sizing / heurística)
            total_dur = 0.0
            cnt = 0
            for line in manifest_text.splitlines():
                if line.startswith('#EXTINF:'):
                    try:
                        dur = float(line.split('#EXTINF:')[1].split(',')[0])
                        total_dur += dur
                        cnt += 1
                    except Exception:
                        pass
            if cnt > 0:
                HLSProxyRequestHandler.manifest_duration = max(total_dur / cnt, 1.0)
                logging.info(f"Duração média segmento detectada: {HLSProxyRequestHandler.manifest_duration:.2f}s")

            # Reescreve manifesto: para cada linha não-# cria URL proxied
            new_lines = []
            for line in manifest_text.splitlines():
                s = line.strip()
                if not s:
                    new_lines.append(line)
                    continue
                if s.startswith('#'):
                    # mantém tags
                    new_lines.append(line)
                    continue
                # s é uma URL relativa ou absoluta de segmento
                # Se URL for relativa, constrói absoluta a partir do base_path
                if not urllib.parse.urlparse(s).netloc:
                    full_segment_url = urllib.parse.urljoin(base_path, s)
                else:
                    full_segment_url = s

                # Se o segmento já contém token (token= ou /auth/ etc.), NÃO tentar resolver/call adicional
                if 'token=' in full_segment_url or '/auth/' in full_segment_url:
                    resolved_segment_url = full_segment_url
                else:
                    # Se for uma URL sem token, tentamos usar base resolvida (se diferente)
                    # Evitamos chamadas HTTP extras por segmento: apenas usamos full_segment_url tal qual.
                    resolved_segment_url = full_segment_url

                proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(resolved_segment_url)}&session_id={session_id}"
                new_lines.append(proxy_segment_url)

            # Envia resposta
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()
            if head_only:
                return
            body = '\n'.join(new_lines).encode('utf-8')
            try:
                self.wfile.write(body)
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante envio de manifesto.")
                return

        except requests.exceptions.HTTPError as e:
            logging.error(f"HTTP error ao obter manifesto: {e}")
            try:
                self.send_error(404, message="Manifest Not Found/Expired")
            except Exception:
                pass
        except Exception as e:
            logging.error(f"Erro ao manipular manifesto: {e}")
            try:
                self.send_error(500, message="Proxy internal error (manifest)")
            except Exception:
                pass

    # ---------------- SEGMENT HANDLER ----------------
    def _handle_segment(self, url, session_id, headers, head_only):
        """
        Lógica para servir segmentos:
         - Se o URL contém token (query 'token='), usa direto (sem resolve extra).
         - Caso contrário, tenta usar cached resolved manifest/base se existir;
           se a tentativa em resolved falhar com 403/404 ou timeout, tenta a URL original para forçar renovação de token.
         - Regras de retry/backoff e envio de segmento silencioso em falhas críticas.
        """
        retries = 0
        consecutive_errors = self.error_counter.get(session_id, 0)
        self._initialize_session_quality(session_id)

        chunk_size = HLSProxyRequestHandler.dynamic_chunk_size.get(session_id, DEFAULT_CHUNK_SIZE)
        stream_timeout = HLSProxyRequestHandler.dynamic_stream_timeout.get(session_id, STREAM_TIMEOUT)

        bytes_downloaded = 0
        original_url = url

        # Se URL já contém token, considere resolvida imediatamente (evitar HEADs extras)
        if 'token=' in original_url or '/auth/' in original_url:
            resolved_url = original_url
        else:
            # Tentar usar cache de manifest/base se houver (mas NÃO resolver cada segmento)
            # A ideia: segmentos sem token ficam como estão; somente resolvemos original se necessário mais tarde.
            resolved_url = self._get_cached_resolved(original_url) or original_url

        tried_original_after_resolved = False
        attempt_urls = [resolved_url] if resolved_url else [original_url]

        while retries < MAX_SEGMENT_RETRIES:
            current_url = attempt_urls[0]
            start_time = time.time()
            try:
                logging.info(f"Baixando segmento (tent {retries+1}/{MAX_SEGMENT_RETRIES}) de {current_url} (sess: {session_id})")
                with HLSProxyRequestHandler.session.get(current_url, headers=headers, stream=True,
                                                       timeout=stream_timeout, verify=False) as r:
                    if r.status_code >= 400:
                        raise requests.exceptions.HTTPError(f"HTTP {r.status_code}", response=r)

                    # Reset contadores de erro
                    self.error_counter[session_id] = 0

                    # Headers de resposta para o cliente
                    self.send_response(r.status_code)
                    for hname, hval in r.headers.items():
                        if hname.lower() in ['transfer-encoding', 'connection', 'content-encoding']:
                            continue
                        self.send_header(hname, hval)
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()

                    if head_only:
                        content_len = int(r.headers.get('Content-Length', '0'))
                        self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=content_len)
                        return

                    # Envia stream chunked
                    for chunk in r.iter_content(chunk_size=chunk_size):
                        if not chunk:
                            continue
                        bytes_downloaded += len(chunk)
                        try:
                            self.wfile.write(chunk)
                            # não forçar flush a cada chunk para reduzir syscalls — flush ao final do iter ou buffer está cheio
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                            logging.warning(f"Cliente fechou conexão (sess: {session_id})")
                            self._update_network_quality(session_id, start_time, time.time(), success=False, size_bytes=bytes_downloaded)
                            return
                        except Exception as e:
                            logging.error(f"Erro ao enviar chunk: {e}")
                            # Reset de sessão e envio de segmento silencioso
                            self._reset_session_and_retry(session_id)
                            self._send_silent_segment(session_id)
                            return

                    # após terminar transmissão
                    self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=bytes_downloaded)
                    return

            except requests.exceptions.HTTPError as e:
                retries += 1
                consecutive_errors += 1
                self.error_counter[session_id] = consecutive_errors
                status_code = None
                if getattr(e, 'response', None) is not None:
                    try:
                        status_code = int(e.response.status_code)
                    except Exception:
                        status_code = None
                logging.warning(f"HTTP error no segmento {current_url} => {status_code} (retry {retries}) (sess: {session_id})")

                # Se falha por token expirado (403/404) e ainda não tentamos a original -> tentar original para renovar token
                if status_code in (403, 404):
                    if not tried_original_after_resolved and current_url != original_url:
                        logging.info("Resolved_url inválida — tentando original para tentar renovar token.")
                        # Força re-resolve a partir da original
                        new_resolved = self.resolve_and_cache(original_url, session_id, force_refresh=True)
                        if new_resolved and new_resolved != current_url:
                            attempt_urls.insert(0, new_resolved)
                        else:
                            attempt_urls.insert(0, original_url)
                        tried_original_after_resolved = True
                        continue
                    else:
                        logging.critical("Falha persistente por token. Resetando sessão e enviando segmento silencioso.")
                        self._reset_session_and_retry(session_id)
                        self._send_silent_segment(session_id)
                        return

                if consecutive_errors >= MAX_CONSECUTIVE_SEGMENT_ERRORS:
                    logging.critical("Muitos erros consecutivos — reset e envio de segmento silencioso.")
                    self._reset_session_and_retry(session_id)
                    self._send_silent_segment(session_id)
                    return

                time.sleep(min(MANIFEST_RETRY_DELAY * (2 ** retries), 2.0))
                continue

            except requests.exceptions.RequestException as e:
                retries += 1
                is_timeout = isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectTimeout))
                logging.warning(f"Erro de rede ao baixar segmento {current_url}: {e} (retry {retries}) (sess: {session_id})")
                self._update_network_quality(session_id, start_time, time.time(), success=False, is_timeout=is_timeout, size_bytes=0)

                # Se falha de rede na resolved_url e ainda não tentou original, tenta original -> força refresh/resolution
                if not tried_original_after_resolved and current_url != original_url:
                    logging.info("Falha de rede na resolved_url — tentando original para possivel refresh de token/resolução.")
                    new_res = self.resolve_and_cache(original_url, session_id, force_refresh=True)
                    if new_res and new_res != current_url:
                        attempt_urls.insert(0, new_res)
                    else:
                        attempt_urls.insert(0, original_url)
                    tried_original_after_resolved = True
                    continue

                # Backoff e abandono se timeout persistente
                time.sleep(min(RETRY_BACKOFF_FACTOR * (2 ** retries), 2.0))
                if is_timeout or retries >= MAX_SEGMENT_RETRIES:
                    logging.critical("Timeout / Max retries no segmento. Reset e envio de segmento silencioso.")
                    self._reset_session_and_retry(session_id)
                    self._send_silent_segment(session_id)
                    return

            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente desconectado antes do fim da transferência.")
                return

            except Exception as e:
                logging.error(f"Erro inesperado ao baixar segmento {original_url}: {e}")
                self._reset_session_and_retry(session_id)
                self._send_silent_segment(session_id)
                return

        # Se esgotou todas tentativas
        logging.critical("Segmento falhou após todas as tentativas. Enviando segmento silencioso.")
        self._reset_session_and_retry(session_id)
        self._send_silent_segment(session_id)

    # ---------------- Segmentos silenciosos (fallback) ----------------
    def _get_dynamic_silent_segment(self, session_id):
        # Monta um segmento silencioso com tamanho baseado em histórico de bitrate
        sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])
        times = HLSProxyRequestHandler.last_segment_times.get(session_id, [])
        avg_bitrate = 0
        if sizes and times and len(sizes) == len(times):
            total_size = sum(sizes)
            total_time = sum(times)
            if total_time > 0:
                avg_bitrate = (total_size * 8) / total_time
        if avg_bitrate > 0:
            target_size = int((avg_bitrate * HLSProxyRequestHandler.manifest_duration) / 8)
        else:
            target_size = self.DEFAULT_DUMMY_SIZE_BYTES
        target_size = max(target_size, self.DEFAULT_DUMMY_SIZE_BYTES)
        # alinhar ao tamanho de pacote TS
        packets = (target_size // TS_PACKET_SIZE) + 1
        return SILENT_AAC_TS_PACKET * packets

    def _send_silent_segment(self, session_id):
        content = self._get_dynamic_silent_segment(session_id)
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            try:
                self.wfile.write(content)
                self.wfile.flush()
            except Exception:
                pass
        except Exception as e:
            logging.error(f"Erro ao enviar segmento silencioso: {e}")

    # ---------------- qualidade de rede / estatísticas ----------------
    def _initialize_session_quality(self, session_id):
        if session_id not in HLSProxyRequestHandler.network_quality:
            HLSProxyRequestHandler.network_quality[session_id] = "good"
            HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
            HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            HLSProxyRequestHandler.last_segment_times[session_id] = []
            HLSProxyRequestHandler.last_segment_sizes[session_id] = []
            HLSProxyRequestHandler.session_ua_versions[session_id] = random.randint(1000,9000)

    def _update_network_quality(self, session_id, start_time, end_time, success, is_timeout=False, size_bytes=0):
        self._initialize_session_quality(session_id)
        duration = max(end_time - start_time, 0.0001)
        times = HLSProxyRequestHandler.last_segment_times.get(session_id, [])
        sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])

        if success:
            times.append(duration)
            if size_bytes > 0:
                sizes.append(size_bytes)
        else:
            penalty = HLSProxyRequestHandler.manifest_duration * 2.0
            times.append(penalty)

        # trim arrays
        while len(times) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE:
            times.pop(0)
        while len(sizes) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE:
            sizes.pop(0)
        HLSProxyRequestHandler.last_segment_times[session_id] = times
        HLSProxyRequestHandler.last_segment_sizes[session_id] = sizes

        if not times:
            return

        avg_time = sum(times)/len(times)
        prev = HLSProxyRequestHandler.network_quality.get(session_id, "good")
        newq = prev
        seglen = max(HLSProxyRequestHandler.manifest_duration, 1.0)
        if avg_time < seglen * 0.6:
            newq = "good"
        elif avg_time < seglen * 1.5:
            newq = "medium"
        else:
            newq = "bad"

        if newq != prev:
            logging.info(f"Qualidade rede mudou de '{prev}' para '{newq}' (avg_time: {avg_time:.2f}s)")
            HLSProxyRequestHandler.network_quality[session_id] = newq
            if newq == "good":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = 1024*256
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT * 1.8
            elif newq == "medium":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            else:
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = 1024*32
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = max(5.0, seglen * 1.2)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()

# ---------------- SERVER MANAGER ----------------
class ThreadingHTTPServer(ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy iniciado na porta {self.active_port}")
                return True
            except OSError:
                continue
        logging.error("Não foi possível iniciar o proxy em nenhuma porta.")
        return False

# ---------------- ADDON (mantido) ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        """
        Inicia proxy e retorna URL proxied para o player.
        Faz PRE-RESOLVE do manifesto para popular cache (reduz latência inicial).
        """
        if not self.proxy.start():
            if xbmcplugin:
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        session_id = f"stream_{int(time.time())}_{random.randint(1000,9999)}"
        logging.info(f"Iniciando stream com session_id: {session_id}")

        # PRE-RESOLVE do manifesto para popular cache e reduzir latência
        try:
            # apenas se parecer manifesto (.m3u8)
            if url and (url.lower().endswith('.m3u8') or 'manifest' in url.lower()):
                # usamos um GET simples para popular cache
                try:
                    req_headers = {'User-Agent': HLSProxyRequestHandler.session_ua_versions.get(session_id, USER_AGENT_TEMPLATE.format(version=1234))}
                    r = requests.get(url, headers=req_headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                    if r.ok:
                        # grava cache manifest -> r.url
                        HLSProxyRequestHandler._set_cached_resolved(url, r.url)
                except Exception as e:
                    logging.debug(f"Pre-resolve manifesto falhou (não crítico): {e}")
        except Exception:
            pass

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&session_id={session_id}"

        if xbmcgui and xbmcplugin:
            li = xbmcgui.ListItem(path=proxy_url, label=title or "Stream")
            li.setProperty("IsPlayable","true")
            if stype == "live":
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setProperty("IsLive","true")
            xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- main ----------------
def main():
    setup_logging()
    try:
        if len(sys.argv) < 2:
            logging.error("Este script deve ser chamado pelo Kodi com argumentos.")
            return

        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(stream_url, stream_type, title)
        elif xbmcplugin:
            xbmcplugin.endOfDirectory(h)
    except Exception as e:
        logging.error(f"Erro main: {e}")

if __name__ == '__main__':
    main()