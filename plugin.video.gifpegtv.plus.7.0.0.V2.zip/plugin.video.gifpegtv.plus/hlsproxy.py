# -*- coding: utf-8 -*-
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingTCPServer
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass
from contextlib import contextmanager
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import HTTPError, RequestException
from doh_client import requests as doh_requests
import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIGURAÇÃO ----------------
@dataclass(frozen=True)
class ProxyConfig:
    max_retries: int = 15
    retry_backoff_factor: float = 4.0
    connection_timeout: int = 10
    stream_timeout: float = 30.0
    chunk_size: int = 1024 * 64
    proxy_host: str = '127.0.0.1'
    max_port_attempts: int = 20
    log_file: str = "hls_proxy.log"
    max_segment_errors: int = 5
    manifest_retries: int = 15
    min_manifest_refresh_interval: float = 5.0  # Tempo mínimo entre recargas de manifesto
    max_backoff_time: float = 30.0  # Tempo máximo de espera entre tentativas

CONFIG = ProxyConfig()
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILITÁRIOS ----------------
def setup_logging() -> None:
    """Configura o sistema de logging com pathlib e formatação moderna."""
    try:
        log_path = Path(xbmc.translatePath('special://logpath')) / CONFIG.log_file
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

def get_forward_headers(client_headers: Dict[str, str]) -> Dict[str, str]:
    """Gera headers com User-Agent rotativo e headers essenciais."""
    chrome_version = random.randint(90, 110)
    user_agent = (
        f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        f"(KHTML, like Gecko) Chrome/{chrome_version}.0.0.0 Safari/537.36"
    )
    
    headers = {
        'User-Agent': user_agent,
        'Connection': 'keep-alive',
    }
    
    # Copia headers essenciais do cliente
    for header in ('Authorization', 'Cookie'):
        if header in client_headers:
            headers[header] = client_headers[header]
    
    return headers

# ---------------- HANDLER OTIMIZADO ----------------
class HLSProxyRequestHandler(BaseHTTPRequestHandler):
    """Handler com recuperação infinita de manifesto."""
    def __init__(self, *args, **kwargs):
        self.session = doh_requests.session
        self.adapter = HTTPAdapter(max_retries=0)
        self.session.mount('http://', self.adapter)
        self.session.mount('https://', self.adapter)
        self.error_counter: Dict[str, int] = {}
        self.manifest_urls: Dict[str, str] = {}  # session_id -> manifest_url
        self.last_manifest_refresh: Dict[str, float] = {}  # session_id -> timestamp
        super().__init__(*args, **kwargs)

    def log_message(self, format: str, *args) -> None:
        """Sobrescrita para logging eficiente."""
        logging.info(f"{self.client_address[0]} - \"{format % args}\"")

    def do_HEAD(self) -> None:
        """Suporte a requisições HEAD."""
        self.do_GET(head_only=True)

    def do_GET(self, head_only: bool = False) -> None:
        """Processa requisições GET com tratamento robusto de erros."""
        try:
            if '?url=' not in self.path:
                self.send_error(404, "Not Found")
                return

            query = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(query.get('url', [''])[0])
            session_id = query.get('session_id', [self.client_address[0]])[0]
            manifest_url = urllib.parse.unquote_plus(query.get('manifest_url', [''])[0])

            if not url:
                self.send_error(400, "Bad Request: 'url' parameter missing")
                return

            # Armazena a URL do manifesto se fornecida
            if manifest_url:
                self.manifest_urls[session_id] = manifest_url

            headers = get_forward_headers(self.headers)
            parsed_url = urllib.parse.urlparse(url)
            
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, session_id, head_only)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou a conexão abruptamente")
        except Exception as e:
            logging.error(f"Erro inesperado no handler GET: {e}", exc_info=True)
            try:
                self.send_error(500, "Internal Proxy Error")
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou a conexão durante o envio de erro 500.")

    def _handle_manifest(self, url: str, headers: Dict[str, str], 
                        session_id: str, head_only: bool) -> None:
        """Processa manifestos com retry inteligente e reescrita de URLs."""
        try:
            response = self._retry_request(
                url, headers, CONFIG.manifest_retries, CONFIG.connection_timeout
            )
            
            if not response:
                # Se falhar ao obter o manifesto, tenta indefinidamente
                self._retry_manifest_until_success(url, headers, session_id, head_only)
                return

            # Armazena a URL do manifesto para recuperação futura
            self.manifest_urls[session_id] = url
            self.last_manifest_refresh[session_id] = time.time()

            self._send_manifest_response(response, session_id, head_only)
            
        except HTTPError as e:
            logging.error(f"Erro HTTP ao processar manifesto {url}: {e}")
            # Tenta novamente indefinidamente
            self._retry_manifest_until_success(url, headers, session_id, head_only)
        except Exception as e:
            logging.error(f"Erro ao processar manifesto {url}: {e}", exc_info=True)
            # Tenta novamente indefinidamente
            self._retry_manifest_until_success(url, headers, session_id, head_only)

    def _retry_manifest_until_success(self, url: str, headers: Dict[str, str], 
                                     session_id: str, head_only: bool) -> None:
        """Tenta obter o manifesto indefinidamente até conseguir."""
        backoff = 1.0
        while True:
            try:
                logging.info(f"Tentando novamente obter manifesto: {url}")
                response = self._retry_request(
                    url, headers, CONFIG.manifest_retries, CONFIG.connection_timeout
                )
                
                if response:
                    # Armazena a URL do manifesto para recuperação futura
                    self.manifest_urls[session_id] = url
                    self.last_manifest_refresh[session_id] = time.time()
                    
                    self._send_manifest_response(response, session_id, head_only)
                    return
                    
            except Exception as e:
                logging.error(f"Falha ao obter manifesto {url}: {e}. Tentando novamente em {backoff:.1f}s...")
            
            # Espera com backoff exponencial
            time.sleep(backoff)
            backoff = min(backoff * 2, CONFIG.max_backoff_time)

    def _handle_segment(self, url: str, session_id: str, 
                       headers: Dict[str, str], head_only: bool) -> None:
        """Processa segmentos com recuperação infinita de manifesto."""
        backoff = 1.0
        attempt = 0
        
        while True:
            response = None
            try:
                attempt += 1
                logging.info(f"Tentando obter segmento {url} (tentativa {attempt})")
                
                response = self._retry_request(
                    url, headers, CONFIG.max_retries, CONFIG.stream_timeout, stream=True
                )
                
                if response:
                    if response.status_code == 404:
                        self._handle_404_error(session_id)
                        # Após erro 404, tenta recarregar o manifesto
                        self._try_refresh_manifest(session_id, headers)
                        # Continua tentando o mesmo segmento
                        time.sleep(backoff)
                        backoff = min(backoff * 2, CONFIG.max_backoff_time)
                        continue
                    
                    # Sucesso! Envia o segmento
                    self.error_counter[session_id] = 0
                    self._send_segment_response(response, head_only)
                    return
                    
            except HTTPError as e:
                logging.error(f"Erro HTTP ao processar segmento {url}: {e}")
            except Exception as e:
                logging.error(f"Erro ao processar segmento {url}: {e}", exc_info=True)
            finally:
                if response:
                    response.close()
            
            # Tenta recarregar o manifesto
            if self._try_refresh_manifest(session_id, headers):
                logging.info("Manifesto recarregado, tentando segmento novamente")
                backoff = 1.0  # Reseta o backoff após recarregar o manifesto
                continue
            
            # Espera com backoff exponencial antes da próxima tentativa
            logging.warning(f"Falha ao obter segmento {url}. Tentando novamente em {backoff:.1f}s...")
            time.sleep(backoff)
            backoff = min(backoff * 2, CONFIG.max_backoff_time)

    def _try_refresh_manifest(self, session_id: str, headers: Dict[str, str]) -> bool:
        """Tenta recarregar o manifesto para obter segmentos frescos."""
        manifest_url = self.manifest_urls.get(session_id)
        if not manifest_url:
            return False

        # Verifica se já recarregou recentemente
        last_refresh = self.last_manifest_refresh.get(session_id, 0)
        if time.time() - last_refresh < CONFIG.min_manifest_refresh_interval:
            return False

        logging.info(f"Tentando recarregar manifesto para sessão {session_id}: {manifest_url}")
        try:
            response = self._retry_request(
                manifest_url, headers, CONFIG.manifest_retries, CONFIG.connection_timeout
            )
            
            if response:
                self.last_manifest_refresh[session_id] = time.time()
                logging.info(f"Manifesto recarregado com sucesso para sessão {session_id}")
                response.close()
                return True
                
        except Exception as e:
            logging.error(f"Falha ao recarregar manifesto {manifest_url}: {e}")
            
        return False

    def _retry_request(self, url: str, headers: Dict[str, str], 
                      max_retries: int, timeout: float, 
                      stream: bool = False) -> Optional[requests.Response]:
        """Realiza requisições com retry exponencial e tratamento de 429."""
        for attempt in range(max_retries):
            try:
                response = self.session.get(
                    url, headers=headers, timeout=timeout, 
                    stream=stream, verify=False, allow_redirects=True
                )
                
                # Se for um erro 404, retornamos a resposta para tratamento específico
                if response.status_code == 404:
                    return response
                    
                response.raise_for_status()
                return response
                
            except HTTPError as e:
                if e.response and e.response.status_code == 429:
                    wait_time = self._calculate_retry_time(e.response, attempt)
                    logging.warning(f"429 - Tentando novamente em {wait_time:.2f}s... (Tentativa {attempt+1}/{max_retries})")
                    time.sleep(wait_time)
                    continue
                # Para outros erros HTTP, vamos levantar a exceção para tratamento específico
                raise
                
            except RequestException as e:
                wait_time = CONFIG.retry_backoff_factor * (2 ** attempt) + random.uniform(0, 1)
                logging.warning(f"Erro na requisição: {e}. Tentando novamente em {wait_time:.2f}s...")
                time.sleep(wait_time)
                continue
                
        return None

    def _calculate_retry_time(self, response: requests.Response, attempt: int) -> float:
        """Calcula tempo de retry baseado em Retry-Header ou backoff exponencial."""
        retry_after = response.headers.get('Retry-After')
        if retry_after:
            try:
                return float(retry_after)
            except ValueError:
                pass
        return CONFIG.retry_backoff_factor * (2 ** attempt) + random.uniform(0, 1)

    def _handle_404_error(self, session_id: str) -> None:
        """Controla erros 404 consecutivos."""
        consecutive_errors = self.error_counter.get(session_id, 0) + 1
        self.error_counter[session_id] = consecutive_errors
        logging.warning(f"404 - Erros consecutivos: {consecutive_errors}")
        
        # Mesmo com muitos erros 404, não encerra - apenas registra
        if consecutive_errors >= CONFIG.max_segment_errors:
            logging.warning("Muitos erros 404 consecutivos. Tentando recarregar manifesto.")

    def _send_manifest_response(self, response: requests.Response, 
                               session_id: str, head_only: bool) -> None:
        """Envia resposta do manifesto com URLs reescritas."""
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.end_headers()
        
        if head_only:
            return
            
        try:
            manifest_content = response.text
            base_url = response.url
            new_manifest = []
            
            for line in manifest_content.splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith('#'):
                    new_manifest.append(line)
                else:
                    full_url = urllib.parse.urljoin(base_url, stripped)
                    proxy_url = (
                        f"http://{CONFIG.proxy_host}:{self.server.server_address[1]}/"
                        f"?url={urllib.parse.quote_plus(full_url)}"
                        f"&session_id={session_id}"
                        f"&manifest_url={urllib.parse.quote_plus(self.manifest_urls.get(session_id, ''))}"
                    )
                    new_manifest.append(proxy_url)
            
            self.wfile.write('\n'.join(new_manifest).encode('utf-8'))
        except Exception as e:
            logging.error(f"Erro ao enviar manifesto: {e}", exc_info=True)
        finally:
            response.close()

    def _send_segment_response(self, response: requests.Response, head_only: bool) -> None:
        """Envia resposta do segmento com streaming eficiente."""
        self.send_response(response.status_code)
        
        # Copia headers relevantes
        for header, value in response.headers.items():
            lower_header = header.lower()
            if lower_header not in ['transfer-encoding', 'connection', 'content-encoding']:
                self.send_header(header, value)
        
        self.end_headers()
        
        if head_only:
            return
            
        try:
            for chunk in response.iter_content(chunk_size=CONFIG.chunk_size):
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou a conexão durante o streaming")
        except Exception as e:
            logging.error(f"Erro durante o streaming: {e}", exc_info=True)
        finally:
            response.close()

    def do_OPTIONS(self) -> None:
        """Responde requisições OPTIONS com headers CORS."""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()

# ---------------- GERENCIADOR DE PROXY ----------------
class HLSProxyManager:
    """Gerenciador de ciclo de vida do proxy com inicialização otimizada."""
    def __init__(self):
        self.server: Optional[ThreadingTCPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None

    def start(self) -> bool:
        """Inicia o proxy em uma porta aleatória com retry eficiente."""
        for _ in range(CONFIG.max_port_attempts):
            port = random.randint(30000, 60000)
            try:
                self.server = ThreadingTCPServer(
                    (CONFIG.proxy_host, port), 
                    HLSProxyRequestHandler,
                    bind_and_activate=False
                )
                self.server.allow_reuse_address = True
                self.server.server_bind()
                self.server.server_activate()
                self.server.daemon_threads = True
                
                self.thread = threading.Thread(
                    target=self.server.serve_forever, 
                    daemon=True
                )
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy iniciado em http://{CONFIG.proxy_host}:{self.active_port}")
                return True
                
            except OSError as e:
                logging.warning(f"Porta {port} em uso: {e}")
                continue
                
        logging.error("Não foi possível iniciar o proxy - todas as portas em uso")
        return False

    def stop(self) -> None:
        """Para o proxy com limpeza de recursos."""
        if self.server:
            logging.info("Parando servidor proxy...")
            self.server.shutdown()
            self.server.server_close()
            if self.thread:
                self.thread.join()
            logging.info("Servidor proxy parado")

# ---------------- ADDON ----------------
class HLSAddon:
    """Interface do addon com Kodi usando métodos otimizados."""
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url: str, stype: str, title: Optional[str] = None) -> None:
        """Inicia o proxy e reproduz a stream no Kodi."""
        if not self.proxy.start():
            xbmcgui.Dialog().notification(
                "Erro no Proxy", 
                "Não foi possível iniciar o servidor local",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = (
            f"http://{CONFIG.proxy_host}:{self.proxy.active_port}/"
            f"?url={urllib.parse.quote_plus(url)}"
        )
        
        li = xbmcgui.ListItem(path=proxy_url)
        if title:
            li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        
        if stype == "live":
            li.setMimeType("application/vnd.apple.mpegurl")
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- PONTO DE ENTRADA ----------------
def main() -> None:
    """Ponto de entrada principal com tratamento robusto de erros."""
    setup_logging()
    try:
        handle = int(sys.argv[1])
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [''])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [''])[0]
            stream_type = args.get('stream_type', ['live'])[0]
            title = args.get('title', [''])[0]

            if stream_url:
                addon = HLSAddon(handle)
                addon.play_stream(stream_url, stream_type, title)
            else:
                logging.error("Ação 'play_stream' sem 'stream_url'")
                xbmcplugin.endOfDirectory(handle, succeeded=False)
        else:
            xbmcplugin.endOfDirectory(handle)
            
    except Exception as e:
        logging.error(f"Erro fatal: {e}", exc_info=True)
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        if handle != -1:
            xbmcplugin.endOfDirectory(handle, succeeded=False)

if __name__ == '__main__':
    main()