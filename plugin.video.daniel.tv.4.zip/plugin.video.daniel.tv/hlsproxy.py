#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# hlsproxy.py — NEXUS CORE HLS Proxy Engine
# v1.3.0-LOWCPU — stdlib puro / Kodi / Android / TV Box de baixo consumo
#
# CORREÇÕES v1.3.0 (recuperação de token/CDN — NUNCA enviar erro ao player):
# - Log real: a URL tokenizada da playlist devolveu HTTP 404 ~65s após o início
#   (token de vida curta). A recuperação antiga buscava a entry_url em vários
#   pontos AO MESMO TEMPO (poll de playlist + REF de cada segmento), cada busca
#   gerando um token novo no painel e podendo invalidar o anterior, e nenhuma
#   adotava a base nova na sessão -> espiral de 404.
#   Agora: re-resolução single-flight (_fresh_resolve) com reuso de resultado
#   recente, ADOÇÃO da base nova na sessão, TTL do token aprendido na 1ª falha
#   e renovação PREVENTIVA a 75% do TTL, antes de expirar.
# - Segmento: 4xx não repete a mesma URL; recupera pelo nome do arquivo no
#   manifesto fresco OU reaplicando o token novo ao path antigo (_retoken).
# - Nenhum status de erro sai para o Kodi: 204/404/416 removidos. Playlist cai
#   em last-good de QUALQUER idade, depois placeholder que continua a
#   MEDIA-SEQUENCE; segmento cai em cache e depois filler; chave em 16 bytes.
#   Sessão encerrada/trocada responde playlist com ENDLIST (200).
# - #EXT-X-DISCONTINUITY só quando o host da CDN muda ou a sequência salta/
#   regride (antes: a cada re-resolução, gerando discontinuities falsas).
#   MEDIA-SEQUENCE regressiva é reescrita para continuar monotônica.
# - Servidor: workers 8, espera maior por worker livre.
#
# CORREÇÕES v1.2.0 (sobre v1.1.0-LOWCPU):
# - LOG: níveis LOGWARNING/LOGERROR estavam deslocados (3/4 em vez de 2/3);
#   agora usam as constantes reais do xbmc.
# - STALE SEQUENCE: force_fresh_resolve() disparava em polls normais (Kodi
#   consulta a playlist mais rápido que a duração do segmento) e só injetava
#   #EXT-X-DISCONTINUITY falso, pois resolved_base era sobrescrito logo depois.
#   Agora exige estagnação por TEMPO (HLS_STALE_SEQUENCE_MIN_SECONDS), faz a
#   re-resolução de verdade e só marca discontinuity na playlist da nova base.
# - _resolve_playlist: após needs_fresh, `base` local passa a ser entry_url.
# - Leitura de corpo: read1() + settimeout por volta (antes: select() no socket
#   com dados já no buffer do http.client podia esperar o deadline inteiro em
#   respostas chunked). Corpo incompleto agora é erro, não segmento truncado.
# - Exceções http.client.HTTPException/ValueError agora tratadas em _fetch.
# - Icy-MetaData removido dos perfis (servidor pode injetar metadados dentro
#   do TS e corromper o vídeo). Upstream agora Connection: close +
#   Accept-Encoding: identity.
# - Range do player: não é mais repassado ao upstream (cache guardava pedaço
#   como se fosse segmento inteiro e a resposta saía 200 com corpo parcial);
#   o proxy busca o segmento inteiro e responde 206/Content-Range local.
# - do_HEAD adicionado. request_queue_size=32; acquire do semáforo com timeout.
# - Segmento que volta 200 mas é HTML/JSON/M3U8 (bloqueio/limite do painel)
#   é tratado como falha, não repassado ao player como vídeo.
# - Orçamento de tempo próprio para segmento (HLS_SEGMENT_MAX_OPERATION_TIME).
# - EXT-X-MEDIA / EXT-X-I-FRAME-STREAM-INF com URI agora reescritos.
# - Cabeçalhos de resposta do upstream normalizados em minúsculas.
# - Diagnóstico leve: motivo de cada falha de fetch + resumo dos primeiros
#   segmentos/playlists (tamanho, content-type, sync byte 0x47).
#
# Mantidas: never-fail, redirects 301/302/303/307/308, Host/Origin/Referer,
# tokens curtos, fresh resolve, REF de segmento, last-good, discontinuity,
# master/variant, troca segura de canal e API HLSAddon.

import sys
import os
import re
import ssl
import socket
import base64
import random
import threading
import time
import select
import http.client
import http.server
import socketserver
from urllib.parse import urlparse, urlunparse, urljoin

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if _ADDON_DIR not in sys.path:
    sys.path.insert(0, _ADDON_DIR)

# ─────────────────────────────────────────────
# LOG
# ─────────────────────────────────────────────
try:
    import xbmc as _xbmc
    LOGDEBUG = _xbmc.LOGDEBUG
    LOGINFO = _xbmc.LOGINFO
    LOGWARNING = _xbmc.LOGWARNING
    LOGERROR = _xbmc.LOGERROR
except Exception:
    _xbmc = None
    LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR = 0, 1, 2, 3

LOG_ENABLED = False  # False = log silenciado | True = log ativo

def set_logging(enabled):
    """Ativa (True) ou desativa (False) o log do proxy."""
    global LOG_ENABLED
    LOG_ENABLED = bool(enabled)

def _log(msg, level=None):
    if not LOG_ENABLED:
        return
    if level is None:
        level = LOGINFO
    try:
        if _xbmc is None:
            raise RuntimeError('sem xbmc')
        _xbmc.log(f'[HLSProxy] {msg}', level)
    except Exception:
        print(f'[HLSProxy] {msg}')

# ─────────────────────────────────────────────
# CONSTANTES — AJUSTADAS PARA CPU/RAM LIMITADOS
# ─────────────────────────────────────────────
HLS_MAX_REDIRECTS = 5
HLS_CONNECT_TIMEOUT = 3
HLS_READ_TIMEOUT = 6

# 64 KiB: menos chamadas Python/socket que 8 KiB, sem buffers gigantes.
HLS_CHUNK_SIZE = 64 * 1024

HLS_PLAYLIST_MAX_RETRIES = 4
HLS_SEGMENT_MAX_RETRIES = 4
HLS_RETRY_BACKOFF_BASE = 0.4
HLS_RETRY_BACKOFF_MAX = 4.0
HLS_STALE_SEQUENCE_MAX = 3
# Estagnação só conta se a media_sequence ficar parada por este tempo (s).
HLS_STALE_SEQUENCE_MIN_SECONDS = 30.0
HLS_LAST_GOOD_MAX_AGE = 20.0           # só para rotular o log (last-good é servida em qualquer idade)
HLS_PLAYLIST_RECOVERY_BUDGET = 8.0     # tempo máx. tentando recuperar antes de servir last-good
HLS_PLAYLIST_COLD_BUDGET = 20.0        # idem, mas sem nenhuma playlist boa ainda (início)
HLS_ENTRY_REUSE_SECONDS = 1.0          # reuso do resultado da entry_url (base == entry)
HLS_FRESH_REUSE_SECONDS = 3.0          # reuso do resultado de re-resolução recente
HLS_FRESH_FAIL_COOLDOWN = 1.0          # pausa após re-resolução falhar
HLS_TTL_REFRESH_RATIO = 0.75           # renova o token a 75% do TTL aprendido
HLS_TTL_MIN_LEARN = 10.0               # idade mínima p/ considerar 4xx como expiração
HLS_SEQ_REGRESS_MIN = 10               # regressão de sequência > N = recomeço de stream
HLS_SEQ_JUMP_MAX = 30                  # salto de sequência > N = lacuna de timeline
HLS_SEGMENT_TOTAL_BUDGET = 25.0        # tempo total p/ entregar um segmento antes do fallback
HLS_MAX_OPERATION_TIME = 6.0          # playlist / key / redirects
HLS_SEGMENT_MAX_OPERATION_TIME = 10.0  # segmento (corpo grande, ainda com teto)

HLS_HOST_DEAD_MAX_RETRIES = 2
HLS_HOST_DEAD_BACKOFF_MAX = 0.6
HLS_FRESH_RESOLVE_TIMEOUT = 3.5

# Limite local de requisições simultâneas.
HLS_MAX_LOCAL_WORKERS = 8
HLS_ACCEPT_QUEUE = 32
HLS_WORKER_WAIT = 60.0

# Cache de segmentos pequeno: RAM baixa e sem replayar dados antigos.
HLS_SEGMENT_CACHE_MAX = 6
HLS_SEGMENT_CACHE_MAX_AGE = 18.0

# Diagnóstico: quantas vezes logar resumo de playlist/segmento por sessão.
HLS_DIAG_PLAYLISTS = 3
HLS_DIAG_SEGMENTS = 4

HOST_BIND = '0.0.0.0'
HLS_PORT_RANGE = (20000, 60000)
HLS_PORT_BIND_ATTEMPTS = 50

# Filler TS pré-construído.
_HLS_NULL_PACKET = b'\x47\x1f\xff\x10' + (b'\x00' * 184)
HLS_FILLER_TS = _HLS_NULL_PACKET * 8

# Perfis imutáveis. SEM Icy-MetaData: pedir metadata ICY em segmento TS pode
# fazer o servidor intercalar blocos de metadados no meio do vídeo.
CLIENT_PROFILES = (
    {
        'User-Agent': 'Kodi/21.0 (Android; Kodi Media Center)',
        'Accept': '*/*',
    },
    {
        'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20',
        'Accept': '*/*',
    },
    {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ),
        'Accept': '*/*',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
    },
)

_SSL_CONTEXT = None
_SSL_CONTEXT_LOCK = threading.Lock()

_SERVER = None
_SERVER_LOCK = threading.Lock()
_SERVER_PORT = 0
_SERVER_SEMAPHORE = None

_SESSIONS = {}
_SESSIONS_LOCK = threading.Lock()

_ACTIVE_TOKEN = None
_ACTIVE_TOKEN_LOCK = threading.Lock()

# ─────────────────────────────────────────────
# HELPERS DE URL / HEADERS
# ─────────────────────────────────────────────
def _b64e(s):
    return base64.urlsafe_b64encode(s.encode('utf-8')).decode('ascii').rstrip('=')

def _b64d(s):
    pad = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode('ascii')).decode('utf-8')

def _host_header(parsed):
    if not parsed.hostname:
        return parsed.netloc
    default_port = 443 if parsed.scheme == 'https' else 80
    try:
        port = parsed.port
    except ValueError:
        port = None
    if port and port != default_port:
        return f'{parsed.hostname}:{port}'
    return parsed.hostname

def _origin_header(parsed):
    return f'{parsed.scheme}://{_host_header(parsed)}'

def _pick_profile(idx):
    return CLIENT_PROFILES[idx % len(CLIENT_PROFILES)]

def _build_headers(parsed, entry_parsed, profile_idx, extra=None):
    headers = dict(_pick_profile(profile_idx))
    headers['Host'] = _host_header(parsed)
    headers['Connection'] = 'close'
    headers['Accept-Encoding'] = 'identity'
    headers['Origin'] = _origin_header(entry_parsed)
    headers['Referer'] = urlunparse(entry_parsed)
    if extra:
        headers.update(extra)
    return headers

def _get_ssl_context():
    global _SSL_CONTEXT
    if _SSL_CONTEXT is None:
        with _SSL_CONTEXT_LOCK:
            if _SSL_CONTEXT is None:
                _SSL_CONTEXT = ssl.create_default_context()
    return _SSL_CONTEXT

# ─────────────────────────────────────────────
# FETCH
# ─────────────────────────────────────────────
class _FetchResult:
    __slots__ = ('status', 'headers', 'body', 'final_url', 'error')
    def __init__(self, status=None, headers=None, body=None, final_url=None, error=None):
        self.status = status
        self.headers = headers or {}
        self.body = body
        self.final_url = final_url
        self.error = error

def _describe(result):
    """Resumo curto de um _FetchResult para log."""
    if result is None:
        return 'sem resultado'
    if result.error is not None:
        return f'erro={result.error}'
    n = len(result.body) if result.body else 0
    ct = (result.headers or {}).get('content-type', '?')
    return f'HTTP {result.status}, {n}B, ct={ct}'

def _open_connection(parsed, timeout):
    if parsed.scheme == 'https':
        return http.client.HTTPSConnection(
            parsed.hostname, parsed.port or 443,
            timeout=timeout, context=_get_ssl_context()
        )
    return http.client.HTTPConnection(
        parsed.hostname, parsed.port or 80, timeout=timeout
    )

def _raw_recv_with_deadline(sock, n, deadline, already_buffered=b''):
    # Mantida por compatibilidade; _read_body_blocks não usa mais este caminho
    # (select() no socket ignora dados já presentes no buffer do http.client).
    if already_buffered:
        if len(already_buffered) >= n:
            return already_buffered[:n]
        chunks = [already_buffered]
        got = len(already_buffered)
    else:
        chunks = []
        got = 0

    while got < n:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise socket.timeout('deadline de leitura total excedido')
        readable, _, _ = select.select([sock], [], [], remaining)
        if not readable:
            raise socket.timeout('deadline de leitura total excedido')
        piece = sock.recv(min(HLS_CHUNK_SIZE, n - got))
        if not piece:
            break
        chunks.append(piece)
        got += len(piece)
    return b''.join(chunks)

def _read_body_blocks(resp, deadline=None, conn=None):
    """Lê o corpo respeitando um deadline de relógio.

    read1() devolve após UMA leitura no socket (não acumula o bloco inteiro
    como read(n) faz com Content-Length), então o deadline é checado a cada
    volta mesmo com upstream "gotejando". O timeout do socket é reajustado a
    cada volta para nunca passar do tempo restante.
    """
    sock = getattr(conn, 'sock', None) if conn is not None else None

    expected = None
    chunked = (resp.getheader('Transfer-Encoding') or '').lower() == 'chunked'
    if not chunked:
        try:
            cl = resp.getheader('Content-Length')
            if cl is not None:
                expected = int(cl)
        except Exception:
            expected = None

    reader = getattr(resp, 'read1', None) or resp.read
    buf = bytearray()

    while True:
        if deadline is not None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise socket.timeout('deadline de leitura total excedido')
            if sock is not None:
                try:
                    sock.settimeout(
                        max(0.25, min(float(HLS_READ_TIMEOUT), remaining))
                    )
                except Exception:
                    pass

        block = reader(HLS_CHUNK_SIZE)
        if not block:
            break
        buf.extend(block)

    if expected is not None and len(buf) < expected:
        raise ConnectionError(
            f'corpo incompleto: {len(buf)}/{expected} bytes'
        )
    return bytes(buf)

def _fetch(url, entry_parsed, profile_idx=0, timeout=HLS_CONNECT_TIMEOUT,
           max_redirects=HLS_MAX_REDIRECTS, range_header=None,
           max_operation_time=None):
    if max_operation_time is None:
        max_operation_time = HLS_MAX_OPERATION_TIME

    op_deadline = time.monotonic() + max_operation_time
    current = url

    for hop in range(max_redirects + 1):
        if time.monotonic() >= op_deadline:
            return _FetchResult(error='tempo total de operação excedido',
                                final_url=current)

        parsed = urlparse(current)
        if not parsed.scheme or not parsed.hostname:
            return _FetchResult(error=f'URL inválida: {current}')

        extra = {'Range': range_header} if range_header else None
        headers = _build_headers(parsed, entry_parsed, profile_idx, extra)

        path = parsed.path or '/'
        if parsed.query:
            path += '?' + parsed.query

        conn = None
        try:
            remaining = max(0.25, op_deadline - time.monotonic())
            conn_timeout = min(timeout, remaining)

            conn = _open_connection(parsed, conn_timeout)
            conn.request('GET', path, headers=headers)
            resp = conn.getresponse()
            status = resp.status

            if status in (301, 302, 303, 307, 308):
                location = resp.getheader('Location')
                try:
                    resp.read(4096)
                except Exception:
                    pass
                if not location:
                    return _FetchResult(status=status, final_url=current,
                                        error='redirect sem Location')
                current = urljoin(current, location)
                continue

            body = _read_body_blocks(resp, deadline=op_deadline, conn=conn)
            resp_headers = {
                k.lower(): v for k, v in resp.getheaders()
            }
            return _FetchResult(
                status=status, headers=resp_headers, body=body,
                final_url=current
            )

        except (socket.timeout, ConnectionError, OSError, ssl.SSLError,
                http.client.HTTPException, ValueError) as e:
            return _FetchResult(error=f'{type(e).__name__}: {e}',
                                final_url=current)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    return _FetchResult(error='máximo de redirects excedido', final_url=current)

def _is_network_level_error(result):
    return result is not None and result.error is not None and result.status is None

def _fetch_with_retry(url, entry_parsed, max_retries, timeout=HLS_CONNECT_TIMEOUT,
                      range_header=None, fast_backoff=False,
                      max_total_time=None, op_time=None,
                      no_retry_4xx=False):
    if op_time is None:
        op_time = HLS_MAX_OPERATION_TIME
    if max_total_time is None:
        max_total_time = op_time * max(1, max_retries)

    total_deadline = time.monotonic() + max_total_time
    last_result = None
    backoff_cap = (
        HLS_HOST_DEAD_BACKOFF_MAX if fast_backoff
        else HLS_RETRY_BACKOFF_MAX
    )

    for attempt in range(max_retries):
        remaining = total_deadline - time.monotonic()
        if remaining <= 0:
            break

        result = _fetch(
            url, entry_parsed, profile_idx=attempt, timeout=timeout,
            range_header=range_header,
            max_operation_time=min(remaining, op_time)
        )
        last_result = result

        if (result.error is None and result.status is not None
                and result.status < 400):
            return result

        if (fast_backoff and _is_network_level_error(result)
                and attempt + 1 >= HLS_HOST_DEAD_MAX_RETRIES):
            break

        # 4xx (token expirado, 404/403/410): repetir a MESMA URL não adianta;
        # quem chamou re-resolve. 408/429 continuam sendo repetidos.
        if (no_retry_4xx and result.status is not None
                and 400 <= result.status < 500
                and result.status not in (408, 429)):
            break

        if time.monotonic() >= total_deadline:
            break

        wait = min(
            HLS_RETRY_BACKOFF_BASE * (2 ** attempt),
            backoff_cap
        )
        wait *= 0.8 + 0.4 * random.random()
        time.sleep(min(wait, max(0.0, total_deadline - time.monotonic())))

    return last_result

# ─────────────────────────────────────────────
# VALIDAÇÃO DE CORPO
# ─────────────────────────────────────────────
_BAD_BODY_PREFIXES = (
    b'<!doctype', b'<html', b'<?xml', b'<head', b'<body', b'{"', b'#extm3u',
)

def _is_bad_media_body(body):
    """HTML/JSON/M3U8 disfarçado de 200 OK. Não rejeita binário qualquer
    (segmento AES-128 é aleatório), só prefixos claramente textuais."""
    if not body:
        return True
    head = body[:64].lstrip().lower()
    return head.startswith(_BAD_BODY_PREFIXES)

def _has_ts_sync(body):
    if not body or body[0] != 0x47:
        return False
    return len(body) < 189 or body[188] == 0x47

def _media_ok(result):
    return (result is not None and result.error is None
            and result.status is not None and result.status < 400
            and result.body and not _is_bad_media_body(result.body))

# ─────────────────────────────────────────────
# SESSÃO
# ─────────────────────────────────────────────
class _StreamSession:
    def __init__(self, token, entry_url):
        self.token = token
        self.entry_url = entry_url
        self.entry_parsed = urlparse(entry_url)
        self.resolved_base = entry_url
        self.lock = threading.RLock()
        self.last_media_sequence = None
        self.last_seq_change_ts = time.time()
        self.stale_sequence_count = 0
        self.last_good_playlist_body = None
        self.last_good_playlist_base = None
        self.last_good_playlist_time = 0.0

        self.last_good_segments = {}
        self.segment_cache_order = []

        self.profile_idx = 0
        self.created_at = time.time()
        self.last_access = time.time()
        self.killed = threading.Event()
        self.last_good_host = None
        self.discontinuity_pending = False
        self.last_seen_first_uri = None

        self.diag_playlists = 0
        self.diag_segments = 0

        # Re-resolução single-flight + ciclo de vida do token
        self.resolve_lock = threading.Lock()
        self.fresh_cache = None            # (texto, final_url)
        self.fresh_cache_time = 0.0        # monotonic
        self.fresh_fail_time = -1e9        # monotonic
        self.base_born = 0.0               # time.time() em que a base atual foi adotada
        self.base_ttl = None               # vida do token aprendida (s)

        # MEDIA-SEQUENCE exposta ao player (monotônica mesmo se a origem recomeçar)
        self.seq_offset = 0
        self.last_exposed_end = 0

        self.log_ts = {}

    def touch(self):
        self.last_access = time.time()

    def kill(self):
        self.killed.set()

    def rotate_profile(self):
        with self.lock:
            self.profile_idx += 1

    def force_fresh_resolve(self):
        # Mantida por compatibilidade. A recuperação real passou a ser
        # _fresh_resolve(); discontinuity agora só é marcada por
        # _accept_playlist (host mudou / sequência saltou ou regrediu).
        with self.lock:
            self.resolved_base = self.entry_url
            self.stale_sequence_count = 0
            self.base_born = 0.0
            _log(
                f'[{self.token[:8]}] Forçando re-resolução pela URL de entrada',
                LOGINFO
            )

    def cache_segment(self, key, body):
        now = time.time()
        with self.lock:
            self.last_good_segments[key] = (body, now)
            try:
                self.segment_cache_order.remove(key)
            except ValueError:
                pass
            self.segment_cache_order.append(key)

            while len(self.segment_cache_order) > HLS_SEGMENT_CACHE_MAX:
                old = self.segment_cache_order.pop(0)
                self.last_good_segments.pop(old, None)

    def get_cached_segment(self, key):
        now = time.time()
        with self.lock:
            item = self.last_good_segments.get(key)
            if item is None:
                return None
            body, ts = item
            if now - ts > HLS_SEGMENT_CACHE_MAX_AGE:
                self.last_good_segments.pop(key, None)
                try:
                    self.segment_cache_order.remove(key)
                except ValueError:
                    pass
                return None
            return item

def _get_or_create_session(token, entry_url):
    with _SESSIONS_LOCK:
        sess = _SESSIONS.get(token)
        if sess is None:
            sess = _StreamSession(token, entry_url)
            _SESSIONS[token] = sess
        else:
            sess.touch()
        return sess

def _set_active_channel(token, entry_url):
    global _ACTIVE_TOKEN

    with _ACTIVE_TOKEN_LOCK:
        previous_token = _ACTIVE_TOKEN
        _ACTIVE_TOKEN = token

    if previous_token is not None and previous_token != token:
        with _SESSIONS_LOCK:
            old = _SESSIONS.pop(previous_token, None)
        if old is not None:
            old.kill()
            _log(
                f'Canal trocado: sessão [{previous_token[:8]}] encerrada',
                LOGINFO
            )

    return _get_or_create_session(token, entry_url)

def _gc_sessions(max_idle=600):
    with _SESSIONS_LOCK:
        now = time.time()
        dead = [
            t for t, s in _SESSIONS.items()
            if now - s.last_access > max_idle
        ]
        for t in dead:
            sess = _SESSIONS.pop(t, None)
            if sess:
                sess.kill()
        if dead:
            _log(f'GC: removidas {len(dead)} sessão(ões) ociosas', LOGINFO)

# ─────────────────────────────────────────────
# M3U8
# ─────────────────────────────────────────────
_RE_MEDIA_SEQUENCE = re.compile(rb'#EXT-X-MEDIA-SEQUENCE:(\d+)')
_RE_KEY_URI = re.compile(r'(#EXT-X-(?:SESSION-)?KEY:[^\n]*URI=")([^"]+)(")')
_RE_MAP_URI = re.compile(r'(#EXT-X-MAP:[^\n]*URI=")([^"]+)(")')
_RE_RENDITION_URI = re.compile(
    r'(#EXT-X-(?:MEDIA|I-FRAME-STREAM-INF):[^\n]*URI=")([^"]+)(")'
)
_RE_STREAM_INF = re.compile(r'#EXT-X-STREAM-INF', re.IGNORECASE)

def _extract_media_sequence(text):
    if isinstance(text, bytes):
        m = _RE_MEDIA_SEQUENCE.search(text)
    else:
        m = re.search(r'#EXT-X-MEDIA-SEQUENCE:(\d+)', text)
    return int(m.group(1)) if m else None

def _is_master_playlist(text):
    return bool(_RE_STREAM_INF.search(text))

def _rewrite_uri(base_url, uri, token, kind):
    absolute = urljoin(base_url, uri)
    return f'/hls/{kind}/{token}/{_b64e(absolute)}'

def _rewrite_playlist(text, base_url, token, insert_discontinuity=False,
                      seq_offset=0):
    is_master = _is_master_playlist(text)
    lines = text.split('\n')
    out = []
    discontinuity_inserted = not insert_discontinuity or is_master
    pending = []

    for line in lines:
        line = line.rstrip('\r')
        stripped = line.strip()

        if seq_offset and stripped.startswith('#EXT-X-MEDIA-SEQUENCE:'):
            try:
                n = int(stripped.split(':', 1)[1]) + seq_offset
                out.append(f'#EXT-X-MEDIA-SEQUENCE:{n}')
                continue
            except ValueError:
                pass

        if stripped.startswith('#EXT-X-KEY') or stripped.startswith('#EXT-X-SESSION-KEY'):
            def sub_key(m):
                return m.group(1) + _rewrite_uri(
                    base_url, m.group(2), token, 'key'
                ) + m.group(3)
            out.append(_RE_KEY_URI.sub(sub_key, line))
            continue

        if stripped.startswith('#EXT-X-MAP'):
            def sub_map(m):
                return m.group(1) + _rewrite_uri(
                    base_url, m.group(2), token, 'seg'
                ) + m.group(3)
            out.append(_RE_MAP_URI.sub(sub_map, line))
            continue

        if (stripped.startswith('#EXT-X-MEDIA:')
                or stripped.startswith('#EXT-X-I-FRAME-STREAM-INF')):
            def sub_rend(m):
                return m.group(1) + _rewrite_uri(
                    base_url, m.group(2), token, 'variant'
                ) + m.group(3)
            out.append(_RE_RENDITION_URI.sub(sub_rend, line))
            continue

        if stripped and not stripped.startswith('#'):
            if not discontinuity_inserted:
                out.append('#EXT-X-DISCONTINUITY')
                discontinuity_inserted = True
            if pending:
                out.extend(pending)
                pending = []
            kind = 'variant' if is_master else 'seg'
            out.append(_rewrite_uri(base_url, stripped, token, kind))
            continue

        if (stripped.startswith('#EXTINF')
                or stripped.startswith('#EXT-X-BYTERANGE')
                or stripped.startswith('#EXT-X-PROGRAM-DATE-TIME')):
            pending.append(line)
            continue

        out.append(line)

    if pending:
        out.extend(pending)
    return '\n'.join(out)

def _diag_playlist(sess, rewritten):
    if sess.diag_playlists >= HLS_DIAG_PLAYLISTS:
        return
    sess.diag_playlists += 1
    short = []
    for ln in rewritten.split('\n')[:14]:
        short.append(ln if len(ln) <= 90 else ln[:90] + '…')
    _log(
        f'[{sess.token[:8]}] Playlist reescrita #{sess.diag_playlists}: '
        + ' | '.join(short),
        LOGINFO
    )

# ─────────────────────────────────────────────
# PLAYLIST
# ─────────────────────────────────────────────
def _log_throttled(sess, key, msg, level=None, interval=5.0):
    now = time.monotonic()
    with sess.lock:
        if now - sess.log_ts.get(key, -1e9) < interval:
            return
        sess.log_ts[key] = now
    _log(msg, level)

def _count_segments(text):
    n = 0
    for ln in text.split('\n'):
        ln = ln.strip()
        if ln and not ln.startswith('#'):
            n += 1
    return n

def _playlist_ok(result):
    return (result is not None and result.error is None
            and result.status is not None and result.status < 400
            and result.body and b'#EXTM3U' in result.body[:128])

def _take_discontinuity(sess):
    with sess.lock:
        d = sess.discontinuity_pending
        sess.discontinuity_pending = False
    return d

def _accept_playlist(sess, text, seq, used_base, via_fresh):
    """Registra uma playlist boa. Decide discontinuity / offset de sequência.
    Retorna True se a estagnação real pede uma re-resolução."""
    need_refresh = False
    with sess.lock:
        now = time.time()
        new_host = urlparse(used_base).hostname
        changed = (
            sess.last_good_host is not None and
            new_host is not None and
            new_host != sess.last_good_host
        )
        if changed:
            _log(
                f'[{sess.token[:8]}] CDN trocou de host: '
                f'{sess.last_good_host} -> {new_host}',
                LOGINFO
            )
            sess.discontinuity_pending = True
        sess.last_good_host = new_host

        last = sess.last_media_sequence
        if seq is None or last is None:
            sess.stale_sequence_count = 0
            sess.last_seq_change_ts = now
        elif seq == last:
            # O Kodi consulta a playlist mais rápido que a duração do
            # segmento: repetir a sequência é normal. Só é estagnação real
            # se persistir por tempo suficiente.
            sess.stale_sequence_count += 1
            stalled_for = now - sess.last_seq_change_ts
            if (sess.stale_sequence_count >= HLS_STALE_SEQUENCE_MAX
                    and stalled_for >= HLS_STALE_SEQUENCE_MIN_SECONDS):
                if not via_fresh and used_base != sess.entry_url:
                    need_refresh = True
                else:
                    _log(
                        f'[{sess.token[:8]}] media_sequence {seq} '
                        f'estagnada há {stalled_for:.0f}s; '
                        f'mantendo origem atual',
                        LOGWARNING
                    )
                sess.stale_sequence_count = 0
                sess.last_seq_change_ts = now
        else:
            sess.stale_sequence_count = 0
            sess.last_seq_change_ts = now
            if last - seq > HLS_SEQ_REGRESS_MIN:
                # Origem recomeçou a numeração: mantém a sequência EXPOSTA
                # monotônica para o player não ficar esperando.
                sess.seq_offset = sess.last_exposed_end - seq
                sess.discontinuity_pending = True
                _log(
                    f'[{sess.token[:8]}] media_sequence regrediu '
                    f'{last} -> {seq}; offset={sess.seq_offset}',
                    LOGWARNING
                )
            elif seq - last > HLS_SEQ_JUMP_MAX:
                sess.discontinuity_pending = True
                _log(
                    f'[{sess.token[:8]}] media_sequence saltou '
                    f'{last} -> {seq}',
                    LOGWARNING
                )

        if seq is not None:
            if last is None or seq >= last or last - seq > HLS_SEQ_REGRESS_MIN:
                sess.last_media_sequence = seq
            exposed_first = seq + sess.seq_offset
            sess.last_exposed_end = max(
                sess.last_exposed_end,
                exposed_first + _count_segments(text)
            )

        sess.resolved_base = used_base
        if via_fresh:
            sess.base_born = now if used_base != sess.entry_url else 0.0
        sess.last_good_playlist_body = text
        sess.last_good_playlist_base = used_base
        sess.last_good_playlist_time = now

    return need_refresh

def _fresh_resolve(sess, min_interval=None):
    """Busca a entry_url (UMA por vez), ADOTA a base nova na sessão e devolve
    (texto, final_url) ou None. Chamadas concorrentes (poll de playlist +
    recuperação de segmentos) esperam o lock e reaproveitam o resultado
    recente, em vez de cada uma gerar um token novo no painel."""
    if min_interval is None:
        min_interval = HLS_FRESH_REUSE_SECONDS
    if sess.killed.is_set():
        return None

    with sess.resolve_lock:
        if sess.killed.is_set():
            return None
        now = time.monotonic()
        if (sess.fresh_cache is not None
                and now - sess.fresh_cache_time < min_interval):
            return sess.fresh_cache
        if now - sess.fresh_fail_time < HLS_FRESH_FAIL_COOLDOWN:
            return None

        with sess.lock:
            prev_born = sess.base_born
        result = _fetch_with_retry(
            sess.entry_url, sess.entry_parsed,
            HLS_PLAYLIST_MAX_RETRIES,
            timeout=HLS_FRESH_RESOLVE_TIMEOUT,
            fast_backoff=True,
            max_total_time=HLS_FRESH_RESOLVE_TIMEOUT * 2
        )
        if sess.killed.is_set():
            return None

        if _playlist_ok(result):
            text = result.body.decode('utf-8', errors='replace')
            final = result.final_url or sess.entry_url
            seq = _extract_media_sequence(result.body)
            _accept_playlist(sess, text, seq, final, via_fresh=True)
            sess.fresh_cache = (text, final)
            sess.fresh_cache_time = time.monotonic()
            age = (time.time() - prev_born) if prev_born else 0
            _log(
                f'[{sess.token[:8]}] Re-resolução OK: '
                f'host={urlparse(final).hostname} seq={seq} '
                f'(base anterior viveu {age:.0f}s)',
                LOGINFO
            )
            return sess.fresh_cache

        sess.fresh_cache = None
        sess.fresh_fail_time = time.monotonic()
        _log_throttled(
            sess, 'fresh_fail',
            f'[{sess.token[:8]}] Re-resolução falhou ({_describe(result)})',
            LOGWARNING
        )
        return None

def _try_resolve_playlist_once(sess):
    with sess.lock:
        base = sess.resolved_base
        born = sess.base_born
        ttl = sess.base_ttl
    entry = sess.entry_url

    # Ainda sem base tokenizada (início): a própria busca da entry é a
    # re-resolução.
    if base == entry:
        r = _fresh_resolve(sess, HLS_ENTRY_REUSE_SECONDS)
        if r is None:
            return None
        return r[0], r[1], _take_discontinuity(sess)

    age = (time.time() - born) if born else None

    # Renovação preventiva: troca o token antes de ele expirar.
    if ttl and age is not None and age > ttl * HLS_TTL_REFRESH_RATIO:
        r = _fresh_resolve(sess, HLS_FRESH_REUSE_SECONDS)
        if r is not None:
            _log(
                f'[{sess.token[:8]}] Renovação preventiva do token '
                f'(idade {age:.0f}s, ttl ~{ttl:.0f}s)',
                LOGINFO
            )
            return r[0], r[1], _take_discontinuity(sess)

    result = _fetch_with_retry(
        base, sess.entry_parsed, HLS_HOST_DEAD_MAX_RETRIES,
        fast_backoff=True,
        max_total_time=HLS_FRESH_RESOLVE_TIMEOUT,
        no_retry_4xx=True
    )
    if sess.killed.is_set():
        return None

    if _playlist_ok(result):
        text = result.body.decode('utf-8', errors='replace')
        seq = _extract_media_sequence(result.body)
        used_base = result.final_url or base
        need_refresh = _accept_playlist(
            sess, text, seq, used_base, via_fresh=False
        )
        if need_refresh:
            r = _fresh_resolve(sess, 0.0)
            if r is not None:
                return r[0], r[1], _take_discontinuity(sess)
        return text, used_base, _take_discontinuity(sess)

    # Falhou. 4xx numa base com idade = token expirou: aprende o TTL.
    if (result is not None and result.status is not None
            and 400 <= result.status < 500
            and age is not None and age >= HLS_TTL_MIN_LEARN):
        with sess.lock:
            sess.base_ttl = min(sess.base_ttl, age) if sess.base_ttl else age
            ttl = sess.base_ttl
        _log(
            f'[{sess.token[:8]}] Token da base expirou com {age:.0f}s '
            f'(ttl aprendido ~{ttl:.0f}s)',
            LOGINFO
        )
    _log_throttled(
        sess, 'base_fail',
        f'[{sess.token[:8]}] Playlist da base falhou ({_describe(result)})',
        LOGWARNING
    )

    r = _fresh_resolve(sess, HLS_FRESH_REUSE_SECONDS)
    if r is not None:
        return r[0], r[1], _take_discontinuity(sess)
    return None

def _resolve_playlist(sess):
    """Nunca devolve erro: tenta recuperar por um orçamento de tempo e, se não
    der, devolve a última playlist boa (de qualquer idade). Só devolve
    texto=None se NUNCA houve playlist boa (placeholder fica no handler)."""
    if sess.killed.is_set():
        return None, sess.resolved_base, False

    with sess.lock:
        have_good = sess.last_good_playlist_body is not None
    budget = (
        HLS_PLAYLIST_RECOVERY_BUDGET if have_good
        else HLS_PLAYLIST_COLD_BUDGET
    )
    deadline = time.monotonic() + budget
    attempt = 0

    while True:
        res = _try_resolve_playlist_once(sess)
        if res is not None:
            return res
        if sess.killed.is_set():
            return None, sess.resolved_base, False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        attempt += 1
        time.sleep(min(0.5 * attempt, 2.0, remaining))

    with sess.lock:
        age = time.time() - sess.last_good_playlist_time
        cached = sess.last_good_playlist_body
        cached_base = sess.last_good_playlist_base or sess.resolved_base

    if cached is not None:
        _log_throttled(
            sess, 'lastgood',
            f'[{sess.token[:8]}] Servindo playlist last-good '
            f'(idade {age:.1f}s{" — velha" if age > HLS_LAST_GOOD_MAX_AGE else ""})',
            LOGWARNING
        )
        return cached, cached_base, False

    _log_throttled(
        sess, 'nogood',
        f'[{sess.token[:8]}] Sem nenhuma playlist boa ainda; placeholder',
        LOGERROR
    )
    return None, sess.resolved_base, False

# ─────────────────────────────────────────────
# RECUPERAÇÃO DE SEGMENTO POR REFERÊNCIA
# ─────────────────────────────────────────────
def _extract_filename(url):
    try:
        return urlparse(url).path.rsplit('/', 1)[-1].split('?')[0]
    except Exception:
        return ''

def _find_segment_in_manifest(filename, manifest_text, final_url):
    if not filename or not manifest_text:
        return None

    for line in manifest_text.splitlines():
        cand = line.strip()
        if cand and not cand.startswith('#') and filename in cand:
            return urljoin(final_url, cand)

    for line in manifest_text.splitlines():
        cand = line.strip()
        if not cand or cand.startswith('#'):
            continue
        try:
            absolute = urljoin(final_url, cand)
            if _extract_filename(absolute) == filename:
                return absolute
        except Exception:
            pass
    return None

def _retoken_segment(old_url, manifest_text, final_url):
    """Reaplica ao path do segmento antigo o host/query (token) vigente no
    manifesto fresco. Cobre segmento que já saiu da janela do manifesto."""
    sample = None
    for line in manifest_text.splitlines():
        cand = line.strip()
        if cand and not cand.startswith('#'):
            sample = urljoin(final_url, cand)
    if not sample:
        return None
    sp = urlparse(sample)
    op = urlparse(old_url)
    if not sp.query:
        return None
    return urlunparse((sp.scheme, sp.netloc, op.path, op.params, sp.query, ''))

def _resolve_seg_via_ref(sess, seg_url):
    filename = _extract_filename(seg_url)
    if not filename:
        return None

    r = _fresh_resolve(sess, HLS_FRESH_REUSE_SECONDS)
    if r is None:
        with sess.lock:
            manifest = sess.last_good_playlist_body
            final_url = sess.last_good_playlist_base or sess.resolved_base
        if manifest is None:
            return None
    else:
        manifest, final_url = r

    return (_find_segment_in_manifest(filename, manifest, final_url)
            or _retoken_segment(seg_url, manifest, final_url))

# ─────────────────────────────────────────────
# MEDIA
# ─────────────────────────────────────────────
def _diag_segment(sess, url, body, ct):
    if sess.diag_segments >= HLS_DIAG_SEGMENTS:
        return
    sess.diag_segments += 1
    _log(
        f'[{sess.token[:8]}] Segmento #{sess.diag_segments} '
        f'{_extract_filename(url)[:40]}: {len(body)}B ct={ct} '
        f'ts_sync={"OK" if _has_ts_sync(body) else "NAO"} '
        f'first={body[:4].hex()}',
        LOGINFO
    )

def _resolve_media(sess, absolute_url, rel_key, range_header=None, kind='seg'):
    """Nunca devolve erro: segmento real -> recuperado (manifesto fresco /
    token novo) -> cache last-good -> filler. Chave: 16 bytes zerados.
    range_header é aceito por compatibilidade mas NÃO é repassado ao upstream
    (o segmento é buscado e cacheado inteiro; o Range é atendido no handler)."""
    fallback = HLS_FILLER_TS if kind != 'key' else (b'\x00' * 16)

    if sess.killed.is_set():
        return fallback, None

    t_end = time.monotonic() + HLS_SEGMENT_TOTAL_BUDGET

    result = _fetch_with_retry(
        absolute_url, sess.entry_parsed,
        HLS_SEGMENT_MAX_RETRIES,
        timeout=HLS_READ_TIMEOUT,
        fast_backoff=True,
        max_total_time=HLS_SEGMENT_MAX_OPERATION_TIME + 2,
        op_time=HLS_SEGMENT_MAX_OPERATION_TIME,
        no_retry_4xx=True
    )

    if sess.killed.is_set():
        return fallback, None

    if _media_ok(result):
        sess.cache_segment(rel_key, result.body)
        ct = (result.headers or {}).get('content-type')
        _diag_segment(sess, absolute_url, result.body, ct)
        return result.body, ct

    if (result is not None and result.error is None and result.body
            and _is_bad_media_body(result.body)):
        _log(
            f'[{sess.token[:8]}] Segmento inválido (texto no lugar de vídeo): '
            f'{_describe(result)} first={result.body[:32]!r}',
            LOGWARNING
        )
    else:
        _log(
            f'[{sess.token[:8]}] Segmento falhou: {_describe(result)}',
            LOGWARNING
        )

    # Recuperação: manifesto fresco (single-flight, base adotada na sessão),
    # localizando o segmento pelo nome ou reaplicando o token novo ao path.
    if t_end - time.monotonic() > 2.0 and not sess.killed.is_set():
        recovered_url = _resolve_seg_via_ref(sess, absolute_url)
        remaining = t_end - time.monotonic()
        if recovered_url and recovered_url != absolute_url and remaining > 1.0:
            recovered = _fetch_with_retry(
                recovered_url, sess.entry_parsed,
                HLS_SEGMENT_MAX_RETRIES,
                timeout=HLS_READ_TIMEOUT,
                fast_backoff=True,
                max_total_time=remaining,
                op_time=min(HLS_SEGMENT_MAX_OPERATION_TIME, remaining),
                no_retry_4xx=True
            )
            if _media_ok(recovered):
                _log(
                    f'[{sess.token[:8]}] Segmento recuperado via REF',
                    LOGINFO
                )
                sess.cache_segment(rel_key, recovered.body)
                return recovered.body, (recovered.headers or {}).get('content-type')
            _log(
                f'[{sess.token[:8]}] REF não recuperou: {_describe(recovered)}',
                LOGWARNING
            )

    cached = sess.get_cached_segment(rel_key)
    if cached is not None:
        body, ts = cached
        _log(
            f'[{sess.token[:8]}] Servindo segmento last-good '
            f'(idade {time.time()-ts:.1f}s)',
            LOGWARNING
        )
        return body, None

    _log(
        f'[{sess.token[:8]}] Sem last-good; servindo filler',
        LOGERROR
    )
    return fallback, ('video/mp2t' if kind != 'key' else None)

def _seg_content_type(ct):
    if ct:
        low = ct.lower()
        if low.startswith('video/') or low.startswith('audio/'):
            return ct
    return 'video/mp2t'

_RE_RANGE = re.compile(r'^\s*bytes\s*=\s*(\d*)\s*-\s*(\d*)\s*(?:,.*)?$', re.IGNORECASE)

def _apply_range(body, range_header):
    """Atende Range localmente (200 ou 206; nunca 416). Retorna (status, body, headers_extra)."""
    extra = {'Accept-Ranges': 'bytes'}
    if not range_header:
        return 200, body, extra
    m = _RE_RANGE.match(range_header)
    if not m:
        return 200, body, extra

    total = len(body)
    s, e = m.group(1), m.group(2)
    if s == '' and e == '':
        return 200, body, extra

    if s == '':
        n = int(e)
        if n <= 0:
            return 200, body, extra
        start = max(0, total - n)
        end = total - 1
    else:
        start = int(s)
        end = int(e) if e != '' else total - 1
        end = min(end, total - 1)

    if start >= total or start > end:
        return 200, body, extra

    if start == 0 and end == total - 1:
        return 200, body, extra

    extra['Content-Range'] = f'bytes {start}-{end}/{total}'
    return 206, body[start:end + 1], extra

# ─────────────────────────────────────────────
# HTTP SERVER
# ─────────────────────────────────────────────
class _ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = HLS_ACCEPT_QUEUE

    def process_request(self, request, client_address):
        # Limita threads vivas para não sobrecarregar CPU/RAM de TV Box.
        sem = _SERVER_SEMAPHORE
        if sem is None:
            return super().process_request(request, client_address)

        # Com timeout: se todos os workers estiverem presos, não trava o
        # loop de accept para sempre; descarta e o Kodi tenta de novo.
        if not sem.acquire(timeout=HLS_WORKER_WAIT):
            _log('Sem worker livre; conexão descartada', LOGWARNING)
            try:
                self.shutdown_request(request)
            except Exception:
                pass
            return

        try:
            t = threading.Thread(
                target=self._run_limited_request,
                args=(request, client_address, sem),
                daemon=True
            )
            t.start()
        except Exception:
            sem.release()
            raise

    def _run_limited_request(self, request, client_address, sem):
        try:
            self.process_request_thread(request, client_address)
        finally:
            sem.release()

class _Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    timeout = 30

    def log_message(self, fmt, *args):
        pass

    def _write_ok(self, body, content_type, status=200, extra=None):
        try:
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Connection', 'close')
            self.send_header('Access-Control-Allow-Origin', '*')
            if extra:
                for k, v in extra.items():
                    self.send_header(k, v)
            self.end_headers()

            total = len(body)
            off = 0
            while off < total:
                self.wfile.write(body[off:off + HLS_CHUNK_SIZE])
                off += HLS_CHUNK_SIZE

        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            pass
        except Exception as e:
            _log(f'Erro escrevendo resposta: {e}', LOGERROR)

    def _never_fail_empty_playlist(self, sess=None):
        # Placeholder que CONTINUA a sequência exposta (nunca volta a 0, o que
        # violaria a monotonicidade HLS e faria o player descartar a playlist).
        seq = 0
        if sess is not None:
            with sess.lock:
                seq = sess.last_exposed_end
        body = (
            '#EXTM3U\n'
            '#EXT-X-VERSION:3\n'
            '#EXT-X-TARGETDURATION:5\n'
            f'#EXT-X-MEDIA-SEQUENCE:{seq}\n'
        ).encode('utf-8')
        self._write_ok(body, 'application/vnd.apple.mpegurl',
                       extra={'Cache-Control': 'no-cache'})

    def _write_ended_playlist(self):
        # Sessão encerrada/trocada de canal: fim limpo, SEM status de erro.
        body = (
            '#EXTM3U\n'
            '#EXT-X-VERSION:3\n'
            '#EXT-X-TARGETDURATION:5\n'
            '#EXT-X-MEDIA-SEQUENCE:0\n'
            '#EXT-X-ENDLIST\n'
        ).encode('utf-8')
        self._write_ok(body, 'application/vnd.apple.mpegurl',
                       extra={'Cache-Control': 'no-cache'})

    def _write_neutral(self, kind, sess=None):
        """Resposta 200 válida para qualquer tipo de recurso. Nunca 204/404."""
        if kind == 'seg':
            self._write_ok(HLS_FILLER_TS, 'video/mp2t')
        elif kind == 'key':
            self._write_ok(b'\x00' * 16, 'application/octet-stream')
        elif kind in ('playlist', 'variant'):
            self._never_fail_empty_playlist(sess)
        else:
            self._write_ok(b'', 'text/plain')

    def do_HEAD(self):
        try:
            parts = [p for p in urlparse(self.path).path.split('/') if p]
            kind = parts[1] if len(parts) >= 3 and parts[0] == 'hls' else ''
            if kind in ('playlist', 'variant'):
                ct = 'application/vnd.apple.mpegurl'
            elif kind == 'key':
                ct = 'application/octet-stream'
            elif kind == 'seg':
                ct = 'video/mp2t'
            else:
                ct = 'text/plain'
            self.send_response(200)
            self.send_header('Content-Type', ct)
            self.send_header('Connection', 'close')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
        except Exception:
            pass

    def do_GET(self):
        kind = ''
        sess = None
        try:
            parsed = urlparse(self.path)
            parts = [p for p in parsed.path.split('/') if p]

            if len(parts) < 3 or parts[0] != 'hls':
                self._write_neutral('')
                return

            kind = parts[1]
            token = parts[2]

            if kind == 'playlist':
                with _SESSIONS_LOCK:
                    sess = _SESSIONS.get(token)

                active = False
                if sess is not None:
                    with _ACTIVE_TOKEN_LOCK:
                        active = token == _ACTIVE_TOKEN

                if sess is None or sess.killed.is_set() or not active:
                    self._write_ended_playlist()
                    return

                sess.touch()
                text, base, discontinuity = _resolve_playlist(sess)

                if text is None:
                    self._never_fail_empty_playlist(sess)
                    return

                is_master = _is_master_playlist(text)
                rewritten = _rewrite_playlist(
                    text, base, token,
                    insert_discontinuity=(discontinuity and not is_master),
                    seq_offset=(0 if is_master else sess.seq_offset)
                )
                _diag_playlist(sess, rewritten)
                self._write_ok(
                    rewritten.encode('utf-8'),
                    'application/vnd.apple.mpegurl',
                    extra={'Cache-Control': 'no-cache'}
                )
                return

            if kind in ('seg', 'key', 'variant'):
                if len(parts) < 4:
                    self._write_neutral(kind)
                    return

                with _SESSIONS_LOCK:
                    sess = _SESSIONS.get(token)

                active = False
                if sess is not None:
                    with _ACTIVE_TOKEN_LOCK:
                        active = token == _ACTIVE_TOKEN

                if sess is None or sess.killed.is_set() or not active:
                    if kind == 'variant':
                        self._write_ended_playlist()
                    else:
                        self._write_neutral(kind)
                    return

                sess.touch()
                absolute_url = _b64d(parts[3])
                rel_key = parts[3]

                if kind == 'variant':
                    result = _fetch_with_retry(
                        absolute_url, sess.entry_parsed,
                        HLS_PLAYLIST_MAX_RETRIES,
                        max_total_time=HLS_PLAYLIST_RECOVERY_BUDGET
                    )
                    if _playlist_ok(result):
                        text = result.body.decode('utf-8', errors='replace')
                        base = result.final_url or absolute_url
                        rewritten = _rewrite_playlist(
                            text, base, token,
                            seq_offset=sess.seq_offset
                        )
                        self._write_ok(
                            rewritten.encode('utf-8'),
                            'application/vnd.apple.mpegurl',
                            extra={'Cache-Control': 'no-cache'}
                        )
                    else:
                        _log(
                            f'[{token[:8]}] Variant falhou: {_describe(result)}',
                            LOGWARNING
                        )
                        self._never_fail_empty_playlist(sess)
                    return

                range_header = self.headers.get('Range')
                body, ct = _resolve_media(
                    sess, absolute_url, rel_key,
                    range_header=range_header, kind=kind
                )

                if not body:
                    self._write_neutral(kind, sess)
                    return

                if kind == 'key':
                    self._write_ok(body, 'application/octet-stream')
                    return

                status, out_body, extra = _apply_range(body, range_header)
                self._write_ok(out_body, _seg_content_type(ct), status, extra)
                return

            self._write_neutral('')

        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            pass
        except Exception as e:
            _log(f'Erro no handler GET: {e}', LOGERROR)
            try:
                self._write_neutral(kind or 'playlist', sess)
            except Exception:
                pass

def _ensure_server_running():
    global _SERVER, _SERVER_PORT, _SERVER_SEMAPHORE

    with _SERVER_LOCK:
        if _SERVER is not None:
            return _SERVER_PORT

        low, high = HLS_PORT_RANGE
        candidates = random.sample(
            range(low, high + 1),
            min(HLS_PORT_BIND_ATTEMPTS, high - low + 1)
        )

        for port in candidates:
            try:
                _SERVER = _ThreadingHTTPServer(
                    (HOST_BIND, port), _Handler
                )
                _SERVER_PORT = port
                break
            except OSError:
                continue

        if _SERVER is None:
            raise RuntimeError(
                'Não foi possível abrir porta local para hlsproxy'
            )

        _SERVER_SEMAPHORE = threading.BoundedSemaphore(
            HLS_MAX_LOCAL_WORKERS
        )

        t = threading.Thread(
            target=_SERVER.serve_forever,
            kwargs={'poll_interval': 0.25},
            daemon=True
        )
        t.start()

        gc_t = threading.Thread(
            target=_gc_loop,
            name='HLSProxy-GC',
            daemon=True
        )
        gc_t.start()

        _log(
            f'Servidor HLS iniciado em {HOST_BIND}:{_SERVER_PORT} '
            f'(workers={HLS_MAX_LOCAL_WORKERS}, chunk={HLS_CHUNK_SIZE // 1024}K)',
            LOGINFO
        )
        return _SERVER_PORT

def _gc_loop():
    while True:
        time.sleep(120)
        try:
            _gc_sessions()
        except Exception:
            pass

# ─────────────────────────────────────────────
# API PÚBLICA — COMPATÍVEL COM default.py
# ─────────────────────────────────────────────
class HLSAddon:
    def __init__(self, addon_handle):
        self.handle = addon_handle

    def play_stream(self, url):
        import xbmcplugin
        import xbmcgui
        import xbmc

        port = _ensure_server_running()

        token = _b64e(
            f'{os.urandom(12).hex()}|{time.time_ns()}'
        )[:16]
        entry_b64 = _b64e(url)

        _set_active_channel(token, url)

        local_url = (
            f'http://127.0.0.1:{port}/hls/playlist/'
            f'{token}/{entry_b64}'
        )
        _log(f'Play <- local: {local_url}', xbmc.LOGINFO)

        li = xbmcgui.ListItem(path=local_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)

        try:
            # Mantido sem forçar inputstream.adaptive/ffmpegdirect.
            li.setMimeType('application/x-mpegURL')
        except Exception:
            pass

        xbmcplugin.setResolvedUrl(self.handle, True, li)