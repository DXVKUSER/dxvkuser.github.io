# -*- coding: utf-8 -*-
import sys
import threading
import random
import urllib.parse
import time
import os
import http.server
import socketserver
import socket
import ssl 
import warnings 

# Importações do Kodi
import xbmc
import xbmcaddon
import xbmcvfs

# --- IMPORTAÇÕES DE REDE ---
try:
    import requests
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
except ImportError:
    xbmc.log("[VOD-PROXY] Erro: Requests não instalado.", xbmc.LOGERROR)

# ---------------- CONFIGURAÇÕES OTIMIZADAS ----------------

DEFAULT_CHUNK_SIZE = 128 * 1024  # Aumentado para 128KB (Melhor performance no Linux)
MAX_RETRIES = 5
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 30.0 

# CONFIGURAÇÃO DE IP (CRÍTICO PARA LINUX/MANJARO)
BIND_HOST = '0.0.0.0'      # Escuta em todas as interfaces
ACCESS_HOST = '127.0.0.1'  # Kodi conecta via loopback IPv4
MAX_PORT_ATTEMPTS = 30

# User Agents
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
]
DEFAULT_USER_AGENT = random.choice(USER_AGENTS)

# --- REQUISITOS DO CLIENTE ---
VERIFY_SSL = False          
ALLOW_REDIRECTS = False    

# Ignora warnings de SSL
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except: pass

# ---------------- ADAPTER SSL PERSISTENTE ----------------

class SSLAdapter(HTTPAdapter):
    """
    Adapter SSL customizado para contornar verificações estritas e permitir legacy SSL.
    """
    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        try:
            ctx.options |= getattr(ssl, 'OP_LEGACY_SERVER_CONNECT')
        except AttributeError:
            pass
        kwargs['ssl_context'] = ctx
        return super().init_poolmanager(*args, **kwargs)

# ---------------- PREPARAÇÃO DA SESSÃO ----------------

def get_global_session():
    try:
        session = requests.Session()
        
        retry_strategy = Retry(
            total=MAX_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        
        adapter = SSLAdapter(max_retries=retry_strategy, pool_connections=20, pool_maxsize=20, pool_block=False)
        
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        session.headers.update({'User-Agent': DEFAULT_USER_AGENT})
        return session
        
    except Exception as e:
        xbmc.log(f"[VOD-PROXY] Falha ao criar sessão: {e}", xbmc.LOGERROR)
        return None

GLOBAL_SESSION = get_global_session()

# ---------------- LÓGICA DO PROXY ----------------

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    session = GLOBAL_SESSION
    local_ua = DEFAULT_USER_AGENT

    def log_message(self, format, *args):
        # Suprime logs padrão do HTTP Server para limpar o log do Kodi
        pass

    def do_HEAD(self):
        self._handle_request(method='HEAD')

    def do_GET(self):
        self._handle_request(method='GET')
    
    def _handle_request(self, method='GET'):
        target_url = None
        
        if self.session is None:
            self.send_error(503, "Service Unavailable")
            return

        try:
            # Parse da URL local
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            target_url = params.get('url', [None])[0]

            if not target_url:
                self.send_error(400, "URL parameter missing")
                return

            target_url = urllib.parse.unquote_plus(target_url)
            # xbmc.log(f"[VOD-PROXY] Requisitando: {target_url}", xbmc.LOGINFO)

            current_url = target_url
            max_redirects = 10
            resp = None

            # --- LOOP MANUAL DE REDIRECIONAMENTO ---
            while max_redirects > 0:
                parsed_url = urllib.parse.urlparse(current_url)
                
                request_headers = {
                    'User-Agent': self.local_ua,
                    'Accept': '*/*',
                    'Accept-Encoding': 'identity', # Importante: evita compactação dupla
                    'Referer': f"{parsed_url.scheme}://{parsed_url.netloc}/",
                    'Connection': 'keep-alive',
                    'Icy-MetaData': '1'
                }
                
                request_headers['Host'] = parsed_url.netloc
                
                # Repassa Range Header (CRÍTICO PARA SEEK NO KODI/FFMPEG)
                if 'Range' in self.headers:
                    request_headers['Range'] = self.headers['Range']

                try:
                    resp = self.session.request(
                        method, 
                        current_url, 
                        headers=request_headers, 
                        stream=True, 
                        timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), 
                        verify=VERIFY_SSL,        
                        allow_redirects=False 
                    )
                except Exception as e:
                    xbmc.log(f"[VOD-PROXY] Erro requisição: {e}", xbmc.LOGERROR)
                    self.send_error(502)
                    return

                # Verifica redirecionamento
                if resp.status_code in (301, 302, 303, 307, 308):
                    location = resp.headers.get('Location')
                    if not location:
                        resp.close()
                        return
                    
                    current_url = urllib.parse.urljoin(current_url, location)
                    resp.close()
                    max_redirects -= 1
                    continue

                if resp.status_code >= 400:
                    xbmc.log(f"[VOD-PROXY] Erro remoto: {resp.status_code}", xbmc.LOGWARNING)
                    self.send_error(resp.status_code) 
                    resp.close()
                    return
                
                break

            # --- ENVIO DA RESPOSTA ---
            self.send_response(resp.status_code)

            hop_by_hop = [
                'connection', 'keep-alive', 'proxy-authenticate', 
                'proxy-authorization', 'te', 'trailers', 
                'transfer-encoding', 'upgrade', 'content-encoding',
                'content-length' # Gerenciamos manualmente
            ]

            for k, v in resp.headers.items():
                if k.lower() not in hop_by_hop:
                    self.send_header(k, v)
                    
            if 'Content-Length' in resp.headers:
                self.send_header('Content-Length', resp.headers['Content-Length'])
            
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Connection', 'close') # Força close para evitar socket preso no Linux
            self.end_headers()

            if method == 'HEAD':
                resp.close()
                return

            # Streaming
            try:
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.wfile.write(chunk)
            except (ConnectionResetError, BrokenPipeError, socket.error):
                # Normal: Cliente parou o vídeo ou fez seek
                pass
            except Exception as e:
                xbmc.log(f"[VOD-PROXY] Erro stream: {str(e)}", xbmc.LOGERROR)
            finally:
                resp.close()

        except Exception as e:
            xbmc.log(f"[VOD-PROXY] Erro fatal: {str(e)}", xbmc.LOGERROR)
            try: self.send_error(500)
            except: pass

class VODProxyManager:
    """Gerencia o ciclo de vida do servidor proxy."""
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def start(self):
        if self._is_running: 
            return True
        
        if GLOBAL_SESSION is None:
             return False
        
        self.stop() 

        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 55000)
                # BIND EM 0.0.0.0 para resolver problema do Manjaro/Flatpak
                self.server = ThreadedTCPServer((BIND_HOST, port), VODProxyRequestHandler)
                self.server.timeout = 1
                
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                
                self.active_port = port
                self._is_running = True
                xbmc.log(f"[VOD-PROXY] Iniciado em {BIND_HOST}:{port}", xbmc.LOGINFO)
                return True
            except Exception:
                continue
        
        xbmc.log("[VOD-PROXY] Falha ao iniciar após várias tentativas.", xbmc.LOGERROR)
        return False

    def stop(self):
        self._is_running = False
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except: pass
            self.server = None
            
        self.active_port = None

# ---------------- PONTO DE ENTRADA ----------------

def resolve_vod_stream(stream_url):
    """
    Retorna a URL local do proxy e o objeto manager.
    """
    proxy_manager = VODProxyManager()
    
    if proxy_manager.start():
        if stream_url:
            # Retorna URL apontando para 127.0.0.1 (ACCESS_HOST)
            proxy_url = f"http://{ACCESS_HOST}:{proxy_manager.active_port}/?url={urllib.parse.quote_plus(stream_url)}"
            return proxy_url, proxy_manager
    
    return None, proxy_manager

# Exporta as classes e funções necessárias
__all__ = ['VODProxyManager', 'resolve_vod_stream']