# -*- coding: utf-8 -*-
import os, re, sys, time, random, socket, threading, collections
import base64
from io import StringIO
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, quote, unquote, urljoin

import xbmc, xbmcgui, xbmcplugin

# Tenta importar requests
try:
    import requests
    from requests.adapters import HTTPAdapter
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    xbmc.log("HLSProxy: Biblioteca 'requests' nao encontrada.", xbmc.LOGERROR)

# --- CONFIGURAÇÃO ---
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
]

CONFIG = {
    "BIND_HOST": "0.0.0.0",
    "ACCESS_HOST": "127.0.0.1",
    "PORT": None,
    "MAX_REDIRECTS": 7,
    "RETRY_ATTEMPTS": 5,
    "TS_CHUNK_SIZE": 32768,
    "PREFETCH_COUNT": 3
}

# Buffer em memória
segment_cache = collections.OrderedDict()
cache_lock = threading.Lock()

class PersistentSession:
    def __init__(self):
        if not HAS_REQUESTS: return
        self.session = requests.Session()
        self.session.verify = False
        adapter = HTTPAdapter(pool_connections=50, pool_maxsize=100, pool_block=False)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)
        self.headers = {
            'User-Agent': random.choice(USER_AGENTS),
            'Accept': '*/*',
            'Connection': 'keep-alive',
            'Accept-Encoding': 'identity'
        }
        self.last_base_url = None
        self.last_parent_url = None

    def fetch(self, url, referer=None, stream=False, attempt=1):
        if not HAS_REQUESTS: return None
        curr_url, curr_ref = url, referer
        
        req_headers = self.headers.copy()
        
        for _ in range(CONFIG['MAX_REDIRECTS']):
            parsed = urlparse(curr_url)
            req_headers['Host'] = parsed.netloc
            
            if curr_ref:
                req_headers['Referer'] = curr_ref
            else:
                req_headers['Referer'] = f"{parsed.scheme}://{parsed.netloc}/"

            try:
                xbmc.log(f"HLSProxy: Fetching {curr_url[:60]}... | Host: {req_headers.get('Host')}", xbmc.LOGDEBUG)
                
                resp = self.session.get(curr_url, headers=req_headers, timeout=(4, 15), stream=stream, allow_redirects=False)
                
                if resp.status_code in (301, 302, 303, 307, 308):
                    new_location = resp.headers.get('Location', '')
                    if not new_location: break
                    
                    xbmc.log(f"HLSProxy: Redirecionando -> {new_location[:60]}...", xbmc.LOGINFO)
                    
                    curr_ref = curr_url
                    curr_url = urljoin(curr_url, new_location)
                    continue
                
                if resp.status_code >= 400:
                    if attempt <= CONFIG['RETRY_ATTEMPTS']:
                        raise Exception(f"HTTP {resp.status_code}")
                    return None
                
                resp.final_url = curr_url
                return resp
            except Exception as e:
                if attempt <= CONFIG['RETRY_ATTEMPTS']:
                    xbmc.log(f"HLSProxy: Erro ({e}), tentando novamente ({attempt}/{CONFIG['RETRY_ATTEMPTS']})", xbmc.LOGWARNING)
                    time.sleep(0.3 * attempt)
                    return self.fetch(url, referer, stream, attempt + 1)
                return None
        return None

r_session = PersistentSession()

class HLSProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args): 
        pass

    def do_HEAD(self):
        try:
            parsed = urlparse(self.path)
            # Verifica os caminhos baseados em Path Parameters
            if '/playlist/' in parsed.path:
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Connection', 'keep-alive')
                self.end_headers()
            elif '/segment/' in parsed.path or '/key/' in parsed.path:
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Connection', 'keep-alive')
                self.end_headers()
            else:
                self.send_error(404)
        except Exception as e:
            xbmc.log(f"HLSProxy HEAD Error: {str(e)}", xbmc.LOGERROR)
            self.send_error(500)

    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            
            # --- LÓGICA DE PATH PARAMETERS (Sem ? e &) ---
            # Formato esperado: /playlist/BASE64.m3u8 ou /segment/BASE64.ts
            
            url = None
            parent = None
            
            # 1. Tentar extrair do PATH (Nova implementação para Manjaro)
            if '/playlist/' in parsed.path:
                # Ex: /playlist/aHR0cDovLi4u.m3u8
                b64_part = parsed.path.split('/playlist/')[-1]
                # Remove extensão falsa se existir para decodificar corretamente
                if b64_part.endswith('.m3u8'): b64_part = b64_part[:-5]
                try:
                    url = base64.b64decode(b64_part).decode('utf-8')
                    parent = r_session.last_parent_url # Usa referer padrão se não especificado
                except: pass

            elif '/segment/' in parsed.path:
                b64_part = parsed.path.split('/segment/')[-1]
                if b64_part.endswith('.ts'): b64_part = b64_part[:-3]
                try:
                    url = base64.b64decode(b64_part).decode('utf-8')
                    parent = r_session.last_parent_url
                except: pass

            elif '/key/' in parsed.path:
                b64_part = parsed.path.split('/key/')[-1]
                if b64_part.endswith('.key'): b64_part = b64_part[:-4]
                try:
                    url = base64.b64decode(b64_part).decode('utf-8')
                    parent = r_session.last_parent_url
                except: pass

            # 2. Roteamento baseado no caminho
            if url:
                if '/playlist/' in parsed.path: 
                    self.handle_m3u8(url)
                elif '/segment/' in parsed.path:
                    self.handle_stream(url, parent, False)
                elif '/key/' in parsed.path:
                    self.handle_stream(url, parent, True)
                else:
                    self.send_error(404)
            else:
                self.send_error(400, "Bad Request: Invalid Path Parameter")

        except (ConnectionResetError, BrokenPipeError):
            pass 
        except Exception as e:
            xbmc.log(f"HLSProxy Error: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
            self.send_error(500)

    def handle_m3u8(self, url):
        resp = r_session.fetch(url, stream=False)
        if not resp: return self.send_error(404)
        
        final_url = getattr(resp, 'final_url', url)
        r_session.last_base_url = final_url.rsplit('/', 1)[0] + '/'
        r_session.last_parent_url = final_url

        try:
            content = resp.content.decode('utf-8')
        except:
            content = resp.text

        lines = content.splitlines()
        output = StringIO()
        
        ts_urls = []
        local_host = f"http://{CONFIG['ACCESS_HOST']}:{CONFIG['PORT']}"

        for line in lines:
            line = line.strip()
            if not line: continue
            
            if line.startswith('#'):
                if line.startswith('#EXT-X-KEY'):
                    m = re.search(r'URI=["\']([^"\']+)["\']', line)
                    if m:
                        abs_key = urljoin(r_session.last_base_url, m.group(1))
                        b64_key = base64.b64encode(abs_key.encode('utf-8')).decode('utf-8')
                        # Reescreve para path parameter: /key/BASE64.key
                        new_uri = f'{local_host}/key/{b64_key}.key'
                        line = line.replace(m.group(1), new_uri)
                output.write(line + '\n')
            elif line == '#EXT-X-ENDLIST':
                output.write(line + '\n')
            else:
                abs_url = urljoin(r_session.last_base_url, line)
                
                if '.m3u8' in abs_url.lower() and not '/ts' in abs_url.lower():
                    # Sub-playlist
                    b64_sub = base64.b64encode(abs_url.encode('utf-8')).decode('utf-8')
                    new_line = f"{local_host}/playlist/{b64_sub}.m3u8"
                else:
                    ts_urls.append(abs_url)
                    # Segmento TS: /segment/BASE64.ts
                    b64_ts = base64.b64encode(abs_url.encode('utf-8')).decode('utf-8')
                    new_line = f"{local_host}/segment/{b64_ts}.ts"
                
                output.write(new_line + '\n')

        for ts in ts_urls[:CONFIG['PREFETCH_COUNT']]:
            threading.Thread(target=self.prefetch_segment, args=(ts, final_url)).start()

        data = output.getvalue().encode('utf-8')
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Connection', 'keep-alive')
        self.end_headers()
        self.wfile.write(data)

    def prefetch_segment(self, url, ref):
        with cache_lock:
            if url in segment_cache: return
        try:
            resp = r_session.fetch(url, referer=ref, stream=True)
            if resp:
                content = resp.content
                with cache_lock:
                    if len(segment_cache) > 20: 
                        segment_cache.popitem(last=False)
                    segment_cache[url] = content
        except: pass

    def handle_stream(self, url, ref, is_key=False):
        content = None
        with cache_lock: content = segment_cache.pop(url, None)

        if content:
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream' if is_key else 'video/mp2t')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()
            self.wfile.write(content)
            return

        resp = r_session.fetch(url, referer=ref, stream=True)
        if not resp: return self.send_error(404)
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream' if is_key else 'video/mp2t')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Accept-Ranges', 'bytes')
        self.end_headers()
        
        try:
            for chunk in resp.iter_content(chunk_size=CONFIG['TS_CHUNK_SIZE']):
                if chunk: 
                    self.wfile.write(chunk)
        except (ConnectionResetError, BrokenPipeError):
            pass
        except Exception:
            pass
        finally:
            resp.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class HLSAddon(object):
    _instance = None
    _is_running = False

    def __new__(cls, *args, **kwargs):
        if not cls._instance: cls._instance = super(HLSAddon, cls).__new__(cls)
        return cls._instance

    def __init__(self, handle=None, *args, **kwargs):
        self.handle = handle
        if not HLSAddon._is_running: self.start_server()

    def start_server(self):
        for _ in range(20):
            port = random.randint(15000, 25000)
            try:
                server = ThreadedHTTPServer((CONFIG['BIND_HOST'], port), HLSProxyHandler)
                server.timeout = 2
                
                t = threading.Thread(target=server.serve_forever, daemon=True)
                t.start()
                
                CONFIG['PORT'] = port
                HLSAddon._is_running = True
                xbmc.log(f"HLSProxy iniciado em {CONFIG['BIND_HOST']}:{port}", xbmc.LOGINFO)
                break
            except Exception as e:
                time.sleep(0.1)
                continue

    def play_stream(self, stream_url, stream_type='live', *args, **kwargs):
        if not CONFIG['PORT']: 
            xbmc.log("HLSProxy falhou ao iniciar servidor", xbmc.LOGERROR)
            return

        # --- MUDANÇA CRÍTICA: Path Parameters ---
        # Isso remove caracteres especiais que causam o erro no FFmpeg do Manjaro
        b64_url = base64.b64encode(stream_url.encode('utf-8')).decode('utf-8')
        
        # Gera URL estilo arquivo: /playlist/BASE64.m3u8
        proxy_url = f"http://{CONFIG['ACCESS_HOST']}:{CONFIG['PORT']}/playlist/{b64_url}.m3u8"
        
        li = xbmcgui.ListItem(path=proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        
        try:
            h = int(self.handle) if self.handle is not None else int(sys.argv[1])
            xbmcplugin.setResolvedUrl(h, True, li)
        except: 
            pass

proxy_addon = HLSAddon()