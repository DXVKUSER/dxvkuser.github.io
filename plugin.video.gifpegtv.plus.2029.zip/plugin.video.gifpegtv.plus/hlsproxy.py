# -*- coding: utf-8 -*-
# HLSHOST9.py - Proxy HLS Local TCP/HTTP Puro v8.7.5 (SOBREVIVÊNCIA & ANDROID FIX)
# Senior IPTV Specialist Implementation - Kodi/Android

import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import time
import random
import socket
import sys
import os
import atexit
import hashlib
import logging
from collections import OrderedDict
from requests.adapters import HTTPAdapter

# --- KODI IMPORTS & PATHS ---
try:
    import xbmc, xbmcgui, xbmcplugin, xbmcvfs
    # Define caminho de log seguro para Android
    ADDON_DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.gifpegtv.plus/")
    if not os.path.exists(ADDON_DATA): os.makedirs(ADDON_DATA)
    LOG_FILE = os.path.join(ADDON_DATA, 'hls_proxy.log')
except ImportError:
    LOG_FILE = 'hls_proxy.log'
    class Mock:
        def log(self, *a): pass
    xbmc = Mock()

# --- LOGGING CONFIG (FIXED FOR ANDROID) ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.FileHandler(LOG_FILE, encoding='utf-8'), logging.StreamHandler()]
)
logger = logging.getLogger("HLSHOST9")

# --- CONFIGURAÇÃO GLOBAL ---
CONFIG = {
    'PORT': 8010,
    'POOL_SIZE': 100,
    'MAX_RETRIES': 3,
    'TIMEOUT': 15,
    'CACHE_TTL': 7200,
    'USER_AGENTS': [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/119.0 Firefox/119.0",
        "Kodi/20.2 (Linux; Android 11) App_Version/20.2.0"
    ]
}

# --- SURVIVAL SESSION MANAGER ---
class SessionManager:
    def __init__(self):
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=CONFIG['POOL_SIZE'], pool_maxsize=CONFIG['POOL_SIZE'], max_retries=CONFIG['MAX_RETRIES'])
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        self.cache = OrderedDict()
        self._lock = threading.Lock()

    def get_headers(self, url, referer=None):
        parsed = urllib.parse.urlparse(url)
        headers = {
            'User-Agent': random.choice(CONFIG['USER_AGENTS']),
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive',
            'Host': parsed.netloc,
            'X-Forwarded-For': f"{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"
        }
        if referer: headers['Referer'] = referer
        return headers

    def invalidate(self, original_url):
        with self._lock:
            if original_url in self.cache:
                logger.warning(f"SOBREVIVÊNCIA: Invalidando cache/token para {original_url}")
                self.cache.pop(original_url, None)

    def resolve_url(self, url, force_new=False):
        if not force_new:
            with self._lock:
                entry = self.cache.get(url)
                if entry and entry['expires'] > time.time():
                    return entry['resolved']

        # Redirecionamento Manual (Bypass CDN/403/521)
        curr = url
        ref = None
        for _ in range(5):
            try:
                headers = self.get_headers(curr, ref)
                r = self.session.get(curr, headers=headers, allow_redirects=False, timeout=10)
                if r.status_code in [301, 302, 303, 307, 308]:
                    ref = curr
                    curr = urllib.parse.urljoin(curr, r.headers.get('Location'))
                    continue
                
                # Se for manifesto, valida conteúdo
                if ".m3u8" in curr.lower() and "#EXTM3U" not in r.text:
                    logger.error("FALHA: Resposta não contém #EXTM3U")
                    return None

                with self._lock:
                    self.cache[url] = {'resolved': curr, 'expires': time.time() + CONFIG['CACHE_TTL']}
                return curr
            except Exception as e:
                logger.error(f"Erro na resolução: {e}")
                break
        return curr

session_mgr = SessionManager()

# --- PROXY HANDLER ---
class HLSHostHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args): pass

    def do_GET(self):
        try:
            params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            orig_url = params.get('url', [None])[0]
            req_type = params.get('type', ['manifest'])[0]
            
            if not orig_url: return

            if req_type == 'manifest':
                self.handle_manifest(orig_url)
            elif req_type == 'segment':
                self.handle_segment(orig_url)
            elif req_type == 'key':
                self.handle_key(orig_url)
        except (ConnectionResetError, BrokenPipeError):
            pass

    def handle_manifest(self, orig_url, retry=True):
        # Prioriza URL resolvida, se falhar invalida e tenta de novo
        resolved = session_mgr.resolve_url(orig_url)
        if not resolved: return

        try:
            r = session_mgr.session.get(resolved, headers=session_mgr.get_headers(resolved), timeout=10)
            if r.status_code != 200 or "#EXTM3U" not in r.text:
                raise ValueError("Manifesto Inválido")
            
            proxy_base = f"http://{self.headers.get('Host')}/"
            lines = r.text.splitlines()
            output = []
            for line in lines:
                line = line.strip()
                if not line: continue
                
                if line.startswith('#EXT-X-KEY'):
                    uri_match = re.search(r'URI=["\'](.*?)["\']', line)
                    if uri_match:
                        uri = uri_match.group(1)
                        abs_key = urllib.parse.urljoin(resolved, uri)
                        proxy_key = f"{proxy_base}?type=key&url={urllib.parse.quote_plus(abs_key)}"
                        line = line.replace(uri, proxy_key)
                elif not line.startswith('#'):
                    abs_url = urllib.parse.urljoin(resolved, line)
                    ptype = "manifest" if ".m3u8" in line.lower() else "segment"
                    line = f"{proxy_base}?type={ptype}&url={urllib.parse.quote_plus(abs_url)}"
                output.append(line)
            
            content = "\n".join(output).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', len(content))
            self.end_headers()
            self.wfile.write(content)
            
        except Exception as e:
            logger.error(f"Erro no manifesto: {e}")
            if retry:
                session_mgr.invalidate(orig_url)
                self.handle_manifest(orig_url, retry=False)
            else:
                self.send_error(502)

    def handle_segment(self, seg_url):
        headers = session_mgr.get_headers(seg_url)
        if 'Range' in self.headers: headers['Range'] = self.headers['Range']
        
        try:
            with session_mgr.session.get(seg_url, headers=headers, stream=True, timeout=CONFIG['TIMEOUT']) as r:
                if r.status_code >= 400:
                    self.send_error(503)
                    return

                # VALIDAÇÃO DE SYNC BYTE (0x47)
                iterator = r.iter_content(chunk_size=1)
                first_byte = next(iterator, None)
                
                # Se for .ts, valida o primeiro byte
                if first_byte and (".ts" in seg_url.lower() or "segment" in seg_url.lower()):
                    if first_byte != b'\x47':
                        logger.error(f"DADO CORROMPIDO (No Sync Byte) em {seg_url}. Forçando 502.")
                        self.send_error(502) # Força o player a recarregar o manifesto
                        return

                self.send_response(r.status_code)
                for k, v in r.headers.items():
                    if k.lower() in ['content-type', 'content-length', 'content-range']:
                        self.send_header(k, v)
                self.end_headers()
                
                if first_byte: self.wfile.write(first_byte)
                for chunk in r.iter_content(chunk_size=16384):
                    if chunk: self.wfile.write(chunk)
        except Exception:
            self.send_error(503)

    def handle_key(self, key_url):
        try:
            r = session_mgr.session.get(key_url, headers=session_mgr.get_headers(key_url), timeout=10)
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.end_headers()
            self.wfile.write(r.content)
        except:
            self.send_error(404)

# --- SERVER CORE ---
class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

class HLSAddon:
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(HLSAddon, cls).__new__(cls)
            cls._instance.port = CONFIG['PORT']
            cls._instance.started = False
        return cls._instance

    def __init__(self, handle=None):
        self.handle = handle

    def start_proxy(self):
        if not self.started:
            try:
                server = ThreadedServer(('127.0.0.1', self.port), HLSHostHandler)
                t = threading.Thread(target=server.serve_forever, daemon=True)
                t.start()
                self.started = True
                logger.info(f"Proxy v8.7.5 Online na porta {self.port}")
            except Exception as e:
                logger.error(f"Falha ao iniciar servidor: {e}")

    def play_stream(self, stream_url, stream_type='live'):
        self.start_proxy()
        proxy_url = f"http://127.0.0.1:{self.port}/?type=manifest&url={urllib.parse.quote_plus(stream_url)}"
        
        # O handle vem do sys.argv[1] no Kodi
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        
        listitem = xbmcgui.ListItem(path=proxy_url)
        listitem.setProperty('IsPlayable', 'true')
        
        if stream_type == 'live':
            listitem.setProperty('IsLiveStream', 'true')
        
        xbmcplugin.setResolvedUrl(handle, True, listitem)
        return True