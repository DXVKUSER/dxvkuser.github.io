import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import os
import re
import socket
from functools import lru_cache
from collections import defaultdict
from typing import Optional, Dict, Tuple, List

# --- Configurações Globais ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE = int(sys.argv[1])

# Configurações de proxy dinâmico
DEFAULT_PROXY_PORT = 65323  # 0 = sistema escolhe porta livre
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 5  # Número máximo de tentativas para encontrar porta livre

# Configurações de desempenho
CHUNK_SIZE = 8192 * 4  # Aumentado para melhor throughput
CONNECTION_TIMEOUT = 15  # segundos
STREAM_TIMEOUT = 30  # segundos
MAX_CACHE_SIZE = 100  # Itens no cache LRU

# Sessão HTTP otimizada
HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate',
    'Connection': 'keep-alive'
})

# Configurações avançadas de adaptação
ADAPTIVE_STREAMING = True  # Habilita ajuste dinâmico de qualidade
MIN_BITRATE = 500000  # 500 kbps (para o monitor de banda interno)
MAX_BITRATE = 8000000  # 8 Mbps (para o monitor de banda interno)
BANDWIDTH_MONITOR_WINDOW = 10  # Número de segmentos para calcular média de banda

# --- Sistema de Log Melhorado ---
class KodiLogger:
    @staticmethod
    def log(msg: str, level: int = xbmc.LOGINFO):
        """Log formatado com nome do addon e níveis personalizados"""
        level_map = {
            'DEBUG': xbmc.LOGDEBUG,
            'INFO': xbmc.LOGINFO,
            'WARNING': xbmc.LOGWARNING,
            'ERROR': xbmc.LOGERROR,
            'FATAL': xbmc.LOGFATAL
        }
        if isinstance(level, str):
            level = level_map.get(level.upper(), xbmc.LOGINFO)
        xbmc.log(f"[{ADDON_NAME}] {msg}", level)

    @staticmethod
    def debug(msg: str):
        KodiLogger.log(msg, xbmc.LOGDEBUG)

    @staticmethod
    def info(msg: str):
        KodiLogger.log(msg, xbmc.LOGINFO)

    @staticmethod
    def warning(msg: str):
        KodiLogger.log(msg, xbmc.LOGWARNING)

    @staticmethod
    def error(msg: str):
        KodiLogger.log(msg, xbmc.LOGERROR)

log = KodiLogger.log
debug = KodiLogger.debug
info = KodiLogger.info
warning = KodiLogger.warning
error = KodiLogger.error

# --- Monitor de Banda Larga Inteligente ---
class BandwidthMonitor:
    def __init__(self, window_size: int = BANDWIDTH_MONITOR_WINDOW):
        self.window_size = window_size
        self.samples = []
        self.timestamps = []
        
    def add_sample(self, bytes_transferred: int):
        """Adiciona uma amostra de transferência"""
        now = time.time()
        self.samples.append(bytes_transferred)
        self.timestamps.append(now)
        
        # Manter apenas as amostras mais recentes dentro da janela
        if len(self.samples) > self.window_size:
            self.samples.pop(0)
            self.timestamps.pop(0)
    
    def get_bandwidth(self) -> float:
        """Calcula a banda disponível em bps"""
        if len(self.samples) < 2:
            return 0
            
        total_bytes = sum(self.samples)
        time_span = self.timestamps[-1] - self.timestamps[0]
        
        if time_span <= 0:
            return 0
            
        return (total_bytes * 8) / time_span  # bits por segundo

# --- Cache Inteligente para Manifestos e Segmentos ---
class StreamCache:
    def __init__(self, max_size: int = MAX_CACHE_SIZE):
        self.max_size = max_size
        self.manifest_cache = {}
        self.segment_cache = {}
        self.access_times = {}
        self.current_size = 0
        
    def get_manifest(self, url: str) -> Optional[str]:
        """Obtém um manifesto do cache se existir e não estiver expirado"""
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            self.access_times[url] = time.time()
            return entry['content']
        return None
        
    def add_manifest(self, url: str, content: str, ttl: int = 10):
        """Adiciona um manifesto ao cache com TTL"""
        if len(self.manifest_cache) >= self.max_size:
            self._evict_oldest()
            
        self.manifest_cache[url] = {
            'content': content,
            'expires': time.time() + ttl
        }
        self.access_times[url] = time.time()
        
    def get_segment(self, url: str) -> Optional[bytes]:
        """Obtém um segmento do cache"""
        if url in self.segment_cache:
            self.access_times[url] = time.time()
            return self.segment_cache[url]
        return None
        
    def add_segment(self, url: str, data: bytes):
        """Adiciona um segmento ao cache"""
        if len(self.segment_cache) >= self.max_size:
            self._evict_oldest()
            
        self.segment_cache[url] = data
        self.access_times[url] = time.time()
        self.current_size += len(data)
        
    def _evict_oldest(self):
        """Remove os itens mais antigos do cache"""
        if not self.access_times:
            return
            
        oldest_url = min(self.access_times, key=self.access_times.get)
        if oldest_url in self.manifest_cache:
            del self.manifest_cache[oldest_url]
        if oldest_url in self.segment_cache:
            self.current_size -= len(self.segment_cache[oldest_url])
            del self.segment_cache[oldest_url]
        del self.access_times[oldest_url]

# --- Manipulador de Proxy Avançado ---
class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.cache = StreamCache()
        self.bw_monitor = BandwidthMonitor()
        self.adaptive_streaming = ADAPTIVE_STREAMING
        super().__init__(*args, **kwargs)
    
    def log_message(self, format, *args):
        """Suprime logs padrão do HTTP server"""
        pass
    
    def do_GET(self):
        """Manipula requisições GET com tratamento avançado"""
        start_time = time.time()
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            original_url = urllib.parse.unquote_plus(parsed_path.path.lstrip('/'))
            
            debug(f"Requisição recebida para: {original_url}")
            
            if ".m3u8" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
                
        except Exception as e:
            error(f"Erro ao processar requisição: {e}")
            self.send_error(500, f"Internal Server Error: {str(e)}")
        finally:
            debug(f"Tempo de processamento: {(time.time() - start_time):.2f}s")
    
    def _handle_manifest(self, url: str):
        """Processa manifestos M3U8 com reescrita inteligente de URLs"""
        cached = self.cache.get_manifest(url)
        if cached:
            debug(f"Retornando manifesto do cache: {url}")
            self._send_response(200, cached, 'application/vnd.apple.mpegurl')
            return
            
        try:
            response = self._fetch_url(url, stream=False)
            if not response:
                self.send_error(502, "Bad Gateway")
                return
                
            parsed_m3u8 = m3u8.loads(response.text, uri=url)
            
            # Ajuste dinâmico de qualidade baseado na banda disponível
            if self.adaptive_streaming and parsed_m3u8.playlists:
                bandwidth = self.bw_monitor.get_bandwidth()
                if bandwidth > 0:
                    self._adjust_quality(parsed_m3u8, bandwidth)
            
            # Reescreve URLs para apontar para o proxy
            actual_port = self.server.server_address[1]
            base_proxy_url = f"http://{PROXY_HOST}:{actual_port}/"
            
            for playlist in parsed_m3u8.playlists:
                playlist.uri = base_proxy_url + urllib.parse.quote_plus(playlist.absolute_uri)
                
            for segment in parsed_m3u8.segments:
                segment.uri = base_proxy_url + urllib.parse.quote_plus(segment.absolute_uri)
                
            rewritten = parsed_m3u8.dumps()
            self.cache.add_manifest(url, rewritten)
            
            self._send_response(200, rewritten, 'application/vnd.apple.mpegurl')
            
        except Exception as e:
            error(f"Erro ao processar manifesto: {url} - {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
    
    def _handle_segment(self, url: str):
        """Processa segmentos de mídia com cache e monitoramento de banda"""
        cached = self.cache.get_segment(url)
        if cached:
            debug(f"Retornando segmento do cache: {url}")
            self._send_response(200, cached, 'video/MP2T')
            return
            
        try:
            response = self._fetch_url(url, stream=True)
            if not response:
                self.send_error(502, "Bad Gateway")
                return
                
            content_length = int(response.headers.get('Content-Length', 0))
            data = bytearray()
            
            self.send_response(200)
            self._copy_headers(response)
            self.end_headers()
            
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    break
                data.extend(chunk)
                self.wfile.write(chunk)
                
            # Atualiza monitor de banda e cache
            if content_length > 0 or data:
                actual_size = len(data) if data else content_length
                self.bw_monitor.add_sample(actual_size)
                
                if data and actual_size <= 5 * 1024 * 1024:  # Cache até 5MB
                    self.cache.add_segment(url, bytes(data))
                    
        except Exception as e:
            error(f"Erro ao processar segmento: {url} - {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
    
    def _adjust_quality(self, m3u8_obj: m3u8.M3U8, bandwidth: float):
        """Seleciona a melhor qualidade baseado na banda disponível"""
        available_bandwidth = min(max(bandwidth, MIN_BITRATE), MAX_BITRATE)
        debug(f"Banda disponível: {bandwidth/1e6:.2f} Mbps")
        
        best_playlist = None
        closest_diff = float('inf')
        
        for playlist in m3u8_obj.playlists:
            playlist_bandwidth = playlist.stream_info.bandwidth
            diff = abs(playlist_bandwidth - available_bandwidth)
            
            # Prioriza playlists que estão dentro da banda disponível ou ligeiramente acima (1.2x)
            if playlist_bandwidth <= available_bandwidth * 1.2:
                if best_playlist is None or diff < closest_diff:
                    closest_diff = diff
                    best_playlist = playlist
                
        if best_playlist:
            # Reordena playlists para colocar a melhor opção primeiro
            # Isso pode influenciar a forma como o player escolhe o stream inicial,
            # embora o inputstream.ffmpegdirect também faça sua própria seleção.
            m3u8_obj.playlists.sort(
                key=lambda p: abs(p.stream_info.bandwidth - best_playlist.stream_info.bandwidth)
            )
            info(f"Qualidade ajustada para: {best_playlist.stream_info.bandwidth/1e6:.2f} Mbps")
    
    def _fetch_url(self, url: str, stream: bool = False) -> Optional[requests.Response]:
        """Busca uma URL com tratamento de erros robusto"""
        try:
            # Adicionando o cabeçalho 'Referer' para a requisição externa.
            # É importante que o 'Referer' reflita o domínio do stream original, não do proxy.
            parsed_original_url = urllib.parse.urlparse(url)
            headers = HTTP_SESSION.headers.copy()
            headers['Referer'] = f"{parsed_original_url.scheme}://{parsed_original_url.netloc}"

            response = HTTP_SESSION.get(
                url,
                stream=stream,
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                headers=headers # Usando os headers atualizados
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            error(f"Erro ao buscar URL {url}: {e}")
            return None
    
    def _send_response(self, code: int, content: str, content_type: str):
        """Envia uma resposta HTTP com headers apropriados"""
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(encoded)))
        self.send_header('Cache-Control', 'max-age=10')
        self.end_headers()
        self.wfile.write(encoded)
    
    def _copy_headers(self, response: requests.Response):
        """Copia headers da resposta original, filtrando os problemáticos"""
        for header, value in response.headers.items():
            header_lower = header.lower()
            if header_lower not in {'transfer-encoding', 'connection', 'content-encoding'}:
                self.send_header(header, value)

# --- Gerenciador de Proxy Avançado ---
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.ready_event = threading.Event()
        self.active_port = None
        
    def start(self) -> Optional[int]:
        """Inicia o servidor proxy em uma porta disponível"""
        global DEFAULT_PROXY_PORT
        
        self.stop()  # Garante que não há servidores ativos
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            port_to_try = DEFAULT_PROXY_PORT if attempt == 0 else 0
            server_address = (PROXY_HOST, port_to_try)
            
            try:
                self.server = socketserver.TCPServer(
                    server_address,
                    AdvancedHLSProxyHandler,
                    bind_and_activate=False
                )
                self.server.allow_reuse_address = True
                self.server.server_bind()
                self.server.server_activate()
                
                self.active_port = self.server.server_address[1]
                info(f"Servidor proxy iniciado em http://{PROXY_HOST}:{self.active_port}")
                
                self.server_thread = threading.Thread(
                    target=self.server.serve_forever,
                    daemon=True
                )
                self.server_thread.start()
                
                self.ready_event.set()
                return self.active_port
                
            except OSError as e:
                if "Address already in use" in str(e):
                    warning(f"Porta {port_to_try} em uso, tentando outra...")
                    # Se a porta padrão estiver em uso, a próxima tentativa será com porta 0 (aleatória)
                    if port_to_try == DEFAULT_PROXY_PORT and DEFAULT_PROXY_PORT != 0:
                        DEFAULT_PROXY_PORT = 0 # Define a global para 0 para futuras tentativas, se necessário
                    continue
                error(f"Erro ao iniciar servidor proxy: {e}")
                break
            except Exception as e:
                error(f"Erro inesperado ao iniciar proxy: {e}")
                break
                
        self.ready_event.set()  # Libera event mesmo em caso de falha
        return None
    
    def stop(self):
        """Para o servidor proxy e limpa recursos"""
        if self.server:
            info("Parando servidor proxy...")
            try:
                self.server.shutdown()
                self.server.server_close()
                info("Servidor proxy parado.")
            except Exception as e:
                error(f"Erro ao parar o servidor proxy: {e}")
            finally:
                self.server = None
            
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=5)
            if self.server_thread.is_alive():
                warning("Thread do proxy não finalizou a tempo")
                
        self.active_port = None
        self.ready_event.clear()
    
    def get_proxy_url(self, original_url: str) -> Optional[str]:
        """Gera a URL do proxy para a URL original"""
        if not self.active_port:
            return None
        return f"http://{PROXY_HOST}:{self.active_port}/{urllib.parse.quote_plus(original_url)}"
    
    def wait_until_ready(self, timeout: float = 15) -> bool:
        """Aguarda até que o proxy esteja pronto"""
        return self.ready_event.wait(timeout)

# --- Interface do Addon ---
class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.player = xbmc.Player()
        self.playback_monitor_thread = None
    
    def play_stream(self, url: str):
        """Prepara e inicia a reprodução de um stream HLS ou MP2T"""
        info(f"Iniciando reprodução para: {url}")
        
        # Inicia o proxy
        port = self.proxy_manager.start()
        if not port:
            xbmcgui.Dialog().notification(ADDON_NAME, "Falha ao iniciar proxy", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
            
        # Aguarda o proxy ficar pronto
        if not self.proxy_manager.wait_until_ready():
            xbmcgui.Dialog().notification(ADDON_NAME, "Proxy não iniciou a tempo", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            self.proxy_manager.stop()
            return
            
        # Prepara o item para reprodução
        proxy_url = self.proxy_manager.get_proxy_url(url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            self.proxy_manager.stop()
            return
            
        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')

        # Determina o tipo de manifesto e MIME Type
        if '.m3u8' in url.lower():
            list_item.setContentLookup(False)
            list_item.setMimeType('application/vnd.apple.mpegurl')
            list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'application/vnd.apple.mpegurl')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        else:
            list_item.setContentLookup(False)
            list_item.setMimeType('video/mp2t')
            list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp2t')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'none') # Não é um manifesto para mp2t direto

        list_item.setProperty('ForceResolvePlugin','false')

        # Propriedades adicionais do inputstream.ffmpegdirect para ambos os tipos de stream
        parsed_original_url = urllib.parse.urlparse(url)
        list_item.setProperty('inputstream.ffmpegdirect.stream_headers', f"Referer={parsed_original_url.scheme}://{parsed_original_url.netloc}")
        list_item.setProperty('inputstream.ffmpegdirect.hls_segment_duration_limit', '60')
        list_item.setProperty('inputstream.ffmpegdirect.hls_min_buffer_duration', '3')
        list_item.setProperty('inputstream.ffmpegdirect.hls_max_bitrate', str(MAX_BITRATE))
        list_item.setProperty('inputstream.ffmpegdirect.hls_allow_partial_segments', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.http_connect_timeout', str(CONNECTION_TIMEOUT))
        list_item.setProperty('inputstream.ffmpegdirect.http_read_timeout', str(STREAM_TIMEOUT))
        list_item.setProperty('inputstream.ffmpegdirect.reconnect_on_error', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.live_threshold', '10')
        list_item.setProperty('inputstream.ffmpegdirect.fast_seek', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.seek_method', 'byte')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_update_parameter', 'full')

        # Propriedades de catchup/tempo
        list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'catchup')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'catchup')
        list_item.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
        list_item.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
        list_item.setProperty('inputstream.ffmpegdirect.default_url',url)
        list_item.setProperty('inputstream.ffmpegdirect.catchup_url_format_string',url)
        list_item.setProperty('inputstream.ffmpegdirect.programme_start_time','1')
        list_item.setProperty('inputstream.ffmpegdirect.programme_end_time','19')
        list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time','1')
        list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset','1')
        list_item.setProperty('inputstream.ffmpegdirect.default_programme_duration','19')

        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        
        self._start_playback_monitor()
        
        if self.playback_monitor_thread:
            self.playback_monitor_thread.join()
            info("Monitor de reprodução finalizado.")
        else:
            warning("Monitor de reprodução não foi iniciado corretamente.")


    def _start_playback_monitor(self):
        """Inicia uma thread para monitorar a reprodução e limpar o proxy quando terminar"""
        if self.playback_monitor_thread and self.playback_monitor_thread.is_alive():
            return

        def monitor():
            info("Iniciando monitor de reprodução...")
            
            # Aguarda até 45 segundos para a reprodução começar
            start_time = time.time()
            is_playing_after_wait = False
            while time.time() - start_time < 45:
                if self.player.isPlaying():
                    is_playing_after_wait = True
                    break
                time.sleep(0.5)
            
            if not is_playing_after_wait:
                warning("Reprodução não iniciada dentro do tempo limite ou falha do player. Parando proxy.")
                self.proxy_manager.stop()
                return
            
            info("Reprodução iniciada. Monitorando...")
            # Monitora enquanto estiver reproduzindo
            while self.player.isPlaying():
                time.sleep(1)
                
            info("Reprodução terminada ou parada. Parando proxy...")
            self.proxy_manager.stop()
            
        self.playback_monitor_thread = threading.Thread(target=monitor, daemon=True)
        self.playback_monitor_thread.start()
    
    def show_test_streams(self):
        """Mostra uma lista de streams de teste para demonstração"""
        test_streams = [
            ("Live Stream Exemplo 1 (M3U8)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Live Stream Exemplo 2 (MP2T)", "http://tvhdbalck.pro:80/live/6464779/0577073/329.ts"), # Exemplo de MP2T
            ("VOD Apple Sample (Estável M3U8)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8"),
            ("Big Buck Bunny (Demo M3U8)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8")
        ]
        
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=name)
            li.setProperty('IsPlayable', 'true')
            li.setInfo('video', {'title': name})
            
            # Set initial MIME type based on URL extension
            if '.m3u8' in url.lower():
                li.setMimeType('application/vnd.apple.mpegurl')
            elif '.ts' in url.lower():
                li.setMimeType('video/mp2t')
            else:
                li.setMimeType('video/x-mpegurl') # Generic for other potential streams
            
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            
        xbmcplugin.endOfDirectory(HANDLE)

# --- Ponto de Entrada do Addon ---
if __name__ == '__main__':
    addon_instance = HLSProxyAddon()
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url = params.get('url')

    if action == 'play' and url:
        info(f"Ação 'play' recebida para URL: {url}")
        addon_instance.play_stream(url)
    else:
        info("Exibindo lista de streams de teste.")
        addon_instance.show_test_streams()