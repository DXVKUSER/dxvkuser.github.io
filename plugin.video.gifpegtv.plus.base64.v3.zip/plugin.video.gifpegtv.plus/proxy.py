# proxy_improved.py
# Versão completa — usa apenas bibliotecas já presentes no seu proxy.py original.
# Melhorias: sessões reutilizáveis, retry, semaphore para concorrência, cache rotativo,
# health/metrics, tratamento de sinais, logging rotativo e rewriting de playlists m3u8.

from __future__ import annotations

import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
from collections import OrderedDict
from typing import Optional, Dict, Tuple
import warnings
import socket
import base64
import re
import hashlib
import hmac
import signal

# Requests / HTTP helpers (estavam no seu arquivo original)
try:
    # se houver doh_client wrapper no ambiente (algumas builds), use-o
    from doh_client import requests  # type: ignore
except Exception:
    import requests  # type: ignore

import requests.exceptions  # type: ignore
from requests.adapters import HTTPAdapter  # type: ignore
from urllib3.util.retry import Retry  # type: ignore

# m3u8 parsing & Flask server (estavam no seu arquivo original)
import m3u8  # type: ignore
from werkzeug.serving import make_server  # type: ignore
from flask import Flask, request, Response, stream_with_context, jsonify  # type: ignore

# ----------------------------- CONFIGURAÇÃO -----------------------------
MAX_SEGMENT_RETRIES = 5
RETRY_BACKOFF_FACTOR = 0.6
MAX_BACKOFF_TIME = 10.0
CONNECTION_TIMEOUT = 5.0
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 64 * 1024
MAX_CACHE_MB = 128
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
PROXY_HOST = "127.0.0.1"
MAX_PORT_ATTEMPTS = 20
SESSION_MAX_AGE = 60
MAX_URL_DECODE_LENGTH = 2000
MAX_CACHE_ITEM_BYTES = 5 * 1024 * 1024  # não cachear itens > 5MB
MAX_CONCURRENT_SEGMENTS = 40
LOG_FILE = "hlsproxy_improved.log"
OBFUSCATION_KEY = "IPTV_PROXY_SECRET_2024"
OBFUSCATION_LAYERS = 2

USER_AGENTS = [
    "VLC/3.0.20 LibVLC/3.0.20 (X11; Linux x86_64)",
    "ExoPlayer/2.18.7 (Linux; Android 13)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)",
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ----------------------------- LOGGING ---------------------------------


def setup_logging():
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s")
    handler.setFormatter(formatter)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    # evitar múltiplas handlers se já tiver rodando
    if not any(isinstance(h, logging.handlers.RotatingFileHandler) and getattr(h, "baseFilename", "") == handler.baseFilename for h in root.handlers):
        root.addHandler(handler)
    # Stream handler para stdout
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(formatter)
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        root.addHandler(sh)


# ----------------------------- UTILITÁRIOS -------------------------------


def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")):
        return "application/vnd.apple.mpegurl"
    if path.endswith(".ts") or "stream" in path:
        return "video/mp2t"
    if path.endswith(".aac"):
        return "audio/aac"
    if path.endswith(".mp4"):
        return "video/mp4"
    return "application/octet-stream"


# ----------------------------- OFUSCAÇÃO --------------------------------


def safe_base64_encode(data: str) -> str:
    return base64.b64encode(data.encode("utf-8")).decode("utf-8")


def safe_base64_decode(encoded_data: str) -> str:
    try:
        return base64.b64decode(encoded_data.encode("utf-8")).decode("utf-8")
    except Exception:
        try:
            return base64.b64decode(encoded_data.encode("utf-8")).decode("utf-8", errors="replace")
        except Exception:
            return ""


def multi_layer_encode(data: str, layers: int = OBFUSCATION_LAYERS) -> str:
    encoded = data.encode("utf-8")
    for _ in range(layers):
        encoded = base64.b64encode(encoded)
    return encoded.decode("utf-8")


def multi_layer_decode(encoded_data: str, layers: int = OBFUSCATION_LAYERS) -> str:
    try:
        decoded = encoded_data.encode("utf-8")
        for _ in range(layers):
            decoded = base64.b64decode(decoded)
        return decoded.decode("utf-8")
    except Exception:
        return safe_base64_decode(encoded_data)


def custom_xor_encode(data: str, key: str = OBFUSCATION_KEY) -> str:
    encoded_chars = []
    for i in range(len(data)):
        key_c = key[i % len(key)]
        encoded_chars.append(chr(ord(data[i]) ^ ord(key_c)))
    return safe_base64_encode("".join(encoded_chars))


def custom_xor_decode(encoded_data: str, key: str = OBFUSCATION_KEY) -> str:
    try:
        decoded_str = safe_base64_decode(encoded_data)
        decoded_chars = []
        for i in range(len(decoded_str)):
            key_c = key[i % len(key)]
            decoded_chars.append(chr(ord(decoded_str[i]) ^ ord(key_c)))
        return "".join(decoded_chars)
    except Exception:
        return safe_base64_decode(encoded_data)


def advanced_encode(data: str) -> str:
    try:
        return multi_layer_encode(custom_xor_encode(data))
    except Exception:
        return safe_base64_encode(data)


def advanced_decode(encoded_data: str) -> str:
    if not encoded_data:
        return ""
    if len(encoded_data) > MAX_URL_DECODE_LENGTH:
        logging.warning("Encoded URL too long, rejecting to avoid abuse")
        return ""
    try:
        layer_decoded = multi_layer_decode(encoded_data)
        return custom_xor_decode(layer_decoded)
    except Exception:
        return safe_base64_decode(encoded_data)


# ----------------------------- CACHE ------------------------------------


class RotatingCache:
    """Cache LRU simples com limite total de bytes e TTL por item."""

    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.store: "OrderedDict[str, Tuple[bytes, Optional[float]]]" = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            item = self.store.get(url)
            if not item:
                return None
            data, expire = item
            if expire and expire < time.time():
                self._pop(url)
                return None
            # move to end (most-recent)
            self.store.move_to_end(url)
            return data

    def add(self, url: str, data: bytes, ttl: int):
        size = len(data)
        if size > self.max_bytes:
            return
        if size > MAX_CACHE_ITEM_BYTES:
            return
        with self.lock:
            if url in self.store:
                self._pop(url)
            while self.total_bytes + size > self.max_bytes:
                self._popitem(last=False)
            expire = time.time() + ttl if ttl else None
            self.store[url] = (data, expire)
            self.total_bytes += size

    def _pop(self, url: str):
        if url in self.store:
            data, _ = self.store.pop(url)
            self.total_bytes -= len(data)

    def _popitem(self, last: bool):
        try:
            _, (data, _) = self.store.popitem(last=last)
            self.total_bytes -= len(data)
        except KeyError:
            pass

    def clear(self):
        with self.lock:
            self.store.clear()
            self.total_bytes = 0


# ------------------ Gerenciador do Proxy HLS (melhorado) -----------------


class IPTVHLSProxyManager:
    def __init__(self):
        self.cache = RotatingCache()
        self.active_port: Optional[int] = None
        self.server = None
        self.server_thread: Optional[threading.Thread] = None
        self.lock = threading.Lock()
        self.thread_local = threading.local()
        self.user_agent = random.choice(USER_AGENTS)
        self.fake_ip = self._random_fake_ip()
        self.app = self._create_flask_app()
        self.shutdown_event = threading.Event()
        self.concurrent_semaphore = threading.Semaphore(MAX_CONCURRENT_SEGMENTS)
        self.metrics = {
            "requests_total": 0,
            "segment_errors": 0,
            "manifest_errors": 0,
            "active_streams": 0,
        }

    def _random_fake_ip(self) -> str:
        return f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,255)}"

    def _get_session(self) -> requests.Session:
        tl = getattr(self.thread_local, "session_info", None)
        now = time.time()
        if not tl or now - tl["created"] > SESSION_MAX_AGE:
            session = requests.Session()
            retry_strategy = Retry(
                total=MAX_SEGMENT_RETRIES,
                backoff_factor=RETRY_BACKOFF_FACTOR,
                status_forcelist=[429, 500, 502, 503, 504],
                allowed_methods=["HEAD", "GET", "OPTIONS"],
                raise_on_status=False,
            )
            adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=100, pool_maxsize=100)
            session.mount("http://", adapter)
            session.mount("https://", adapter)
            self.thread_local.session_info = {"session": session, "created": now}
            return session
        return tl["session"]

    def _randomize_headers(self):
        self.user_agent = random.choice(USER_AGENTS)
        self.fake_ip = self._random_fake_ip()

    def force_reconnect(self, reason: str = "Unknown"):
        with self.lock:
            logging.info(f"Forçando RECONEXÃO ({reason}). Descartando sessão antiga e cache.")
            self.cache.clear()
            try:
                del self.thread_local.session_info
            except Exception:
                pass
            self._randomize_headers()

    def get_headers(self, url: str, original_url: Optional[str] = None, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        parsed_url = urllib.parse.urlparse(url)
        original_host = urllib.parse.urlparse(original_url).netloc if original_url else parsed_url.netloc
        timestamp = str(int(time.time()))
        signature = self.create_signature(url, timestamp)

        headers = {
            "Host": parsed_url.netloc,
            "User-Agent": self.user_agent,
            "Accept": "application/vnd.apple.mpegurl, */*",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Referer": f"http://{original_host}/",
            "Origin": f"http://{original_host}",
            "Pragma": "no-cache",
            "Cache-Control": "no-cache",
            "X-Forwarded-For": self.fake_ip,
            "X-Timestamp": timestamp,
            "X-Signature": signature,
        }
        if extra:
            headers.update(extra)
        return headers

    def create_signature(self, url: str, timestamp: str) -> str:
        signature_data = f"{url}{timestamp}{OBFUSCATION_KEY}".encode("utf-8")
        return hmac.new(OBFUSCATION_KEY.encode("utf-8"), signature_data, hashlib.sha256).hexdigest()

    def _create_flask_app(self) -> Flask:
        app = Flask("IPTVHLSProxyImproved")

        @app.route("/", methods=["GET"])
        def proxy():
            self.metrics["requests_total"] += 1
            url_param = request.args.get("url")
            original_url_param = request.args.get("original_url")

            if not url_param:
                return Response("Missing 'url' parameter", 400)

            decoded_url = advanced_decode(url_param)
            if original_url_param:
                decoded_original_url = advanced_decode(original_url_param)
            else:
                decoded_original_url = decoded_url

            if not decoded_url or not decoded_url.startswith(("http://", "https://")):
                logging.error(f"URL decodificada inválida: {decoded_url}")
                return Response("Invalid decoded URL", 400)

            if decoded_url.endswith((".m3u8", ".m3u")):
                return self.handle_manifest(decoded_url, decoded_original_url)
            return self.handle_segment_stream(decoded_url, decoded_original_url)

        @app.route("/health", methods=["GET"])
        def health():
            return jsonify(
                {
                    "status": "ok",
                    "active_port": self.active_port,
                    "cache_bytes": self.cache.total_bytes,
                }
            )

        @app.route("/metrics", methods=["GET"])
        def metrics():
            return jsonify(self.metrics)

        return app

    def _make_request(self, url: str, method: str = "GET", original_url: Optional[str] = None, headers=None, stream: bool = False, timeout: Tuple[float, float] = (CONNECTION_TIMEOUT, STREAM_TIMEOUT), **kwargs):
        self._randomize_headers()
        session = self._get_session()
        req_headers = self.get_headers(url, original_url, extra=headers)
        kwargs.setdefault("allow_redirects", False)
        try:
            r = session.request(method, url, headers=req_headers, stream=stream, timeout=timeout, **kwargs)
            # Tratar redirecionamentos manualmente
            if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get("Location")
                if location:
                    new_url = urllib.parse.urljoin(url, location)
                    logging.info(f"Redirecionamento interceptado: {url} -> {new_url}")
                    r.close()
                    return self._make_request(new_url, method, original_url, headers, stream=stream, timeout=timeout, **kwargs)
            return r
        except requests.exceptions.RequestException as e:
            logging.debug(f"Request exception para {url}: {e}")
            raise

    def handle_manifest(self, url: str, original_url: str, retries: int = 0) -> Response:
        cached = self.cache.get(url)
        if cached and retries == 0:
            logging.info(f"Manifesto de {url} servido do cache.")
            return Response(cached, mimetype="application/vnd.apple.mpegurl")

        try:
            r = self._make_request(url, method="GET", original_url=original_url, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT))
            r.raise_for_status()
            content = r.text
            final_url = r.url
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 403:
                logging.error(f"Erro ao carregar manifesto {url}: {e}")
                if retries < 3:
                    logging.info(f"Tentativa de reconexão com novo IP/UA... Tentativa {retries + 1}/3")
                    self.force_reconnect(reason=f"Falha manifesto principal: {e}")
                    return self.handle_manifest(url, original_url, retries + 1)
                else:
                    logging.critical(f"Falha persistente após {retries} tentativas para o manifesto: {url}")
                    return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")
            else:
                logging.error(f"Erro ao carregar manifesto {url}: {e}", exc_info=True)
                self.metrics["manifest_errors"] += 1
                self.force_reconnect(reason=f"Falha manifesto principal: {e}")
                return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")
        except Exception as e:
            logging.error(f"Erro inesperado ao carregar manifesto {url}: {e}", exc_info=True)
            self.metrics["manifest_errors"] += 1
            self.force_reconnect(reason=f"Falha inesperada no manifesto: {e}")
            return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")

        try:
            proxy_base_url = f"http://{PROXY_HOST}:{self.active_port}/?url="
            encoded_original = advanced_encode(original_url)

            m3u8_obj = m3u8.loads(content, uri=final_url)
            is_live = not m3u8_obj.is_endlist

            if m3u8_obj.is_variant:
                for playlist in m3u8_obj.playlists:
                    encoded_uri = advanced_encode(playlist.absolute_uri)
                    playlist.uri = proxy_base_url + urllib.parse.quote_plus(encoded_uri) + "&original_url=" + urllib.parse.quote_plus(encoded_original)

            for segment in m3u8_obj.segments:
                encoded_uri = advanced_encode(segment.absolute_uri)
                segment.uri = proxy_base_url + urllib.parse.quote_plus(encoded_uri) + "&original_url=" + urllib.parse.quote_plus(encoded_original)
                if segment.key and segment.key.uri:
                    encoded_key = advanced_encode(segment.key.absolute_uri)
                    segment.key.uri = proxy_base_url + urllib.parse.quote_plus(encoded_key) + "&original_url=" + urllib.parse.quote_plus(encoded_original)

            proxied_playlist = m3u8_obj.dumps().encode("utf-8")
            ttl = 3 if is_live else 300
            self.cache.add(url, proxied_playlist, ttl)

            response = Response(proxied_playlist, mimetype="application/vnd.apple.mpegurl")
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
            return response
        except Exception as e:
            logging.error(f"Erro ao reescrever manifesto: {e}", exc_info=True)
            return Response("#EXTM3U\n#EXT-X-ERROR: Playlist processing error\n", status=500, mimetype="application/vnd.apple.mpegurl")

    def handle_segment_stream(self, url: str, original_url: str) -> Response:
        acquired = self.concurrent_semaphore.acquire(blocking=False)
        if not acquired:
            logging.warning("Limite de segmentos concorrentes atingido. Rejeitando nova requisição.")
            return Response("Too Many Requests", status=429)

        def generate():
            try:
                self.metrics["active_streams"] += 1
                for attempt in range(1, MAX_SEGMENT_RETRIES + 1):
                    try:
                        r = self._make_request(url, method="GET", stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), original_url=original_url)
                        r.raise_for_status()
                        logging.info(f"Stream do segmento {url.split('/')[-1]} iniciado com sucesso na tentativa {attempt}.")

                        for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            if chunk:
                                yield chunk
                        r.close()
                        return
                    except requests.exceptions.RequestException as e:
                        logging.warning(f"Falha ao buscar segmento {url} na tentativa {attempt}: {e}")
                        if attempt == MAX_SEGMENT_RETRIES:
                            logging.error(f"Falha persistente de segmento: {url}")
                            # Não forçar reconexão aqui para não interromper a reprodução de outros segmentos.
                            # O player tentará buscar novamente, ou a falha indicará que o stream terminou.
                            return
                        backoff = min(RETRY_BACKOFF_FACTOR * (2 ** (attempt - 1)), MAX_BACKOFF_TIME)
                        time.sleep(backoff)
            finally:
                self.metrics["active_streams"] -= 1
                if acquired:
                    self.concurrent_semaphore.release()
                else:
                    logging.error("Erro ao liberar o semáforo. O semáforo pode ter sido liberado mais vezes do que adquirido.")

        return Response(stream_with_context(generate()), mimetype=safe_mime_type(url), status=200)

    def start(self) -> Optional[int]:
        self.stop()
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True, name="HLSProxyServer")
                self.server_thread.start()
                self.active_port = port
                self._randomize_headers()
                logging.info(f"Proxy melhorado iniciado em http://{PROXY_HOST}:{port}")
                return port
            except OSError:
                logging.debug("Porta ocupada, tentando outra...")
                continue
        logging.error("Falha ao iniciar proxy: nenhuma porta disponível.")
        return None

    def stop(self):
        self.shutdown_event.set()
        if self.server:
            try:
                self.server.shutdown()
            except Exception:
                logging.exception("Erro no shutdown do servidor")
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
        self.server = None
        self.server_thread = None
        self.active_port = None


# ----------------------------- ADDON/KODI --------------------------------


class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url: str, title: Optional[str] = None):
        self.proxy.stop()
        self.proxy.cache.clear()

        if not self.proxy.start():
            try:
                import xbmcgui  # type: ignore
                import xbmcplugin  # type: ignore
                xbmcgui.Dialog().ok("Erro Proxy IPTV", "Não foi possível iniciar o servidor proxy.")
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            except Exception:
                logging.exception("Erro ao notificar usuário (xbmc não disponível)")
            return

        encoded_url = advanced_encode(url)
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(encoded_url)}&original_url={urllib.parse.quote_plus(encoded_url)}"

        try:
            import xbmcgui  # type: ignore
            import xbmcplugin  # type: ignore
            li = xbmcgui.ListItem(path=proxy_url, label=title or "HLSProxy Improved")
            li.setProperty("IsPlayable", "true")
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true")
            xbmcplugin.setResolvedUrl(self.handle, True, li)
            logging.info(f"Reprodução iniciada com URL do proxy: {proxy_url}")
        except Exception:
            logging.exception("Erro ao criar ListItem para XBMC")

    def show_test_streams(self):
        try:
            import xbmcgui  # type: ignore
            import xbmcplugin  # type: ignore
            test_streams = [
                ("Big Buck Bunny", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
                ("Elephants Dream", "https://d3u2k51g8x1l3w.cloudfront.net/a/master_elephantsdream.m3u8"),
            ]
            for name, url in test_streams:
                encoded_url = advanced_encode(url)
                li = xbmcgui.ListItem(label=name)
                li.setProperty("IsPlayable", "true")
                plugin_url = f"plugin://{sys.argv[0]}/?action=play_stream&url={urllib.parse.quote_plus(encoded_url)}&title={urllib.parse.quote_plus(name)}"
                xbmcplugin.addDirectoryItem(self.handle, plugin_url, li, isFolder=False)
            xbmcplugin.endOfDirectory(self.handle)
        except Exception:
            logging.exception("Erro ao listar streams de teste (xbmc não disponível)")


# ----------------------------- Entrypoint --------------------------------


def _install_signal_handlers(manager: IPTVHLSProxyManager):
    def _handler(signum, frame):
        logging.info(f"Recebido sinal {signum}. Encerrando proxy...")
        manager.stop()
        sys.exit(0)

    signal_names = ("SIGINT", "SIGTERM")
    for sig_name in signal_names:
        try:
            sig = getattr(__import__("signal"), sig_name)
            __import__("signal").signal(sig, _handler)
        except Exception:
            # ambiente que não suporta signals (ex: Windows via algumas shells)
            pass


def main():
    setup_logging()
    logging.info("Iniciando HLS Proxy Improved")
    try:
        # Suporte a execução como addon: python proxy_improved.py <handle> '?action=play_stream&url=...'
        if len(sys.argv) > 1:
            try:
                handle = int(sys.argv[1])
            except Exception:
                handle = 0
            params = {}
            if len(sys.argv) > 2 and sys.argv[2].startswith("?"):
                params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
            addon = HLSProxyAddon(handle)
            action = params.get("action")
            if action == "play_stream":
                url_param = params.get("url")
                if url_param:
                    url = advanced_decode(url_param)
                else:
                    url = None
                title = params.get("title", "HLSProxy Improved")
                if url:
                    addon.play_stream(url, title)
                else:
                    addon.show_test_streams()
            else:
                addon.show_test_streams()
            return

        manager = IPTVHLSProxyManager()
        _install_signal_handlers(manager)
        port = manager.start()
        if not port:
            logging.critical("Não foi possível iniciar o proxy")
            return
        # Loop principal
        while True:
            time.sleep(1)
    except Exception:
        logging.critical("Fatal error", exc_info=True)


if __name__ == "__main__":
    main()