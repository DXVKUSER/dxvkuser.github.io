import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import json
import re

# Import requests (with fallback)
try:
    import requests
    from requests.exceptions import RequestException
except ImportError:
    from doh_client import requests 
    RequestException = Exception  # Fallback to catch broader exceptions when using doh_client

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------
# All configs are now dynamic where possible, calculated at runtime based on manifest properties
RETRY_BACKOFF_FACTOR_BASE = 0.05  # Base for backoff, adjusted dynamically
DEFAULT_CONNECTION_TIMEOUT = 10
DEFAULT_STREAM_TIMEOUT = 20.0
DEFAULT_CHUNK_SIZE = 1024 * 128  # Fallback chunk size
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
USER_AGENT_BASE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
LOG_FILE = "hls_proxy_persistent.log"
MANIFEST_CACHE_MAX_AGE = 3  # Balanced for live updates without overload
LOG_LEVEL = logging.INFO  # Set to WARNING for production to reduce I/O
DEFAULT_TARGET_DURATION = 10  # Fallback if #EXT-X-TARGETDURATION not found
DEFAULT_MAX_SEGMENT_RETRIES = 1  # Fallback retries

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------
def setup_logging():
    """Configura o logging para um arquivo específico do Kodi."""
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=LOG_LEVEL,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=LOG_LEVEL, format='%(asctime)s - %(levelname)s - %(message)s')

def _obfuscate_url(url):
    """Ofusca a URL para os logs, mostrando apenas o esquema e o host."""
    if not isinstance(url, str):
        return "URL inválida"
    try:
        parsed = urllib.parse.urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}/..."
    except Exception:
        return "URL malformada"

def extract_target_duration(manifest_content):
    """Extrai o valor de #EXT-X-TARGETDURATION do manifesto."""
    if not manifest_content:
        return DEFAULT_TARGET_DURATION
    match = re.search(r'#EXT-X-TARGETDURATION:(\d+)', manifest_content)
    if match:
        return int(match.group(1))
    logging.warning("Tag #EXT-X-TARGETDURATION não encontrada. Usando fallback.")
    return DEFAULT_TARGET_DURATION

def calculate_num_segments(manifest_content):
    """Calcula o número de segmentos no manifesto (linhas não-comentadas)."""
    if not manifest_content:
        return 0
    segments = [line for line in manifest_content.splitlines() if line.strip() and not line.startswith('#')]
    return len(segments)

def _create_new_session(version):
    """Cria e configura uma nova sessão requests sem retries fixos (gerenciados por request)."""
    try:
        session = requests.Session()
        session.headers.update({'User-Agent': f"{USER_AGENT_BASE}{version}.0.0.0 Safari/537.36"})
        logging.info(f"Sessão HTTP criada com sucesso (versão {version}).")
        return session
    except Exception as e:
        logging.error(f"Erro ao criar sessão HTTP: {e}. Verifique versão do requests/urllib3.")
        raise

# ---------------- HANDLER & SERVER ----------------
class _TCPServer(socketserver.ThreadingTCPServer):
    """Servidor TCP que permite reuso do endereço e maior queue para concurrency."""
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        self.request_queue_size = 100  # Increased for Kodi's concurrent requests
        super().__init__(server_address, RequestHandlerClass, bind_and_activate)

class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    """Handler de requisições HLS/Segmentos com sessão verdadeiramente persistente."""
    
    # Variáveis de classe para manter o estado persistente
    current_version = 90
    max_version = 120
    http_session = None  # Inicializado após a classe
    manifest_cache = {}  # Agora armazena também timeouts dinâmicos, num_segments, etc.
    cache_lock = threading.Lock()  # Thread-safe cache access
    
    @classmethod
    def get_current_user_agent(cls):
        if cls.http_session:
            return cls.http_session.headers.get('User-Agent')
        return USER_AGENT_BASE + "90.0.0.0 Safari/537.36"

    @classmethod
    def rotate_user_agent_and_refresh_session(cls):
        """Rotaciona o User-Agent e recria a sessão APENAS em caso de erro."""
        with cls.cache_lock:
            cls.current_version += 1
            if cls.current_version > cls.max_version:
                cls.current_version = 90
            
            if cls.http_session:
                cls.http_session.close()
            cls.http_session = _create_new_session(cls.current_version)
            cls.manifest_cache.clear()  # Limpa cache, incluindo timeouts
        logging.warning(f"ERRO DE REPRODUÇÃO: Sessão HTTP e User-Agent rotacionados para versão: {cls.current_version}")

    def log_message(self, format, *args):
        pass  # Desliga logging padrão para performance

    def get_forward_headers(self):
        """Encaminha headers de autenticação/token do cliente Kodi."""
        headers = {
            'User-Agent': self.get_current_user_agent(),
            'Connection': 'keep-alive',
        }
        if 'Authorization' in self.headers:
            headers['Authorization'] = self.headers['Authorization']
        if 'Cookie' in self.headers:
            headers['Cookie'] = self.headers['Cookie']
        return headers

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        url = None
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            encoded_headers = params.get('headers', [None])[0]

            if not url:
                self.send_error(400)
                return

            headers = self.get_forward_headers()

            if encoded_headers:
                try:
                    decoded_headers = urllib.parse.unquote_plus(encoded_headers)
                    custom_headers = json.loads(decoded_headers)
                    headers.update(custom_headers) 
                except Exception as e:
                    logging.error(f"Erro ao decodificar headers personalizados: {e}")

            parsed_url = urllib.parse.urlparse(url)
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, head_only)
            else:
                self._handle_segment(url, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado GET ({_obfuscate_url(url)}): {e}")
            self.rotate_user_agent_and_refresh_session()  # Força reconexão em falhas gerais
            try:
                self.send_error(500)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

    def _get_cached_manifest(self, url):
        """Obtém manifesto do cache se válido (thread-safe), incluindo timeouts e num_segments."""
        with self.cache_lock:
            if url in self.manifest_cache:
                content, final_url, timestamp, conn_timeout, stream_timeout, num_segments = self.manifest_cache[url]
                if time.time() - timestamp < MANIFEST_CACHE_MAX_AGE:
                    logging.info(f"Usando manifesto em cache para {_obfuscate_url(url)}")
                    return content, final_url, conn_timeout, stream_timeout, num_segments
            return None, None, None, None, None
    
    def _set_cached_manifest(self, url, content, final_url, conn_timeout, stream_timeout, num_segments):
        """Armazena manifesto no cache (thread-safe), com timeouts dinâmicos e num_segments."""
        with self.cache_lock:
            self.manifest_cache[url] = (content, final_url, time.time(), conn_timeout, stream_timeout, num_segments)
            logging.info(f"Manifesto armazenado em cache para {_obfuscate_url(url)} (target_duration: {conn_timeout / 1.5}s, num_segments: {num_segments})")

    def _handle_manifest(self, url, headers, head_only):
        try:
            manifest_content = None
            base_url = url
            conn_timeout = DEFAULT_CONNECTION_TIMEOUT
            stream_timeout = DEFAULT_STREAM_TIMEOUT
            num_segments = 0

            cached_content, cached_final_url, cached_conn, cached_stream, cached_num_segments = self._get_cached_manifest(url)
            if cached_content and not head_only:
                manifest_content = cached_content
                base_url = cached_final_url
                conn_timeout = cached_conn
                stream_timeout = cached_stream
                num_segments = cached_num_segments
            else:
                logging.info(f"Baixando manifesto de {_obfuscate_url(url)}")
                
                # Dynamic retries for manifest fetch based on defaults (since no prior manifest info)
                max_retries = DEFAULT_MAX_SEGMENT_RETRIES
                backoff_factor = RETRY_BACKOFF_FACTOR_BASE
                for attempt in range(max_retries + 1):
                    try:
                        r = self.http_session.get(url, headers=headers, timeout=DEFAULT_CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                        r.raise_for_status()
                        break
                    except RequestException as e:
                        if attempt == max_retries:
                            raise
                        logging.warning(f"Retry {attempt+1}/{max_retries} for manifest: {e}")
                        time.sleep(backoff_factor * (2 ** attempt))

                manifest_content = r.text
                base_url = r.url
                
                # Detecta target_duration e ajusta timeouts dinamicamente
                target_duration = extract_target_duration(manifest_content)
                conn_timeout = target_duration * 1.5
                stream_timeout = target_duration * 2.5
                
                # Calcula num_segments para ajustes dinâmicos (ex: retries para segmentos relacionados)
                num_segments = calculate_num_segments(manifest_content)
                
                # Ajusta backoff_factor dinamicamente baseado no tamanho do manifesto (maior manifesto = maior backoff para estabilidade)
                backoff_factor = RETRY_BACKOFF_FACTOR_BASE * (1 + num_segments / 100)  # Escala com tamanho
                
                logging.info(f"Target Duration detectado: {target_duration}s. Timeouts ajustados: conexão={conn_timeout}s, stream={stream_timeout}s. Num segments: {num_segments}, backoff ajustado: {backoff_factor}")
                
                if not head_only:
                    self._set_cached_manifest(url, manifest_content, base_url, conn_timeout, stream_timeout, num_segments)

            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            # Kodi/InputStream Adaptive hint for low-latency live streams
            if '#EXT-X-VERSION:3' not in manifest_content:  # Basic live check
                self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            if head_only:
                return
            
            proxy_base_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/"
            encoded_headers_param = ""
            if 'headers' in urllib.parse.parse_qs(self.path.split('?', 1)[1]):
                encoded_headers_param = f"&headers={urllib.parse.parse_qs(self.path.split('?', 1)[1])['headers'][0]}"

            new_manifest_lines = []
            for line in manifest_content.splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith('#'):
                    new_manifest_lines.append(line)
                else:
                    full_segment_url = urllib.parse.urljoin(base_url, stripped)
                    proxy_segment_url = f"{proxy_base_url}?url={urllib.parse.quote_plus(full_segment_url)}{encoded_headers_param}"
                    new_manifest_lines.append(proxy_segment_url)

            try:
                self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante envio do manifesto.")
                return

            logging.info("Manifesto enviado com sucesso. Sessão HTTP mantida.")

        except Exception as e:
            logging.error(f"Erro ao manipular manifesto ({_obfuscate_url(url)}): {e}")
            self.rotate_user_agent_and_refresh_session()  # Força reconexão em falhas no manifesto
            try:
                self.send_error(502)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

    def _handle_segment(self, url, headers, head_only):
        try:
            # Usa timeouts e num_segments dinâmicos do cache do manifesto (aproxima via parsed_url)
            parsed_url = urllib.parse.urlparse(url)
            manifest_key = None
            with self.cache_lock:
                for cached_url in list(self.manifest_cache.keys()):
                    if parsed_url.path.startswith(urllib.parse.urlparse(cached_url).path):
                        manifest_key = cached_url
                        break
            conn_timeout = DEFAULT_CONNECTION_TIMEOUT
            stream_timeout = DEFAULT_STREAM_TIMEOUT
            num_segments = 0
            if manifest_key:
                with self.cache_lock:
                    if manifest_key in self.manifest_cache:
                        _, _, _, conn_timeout, stream_timeout, num_segments = self.manifest_cache[manifest_key]

            # Ajusta max_retries dinamicamente baseado no tamanho do manifesto (num_segments)
            max_retries = max(DEFAULT_MAX_SEGMENT_RETRIES, 1 + num_segments // 20)  # Mais segmentos = mais retries para robustez
            # Ajusta backoff_factor dinamicamente baseado no num_segments
            backoff_factor = RETRY_BACKOFF_FACTOR_BASE * (1 + num_segments / 50)  # Escala com complexidade do stream
            
            logging.info(f"Segmento: max_retries ajustado para {max_retries}, backoff para {backoff_factor} baseado em num_segments {num_segments}")

            r = None
            for attempt in range(max_retries + 1):
                try:
                    r = self.http_session.get(url, headers=headers, stream=True, timeout=stream_timeout, verify=False)
                    if r.status_code in (404, 403):
                        logging.warning(f"Segmento erro ({r.status_code}): {_obfuscate_url(url)}. Refresh de sessão.")
                        self.rotate_user_agent_and_refresh_session()
                        self.send_error(r.status_code)
                        return
                    r.raise_for_status()
                    break
                except RequestException as e:
                    if attempt == max_retries:
                        raise
                    logging.warning(f"Retry {attempt+1}/{max_retries} for segment {_obfuscate_url(url)}: {e}")
                    time.sleep(backoff_factor * (2 ** attempt))
            
            self.send_response(r.status_code)
            for header, value in r.headers.items():
                if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                    self.send_header(header, value)
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.end_headers()

            if head_only:
                return

            # Chunksize adaptativo baseado na qualidade (estimada via Content-Length, correlacionado com bitrate/qualidade)
            chunk_size = DEFAULT_CHUNK_SIZE
            if 'Content-Length' in r.headers:
                try:
                    content_length = int(r.headers['Content-Length'])
                    # Ajusta dinamicamente: Maior para segmentos grandes (alta qualidade), min 64KB, max 1MB
                    chunk_size = max(1024 * 64, min(1024 * 1024, content_length // 10))  # ~10 chunks por segmento
                    logging.info(f"Chunksize ajustado dinamicamente para {chunk_size} baseado em Content-Length {content_length}")
                except ValueError:
                    pass

            # Ensure full consumption for connection pooling
            for chunk in r.iter_content(chunk_size=chunk_size):
                if not chunk: continue
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    logging.warning("Cliente fechou conexão durante segmento.")
                    return

            # Explicit close to release connection
            r.close()
            return
                
        except RequestException as e:
            logging.warning(f"Erro de requisição no segmento {_obfuscate_url(url)}: {e}. Refresh de sessão.")
            self.rotate_user_agent_and_refresh_session()
            try:
                self.send_error(502)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente desconectado antes do fim do segmento.")
            return
        except Exception as e:
            logging.error(f"Erro geral no segmento {_obfuscate_url(url)}: {e}")
            self.rotate_user_agent_and_refresh_session()  # Força reconexão em falhas gerais
            try:
                self.send_error(500)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return

# Inicializa a sessão após definir a classe
HLSProxyRequestHandler.http_session = _create_new_session(HLSProxyRequestHandler.current_version)

# ---------------- MANAGER ----------------
class HLSProxyManager:
    """Gerencia o ciclo de vida do servidor proxy em uma thread dedicada."""
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None
        self.handler_class = HLSProxyRequestHandler 

    def start(self):
        """Inicia o proxy em uma thread dedicada."""
        if self.thread and self.thread.is_alive():
            logging.info(f"Proxy já rodando na porta {self.active_port}")
            return True
            
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = _TCPServer((PROXY_HOST, port), self.handler_class)
                
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                
                self.active_port = port
                logging.info(f"Proxy HLS persistente iniciado na porta {self.active_port}")
                logging.info(f"User-Agent inicial: {self.handler_class.get_current_user_agent()}")
                return True
            except OSError as e:
                logging.warning(f"Porta {port} ocupada ou erro de socket: {e}")
                continue
                
        logging.error("Não foi possível iniciar o proxy.")
        return False
        
    def stop(self):
        """Para o servidor de forma limpa."""
        if self.server:
            logging.info("Parando servidor proxy.")
            self.server.shutdown()
            self.server.server_close()
            if self.handler_class.http_session:
                self.handler_class.http_session.close()
            with self.handler_class.cache_lock:
                self.handler_class.manifest_cache.clear()

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1)
            logging.info("Thread do proxy encerrada.")
        
        self.server = None
        self.thread = None
        self.active_port = None

class HLSAddon:
    """Funções do Addon Kodi."""
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None, headers=None):
        """Prepara o item de lista para o Kodi e inicia o proxy."""
        if not self.proxy.start():
            logging.error("Falha ao iniciar HLS Proxy.")
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        
        if headers and isinstance(headers, dict):
            encoded_headers = urllib.parse.quote_plus(json.dumps(headers))
            proxy_url += f"&headers={encoded_headers}"

        li = xbmcgui.ListItem(path=proxy_url)
        li.setProperty("IsPlayable", "true")
        
        info_labels = {}
        if title:
            info_labels['title'] = title
            
        if stype == "live":
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true") 
            info_labels['duration'] = 3600 

        if info_labels:
            li.setInfo(type='video', infoLabels=info_labels)

        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    
    try:
        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0] 
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            headers_str = args.get('headers', [None])[0]
            
            custom_headers = None
            if headers_str:
                try:
                    custom_headers = json.loads(urllib.parse.unquote_plus(headers_str))
                except Exception as e:
                    logging.error(f"Erro ao analisar headers: {e}")

            if stream_url:
                addon.play_stream(stream_url, stream_type, title, custom_headers)
            else:
                logging.error("URL do stream não fornecida.")
                xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
                
        xbmcplugin.endOfDirectory(h) 
        
    except Exception as e:
        logging.error(f"Erro main: {e}")

if __name__ == '__main__':
    main()