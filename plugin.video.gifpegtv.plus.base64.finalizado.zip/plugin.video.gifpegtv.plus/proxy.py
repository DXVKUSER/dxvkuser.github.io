import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
import warnings
import os
import re
from collections import OrderedDict
from typing import Optional, Dict
import http.server
import socketserver
# Importa o requests do módulo doh_client para usar DNS-over-HTTPS
from doh_client import requests
import requests.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import m3u8
import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------

MAX_SEGMENT_RETRIES = 2
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 10
STREAM_TIMEOUT = 15.0
DEFAULT_CHUNK_SIZE = 50*1024
MAX_CACHE_MB = 20
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
LOG_FILE = "hlsproxy_iptv.log"
MANIFEST_RELOAD_INTERVAL = 12  # Tempo de recarga proativa do manifesto em segundos
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------

def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')])
    except Exception as e:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
        logging.error(f"Erro ao configurar o logging para o arquivo: {e}")

# ---------------- PROXY LOGIC ----------------

class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format}\" % (args)")

    def do_HEAD(self):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return
                
            url = urllib.parse.unquote_plus(self.path.split('?url=')[1].split('&')[0])
            original_url = urllib.parse.unquote_plus(self.path.split('&original_url=')[1])
            parsed_url = urllib.parse.urlparse(url)
            headers = {'User-Agent': USER_AGENT}
            if 'Range' in self.headers:
                headers['Range'] = self.headers['Range']
            
            try:
                r = requests.head(url, headers=headers, stream=True, timeout=CONNECTION_TIMEOUT, allow_redirects=True)
                self.send_response(r.status_code)
                for header, value in r.headers.items():
                    self.send_header(header, value)
                self.end_headers()
            except requests.exceptions.RequestException as e:
                logging.error(f"Erro no HEAD para {url}: {e}")
                self.send_error(502)
        except Exception as e:
            logging.error(f"Erro inesperado no HEAD: {e}")
            self.send_error(500)

    def do_GET(self):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            url = urllib.parse.unquote_plus(self.path.split('?url=')[1].split('&')[0])
            original_url = urllib.parse.unquote_plus(self.path.split('&original_url=')[1])
            parsed_url = urllib.parse.urlparse(url)
            
            headers = {'User-Agent': USER_AGENT}
            range_header = self.headers.get('Range', None)
            if range_header:
                headers['Range'] = range_header

            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self.handle_hls_stream(url, original_url, headers)
            else:
                self.handle_progressive_stream(url, headers)

        except (IndexError, ValueError):
            self.send_error(400)
        except Exception as e:
            logging.error(f"Erro inesperado no GET para {self.path}: {e}")
            self.send_error(500)

    def handle_hls_stream(self, url, original_url, headers):
        try:
            r = requests.get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False)
            r.raise_for_status()

            manifest = m3u8.loads(r.text, r.url)
            base_url = urllib.parse.urlparse(r.url)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()

            new_manifest_lines = []
            for line in r.text.splitlines():
                if line.startswith('#EXTINF:'):
                    new_manifest_lines.append(line)
                elif not line.startswith('#') and line.strip():
                    full_segment_url = urllib.parse.urljoin(base_url.geturl(), line)
                    # CORREÇÃO: usar server_address[1] em vez de server_port
                    proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&original_url={urllib.parse.quote_plus(original_url)}"
                    new_manifest_lines.append(proxy_segment_url)
                else:
                    new_manifest_lines.append(line)
            
            self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
        except requests.exceptions.RequestException as e:
            logging.error(f"Erro ao processar stream HLS para {url}: {e}")
            self.send_error(502)

    def handle_progressive_stream(self, url, headers):
        session = requests.session()
        session.mount('http://', HTTPAdapter(max_retries=Retry(total=MAX_SEGMENT_RETRIES, backoff_factor=RETRY_BACKOFF_FACTOR)))
        session.mount('https://', HTTPAdapter(max_retries=Retry(total=MAX_SEGMENT_RETRIES, backoff_factor=RETRY_BACKOFF_FACTOR)))
        
        retries = 0
        max_retries = 5
        start_byte = 0
        if 'range' in headers:
            start_byte = int(headers['range'].split('=')[-1].split('-')[0])
            
        while retries < max_retries:
            try:
                if start_byte > 0:
                    headers['Range'] = f"bytes={start_byte}-"
                
                with session.get(url, headers=headers, stream=True, timeout=STREAM_TIMEOUT, verify=False) as r:
                    r.raise_for_status()
                    
                    if start_byte > 0 and r.status_code == 200:
                        self.send_response(206) # Partial content
                        self.send_header('Content-Range', f"bytes {start_byte}-{r.headers.get('Content-Length') or '*'}/{r.headers.get('Content-Length') or '*'}")
                    else:
                        self.send_response(r.status_code)
                    
                    for header, value in r.headers.items():
                        self.send_header(header, value)
                    self.end_headers()
                    
                    for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        if not chunk:
                            continue
                        self.wfile.write(chunk)
                        start_byte += len(chunk)
                        
                    return # Sucesso, sai do loop
                    
            except requests.exceptions.RequestException as e:
                logging.error(f"Erro ao transmitir arquivo progressivo para {url}: {e}. Tentativa {retries+1}/{max_retries}")
                retries += 1
                time.sleep(1) # Espera antes de tentar novamente
            except (ConnectionError, OSError, BrokenPipeError) as e:
                logging.warning(f"Conexão quebrada para o cliente. Tentando reconectar e continuar. {e}")
                retries += 1
                time.sleep(1) # Espera antes de tentar novamente

        logging.error(f"Falha ao transmitir o stream após {max_retries} tentativas.")

# ---------------- PROXY MANAGER ----------------

class IPTVHLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def is_running(self):
        return self._is_running

    def start(self):
        if self.is_running():
            return True

        self.stop()
        
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                self.active_port = port
                self._is_running = True
                logging.info(f"Proxy iniciado em {self.active_port}")
                return True
            except OSError:
                continue
        return False

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        if self.server_thread:
            self.server_thread.join(1)
        self.server = None
        self.server_thread = None
        self._is_running = False

# ---------------- ADDON ----------------

class HLSProxyAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&original_url={urllib.parse.quote_plus(url)}"
        li = xbmcgui.ListItem(path=proxy_url, label=title or "Canal IPTV")
        li.setProperty("IsPlayable", "true")
        if stype == "live":
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true")
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    try:
        h = int(sys.argv[1])
        addon = HLSProxyAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]
        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(stream_url, stream_type, title)
        else:
            xbmcplugin.endOfDirectory(h)
    except Exception as e:
        logging.error(f"Erro no main: {e}")

if __name__ == '__main__':
    main()