# -*- coding: utf-8 -*-
# NEXUS X-CODES HYBRID V21.03 (SUTURA CLÁSSICA + IDENTITY LOCK + 200 OK)
#
# HERANÇA:
#   - V21.02: Correções críticas de AttributeError, NameError, inicialização.
#
# CORREÇÕES V21.03:
#   [1] FIX EOF FATAL: generator() agora detecta inatividade prolongada do producer
#       (NULL_STARVATION_TIMEOUT=25s) e força reinício do producer thread — impede
#       que o Kodi receba só null packets por ~80s e interprete como EOF/stream-end.
#   [2] FIX PRODUCER THREAD MORTO: watchdog agora verifica se o producer thread
#       está vivo; se morreu por exceção não capturada, relança automaticamente.
#   [3] FIX do_GET EXCEPTION: removido _keep_alive_dummy() do except genérico —
#       qualquer exceção no wfile encerra limpo sem bloquear o handler thread.
#   [4] FIX GENERATOR EXIT: ao detectar morte do producer ou starvation fatal,
#       o generator sai do while True e permite que o do_GET retorne, liberando
#       o handler para aceitar nova conexão do Kodi.
#   [5] FIX CONTADOR RESET: consecutive_failures/failure_count não são resetados
#       pelo _session_reset() — após reset, producer recomeça com failures=0 e
#       faz conexão inicial (sem estratégia de reconexão), evitando loop de retry.

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, parse_qs
from requests.adapters import HTTPAdapter
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

import xbmc
import xbmcgui
import xbmcplugin

# Desativa alertas SSL e força compatibilidade com ciphers legados de painéis IPTV
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
try:
    urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL:@SECLEVEL=1'
except AttributeError:
    pass

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS   = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

VERSION = 'V21.03-STABLE-RECONN'

TS_PACKET_SIZE = 188
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
NULL_BLOCK     = TS_NULL_PACKET * 7

# --- CONFIGURAÇÃO DE BUFFER ---
CHUNK_SIZE_MIN  = 50  * 1024
CHUNK_SIZE_MAX  = 100 * 1024
CHUNK_SIZE_DEF  = 50  * 1024
TS_CHUNK_SIZE   = 50  * 1024

FETCH_TIMEOUT   = 12
CONNECT_TIMEOUT = 6
QUEUE_SIZE      = 1024

PREBUFFER_BYTES   = 50 * 1024 * 40
PREBUFFER_TIMEOUT = 15.0

KEEPALIVE_INTERVAL  = 0.025
WATCHDOG_INTERVAL   = 0.5
STARVATION_TIMEOUT  = 5.0

STALL_INJECT_INTERVAL = 0.04

# Tempo máximo sem dados reais no generator antes de forçar reinício do producer.
# Se o generator só injetar null packets por mais que este tempo, o producer é
# relançado. Valor calibrado para ser menor que o timeout de EOF do Kodi (~60-90s).
NULL_STARVATION_TIMEOUT = 20.0

TOKEN_EXPIRED_CODES = {401, 403, 404, 406, 410, 409, 423, 429, 451, 500, 502, 503, 504}

# [FIX 2] Constante que estava ausente e causava NameError
SESSION_RESET_FAIL_LIMIT = 3

# ---- Sutura - MATEMÁTICA EXATA --------------------------
TAIL_SIZE      = 174 * 188
TAIL_SECONDARY = 43  * 188

SLIDING_WINDOW_SIZE_DEFAULT = 12 * 1024 * 1024
SUTURE_MAX_TIME_DEFAULT     = 14

SUTURE_SKIP_THRESHOLD = 2
SUTURE_HARD_RESET_TIMEOUT = 11

SUTURE_WINDOW_STEP  = (188 * 200)
SUTURE_WINDOW_FLUSH = (188 * 1200)
SUTURE_WINDOW_KEEP  = TAIL_SIZE + TAIL_SECONDARY

SUTURE_CALL_EVERY = 50 * 1024

TAIL_SAVE_INTERVAL  = 0.25
TAIL_SAVE_MIN_BYTES = TS_PACKET_SIZE * 8

NULL_FLUSH_BLOCKS = 150

_ALL_REFERER = [
    'https://www.google.com/',
    'https://www.bing.com/',
    'https://www.duckduckgo.com/',
    'https://www.yandex.com/',
    'https://www.youtube.com/',
    'https://www.twitch.tv/',
    'https://www.facebook.com/',
    'https://www.reddit.com/',
]

_ACCEPT_LANG = [
    'en-US,en;q=0.9',
    'pt-BR,pt;q=0.9,en;q=0.8',
    'es-ES,es;q=0.9,en;q=0.8',
    'fr-FR,fr;q=0.9,en;q=0.8',
    'de-DE,de;q=0.9,en;q=0.8',
]

def generate_exoplayer_ua():
    major = 2
    minor = random.randint(14, 19)
    patch = random.randint(0, 5)
    android = random.randint(9, 14)
    version = f"{major}.{minor}.{patch}"
    return f"ExoPlayer/{version} (Linux; Android {android}) ExoPlayerLib/{version}"

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in (10, 127, 169, 172, 192, 198, 203, 224): continue
        o2, o3 = random.randint(0, 255), random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31: continue
        if o1 == 192 and o2 == 168: continue
        return '%d.%d.%d.%d' % (o1, o2, o3, o4)

def get_stream_headers(target_url, ua=None, fake_ip=None):
    if ua is None: ua = generate_exoplayer_ua()
    if fake_ip is None: fake_ip = random_ip()
    return {
        'User-Agent':      ua,
        'Accept':          '*/*',
        'Accept-Language': random.choice(_ACCEPT_LANG),
        'Accept-Encoding': 'identity',
        'Connection':      'keep-alive',
        'Cache-Control':   'no-cache',
        'Pragma':          'no-cache',
        'X-Forwarded-For': fake_ip,
        'X-Real-IP':       fake_ip,
        'Client-IP':       fake_ip,
        'Referer':         random.choice(_ALL_REFERER),
        'DNT':             str(random.randint(0, 1)),
    }

def get_proxy_response_headers():
    return {
        'Content-Type': 'video/mp2t',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
        'Pragma': 'no-cache',
        'Expires': '0',
    }

class ReconnectionSystem(object):
    def __init__(self):
        self.history = []
        self.last_success_idx = None
        self.locked_ip = random_ip()
        self.locked_ua = generate_exoplayer_ua()
        # [FIX 1] Contador de erros HTTP para controle de estratégia
        self._http_error_count = 0

    def reset_identity(self):
        self.locked_ip = random_ip()
        self.locked_ua = generate_exoplayer_ua()
        self._http_error_count = 0

    # [FIX 1] Método que estava ausente causando AttributeError silencioso
    def on_http_error(self):
        """Registra falha HTTP para orientar seleção de estratégia.
        Chamado sempre que o servidor retorna código fora de 200/206."""
        self._http_error_count += 1
        # Após 2 erros consecutivos, força nova identidade para escapar
        # de bloqueios por IP/fingerprint
        if self._http_error_count >= 2:
            self.locked_ip = random_ip()
            self._http_error_count = 0

    def on_success(self):
        """Reseta contador de erros após conexão bem-sucedida."""
        self._http_error_count = 0

    @staticmethod
    def _make_session():
        s = requests.Session()
        a = HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0)
        s.mount('http://', a); s.mount('https://', a)
        return s

    def _do_get(self, session, url, extra=None, t_add=(0, 0)):
        h = get_stream_headers(url, ua=self.locked_ua, fake_ip=self.locked_ip)
        if extra: h.update(extra)
        return session.get(
            url, headers=h, stream=True,
            timeout=(CONNECT_TIMEOUT + t_add[0], FETCH_TIMEOUT + t_add[1]),
            verify=False, allow_redirects=True)

    def _s0_fast(self, s, url):
        return self._do_get(s, url, extra={'X-Request-Id': str(uuid.uuid4())})

    def _s1_backoff(self, s, url):
        time.sleep(random.uniform(0.3, 0.8))
        return self._do_get(s, url, t_add=(2, 4))

    def _s2_new_session(self, s, url):
        return self._do_get(self._make_session(), url)

    def _s3_alt_proto(self, s, url):
        if 'http://' in url and ':80/' in url:
            return self._s0_fast(s, url)
        alt = url.replace('https://', 'http://', 1) if url.startswith('https://') else url.replace('http://', 'https://', 1)
        return self._do_get(s, alt)

    def _s4_cache_bust(self, s, url):
        sep = '&' if '?' in url else '?'
        busted = '%s%s_t=%d' % (url, sep, int(time.time()))
        return self._do_get(s, busted, extra={'Cache-Control': 'no-cache, no-store', 'Pragma': 'no-cache'})

    _STRATEGIES = [_s0_fast, _s1_backoff, _s2_new_session, _s3_alt_proto, _s4_cache_bust]

    def next_idx(self):
        if self.last_success_idx is not None: return self.last_success_idx
        if not self.history: return 0
        used = set(self.history[-3:])
        avail = [i for i in range(len(self._STRATEGIES)) if i not in used]
        if avail: return random.choice(avail)
        counts = {x: self.history.count(x) for x in set(self.history)}
        return min(counts, key=counts.get)

    def execute(self, idx, session, url):
        return self._STRATEGIES[idx % len(self._STRATEGIES)](self, session, url)

class AdaptiveChunkSizer(object):
    def __init__(self):
        self._size = CHUNK_SIZE_DEF; self._bytes = 0
        self._t_last = time.time(); self._lock = threading.Lock()

    def update(self, n):
        with self._lock:
            self._bytes += n; now = time.time(); dt = now - self._t_last
            if dt >= 2.0:
                rate = self._bytes / dt
                if   rate > 6*1024*1024: self._size = 100 * 1024
                elif rate > 2*1024*1024: self._size = 75  * 1024
                else:                    self._size = 50  * 1024
                self._bytes = 0; self._t_last = now

    @property
    def size(self):
        with self._lock: return self._size

class SingleTailCache(object):
    def __init__(self):
        self._live = b''; self._backup = b''; self._lock = threading.Lock()

    def update_live(self, tail):
        if not tail or len(tail) < TAIL_SAVE_MIN_BYTES: return False
        remainder = len(tail) % TS_PACKET_SIZE
        if remainder: tail = tail[remainder:]
        if not tail or len(tail) < TAIL_SAVE_MIN_BYTES: return False
        with self._lock:
            self._live = tail[-TAIL_SIZE:] if len(tail) > TAIL_SIZE else tail
            return True

    def promote_to_backup(self):
        with self._lock:
            if self._live and len(self._live) >= TAIL_SAVE_MIN_BYTES:
                self._backup = self._live; self._live = b''; return True
        return False

    def get_for_suture(self):
        with self._lock: return self._live

    def get_for_recovery(self):
        with self._lock:
            if not self._live and self._backup: return self._backup
            return b''

    def suture_done(self):
        with self._lock: self._live = b''; self._backup = b''

    def clear_all(self):
        with self._lock: self._live = b''; self._backup = b''

    @property
    def has_any(self):
        with self._lock:
            return bool((self._live and len(self._live) >= TAIL_SAVE_MIN_BYTES) or
                        (self._backup and len(self._backup) >= TAIL_SAVE_MIN_BYTES))

class DynamicTailSaver(threading.Thread):
    def __init__(self, engine):
        super().__init__(daemon=True, name='TailSaver')
        self.engine = engine; self._stop = threading.Event(); self._last_hash = None

    def run(self):
        while not self._stop.wait(timeout=TAIL_SAVE_INTERVAL):
            tail = self.engine.stream_tail
            if not tail or len(tail) < TAIL_SAVE_MIN_BYTES: continue
            if self.engine._bytes_streamed == 0: continue
            h = hash(bytes(tail[-512:])) if len(tail) >= 512 else hash(bytes(tail))
            if h != self._last_hash:
                if self.engine.tail_cache.update_live(bytes(tail)): self._last_hash = h

    def mark_synced(self):
        tail = self.engine.stream_tail
        if tail: self._last_hash = hash(bytes(tail[-512:])) if len(tail) >= 512 else hash(bytes(tail))

    def reset(self): self._last_hash = None
    def stop(self): self._stop.set()

class _KeepaliveThread(threading.Thread):
    def __init__(self, engine):
        super().__init__(daemon=True, name='Keepalive')
        self.engine = engine; self._stop = threading.Event()

    def run(self):
        while not self._stop.wait(timeout=KEEPALIVE_INTERVAL):
            if self.engine._reconnecting and self.engine.data_queue.qsize() < 8:
                try: self.engine.data_queue.put_nowait(NULL_BLOCK)
                except queue.Full: pass

    def stop(self): self._stop.set()

class XCodesEngine(object):
    def __init__(self):
        self.base_url = None
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self._stop_event = threading.Event()
        self.prebuf_ready = threading.Event()
        self._engine_lock = threading.Lock()
        self._gen = 0; self._gen_lock = threading.Lock()
        self.session = None
        self._active_response = None
        self._active_response_lock = threading.Lock()
        self.reconn = ReconnectionSystem()
        self.chunk_sizer = AdaptiveChunkSizer()
        self.stream_tail = bytearray()
        self.residual_buffer = bytearray()
        self.has_initial_lock = False
        self.tail_cache = SingleTailCache()
        self.tail_saver = DynamicTailSaver(self)
        self.emergency = queue.Queue(maxsize=200); self._refill_emergency()
        self._producer_thread = None
        self._watchdog_thread = None
        self._keepalive_thread = None
        self._reconnecting = False
        self._prebuf_bytes = 0
        self.last_data_time = 0.0
        self.starvation_counter = 0
        self.consecutive_failures = 0
        self._bytes_streamed = 0
        self._watchdog_restart_flag = threading.Event()
        self._suture_win_pos = 0
        self._suture_win_checked = 0
        self._suture_timeout_streak = 0
        self._suture_skip = False
        self.sliding_window_size = SLIDING_WINDOW_SIZE_DEFAULT
        self.suture_max_time = SUTURE_MAX_TIME_DEFAULT
        self._hard_reset_streak = 0
        self._last_409_time = 0.0
        # [FIX 1] Timestamp do último chunk REAL enviado ao generator (não null packet).
        # Usado pelo generator para detectar starvation fatal e forçar reinício.
        self._last_real_chunk_time = 0.0
        # [FIX 6] Timestamp do último retry para evitar loop de 403 em rajada
        self._last_retry_time = 0.0

    def _refill_emergency(self):
        for _ in range(200):
            try: self.emergency.put_nowait(NULL_BLOCK)
            except queue.Full: break

    def _push_keepalive(self, n=150):
        for _ in range(n):
            try: self.data_queue.put_nowait(NULL_BLOCK)
            except queue.Full: pass

    def _next_gen(self):
        with self._gen_lock: self._gen += 1; return self._gen

    def _get_gen(self):
        with self._gen_lock: return self._gen

    def _set_active_response(self, r):
        with self._active_response_lock: self._active_response = r

    def _clear_queue(self):
        while True:
            try: self.data_queue.get_nowait()
            except queue.Empty: break

    def _new_session(self):
        if self.session:
            try: self.session.close()
            except Exception: pass
        self.session = requests.Session()
        a = HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0)
        self.session.mount('http://', a); self.session.mount('https://', a)

    def _prepare_for_reset(self, reason=''):
        tail = self.stream_tail
        if tail and len(tail) >= TAIL_SAVE_MIN_BYTES:
            saved = self.tail_cache.update_live(bytes(tail))
            if saved:
                self.tail_cache.promote_to_backup()
                self.tail_saver.mark_synced()

    def _session_reset(self, reason='', keep_prebuf=False):
        xbmc.log(f'[RESET] {reason} tail_has_any={self.tail_cache.has_any}', xbmc.LOGWARNING)
        with self._active_response_lock:
            if self._active_response:
                try: self._active_response.close()
                except Exception: pass
                self._active_response = None

        if 'ConnectionError' in reason: self._push_keepalive(120)
        if not any(x in reason.upper() for x in ('HTTP_4', 'TOKEN_', '409', 'HARD_RESET', '403')):
            self._clear_queue()
        if self.data_queue.empty(): self._push_keepalive(30)

        self._prepare_for_reset(reason)
        # [FIX 5] consecutive_failures NÃO é zerado aqui — o producer já tratou
        # isso antes de chamar _session_reset. Zerar aqui causava o producer
        # recomeçar sem estratégia (consecutive_failures=0) logo após um reset,
        # fazendo a primeira reconexão sem backoff e sem sutura preparada.
        self.starvation_counter = 0
        if not keep_prebuf:
            self._prebuf_bytes = 0; self.prebuf_ready.clear()

        self.last_data_time = time.time()
        self.stream_tail = bytearray(); self.residual_buffer = bytearray()
        self.has_initial_lock = False
        self._new_session(); self.tail_saver.reset()
        self._suture_win_pos = 0; self._suture_win_checked = 0
        self.sliding_window_size = SLIDING_WINDOW_SIZE_DEFAULT
        self.suture_max_time = SUTURE_MAX_TIME_DEFAULT
        self._reconnecting = True

        if self.tail_cache.has_any:
            self._suture_skip = False
            self._suture_timeout_streak = 0

    def _suture_hard_reset(self, r):
        self._hard_reset_streak += 1
        xbmc.log(f'[SUTURA] Hard Reset #{self._hard_reset_streak} — sem match em {SUTURE_HARD_RESET_TIMEOUT}s', xbmc.LOGWARNING)
        self._set_active_response(None)
        try: r.close()
        except Exception: pass
        self._prepare_for_reset('sutura_hard_reset')
        self.tail_cache.promote_to_backup()
        self._push_keepalive(120)

        if self._hard_reset_streak >= 3:
            self._hard_reset_streak = 0
            self.consecutive_failures = 4
        else:
            self.consecutive_failures = 3
        self._session_reset('sutura_hard_reset', keep_prebuf=True)

    def _start_producer(self):
        self._stop_event.clear(); self._watchdog_restart_flag.clear()
        t = threading.Thread(target=self._producer_loop, name='XCodes-Producer', daemon=True)
        self._producer_thread = t; t.start()

    def _start_watchdog(self):
        t = threading.Thread(target=self._watchdog_loop, name='XCodes-Watchdog', daemon=True)
        self._watchdog_thread = t; t.start()

    def _start_keepalive(self):
        if self._keepalive_thread and self._keepalive_thread.is_alive(): self._keepalive_thread.stop()
        self._keepalive_thread = _KeepaliveThread(self); self._keepalive_thread.start()

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls: return
        entry = urls[0]
        with self._engine_lock:
            self._stop_event.set()
            if self.tail_saver.is_alive(): self.tail_saver.stop()
            time.sleep(0.05)
            self._clear_queue()
            self.tail_cache.clear_all()
            self.stream_tail = bytearray(); self.residual_buffer = bytearray()
            self.has_initial_lock = False
            self.reconn.reset_identity()
            self._new_session(); self._next_gen()
            self._prebuf_bytes = 0; self.prebuf_ready.clear()
            self.last_data_time = time.time()
            self.consecutive_failures = 0
            self._bytes_streamed = 0
            self._suture_timeout_streak = 0; self._suture_skip = False
            self._reconnecting = False
            self._hard_reset_streak = 0
            self._last_retry_time = 0.0
            self._last_real_chunk_time = time.time()
            self.reconn.history = []; self.reconn.last_success_idx = None
            self.base_url = entry
            self._refill_emergency()
            self.tail_saver = DynamicTailSaver(self); self.tail_saver.start()
            self._start_producer(); self._start_watchdog(); self._start_keepalive()

    def _watchdog_loop(self):
        while not self._stop_event.wait(timeout=WATCHDOG_INTERVAL):
            if self.last_data_time == 0.0: continue

            # [FIX 2] Se o producer thread morreu por exceção não capturada, relança.
            # Isso cobre o caso em que o loop _producer_loop sai sem reiniciar.
            if self._producer_thread and not self._producer_thread.is_alive():
                xbmc.log('[WATCHDOG] Producer thread morto — relançando', xbmc.LOGWARNING)
                self.consecutive_failures = max(self.consecutive_failures, 1)
                self._start_producer()
                self.last_data_time = time.time()
                continue

            if time.time() - self.last_data_time >= STARVATION_TIMEOUT:
                self.starvation_counter += 1
                self._watchdog_restart_flag.set()
                if self.data_queue.empty(): self._push_keepalive(8)
                self.last_data_time = time.time()

    def _try_suture(self, buf):
        buf_len = len(buf)
        if buf_len > self.sliding_window_size:
            excess = buf_len - self.sliding_window_size
            self._suture_win_pos = max(0, self._suture_win_pos - excess)
            effective_start = excess
        else: effective_start = 0

        win_start = effective_start + self._suture_win_pos
        if (buf_len - win_start) < (TAIL_SIZE + TAIL_SECONDARY + TS_PACKET_SIZE * 4):
            return False, b''

        window = buf[win_start:]
        tail = self.tail_cache.get_for_suture()
        if tail:
            ok, rem = self._find_match(window, tail, 'LIVE')
            if ok: self._suture_win_pos = 0; return ok, rem

        tail = self.tail_cache.get_for_recovery()
        if tail:
            ok, rem = self._find_match(window, tail, 'BACKUP')
            if ok: self._suture_win_pos = 0; return ok, rem

        eff_len = buf_len - effective_start
        self._suture_win_checked += (eff_len - self._suture_win_pos)

        if self._suture_win_checked >= SUTURE_WINDOW_FLUSH:
            k_start = max(0, eff_len - SUTURE_WINDOW_KEEP)
            self._suture_win_pos = k_start - (k_start % TS_PACKET_SIZE) if k_start >= TS_PACKET_SIZE else 0
            self._suture_win_checked = 0
        else:
            step = SUTURE_WINDOW_STEP - (SUTURE_WINDOW_STEP % TS_PACKET_SIZE)
            self._suture_win_pos = min(self._suture_win_pos + step, max(0, eff_len - SUTURE_WINDOW_KEEP))
        return False, b''

    def _find_match(self, buf, tail, label):
        primary = tail[-TAIL_SIZE:] if len(tail) >= TAIL_SIZE else tail
        if primary:
            idx = buf.find(primary)
            if idx != -1:
                skip = idx + len(primary)
                remainder = bytes(buf[skip:])
                align = self._find_sync_offset(remainder)
                if align > 0: remainder = remainder[align:]; skip += align
                xbmc.log(f'[SUTURA] Perfeita [{label}] pulou {skip//1024}KB', xbmc.LOGINFO)
                return True, remainder

        secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
        if secondary and len(buf) > TAIL_SECONDARY + 188 * 50:
            idx = buf.find(secondary)
            if idx != -1:
                skip = idx + len(secondary)
                remainder = bytes(buf[skip:])
                align = self._find_sync_offset(remainder)
                if align > 0: remainder = remainder[align:]; skip += align
                return True, remainder
        return False, b''

    @staticmethod
    def _find_sync_offset(data):
        length = len(data)
        for i in range(length):
            if data[i] == 0x47:
                n1 = i + TS_PACKET_SIZE; n2 = i + 2 * TS_PACKET_SIZE
                if n1 < length and data[n1] == 0x47: return i
        return -1

    def _process(self, raw, my_gen):
        if my_gen != self._get_gen() or not raw: return
        self.residual_buffer.extend(raw)
        batch = self.residual_buffer
        if not self.has_initial_lock:
            idx = self._find_sync_offset(batch)
            if idx == -1:
                if len(batch) > TS_PACKET_SIZE * 4: del batch[:len(batch) - TS_PACKET_SIZE * 4]
                return
            del batch[:idx]; self.has_initial_lock = True

        n = len(batch) // TS_PACKET_SIZE
        if n == 0: return
        used = n * TS_PACKET_SIZE
        payload = bytes(batch[:used])
        del batch[:used]

        self.stream_tail.extend(payload)
        if len(self.stream_tail) > (TAIL_SIZE + TAIL_SECONDARY):
            del self.stream_tail[:len(self.stream_tail) - TAIL_SIZE]

        self.last_data_time = time.time()
        self.chunk_sizer.update(len(payload))
        # [FIX 1] Atualiza timestamp de dado real — usado pelo generator
        self._last_real_chunk_time = time.time()

        if not self.prebuf_ready.is_set():
            self._prebuf_bytes += len(payload)
            if self._prebuf_bytes >= PREBUFFER_BYTES: self.prebuf_ready.set()

        try: self.data_queue.put_nowait(payload)
        except queue.Full:
            try: self.data_queue.get_nowait(); self.data_queue.put_nowait(payload)
            except Exception: pass

    def _producer_loop(self):
        my_gen = self._get_gen(); failure_count = 0; strategy_idx = 0

        while not self._stop_event.is_set():
            if self._watchdog_restart_flag.is_set():
                self._watchdog_restart_flag.clear()
                self.consecutive_failures += 1
                self.last_data_time = time.time()

            r = None
            try:
                if self.consecutive_failures >= 1:
                    self._reconnecting = True

                    # [FIX 6] Backoff mínimo entre retentativas para evitar
                    # loop de 403 em rajada (observado no log às 07:15:33)
                    elapsed_since_retry = time.time() - self._last_retry_time
                    if elapsed_since_retry < 0.5:
                        time.sleep(0.5 - elapsed_since_retry)
                    self._last_retry_time = time.time()

                    strategy_idx = self.reconn.next_idx()

                    if self._hard_reset_streak > 0 or time.time() - self._last_409_time < 20:
                        strategy_idx = 2
                        time.sleep(random.uniform(1.5, 4.0))

                    xbmc.log(f'[PRODUCER] Reconexao S{strategy_idx} via base_url tail_has_any={self.tail_cache.has_any}', xbmc.LOGINFO)
                    self.reconn.history.append(strategy_idx)

                    if self.stream_tail and len(self.stream_tail) >= TAIL_SAVE_MIN_BYTES:
                        self._prepare_for_reset('reconexao')

                    if strategy_idx == 2 or self._hard_reset_streak > 0: self._new_session()

                    self.stream_tail = bytearray(); self.residual_buffer = bytearray()
                    self.has_initial_lock = False
                    self.tail_saver.reset()
                    self._suture_win_pos = 0; self._suture_win_checked = 0

                    if self.data_queue.empty(): self._push_keepalive(150)

                    try:
                        # [FIX 4] Sempre reconecta via base_url (entry_url imutável)
                        # para obter token CDN fresco — nunca recicla URL expirada
                        r = self.reconn.execute(strategy_idx, self.session, self.base_url)
                    except Exception as e:
                        self._session_reset(f'Falha S{strategy_idx}: {type(e).__name__}', keep_prebuf=True)
                        self.consecutive_failures = 1
                        failure_count += 1; continue

                else:
                    try:
                        h = get_stream_headers(self.base_url, ua=self.reconn.locked_ua, fake_ip=self.reconn.locked_ip)
                        r = self.session.get(self.base_url, headers=h, stream=True,
                                             timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT), verify=False)
                    except Exception as e:
                        self._session_reset(f'Falha init: {type(e).__name__}', keep_prebuf=True)
                        self.consecutive_failures = 1
                        failure_count += 1; continue

                if r is None:
                    self.consecutive_failures += 1
                    if self.data_queue.empty(): self._push_keepalive(10)
                    continue

                status = r.status_code

                if status not in (200, 206):
                    r.close()
                    label = f'HTTP_{status}'
                    xbmc.log(f'[PRODUCER] Erro {status} -> Gerenciando bloqueio', xbmc.LOGWARNING)

                    # [FIX 1] Chamada agora funciona corretamente (método existe)
                    self.reconn.on_http_error()

                    if status == 409:
                        self._last_409_time = time.time()
                        self.reconn.reset_identity()  # 409 exige novo IP obrigatoriamente

                    if status == 409 or 'ConnectionError' in label: self._push_keepalive(150)
                    if self.data_queue.empty(): self._push_keepalive(30)

                    failure_count += 1
                    self.consecutive_failures += 1

                    # [FIX 2] SESSION_RESET_FAIL_LIMIT agora está definida (=3)
                    if failure_count >= SESSION_RESET_FAIL_LIMIT or status == 409 or status == 403:
                        self._session_reset(f'{label} x{failure_count}', keep_prebuf=True)
                        self.consecutive_failures = 1 if status != 409 else 2
                        failure_count = 0
                    continue

                # Sucesso na Conexão
                self._hard_reset_streak = 0
                self.sliding_window_size = SLIDING_WINDOW_SIZE_DEFAULT
                self.suture_max_time = SUTURE_MAX_TIME_DEFAULT
                self._watchdog_restart_flag.clear()
                self.last_data_time = time.time()
                self.consecutive_failures = 0
                failure_count = 0
                self._reconnecting = False
                self.reconn.last_success_idx = strategy_idx
                # [FIX 1] Notifica sucesso ao ReconnectionSystem
                self.reconn.on_success()
                self._set_active_response(r)

                is_ts = any(x in r.url.lower() for x in ('.ts', '/ts', '.m2ts', '/chunk', '/segment'))
                chunk_sz = TS_CHUNK_SIZE if is_ts else self.chunk_sizer.size
                resync_buf = bytearray()
                _suture_pending = SUTURE_CALL_EVERY
                need_suture = self.tail_cache.has_any and not self._suture_skip
                suture_start = time.time()

                if need_suture: self._suture_win_pos = 0; self._suture_win_checked = 0
                _hard_reset_done = False

                try:
                    for chunk in r.iter_content(chunk_size=chunk_sz):
                        if self._stop_event.is_set(): break
                        if not chunk: continue

                        if not is_ts: chunk_sz = self.chunk_sizer.size

                        if need_suture:
                            resync_buf.extend(chunk)
                            _suture_pending += len(chunk)
                            self._bytes_streamed += len(chunk)
                            self.last_data_time = time.time()

                            if len(resync_buf) > self.sliding_window_size:
                                del resync_buf[:len(resync_buf) - self.sliding_window_size]

                            if _suture_pending < SUTURE_CALL_EVERY:
                                if self._watchdog_restart_flag.is_set(): break
                                continue
                            _suture_pending = 0

                            ok, remainder = self._try_suture(resync_buf)
                            time_spent = time.time() - suture_start

                            if ok:
                                resync_buf = bytearray(); need_suture = False
                                self._suture_timeout_streak = 0
                                self._suture_skip = False
                                self.has_initial_lock = False
                                self.residual_buffer = bytearray()
                                self.tail_cache.suture_done(); self.tail_saver.reset()
                                # [FIX 5] Removido _push_keepalive antes de _process(remainder)
                                # Era a causa do "large audio sync error: -89400ms" no Kodi.
                                # Os null packets injetados aqui criavam um gap de ~89 segundos
                                # no PTS, causando dessincronização de áudio irrecuperável.
                                self._process(remainder, my_gen)
                                if not self.prebuf_ready.is_set(): self.prebuf_ready.set()

                            elif time_spent > SUTURE_HARD_RESET_TIMEOUT and len(resync_buf) >= SUTURE_WINDOW_KEEP:
                                self._suture_hard_reset(r)
                                _hard_reset_done = True
                                break

                            elif time_spent > self.suture_max_time and len(resync_buf) >= SUTURE_WINDOW_KEEP:
                                self._suture_timeout_streak += 1
                                if self._suture_timeout_streak >= SUTURE_SKIP_THRESHOLD: self._suture_skip = True
                                need_suture = False
                                self.has_initial_lock = False
                                self.residual_buffer = bytearray()
                                self.tail_cache.clear_all(); self.tail_saver.reset()
                                resync_buf = bytearray()

                        else:
                            self._process(chunk, my_gen)
                            self._bytes_streamed += len(chunk)

                        if self._watchdog_restart_flag.is_set(): break

                except Exception as e:
                    self._prepare_for_reset('falha_stream')
                    self._set_active_response(None)
                    try: r.close()
                    except Exception: pass
                    self._session_reset(f'Stream Quebrada: {type(e).__name__}', keep_prebuf=True)
                    self._push_keepalive(120)
                    failure_count += 1; continue

                if need_suture and resync_buf and not _hard_reset_done:
                    ok, remainder = self._try_suture(resync_buf)
                    if ok:
                        resync_buf = bytearray(); need_suture = False
                        self._suture_timeout_streak = 0; self._suture_skip = False
                        self.has_initial_lock = False; self.residual_buffer = bytearray()
                        self.tail_cache.suture_done(); self.tail_saver.reset()
                        # [FIX 5] Idem: sem _push_keepalive antes de _process()
                        self._process(remainder, my_gen)
                        if not self.prebuf_ready.is_set(): self.prebuf_ready.set()

                self._set_active_response(None)
                if not _hard_reset_done:
                    try: r.close()
                    except Exception: pass

            except Exception as exc:
                self._set_active_response(None)
                if r:
                    try: r.close()
                    except Exception: pass
                self._prepare_for_reset('excecao')
                if self._stop_event.is_set(): break
                self.consecutive_failures += 1; failure_count += 1
                if self.data_queue.empty(): self._push_keepalive(150)

        self._prepare_for_reset('fim')

    def generator(self):
        for _ in range(80): yield NULL_BLOCK
        self.prebuf_ready.wait(timeout=PREBUFFER_TIMEOUT)

        next_kp = time.time() + STALL_INJECT_INTERVAL
        # [FIX 1] Rastreia quando foi o último chunk real entregue ao generator.
        # Inicializa com o tempo atual para dar margem ao producer começar.
        last_real = time.time()

        try:
            while True:
                # [FIX 4] Se o engine foi parado externamente, sai limpo.
                if self._stop_event.is_set():
                    break

                now = time.time()
                try:
                    chunk = self.data_queue.get(timeout=STALL_INJECT_INTERVAL)
                    # É um chunk real (não null packet interno)?
                    # NULL_BLOCK começa com o sync byte 0x47 mas tem padrão fixo.
                    # Qualquer dado do producer é considerado "real" para o timer.
                    # Null packets do _push_keepalive também chegam aqui, mas a
                    # atualização de _last_real_chunk_time em _process() é quem
                    # dita se houve dado real. Usamos ela como oracle.
                    if time.time() - self._last_real_chunk_time < 2.0:
                        last_real = time.time()
                    yield chunk
                    next_kp = time.time() + STALL_INJECT_INTERVAL
                except queue.Empty:
                    if now >= next_kp:
                        try:
                            yield self.emergency.get_nowait()
                            self._refill_emergency()
                        except queue.Empty:
                            yield NULL_BLOCK
                        next_kp = time.time() + STALL_INJECT_INTERVAL

                # [FIX 1] Detecção de starvation fatal: se passamos mais de
                # NULL_STARVATION_TIMEOUT segundos sem dado real do producer,
                # força reinício do producer thread em vez de continuar injetando
                # null packets para o Kodi (que causaria EOF/encerramento).
                starvation = time.time() - max(last_real, self._last_real_chunk_time)
                if starvation > NULL_STARVATION_TIMEOUT:
                    xbmc.log(
                        f'[GENERATOR] Starvation fatal {starvation:.1f}s — forçando reinicio do producer',
                        xbmc.LOGWARNING
                    )
                    # Força reconexão imediata via consecutive_failures
                    self.consecutive_failures = max(self.consecutive_failures, 1)
                    self._watchdog_restart_flag.set()
                    # Se o producer thread morreu, relança aqui mesmo
                    if self._producer_thread and not self._producer_thread.is_alive():
                        self._start_producer()
                    # Reseta o timer para dar tempo ao producer reconectar
                    last_real = time.time()
                    self._last_real_chunk_time = time.time()

        except GeneratorExit:
            if not self._stop_event.is_set(): self._stop_event.set()
        except Exception:
            if not self._stop_event.is_set(): self._stop_event.set()

# ---------------------------------------------------------------------------
# Servidor HTTP local
# ---------------------------------------------------------------------------
engine = XCodesEngine()

class TSProxyHandler(BaseHTTPRequestHandler):
    def _apply_headers(self):
        for k, v in get_proxy_response_headers().items():
            self.send_header(k, v)

    def do_GET(self):
        p = urlparse(self.path)
        if p.path != '/stream':
            self.send_response(404)
            self._apply_headers()
            self.end_headers()
            return

        # BLINDAGEM 200 OK FOREVER (Evita Kodi fechar sozinho)
        self.send_response(200)
        self._apply_headers()
        self.end_headers()

        url_param = parse_qs(p.query).get('url', [None])[0]
        if not url_param:
            self._keep_alive_dummy()
            return

        try:
            engine.start_stream(url_param)
            for chunk in engine.generator():
                self.wfile.write(chunk)
                self.wfile.flush()
        except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError, OSError):
            # [FIX 3] Kodi fechou a conexão — sai limpo, sem loops infinitos.
            pass
        except Exception:
            # [FIX 3] Qualquer outra exceção no wfile também encerra limpo.
            # _keep_alive_dummy() foi removido aqui pois bloqueava o handler
            # thread em loop eterno numa conexão já morta, impedindo o Kodi
            # de reconectar neste mesmo handler.
            pass

    def do_HEAD(self):
        self.send_response(200)
        self._apply_headers()
        self.end_headers()

    def _keep_alive_dummy(self):
        try:
            while True:
                self.wfile.write(NULL_BLOCK)
                self.wfile.flush()
                time.sleep(0.05)
        except Exception:
            pass

    def log_message(self, fmt, *args): pass

class SilentHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address):
        exc_type = sys.exc_info()[0]
        if exc_type in (ConnectionResetError, BrokenPipeError, ConnectionAbortedError, OSError): return
        return super().handle_error(request, client_address)

class TSProxyServer(threading.Thread):
    def __init__(self, port):
        super().__init__(daemon=True)
        self.port = port
        self.server = SilentHTTPServer(('127.0.0.1', port), TSProxyHandler)

    def run(self):
        try: self.server.serve_forever()
        except Exception: pass

    def stop(self):
        self.server.shutdown()
        self.server.server_close()

def get_free_port(start=50088):
    for port in range(start, start + 100):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            return port
        except OSError: pass
        finally:
            try: s.close()
            except Exception: pass
    return random.randint(50088, 50188)

# [FIX 3] Inicialização corrigida — start_server() não existia e causava crash
def start_proxy():
    port = get_free_port()
    proxy = TSProxyServer(port)
    proxy.start()
    time.sleep(0.3)
    return port

SERVER_PORT = start_proxy()

def run_addon():
    action = _ARGS.get('action')
    url = _ARGS.get('url')
    if action == 'play' and url:
        local = 'http://127.0.0.1:%d/stream?url=%s' % (SERVER_PORT, quote(url))
        li = xbmcgui.ListItem(path=local)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    else:
        li = xbmcgui.ListItem('[COLOR cyan]NEXUS X-CODES HYBRID %s[/COLOR]' % VERSION)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle('Nexus X-Codes Hybrid Proxy - Anti-Bloqueio')
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    run_addon()
