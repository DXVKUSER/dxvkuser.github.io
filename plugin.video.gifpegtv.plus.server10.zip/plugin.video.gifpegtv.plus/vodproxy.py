import sys
import threading
import random
import logging
import urllib.parse
import time
import os
import http.server
import socketserver
import socket
import ssl 
import warnings # Adicionado para warnings de SSL

# --- IMPORTAÇÕES DE REDE ---
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException, ConnectionError, HTTPError, Timeout, StreamConsumedError
from requests.packages.urllib3.util.retry import Retry
# from urllib3.util.retry import Retry # Alternativa para a linha acima se requests for mais antigo.

# Tenta importar o wrapper DoH (doh_client/netunblock)
# Se falhar, usa o requests padrão
try:
    from doh_client import requests as netunblock_requests
    requests_source = netunblock_requests
    NETUNBLOCK_AVAILABLE = True
except ImportError:
    import requests
    requests_source = requests
    NETUNBLOCK_AVAILABLE = False


# Importações necessárias do Kodi
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs 

# ---------------- CONFIGURAÇÕES OTIMIZADAS ----------------

DEFAULT_CHUNK_SIZE = 64 * 1024  # 64KB (Otimizado para Kodi)
MAX_RETRIES = 5 # Mantido em 5 (era 3 no vodproxy2)
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 25.0 
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 30
# Lista de User Agents
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; SM-A536E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
]
DEFAULT_USER_AGENT = random.choice(USER_AGENTS)

LOG_FILE = "vod_proxy.log"

# --- REQUISITOS DO CLIENTE ---
VERIFY_SSL = False          
ALLOW_REDIRECTS = True      

# Ignora warnings de SSL (necessário quando verify=False)
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- LOGGING ----------------

def setup_logging():
    """Configura o logger para o proxy, usando xbmcvfs.translatePath."""
    log_path = None
    try:
        log_path = os.path.join(xbmcvfs.translatePath('special://logpath'), LOG_FILE)
    except Exception:
        pass 

    if log_path:
        try:
            logging.basicConfig(
                level=logging.INFO,
                format='[VOD-PROXY] %(asctime)s - %(levelname)s - %(message)s',
                handlers=[logging.FileHandler(log_path, mode='w', encoding='latin-1')]
            )
        except Exception:
            logging.basicConfig(level=logging.INFO, format='[VOD-PROXY] %(message)s')
    else:
        logging.basicConfig(level=logging.INFO, format='[VOD-PROXY] %(message)s')


# ---------------- PREPARAÇÃO DA SESSÃO (CORREÇÃO FINAL) ----------------

def get_global_session():
    """
    Implementa a lógica de detecção de sessão do vodproxy2 para corrigir
    os erros de inicialização com o doh_client/netunblock.
    """
    global requests_source 
    session_obj = None
    
    # 1. Verifica se requests_source.session existe e NÃO é callable (doh_client/netunblock)
    if hasattr(requests_source, 'session') and not callable(requests_source.session):
        session_obj = requests_source.session
        logging.info("[VOD-PROXY] Usando objeto Session do doh_client (não-callable).")
        
    # 2. Verifica se requests_source.Session (maiúsculo) é callable (requests padrão)
    elif hasattr(requests_source, 'Session') and callable(requests_source.Session):
        session_obj = requests_source.Session()
        logging.info("[VOD-PROXY] Criando nova requests.Session().")
        
    # 3. Verifica se requests_source.session (minúsculo) é callable (requests padrão como alias)
    elif hasattr(requests_source, 'session') and callable(requests_source.session):
        session_obj = requests_source.session()
        logging.info("[VOD-PROXY] Criando nova requests.session().")
    
    else:
        # 4. Fallback de segurança para requests padrão
        try:
            import requests as std_requests
            session_obj = std_requests.Session()
            logging.warning("[VOD-PROXY] Fallback para requests padrão Session().")
        except Exception as e:
            logging.error(f"[VOD-PROXY] Falha na inicialização da sessão. Erro: {e}")
            return None

    if session_obj is None:
        logging.error("[VOD-PROXY] Falha ao obter objeto de sessão.")
        return None

    # Configura Adapters e Retries
    retry_strategy = Retry(
        total=MAX_RETRIES,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=20, pool_maxsize=20)
    
    try:
        session_obj.mount("https://", adapter)
        session_obj.mount("http://", adapter)
    except Exception as e:
        logging.error(f"[VOD-PROXY] Erro ao montar adaptadores na sessão: {e}")
        pass
    
    # Define o User-Agent na sessão
    session_obj.headers.update({'User-Agent': DEFAULT_USER_AGENT})
    
    return session_obj

# Inicializa a sessão globalmente
GLOBAL_SESSION = get_global_session()

# ---------------- LÓGICA DO PROXY ----------------

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    session = GLOBAL_SESSION
    local_ua = DEFAULT_USER_AGENT # Usa o User-Agent padrão

    def log_message(self, format, *args):
        # Suprime logs de acesso HTTP do proxy
        pass

    def do_HEAD(self):
        self._handle_request(method='HEAD')

    def do_GET(self):
        self._handle_request(method='GET')
    
    def _handle_request(self, method='GET'):
        target_url = None
        
        if self.session is None:
            logging.error("[VOD-PROXY] Sessão não está disponível.")
            self.send_error(503, "Proxy Service Unavailable (Session Error)")
            return

        try:
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            target_url = params.get('url', [None])[0]

            if not target_url:
                self.send_error(400, "URL parameter missing")
                return

            target_url = urllib.parse.unquote_plus(target_url)
            logging.info(f"[VOD-PROXY] Requisitando: {method} {target_url}")

            # Headers mínimos (simplificado como no vodproxy2)
            headers = {
                'User-Agent': self.local_ua,
                'Connection': 'keep-alive',
            }

            # Repassa Range (Seek) se o Kodi solicitar
            if 'Range' in self.headers:
                headers['Range'] = self.headers['Range']
            
            # Requisição upstream
            resp = self.session.request(
                method, 
                target_url, 
                headers=headers, 
                stream=True, 
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), 
                verify=VERIFY_SSL,        
                allow_redirects=ALLOW_REDIRECTS 
            )

            if resp.status_code >= 400:
                logging.error(f"[VOD-PROXY] Erro upstream {resp.status_code} para {target_url}")
                self.send_error(resp.status_code) 
                resp.close()
                return

            # --- Resposta de Sucesso (200, 206) ---
            self.send_response(resp.status_code)

            # Headers Hop-by-Hop que não devem ser repassados
            hop_by_hop = [
                'connection', 'keep-alive', 'proxy-authenticate', 
                'proxy-authorization', 'te', 'trailers', 
                'transfer-encoding', 'upgrade', 'content-encoding',
                'content-length' # Removido para ser repassado no final
            ]

            for k, v in resp.headers.items():
                if k.lower() not in hop_by_hop:
                    self.send_header(k, v)
                    
            if 'Content-Length' in resp.headers:
                self.send_header('Content-Length', resp.headers['Content-Length'])
            
            self.end_headers()

            if method == 'HEAD':
                resp.close()
                return

            # Streaming Direto
            try:
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.wfile.write(chunk)
            except (ConnectionError, socket.error, StreamConsumedError) as e:
                # Cliente desconectou (Stop/Pause/Seek/Close), comportamento normal
                logging.info(f"[VOD-PROXY] Conexão com o cliente (Kodi) fechada ou erro no stream (normalmente): {e}")
            except Exception as e:
                logging.error(f"[VOD-PROXY] Erro inesperado no stream de dados: {e}")
            finally:
                resp.close()

        except Exception as e:
            logging.error(f"[VOD-PROXY] Erro fatal no handler: {e}", exc_info=True)
            try:
                self.send_error(502, "Bad Gateway")
            except:
                pass

class VODProxyManager:
    """Gerencia o ciclo de vida do servidor proxy."""
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def start(self):
        if self._is_running: 
            return True
        
        # Garante que a sessão é válida antes de tentar iniciar
        if GLOBAL_SESSION is None:
             logging.error("[VOD-PROXY] Impossível iniciar o proxy, a sessão global é inválida.")
             return False
        
        # Adicionado stop() para limpar a porta se a thread anterior não fechou (melhor estabilidade)
        self.stop() 

        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 55000)
                self.server = ThreadedTCPServer((PROXY_HOST, port), VODProxyRequestHandler)
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                self.active_port = port
                self._is_running = True
                logging.info(f"[VOD-PROXY] Proxy iniciado com sucesso em http://{PROXY_HOST}:{port}")
                return True
            except OSError as e:
                logging.warning(f"[VOD-PROXY] Falha ao iniciar na porta {port}: {e}. Tentando outra...")
                continue
        
        logging.error(f"[VOD-PROXY] Falha ao iniciar o proxy após {MAX_PORT_ATTEMPTS} tentativas de porta.")
        return False

    def stop(self):
        self._is_running = False
        if self.server:
            logging.info("[VOD-PROXY] Parando o servidor proxy...")
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception as e:
                logging.error(f"[VOD-PROXY] Erro ao desligar o servidor: {e}")
            self.server = None
        if self.server_thread and self.server_thread.is_alive():
            try:
                self.server_thread.join(1)
            except Exception as e:
                logging.error(f"[VOD-PROXY] Erro ao finalizar a thread: {e}") 
        self.server_thread = None
        self.active_port = None
        logging.info("[VOD-PROXY] Proxy parado.")


# ---------------- PONTO DE ENTRADA E EXPORTAÇÃO PARA ADDON.PY ----------------

def resolve_vod_stream(stream_url):
    """
    Função chamada pelo addon principal para resolver uma URL de VOD
    usando o proxy.
    """
    setup_logging()
    
    proxy_manager = VODProxyManager()
    
    if proxy_manager.start():
        if stream_url:
            proxy_url = f"http://{PROXY_HOST}:{proxy_manager.active_port}/?url={urllib.parse.quote_plus(stream_url)}"
            return proxy_url, proxy_manager
        else:
            logging.error("[VOD-PROXY] URL do stream está vazia.")
            return None, proxy_manager
    
    return None, proxy_manager

# Exporta as classes e funções necessárias para o addon.py
__all__ = ['VODProxyManager', 'resolve_vod_stream']