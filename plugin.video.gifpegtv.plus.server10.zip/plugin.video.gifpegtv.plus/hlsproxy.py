#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------------
# Proxy HLS Local TCP/HTTP Puro v9.7 (FAILOVER AUTOMÁTICO)
# -----------------------------------------------------------------------------------
# Objetivo: Baixa segmentos HLS via HTTP e os retransmite ao player nativo do Kodi.
# -----------------------------------------------------------------------------------
# CORREÇÕES (v9.7):
# 1. FAILOVER DE SEGMENTO: Se um segmento der Timeout na URL resolvida, o script
#    limpa o cache da URL imediatamente. Isso força o manifesto a buscar um novo
#    servidor na próxima atualização da playlist.
# 2. FAILOVER DE MANIFESTO: Se a conexão com a URL resolvida falhar (Timeout/Erro),
#    ele troca instantaneamente para a URL original dentro da mesma execução,
#    garantindo que o player não receba um erro 404/500.
# 3. TIMEOUTS: Ajustados para detectar servidores mortos mais rápido.
# -----------------------------------------------------------------------------------
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import json
import socket
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse, urljoin, quote, unquote_plus, parse_qs
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import ConnectionError, Timeout, ReadTimeout, RequestException, ChunkedEncodingError
from functools import lru_cache

# ---------------- MOCK KODI ----------------
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    def kodi_log(msg, level=xbmc.LOGINFO):
        if xbmc:
            xbmc.log(f"[HLSProxy] {msg}", level=level)
except ImportError:
    class MockKodi:
        def log(self, msg, level=None):
            print(f"[MOCK] {msg}")
        LOGINFO = 1
        LOGDEBUG = 0
        LOGWARNING = 2
        LOGERROR = 3
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    def kodi_log(msg, level=xbmc.LOGINFO):
        print(f"[HLSProxy] {msg}")
# ---------------- FIM MOCK KODI ----------------

# ---------------- CONFIGURAÇÕES ----------------
MAX_SEGMENT_RETRIES = 1
CONNECTION_TIMEOUT = 2.0 # Reduzido para falhar rápido se o server cair
READ_TIMEOUT = 4.0      # Reduzido para não travar o player esperando
SEGMENT_CACHE_SIZE = 30
MAX_PREFETCH_THREADS = 2
CIRCUIT_BREAKER_TIMEOUT = 30
SESSION_TIMEOUT_SECONDS = 60
MAX_ACTIVE_SESSIONS = 50

DEFAULT_CHUNK_SIZE = 128 * 1024
PROXY_HOST = '0.0.0.0'
HTTP_PORT = 8010
LOG_FILE = "hls_tcp_proxy.log"
MANIFEST_CACHE_TTL = 2 # Cache curto para streams ao vivo

USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.{version} Safari/537.36"
NULL_TS_PACKET = b'\x47\x1f\xff\x10' + (b'\xff' * 184)

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- ESTADO GLOBAL ----------------
MANIFEST_CACHE = {}
SESSION_STORE = {}
STATE_LOCK = threading.Lock()
PROXY_SERVER_INSTANCE = None
PROXY_SERVER_PORT = 0

# ---------------- UTILS & SETUP ----------------
def _generate_fake_ip():
    while True:
        octets = [random.randint(1, 254) for _ in range(4)]
        if (octets[0] == 10 or (octets[0] == 192 and octets[1] == 168) or
            (octets[0] == 172 and 16 <= octets[1] <= 31) or octets[0] == 127 or
            octets[0] == 0 or octets[0] >= 240):
            continue
        return ".".join(map(str, octets))

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

HOST_NAME_FOR_URLS = get_local_ip()

def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    if logger.hasHandlers():
        logger.handlers.clear()
    try:
        file_handler = logging.FileHandler(LOG_FILE, mode='w', encoding='utf-8')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception: pass
    logging.getLogger('urllib3').setLevel(logging.ERROR)
    logging.getLogger('requests').setLevel(logging.ERROR)

# ---------------- GERENCIAMENTO DE SESSÃO ----------------
class SessionManager:
    def __init__(self):
        self._cleanup_thread = threading.Thread(target=self._cleanup_idle_sessions_loop, daemon=True)
        self._cleanup_thread.start()

    def _create_new_session_entry(self, session_id, original_url, origin_host):
        session = requests.Session()
        adapter = HTTPAdapter(
            pool_connections=10,
            pool_maxsize=20,
            max_retries=Retry(total=1, backoff_factor=0.2, status_forcelist=[500, 502, 503, 504])
        )
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        ua_version = random.randint(1000, 9999)
        SESSION_STORE[session_id] = {
            'session': session,
            'original_url': original_url,   # URL Padrão
            'resolved_url': None,           # URL com Token (Cacheada)
            'origin_host': origin_host,
            'user_agent': USER_AGENT_TEMPLATE.format(version=ua_version),
            'fake_ip': _generate_fake_ip(),
            'last_rotation': time.time(),
            'last_activity_time': time.time(),
        }
        kodi_log(f"Sessão Iniciada: {session_id} -> {original_url}", xbmc.LOGDEBUG)

    def get_session_data(self, session_id, original_url=None, origin_host=None):
        with STATE_LOCK:
            if len(SESSION_STORE) >= MAX_ACTIVE_SESSIONS and session_id not in SESSION_STORE:
                raise Exception("Too many active sessions")

            if session_id not in SESSION_STORE:
                if not (original_url and origin_host):
                    raise Exception("Sessão não encontrada.")
                self._create_new_session_entry(session_id, original_url, origin_host)

            SESSION_STORE[session_id]['last_activity_time'] = time.time()
            return SESSION_STORE[session_id]

    def update_resolved_url(self, session_id, new_url):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                if SESSION_STORE[session_id]['resolved_url'] != new_url:
                    SESSION_STORE[session_id]['resolved_url'] = new_url
                    kodi_log(f"✅ URL Resolvida Cacheada: {new_url}", xbmc.LOGINFO)

    def clear_resolved_url(self, session_id):
        with STATE_LOCK:
            if session_id in SESSION_STORE and SESSION_STORE[session_id]['resolved_url']:
                SESSION_STORE[session_id]['resolved_url'] = None
                kodi_log(f"⚠️ URL Resolvida falhou. Resetando para Original.", xbmc.LOGWARNING)

    def rotate_credentials(self, session_id, force=False):
        with STATE_LOCK:
            if session_id not in SESSION_STORE: return False
            s_data = SESSION_STORE[session_id]
            now = time.time()
            if not force and now - s_data['last_rotation'] < 10: return False
            
            s_data['user_agent'] = USER_AGENT_TEMPLATE.format(version=random.randint(1000, 9999))
            s_data['fake_ip'] = _generate_fake_ip()
            s_data['last_rotation'] = now
            if session_id in MANIFEST_CACHE:
                del MANIFEST_CACHE[session_id]
            
            # Reset de token forçado
            s_data['resolved_url'] = None 
            kodi_log(f"🚨 Rotação de Credenciais: {session_id}", xbmc.LOGINFO)
            return True

    def _cleanup_idle_sessions_loop(self):
        while True:
            time.sleep(30)
            with STATE_LOCK:
                now = time.time()
                to_remove = []
                for sid, s_data in SESSION_STORE.items():
                    if now - s_data['last_activity_time'] > SESSION_TIMEOUT_SECONDS:
                        to_remove.append(sid)
                for sid in to_remove:
                    try: SESSION_STORE[sid]['session'].close()
                    except: pass
                    del SESSION_STORE[sid]
                    if sid in MANIFEST_CACHE: del MANIFEST_CACHE[sid]

session_manager = SessionManager()

# ---------------- BYPASS DE DPI ----------------
def generate_random_headers(user_agent=None, referer=None):
    headers = {
        'User-Agent': user_agent,
        'Accept': "*/*",
        'Accept-Language': "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        'Accept-Encoding': "gzip, deflate",
        'Connection': 'keep-alive',
        'Cache-Control': "no-cache",
        'DNT': "1",
        'X-Real-IP': _generate_fake_ip(),
        'Upgrade-Insecure-Requests': '1',
    }
    if referer: headers['Referer'] = referer
    return {k: v for k, v in headers.items() if v is not None}

# ---------------- CACHE DE SEGMENTOS ----------------
@lru_cache(maxsize=SEGMENT_CACHE_SIZE)
def fetch_and_cache_segment(session_id, segment_url):
    try:
        s_data = session_manager.get_session_data(session_id)
        host_segment = urlparse(segment_url).netloc
        headers = generate_random_headers(s_data['user_agent'], f"http://{host_segment}/")
        headers['X-Forwarded-For'] = s_data['fake_ip']
        
        temp_session = requests.Session()
        adapter = HTTPAdapter(max_retries=Retry(total=0)) # Sem retries aqui, queremos rapidez
        temp_session.mount('http://', adapter)
        
        r = temp_session.get(segment_url, headers=headers, timeout=(CONNECTION_TIMEOUT, READ_TIMEOUT), verify=False)
        if r.status_code == 200: return r.content
        return None
    except Exception: return None
    finally: temp_session.close()

# ---------------- HTTP SERVER ----------------
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class ProxyHTTPHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args): return

    def get_safe_manifest(self):
        return """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:1
#EXT-X-MEDIA-SEQUENCE:1
#EXTINF:1.0,
http://{}:{}/dummy_wait_segment.ts
""".format(HOST_NAME_FOR_URLS, PROXY_SERVER_PORT).encode('utf-8')

    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        query = parse_qs(parsed_url.query)
        try:
            if path.startswith('/play/') and path.endswith('/index.m3u8'):
                self.proxy_manifest(path)
            elif path == '/stream':
                self.proxy_segment(query)
            elif path == '/dummy_wait_segment.ts':
                self._send_null_packets(100)
            elif path == '/':
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"HLS Proxy Active v9.7")
            else:
                self.send_error(404)
        except Exception:
            try: self.send_error(500)
            except: pass

    def proxy_manifest(self, path):
        try:
            session_id = path.split('/')[2]
            s_data = session_manager.get_session_data(session_id)
        except Exception:
            self._send_safe_manifest()
            return

        now = time.time()
        cache = MANIFEST_CACHE.get(session_id)
        if cache and (now - cache['timestamp'] < MANIFEST_CACHE_TTL):
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            try: self.wfile.write(cache['content'])
            except: pass
            return

        # --- LÓGICA DE FAILOVER DE URL ---
        # 1. Tenta URL Resolvida (se existir)
        # 2. Se falhar, reseta e usa Original na mesma chamada
        
        active_url = s_data['resolved_url'] if s_data['resolved_url'] else s_data['original_url']
        final_content = None
        base_url = None
        
        try:
            # Tentativa Principal
            current_host = urlparse(active_url).netloc
            headers = generate_random_headers(s_data['user_agent'], f"http://{current_host}/")
            headers['X-Forwarded-For'] = s_data['fake_ip']
            
            r = s_data['session'].get(active_url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
            
            if r.status_code == 200:
                final_content = r.text
                base_url = r.url
                # Se usou original e redirecionou, salva a nova
                if s_data['resolved_url'] is None and base_url != s_data['original_url']:
                    session_manager.update_resolved_url(session_id, base_url)
            elif r.status_code in [401, 403, 404, 500, 502]:
                raise RequestException(f"Status ruim: {r.status_code}")

        except (RequestException, Timeout, ConnectionError) as e:
            # SE FALHOU:
            kodi_log(f"Falha na URL Ativa ({active_url}): {e}", xbmc.LOGWARNING)
            
            # Se estavamos usando a resolvida e ela falhou, tentamos a original IMEDIATAMENTE
            if s_data['resolved_url']:
                session_manager.clear_resolved_url(session_id) # Limpa cache ruim
                active_url = s_data['original_url'] # Fallback
                
                try:
                    kodi_log(f"Tentando reconexão na Original: {active_url}", xbmc.LOGINFO)
                    session_manager.rotate_credentials(session_id, force=True) # Novo IP/UA para garantir
                    
                    # Recria headers para nova tentativa
                    current_host = urlparse(active_url).netloc
                    headers = generate_random_headers(s_data['user_agent'], f"http://{current_host}/")
                    
                    r2 = s_data['session'].get(active_url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                    if r2.status_code == 200:
                        final_content = r2.text
                        base_url = r2.url
                        if base_url != s_data['original_url']:
                            session_manager.update_resolved_url(session_id, base_url)
                except Exception as e2:
                    kodi_log(f"Falha total no fallback: {e2}", xbmc.LOGERROR)

        if not final_content:
            self._send_safe_manifest()
            return

        # Processamento e Resposta
        try:
            new_lines = []
            for line in final_content.splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    new_lines.append(line)
                    continue
                
                full_url = urljoin(base_url, line)
                enc_url = quote(full_url, safe='')
                proxy_url = f"http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}/stream?url={enc_url}&sid={session_id}"
                new_lines.append(proxy_url)
                
            resp_data = "\n".join(new_lines).encode('utf-8')
            MANIFEST_CACHE[session_id] = {'content': resp_data, 'timestamp': now}
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            self.wfile.write(resp_data)
            
        except Exception:
            self._send_safe_manifest()

    def proxy_segment(self, query):
        url = query.get('url', [None])[0]
        sid = query.get('sid', [None])[0]
        
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.end_headers()
        except: return

        if not url or not sid:
            self._send_null_packets(10)
            return
            
        url = unquote_plus(url)
        
        cached = fetch_and_cache_segment(sid, url)
        if cached:
            try: self.wfile.write(cached)
            except: pass
            return

        try:
            s_data = session_manager.get_session_data(sid)
            seg_host = urlparse(url).netloc
            headers = generate_random_headers(s_data['user_agent'], f"http://{seg_host}/")
            headers['X-Forwarded-For'] = s_data['fake_ip']
            
            with s_data['session'].get(url, headers=headers, stream=True, timeout=(CONNECTION_TIMEOUT, READ_TIMEOUT), verify=False) as r:
                if r.status_code == 200:
                    for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        if chunk: self.wfile.write(chunk)
                elif r.status_code in [401, 403]:
                    # 403 no segmento = Token Expirado
                    session_manager.clear_resolved_url(sid)
                    self._send_null_packets(50)
                else:
                    self._send_null_packets(50)

        except (Timeout, ConnectionError, ReadTimeout) as e:
            # TIMEOUT NO SEGMENTO = SERVIDOR MORTO
            # Ação: Limpar URL Resolvida IMEDIATAMENTE
            kodi_log(f"Timeout Segmento: {e}. Resetando URL Resolvida.", xbmc.LOGWARNING)
            session_manager.clear_resolved_url(sid)
            self._send_null_packets(50)
        except Exception:
            self._send_null_packets(50)

    def _send_null_packets(self, count):
        try: self.wfile.write(NULL_TS_PACKET * count)
        except: pass
        
    def _send_safe_manifest(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.end_headers()
        try: self.wfile.write(self.get_safe_manifest())
        except: pass

# ---------------- CONTROLLER ----------------
class ProxyController:
    def __init__(self):
        self.lock = threading.Lock()
    def find_available_port(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind((PROXY_HOST, 0))
            port = s.getsockname()[1]
            s.close()
            return port
        except: return HTTP_PORT

    def start(self):
        global PROXY_SERVER_INSTANCE, PROXY_SERVER_PORT
        with self.lock:
            if PROXY_SERVER_INSTANCE: return True
            PROXY_SERVER_PORT = self.find_available_port()
            try:
                PROXY_SERVER_INSTANCE = ThreadedHTTPServer((PROXY_HOST, PROXY_SERVER_PORT), ProxyHTTPHandler)
                threading.Thread(target=PROXY_SERVER_INSTANCE.serve_forever, daemon=True).start()
                kodi_log(f"Proxy START: {PROXY_SERVER_PORT}", xbmc.LOGINFO)
                return True
            except: return False

    def stop(self):
        global PROXY_SERVER_INSTANCE
        with self.lock:
            if PROXY_SERVER_INSTANCE:
                PROXY_SERVER_INSTANCE.shutdown()
                PROXY_SERVER_INSTANCE = None

_proxy_controller = ProxyController()

class HLSAddon:
    def __init__(self, handle=None):
        self.handle = handle

    def get_proxy_url(self, target_url):
        global PROXY_SERVER_PORT
        if not _proxy_controller.start(): return target_url
        
        session_id = str(abs(hash(target_url)))
        origin_host = urlparse(target_url).netloc
        
        try: session_manager.get_session_data(session_id, target_url, origin_host)
        except: return target_url
            
        return f"http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}/play/{session_id}/index.m3u8"

    def play_stream(self, url, stream_type=None):
        if not xbmcgui: return
        try:
            kodi_log(f"Reproduzindo: {url} (Type: {stream_type})", xbmc.LOGDEBUG)
            proxy_url = self.get_proxy_url(url)
            li = xbmcgui.ListItem(path=proxy_url)
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setProperty('IsLive', 'true')
            if self.handle: xbmcplugin.setResolvedUrl(int(self.handle), True, li)
            else: xbmc.Player().play(proxy_url, li)
        except: pass

if __name__ == '__main__':
    setup_logging()
    _proxy_controller.start()
    print(f"Proxy Rodando em: http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}")
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        _proxy_controller.stop()