# -*- coding: utf-8 -*-
import sys, threading, urllib.parse, warnings, time, random, io, ipaddress, errno
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple
import xbmc, xbmcgui, xbmcplugin
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException
from urllib3.util.retry import Retry
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

# ---------------- CONFIG ----------------
@dataclass(frozen=True)
class ProxyConfig:
    max_retries: int = 4
    retry_backoff_factor: float = 0.6
    connection_timeout: int = 15  # Aumentar timeout de conexão
    stream_timeout: float = 30    # Aumentar timeout de stream
    chunk_size: int = 64 * 1024
    buffer_size: int = 1 * 1024 * 1024
    max_reconnect_attempts: int = 4
    default_headers: Dict[str, str] = field(default_factory=lambda: {
        'User-Agent': 'VLC/3.0.20',
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
    })
    verify_ssl: bool = False

USER_AGENTS = [
    'VLC/3.0.20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/116',
    'AppleCoreMedia/1.0.0 (Apple TV)', 'curl/7.68.0', 'Lavf/58.76.100'
]

CLOUDFLARE_DOH_URL = 'https://cloudflare-dns.com/dns-query'
PROXY_CONFIG = ProxyConfig()
PROXY_MANAGER = None
DOH_CACHE: Dict[str, Tuple[str, float]] = {}
DOH_TTL_SECONDS = 7200

# ---------------- UTILS ----------------
def is_ip(host: str) -> bool:
    try: 
        ipaddress.ip_address(host.split(':')[0])
        return True
    except ValueError: 
        return False

def resolve_doh(url: str, session: Optional[requests.Session] = None) -> str:
    try:
        parsed = urllib.parse.urlparse(url)
        host = parsed.netloc.split(':')[0]
        if is_ip(host): 
            return url
        if host in DOH_CACHE:
            ip, exp = DOH_CACHE[host]
            if time.time() < exp:
                return parsed._replace(netloc=parsed.netloc.replace(host, ip)).geturl()
            DOH_CACHE.pop(host, None)
        resp = (session or requests).get(
            CLOUDFLARE_DOH_URL,
            headers={'accept': 'application/dns-json'},
            params={'name': host, 'type': 'A'}, 
            timeout=5  # Aumentar timeout DOH
        )
        data = resp.json()
        ip = next((r['data'] for r in data.get('Answer',[]) if r.get('type')==1), None)
        if ip: 
            DOH_CACHE[host] = (ip, time.time()+DOH_TTL_SECONDS)
            return parsed._replace(netloc=parsed.netloc.replace(host, ip)).geturl()
    except Exception as e:
        xbmc.log(f"Erro DOH: {e}", xbmc.LOGDEBUG)
        pass
    return url

def create_session(ua: str) -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=PROXY_CONFIG.max_retries,
        backoff_factor=PROXY_CONFIG.retry_backoff_factor,
        status_forcelist=[429,500,502,503,504],
        allowed_methods=["GET","HEAD"]
    )
    adapter = HTTPAdapter(
        pool_connections=20,  # Aumentar pool de conexões
        pool_maxsize=20,
        pool_block=True,
        max_retries=retry
    )
    s.mount('http://', adapter)
    s.mount('https://', adapter)
    s.verify = False
    s.stream = True
    s.trust_env = False
    s.headers.update({'User-Agent': ua})
    warnings.filterwarnings('ignore', 'Unverified HTTPS request')
    return s

def rand_ua() -> str: 
    return random.choice(USER_AGENTS)

# ---------------- M3U8 PROCESSOR ----------------
def process_m3u8(content: str, base_url: str) -> str:
    lines = content.splitlines()
    processed = []
    parsed = urllib.parse.urlparse(base_url)
    root = f"{parsed.scheme}://{parsed.netloc}"
    base_path = base_url.rsplit("/", 1)[0]

    for line in lines:
        if not line or line.startswith("#"):
            if line.startswith("#EXT-X-KEY") and "URI=" in line:
                key_uri = line.split("URI=")[1].split('"')[1]
                abs_url = key_uri if key_uri.startswith("http") else (
                    root + key_uri if key_uri.startswith("/") else f"{base_path}/{key_uri}"
                )
                proxied = PROXY_MANAGER.url(resolve_doh(abs_url)) or abs_url
                line = line.replace(key_uri, proxied)
            processed.append(line)
            continue

        # Processar linha de segmento
        abs_url = line if line.startswith("http") else (
            root + line if line.startswith("/") else f"{base_path}/{line}"
        )
        proxied = PROXY_MANAGER.url(resolve_doh(abs_url)) or abs_url
        processed.append(proxied)

    return "\n".join(processed)

# ---------------- PROXY CORE ----------------
class HLSProxyManager:
    def __init__(self): 
        self._server = None
        self._port = None
        self._lock = threading.Lock()
    
    def start(self, pr=(15000,15099)):
        with self._lock:
            if self._server: 
                return True
            for port in range(pr[0], pr[1]+1):
                try:
                    self._port = port
                    self._server = ThreadedHTTPServer(('127.0.0.1', port), ProxyHandler)
                    threading.Thread(target=self._server.serve_forever, daemon=True).start()
                    xbmc.log(f"HLS Proxy iniciado na porta {port}", xbmc.LOGINFO)
                    return True
                except OSError: 
                    continue
            return False
    
    def stop(self):
        if self._server: 
            self._server.shutdown()
            self._server.server_close()
            self._server = None
    
    def url(self, tgt: str) -> Optional[str]:
        return f"http://127.0.0.1:{self._port}/?url={urllib.parse.quote_plus(tgt)}" if self._port else None

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer): 
    daemon_threads = True
    allow_reuse_address = True

class ProxyHandler(BaseHTTPRequestHandler):
    timeout = 30  # Aumentar timeout do handler
    
    def do_GET(self): 
        self._handle()
    
    def do_HEAD(self): 
        self._handle()
    
    def _handle(self):
        try:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if 'url' not in qs: 
                self.send_error(400, "URL ausente")
                return
            
            url = urllib.parse.unquote_plus(qs['url'][0])
            is_manifest = '.m3u8' in url.lower()
            
            resp = self._fetch(url, is_manifest)
            if not resp: 
                self.send_error(502, "Falha backend")
                return
            
            self.send_response(resp.status_code)
            
            # Filtrar headers sensíveis
            for k, v in resp.headers.items():
                if k.lower() not in ['connection', 'transfer-encoding', 'content-encoding']:
                    self.send_header(k, v)
            
            self.end_headers()
            
            if self.command == 'HEAD': 
                resp.close()
                return

            try:
                if is_manifest or "mpegurl" in resp.headers.get("content-type", "").lower():
                    processed = process_m3u8(resp.text, resp.url)
                    self.wfile.write(processed.encode("utf-8"))
                else:
                    # Melhorado streaming de vídeo
                    for chunk in resp.iter_content(chunk_size=PROXY_CONFIG.chunk_size):
                        if not chunk: 
                            continue
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError) as e:
                            xbmc.log(f"Cliente desconectado: {e}", xbmc.LOGDEBUG)
                            break
            except (BrokenPipeError, ConnectionResetError) as e:
                xbmc.log(f"Cliente desconectado durante transmissão: {e}", xbmc.LOGDEBUG)
            finally:
                resp.close()
                
        except (BrokenPipeError, ConnectionResetError) as e:
            xbmc.log(f"Cliente desconectado: {e}", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"Proxy erro: {e}", xbmc.LOGERROR)
            try:
                self.send_error(500, str(e))
            except (BrokenPipeError, ConnectionResetError):
                pass  # Cliente já desconectou, ignorar erro
    
    def _fetch(self, url, is_manifest):
        parsed = urllib.parse.urlparse(url)
        host = parsed.netloc
        
        for attempt in range(PROXY_CONFIG.max_reconnect_attempts):
            try:
                ua = rand_ua()
                s = create_session(ua)
                headers = dict(PROXY_CONFIG.default_headers)
                headers.update({
                    'User-Agent': ua,
                    'Host': host,
                    'Referer': f"{parsed.scheme}://{parsed.netloc}/"
                })
                
                req_url = resolve_doh(url, s)
                return s.request(
                    self.command,
                    req_url,
                    headers=headers,
                    timeout=(PROXY_CONFIG.connection_timeout, PROXY_CONFIG.stream_timeout),
                    stream=True
                )
            except RequestException as e:
                xbmc.log(f"Tentativa {attempt+1} falhou: {e}", xbmc.LOGDEBUG)
                if attempt == PROXY_CONFIG.max_reconnect_attempts - 1:
                    xbmc.log(f"Máximo de tentativas atingido para {url}", xbmc.LOGERROR)
                time.sleep(min(2 ** attempt, 5))  # Backoff exponencial, máximo 5s
        
        return None

# ---------------- ADDON ----------------
class HLSProxyAddon:
    def __init__(self, h): 
        self.h = h
    
    def play_stream(self, url: str, title='Stream HLS'):
        global PROXY_MANAGER
        if not PROXY_MANAGER: 
            PROXY_MANAGER = HLSProxyManager()
        
        if not PROXY_MANAGER.start(): 
            xbmcgui.Dialog().notification("Erro Proxy", "Falha ao iniciar", xbmcgui.NOTIFICATION_ERROR)
            return
        
        pu = PROXY_MANAGER.url(url)
        if not pu: 
            xbmcgui.Dialog().notification("Erro Proxy", "URL Proxy inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        li = xbmcgui.ListItem(title, path=pu)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(self.h, True, li)

if __name__ == '__main__':
    h = -1
    try:
        h = int(sys.argv[1])
        args = urllib.parse.parse_qs(sys.argv[2][1:] if len(sys.argv) > 2 else '')
        
        if args.get('action', [None])[0] in ['play', 'play_stream'] and args.get('url', [None])[0]:
            HLSProxyAddon(h).play_stream(
                args['url'][0],
                args.get('title', ['Stream HLS'])[0]
            )
        else: 
            xbmcplugin.endOfDirectory(h, succeeded=False)
    except Exception as e: 
        xbmc.log(f"Erro no addon: {e}", xbmc.LOGERROR)
        if h != -1: 
            xbmcplugin.endOfDirectory(h, succeeded=False)