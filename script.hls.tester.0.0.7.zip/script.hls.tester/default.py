# -*- coding: utf-8 -*-
"""
HLS Proxy para Kodi usando Flask (script.module.flask)
Suporte a plugin://script.hls.tester/?action=play&url=<HLS_URL>
Com suporte a DNS-over-HTTPS via script.module.netunblock
"""

# ==============================================================================
# IMPORTS
# ==============================================================================
import sys
import os
import threading
import time
import random
import logging
import logging.handlers
import urllib.parse
from collections import OrderedDict
from typing import Optional, Dict, Any

# KODI
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# REDE (usa netunblock)
import m3u8
from doh_client import requests   # <<< INTEGRAÇÃO DNS-OVER-HTTPS
from werkzeug.serving import make_server

# ==============================================================================
# FLASK (script.module.flask)
# ==============================================================================
try:
    from flask import Flask, Response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro de Dependência",
                        "O addon 'script.module.flask' não foi encontrado. "
                        "Instale-o para que o HLS Proxy funcione.")
    sys.exit(1)

# ==============================================================================
# CONFIG
# ==============================================================================
PROXY_HOST = "127.0.0.1"
MAX_PORT_ATTEMPTS = 15
CONNECTION_TIMEOUT = 8
STREAM_TIMEOUT = 15
DEFAULT_CHUNK_SIZE = 256 * 1024
MAX_CACHE_MB = 64
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
FETCHER_MAX_RETRIES = 4
RETRY_BACKOFF_FACTOR = 0.3
MAX_BACKOFF_TIME = 20

USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0",
    "Kodi/20.0 (Windows NT 10.0; Win64; x64)"
]

LOG_FILE = xbmcvfs.translatePath("special://temp/hlstester.log")
LOG_MAX_BYTES = 5 * 1024 * 1024
LOG_BACKUP_COUNT = 2
LOG_LEVEL = logging.DEBUG

SENSITIVE_HEADERS = {
    "X-Forwarded-For", "Forwarded", "Via", "X-Real-IP",
    "Client-IP", "X-Client-IP", "X-Cluster-Client-IP",
    "Content-Length", "Connection", "Transfer-Encoding"
}
SENSITIVE_HEADERS_LOWER = {h.lower() for h in SENSITIVE_HEADERS}

# ==============================================================================
# LOGGING
# ==============================================================================
def setup_logging():
    handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT, encoding="utf-8"
    )
    logging.basicConfig(
        handlers=[handler],
        level=LOG_LEVEL,
        format="%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s",
        force=True
    )

    # Silencia logs verbosos do requests e urllib3
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)

setup_logging()

# ==============================================================================
# UTILS
# ==============================================================================
def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "*/*",
        "Origin": origin,
        "Referer": origin
    }

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")):
        return "application/vnd.apple.mpegurl"
    if path.endswith(".ts"):
        return "video/mp2t"
    if path.endswith(".aac"):
        return "audio/aac"
    if path.endswith(".mp4"):
        return "video/mp4"
    return "application/octet-stream"

def calculate_backoff(attempt: int) -> float:
    base = RETRY_BACKOFF_FACTOR * (2 ** min(attempt, 5))
    backoff = min(base, MAX_BACKOFF_TIME)
    jitter = random.uniform(-0.3, 0.3) * backoff
    return max(0.1, backoff + jitter)

# ==============================================================================
# CACHE
# ==============================================================================
class RotatingChunkCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.chunks: OrderedDict[str, bytes] = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
            return data

    def add(self, url: str, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
            if len(data) > self.max_bytes:
                return
            self.chunks[url] = data
            self.total_bytes += len(data)
            self._evict()

    def _evict(self):
        while self.total_bytes > self.max_bytes and len(self.chunks) > 1:
            _, data = self.chunks.popitem(last=False)
            self.total_bytes -= len(data)

# ==============================================================================
# FETCHER
# ==============================================================================
class UpstreamFetcher:
    def __init__(self):
        self.session = requests   # agora usa DoH

    def fetch(self, url: str, stream: bool = False, headers: Optional[Dict] = None):
        h = get_player_headers(url)
        if headers:
            h.update(clean_headers(headers))
        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    url, stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=h, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                return resp
            except Exception as e:
                logging.warning(f"Erro fetch ({attempt+1}) {url}: {e}")
                if attempt < FETCHER_MAX_RETRIES:
                    time.sleep(calculate_backoff(attempt))
                else:
                    raise

# ==============================================================================
# PROXY MANAGER
# ==============================================================================
class HLSProxyManager:
    def __init__(self):
        self.cache = RotatingChunkCache()
        self.fetcher = UpstreamFetcher()
        self.app = Flask(__name__)
        self.server = None
        self.thread = None
        self.port = None
        self._setup_routes()

    def _setup_routes(self):
        @self.app.route("/health")
        def health():
            return {"status": "ok", "port": self.port}

        @self.app.route("/manifest/<path:url>")
        def manifest(url):
            real_url = urllib.parse.unquote_plus(url)
            try:
                resp = self.fetcher.fetch(real_url)
                content = resp.text
                m3u8_obj = m3u8.loads(content, uri=real_url)

                for seg in m3u8_obj.segments:
                    seg.uri = f"http://{PROXY_HOST}:{self.port}/proxy/" + urllib.parse.quote_plus(seg.absolute_uri)
                for playlist in m3u8_obj.playlists:
                    playlist.uri = f"http://{PROXY_HOST}:{self.port}/manifest/" + urllib.parse.quote_plus(playlist.absolute_uri)
                for media in m3u8_obj.media:
                    if media.uri:
                        media.uri = f"http://{PROXY_HOST}:{self.port}/manifest/" + urllib.parse.quote_plus(media.absolute_uri)
                for seg in m3u8_obj.segments:
                    if seg.key and seg.key.uri and not seg.key.uri.startswith("data:"):
                        seg.key.uri = f"http://{PROXY_HOST}:{self.port}/proxy/" + urllib.parse.quote_plus(seg.key.absolute_uri)

                return Response(m3u8_obj.dumps(), mimetype="application/vnd.apple.mpegurl")
            except Exception as e:
                logging.error(f"Erro manifest: {e}")
                return Response("#EXTM3U\n", status=502, mimetype="application/vnd.apple.mpegurl")

        @self.app.route("/proxy/<path:url>")
        def proxy(url):
            real_url = urllib.parse.unquote_plus(url)
            cached = self.cache.get(real_url)
            if cached:
                return Response(cached, mimetype=safe_mime_type(real_url))

            try:
                upstream = self.fetcher.fetch(real_url, stream=True)
                def generate():
                    data = bytearray()
                    for chunk in upstream.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        if chunk:
                            data.extend(chunk)
                            yield chunk
                    self.cache.add(real_url, bytes(data))
                return Response(stream_with_context(generate()), mimetype=safe_mime_type(real_url))
            except Exception as e:
                logging.error(f"Erro segmento: {e}")
                return Response(b"", status=502, mimetype="application/octet-stream")

    def start(self):
        for port in range(5050, 5050 + MAX_PORT_ATTEMPTS):
            try:
                self.server = make_server(PROXY_HOST, port, self.app)
                self.port = port
                break
            except OSError:
                continue
        if not self.server:
            raise RuntimeError("Não conseguiu iniciar proxy")

        def run():
            self.server.serve_forever()

        self.thread = threading.Thread(target=run, daemon=True)
        self.thread.start()
        logging.info(f"HLS Proxy rodando em http://{PROXY_HOST}:{self.port}")

# ==============================================================================
# PLUGIN ROUTER (Kodi)
# ==============================================================================
proxy_instance = None

def get_proxy():
    global proxy_instance
    if proxy_instance is None:
        proxy_instance = HLSProxyManager()
        proxy_instance.start()
    return proxy_instance

def router(params: dict):
    action = params.get("action")

    if action == "play":
        url = params.get("url")
        if not url:
            xbmcgui.Dialog().notification("HLS Tester", "Nenhuma URL recebida", xbmcgui.NOTIFICATION_ERROR)
            return

        p = get_proxy()
        encoded = urllib.parse.quote_plus(url)
        final_url = f"http://{PROXY_HOST}:{p.port}/manifest/{encoded}"

        li = xbmcgui.ListItem(path=final_url)
        li.setMimeType("application/x-mpegURL")
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.open_mode", "curl")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
        li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        logging.info(f"[HLS TESTER] Tocando via proxy: {final_url}")

    else:
        xbmcgui.Dialog().notification("HLS Tester", "Ação inválida", xbmcgui.NOTIFICATION_ERROR)

# ==============================================================================
# MAIN
# ==============================================================================
if __name__ == "__main__":
    if len(sys.argv) > 2:
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        router(params)
    else:
        xbmcgui.Dialog().ok("HLS Tester", "Use plugin://script.hls.tester/?action=play&url=<link>")