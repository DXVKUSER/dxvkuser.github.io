# -*- coding: utf-8 -*-

import sys
import threading
import time
import re
import socket
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer
from queue import Empty, Full, Queue
from socketserver import ThreadingMixIn
from urllib.parse import parse_qsl, urlparse, urljoin, quote, unquote
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from typing import Optional, Dict, List, Tuple, Union
from collections import OrderedDict
import urllib.parse

# --- Resolvedor DoH (DNS-over-HTTPS) otimizado para Cloudflare ---
DOH_RESOLVER_URL = 'https://cloudflare-dns.com/dns-query'
DNS_CACHE: Dict[str, Tuple[str, float]] = {}
DNS_CACHE_TTL = 300  # 5 minutos

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

def get_setting_int(setting_id: str, default_value: int) -> int:
    try:
        return int(ADDON.getSetting(setting_id))
    except (ValueError, TypeError):
        return default_value

def get_setting_float(setting_id: str, default_value: float) -> float:
    try:
        return float(ADDON.getSetting(setting_id))
    except (ValueError, TypeError):
        return default_value

def get_setting_bool(setting_id: str, default_value: bool) -> bool:
    try:
        return ADDON.getSettingBool(setting_id)
    except Exception:
        return default_value

def resolve_hostname_doh(hostname: str) -> Optional[str]:
    now = time.time()
    cached = DNS_CACHE.get(hostname)
    if cached and now < cached[1]:
        return cached[0]

    headers = {'accept': 'application/dns-json'}
    params = {'name': hostname, 'type': 'A'}
    try:
        resp = requests.get(DOH_RESOLVER_URL, headers=headers, params=params, timeout=2)
        resp.raise_for_status()
        data = resp.json()
        if data.get("Status") == 0 and "Answer" in data:
            for answer in data["Answer"]:
                if answer.get("type") == 1:
                    ip = answer.get("data")
                    DNS_CACHE[hostname] = (ip, now + DNS_CACHE_TTL)
                    xbmc.log(f"[IPTV PROXY DOH] {hostname} => {ip}", xbmc.LOGINFO)
                    return ip
    except Exception as e:
        xbmc.log(f"[IPTV PROXY DOH] Erro ao resolver {hostname} via DoH: {e}", xbmc.LOGWARNING)
    return None

def get_url_with_resolved_ip(url: str) -> str:
    try:
        parsed = urlparse(url)
        if not parsed.hostname: return url
        
        ip = resolve_hostname_doh(parsed.hostname) if get_setting_bool('enable_doh', False) else None
        if not ip:
            try:
                ip = socket.gethostbyname(parsed.hostname)
            except socket.gaierror:
                return url

        if ip and parsed.hostname != ip:
            netloc = ip
            if parsed.port: netloc += f":{parsed.port}"
            if parsed.username:
                netloc = f"{parsed.username}:{parsed.password or ''}@{netloc}"
            return parsed._replace(netloc=netloc).geturl()
    except Exception:
        pass
    return url

DEFAULT_CHROME_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Encoding': 'identity', # 'identity' para evitar descompressão automática
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
}

REQUEST_RETRIES = max(get_setting_int('request_retries', 8), 4)
REQUEST_TIMEOUT = max(get_setting_float('request_timeout', 12.0), 8.0)
CONNECTION_POOL_SIZE = max(get_setting_int('connection_pool_size', 8), 6)

# Variáveis para inputstream.ffmpegdirect (agora lidas de settings.xml)
FFMPEG_LIVE_THRESHOLD = str(get_setting_int('ffmpeg_live_threshold', 15))
FFMPEG_LOW_DELAY = str(get_setting_bool('ffmpeg_low_delay', True)).lower()
FFMPEG_CONNECT_TIMEOUT = str(get_setting_float('ffmpeg_http_connect_timeout', 12.0))
FFMPEG_READ_TIMEOUT = str(get_setting_float('ffmpeg_http_read_timeout', 24.0)) # Default 2x connect timeout
FFMPEG_RECONNECT_ON_ERROR = str(get_setting_bool('ffmpeg_reconnect_on_error', True)).lower()
FFMPEG_FAST_SEEK = str(get_setting_bool('ffmpeg_fast_seek', True)).lower()
FFMPEG_CHUNK_SIZE = str(int(get_setting_float('ffmpeg_chunk_size_mb', 1.0) * 1024 * 1024)) # Convert MB to bytes
MAX_BITRATE = 0 # 0 para ilimitado, ou um valor específico em bps (ex: 5000000 para 5Mbps)


BLOCKED_RESPONSE_HEADERS = ['transfer-encoding', 'connection', 'content-encoding', 'keep-alive']

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class LRUCache:
    def __init__(self, capacity_bytes: int):
        self.capacity = capacity_bytes
        self.cache = OrderedDict()
        self.current_size = 0
        self.lock = threading.Lock()

    def get(self, key: str) -> Optional[bytes]:
        with self.lock:
            if key not in self.cache: return None
            self.cache.move_to_end(key)
            return self.cache[key]

    def put(self, key: str, value: bytes):
        with self.lock:
            value_size = sys.getsizeof(value)
            if value_size > self.capacity: return

            if key in self.cache:
                self.current_size -= sys.getsizeof(self.cache[key])
                self.cache.pop(key)

            while self.current_size + value_size > self.capacity:
                oldest_key, oldest_value = self.cache.popitem(last=False)
                self.current_size -= sys.getsizeof(oldest_value)
            
            self.cache[key] = value
            self.current_size += value_size
    def clear(self):
        with self.lock:
            self.cache.clear()
            self.current_size = 0

class ConnectionPool:
    def __init__(self, size=CONNECTION_POOL_SIZE):
        self.pool = Queue(maxsize=size)
        self.size = size
        for _ in range(self.size):
            self._add_session()

    def _add_session(self):
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=self.size, pool_maxsize=self.size*2)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        try: self.pool.put_nowait(session)
        except Full: session.close()

    def get_session(self) -> requests.Session:
        try: return self.pool.get(timeout=2)
        except Empty:
            self._add_session()
            return self.pool.get()

    def return_session(self, session: requests.Session):
        try: self.pool.put_nowait(session)
        except Full: session.close()

class StreamProxy:
    _instance: Optional['StreamProxy'] = None
    _lock = threading.Lock()

    def __init__(self, stream_url: str):
        self.original_stream_url = stream_url
        self.stop_event = threading.Event()
        self.server: Optional[ThreadedHTTPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.local_port: Optional[int] = None
        self.connection_pool = ConnectionPool()
        self.video_cache = LRUCache(capacity_bytes=20 * 1024 * 1024)

    def _fetch_url(self, url: str, session: requests.Session, headers: Optional[Dict] = None, stream=False):
        req_headers = DEFAULT_CHROME_HEADERS.copy()
        if 'Host' not in req_headers:
            req_headers['Host'] = urlparse(self.original_stream_url).hostname
        if headers: req_headers.update(headers)
        
        url_to_fetch = get_url_with_resolved_ip(url)
        for attempt in range(REQUEST_RETRIES):
            if self.stop_event.is_set(): return None, "Proxy parado"
            try:
                response = session.get(url_to_fetch, headers=req_headers, stream=stream, timeout=REQUEST_TIMEOUT, allow_redirects=True)
                response.raise_for_status()
                return response, None
            except requests.exceptions.RequestException as e:
                if hasattr(e, 'response') and e.response and 400 <= e.response.status_code < 500:
                    return None, f"Erro de Cliente: {e.response.status_code}"
                time.sleep(0.1 * (2 ** attempt))
        return None, f"Falha ao buscar {url} após {REQUEST_RETRIES} tentativas."

    def _ts_brute_stream(self, ts_url: str, handler):
        """
        MODO DE RECONEXÃO FORÇADA (VOD SIMULADO):
        Esta função conecta-se à URL .ts de forma persistente. Se a conexão
        cair ou o servidor parar de enviar dados, ela tentará se reconectar
        imediatamente para continuar o stream, tornando-o contínuo para o Kodi.
        """
        session = self.connection_pool.get_session()
        start_byte = 0
        headers_sent = False
        consecutive_failures = 0
        max_consecutive_failures = 10 # Tentativas antes de reiniciar do zero

        while not self.stop_event.is_set():
            if consecutive_failures >= max_consecutive_failures:
                xbmc.log(f"[IPTV PROXY] Muitas falhas seguidas. REINICIANDO stream do byte 0 para {ts_url}", xbmc.LOGWARNING)
                start_byte = 0
                consecutive_failures = 0
                headers_sent = False # Precisa reenviar os headers
                time.sleep(1) # Pausa antes de reiniciar

            req_headers = DEFAULT_CHROME_HEADERS.copy()
            req_headers['Host'] = urlparse(self.original_stream_url).hostname
            req_headers['Range'] = f'bytes={start_byte}-'
            
            url_to_fetch = get_url_with_resolved_ip(ts_url)
            
            try:
                response = session.get(url_to_fetch, headers=req_headers, stream=True, timeout=REQUEST_TIMEOUT)
                response.raise_for_status()
                
                consecutive_failures = 0 # Reseta falhas no sucesso

                if not headers_sent:
                    # Envia status 200 OK para o Kodi, escondendo o 206 (Partial Content) do servidor
                    handler.send_response(200)
                    # Copia os headers relevantes (Content-Type), mas ignora os que podem quebrar o streaming
                    for h_key, h_val in response.headers.items():
                        if h_key.lower() not in BLOCKED_RESPONSE_HEADERS:
                             handler.send_header(h_key, h_val)
                    if 'content-type' not in response.headers:
                        handler.send_header('Content-Type', 'video/mp2t') # Default para .ts
                    handler.end_headers()
                    headers_sent = True

                stream_ended = True
                for chunk in response.iter_content(chunk_size=int(FFMPEG_CHUNK_SIZE)):
                    if chunk:
                        stream_ended = False
                        handler.wfile.write(chunk)
                        start_byte += len(chunk)
                
                response.close()

                if stream_ended:
                    xbmc.log(f"[IPTV PROXY] Stream de dados de {ts_url} terminou. RECONECTANDO IMEDIATAMENTE...", xbmc.LOGINFO)
                    time.sleep(0.05) # Pequena pausa para evitar loop agressivo
                    continue # Força a reconexão no loop while

            except (requests.exceptions.Timeout, OSError) as e: # Catch OSError for ConnectionResetError and similar
                consecutive_failures += 1
                log_message = f"[IPTV PROXY] Erro de conexão/IO para {ts_url} (tentativa {consecutive_failures}): {e}. Reconectando..."
                # Explicitly log if it's a known WinError 10053 or 10054
                if isinstance(e, OSError) and (e.errno == 10053 or e.errno == 10054):
                    xbmc.log(f"{log_message} (Identificado como WinError {e.errno})", xbmc.LOGWARNING)
                else:
                    xbmc.log(log_message, xbmc.LOGWARNING)
                time.sleep(0.5 * consecutive_failures)
            except requests.exceptions.HTTPError as e:
                consecutive_failures += 1
                if e.response.status_code in [403, 404, 410]: # Erros que sugerem que o segmento mudou ou não existe
                    xbmc.log(f"[IPTV PROXY] HTTP {e.response.status_code} para {ts_url}. O segmento não existe ou mudou. Encerrando stream.", xbmc.LOGERROR)
                    break # Sai do loop, não tenta reiniciar o mesmo segmento
                else:
                    xbmc.log(f"[IPTV PROXY] HTTP Erro para {ts_url} (tentativa {consecutive_failures}): {e}. Reconectando...", xbmc.LOGWARNING)
                time.sleep(1)
            except (BrokenPipeError): # Isso significa que o cliente Kodi desconectou
                xbmc.log(f"[IPTV PROXY] Cliente Kodi desconectou de {ts_url}. Encerrando esta thread de stream.", xbmc.LOGINFO)
                break # Sai do loop while, pois o cliente se foi
            except Exception as e: # Qualquer outro erro inesperado
                consecutive_failures += 1
                xbmc.log(f"[IPTV PROXY] Erro inesperado no stream {ts_url}: {e}. Reconectando...", xbmc.LOGERROR)
                time.sleep(1)
        
        self.connection_pool.return_session(session)

    def start(self) -> Optional[str]:
        class ProxyHandler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            def do_GET(handler):
                proxy = StreamProxy._instance
                if not proxy or proxy.stop_event.is_set():
                    handler.send_error(503, "Proxy está parando."); return

                query_params = dict(parse_qsl(urlparse(handler.path).query))
                remote_url = unquote(query_params.get('url', ''))
                if not remote_url:
                    handler.send_error(400, "URL não fornecida."); return

                session = proxy.connection_pool.get_session()
                try:
                    if remote_url.endswith('.m3u8'):
                        response, error = proxy._fetch_url(remote_url, session)
                        if error or not response:
                            handler.send_error(502, f"Falha ao buscar playlist: {error}"); return
                        
                        handler.send_response(200)
                        for k, v in response.headers.items():
                            if k.lower() not in BLOCKED_RESPONSE_HEADERS:
                                handler.send_header(k, v)
                        if 'content-type' not in response.headers:
                             handler.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                        handler.end_headers()

                        proxy_base = f"http://127.0.0.1:{proxy.local_port}/?url="
                        for line in response.text.splitlines():
                            line = line.strip()
                            if not line: continue
                            if line.startswith('#'):
                                if 'URI="' in line:
                                    uri = re.search(r'URI="([^"]+)"', line).group(1)
                                    full_uri = urljoin(remote_url, uri)
                                    line = line.replace(uri, proxy_base + quote(full_uri))
                            elif not line.startswith('http'):
                                line = proxy_base + quote(urljoin(remote_url, line))
                            else: # Reescreve URLs absolutas também para passar pelo proxy
                                line = proxy_base + quote(line)
                            handler.wfile.write((line + '\n').encode('utf-8'))

                    elif re.search(r'\.ts(\?.*)?$', remote_url, re.IGNORECASE):
                        proxy._ts_brute_stream(remote_url, handler)
                    else:
                        response, error = proxy._fetch_url(remote_url, session, stream=True)
                        if error or not response:
                            handler.send_error(502, f"Falha ao buscar recurso: {error}"); return
                        handler.send_response(response.status_code)
                        for k, v in response.headers.items():
                            if k.lower() not in BLOCKED_RESPONSE_HEADERS:
                                handler.send_header(k, v)
                        handler.end_headers()
                        for chunk in response.iter_content(int(FFMPEG_CHUNK_SIZE)):
                            if chunk: handler.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    xbmc.log(f"[IPTV PROXY HANDLER] Cliente desconectou.", xbmc.LOGINFO)
                except Exception as e:
                    if not handler.headers_sent: handler.send_error(500)
                    xbmc.log(f"[IPTV PROXY HANDLER] Erro no GET: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
                finally:
                    proxy.connection_pool.return_session(session)

            def log_message(self, format, *args): pass

        with self._lock:
            if StreamProxy._instance: StreamProxy._instance.stop()
            
            for port in range(50000, 50021):
                try:
                    self.server = ThreadedHTTPServer(('127.0.0.1', port), ProxyHandler)
                    self.local_port = port
                    self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                    self.server_thread.start()
                    xbmc.log(f"[IPTV PROXY] Servidor iniciado em http://127.0.0.1:{self.local_port}", xbmc.LOGINFO)
                    StreamProxy._instance = self
                    return f"http://127.0.0.1:{self.local_port}/?url={quote(self.original_stream_url)}"
                except socket.error:
                    continue
            return None

    def stop(self):
        with self._lock:
            if self.stop_event.is_set(): return
            self.stop_event.set()
            if self.server:
                threading.Thread(target=self.server.shutdown, daemon=True).start()
            self.video_cache.clear()
            StreamProxy._instance = None
            xbmc.log("[IPTV PROXY] Proxy parado.", xbmc.LOGINFO)

class KodiPlayer(xbmc.Player):
    def __init__(self, *, proxy_instance: StreamProxy):
        self._proxy_instance = proxy_instance

    def onPlayBackStopped(self): self._cleanup("Parado")
    def onPlayBackEnded(self): self._cleanup("Terminado")
    def onPlayBackError(self): self._cleanup("Erro")

    def _cleanup(self, reason: str):
        xbmc.log(f"[IPTV PROXY PLAYER] Playback {reason}. Limpando proxy.", xbmc.LOGINFO)
        if self._proxy_instance:
            self._proxy_instance.stop()
            self._proxy_instance = None

def play_stream(url: str, title: str):
    proxy = None
    try:
        proxy = StreamProxy(url)
        proxy_url = proxy.start()
        if not proxy_url:
            raise RuntimeError("Falha ao iniciar servidor proxy local.")
        
        player_monitor = KodiPlayer(proxy_instance=proxy)

        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')

        parsed_original_url = urllib.parse.urlparse(url)
        
        header_parts = []
        header_parts.append(f"Referer={quote(f'{parsed_original_url.scheme}://{parsed_original_url.netloc}')}")
        header_parts.append(f"User-Agent={quote(DEFAULT_CHROME_HEADERS['User-Agent'])}")
        headers_ffmpeg_direct = '&'.join(header_parts)

        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setMediaType('video')

        if '.m3u8' in url.lower():
            list_item.setContentLookup(False)
            list_item.setMimeType('application/vnd.apple.mpegurl')
            list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'application/vnd.apple.mpegurl')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
            list_item.setProperty('inputstream.ffmpegdirect.stream_headers', headers_ffmpeg_direct)
            list_item.setProperty('inputstream.ffmpegdirect.hls_segment_duration_limit', '60')
            list_item.setProperty('inputstream.ffmpegdirect.hls_min_buffer_duration', '3')
            list_item.setProperty('inputstream.ffmpegdirect.hls_max_bitrate', str(MAX_BITRATE))
            list_item.setProperty('inputstream.ffmpegdirect.hls_allow_partial_segments', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_update_parameter', 'full')

            list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
            list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            list_item.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'true' if 'catchup' in title.lower() else 'false') 
            list_item.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.default_url', url)
            list_item.setProperty('inputstream.ffmpegdirect.catchup_url_format_string', url)
            list_item.setProperty('inputstream.ffmpegdirect.programme_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.programme_end_time', '19')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset', '1')
            list_item.setProperty('inputstream.ffmpegdirect.default_programme_duration', '19')
            list_item.setProperty('inputstream.ffmpegdirect.allow_discontinuities', 'true')
            
            # Usando as novas configurações do settings.xml para HLS
            list_item.setProperty('inputstream.ffmpegdirect.live_threshold', FFMPEG_LIVE_THRESHOLD)
            list_item.setProperty('inputstream.ffmpegdirect.low_delay', FFMPEG_LOW_DELAY)
            list_item.setProperty('inputstream.ffmpegdirect.http_connect_timeout', FFMPEG_CONNECT_TIMEOUT)
            list_item.setProperty('inputstream.ffmpegdirect.http_read_timeout', FFMPEG_READ_TIMEOUT)
            list_item.setProperty('inputstream.ffmpegdirect.reconnect_on_error', FFMPEG_RECONNECT_ON_ERROR)
            list_item.setProperty('inputstream.ffmpegdirect.fast_seek', FFMPEG_FAST_SEEK)
            list_item.setProperty('inputstream.ffmpegdirect.chunk_size', FFMPEG_CHUNK_SIZE)

        else:
            list_item.setContentLookup(False)
            list_item.setMimeType('video/mp2t')
            list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp2t')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'none')
            list_item.setProperty('inputstream.ffmpegdirect.stream_headers', headers_ffmpeg_direct)
            
            # Usando as novas configurações do settings.xml para MP2T
            list_item.setProperty('inputstream.ffmpegdirect.http_connect_timeout', FFMPEG_CONNECT_TIMEOUT)
            list_item.setProperty('inputstream.ffmpegdirect.http_read_timeout', FFMPEG_READ_TIMEOUT)
            list_item.setProperty('inputstream.ffmpegdirect.reconnect_on_error', FFMPEG_RECONNECT_ON_ERROR)
            list_item.setProperty('inputstream.ffmpegdirect.live_threshold', FFMPEG_LIVE_THRESHOLD)
            list_item.setProperty('inputstream.ffmpegdirect.fast_seek', FFMPEG_FAST_SEEK)
            list_item.setProperty('inputstream.ffmpegdirect.seek_method', 'byte')
            list_item.setProperty('inputstream.ffmpegdirect.chunk_size', FFMPEG_CHUNK_SIZE)
            list_item.setProperty('inputstream.ffmpegdirect.low_delay', FFMPEG_LOW_DELAY)
            
            list_item.setProperty('inputstream.ffmpegdirect.readrate_start', '1.0')
            list_item.setProperty('inputstream.ffmpegdirect.readrate_max', '2.0')
            list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'catchup')
            list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'true' if 'catchup' in title.lower() else 'false')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.default_url', url)
            list_item.setProperty('inputstream.ffmpegdirect.catchup_url_format_string', url)
            list_item.setProperty('inputstream.ffmpegdirect.programme_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.programme_end_time', '19')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time', '1')
            list_item.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset', '1')
            list_item.setProperty('inputstream.ffmpegdirect.default_programme_duration', '19')
            list_item.setProperty('inputstream.ffmpegdirect.allow_discontinuities', 'true')
        
        xbmcplugin.setResolvedUrl(handle=_HANDLE, succeeded=True, listitem=list_item)
        
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            if not (player_monitor and player_monitor._proxy_instance):
                break
            if monitor.waitForAbort(1):
                break
    except Exception as e:
        xbmc.log(f"[IPTV PROXY MAIN] Erro fatal: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle=_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        if proxy: proxy.stop()

def run_addon():
    action = _ARGS.get('action')
    url = _ARGS.get('url')
    title = _ARGS.get('title', 'IPTV Stream')
    
    if action == 'play' and url:
        play_stream(url, title)
    elif action == 'settings':
        ADDON.openSettings()
    else: # Menu principal
        test_title = "Canal de Teste (HLS)"
        test_url = "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8"
        
        li = xbmcgui.ListItem(label=test_title)
        li.setProperty('IsPlayable', 'true')
        play_url = f"{sys.argv[0]}?action=play&url={quote(test_url)}&title={quote(test_title)}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=play_url, listitem=li, isFolder=False)
        
        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    run_addon()