import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
import warnings
import os
from collections import OrderedDict
import http.server
import socketserver
import requests
import requests.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------

MAX_SEGMENT_RETRIES = 5
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 15
STREAM_TIMEOUT = 60.0
DEFAULT_CHUNK_SIZE = 1024 * 512
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
LOG_FILE = "hls_proxy.log"
MANIFEST_RELOAD_INTERVAL = 5
MAX_RECONNECTION_ATTEMPTS = 5
CLIENT_CHECK_TIMEOUT = 1.0
HEALTH_CHECK_INTERVAL = 5.0
SESSION_TIMEOUT = 300.0  # Aumentado para 5 minutos
MANIFEST_RETRY_DELAY = 1.0
LIVE_STREAM_DURATION = 3600  # 1 hora para streams ao vivo

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------

def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')])
    except Exception as e:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
        logging.error(f"Erro ao configurar o logging para o arquivo: {e}")

# ---------------- PROXY LOGIC ----------------

class ManifestCache:
    def __init__(self, max_size=10):
        self.cache = OrderedDict()
        self.max_size = max_size
        self.lock = threading.Lock()
        self.last_access = {}
        self.last_manifest_reload = {}
        self.session_start_time = {}  # Rastrear quando a sessão começou

    def get(self, session_id):
        with self.lock:
            manifest_info = self.cache.get(session_id)
            if manifest_info:
                self.cache.move_to_end(session_id)
                self.last_access[session_id] = time.time()
            return manifest_info

    def set(self, session_id, manifest_url, manifest_content, last_updated):
        with self.lock:
            if session_id in self.cache:
                self.cache.move_to_end(session_id)
            self.cache[session_id] = {
                'url': manifest_url,
                'content': manifest_content,
                'last_updated': last_updated
            }
            self.last_access[session_id] = time.time()
            self.last_manifest_reload[session_id] = time.time()
            
            # Registrar o início da sessão se for a primeira vez
            if session_id not in self.session_start_time:
                self.session_start_time[session_id] = time.time()
            
            if len(self.cache) > self.max_size:
                oldest_session = next(iter(self.cache))
                self.cache.popitem(last=False)
                self.last_access.pop(oldest_session, None)
                self.last_manifest_reload.pop(oldest_session, None)
                self.session_start_time.pop(oldest_session, None)

    def should_reload(self, session_id):
        with self.lock:
            manifest_info = self.cache.get(session_id)
            if manifest_info and (time.time() - manifest_info['last_updated']) > MANIFEST_RELOAD_INTERVAL:
                return True
            return False
    
    def get_last_manifest_reload(self, session_id):
        with self.lock:
            return self.last_manifest_reload.get(session_id, 0)
    
    def get_session_duration(self, session_id):
        with self.lock:
            if session_id in self.session_start_time:
                return time.time() - self.session_start_time[session_id]
            return 0
    
    def cleanup_inactive_sessions(self):
        """Remove sessões inativas para economizar recursos"""
        with self.lock:
            current_time = time.time()
            inactive_sessions = [
                session_id for session_id, last_time in self.last_access.items()
                if current_time - last_time > SESSION_TIMEOUT
            ]
            for session_id in inactive_sessions:
                self.cache.pop(session_id, None)
                self.last_access.pop(session_id, None)
                self.last_manifest_reload.pop(session_id, None)
                self.session_start_time.pop(session_id, None)
                logging.info(f"Sessão inativa removida: {session_id}")

class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    manifest_cache = ManifestCache()
    session = requests.session()
    retry_strategy = Retry(
        total=MAX_SEGMENT_RETRIES,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504]
    )
    session.mount('http://', HTTPAdapter(max_retries=retry_strategy))
    session.mount('https://', HTTPAdapter(max_retries=retry_strategy))

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    def safe_send_response(self, code, message=None):
        """Envia resposta de forma segura, tratando desconexões"""
        try:
            self.send_response(code, message)
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante envio de resposta")
            raise
        except Exception as e:
            logging.error(f"Erro ao enviar resposta: {e}")
            raise

    def safe_send_header(self, keyword, value):
        """Envia header de forma segura, tratando desconexões"""
        try:
            self.send_header(keyword, value)
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante envio de header")
            raise
        except Exception as e:
            logging.error(f"Erro ao enviar header: {e}")
            raise

    def safe_end_headers(self):
        """Finaliza headers de forma segura, tratando desconexões"""
        try:
            self.end_headers()
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante finalização de headers")
            raise
        except Exception as e:
            logging.error(f"Erro ao finalizar headers: {e}")
            raise

    def safe_write(self, data):
        """Escreve dados de forma segura, tratando desconexões"""
        try:
            self.wfile.write(data)
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante transmissão de dados")
            raise
        except Exception as e:
            logging.error(f"Erro ao escrever dados: {e}")
            raise

    def do_HEAD(self):
        retry_count = 0
        while retry_count < MAX_RECONNECTION_ATTEMPTS:
            try:
                if '?url=' not in self.path: 
                    self.safe_send_response(404)
                    return
                
                url = urllib.parse.unquote_plus(self.path.split('?url=')[1].split('&')[0])
                headers = {'User-Agent': USER_AGENT}
                if 'Range' in self.headers: 
                    headers['Range'] = self.headers['Range']
                
                r = self.session.head(url, headers=headers, stream=True, 
                                     timeout=CONNECTION_TIMEOUT, 
                                     allow_redirects=True, verify=False)
                
                self.safe_send_response(r.status_code)
                for header, value in r.headers.items(): 
                    self.safe_send_header(header, value)
                self.safe_end_headers()
                return
                
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                logging.warning("Cliente desconectado durante requisição HEAD")
                return
            except Exception as e:
                retry_count += 1
                logging.error(f"Erro no HEAD para {self.path} (tentativa {retry_count}/{MAX_RECONNECTION_ATTEMPTS}): {e}")
                if retry_count < MAX_RECONNECTION_ATTEMPTS:
                    time.sleep(min(2 ** retry_count, 5))
                else:
                    try:
                        self.safe_send_response(502)
                    except:
                        pass
                    return

    def do_GET(self):
        try:
            if '?url=' not in self.path: 
                self.safe_send_response(404)
                return
            
            params = urllib.parse.parse_qs(self.path.split('?')[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [None])[0]
            
            if not url: 
                self.safe_send_response(400)
                return
                
            headers = {'User-Agent': USER_AGENT}
            parsed_url = urllib.parse.urlparse(url)
            
            # Limpar sessões inativas periodicamente
            self.manifest_cache.cleanup_inactive_sessions()
            
            # Verificar se a sessão está ativa e atualizar tempo de acesso
            if session_id:
                self.manifest_cache.get(session_id)
                
                # Verificar se a sessão está durando mais que o esperado para streams ao vivo
                session_duration = self.manifest_cache.get_session_duration(session_id)
                if session_duration > LIVE_STREAM_DURATION:
                    logging.info(f"Sessão {session_id} durou mais de {LIVE_STREAM_DURATION} segundos, forçando renovação")
                    self._force_session_reload(session_id)
                    return
            
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_hls_manifest(url, session_id, headers)
            else:
                self._handle_hls_segment(url, session_id, headers)
                
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante requisição GET")
            return
        except (IndexError, ValueError) as e:
            logging.error(f"Erro de parâmetro: {e}")
            try:
                self.safe_send_response(400)
            except:
                pass
        except Exception as e:
            logging.error(f"Erro inesperado no GET para {self.path}: {e}")
            try:
                self.safe_send_response(500)
            except:
                pass

    def _handle_hls_manifest(self, url, session_id, headers):
        retry_count = 0
        manifest_info = None
        manifest_content = None
        base_url = None
        
        # Adicionar headers para evitar cache
        headers['Cache-Control'] = 'no-cache'
        headers['Pragma'] = 'no-cache'
        
        # Tentar obter o manifesto, com retries
        while retry_count < MAX_RECONNECTION_ATTEMPTS:
            try:
                # Verificar cache primeiro
                manifest_info = self.manifest_cache.get(session_id)
                if not manifest_info or self.manifest_cache.should_reload(session_id):
                    r = self.session.get(url, headers=headers, 
                                        timeout=CONNECTION_TIMEOUT, verify=False)
                    r.raise_for_status()
                    manifest_content = r.text
                    base_url = r.url
                    self.manifest_cache.set(session_id, base_url, manifest_content, time.time())
                else:
                    manifest_content = manifest_info['content']
                    base_url = manifest_info['url']
                
                # Se chegamos aqui, obtivemos o manifesto com sucesso
                break
                
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                logging.warning("Cliente desconectado durante obtenção do manifesto")
                return
            except requests.exceptions.RequestException as e:
                retry_count += 1
                logging.error(f"Erro ao obter manifesto HLS para {url} (tentativa {retry_count}/{MAX_RECONNECTION_ATTEMPTS}): {e}")
                if retry_count < MAX_RECONNECTION_ATTEMPTS:
                    time.sleep(min(2 ** retry_count, 5))
                else:
                    try:
                        self.safe_send_response(502)
                    except:
                        pass
                    return
        
        # Se não conseguimos obter o manifesto após todas as tentativas
        if manifest_content is None:
            logging.error(f"Falha ao obter manifesto HLS após {MAX_RECONNECTION_ATTEMPTS} tentativas")
            try:
                self.safe_send_response(502)
            except:
                pass
            return
        
        # Enviar resposta com manifesto modificado
        try:
            self.safe_send_response(200)
            self.safe_send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.safe_send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.safe_send_header('Pragma', 'no-cache')
            self.safe_send_header('Expires', '0')
            self.safe_end_headers()
            
            new_manifest_lines = []
            for line in manifest_content.splitlines():
                if not line.startswith('#') and line.strip():
                    full_segment_url = urllib.parse.urljoin(base_url, line)
                    proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&session_id={session_id}"
                    new_manifest_lines.append(proxy_segment_url)
                else:
                    new_manifest_lines.append(line)
            
            self.safe_write('\n'.join(new_manifest_lines).encode('utf-8'))
            
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante envio do manifesto")
            return
        except Exception as e:
            logging.error(f"Erro ao enviar manifesto HLS: {e}")
            # Não podemos enviar um erro aqui pois os headers já foram enviados

    def _handle_hls_segment(self, url, session_id, headers):
        retries = 0
        start_byte = 0
        last_health_check = time.time()
        manifest_reloaded = False
        
        if 'range' in headers:
            start_byte_str = headers['range'].split('=')[-1].split('-')[0]
            if start_byte_str: 
                start_byte = int(start_byte_str)
        
        while retries < MAX_SEGMENT_RETRIES:
            try:
                # Atualizar o acesso à sessão
                self.manifest_cache.get(session_id)
                
                # Configurar range se necessário
                if start_byte > 0: 
                    headers['Range'] = f"bytes={start_byte}-"
                
                # Abrir conexão com o servidor de origem
                with self.session.get(url, headers=headers, stream=True, 
                                    timeout=STREAM_TIMEOUT, verify=False) as r:
                    # Verificar se o status é 404 (Not Found)
                    if r.status_code == 404:
                        logging.warning(f"Segmento não encontrado (404): {url}")
                        
                        # Se ainda não recarregamos o manifesto nesta sessão
                        if not manifest_reloaded:
                            logging.info(f"Recarregando manifesto para sessão {session_id}")
                            manifest_reloaded = True
                            
                            # Forçar recarga do manifesto
                            manifest_info = self.manifest_cache.get(session_id)
                            if manifest_info:
                                # Atualizar timestamp para forçar recarga
                                with self.manifest_cache.lock:
                                    if session_id in self.manifest_cache.cache:
                                        self.manifest_cache.cache[session_id]['last_updated'] = 0
                            
                            # Esperar um pouco após recarregar o manifesto
                            time.sleep(MANIFEST_RETRY_DELAY)
                            
                            # Tentar novamente o mesmo segmento (com manifesto atualizado)
                            retries -= 1  # Não contar como retry, pois vamos tentar novamente com manifesto atualizado
                            continue
                        else:
                            # Já tentamos recarregar o manifesto e ainda temos 404
                            # Forçar reconexão imediata
                            logging.warning(f"Forçando reconexão para sessão {session_id}")
                            try:
                                self._force_session_reload(session_id)
                            except:
                                pass
                            return
                    
                    # Se chegamos aqui, o status não é 404
                    r.raise_for_status()
                    
                    # Enviar headers de resposta
                    self.safe_send_response(r.status_code)
                    for header, value in r.headers.items():
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.safe_send_header(header, value)
                    self.safe_end_headers()
                    
                    # Transmitir o conteúdo do segmento
                    for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        # Verificar periodicamente a conexão do cliente
                        current_time = time.time()
                        if current_time - last_health_check > HEALTH_CHECK_INTERVAL:
                            last_health_check = current_time
                            if not self.check_client_connection():
                                logging.warning("Cliente desconectado durante a transmissão do segmento")
                                return
                        
                        if not chunk: 
                            continue
                            
                        try:
                            self.safe_write(chunk)
                            start_byte += len(chunk)
                        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                            logging.warning("Cliente desconectado durante transmissão do segmento")
                            return
                    
                    logging.info(f"Segmento HLS para {url} transmitido com sucesso.")
                    return
                    
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                logging.warning("Cliente desconectado durante processamento do segmento")
                return
            except (requests.exceptions.RequestException, ConnectionError, OSError) as e:
                retries += 1
                logging.warning(f"Erro ao transmitir segmento {url}: {e}. Tentativa {retries}/{MAX_SEGMENT_RETRIES}")
                
                if retries < MAX_SEGMENT_RETRIES:
                    # Backoff exponencial com limite máximo
                    wait_time = min(2 ** retries, 5)
                    time.sleep(wait_time)
                else:
                    logging.error(f"Falha ao transmitir o segmento após {MAX_SEGMENT_RETRIES} tentativas.")
                    try:
                        self.safe_send_response(502)
                    except:
                        pass
                    return

    def _force_session_reload(self, session_id):
        """Força o Kodi a recarregar completamente a sessão enviando um redirecionamento"""
        try:
            # Obter o manifesto original para esta sessão
            manifest_info = self.manifest_cache.get(session_id)
            if not manifest_info:
                logging.error(f"Não foi possível encontrar informações do manifesto para a sessão {session_id}")
                self.safe_send_response(404)
                return
                
            # Gerar nova sessão
            new_session_id = f"{int(time.time())}_{random.randint(1000, 9999)}"
            
            # Construir URL de redirecionamento para o manifesto com nova sessão
            encoded_manifest_url = urllib.parse.quote_plus(manifest_info['url'])
            redirect_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={encoded_manifest_url}&session_id={new_session_id}"
            
            # Enviar redirecionamento
            self.safe_send_response(307)  # Temporary Redirect
            self.safe_send_header('Location', redirect_url)
            self.safe_send_header('Cache-Control', 'no-cache, no-store')
            self.safe_end_headers()
            
            logging.info(f"Redirecionando para nova sessão: {new_session_id}")
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            logging.warning("Cliente desconectado durante redirecionamento de sessão")
            return
        except Exception as e:
            logging.error(f"Erro ao forçar recarga da sessão: {e}")
            try:
                self.safe_send_response(500)
            except:
                pass

    def check_client_connection(self):
        try:
            self.wfile.flush()
            return True
        except:
            return False

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False
        self.restart_count = 0
        self.max_restarts = 3
        self.last_restart_time = 0
        
    def is_running(self): 
        return self._is_running
        
    def start(self):
        if self.is_running(): 
            return True
            
        self.stop()
        
        # Verificar se estamos reiniciando com muita frequência
        current_time = time.time()
        if current_time - self.last_restart_time < 30:  # Menos de 30 segundos desde o último restart
            self.restart_count += 1
            if self.restart_count > self.max_restarts:
                logging.error("Muitas reinicializações rápidas. Abortando.")
                return False
        else:
            self.restart_count = 0
            
        self.last_restart_time = current_time
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                self.active_port = port
                self._is_running = True
                logging.info(f"Proxy HLS iniciado em {self.active_port}")
                return True
            except OSError as e:
                logging.warning(f"Tentativa {attempt + 1}/{MAX_PORT_ATTEMPTS} falhou: {e}")
                continue
                
        logging.error("Falha ao iniciar o proxy HLS após várias tentativas")
        return False
        
    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception as e:
                logging.error(f"Erro ao desligar o servidor: {e}")
                
        if self.server_thread:
            try:
                self.server_thread.join(1)
            except:
                pass
                
        self.server = None
        self.server_thread = None
        self._is_running = False
        
    def restart(self):
        """Reinicia o proxy em caso de falha crítica"""
        logging.info("Reiniciando o proxy HLS...")
        self.stop()
        return self.start()

class HLSAddon:
    def __init__(self, handle): 
        self.handle = handle
        self.proxy = HLSProxyManager()
        
    def play_stream(self, url, stype, title=None):
        # Tenta iniciar o proxy, com retries
        for attempt in range(MAX_RECONNECTION_ATTEMPTS):
            if self.proxy.start():
                break
            if attempt < MAX_RECONNECTION_ATTEMPTS - 1:
                logging.warning(f"Falha ao iniciar proxy, tentando novamente ({attempt + 1}/{MAX_RECONNECTION_ATTEMPTS})")
                time.sleep(min(2 ** attempt, 5))
        else:
            logging.error("Não foi possível iniciar o proxy HLS")
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            
        session_id = f"{int(time.time())}_{random.randint(1000, 9999)}"
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&session_id={session_id}"
        
        li = xbmcgui.ListItem(path=proxy_url, label=title or "Proxy HLS")
        li.setProperty("IsPlayable", "true")
        
        if stype == "live": 
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true")
            
        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    try:
        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]
        
        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(stream_url, stream_type, title)
        else:
            xbmcplugin.endOfDirectory(h)
            
    except Exception as e:
        logging.error(f"Erro no main do HLS Proxy: {e}")

if __name__ == '__main__':
    main()