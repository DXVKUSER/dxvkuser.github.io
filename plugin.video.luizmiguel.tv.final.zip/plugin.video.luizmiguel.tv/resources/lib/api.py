# -*- coding: utf-8 -*-
import xbmcgui
import xbmc
from doh_client import requests
import time
import random
import hashlib

# ---------------- CONFIG ----------------
API_CACHE_TTL = 60  # segundos de cache
API_MAX_RETRIES = 4
API_BACKOFF_BASE = 1.5
API_MAX_BACKOFF = 8  # segundos

BASE_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{ver}.0) Gecko/20100101 Firefox/{ver}.0"

# ---------------- UTILS ----------------
def generate_user_agent():
    """Rotaciona apenas a versão do Firefox para parecer dinâmico."""
    ver = random.randint(85, 120)
    return BASE_USER_AGENT.format(ver=ver)

def make_cache_key(url, params):
    raw = url + str(sorted(params.items()))
    return hashlib.md5(raw.encode("utf-8")).hexdigest()

# ---------------- CACHE ----------------
_api_cache = {}

def get_from_cache(key):
    if key in _api_cache:
        data, expira = _api_cache[key]
        if time.time() < expira:
            return data
        else:
            del _api_cache[key]
    return None

def set_cache(key, data, ttl=API_CACHE_TTL):
    _api_cache[key] = (data, time.time() + ttl)

# ---------------- API ----------------
class XtreamAPI:
    def __init__(self, server, username, password):
        # AQUI ESTÁ A CORREÇÃO
        self.server = server
        self.username = username
        self.password = password
        self.base_url = f"{server}"
        self.session = requests.session
        self.session.headers.update({'User-Agent': generate_user_agent()})

    def _make_request(self, params):
        params['username'] = self.username
        params['password'] = self.password
        url = f"{self.base_url}/player_api.php"
        cache_key = make_cache_key(url, params)

        # Verifica cache
        cached = get_from_cache(cache_key)
        if cached is not None:
            return cached

        backoff = API_BACKOFF_BASE
        last_exception = None
        for attempt in range(API_MAX_RETRIES):
            try:
                r = self.session.get(url, params=params, timeout=10)
                # Se 429 Too Many Requests, respeita Retry-After (ou aplica backoff), tenta menos vezes
                if r.status_code == 429:
                    retry_after = r.headers.get("Retry-After")
                    if retry_after:
                        try:
                            wait_time = min(float(retry_after), API_MAX_BACKOFF)
                        except Exception:
                            wait_time = min(backoff, API_MAX_BACKOFF)
                    else:
                        wait_time = min(backoff, API_MAX_BACKOFF)
                    xbmc.log(f"[XtreamProxy] 429 recebido, aguardando {wait_time}s antes do retry...", xbmc.LOGWARNING)
                    time.sleep(wait_time)
                    backoff *= 2
                    continue

                r.raise_for_status()

                if r.text.strip() == "[]":
                    set_cache(cache_key, [])
                    return []

                data = r.json()
                if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
                    xbmcgui.Dialog().ok("Erro de Autenticação", "Usuário ou senha inválidos.")
                    set_cache(cache_key, None, ttl=10)  # Evita flood de tentativas
                    return None

                # Salva no cache
                set_cache(cache_key, data)
                return data

            except ValueError:
                xbmc.log(f"[XtreamProxy] Erro de API: Resposta não é JSON válido.", xbmc.LOGERROR)
                xbmcgui.Dialog().ok("Erro de Servidor", "O servidor retornou uma resposta inválida.")
                return None
            except Exception as e:
                last_exception = e
                xbmc.log(f"[XtreamProxy] Erro API tentativa {attempt+1}: {e}", xbmc.LOGWARNING)
                time.sleep(min(backoff, API_MAX_BACKOFF))
                backoff *= 2

        # Se chegou aqui, falhou
        msg = f"Falha após {API_MAX_RETRIES} tentativas de API"
        xbmc.log(f"[XtreamProxy] {msg}: {last_exception}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Conexão", "Não foi possível conectar ao servidor (429, timeout ou bloqueio).")
        return None

    # ---------------- MÉTODOS DE API ----------------
    def get_live_categories(self):
        return self._make_request({'action': 'get_live_categories'})

    def get_live_streams(self, category_id=None):
        params = {'action': 'get_live_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_vod_categories(self):
        return self._make_request({'action': 'get_vod_categories'})

    def get_vod_streams(self, category_id=None):
        params = {'action': 'get_vod_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_categories(self):
        return self._make_request({'action': 'get_series_categories'})

    def get_series(self, category_id=None):
        params = {'action': 'get_series'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_info(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_live_stream_url(self, stream_id):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.m3u8"

    def get_vod_stream_url(self, stream_id):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.mp4"

    def get_series_stream_url(self, stream_id):
        return f"{self.base_url}/series/{self.username}/{self.password}/{stream_id}.mp4"

    def get_epg_url(self):
        """
        Retorna a URL do arquivo EPG XML para o servidor Xtream.
        O padrão Xtream geralmente é: .../xmltv.php?username=xxx&password=yyy
        """
        return f"{self.base_url}/xmltv.php?username={self.username}&password={self.password}"