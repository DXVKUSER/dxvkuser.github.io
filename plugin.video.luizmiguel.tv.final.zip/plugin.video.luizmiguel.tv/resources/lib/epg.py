# -*- coding: utf-8 -*-
import os # Adicionado para corrigir o NameError
import time
import calendar
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
import html

def parse_xmltv_time(ts):
    if not ts:
        return int(time.time())
    ts = ts.strip()
    if len(ts) < 14 or not ts[:14].isdigit():
        return int(time.time())
    base = ts[:14]
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except Exception:
        return int(time.time())
    
    offset_secs = 0
    rest = ts[14:].strip()
    if rest:
        rest = rest.replace(' ', '')
        if rest.startswith(('+', '-')) and len(rest) >= 5:
            try:
                sign = 1 if rest[0] == '+' else -1
                hh = int(rest[1:3])
                mm = int(rest[3:5])
                offset_secs = sign * (hh * 3600 + mm * 60)
            except Exception:
                offset_secs = 0

    tz_local = datetime.now().astimezone().tzinfo
    dt_local = dt.replace(tzinfo=timezone(timedelta(seconds=offset_secs))).astimezone(tz_local)
    
    epoch = dt_local.timestamp()
    return int(epoch) if epoch > 0 else int(time.time())

def normalize_epg_channel_id(cid):
    if not cid:
        return ''
    return html.unescape(cid.strip().lower())

def load_epg(epg_xml_path):
    if not os.path.exists(epg_xml_path):
        return {'channels': {}, 'progs': {}}
    try:
        tree = ET.parse(epg_xml_path)
        root = tree.getroot()
        channels = {}
        progs = {}
        for c in root.findall(".//channel"):
            cid = normalize_epg_channel_id(c.get('id'))
            dn = html.unescape((c.findtext('display-name') or '').strip())
            channels[cid] = dn
        for p in root.findall(".//programme"):
            cid = normalize_epg_channel_id(p.get('channel'))
            
            start_timestamp_str = p.get('start_timestamp')
            stop_timestamp_str = p.get('stop_timestamp')
            
            if start_timestamp_str and stop_timestamp_str:
                start = int(start_timestamp_str)
                stop = int(stop_timestamp_str)
            else:
                start = parse_xmltv_time(p.get('start'))
                stop = parse_xmltv_time(p.get('stop') or p.get('end'))
            
            if stop <= start:
                stop = start + 3600
            
            title = html.unescape((p.findtext('title') or '').strip())
            desc = html.unescape((p.findtext('desc') or '').strip())
            
            if cid not in progs:
                progs[cid] = []
            progs[cid].append({'start': start, 'end': stop, 'title': title, 'desc': desc})
            
        for cid, arr in progs.items():
            arr.sort(key=lambda x: x['start'])
            
        return {'channels': channels, 'progs': progs}
    except Exception as e:
        return {'channels': {}, 'progs': {}}

def epg_lookup_current_next(epg_channel_id, epg):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())
    plist = epg['progs'].get(cid, [])
    current, nextp = None, None
    for i, pr in enumerate(plist):
        start = pr.get('start') or now
        end = pr.get('end') or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end
        if start <= now < end:
            current = pr
            if i + 1 < len(plist):
                nextp = plist[i + 1]
            break
        if start > now:
            nextp = pr
            if i - 1 >= 0 and plist[i-1]['end'] > now:
                current = plist[i-1]
            break
    return current, nextp