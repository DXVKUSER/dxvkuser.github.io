# -*- coding: utf-8 -*-

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import logging
import time
import re
import html
import xbmcvfs
import hashlib
import os

from resources.lib.api import XtreamAPI
from resources.lib.epg import load_epg, epg_lookup_current_next, normalize_epg_channel_id
from hlsproxy import HLSAddon
from vodproxy import VODAddon

from doh_client import requests
from requests.exceptions import Timeout

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADULT_KEYWORDS = ['adult', 'xxx', '+18', 'private']

REMOTE_CREDENTIALS_URL = "https://raw.githubusercontent.com/DXVKUSER/SRTORRENT/refs/heads/main/mig.json"
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_TTL = 24 * 3600  # 24h

class EpgCache:
    _instance = None
    _epg_data = {}
    _last_server_hash = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(EpgCache, cls).__new__(cls)
        return cls._instance

    def get_epg_data(self, api):
        if not ADDON.getSettingBool('enable_epg'):
            return {'channels': {}, 'progs': {}}

        # Cria um hash baseado nas credenciais do servidor
        server_identifier = f"{api.server}{api.username}{api.password}"
        server_hash = hashlib.sha1(server_identifier.encode('utf-8')).hexdigest()

        epg_xml_path = xbmcvfs.translatePath(os.path.join(PROFILE_DIR, f'epg_{server_hash}.xml'))
        current_time = time.time()
        
        # Verifica se o servidor mudou desde a última vez
        server_changed = (self._last_server_hash is not None and self._last_server_hash != server_hash)
        self._last_server_hash = server_hash
        
        # Tenta carregar do cache se o arquivo existir e não estiver expirado
        if xbmcvfs.exists(epg_xml_path) and not server_changed:
            file_mod_time = os.path.getmtime(epg_xml_path)
            if current_time - file_mod_time < EPG_TTL:
                xbmc.log("[ADDON] Carregando EPG do cache...", level=xbmc.LOGINFO)
                try:
                    self._epg_data = load_epg(epg_xml_path)
                    xbmc.log("[ADDON] EPG carregado do cache com sucesso.", level=xbmc.LOGINFO)
                    return self._epg_data
                except Exception as e:
                    xbmc.log(f"[ADDON] Erro ao carregar EPG do cache: {e}", level=xbmc.LOGERROR)
        
        # Se o cache não for válido ou o servidor mudou, tenta baixar o arquivo novamente
        xbmc.log("[ADDON] Baixando novo EPG...", level=xbmc.LOGINFO)
        try:
            epg_url = api.get_epg_url()
            response = requests.get(epg_url, timeout=120)
            response.raise_for_status()
            if not xbmcvfs.exists(PROFILE_DIR):
                xbmcvfs.mkdir(PROFILE_DIR)
            with xbmcvfs.File(epg_xml_path, 'w') as f:
                f.write(response.text)
            self._epg_data = load_epg(epg_xml_path)
            xbmc.log("[ADDON] EPG baixado e salvo com sucesso.", level=xbmc.LOGINFO)
        except Timeout as e:
            xbmc.log(f"[ADDON] Erro de tempo limite ao baixar o EPG: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de EPG", "Tempo limite excedido ao baixar o EPG. A conexão está muito lenta.")
            self._epg_data = {'channels': {}, 'progs': {}}
        except Exception as e:
            xbmc.log(f"[ADDON] Erro ao baixar ou salvar o EPG: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de EPG", "Não foi possível baixar o EPG. Tente novamente mais tarde.")
            self._epg_data = {'channels': {}, 'progs': {}}
        
        return self._epg_data

def get_remote_credentials():
    try:
        xbmc.log(f"[ADDON] Tentando baixar credenciais de: {REMOTE_CREDENTIALS_URL}", level=xbmc.LOGINFO)
        response = requests.get(REMOTE_CREDENTIALS_URL, timeout=15)
        response.raise_for_status()
        data = json.loads(response.text)
        return data.get('server'), data.get('username'), data.get('password')
    except Exception as e:
        xbmc.log(f"[ADDON] Erro de conexão ou requisição ao baixar credenciais: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Conexão", "Não foi possível baixar as credenciais do servidor remoto.")
        return None, None, None

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_dir(name, query, icon='https://i.imgur.com/j47gcaz.png', fanart='https://i.imgur.com/VwCHr1G.jpeg', is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
    url = build_url(query)
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def main_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Menu Principal")
    add_dir("TV", {'action': 'list_live_categories'})
    add_dir("Filmes", {'action': 'list_vod_categories'})
    add_dir("Séries", {'action': 'list_series_categories'})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def show_epg_menu(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Guia de Programação (EPG)")
    epg_data = EpgCache().get_epg_data(api)
    channels = epg_data.get('channels', {})
    if not channels:
        xbmcgui.Dialog().ok("Aviso", "EPG não disponível ou vazio.")
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    sorted_channels = sorted(channels.items(), key=lambda x: x[1])
    for channel_id, channel_name in sorted_channels:
        current_show, next_show = epg_lookup_current_next(channel_id, epg_data)
        summary = ""
        if current_show:
            start_time = time.strftime('%H:%M', time.localtime(current_show['start']))
            end_time = time.strftime('%H:%M', time.localtime(current_show['end']))
            summary += f"Agora: {current_show['title']} ({start_time}-{end_time})"
            if current_show.get('desc'):
                summary += f"\nSinopse: {current_show['desc']}"
        if next_show:
            start_time_next = time.strftime('%H:%M', time.localtime(next_show['start']))
            summary += f"\nPróximo: {next_show['title']} ({start_time_next})"
        li = xbmcgui.ListItem(label=f"{channel_name}")
        li.setLabel2(summary)
        li.setInfo('video', {'plot': summary, 'title': channel_name})
        url = build_url({'action': 'noop'})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_live_categories(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias Ao Vivo")
    categories = api.get_live_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = ADDON.getSettingBool('adult_filter')
    add_dir("Todos os Canais", {'action': 'list_live_streams', 'category_id': '0'})
    for category in categories:
        if adult_filter_enabled and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(category['category_name'], {'action': 'list_live_streams', 'category_id': category['category_id']})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_live_streams(api, category_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Canais Ao Vivo")
    streams = api.get_live_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    enable_epg = ADDON.getSettingBool('enable_epg')
    epg_data = EpgCache().get_epg_data(api) if enable_epg else {'channels': {}, 'progs': {}}

    for stream in streams:
        title = stream.get('name', 'Sem Título')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        epg_channel_id = stream.get('epg_channel_id', None)

        label_epg = title
        info_title = title
        plot = "Sinopse não disponível."
        epg_text = ""

        if enable_epg and epg_channel_id:
            epg_channel_id_normalized = normalize_epg_channel_id(epg_channel_id)
            current_show, next_show = epg_lookup_current_next(epg_channel_id_normalized, epg_data)

            if current_show:
                start_time = time.strftime('%H:%M', time.localtime(current_show['start']))
                end_time = time.strftime('%H:%M', time.localtime(current_show['end']))
                label_epg = f"{title} | {current_show['title']} ({start_time}-{end_time})"
                epg_text = f"Agora: {current_show['title']} ({start_time}-{end_time})"
                if current_show.get('desc'):
                    epg_text += f"\nSinopse: {current_show['desc']}"
                info_title = f"{title} - {current_show['title']}"
                plot = current_show.get('desc', 'Sinopse não disponível.')
            else:
                label_epg = f"{title} | EPG não disponível"
                epg_text = "EPG não disponível."
                info_title = title
                plot = "Sinopse não disponível."
            if next_show:
                start_time_next = time.strftime('%H:%M', time.localtime(next_show['start']))
                epg_text += f"\nPróximo: {next_show['title']} ({start_time_next})"
        else:
            label_epg = title
            info_title = title
            plot = "Sinopse não disponível."
            epg_text = "EPG desativado ou não disponível."

        li = xbmcgui.ListItem(label=label_epg)
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': info_title, 'plot': epg_text, 'plotoutline': epg_text})
        li.setLabel2(epg_text)
        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'live', 'title': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_categories(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias Filmes (VOD)")
    categories = api.get_vod_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = ADDON.getSettingBool('adult_filter')
    add_dir("Todos os Filmes", {'action': 'list_vod_streams', 'category_id': '0'})
    for category in categories:
        if adult_filter_enabled and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(category['category_name'], {'action': 'list_vod_streams', 'category_id': category['category_id']})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_streams(api, category_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Filmes (VOD)")
    streams = api.get_vod_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    for stream in streams:
        title = stream.get('name', 'Sem Título')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        plot = stream.get('plot', 'Sinopse não disponível.')
        rating_raw = stream.get('rating', '0')
        genre = stream.get('genre', 'N/A')
        releasedate_raw = stream.get('releasedate', 'N/A')

        rating_str = str(rating_raw)
        releasedate_str = str(releasedate_raw)
        rating = float(rating_str) if rating_str.replace('.', '', 1).isdigit() else 0
        year = int(releasedate_str.split('-')[0]) if releasedate_str and releasedate_str.replace('-', '', 1).isdigit() else 0

        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setInfo('video', {
            'title': title,
            'plot': plot,
            'rating': rating,
            'genre': genre,
            'year': year
        })
        li.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'title': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_series_categories(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias Séries")
    categories = api.get_series_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = ADDON.getSettingBool('adult_filter')
    add_dir("Todas as Séries", {'action': 'list_series', 'category_id': '0'})
    for category in categories:
        if adult_filter_enabled and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(category['category_name'], {'action': 'list_series', 'category_id': category['category_id']})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_series(api, category_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Séries")
    series = api.get_series(category_id)
    if series is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    for serie in series:
        title = serie.get('name', 'Sem Título')
        series_id = serie.get('series_id')
        series_icon = serie.get('cover', 'DefaultVideo.png')
        plot = serie.get('plot', 'Sinopse não disponível.')
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': series_icon, 'icon': series_icon, 'fanart': series_icon})
        li.setInfo('video', {'title': title, 'plot': plot})
        url = build_url({'action': 'list_episodes', 'series_id': series_id})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_episodes(api, series_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Episódios")
    series_info = api.get_series_info(series_id)
    if not series_info or 'episodes' not in series_info:
        xbmcgui.Dialog().ok("Aviso", "Nenhum episódio encontrado para esta série.")
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes_by_season = series_info['episodes']
    series_icon = series_info.get('info', {}).get('cover', 'DefaultVideo.png')
    for season_number, episodes in episodes_by_season.items():
        season_title = f"Temporada {season_number}"
        add_dir(season_title, {'action': 'list_episodes_for_season', 'series_id': series_id, 'season_number': season_number, 'series_icon': series_icon}, icon=series_icon, fanart=series_icon)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_episodes_for_season(api, series_id, season_number, series_icon=None):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Temporada {season_number}")
    series_info = api.get_series_info(series_id)
    if not series_info or 'episodes' not in series_info:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes = series_info['episodes'].get(season_number, [])
    default_icon = "DefaultVideo.png"
    season_icon = default_icon
    if 'seasons' in series_info:
        season_data = series_info['seasons'].get(str(season_number)) or series_info['seasons'].get(int(season_number)) if isinstance(season_number, int) else None
        if season_data and isinstance(season_data, dict):
            season_icon = season_data.get('cover', default_icon)
    if not season_icon or season_icon == default_icon:
        if series_icon:
            season_icon = series_icon

    for episode in episodes:
        episode_id = episode.get('id')
        title = episode.get('title', 'Sem Título')
        episode_num_raw = episode.get('episode_num')
        try:
            episode_num = int(episode_num_raw)
            label = f"E{episode_num:02d} - {title}"
        except (ValueError, TypeError):
            label = f"E{episode_num_raw} - {title}"

        plot = episode.get('info', {}).get('plot', 'Sinopse não disponível.')
        releasedate = episode.get('info', {}).get('releasedate', 'N/A')
        episode_icon = episode.get('info', {}).get('cover') or season_icon or default_icon
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': episode_icon, 'icon': episode_icon, 'fanart': episode_icon})
        li.setInfo('video', {'title': title, 'plot': plot, 'season': int(season_number) if str(season_number).isdigit() else season_number, 'episode': episode_num_raw})
        li.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_stream', 'stream_id': episode_id, 'stream_type': 'series', 'title': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def play_stream(api, stream_id, stream_type, title):
    xbmc.log(f"[ADDON] Reproduzindo stream_id: {stream_id}, tipo: {stream_type}", level=xbmc.LOGINFO)
    stream_url = ""
    if stream_type == 'live':
        stream_url = api.get_live_stream_url(stream_id)
    elif stream_type == 'vod':
        stream_url = api.get_vod_stream_url(stream_id)
    elif stream_type == 'series':
        stream_url = api.get_series_stream_url(stream_id)
    if not stream_url:
        xbmc.log(f"[ADDON] URL de stream não encontrada para o tipo {stream_type} e ID {stream_id}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Reprodução", "URL do stream não encontrada.")
        return
    if '.m3u8' in stream_url.lower():
        proxy_addon = HLSAddon(ADDON_HANDLE)
        proxy_addon.play_stream(stream_url, stream_type, title)
    else:
        proxy_addon = VODAddon(ADDON_HANDLE)
        proxy_addon.play_stream(stream_url, stream_type, title)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')
    server, username, password = get_remote_credentials()
    if not all([server, username, password]):
        return
    api = XtreamAPI(server, username, password)
    if action is None:
        main_menu()
    elif action == 'list_live_categories':
        list_live_categories(api)
    elif action == 'list_live_streams':
        list_live_streams(api, params['category_id'])
    elif action == 'list_vod_categories':
        list_vod_categories(api)
    elif action == 'list_vod_streams':
        list_vod_streams(api, params['category_id'])
    elif action == 'list_series_categories':
        list_series_categories(api)
    elif action == 'list_series':
        list_series(api, params['category_id'])
    elif action == 'list_episodes':
        list_episodes(api, params['series_id'])
    elif action == 'list_episodes_for_season':
        list_episodes_for_season(api, params['series_id'], params['season_number'], params.get('series_icon'))
    elif action == 'play_stream':
        play_stream(api, params['stream_id'], params['stream_type'], params.get('title'))
    elif action == 'show_epg':
        show_epg_menu(api)
    elif action == 'noop':
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

if __name__ == '__main__':
    router(sys.argv[2][1:])