# -*- coding: utf-8 -*-
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver

import requests
from requests.adapters import HTTPAdapter

from doh_client import requests as doh_requests

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------
MAX_RETRIES = 15
RETRY_BACKOFF_FACTOR = 4.0
CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 1024 * 64  # 64 KB
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"
MAX_CONSECUTIVE_SEGMENT_ERRORS = 5
MAX_MANIFEST_RETRIES = 15
# ----------------------------------

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------
def setup_logging():
    """Configura o sistema de logging."""
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')


def get_forward_headers(client_headers):
    """Encaminha alguns headers importantes e adiciona um User-Agent rotativo."""
    chrome_version = random.randint(110, 122)
    user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_version}.0.0.0 Safari/537.36"
    
    headers = {
        'User-Agent': user_agent,
        'Connection': 'keep-alive',
        'Accept-Encoding': 'identity'
    }
    if 'Authorization' in client_headers:
        headers['Authorization'] = client_headers['Authorization']
    if 'Cookie' in client_headers:
        headers['Cookie'] = client_headers['Cookie']
    
    return headers


def backoff_wait(attempt):
    """Calcula tempo de espera exponencial com jitter."""
    return RETRY_BACKOFF_FACTOR * (2 ** attempt) + random.uniform(0, 1)


# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    """Manipulador de requisições para o proxy HLS."""
    manifest_session = doh_requests.session
    segment_session = doh_requests.session

    adapter = HTTPAdapter(max_retries=0)
    manifest_session.mount('http://', adapter)
    manifest_session.mount('https://', adapter)
    segment_session.mount('http://', adapter)
    segment_session.mount('https://', adapter)

    error_counter = {}

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - \"{format % args}\"")

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404, "Not Found")
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400, "Bad Request: 'url' parameter missing")
                return

            headers = get_forward_headers(self.headers)

            parsed_url = urllib.parse.urlparse(url)
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, session_id, head_only)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou a conexão.")
        except Exception as e:
            logging.error(f"Erro inesperado no handler GET: {e}", exc_info=True)
            if not self.wfile.closed:
                try:
                    self.send_error(500, "Internal Proxy Error")
                except Exception:
                    pass

    def _handle_manifest(self, url, headers, session_id, head_only):
        """Serve manifestos com URLs reescritas."""
        response = None
        for i in range(MAX_MANIFEST_RETRIES):
            try:
                response = self.manifest_session.get(
                    url, headers=headers,
                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                    verify=False, allow_redirects=True
                )
                response.raise_for_status()
                break
            except requests.exceptions.HTTPError as e:
                if response: response.close()
                wait_time = backoff_wait(i)
                if e.response and e.response.status_code == 429:
                    retry_after = e.response.headers.get("Retry-After")
                    if retry_after and retry_after.isdigit():
                        wait_time = int(retry_after)
                logging.warning(f"Manifesto erro {e}. Retentando em {wait_time:.2f}s...")
                time.sleep(wait_time)
            except requests.exceptions.RequestException as e:
                if response: response.close()
                wait_time = backoff_wait(i)
                logging.warning(f"Manifesto falhou {e}. Retentando em {wait_time:.2f}s...")
                time.sleep(wait_time)
        else:
            self.send_error(503, "Service Unavailable: Retries exhausted for manifest")
            return

        manifest_content = response.text
        base_url = response.url
        response.close()

        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()

        if head_only:
            return

        new_manifest_lines = []
        for line in manifest_content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                new_manifest_lines.append(line)
            else:
                full_url = urllib.parse.urljoin(base_url, stripped)
                proxy_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={session_id}"
                new_manifest_lines.append(proxy_url)
        
        self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
        self.wfile.flush()

    def _handle_segment(self, url, session_id, headers, head_only):
        """Serve segmentos individuais com retentativas robustas."""
        response = None
        for i in range(MAX_RETRIES):
            try:
                response = self.segment_session.get(
                    url, headers=headers, stream=True,
                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                    verify=False
                )
                if response.status_code == 404:
                    response.close()
                    errors = self.error_counter.get(session_id, 0) + 1
                    self.error_counter[session_id] = errors
                    if errors >= MAX_CONSECUTIVE_SEGMENT_ERRORS:
                        self.send_error(404, "Segment not found permanently")
                        return
                    self.send_error(503, "Segment temporarily unavailable")
                    return

                response.raise_for_status()
                self.error_counter[session_id] = 0

                self.send_response(200)
                for h, v in response.headers.items():
                    if h.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                        self.send_header(h, v)
                self.end_headers()

                if head_only:
                    response.close()
                    return

                for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if not chunk:
                        continue
                    self.wfile.write(chunk)
                    self.wfile.flush()
                response.close()
                return
            except Exception as e:
                if response: response.close()
                wait_time = backoff_wait(i)
                logging.warning(f"Segmento erro {e}. Retentando em {wait_time:.2f}s...")
                time.sleep(wait_time)
        self.send_error(502, "Bad Gateway: Retries exhausted for segment")

    def do_OPTIONS(self):
        self.send_response(200, "OK")
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()


# ---------------- MANAGER ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer(
                    (PROXY_HOST, port), HLSProxyRequestHandler, bind_and_activate=False
                )
                self.server.allow_reuse_address = True
                self.server.server_bind()
                self.server.server_activate()
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy HLS iniciado em http://{PROXY_HOST}:{port}")
                return True
            except OSError:
                continue
        logging.error("Não foi possível iniciar o proxy HLS.")
        return False

    def stop(self):
        if self.server:
            logging.info("Parando proxy HLS...")
            self.server.shutdown()
            self.server.server_close()
            self.thread.join()


# ---------------- ADDON ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro Proxy HLS", "Não foi possível iniciar.", xbmcgui.NOTIFICATION_ERROR)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        li = xbmcgui.ListItem(path=proxy_url)
        if title:
            li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        if stype == "live":
            li.setMimeType("application/vnd.apple.mpegurl")
        xbmcplugin.setResolvedUrl(self.handle, True, li)


def main():
    setup_logging()
    try:
        handle = int(sys.argv[1])
        addon = HLSAddon(handle)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', ['live'])[0]
            title = args.get('title', [None])[0]
            if stream_url:
                addon.play_stream(stream_url, stream_type, title)
            else:
                xbmcplugin.endOfDirectory(handle, succeeded=False)
        else:
            xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        logging.error(f"Erro fatal: {e}", exc_info=True)
        if len(sys.argv) > 1:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)


if __name__ == '__main__':
    main()