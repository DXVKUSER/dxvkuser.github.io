import sys
import threading
import socket
import re
import random
import time
import requests
from urllib.parse import urlparse, parse_qs, urljoin
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

# Desativa avisos de SSL
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# --- CONFIGURAÇÃO INICIAL ---
CONFIG = {
    "PORT": 8010,
    "BIND": "127.0.0.1",
    "MAX_REDIRECTS": 5,
    "CHUNK_SIZE": 65536,
    "DEFAULT_TIMEOUT": 15,
    "MAX_FAILURES": 3,
    "CIRCUIT_TTL": 10,  # Segundos para resetar disjuntor
    "LIST_UA": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (SmartTV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/76.0.3809.146 TV Safari/537.36"
    ]
}

# --- 1. GERENCIADOR DE SESSÕES (SESSION MANAGER) ---

class SessionManager:
    def __init__(self):
        self.sessions = {}
        self.failure_count = 0
        self.last_failure_time = 0
        self.lock = threading.Lock()
        self.current_ua = random.choice(CONFIG["LIST_UA"])
        self.fake_ip = self._gen_ip()

    def _gen_ip(self):
        return f"{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"

    def get_session(self, stream_id="default"):
        with self.lock:
            # Circuit Breaker: Verifica se o sistema está em "cooldown" após falhas
            if self.failure_count >= CONFIG["MAX_FAILURES"]:
                if time.time() - self.last_failure_time < CONFIG["CIRCUIT_TTL"]:
                    return None  # Disjuntor aberto
                else:
                    self.failure_count = 0  # Reset após TTL

            if stream_id not in self.sessions:
                self.sessions[stream_id] = requests.Session()
            return self.sessions[stream_id]

    def report_failure(self):
        with self.lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            # Backoff Exponencial Simples: Troca de identidade imediata
            self.current_ua = random.choice(CONFIG["LIST_UA"])
            self.fake_ip = self._gen_ip()
            for s in self.sessions.values(): s.close()
            self.sessions.clear()

    def global_reset(self):
        with self.lock:
            self.failure_count = 0
            for s in self.sessions.values(): s.close()
            self.sessions.clear()

session_manager = SessionManager()

# --- 2. MONITOR DE SAÚDE GLOBAL (GLOBAL HEALTH MONITOR) ---

class GlobalHealthMonitor(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.internet_stable = True

    def run(self):
        while True:
            try:
                # Ping rápido DNS do Google para checar conectividade
                socket.create_connection(("8.8.8.8", 53), timeout=3)
                if not self.internet_stable:
                    session_manager.global_reset()
                    self.internet_stable = True
            except OSError:
                self.internet_stable = False
            time.sleep(10)

# --- 3. AJUSTE DINÂMICO DE CONFIGURAÇÃO ---

class DynamicConfigAdjuster(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.latencies = []

    def add_latency(self, val):
        self.latencies.append(val)
        if len(self.latencies) > 20: self.latencies.pop(0)

    def run(self):
        global CONFIG
        while True:
            if self.latencies:
                avg = sum(self.latencies) / len(self.latencies)
                # Se a latência média subir, aumentamos o timeout preventivamente
                if avg > 2.0:
                    CONFIG["DEFAULT_TIMEOUT"] = 25
                else:
                    CONFIG["DEFAULT_TIMEOUT"] = 15
            time.sleep(30)

monitor = GlobalHealthMonitor()
monitor.start()
adjuster = DynamicConfigAdjuster()
adjuster.start()

# --- 4. PROXY CORE (INTEGRANDO REDIRECT MANUAL + VALIDAÇÃO) ---



class HLSProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args): return

    def _get_headers(self, url):
        parsed = urlparse(url)
        return {
            "User-Agent": session_manager.current_ua,
            "Host": parsed.netloc,
            "Origin": f"{parsed.scheme}://{parsed.netloc}",
            "Referer": f"{parsed.scheme}://{parsed.netloc}/",
            "X-Forwarded-For": session_manager.fake_ip,
            "Accept": "*/*",
            "Connection": "keep-alive"
        }

    def _fetch(self, url, stream=False):
        session = session_manager.get_session()
        if not session: return None, url # Disjuntor Ativo

        start_t = time.time()
        curr_url = url
        for _ in range(CONFIG["MAX_REDIRECTS"]):
            try:
                r = session.get(curr_url, headers=self._get_headers(curr_url), 
                               stream=stream, verify=False, 
                               timeout=CONFIG["DEFAULT_TIMEOUT"], allow_redirects=False)
                
                if r.status_code in [301, 302, 303, 307, 308]:
                    curr_url = urljoin(curr_url, r.headers.get('Location'))
                    continue
                
                adjuster.add_latency(time.time() - start_t)
                return r, curr_url
            except Exception:
                session_manager.report_failure()
                break
        return None, curr_url

    def do_GET(self):
        params = parse_qs(urlparse(self.path).query)
        target = params.get('url', [None])[0]
        if not target: return

        if "/play" in self.path: self.handle_m3u8(target)
        else: self.handle_ts(target)

    def handle_m3u8(self, url):
        resp, final_url = self._fetch(url, stream=False)
        if not resp or resp.status_code != 200 or "#EXTM3U" not in resp.text:
            session_manager.report_failure()
            self.send_error(503)
            return

        base = final_url.rsplit('/', 1)[0] + "/"
        local = self.headers.get('Host')
        output = []
        for line in resp.text.splitlines():
            line = line.strip()
            if not line: continue
            if "#EXT-X-KEY" in line:
                m = re.search(r'URI=["\'](.*?)["\']', line)
                if m:
                    abs_key = urljoin(base, m.group(1))
                    line = line.replace(m.group(1), f"http://{local}/key?url={abs_key}")
                output.append(line)
            elif line.startswith("#"): output.append(line)
            else:
                full = line if line.startswith("http") else urljoin(base, line)
                tag = "/play?url=" if ".m3u8" in line else "/stream?url="
                output.append(f"http://{local}{tag}{full}")

        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.end_headers()
        self.wfile.write("\n".join(output).encode())

    def handle_ts(self, url):
        resp, _ = self._fetch(url, stream=True)
        if not resp or resp.status_code != 200:
            self.send_error(502)
            return

        it = resp.iter_content(CONFIG["CHUNK_SIZE"])
        try:
            chunk = next(it)
            # VALIDAÇÃO SYNC BYTE 0x47
            if "/stream" in self.path and chunk[0] != 0x47:
                session_manager.report_failure()
                self.send_error(503)
                return
            
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.end_headers()
            self.wfile.write(chunk)
            for c in it: self.wfile.write(c)
        except:
            session_manager.report_failure()

# --- 5. SINGLETON KODI INTEGRATION ---

class HLSAddon:
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls)
            cls._instance._init = False
        return cls._instance

    def __init__(self, *args):
        if self._init: return
        self.handle = int(args[0]) if args and str(args[0]).isdigit() else -1
        self._init = True
        self._start()

    def _start(self):
        try:
            s = socket.socket()
            if s.connect_ex((CONFIG["BIND"], CONFIG["PORT"])) != 0:
                threading.Thread(target=HTTPServer((CONFIG["BIND"], CONFIG["PORT"]), HLSProxyHandler).serve_forever, daemon=True).start()
            s.close()
        except: pass

    def play_stream(self, url, title="Survival Stream"):
        import xbmcgui, xbmcplugin
        l_url = f"http://{CONFIG['BIND']}:{CONFIG['PORT']}/play?url={url}"
        item = xbmcgui.ListItem(label=title, path=l_url)
        try:
            tag = item.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('video')
        except:
            item.setInfo('video', {'title': title})
        item.setProperty('IsPlayable', 'true')
        if self.handle != -1: xbmcplugin.setResolvedUrl(self.handle, True, item)

if __name__ == "__main__":
    HTTPServer((CONFIG["BIND"], CONFIG["PORT"]), HLSProxyHandler).serve_forever()