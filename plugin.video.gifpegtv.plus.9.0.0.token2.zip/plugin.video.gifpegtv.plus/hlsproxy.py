#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — Proxy HLS/MPEG-TS com melhorias contra travamentos para Kodi
Melhorias aplicadas:
 - Lógica de renovação de token no segmento aprimorada: 
   - Se falha 403/404, tenta renovar o token do manifesto e *reutiliza* o segmento.
 - Reset de sessão e renovação de token forçada após falha total de rede/timeout.
 - Preservação do título original do canal.
 - Corrigido IndentationError no método stop().
"""
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
from socketserver import ThreadingMixIn
import socketserver
import socket 

# ************************************************************
# ALTERAÇÃO SOLICITADA: Usando requests com DoH
# ************************************************************
from doh_client import requests
# ************************************************************

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests import Session

# Tentativa de importar libs do Kodi (fingir se não existir)
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    KODI_ENV = True
except Exception:
    class MockKodi:
        def translatePath(self, path): return os.path.join(os.path.dirname(os.path.abspath(__file__)), "kodi_temp")
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    KODI_ENV = False

# ---------------- CONFIG ----------------
MAX_SEGMENT_RETRIES = 4 
RETRY_BACKOFF_FACTOR = 0.2
CONNECTION_TIMEOUT = 10.0 
STREAM_TIMEOUT = 30.0 
DEFAULT_CHUNK_SIZE = 1024 * 128    # 128 KB por chunk (Base)
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 30 
LOG_FILE = "hls_proxy.log"
MANIFEST_RETRY_DELAY = 0.15
MAX_CONSECUTIVE_SEGMENT_ERRORS = 10 

# User-Agent template
USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.{version} Safari/537.36"

# Cache de URLs resolvidas (manifest/base) (original_url -> (resolved_url, expires_at))
RESOLVED_CACHE_TTL = 360  # TTL para manifiesto/base (6 minutos)

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Dummy TS Content (segmento silencioso) - Pacote TS Vazio
TS_PACKET_SIZE = 188
SILENT_AAC_TS_PACKET = b'\x47\x00\x10\x00' + (b'\x00' * 184) 
SILENT_AAC_TS_CONTENT = SILENT_AAC_TS_PACKET * 10

# ---------------- LOGGING ----------------
def setup_logging():
    try:
        # CORREÇÃO: Verifica se 'translatePath' existe no módulo xbmc, 
        # pois alguns ambientes Kodi podem não ter a função disponível diretamente, 
        # mesmo que a importação de 'xbmc' tenha sido bem-sucedida.
        if KODI_ENV and hasattr(xbmc, 'translatePath'):
            log_dir = xbmc.translatePath('special://logpath')
        else:
            # Fallback para ambientes não-Kodi ou Kodi sem translatePath
            log_dir = os.path.dirname(os.path.abspath(__file__))
        
        log_path = os.path.join(log_dir, LOG_FILE)
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(levelname)s: %(message)s',
            handlers=[logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=True)]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
        logging.warning("Falha ao configurar logging em arquivo. Usando console.")

setup_logging() 

# ---------------- SESSÃO HTTP ----------------
def _create_new_session(pool_maxsize=100): 
    """Cria sessão requests com um pool maior e estratégia de retry."""
    # A sessão requests é agora a do doh_client, mas a lógica de retry
    # e adaptador é aplicada à sessão interna que ele usa (`requests_.Session()`)
    # O doh_client.requests usa uma sessão global, então não a criamos aqui.
    # A estratégia de retry é aplicada ao adaptador, que é montado na sessão
    # global que o doh_client usa.
    s = requests.session # A sessão que o doh_client usa
    retry_strategy = Retry(
        total=5, 
        read=5,
        connect=5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"],
        backoff_factor=RETRY_BACKOFF_FACTOR
    )
    adapter = HTTPAdapter(pool_connections=pool_maxsize, pool_maxsize=pool_maxsize, max_retries=retry_strategy)
    s.mount('http://', adapter)
    s.mount('https://', adapter)
    return s, adapter

# Sessão global (reutilizada)
GLOBAL_SESSION, GLOBAL_ADAPTER = _create_new_session()

# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    # Estado compartilhado
    # Usamos o requests com DoH diretamente para as chamadas.
    # Mantemos session e adapter, mas a criação é um pouco diferente
    # já que o doh_client gerencia a sessão requests internamente.
    session = GLOBAL_SESSION
    adapter = GLOBAL_ADAPTER

    # caches & locks
    resolved_cache = {}  
    resolved_cache_lock = threading.Lock()

    # estatísticas por sessão
    error_counter = {}
    manifest_duration = 6.0
    network_quality = {}
    dynamic_chunk_size = {}
    dynamic_stream_timeout = {}
    last_segment_times = {}
    last_segment_sizes = {}
    session_ua_versions = {}
    session_manifest_refresh = {}
    session_original_manifest_url = {} # Armazena a URL base sem token para renovação

    MAX_TIMES_TO_AVERAGE = 12 
    DEFAULT_DUMMY_SIZE_BYTES = 50 * 1024 

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    # ---------------- utilitários de sessão/UA ----------------
    def _get_session_user_agent(self, session_id):
        version = HLSProxyRequestHandler.session_ua_versions.get(session_id)
        if version is None:
            version = random.randint(1000, 9000)
            HLSProxyRequestHandler.session_ua_versions[session_id] = version
        return USER_AGENT_TEMPLATE.format(version=version)

    def _rotate_session_user_agent(self, session_id):
        new_version = (HLSProxyRequestHandler.session_ua_versions.get(session_id, random.randint(1000,8999)) % 8000) + 1
        HLSProxyRequestHandler.session_ua_versions[session_id] = new_version
        logging.info(f"Rotacionando UA -> v{new_version} (sess: {session_id})")

    def _reset_session_and_retry(self, session_id):
        """Reinicia a sessão requests e força um refresh de manifesto na próxima requisição."""
        logging.critical(f"Reiniciando sessão HTTP (sess: {session_id})")
        self._rotate_session_user_agent(session_id)
        # Recria a sessão global. No doh_client, isso na verdade aplica a estratégia
        # de retry e adaptador na sessão interna dele.
        global GLOBAL_SESSION, GLOBAL_ADAPTER
        GLOBAL_SESSION, GLOBAL_ADAPTER = _create_new_session()
        HLSProxyRequestHandler.session = GLOBAL_SESSION
        HLSProxyRequestHandler.adapter = GLOBAL_ADAPTER
        # Força o próximo MANIFEST a ser resolvido novamente, gerando novo token
        HLSProxyRequestHandler.session_manifest_refresh[session_id] = time.time()
        self.error_counter[session_id] = 0

    def _get_forward_headers(self, session_id):
        ua = self._get_session_user_agent(session_id)
        headers = {
            'User-Agent': ua,
            'Connection': 'keep-alive',
        }
        if 'Authorization' in self.headers:
            headers['Authorization'] = self.headers['Authorization']
        if 'Cookie' in self.headers:
            headers['Cookie'] = self.headers['Cookie']
        if 'Range' in self.headers:
            headers['Range'] = self.headers['Range']
            
        return headers

    # ---------------- cache resolvido (manifest/base) ----------------
    @classmethod
    def _get_cached_resolved(cls, original_url):
        with cls.resolved_cache_lock:
            entry = cls.resolved_cache.get(original_url)
            if not entry:
                return None
            resolved, expires_at = entry
            if time.time() > expires_at:
                try:
                    del cls.resolved_cache[original_url]
                except KeyError:
                    pass
                return None
            return resolved

    @classmethod
    def _set_cached_resolved(cls, original_url, resolved_url, ttl=RESOLVED_CACHE_TTL):
        with cls.resolved_cache_lock:
            expires_at = time.time() + ttl
            cls.resolved_cache[original_url] = (resolved_url, expires_at)
            logging.info(f"Cache atualizado (manifest/base): {original_url} -> {resolved_url} (ttl={ttl}s)")

    def resolve_and_cache(self, original_url, session_id, force_refresh=False):
        """
        Resolve URL de manifesto/base, seguindo redirects. Retorna a URL final (com token, se houver).
        """
        clean_url = original_url.split('&session_id=')[0] 
        
        if not force_refresh:
            cached = self._get_cached_resolved(clean_url)
            if cached:
                logging.debug(f"Usando resolved cache para manifest/base: {clean_url} (sess: {session_id})")
                return cached

        headers = self._get_forward_headers(session_id)

        for attempt in range(3):
            try:
                logging.info(f"Tentando resolver manifest/base: {clean_url} (tent {attempt+1}/3) (sess: {session_id})")
                # Usa a requests com DoH
                r = requests.get(clean_url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                final_url = r.url
                
                if r.status_code >= 400:
                    logging.warning(f"Resolver manifesto retornou {r.status_code}. Rotacionando UA.")
                    self._rotate_session_user_agent(session_id)
                    time.sleep(MANIFEST_RETRY_DELAY * (2 ** attempt))
                    continue
                
                self._set_cached_resolved(clean_url, final_url)
                return final_url
            
            except requests.exceptions.RequestException as e:
                logging.warning(f"Erro ao resolver manifesto {clean_url}: {e}")
                time.sleep(min(RETRY_BACKOFF_FACTOR * (2 ** attempt), 2.0))
                continue

        logging.error(f"Falha completa ao resolver manifesto: {clean_url}")
        return clean_url 

    # ---------------- GET / HEAD ----------------
    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?',1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400)
                return

            self._initialize_session_quality(session_id) 

            headers = self._get_forward_headers(session_id)
            parsed = urllib.parse.urlparse(url)
            path_lower = parsed.path.lower()

            if path_lower.endswith(('.m3u8', '.m3u', '.m3u8/')) or 'manifest' in parsed.query.lower():
                self._handle_manifest(url, headers, head_only, session_id)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado em do_GET: {e}", exc_info=True)
            try:
                self.send_error(500, message="Proxy Internal Error")
            except Exception:
                pass

    # ---------------- MANIFEST HANDLER (rewrite) ----------------
    def _handle_manifest(self, url, headers, head_only, session_id):
        """
        - Faz pre-resolve (cache) se necessário.
        - Reescreve URLs para apontar ao proxy.
        """
        original_manifest_url = url.split('&session_id=')[0]
        
        try:
            force_refresh = HLSProxyRequestHandler.session_manifest_refresh.pop(session_id, None) is not None
            if force_refresh:
                logging.info(f"Manifest fetch com sessão renovada (sess: {session_id})")
            
            # Baixa manifesto (seguindo redirects)
            # Usa a requests com DoH
            r = requests.get(original_manifest_url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
            r.raise_for_status()

            manifest_text = r.text
            resolved_manifest_url = r.url
            
            # Salva resolved manifest / base na cache
            self._set_cached_resolved(original_manifest_url, resolved_manifest_url)
            HLSProxyRequestHandler.session_original_manifest_url[session_id] = original_manifest_url # Guarda original para referência em segmentos
            
            # Determina base para resoluções relativas
            base_path = resolved_manifest_url.rsplit('/',1)[0] + '/'

            # Calcula duração média dos segmentos
            total_dur = 0.0
            cnt = 0
            for line in manifest_text.splitlines():
                if line.startswith('#EXTINF:'):
                    try:
                        dur = float(line.split('#EXTINF:')[1].split(',')[0])
                        total_dur += dur
                        cnt += 1
                    except Exception:
                        pass
            if cnt > 0:
                HLSProxyRequestHandler.manifest_duration = max(total_dur / cnt, 1.0)
                logging.info(f"Duração média segmento detectada: {HLSProxyRequestHandler.manifest_duration:.2f}s (sess: {session_id})")

            # Reescreve manifesto: para cada linha não-# cria URL proxied
            new_lines = []
            for line in manifest_text.splitlines():
                s = line.strip()
                if not s or s.startswith('#'):
                    new_lines.append(line)
                    continue
                
                # s é uma URL relativa ou absoluta de segmento
                if not urllib.parse.urlparse(s).netloc:
                    full_segment_url = urllib.parse.urljoin(base_path, s)
                else:
                    full_segment_url = s

                # O segmento é proxied com sua URL absoluta. 
                proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&session_id={session_id}"
                new_lines.append(proxy_segment_url)

            # Envia resposta
            self.send_response(200)
            self.send_header('Content-Type', r.headers.get('Content-Type', 'application/vnd.apple.mpegurl'))
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()
            
            if not head_only:
                body = '\n'.join(new_lines).encode('utf-8')
                try:
                    self.wfile.write(body)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    logging.warning("Cliente fechou conexão durante envio de manifesto.")

        except requests.exceptions.HTTPError as e:
            logging.error(f"HTTP error ao obter manifesto: {e} (Status: {getattr(e.response, 'status_code', 'N/A')})")
            if getattr(e.response, 'status_code', 0) in (403, 404):
                self._rotate_session_user_agent(session_id)
            try:
                self.send_error(404, message="Manifest Not Found/Expired")
            except Exception:
                pass
        except Exception as e:
            logging.error(f"Erro ao manipular manifesto: {e}", exc_info=True)
            try:
                self.send_error(500, message="Proxy internal error (manifest)")
            except Exception:
                pass

    # ---------------- SEGMENT HANDLER ----------------
    def _handle_segment(self, url, session_id, headers, head_only):
        
        retries = 0
        consecutive_errors = self.error_counter.get(session_id, 0)
        self._initialize_session_quality(session_id)

        chunk_size = HLSProxyRequestHandler.dynamic_chunk_size.get(session_id, DEFAULT_CHUNK_SIZE)
        stream_timeout = HLSProxyRequestHandler.dynamic_stream_timeout.get(session_id, STREAM_TIMEOUT)

        bytes_downloaded = 0
        original_segment_url = url
        
        tried_refresh = False 
        
        while retries < MAX_SEGMENT_RETRIES:
            current_url = original_segment_url # Sempre tenta a URL original do segmento primeiro
            start_time = time.time()
            is_timeout = False
            
            try:
                logging.debug(f"Baixando segmento (tent {retries+1}/{MAX_SEGMENT_RETRIES}) de {current_url} (sess: {session_id})")
                
                # Usa a requests com DoH. Usa a sessão que tem o adaptador com retry montado.
                with HLSProxyRequestHandler.session.get(current_url, headers=headers, stream=True,
                                                        timeout=stream_timeout, verify=False) as r:
                    
                    if r.status_code >= 400:
                        raise requests.exceptions.HTTPError(f"HTTP {r.status_code}", response=r)

                    self.error_counter[session_id] = 0

                    self.send_response(r.status_code)
                    for hname, hval in r.headers.items():
                        if hname.lower() in ['transfer-encoding', 'connection', 'content-encoding']:
                            continue
                        self.send_header(hname, hval)
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()

                    if head_only:
                        content_len = int(r.headers.get('Content-Length', '0'))
                        self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=content_len)
                        return

                    for chunk in r.iter_content(chunk_size=chunk_size):
                        if not chunk:
                            continue
                        bytes_downloaded += len(chunk)
                        try:
                            self.wfile.write(chunk)
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                            logging.warning(f"Cliente fechou conexão durante streaming (sess: {session_id})")
                            self._update_network_quality(session_id, start_time, time.time(), success=False, size_bytes=bytes_downloaded)
                            return
                        except Exception as e:
                            logging.error(f"Erro ao enviar chunk para cliente: {e}")
                            self._reset_session_and_retry(session_id)
                            return
                            
                    self.wfile.flush() 
                    
                    self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=bytes_downloaded)
                    return

            except requests.exceptions.HTTPError as e:
                retries += 1
                consecutive_errors += 1
                self.error_counter[session_id] = consecutive_errors
                status_code = getattr(e.response, 'status_code', None)
                logging.warning(f"HTTP error no segmento {current_url} => {status_code} (retry {retries}) (sess: {session_id})")

                # Lógica de renovação de token: Se falha por 403/404 e ainda não tentou renovar...
                if status_code in (403, 404) and not tried_refresh:
                    manifest_url = HLSProxyRequestHandler.session_original_manifest_url.get(session_id)
                    if manifest_url:
                        logging.info("Token/URL expirado detectado. Forçando re-resolve do manifesto original para obter novo token.")
                        
                        # 1. Força o re-resolve do MANIFESTO (para gerar novo token no cache)
                        new_resolved_manifest_url = self.resolve_and_cache(manifest_url, session_id, force_refresh=True)
                        tried_refresh = True
                        
                        # 2. Reconstroi o original_segment_url para a próxima tentativa
                        #    Assumimos que o caminho relativo do segmento é o mesmo, mas a base (resolved_manifest_url) mudou o token.
                        parsed_manifest_base = new_resolved_manifest_url.rsplit('/',1)[0] + '/'
                        
                        # Extrai o caminho relativo/nome do segmento da URL que falhou
                        # Ex: Se falhou: http://203.57.82.79:8880/hls/3c32d4a9d2a7821b32f745be475619a9/83255_4993.ts
                        # E novo manifest é: http://185.40.4.105:80/live/HsVtsR/CGm7CS/83255.m3u8?token=NOVO
                        # A URL do segmento é reconstruída em relação ao resolved_manifest_url.
                        
                        # **MUDANÇA CRUCIAL:** Usamos o URL original do segmento (sem host) e resolvemos contra a base do NOVO manifesto.
                        
                        # Pega o caminho do segmento (ex: /hls/3c32d4a9d2a7821b32f745be475619a9/83255_4993.ts)
                        parsed_original_segment = urllib.parse.urlparse(original_segment_url)
                        segment_path_and_query = parsed_original_segment.path
                        
                        # Tentativa 1: Resolve contra a base da *nova* URL resolvida (que tem o token)
                        if segment_path_and_query.startswith('/'):
                             # Para URLs que resolvem para um path absoluto
                            base_url_for_segment = new_resolved_manifest_url.rsplit('/',1)[0]
                            new_segment_url = urllib.parse.urljoin(base_url_for_segment, segment_path_and_query)
                        else:
                            # Caso onde o segmento é relativo ao manifest base (mais comum)
                            base_url_for_segment = new_resolved_manifest_url.rsplit('/',1)[0] + '/'
                            new_segment_url = urllib.parse.urljoin(base_url_for_segment, parsed_original_segment.path.rsplit('/',1)[-1])
                        
                        original_segment_url = new_segment_url
                        
                        logging.info(f"Segmento será re-tentado com URL: {original_segment_url}")
                        # Retries continua para dar chance de funcionar com a URL renovada
                        continue # Volta para o topo do while, usando a original_segment_url atualizada

                if consecutive_errors >= MAX_CONSECUTIVE_SEGMENT_ERRORS:
                    logging.critical("Muitos erros consecutivos. Forçando reset de sessão e renovação de token.")
                    self._reset_session_and_retry(session_id)
                    # Não retorna aqui, cai no bloco de falha total para enviar o silencioso

                time.sleep(min(MANIFEST_RETRY_DELAY * (2 ** retries), 2.0))
                continue

            except requests.exceptions.RequestException as e:
                retries += 1
                is_timeout = isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectTimeout))
                consecutive_errors += 1
                self.error_counter[session_id] = consecutive_errors
                
                logging.warning(f"Erro de rede ao baixar segmento {current_url}: {e} (retry {retries}) (sess: {session_id})")
                self._update_network_quality(session_id, start_time, time.time(), success=False, is_timeout=is_timeout, size_bytes=0)

                # Reset se timeout persistente ou max retries atingido (e forçamos o refresh do token)
                if is_timeout or retries >= MAX_SEGMENT_RETRIES:
                    logging.critical("Timeout / Max retries no segmento. Reset, renovação de token e envio de segmento silencioso.")
                    
                    # Tenta renovar o token antes de desistir e enviar o segmento silencioso
                    manifest_url = HLSProxyRequestHandler.session_original_manifest_url.get(session_id)
                    if manifest_url:
                        self._reset_session_and_retry(session_id) # Reset da sessão
                        self.resolve_and_cache(manifest_url, session_id, force_refresh=True) # Renovação do token no cache
                    
                    self._send_silent_segment(session_id)
                    return

                time.sleep(min(RETRY_BACKOFF_FACTOR * (2 ** retries), 2.0))
                continue

            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente desconectado antes do fim da transferência.")
                self._update_network_quality(session_id, start_time, time.time(), success=False, size_bytes=bytes_downloaded)
                return

            except Exception as e:
                logging.error(f"Erro inesperado ao baixar segmento {original_segment_url}: {e}", exc_info=True)
                self._reset_session_and_retry(session_id)
                self._send_silent_segment(session_id)
                return

        # Se esgotou todas tentativas sem sucesso (incluindo tentativas após renovação de token)
        logging.critical("Segmento falhou após todas as tentativas. Forçando renovação de token e enviando segmento silencioso.")
        # Garante a renovação do token na falha final
        manifest_url = HLSProxyRequestHandler.session_original_manifest_url.get(session_id)
        if manifest_url:
            self._reset_session_and_retry(session_id) 
            self.resolve_and_cache(manifest_url, session_id, force_refresh=True) 
            
        self._send_silent_segment(session_id)

    # ---------------- Segmentos silenciosos (fallback) ----------------
    def _get_dynamic_silent_segment(self, session_id):
        sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])
        times = HLSProxyRequestHandler.last_segment_times.get(session_id, [])
        avg_bitrate = 0
        if sizes and times and len(sizes) == len(times):
            total_size = sum(sizes)
            total_time = sum(times)
            if total_time > 0:
                avg_bitrate = (total_size * 8) / total_time 
        
        target_duration = HLSProxyRequestHandler.manifest_duration

        if avg_bitrate > 0:
            target_size = int((avg_bitrate * target_duration) / 8) 
        else:
            target_size = self.DEFAULT_DUMMY_SIZE_BYTES
            
        target_size = max(target_size, self.DEFAULT_DUMMY_SIZE_BYTES)
        
        packets = (target_size // TS_PACKET_SIZE) + 1
        return SILENT_AAC_TS_PACKET * packets

    def _send_silent_segment(self, session_id):
        content = self._get_dynamic_silent_segment(session_id)
        logging.info(f"Enviando segmento silencioso de {len(content)} bytes (sess: {session_id})")
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            try:
                self.wfile.write(content)
                self.wfile.flush()
            except Exception:
                pass
        except Exception as e:
            logging.error(f"Erro ao enviar segmento silencioso: {e}")

    # ---------------- qualidade de rede / estatísticas ----------------
    def _initialize_session_quality(self, session_id):
        if session_id not in HLSProxyRequestHandler.network_quality:
            HLSProxyRequestHandler.network_quality[session_id] = "medium"
            HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
            HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            HLSProxyRequestHandler.last_segment_times[session_id] = []
            HLSProxyRequestHandler.last_segment_sizes[session_id] = []
            HLSProxyRequestHandler.session_ua_versions[session_id] = random.randint(1000,9000)

    def _update_network_quality(self, session_id, start_time, end_time, success, is_timeout=False, size_bytes=0):
        self._initialize_session_quality(session_id)
        duration = max(end_time - start_time, 0.0001)
        times = HLSProxyRequestHandler.last_segment_times[session_id]
        sizes = HLSProxyRequestHandler.last_segment_sizes[session_id]
        seglen = HLSProxyRequestHandler.manifest_duration

        if success:
            times.append(duration)
            if size_bytes > 0:
                sizes.append(size_bytes)
        else:
            penalty = seglen * 3.0 if is_timeout else seglen * 2.0
            times.append(penalty)

        while len(times) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE:
            times.pop(0)
        while len(sizes) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE:
            sizes.pop(0)

        if not times:
            return

        avg_time = sum(times) / len(times)
        prev = HLSProxyRequestHandler.network_quality.get(session_id, "medium")
        newq = prev
        
        if avg_time < seglen * 0.6: 
            newq = "good"
            new_chunk_size = 1024 * 256
            new_timeout = STREAM_TIMEOUT * 1.5
        elif avg_time < seglen * 1.5: 
            newq = "medium"
            new_chunk_size = DEFAULT_CHUNK_SIZE
            new_timeout = STREAM_TIMEOUT
        else: 
            newq = "bad"
            new_chunk_size = 1024 * 64 
            new_timeout = max(5.0, seglen * 1.5)

        if newq != prev:
            logging.info(f"Qualidade rede mudou de '{prev}' para '{newq}' (avg_time: {avg_time:.2f}s, seg_dur: {seglen:.2f}s) -> Chunk: {new_chunk_size//1024}KB, Timeout: {new_timeout:.1f}s")
            HLSProxyRequestHandler.network_quality[session_id] = newq
            HLSProxyRequestHandler.dynamic_chunk_size[session_id] = new_chunk_size
            HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = new_timeout

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()

# ---------------- SERVER MANAGER ----------------
class ThreadingHTTPServer(ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address):
        if issubclass(sys.exc_info()[0], (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
            pass
        else:
            http.server.HTTPServer.handle_error(self, request, client_address)

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None
        self.running = threading.Event()

    def start(self):
        if self.running.is_set():
            return True 
            
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                
                self.thread = threading.Thread(target=self._serve_loop, daemon=True)
                self.thread.start()
                self.active_port = port
                self.running.set()
                logging.info(f"Proxy iniciado com sucesso na porta {self.active_port}")
                return True
            except (OSError, socket.error) as e:
                if 'Address already in use' in str(e):
                    logging.warning(f"Porta {port} em uso, tentando próxima porta.")
                    continue
                else:
                    logging.error(f"Erro ao iniciar o servidor HTTP: {e}")
                    break
            except Exception as e:
                 logging.error(f"Erro inesperado ao iniciar o servidor HTTP: {e}")
                 break
                 
        logging.error("Não foi possível iniciar o proxy em nenhuma porta.")
        return False

    def _serve_loop(self):
        try:
            self.server.serve_forever()
        except Exception as e:
            logging.error(f"Loop do servidor encerrado com erro: {e}")

    def stop(self):
        if self.server:
            logging.info(f"Encerrando proxy na porta {self.active_port}")
            self.server.shutdown()
            self.server.server_close()
            self.thread.join(timeout=2.0)
            self.server = None
            self.thread = None
            self.active_port = None
            self.running.clear()

# ---------------- ADDON ----------------
class HLSAddon:
    """Interface mínima para o addon Kodi."""
    
    _manager = HLSProxyManager() 

    def __init__(self, handle):
        self.handle = handle

    def play_stream(self, url, stype, title=None):
        """
        Inicia proxy e retorna URL proxied para o player.
        Faz PRE-RESOLVE do manifesto para popular cache e obter BASE URL.
        """
        # 1. Inicia o proxy se não estiver rodando
        if not self._manager.start():
            if xbmcplugin:
                logging.error("Falha ao iniciar o proxy. Setando resolved URL para False.")
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        session_id = f"stream_{int(time.time())}_{random.randint(1000,9999)}"
        logging.info(f"Iniciando stream com session_id: {session_id} para URL: {url}")
        
        # 2. PRE-RESOLVE do manifesto
        temp_handler = HLSProxyRequestHandler
        try:
            resolved_url = temp_handler(None, None, None).resolve_and_cache(url, session_id, force_refresh=True)
            logging.info(f"Manifesto pré-resolvido: {url} -> {resolved_url}")
        except Exception as e:
            logging.error(f"Erro durante o PRE-RESOLVE do manifesto: {e}")
            resolved_url = url
            
        # 3. Constrói a URL proxied
        proxy_url = f"http://{PROXY_HOST}:{self._manager.active_port}/?url={urllib.parse.quote_plus(resolved_url)}&session_id={session_id}"
        
        if xbmcplugin:
            li = xbmcgui.ListItem(path=proxy_url)
            if title:
                li.setLabel(title) 
                
            li.setProperty('IsPlayable', 'true')
            
            # Preserva o título original do canal
            li.setInfo('video', {'Title': title, 'mediatype': stype or 'video'})
            
            xbmcplugin.setResolvedUrl(self.handle, True, li)
        else:
            print(f"URL Proxied: {proxy_url}") 

    def stop(self):
        """Método de parada opcional."""
        pass 
        
    def __del__(self):
        pass

# ---------------- Inicialização (Se for executado diretamente) ----------------
if __name__ == '__main__':
    logging.info("Iniciando hlsproxy.py em modo standalone de teste.")
    proxy_manager = HLSProxyManager()
    if proxy_manager.start():
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Proxy encerrado manualmente.")
        finally:
            proxy_manager.stop()
    else:
        print("Falha ao iniciar o Proxy HLS.")