# -*- coding: utf-8 -*-
# NEXUS X-CODES HYBRID V20.90 (CPU-OPT: sutura de baixo consumo)
#
# HERANÇA PRESERVADA INTEGRALMENTE:
#   - V20.67: sutura perfeita _find_match (primary/secondary).
#   - V20.77: _real_bytes_sent durante sutura, guard _bytes_streamed.
#   - V20.78: janela deslizante dinâmica (_suture_win_pos).
#   - V20.79: generator anti-EOF, keepalive turbo, watchdog agressivo, keep_prebuf.
#   - V20.80: _suture_timeout_streak, clear_all() no timeout.
#   - V20.81: _find_sync_offset com dupla/tripla confirmação anti-Grinch.
#   - V20.82: SUTURE_MAX_TIME aumentado + first-match (find) para zero repetição.
#   - V20.83: SLIDING_WINDOW_SIZE e SUTURE_MAX_TIME dinâmicos por Content-Length.
#   - V20.85: Timeouts reduzidos, prebuffer menor, watchdog mais agressivo.
#   - V20.86: headers IPTV-safe (sem Sec-*, TE, Origin, Via, etc.).
#   - V20.87: Suture Hard Reset — reinicia sessão se sutura não casa em 10s.
#
# CORREÇÕES V20.88 — NEVER-ERROR PLAYER (diagnóstico logs 406 em loop — preservado).
# CORREÇÕES V20.89 — ANTI-EOF + ANTI-AUDIOSYNC + RECONEXÃO BLINDADA:
#
#   [1] AUDIO SYNC ERROR -89430s → NULL FLUSH APÓS SUTURA
#       Após sutura OK, antes de enviar remainder ao player:
#       injeta NULL_FLUSH_BLOCKS (40) de null packets para resetar
#       o clock do decoder. Evita "large audio sync error" de 89000ms.
#
#   [2] EOF "eof reading from demuxer" → GENERATOR NUNCA TERMINA
#       generator() reescrito: loop infinito protegido, só sai em
#       GeneratorExit. _stop_event não causa mais EOF — o generator
#       continua emitindo null packets enquanto o producer reconecta.
#
#   [3] KEEPALIVE CONTÍNUO DURANTE RECONEXÃO LONGA (ConnectionError ~8s)
#       _KeepaliveThread injeta NULL_BLOCK na data_queue a cada
#       KEEPALIVE_INTERVAL enquanto o producer estiver em estado de
#       reconexão (_reconnecting flag). Elimina starvation de 8s+.

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, parse_qs
from requests.adapters import HTTPAdapter
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

import xbmc
import xbmcgui
import xbmcplugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS   = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

VERSION = 'V20.90-CPU-OPT'

TS_PACKET_SIZE = 188
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
NULL_BLOCK     = TS_NULL_PACKET * 7

CHUNK_SIZE_MIN  = 32  * 1024
CHUNK_SIZE_MAX  = 512 * 1024
CHUNK_SIZE_DEF  = 128 * 1024
TS_CHUNK_SIZE   = 8   * 1024

# V20.86: CONNECT_TIMEOUT restaurado para 3s (2s era muito agressivo)
FETCH_TIMEOUT   = 6
CONNECT_TIMEOUT = 3
QUEUE_SIZE      = 512

# V20.85: Prebuffer reduzido para retomada rápida
PREBUFFER_BYTES   = 94 * 188   # ~17.6KB
PREBUFFER_TIMEOUT = 3.0

KEEPALIVE_INTERVAL  = 0.025
WATCHDOG_INTERVAL   = 0.8
STARVATION_TIMEOUT  = 1.5

STALL_INJECT_INTERVAL = 0.04

# V20.88: todos os erros HTTP tratados igual — reset silencioso + null injection
# TOKEN_EXPIRED_CODES mantido apenas para log diferenciado, sem lógica especial
TOKEN_EXPIRED_CODES   = {401, 403, 404, 406, 410}
MANIFEST_FAIL_TIMEOUT = 8
BACKOFF_SEQUENCE = [0.0, 0.0, 0.3, 0.6, 1.0, 2.0]

SESSION_RESET_FAIL_LIMIT = 2
SESSION_RESET_BACKOFF    = 0.0

# ---- Sutura - MATEMÁTICA EXATA (MÚLTIPLOS DE 188) --------------------------
TAIL_SIZE      = 174 * 188   # 32712 bytes
TAIL_SECONDARY = 43  * 188   # 8084 bytes

SLIDING_WINDOW_SIZE_DEFAULT = 11 * 1024 * 1024
SUTURE_MAX_TIME_DEFAULT     = 12

SUTURE_SKIP_THRESHOLD = 2

# V20.87: Hard reset da sessão HTTP se sutura não casa em 10s
# (independente de suture_max_time dinâmico — o hard reset é sempre 10s)
SUTURE_HARD_RESET_TIMEOUT = 10.0

# ---- Janela Deslizante Dinâmica --------------------------------------------
SUTURE_WINDOW_STEP  = (188 * 200)
SUTURE_WINDOW_FLUSH = (188 * 1200)
SUTURE_WINDOW_KEEP  = TAIL_SIZE + TAIL_SECONDARY

# V20.90: Throttle de invocação do _try_suture — só chama a cada N bytes novos
# Reduz chamadas de ~1/chunk (~8KB) para ~1/64KB → ~8x menos varreduras por segundo
SUTURE_CALL_EVERY = 64 * 1024   # bytes novos acumulados antes de tentar sutura

TAIL_SAVE_INTERVAL  = 0.25
TAIL_SAVE_MIN_BYTES = TS_PACKET_SIZE * 8

# V20.89: null packets injetados após sutura para resetar clock do decoder
NULL_FLUSH_BLOCKS = 40

_ALL_UA = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 7.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.0 Chrome/122.0.0.0 TV Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20',
    'Lavf/60.3.100',
    'Kodi/20.5 (Windows NT 10.0; Win64; x64) App_Bitness/64 Version/20.5',
]

_ALL_REFERER = [
    'https://www.google.com/',
    'https://www.bing.com/',
    'https://www.duckduckgo.com/',
    'https://www.yandex.com/',
    'https://www.youtube.com/',
    'https://www.twitch.tv/',
    'https://www.facebook.com/',
    'https://www.reddit.com/',
]

_ACCEPT_LANG = [
    'en-US,en;q=0.9',
    'pt-BR,pt;q=0.9,en;q=0.8',
    'es-ES,es;q=0.9,en;q=0.8',
    'fr-FR,fr;q=0.9,en;q=0.8',
    'de-DE,de;q=0.9,en;q=0.8',
]

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in (10, 127, 169, 172, 192, 198, 203, 224): continue
        o2, o3 = random.randint(0, 255), random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31: continue
        if o1 == 192 and o2 == 168: continue
        return '%d.%d.%d.%d' % (o1, o2, o3, o4)


# ---------------------------------------------------------------------------
# V20.86: get_stream_headers() — headers MÍNIMOS e IPTV-safe
# Remove todos os headers que causam 406 em servidores Xtream Codes / IPTV baratos:
# Sec-CH-UA, Sec-Fetch-*, TE, Upgrade-Insecure-Requests, Via, Forwarded,
# Origin, X-Originating-IP, X-Client-IP, X-Forwarded-Host, X-Forwarded-Proto
# ---------------------------------------------------------------------------
def get_stream_headers(target_url, ua=None, fake_ip=None):
    if ua is None:      ua = random.choice(_ALL_UA)
    if fake_ip is None: fake_ip = random_ip()
    return {
        'User-Agent':      ua,
        'Accept':          '*/*',
        'Accept-Language': random.choice(_ACCEPT_LANG),
        'Accept-Encoding': 'identity',
        'Connection':      'keep-alive',
        'Cache-Control':   'no-cache',
        'Pragma':          'no-cache',
        'X-Forwarded-For': fake_ip,
        'X-Real-IP':       fake_ip,
        'Client-IP':       fake_ip,
        'Referer':         random.choice(_ALL_REFERER),
        'DNT':             str(random.randint(0, 1)),
    }


# V20.86: get_stealth_headers() mantida MAS sem Sec-* e sem Origin
# (usada apenas para reconexão via base_url — mais permissiva)
def get_stealth_headers(target_url, ua=None, fake_ip=None):
    if fake_ip is None: fake_ip = random_ip()
    parsed = urlparse(target_url)
    if ua is None: ua = random.choice(_ALL_UA)
    return {
        'User-Agent':      ua,
        'Accept':          '*/*',
        'Accept-Language': random.choice(_ACCEPT_LANG),
        'Accept-Encoding': 'identity',
        'Connection':      'keep-alive',
        'Cache-Control':   'no-cache',
        'Pragma':          'no-cache',
        'Referer':         random.choice(_ALL_REFERER),
        'DNT':             str(random.randint(0, 1)),
        'X-Forwarded-For': fake_ip,
        'X-Real-IP':       fake_ip,
        'Client-IP':       fake_ip,
    }


def get_proxy_response_headers(target_url):
    fake_ip = random_ip()
    ua = random.choice(_ALL_UA)
    return {
        'User-Agent':               ua,
        'Accept':                   '*/*',
        'Accept-Language':          random.choice(_ACCEPT_LANG),
        'Accept-Encoding':          'identity',
        'Connection':               'keep-alive',
        'Cache-Control':            'no-cache, no-store, must-revalidate, max-age=0',
        'Pragma':                   'no-cache',
        'Expires':                  '0',
        'X-Forwarded-For':          fake_ip,
        'X-Real-IP':                fake_ip,
        'Client-IP':                fake_ip,
        'X-Originating-IP':         '[%s]' % fake_ip,
        'X-Client-IP':              fake_ip,
        'X-Forwarded-Host':         urlparse(target_url).netloc,
        'X-Forwarded-Proto':        urlparse(target_url).scheme,
        'Referer':                  random.choice(_ALL_REFERER),
        'Origin':                   '%s://%s' % (urlparse(target_url).scheme, urlparse(target_url).netloc),
        'DNT':                      str(random.randint(0, 1)),
        'Sec-Fetch-Site':           'cross-site',
        'Sec-Fetch-Mode':           'cors',
        'Sec-Fetch-Dest':           'empty',
        'Sec-Fetch-User':           '?1',
        'Upgrade-Insecure-Requests':'1',
        'TE':                       'trailers',
        'Via':                      '1.1 %s' % fake_ip,
        'Forwarded':                'for=%s;proto=%s' % (fake_ip, urlparse(target_url).scheme),
    }


# ---------------------------------------------------------------------------
# Sistema de reconexão com 6 estratégias
# ---------------------------------------------------------------------------
class ReconnectionSystem(object):
    def __init__(self):
        self.history = []
        self.last_success_idx = None

    @staticmethod
    def _make_session():
        s = requests.Session()
        a = HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0)
        s.mount('http://', a); s.mount('https://', a)
        return s

    @staticmethod
    def _do_get(session, url, ua=None, fake_ip=None, extra=None, t_add=(0, 0)):
        h = get_stream_headers(url, ua=ua, fake_ip=fake_ip)
        if extra: h.update(extra)
        return session.get(
            url, headers=h, stream=True,
            timeout=(CONNECT_TIMEOUT + t_add[0], FETCH_TIMEOUT + t_add[1]),
            verify=False, allow_redirects=True)

    def _s0_fast(self, s, url, ua=None, ip=None):
        return self._do_get(s, url, ua=ua, fake_ip=ip,
                            extra={'X-Request-Id': str(uuid.uuid4())})

    def _s1_backoff(self, s, url, ua=None, ip=None):
        time.sleep(random.uniform(0.3, 0.8))
        return self._do_get(s, url, ua=ua, fake_ip=ip, t_add=(2, 4))

    def _s2_new_session(self, s, url, ua=None, ip=None):
        return self._do_get(self._make_session(), url, ua=ua, fake_ip=ip)

    def _s3_alt_proto(self, s, url, ua=None, ip=None):
        alt = url.replace('https://', 'http://', 1) if url.startswith('https://') \
              else url.replace('http://', 'https://', 1)
        return self._do_get(s, alt, ua=ua, fake_ip=ip)

    def _s4_new_ip(self, s, url, ua=None, ip=None):
        time.sleep(random.uniform(0.3, 1.0))
        new_ip = random_ip()
        return self._do_get(s, url, ua=ua, fake_ip=new_ip,
                            extra={'X-Device-ID': str(uuid.uuid4())})

    def _s5_cache_bust(self, s, url, ua=None, ip=None):
        sep = '&' if '?' in url else '?'
        busted = '%s%s_t=%d' % (url, sep, int(time.time()))
        return self._do_get(s, busted, ua=ua, fake_ip=ip,
                            extra={'Cache-Control': 'no-cache, no-store', 'Pragma': 'no-cache'})

    _STRATEGIES = [_s0_fast, _s1_backoff, _s2_new_session,
                   _s3_alt_proto, _s4_new_ip, _s5_cache_bust]

    def next_idx(self):
        if self.last_success_idx is not None: return self.last_success_idx
        if not self.history: return 0
        used = set(self.history[-3:])
        avail = [i for i in range(len(self._STRATEGIES)) if i not in used]
        if avail: return random.choice(avail)
        counts = {x: self.history.count(x) for x in set(self.history)}
        return min(counts, key=counts.get)

    def execute(self, idx, session, url, ua=None, ip=None):
        return self._STRATEGIES[idx % len(self._STRATEGIES)](self, session, url, ua=ua, ip=ip)


# ---------------------------------------------------------------------------
# Chunk sizer adaptativo
# ---------------------------------------------------------------------------
class AdaptiveChunkSizer(object):
    def __init__(self):
        self._size = CHUNK_SIZE_DEF; self._bytes = 0
        self._t_last = time.time(); self._lock = threading.Lock()

    def update(self, n):
        with self._lock:
            self._bytes += n; now = time.time(); dt = now - self._t_last
            if dt >= 2.0:
                rate = self._bytes / dt
                if   rate > 4*1024*1024: self._size = CHUNK_SIZE_MAX
                elif rate > 1*1024*1024: self._size = 256*1024
                elif rate > 256*1024:    self._size = 128*1024
                else:                    self._size = CHUNK_SIZE_MIN
                self._bytes = 0; self._t_last = now

    @property
    def size(self):
        with self._lock: return self._size


# ---------------------------------------------------------------------------
# Cache de tail
# ---------------------------------------------------------------------------
class SingleTailCache(object):
    def __init__(self):
        self._live = b''; self._backup = b''; self._lock = threading.Lock()

    def update_live(self, tail):
        if not tail or len(tail) < TAIL_SAVE_MIN_BYTES: return False
        remainder_bytes = len(tail) % TS_PACKET_SIZE
        if remainder_bytes:
            tail = tail[remainder_bytes:]
        if not tail or len(tail) < TAIL_SAVE_MIN_BYTES: return False
        with self._lock:
            self._live = tail[-TAIL_SIZE:] if len(tail) > TAIL_SIZE else tail
            return True

    def promote_to_backup(self):
        with self._lock:
            if self._live and len(self._live) >= TAIL_SAVE_MIN_BYTES:
                self._backup = self._live; self._live = b''; return True
        return False

    def get_for_suture(self):
        with self._lock: return self._live

    def get_for_recovery(self):
        with self._lock:
            if not self._live and self._backup: return self._backup
            return b''

    def suture_done(self):
        with self._lock: self._live = b''; self._backup = b''

    def clear_live(self):
        with self._lock: self._live = b''

    def clear_all(self):
        with self._lock: self._live = b''; self._backup = b''

    @property
    def has_live(self):
        with self._lock: return bool(self._live and len(self._live) >= TAIL_SAVE_MIN_BYTES)

    @property
    def has_backup(self):
        with self._lock: return bool(self._backup and len(self._backup) >= TAIL_SAVE_MIN_BYTES)

    @property
    def has_any(self):
        with self._lock:
            return bool(
                (self._live   and len(self._live)   >= TAIL_SAVE_MIN_BYTES) or
                (self._backup and len(self._backup) >= TAIL_SAVE_MIN_BYTES)
            )


# ---------------------------------------------------------------------------
# Dynamic Tail Saver
# ---------------------------------------------------------------------------
class DynamicTailSaver(threading.Thread):
    def __init__(self, engine):
        super(DynamicTailSaver, self).__init__(daemon=True, name='TailSaver')
        self.engine = engine; self._stop = threading.Event(); self._last_hash = None

    def run(self):
        while not self._stop.wait(timeout=TAIL_SAVE_INTERVAL):
            tail = self.engine.stream_tail
            if not tail or len(tail) < TAIL_SAVE_MIN_BYTES: continue
            if self.engine._bytes_streamed == 0: continue
            # V20.90: tail é bytearray — hash() e slicing funcionam diretamente
            h = hash(bytes(tail[-512:])) if len(tail) >= 512 else hash(bytes(tail))
            if h != self._last_hash:
                if self.engine.tail_cache.update_live(bytes(tail)): self._last_hash = h

    def force_save(self):
        tail = self.engine.stream_tail
        if tail and len(tail) >= TAIL_SAVE_MIN_BYTES:
            self.engine.tail_cache.update_live(bytes(tail))
            self._last_hash = hash(bytes(tail[-512:])) if len(tail) >= 512 else hash(bytes(tail))

    def mark_synced(self):
        tail = self.engine.stream_tail
        if tail: self._last_hash = hash(bytes(tail[-512:])) if len(tail) >= 512 else hash(bytes(tail))

    def reset(self): self._last_hash = None
    def stop(self): self._stop.set()


# ---------------------------------------------------------------------------
# V20.89: KeepaliveThread — injeta null packets enquanto producer reconecta
# Elimina starvation durante ConnectionError longa (ex: 8s sem dados)
# ---------------------------------------------------------------------------
class _KeepaliveThread(threading.Thread):
    def __init__(self, engine):
        super(_KeepaliveThread, self).__init__(daemon=True, name='Keepalive')
        self.engine = engine
        self._stop = threading.Event()

    def run(self):
        while not self._stop.wait(timeout=KEEPALIVE_INTERVAL):
            if self.engine._reconnecting:
                try: self.engine.data_queue.put_nowait(NULL_BLOCK)
                except queue.Full: pass

    def stop(self): self._stop.set()


# ---------------------------------------------------------------------------
# Engine Principal
# ---------------------------------------------------------------------------
class XCodesEngine(object):
    def __init__(self):
        self.entry_url = None; self.current_url = None
        self.base_url = None; self.active_param = None
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self._stop_event = threading.Event()
        self.prebuf_ready = threading.Event()
        self._engine_lock = threading.Lock()
        self._gen = 0; self._gen_lock = threading.Lock()
        self.session = None
        self._active_response = None
        self._active_response_lock = threading.Lock()
        self.reconn = ReconnectionSystem()
        self.chunk_sizer = AdaptiveChunkSizer()
        self.stream_tail = bytearray()
        self.residual_buffer = bytearray()
        self.has_initial_lock = False
        self.tail_cache = SingleTailCache()
        self.tail_saver = DynamicTailSaver(self)
        self.emergency = queue.Queue(maxsize=200); self._refill_emergency()
        self._producer_thread = None
        self._watchdog_thread = None
        self._keepalive_thread = None          # V20.89
        self._reconnecting = False             # V20.89: True durante reconexão
        self._prebuf_bytes = 0
        self.last_data_time = 0.0
        self.starvation_counter = 0
        self.consecutive_failures = 0
        self.reconnection_count = 0
        self._real_bytes_sent = 0
        self._bytes_streamed = 0
        self._watchdog_restart_flag = threading.Event()
        self._next_fake_ip = random_ip()
        self._next_ua = random.choice(_ALL_UA)
        self._suture_win_pos = 0
        self._suture_win_checked = 0
        self._suture_timeout_streak = 0
        self._suture_skip = False

        self.sliding_window_size = SLIDING_WINDOW_SIZE_DEFAULT
        self.suture_max_time = SUTURE_MAX_TIME_DEFAULT

    def _refill_emergency(self):
        for _ in range(200):
            try: self.emergency.put_nowait(NULL_BLOCK)
            except queue.Full: break

    def _push_keepalive(self, n=8):
        for _ in range(n):
            try: self.data_queue.put_nowait(NULL_BLOCK)
            except queue.Full: pass

    def _next_gen(self):
        with self._gen_lock: self._gen += 1; return self._gen

    def _get_gen(self):
        with self._gen_lock: return self._gen

    def _set_active_response(self, r):
        with self._active_response_lock: self._active_response = r

    def _clear_queue(self):
        while True:
            try: self.data_queue.get_nowait()
            except queue.Empty: break

    def _new_session_with_rotation(self):
        if self.session:
            try: self.session.close()
            except Exception: pass
        self.session = requests.Session()
        a = HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0)
        self.session.mount('http://', a); self.session.mount('https://', a)
        self.reconnection_count += 1
        self._next_fake_ip = random_ip()
        self._next_ua = random.choice(_ALL_UA)
        if self.reconnection_count % 5 == 0: gc.collect()

    def _quick_rotate(self):
        # Rotação rápida SEM fechar sessão TCP — para S0/S1/S4/S5
        self.reconnection_count += 1
        self._next_fake_ip = random_ip()
        self._next_ua = random.choice(_ALL_UA)

    def _prepare_for_reset(self, reason=''):
        tail = self.stream_tail
        if tail and len(tail) >= TAIL_SAVE_MIN_BYTES and self._bytes_streamed > 0:
            self.tail_cache.update_live(bytes(tail))
            self.tail_cache.promote_to_backup()
            self.tail_saver.mark_synced()
            xbmc.log('[TAIL] Snapshot salvo antes de reset (%s) %dKB'
                     % (reason, len(tail) // 1024), xbmc.LOGDEBUG)

    def _session_reset(self, reason='', keep_prebuf=False):
        xbmc.log('[RESET] %s' % reason, xbmc.LOGWARNING)
        with self._active_response_lock:
            if self._active_response:
                try: self._active_response.close()
                except Exception: pass
                self._active_response = None
        self._clear_queue(); self._push_keepalive(16)
        self._prepare_for_reset(reason)
        self.consecutive_failures = 0
        self.starvation_counter = 0
        self._real_bytes_sent = 0
        if not keep_prebuf:
            self._prebuf_bytes = 0; self.prebuf_ready.clear()
        self.last_data_time = time.time()
        self.stream_tail = bytearray(); self.residual_buffer = bytearray()
        self.has_initial_lock = False
        self._new_session_with_rotation(); self.tail_saver.reset()
        self._reset_suture_window()
        self.sliding_window_size = SLIDING_WINDOW_SIZE_DEFAULT
        self.suture_max_time = SUTURE_MAX_TIME_DEFAULT
        self._reconnecting = True   # V20.89: session reset implica que vai reconectar

    def _suture_hard_reset(self, r):
        """V20.87: Fecha conexão HTTP e reinicia sessão SEM tocar tail_cache.
        Chamado quando sutura não encontra match em SUTURE_HARD_RESET_TIMEOUT segundos.
        tail_cache.live e tail_cache.backup são PRESERVADOS para nova tentativa."""
        xbmc.log('[SUTURA] Hard Reset — sem match em %.0fs — reconectando (tail preservado)'
                 % SUTURE_HARD_RESET_TIMEOUT, xbmc.LOGWARNING)
        self._set_active_response(None)
        try:
            r.close()
        except Exception:
            pass
        # _session_reset fecha sessão HTTP, cria nova, rotaciona IP/UA
        # NÃO chama tail_cache.clear_all() — live + backup ficam intactos
        self._session_reset('sutura_hard_reset', keep_prebuf=True)
        # Força needs_reconn=True no próximo ciclo → reconecta via base_url com nova estratégia
        self.consecutive_failures = 1

    def _start_producer(self):
        self._stop_event.clear(); self._watchdog_restart_flag.clear()
        t = threading.Thread(target=self._producer_loop,
                             name='XCodes-Producer', daemon=True)
        self._producer_thread = t; t.start()

    def _start_watchdog(self):
        t = threading.Thread(target=self._watchdog_loop,
                             name='XCodes-Watchdog', daemon=True)
        self._watchdog_thread = t; t.start()

    def _start_keepalive(self):
        if self._keepalive_thread and self._keepalive_thread.is_alive():
            self._keepalive_thread.stop()
        self._keepalive_thread = _KeepaliveThread(self)
        self._keepalive_thread.start()

    def _stop_keepalive(self):
        if self._keepalive_thread and self._keepalive_thread.is_alive():
            self._keepalive_thread.stop()

    def _start_tail_saver(self):
        if not self.tail_saver.is_alive():
            self.tail_saver = DynamicTailSaver(self); self.tail_saver.start()

    def _stop_tail_saver(self):
        if self.tail_saver.is_alive(): self.tail_saver.stop()

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls: raise ValueError('URL vazia')
        entry = urls[0]
        with self._engine_lock:
            same = (self.active_param == url_param)
            if same and self._producer_thread and self._producer_thread.is_alive():
                return

            self._stop_event.set(); self._stop_tail_saver(); time.sleep(0.05)
            self._clear_queue()
            if same and self._bytes_streamed > 0 and self.stream_tail:
                self._prepare_for_reset('reinicio_same')
            self.tail_cache.clear_all()
            self.stream_tail = bytearray(); self.residual_buffer = bytearray()
            self.has_initial_lock = False
            self._new_session_with_rotation(); self._next_gen()
            self._prebuf_bytes = 0; self.prebuf_ready.clear()
            self.last_data_time = time.time()
            self.starvation_counter = 0
            self.consecutive_failures = 0
            self._real_bytes_sent = 0; self._bytes_streamed = 0
            self._suture_timeout_streak = 0; self._suture_skip = False
            self._reconnecting = False   # V20.89: stream novo, ainda não reconectando

            if not same:
                self.active_param = url_param
                self.reconn.history = []; self.reconn.last_success_idx = None
            self.entry_url = entry; self.current_url = entry
            self.base_url = entry.split('?')[0]
            self._refill_emergency()
            self._start_tail_saver(); self._start_producer()
            self._start_watchdog(); self._start_keepalive()

    def _watchdog_loop(self):
        while not self._stop_event.wait(timeout=WATCHDOG_INTERVAL):
            if self.last_data_time == 0.0: continue
            if time.time() - self.last_data_time >= STARVATION_TIMEOUT:
                self.starvation_counter += 1
                self._watchdog_restart_flag.set()
                self._push_keepalive(8)
                self.last_data_time = time.time()

    # ---- SUTURA ----------------------------------------------------------------
    def _reset_suture_window(self):
        self._suture_win_pos     = 0
        self._suture_win_checked = 0

    def _try_suture(self, buf):
        # buf é bytearray — .find(bytes) funciona nativamente
        buf_len = len(buf)

        # Ajusta win_pos se buf cresceu além da janela máxima
        if buf_len > self.sliding_window_size:
            excess = buf_len - self.sliding_window_size
            self._suture_win_pos = max(0, self._suture_win_pos - excess)
            # Truncamento in-place no loop externo (resync_buf); aqui só ajustamos a referência
            effective_start = excess
        else:
            effective_start = 0

        win_start = effective_start + self._suture_win_pos
        min_needed = TAIL_SIZE + TAIL_SECONDARY + TS_PACKET_SIZE * 4
        available = buf_len - win_start
        if available < min_needed:
            return False, b''

        # Fatia do bytearray — bytearray.find(bytes) funciona; cria cópia só da janela
        window = buf[win_start:]

        tail = self.tail_cache.get_for_suture()
        if tail:
            ok, remainder = self._find_match(window, tail, 'LIVE')
            if ok:
                self._reset_suture_window()
                return ok, remainder

        tail = self.tail_cache.get_for_recovery()
        if tail:
            ok, remainder = self._find_match(window, tail, 'BACKUP')
            if ok:
                self._reset_suture_window()
                return ok, remainder

        effective_buf_len = buf_len - effective_start
        new_data = effective_buf_len - self._suture_win_pos
        self._suture_win_checked += new_data

        if self._suture_win_checked >= SUTURE_WINDOW_FLUSH:
            keep_start = max(0, effective_buf_len - SUTURE_WINDOW_KEEP)
            keep_start = keep_start - (keep_start % TS_PACKET_SIZE) if keep_start >= TS_PACKET_SIZE else 0
            self._suture_win_pos     = keep_start
            self._suture_win_checked = 0
            xbmc.log('[SUTURA] Janela deslizou → pos=%dKB restam=%dKB'
                     % (keep_start // 1024, (effective_buf_len - keep_start) // 1024), xbmc.LOGDEBUG)
        else:
            step = SUTURE_WINDOW_STEP - (SUTURE_WINDOW_STEP % TS_PACKET_SIZE)
            self._suture_win_pos = min(
                self._suture_win_pos + step,
                max(0, effective_buf_len - SUTURE_WINDOW_KEEP)
            )

        return False, b''

    def _find_match(self, buf, tail, label):
        # buf é bytes ou bytearray — ambos suportam .find(bytes) nativamente
        # V20.90: find() único em vez de "in" + find() — elimina varredura dupla
        if not tail: return False, b''

        primary = tail[-TAIL_SIZE:] if len(tail) >= TAIL_SIZE else tail
        if primary:
            idx = buf.find(primary)
            if idx != -1:
                skip = idx + len(primary)
                remainder = bytes(buf[skip:])
                align = self._find_sync_offset(remainder)
                if align == -1:
                    pass
                elif align > 0:
                    remainder = remainder[align:]
                    skip += align
                xbmc.log('[SUTURA] Perfeita [%s] pulou %dKB align=%d'
                         % (label, skip // 1024, align if align != -1 else -1), xbmc.LOGINFO)
                return True, remainder

        secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
        if secondary and len(buf) > TAIL_SECONDARY + 188 * 50:
            idx = buf.find(secondary)
            if idx != -1:
                skip = idx + len(secondary)
                remainder = bytes(buf[skip:])
                align = self._find_sync_offset(remainder)
                if align > 0:
                    remainder = remainder[align:]
                    skip += align
                xbmc.log('[SUTURA] Rapida [%s] pulou %dKB' % (label, skip // 1024), xbmc.LOGINFO)
                return True, remainder

        return False, b''

    @staticmethod
    def _find_sync_offset(data):
        i = 0
        length = len(data)
        while i < length:
            if data[i] == 0x47:
                next1 = i + TS_PACKET_SIZE
                next2 = i + 2 * TS_PACKET_SIZE
                if next1 < length:
                    if data[next1] == 0x47:
                        if next2 < length:
                            if data[next2] == 0x47:
                                return i
                            i += 1
                            continue
                        return i
                    i += 1
                    continue
                else:
                    return -1
            i += 1
        return -1

    def _process(self, raw, my_gen):
        if my_gen != self._get_gen() or not raw: return
        # V20.90: residual_buffer é bytearray — extend é O(len(raw)), sem cópia do acumulado
        self.residual_buffer.extend(raw)
        batch = self.residual_buffer
        if not self.has_initial_lock:
            idx = self._find_sync_offset(batch)
            if idx == -1:
                max_residual = TS_PACKET_SIZE * 4
                if len(batch) > max_residual:
                    del batch[:len(batch) - max_residual]
                return
            del batch[:idx]; self.has_initial_lock = True
        n = len(batch) // TS_PACKET_SIZE
        if n == 0: return
        used = n * TS_PACKET_SIZE
        payload = bytes(batch[:used])
        # Descarta os bytes já consumidos in-place (sem criar novo bytearray)
        del batch[:used]
        # V20.90: stream_tail é bytearray — extend + del in-place, zero cópia extra
        self.stream_tail.extend(payload)
        tail_max = TAIL_SIZE + TAIL_SECONDARY
        if len(self.stream_tail) > tail_max:
            del self.stream_tail[:len(self.stream_tail) - TAIL_SIZE]
        self.last_data_time = time.time()
        self.starvation_counter = 0
        self.chunk_sizer.update(len(payload))
        if not self.prebuf_ready.is_set():
            self._prebuf_bytes += len(payload)
            if self._prebuf_bytes >= PREBUFFER_BYTES: self.prebuf_ready.set()
        try: self.data_queue.put_nowait(payload)
        except queue.Full:
            try: self.data_queue.get_nowait(); self.data_queue.put_nowait(payload)
            except Exception: pass

    def _producer_loop(self):
        my_gen = self._get_gen(); failure_count = 0; strategy_idx = 0

        while not self._stop_event.is_set():
            if self._watchdog_restart_flag.is_set():
                self._watchdog_restart_flag.clear()
                self.consecutive_failures += 1
                self.last_data_time = time.time()

            r = None
            try:
                needs_reconn = (self.consecutive_failures >= 1)

                if needs_reconn:
                    # V20.88: SEMPRE reconecta via base_url — sem Stealth Lock, sem current_url
                    self._reconnecting = True   # V20.89: keepalive thread injeta null durante reconexão
                    target_url = self.base_url
                    strategy_idx = self.reconn.next_idx()
                    xbmc.log('[PRODUCER] Reconexao S%d via base_url' % strategy_idx, xbmc.LOGINFO)
                    self.reconn.history.append(strategy_idx)
                    self._prepare_for_reset('reconexao')

                    if strategy_idx == 2:
                        self._new_session_with_rotation()
                    else:
                        self._quick_rotate()

                    self.stream_tail = bytearray(); self.residual_buffer = bytearray()
                    self.has_initial_lock = False
                    self._real_bytes_sent = 0; self.tail_saver.reset()
                    self._reset_suture_window()
                    self._push_keepalive(16)  # V20.88: null injection mais agressiva

                    reconnect_ip = self._next_fake_ip
                    reconnect_ua = self._next_ua
                    try:
                        r = self.reconn.execute(strategy_idx, self.session, target_url,
                                                ua=reconnect_ua, ip=reconnect_ip)
                    except Exception as e:
                        self._session_reset('Falha: %s' % type(e).__name__, keep_prebuf=True)
                        self.consecutive_failures = 1
                        failure_count += 1; continue

                else:
                    # Primeira conexão — usa base_url com UA/IP frescos
                    target_url = self.base_url
                    used_ip = self._next_fake_ip
                    used_ua = self._next_ua
                    h = get_stream_headers(target_url, ua=used_ua, fake_ip=used_ip)
                    try:
                        r = self.session.get(
                            target_url, headers=h, stream=True,
                            timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT),
                            verify=False, allow_redirects=True)
                    except Exception as e:
                        self._session_reset('Falha init: %s' % type(e).__name__, keep_prebuf=True)
                        self.consecutive_failures = 1
                        failure_count += 1; continue

                if r is None:
                    self.consecutive_failures += 1
                    self._push_keepalive(16); continue

                status = r.status_code

                # V20.88: QUALQUER erro HTTP = reset silencioso + null injection
                # Sem backoff, sem lógica diferenciada, sem token_expired_count
                # O player nunca vê interrupção — recebe null packets durante reconexão
                if status not in (200, 206):
                    r.close()
                    label = ('TOKEN_%d' % status) if status in TOKEN_EXPIRED_CODES else ('HTTP_%d' % status)
                    xbmc.log('[PRODUCER] %s → reset silencioso' % label, xbmc.LOGWARNING)
                    self._push_keepalive(16)
                    failure_count += 1
                    self.consecutive_failures += 1
                    if failure_count >= SESSION_RESET_FAIL_LIMIT:
                        self._session_reset('%s x%d' % (label, failure_count), keep_prebuf=True)
                        self.consecutive_failures = 1
                        failure_count = 0
                    continue

                # === V20.83: DETECÇÃO DINÂMICA DO TAMANHO DO ARQUIVO TS ===
                self.sliding_window_size = SLIDING_WINDOW_SIZE_DEFAULT
                self.suture_max_time = SUTURE_MAX_TIME_DEFAULT
                content_length_str = r.headers.get('Content-Length', '')
                if content_length_str.isdigit():
                    cl = int(content_length_str)
                    if cl > TS_PACKET_SIZE * 100:
                        if cl < 1_048_576:
                            self.sliding_window_size = 2 * 1024 * 1024
                        elif cl < 5_242_880:
                            self.sliding_window_size = 6 * 1024 * 1024
                        elif cl < 20_971_520:
                            self.sliding_window_size = 12 * 1024 * 1024
                        else:
                            self.sliding_window_size = min(32 * 1024 * 1024, cl // 5)
                        mb_size = cl / (1024 * 1024.0)
                        self.suture_max_time = max(10.0, min(30.0, 10.0 + mb_size * 0.8))
                        xbmc.log('[DYNAMIC V20.83] TS %dKB → Win %dKB SutureTime %.1fs'
                                 % (cl//1024, self.sliding_window_size//1024, self.suture_max_time),
                                 xbmc.LOGINFO)

                self._watchdog_restart_flag.clear()
                self.last_data_time = time.time()
                self.consecutive_failures = 0
                failure_count = 0
                self._reconnecting = False   # V20.89: conectou — para o keepalive thread
                self.reconn.last_success_idx = strategy_idx
                self.current_url = r.url

                # Prepara próxima rotação (UA/IP frescos para próxima reconexão)
                self._next_fake_ip = random_ip()
                self._next_ua = random.choice(_ALL_UA)

                self._real_bytes_sent = 0
                self._set_active_response(r)

                is_ts = any(x in r.url.lower() for x in ('.ts', '/ts', '.m2ts', '/chunk', '/segment'))
                chunk_sz = TS_CHUNK_SIZE if is_ts else self.chunk_sizer.size
                real_bytes = 0; conn_start = time.time()
                # V20.90: bytearray — extend() O(chunk), truncamento in-place, zero cópia do acumulado
                resync_buf = bytearray()
                _suture_pending = 0   # V20.90: bytes acumulados desde última chamada _try_suture
                need_suture = self.tail_cache.has_any and not self._suture_skip
                if self._suture_skip:
                    xbmc.log('[SUTURA] Pulando sutura (streak=%d)'
                             % self._suture_timeout_streak, xbmc.LOGWARNING)
                suture_start = time.time()
                if need_suture:
                    self._reset_suture_window()

                _hard_reset_done = False
                try:
                    for chunk in r.iter_content(chunk_size=chunk_sz):
                        if self._stop_event.is_set(): break
                        if not chunk:
                            if real_bytes == 0 and time.time() - conn_start > MANIFEST_FAIL_TIMEOUT:
                                break
                            continue

                        real_bytes += len(chunk)
                        if not is_ts: chunk_sz = self.chunk_sizer.size

                        if need_suture:
                            resync_buf.extend(chunk)
                            _suture_pending += len(chunk)
                            self._bytes_streamed += len(chunk)
                            self.last_data_time = time.time()
                            # Truncamento in-place — sem criar novo bytearray
                            rb_len = len(resync_buf)
                            if rb_len > self.sliding_window_size:
                                del resync_buf[:rb_len - self.sliding_window_size]

                            # V20.90: throttle — só chama _try_suture a cada SUTURE_CALL_EVERY bytes
                            if _suture_pending < SUTURE_CALL_EVERY:
                                if self._watchdog_restart_flag.is_set(): break
                                continue
                            _suture_pending = 0

                            ok, remainder = self._try_suture(resync_buf)
                            time_spent = time.time() - suture_start

                            if ok:
                                self._real_bytes_sent += len(resync_buf)
                                resync_buf = bytearray(); need_suture = False
                                self._reset_suture_window()
                                self._suture_timeout_streak = 0
                                self._suture_skip = False
                                self.has_initial_lock = False
                                self.residual_buffer = bytearray()
                                self.tail_cache.suture_done(); self.tail_saver.reset()
                                # V20.89: flush null packets ANTES do remainder
                                # Reseta o clock do decoder — evita "large audio sync error"
                                for _ in range(NULL_FLUSH_BLOCKS):
                                    try: self.data_queue.put_nowait(NULL_BLOCK)
                                    except queue.Full: break
                                self._process(remainder, my_gen)
                                if not self.prebuf_ready.is_set():
                                    self.prebuf_ready.set()
                                    xbmc.log('[SUTURA] prebuf_ready forçado', xbmc.LOGDEBUG)
                                xbmc.log('[SUTURA] OK streak=0 null_flush=%d real_bytes=%d'
                                         % (NULL_FLUSH_BLOCKS, self._real_bytes_sent), xbmc.LOGDEBUG)

                            # V20.87: Hard reset de sessão HTTP aos 10s (antes do timeout final)
                            elif (time_spent > SUTURE_HARD_RESET_TIMEOUT
                                  and len(resync_buf) >= SUTURE_WINDOW_KEEP
                                  and time_spent <= self.suture_max_time):
                                # tail_cache NÃO é tocado — próxima conexão tenta sutura novamente
                                self._suture_hard_reset(r)
                                failure_count += 1
                                _hard_reset_done = True
                                break

                            elif time_spent > self.suture_max_time and len(resync_buf) >= SUTURE_WINDOW_KEEP:
                                self._suture_timeout_streak += 1
                                if self._suture_timeout_streak >= SUTURE_SKIP_THRESHOLD:
                                    self._suture_skip = True
                                xbmc.log('[SUTURA] Timeout %.1fs streak=%d skip=%s'
                                         % (time_spent, self._suture_timeout_streak, self._suture_skip),
                                         xbmc.LOGWARNING)
                                need_suture = False
                                self._reset_suture_window()
                                self.has_initial_lock = False
                                self.residual_buffer = bytearray()
                                self.tail_cache.clear_all(); self.tail_saver.reset()
                                resync_buf = bytearray()

                        else:
                            self._process(chunk, my_gen)
                            self._real_bytes_sent += len(chunk)
                            self._bytes_streamed  += len(chunk)

                        if self._watchdog_restart_flag.is_set(): break

                except Exception as e:
                    self._prepare_for_reset('falha_stream')
                    self._set_active_response(None)
                    try: r.close()
                    except Exception: pass
                    self._session_reset('Stream: %s' % type(e).__name__, keep_prebuf=True)
                    failure_count += 1; continue

                self._set_active_response(None)
                if not _hard_reset_done:
                    try: r.close()
                    except Exception: pass
                if _hard_reset_done:
                    continue
                if real_bytes == 0 and not self._stop_event.is_set():
                    self.consecutive_failures += 1; failure_count += 1
                    self._push_keepalive(16)
                    if failure_count >= SESSION_RESET_FAIL_LIMIT:
                        self._session_reset('Zero bytes x%d' % failure_count, keep_prebuf=True)
                        self.consecutive_failures = 1
                        failure_count = 0
                elif real_bytes > 0 and not need_suture and self._suture_skip:
                    self._suture_timeout_streak = 0
                    self._suture_skip = False
                    xbmc.log('[SUTURA] Reabilitada stream limpo %dKB' % (real_bytes // 1024), xbmc.LOGDEBUG)

            except Exception as exc:
                self._set_active_response(None)
                if r:
                    try: r.close()
                    except Exception: pass
                self._prepare_for_reset('excecao')
                if self._stop_event.is_set(): break
                xbmc.log('[PRODUCER] Excecao: %s' % exc, xbmc.LOGERROR)
                self.consecutive_failures += 1; failure_count += 1
                self._push_keepalive(16)
                if failure_count >= SESSION_RESET_FAIL_LIMIT:
                    self._session_reset('Exc x%d' % failure_count, keep_prebuf=True)
                    self.consecutive_failures = 1
                    failure_count = 0

        self._prepare_for_reset('fim')

    def generator(self):
        # V20.89: Null inicial para dar tempo ao producer conectar
        for _ in range(20):
            yield NULL_BLOCK
        if self.prebuf_ready.wait(timeout=PREBUFFER_TIMEOUT): pass
        else: xbmc.log('[PRE-BUFFER] Timeout', xbmc.LOGWARNING)
        next_kp = time.time() + STALL_INJECT_INTERVAL
        # V20.89: Loop INFINITO — só sai em GeneratorExit (Kodi fechou a conexão)
        # _stop_event NÃO causa EOF — producer pode resetar sem matar o generator
        try:
            while True:
                now = time.time()
                try:
                    chunk = self.data_queue.get(timeout=STALL_INJECT_INTERVAL)
                    yield chunk
                    next_kp = time.time() + STALL_INJECT_INTERVAL
                except queue.Empty:
                    if now >= next_kp:
                        try: yield self.emergency.get_nowait(); self._refill_emergency()
                        except queue.Empty: yield NULL_BLOCK
                        next_kp = time.time() + STALL_INJECT_INTERVAL
        except GeneratorExit:
            # Kodi fechou a conexão HTTP — encerra tudo limpo
            if not self._stop_event.is_set():
                self._stop_event.set()
        except Exception as e:
            xbmc.log('[ENGINE] Erro generator: %s' % e, xbmc.LOGERROR)
            if not self._stop_event.is_set():
                self._stop_event.set()


# ---------------------------------------------------------------------------
# Servidor HTTP local
# ---------------------------------------------------------------------------
engine = XCodesEngine()

class TSProxyHandler(BaseHTTPRequestHandler):
    def _apply_anti_blocking_headers(self):
        headers = get_proxy_response_headers(engine.base_url or 'http://localhost')
        for k in ('Cache-Control','Pragma','Expires','Connection',
                  'X-Forwarded-For','X-Real-IP','Client-IP','X-Originating-IP',
                  'X-Client-IP','X-Forwarded-Host','X-Forwarded-Proto',
                  'Forwarded','Via','Origin','Referer','User-Agent','Accept',
                  'Accept-Language','Accept-Encoding','DNT',
                  'Sec-Fetch-Site','Sec-Fetch-Mode','Sec-Fetch-Dest',
                  'Sec-Fetch-User','Upgrade-Insecure-Requests','TE'):
            if k in headers:
                self.send_header(k, headers[k])

    def do_GET(self):
        p = urlparse(self.path)
        if p.path != '/stream':
            self.send_response(404)
            self._apply_anti_blocking_headers()
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            return
        self.send_response(200)
        self._apply_anti_blocking_headers()
        self.send_header('Content-Type', 'video/mp2t')
        self.end_headers()
        url_param = parse_qs(p.query).get('url', [None])[0]
        if not url_param:
            self._keep_alive_dummy()
            return
        try:
            engine.start_stream(url_param)
            for chunk in engine.generator():
                self.wfile.write(chunk)
                self.wfile.flush()
        except (ConnectionResetError, BrokenPipeError):
            pass
        except Exception:
            self._keep_alive_dummy()

    def do_HEAD(self):
        p = urlparse(self.path)
        if p.path != '/stream':
            self.send_response(404)
            self._apply_anti_blocking_headers()
            self.end_headers()
            return
        self.send_response(200)
        self._apply_anti_blocking_headers()
        self.send_header('Content-Type', 'video/mp2t')
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self._apply_anti_blocking_headers()
        self.send_header('Allow', 'GET, HEAD, OPTIONS')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def _keep_alive_dummy(self):
        try:
            while True:
                self.wfile.write(NULL_BLOCK)
                self.wfile.flush()
                time.sleep(0.05)
        except Exception:
            pass

    def log_message(self, fmt, *args):
        pass


class SilentHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        exc_type = sys.exc_info()[0]
        if exc_type in (ConnectionResetError, BrokenPipeError,
                        ConnectionAbortedError, OSError):
            return
        return super(SilentHTTPServer, self).handle_error(request, client_address)


class TSProxyServer(threading.Thread):
    def __init__(self, port):
        super(TSProxyServer, self).__init__(daemon=True)
        self.port = port
        self.server = SilentHTTPServer(('127.0.0.1', port), TSProxyHandler)

    def run(self):
        try:
            self.server.serve_forever()
        except Exception:
            pass

    def stop(self):
        self.server.shutdown()
        self.server.server_close()


def get_free_port(start=50088):
    for port in range(start, start + 100):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            return port
        except OSError:
            pass
        finally:
            try: s.close()
            except Exception: pass
    return random.randint(50088, 50188)


proxy_server = None

def start_server():
    global proxy_server
    port = get_free_port()
    proxy_server = TSProxyServer(port)
    proxy_server.start()
    time.sleep(0.3)
    return port


SERVER_PORT = start_server()


# ---------------------------------------------------------------------------
# Entry point do addon
# ---------------------------------------------------------------------------
def run_addon():
    action = _ARGS.get('action')
    url = _ARGS.get('url')
    if action == 'play' and url:
        local = 'http://127.0.0.1:%d/stream?url=%s' % (SERVER_PORT, quote(url))
        li = xbmcgui.ListItem(path=local)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    else:
        li = xbmcgui.ListItem('[COLOR cyan]NEXUS X-CODES HYBRID %s[/COLOR]' % VERSION)
        li.setInfo('video', {'title': 'Nexus X-Codes Hybrid Proxy - Anti-Bloqueio'})
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(_HANDLE)


if __name__ == '__main__':
    run_addon()