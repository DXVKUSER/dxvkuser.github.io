import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import urllib3
import time
import random
import base64
from collections import OrderedDict
import logging
from logging.handlers import RotatingFileHandler
import os
import queue
import hashlib

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------
# LOGGING CONFIGURADO
# ---------------------------------------------------------------
def setup_proxy_logging():
    log_dir = os.path.join(
        os.path.expanduser("~"),
        ".kodi", "userdata", "addon_data", "plugin.video.hlsproxy"
    )
    try:
        os.makedirs(log_dir, exist_ok=True)
        log_file = os.path.join(log_dir, "proxy.log")
        logger = logging.getLogger('HLSProxy')
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=3)
            handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            ))
            logger.addHandler(handler)
        return logger
    except Exception:
        return logging.getLogger('HLSProxy')

logger = setup_proxy_logging()

# ---------------------------------------------------------------
# FAKE IP ROTATION (NOVO - IP aleatório em TODOS os cabeçalhos)
# ---------------------------------------------------------------
def get_random_fake_ip():
    """Gera IP fake realista e rotaciona em cada requisição."""
    return f"{random.randint(15, 220)}.{random.randint(10, 250)}.{random.randint(10, 250)}.{random.randint(1, 254)}"

# ---------------------------------------------------------------
# EXPONENTIAL BACKOFF & UTILS (OTIMIZADO)
# ---------------------------------------------------------------
class ExponentialBackoff:
    def __init__(self, base_delay=0.3, max_delay=8):
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.attempt = 0

    def wait(self):
        delay = min(self.base_delay * (2 ** self.attempt), self.max_delay)
        time.sleep(delay)
        self.attempt += 1
        return delay

    def reset(self):
        self.attempt = 0

def update_url_token(target_url, reference_url):
    if not reference_url or not target_url:
        return target_url
    ref_parsed = urllib.parse.urlparse(reference_url)
    tgt_parsed = urllib.parse.urlparse(target_url)
    if ref_parsed.query:
        return urllib.parse.urlunparse(tgt_parsed._replace(query=ref_parsed.query))
    return target_url

# ---------------------------------------------------------------
# RECONNECTION GUARD (OTIMIZADO)
# ---------------------------------------------------------------
class ReconnectionGuard:
    def __init__(self, max_attempts=8, window_seconds=45):
        self.max_attempts = max_attempts
        self.window = window_seconds
        self.attempts = []
        self._lock = threading.Lock()

    def can_reconnect(self):
        with self._lock:
            now = time.time()
            self.attempts = [t for t in self.attempts if now - t < self.window]
            return len(self.attempts) < self.max_attempts

    def record_attempt(self):
        with self._lock:
            self.attempts.append(time.time())

    def reset(self):
        with self._lock:
            self.attempts.clear()

# ---------------------------------------------------------------
# QUALITY MONITOR & ADAPTIVE BUFFER
# ---------------------------------------------------------------
class QualityMonitor:
    def __init__(self):
        self.segment_times = []
        self.error_count = 0
        self.consecutive_errors = 0
        self.last_segment_time = 0
        self._lock = threading.Lock()

    def record_segment_time(self, duration):
        with self._lock:
            self.segment_times.append(duration)
            if len(self.segment_times) > 20:
                self.segment_times.pop(0)
            self.consecutive_errors = 0
            self.last_segment_time = time.time()

    def record_error(self):
        with self._lock:
            self.error_count += 1
            self.consecutive_errors += 1
            return self.consecutive_errors >= 3

    def get_last_activity(self):
        with self._lock:
            return self.last_segment_time

    def is_stalled(self, timeout=15):
        with self._lock:
            if self.last_segment_time == 0:
                return False
            return (time.time() - self.last_segment_time) > timeout

class AdaptiveBuffer:
    def __init__(self):
        self.buffer_size = 5
        self.latency_history = []
        self._lock = threading.Lock()

    def update(self, fetch_time):
        with self._lock:
            self.latency_history.append(fetch_time)
            if len(self.latency_history) > 10:
                self.latency_history.pop(0)
            avg_latency = sum(self.latency_history) / len(self.latency_history)
            if avg_latency > 2.0:
                new_size = 8
            elif avg_latency < 0.5:
                new_size = 4
            else:
                new_size = 5
            if new_size != self.buffer_size:
                logger.info(f"Buffer ajustado: {self.buffer_size} -> {new_size} (latência: {avg_latency:.2f}s)")
                self.buffer_size = new_size
            return self.buffer_size

    def get_buffer_size(self):
        with self._lock:
            return self.buffer_size

# ---------------------------------------------------------------
# CACHE COM TTL
# ---------------------------------------------------------------
class CachedEntry:
    def __init__(self, content, ttl=30):
        self.content = content
        self.timestamp = time.time()
        self.ttl = ttl

    def is_valid(self):
        return time.time() - self.timestamp < self.ttl

class SmartLRUCache:
    def __init__(self, maxsize=200, default_ttl=30):
        self._data = OrderedDict()
        self._maxsize = maxsize
        self._default_ttl = default_ttl
        self._lock = threading.Lock()

    def get(self, key, default=None):
        with self._lock:
            if key not in self._data:
                return default
            entry = self._data[key]
            if entry.is_valid():
                self._data.move_to_end(key)
                return entry.content
            else:
                del self._data[key]
                return default

    def set(self, key, value, ttl=None):
        with self._lock:
            if key in self._data:
                self._data.move_to_end(key)
            self._data[key] = CachedEntry(value, ttl or self._default_ttl)
            if len(self._data) > self._maxsize:
                self._data.popitem(last=False)

    def delete(self, key):
        with self._lock:
            self._data.pop(key, None)

    def clear(self):
        with self._lock:
            self._data.clear()

    def __contains__(self, key):
        with self._lock:
            return key in self._data and self._data[key].is_valid()

# ---------------------------------------------------------------
# SEGMENT LRU BUFFER
# ---------------------------------------------------------------
SEGMENT_LRU_MAX_BYTES = 20 * 1024 * 1024
SEND_CHUNK_SIZE       = 4 * 1024
PREBUFFER_SEGMENTS    = 4
SEGMENT_LRU_TTL       = 90

class SegmentLRUEntry:
    __slots__ = ('data', 'size', 'ts')

    def __init__(self, data: bytes):
        self.data = data
        self.size = len(data)
        self.ts   = time.monotonic()

    def is_valid(self) -> bool:
        return (time.monotonic() - self.ts) < SEGMENT_LRU_TTL

class SegmentLRUBuffer:
    def __init__(self, max_bytes: int = SEGMENT_LRU_MAX_BYTES):
        self._data:          OrderedDict = OrderedDict()
        self._max_bytes:     int = max_bytes
        self._current_bytes: int = 0
        self._lock           = threading.Lock()
        self._hits           = 0
        self._misses         = 0

    def get(self, url: str):
        with self._lock:
            entry = self._data.get(url)
            if entry is None:
                self._misses += 1
                return None
            if not entry.is_valid():
                self._current_bytes -= entry.size
                del self._data[url]
                self._misses += 1
                return None
            self._data.move_to_end(url)
            self._hits += 1
            return entry.data

    def put(self, url: str, data: bytes):
        if not data or data[0] != 0x47:
            return
        size = len(data)
        if size > self._max_bytes:
            return
        with self._lock:
            if url in self._data:
                self._current_bytes -= self._data[url].size
                del self._data[url]
            while self._current_bytes + size > self._max_bytes and self._data:
                _, evicted = self._data.popitem(last=False)
                self._current_bytes -= evicted.size
            self._data[url] = SegmentLRUEntry(data)
            self._current_bytes += size

    def contains(self, url: str) -> bool:
        with self._lock:
            entry = self._data.get(url)
            return bool(entry and entry.is_valid())

    def remove(self, url: str):
        with self._lock:
            entry = self._data.pop(url, None)
            if entry:
                self._current_bytes -= entry.size

    def clear(self):
        with self._lock:
            self._data.clear()
            self._current_bytes = 0

    @property
    def stats(self) -> dict:
        with self._lock:
            total = self._hits + self._misses
            ratio = self._hits / total if total else 0.0
            return {
                'entries':   len(self._data),
                'bytes':     self._current_bytes,
                'max_bytes': self._max_bytes,
                'hits':      self._hits,
                'misses':    self._misses,
                'hit_ratio': round(ratio, 3),
            }

# ---------------------------------------------------------------
# PREBUFFER STATE
# ---------------------------------------------------------------
class PrebufferState:
    def __init__(self, required: int = PREBUFFER_SEGMENTS):
        self._required = required
        self._filled   = 0
        self._ready    = False
        self._lock     = threading.Lock()

    def mark_segment_ready(self):
        with self._lock:
            if not self._ready:
                self._filled += 1
                if self._filled >= self._required:
                    self._ready = True
                    logger.info(f"Prebuffer completo ({self._filled} segs) — liberando stream")

    def is_ready(self) -> bool:
        with self._lock:
            return self._ready

    def reset(self):
        with self._lock:
            self._filled = 0
            self._ready  = False

# ---------------------------------------------------------------
# ESTADO GLOBAL DA SESSÃO
# ---------------------------------------------------------------
URL_CACHE        = SmartLRUCache(maxsize=200, default_ttl=45)
PLAYLIST_SEQUENCE = SmartLRUCache(maxsize=20,  default_ttl=90)

SEGMENT_LRU    = SegmentLRUBuffer(max_bytes=SEGMENT_LRU_MAX_BYTES)
PREBUFFER_STATE = PrebufferState(required=PREBUFFER_SEGMENTS)

PREFETCH_CACHE      = OrderedDict()
PREFETCH_LOCK       = threading.Lock()
PREFETCH_MAX_ENTRIES = 8
PREFETCH_MAX_BYTES  = SEGMENT_LRU_MAX_BYTES

_LAST_URL_LOCK = threading.Lock()
LAST_KNOWN_URL = None

QUALITY_MONITOR    = QualityMonitor()
ADAPTIVE_BUFFER    = AdaptiveBuffer()
RECONNECTION_GUARD = ReconnectionGuard()

_ORIGINAL_URL_LOCK    = threading.Lock()
_CURRENT_ORIGINAL_URL = None
_PLAYLIST_REFRESH_THREAD = None
_PLAYLIST_REFRESH_LOCK   = threading.Lock()

def set_original_url(url):
    global _CURRENT_ORIGINAL_URL
    with _ORIGINAL_URL_LOCK:
        _CURRENT_ORIGINAL_URL = url
        if url:
            RECONNECTION_GUARD.reset()
            logger.info(f"URL original registrada: {url[:100]}...")

def get_original_url():
    with _ORIGINAL_URL_LOCK:
        return _CURRENT_ORIGINAL_URL

# ---------------------------------------------------------------
# USER-AGENTS + ROTATION OFUSCADA PARA RECONEXÕES
# ---------------------------------------------------------------
UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Edg/124.0.0.0",
]

_SESSION_UA_LOCK = threading.Lock()
_SESSION_UA      = random.choice(UAS)

def _get_session_ua():
    with _SESSION_UA_LOCK:
        return _SESSION_UA

def _rotate_session_ua():
    global _SESSION_UA
    with _SESSION_UA_LOCK:
        _SESSION_UA = random.choice(UAS)

def rotate_ua_for_reconnection():
    """Rotaciona UA ofuscado especificamente nas tentativas de reconexão."""
    _rotate_session_ua()
    with _SESSION_LOCK:
        if SESSION:
            SESSION.headers.update(_build_session_ua_headers())
    logger.info(f"UA ofuscado rotacionado para reconexão: {_get_session_ua()[:80]}...")

# ---------------------------------------------------------------
# SESSÃO HTTP PERSISTENTE
# ---------------------------------------------------------------
SESSION      = None
_SESSION_LOCK = threading.Lock()

def _build_session_ua_headers():
    ua         = _get_session_ua()
    is_firefox = 'Firefox' in ua
    if is_firefox:
        accept     = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
        accept_enc = "gzip, deflate, br"
        accept_lang = "pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3"
    else:
        accept     = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
        accept_enc = "gzip, deflate, br, zstd"
        accept_lang = "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
    return {
        'User-Agent':            ua,
        'Accept':                accept,
        'Accept-Encoding':       accept_enc,
        'Accept-Language':       accept_lang,
        'Cache-Control':         'no-cache',
        'Pragma':                'no-cache',
        'DNT':                   '1',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest':        'document',
        'Sec-Fetch-Mode':        'navigate',
        'Sec-Fetch-Site':        'none',
        'Sec-Fetch-User':        '?1',
    }

def _build_adapter():
    return requests.adapters.HTTPAdapter(
        pool_connections=4,
        pool_maxsize=8,
        max_retries=2,
        pool_block=False,
    )

def _init_session():
    global SESSION
    sess = requests.Session()
    sess.mount('http://',  _build_adapter())
    sess.mount('https://', _build_adapter())
    sess.headers.update(_build_session_ua_headers())
    sess.cookies.clear()
    SESSION = sess
    logger.info(f"Sessão HTTP criada | UA: {_get_session_ua()[:60]}...")
    return sess

def get_session():
    with _SESSION_LOCK:
        global SESSION
        if SESSION is None:
            _init_session()
        return SESSION

def reset_session():
    global SESSION
    _rotate_session_ua()
    with _SESSION_LOCK:
        try:
            if SESSION:
                SESSION.close()
        except Exception:
            pass
        _init_session()
    logger.info("Sessão HTTP reiniciada com novo UA")

def close_session():
    with _SESSION_LOCK:
        global SESSION
        try:
            if SESSION:
                SESSION.close()
                SESSION = None
        except Exception:
            pass
    logger.info("Sessão HTTP encerrada")

# ---------------------------------------------------------------
# CABEÇALHOS DINÂMICOS (COM FAKE IP ROTACIONADO EM TODOS)
# ---------------------------------------------------------------
def get_request_headers(url, referer=None):
    parsed    = urllib.parse.urlparse(url)
    origin    = f"{parsed.scheme}://{parsed.netloc}"
    ref_netloc = urllib.parse.urlparse(referer).netloc if referer else ''
    fake_ip   = get_random_fake_ip()
    return {
        'Host':           parsed.netloc,
        'Origin':         origin,
        'Referer':        referer if referer else f"{origin}/",
        'Sec-Fetch-Site': 'same-origin' if ref_netloc == parsed.netloc else 'cross-site',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'X-Forwarded-For': fake_ip,
        'X-Real-IP':       fake_ip,
        'X-Client-IP':     fake_ip,
        'Client-IP':       fake_ip,
    }

def get_m3u8_request_headers(url, referer=None):
    h = get_request_headers(url, referer)
    h['Sec-Fetch-Dest'] = 'document'
    h['Sec-Fetch-Mode'] = 'navigate'
    return h

def get_ts_request_headers(url, referer=None):
    h = get_request_headers(url, referer)
    h['Sec-Fetch-Dest'] = 'empty'
    h['Sec-Fetch-Mode'] = 'cors'
    h['Accept']         = '*/*'
    return h

def invalidate_cache(cache_key):
    URL_CACHE.delete(cache_key)

# ---------------------------------------------------------------
# DEDUPLICATION DE REQUESTS
# ---------------------------------------------------------------
_INFLIGHT_LOCK = threading.Lock()
_INFLIGHT: dict = {}

def _fetch_with_dedup(url, expected_type, referer):
    key = hashlib.md5(f"{url}|{expected_type}|{referer}".encode()).hexdigest()

    with _INFLIGHT_LOCK:
        if key in _INFLIGHT:
            event, result_holder = _INFLIGHT[key]
            wait_for_result = True
        else:
            event         = threading.Event()
            result_holder = [None, None]
            _INFLIGHT[key] = (event, result_holder)
            wait_for_result = False

    if wait_for_result:
        event.wait(timeout=15)
        with _INFLIGHT_LOCK:
            _, rh = _INFLIGHT.get(key, (None, [None, None]))
        if expected_type == 'ts':
            return _fetch_content_raw(url, expected_type, referer)
        return rh[0], rh[1]

    try:
        resp, final_url = _fetch_content_raw(url, expected_type, referer)
        with _INFLIGHT_LOCK:
            if key in _INFLIGHT:
                _INFLIGHT[key][1][0] = resp
                _INFLIGHT[key][1][1] = final_url
        return resp, final_url
    finally:
        with _INFLIGHT_LOCK:
            if key in _INFLIGHT:
                _INFLIGHT[key][0].set()
                threading.Timer(2.0, lambda: _INFLIGHT.pop(key, None)).start()

# ---------------------------------------------------------------
# RENOVAÇÃO FORÇADA DE TOKEN (UA OFUSCADO + FAKE IP)
# ---------------------------------------------------------------
def force_fresh_token(original_url, reason="token expirado", backoff=None):
    if not original_url:
        logger.warning("force_fresh_token: URL original não disponível")
        return None
    if not RECONNECTION_GUARD.can_reconnect():
        logger.warning("Limite de reconexões atingido")
        return None

    logger.info(f"Renovando token: {reason}")
    RECONNECTION_GUARD.record_attempt()
    rotate_ua_for_reconnection()                     # ← UA OFUSCADO na reconexão

    max_redirects = 8
    current_url   = original_url
    current_referer = original_url

    if backoff is None:
        backoff = ExponentialBackoff(base_delay=0.3, max_delay=5)

    try:
        sess = get_session()
        for hop in range(max_redirects):
            headers = get_m3u8_request_headers(current_url, current_referer)
            
            resp = sess.get(
                current_url, headers=headers, stream=True,
                timeout=(4.0, 12.0), allow_redirects=False, verify=False
            )
            
            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get('Location', '').strip()
                resp.close()
                if not location: break
                current_referer = current_url
                current_url = urllib.parse.urljoin(current_url, location)
                continue
                
            if resp.status_code == 200:
                content = resp.content
                resp.close()
                if b'#EXTM3U' in content:
                    logger.info("Novo token obtido")
                    URL_CACHE.set(original_url, current_url, ttl=90)
                    set_last_known_url(current_url)
                    backoff.reset()
                    return current_url
                break
            
            resp.close()
            break
            
    except Exception as e:
        logger.error(f"Erro na renovação: {e}")
        backoff.wait()

    return None

# ---------------------------------------------------------------
# FETCH CONTENT (OTIMIZADO + FAKE IP + UA rotacionado em reconexão)
# ---------------------------------------------------------------
def get_adaptive_timeout(url, attempt):
    base = (3.0, 8.0) if '.ts' in url.lower() else (4.0, 12.0)
    m    = min(1 + attempt * 0.2, 1.6)
    return (base[0] * m, base[1] * m)

def _make_fake_resp(content):
    return type('R', (), {
        '_cached_content': content,
        'close':           lambda self: None,
    })()

def _fetch_content_raw(url, expected_type='m3u8', referer=None, attempt=0):
    cache_key      = (url, referer) if referer else url
    cached_target  = URL_CACHE.get(cache_key)

    if cached_target:
        try:
            headers = (get_m3u8_request_headers if expected_type == 'm3u8'
                       else get_ts_request_headers)(cached_target, referer)
            sess = get_session()
            resp = sess.get(
                cached_target, headers=headers, stream=True,
                timeout=get_adaptive_timeout(cached_target, attempt),
                allow_redirects=False, verify=False
            )
            
            if resp.status_code in (301, 302, 303, 307, 308):
                resp.close()
                invalidate_cache(cache_key)
            elif resp.status_code == 200:
                if expected_type == 'm3u8':
                    content = resp.content; resp.close()
                    if b'#EXTM3U' in content:
                        return _make_fake_resp(content), cached_target
                elif expected_type == 'ts':
                    first = resp.raw.read(1)
                    if first == b'\x47':
                        resp._first_byte  = first
                        resp._target_url  = cached_target
                        resp._referer     = referer
                        return resp, cached_target
                    resp.close()
                elif expected_type == 'key':
                    resp._cached_content = resp.content
                    return resp, cached_target
            elif resp.status_code in (401, 403, 404, 410, 500, 502, 521):
                resp.close()
                invalidate_cache(cache_key)
            else:
                resp.close()
        except Exception:
            invalidate_cache(cache_key)

    max_redirects = 8
    max_retries   = 3
    backoff       = ExponentialBackoff(base_delay=0.3, max_delay=5)

    for retry in range(max_retries):
        current_url     = url
        current_referer = referer
        
        try:
            for _ in range(max_redirects):
                headers = (get_m3u8_request_headers if expected_type == 'm3u8'
                           else get_ts_request_headers)(current_url, current_referer)
                           
                sess = get_session()
                resp = sess.get(
                    current_url, headers=headers, stream=True,
                    timeout=get_adaptive_timeout(current_url, retry),
                    allow_redirects=False, verify=False
                )
                
                if resp.status_code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get('Location')
                    resp.close()
                    if not loc: break
                    current_referer = current_url
                    current_url     = urllib.parse.urljoin(current_url, loc)
                    continue

                if resp.status_code in (401, 403, 521, 500, 502, 503):
                    logger.warning(f"Status {resp.status_code} na tentativa {retry+1}. Renovando token...")
                    resp.close()
                    sess.cookies.clear()
                    rotate_ua_for_reconnection()          # ← UA OFUSCADO
                    orig = get_original_url()
                    if orig:
                        new_playlist_url = force_fresh_token(orig, f"Erro CDN {resp.status_code}")
                        if new_playlist_url:
                            url = update_url_token(url, new_playlist_url)
                            cache_key = (url, referer) if referer else url
                    break

                if resp.status_code in (404, 410):
                    resp.close()
                    break

                if resp.status_code == 200:
                    if expected_type == 'm3u8':
                        content = resp.content; resp.close()
                        if b'#EXTM3U' in content:
                            URL_CACHE.set(cache_key, current_url, ttl=90)
                            backoff.reset()
                            return _make_fake_resp(content), current_url
                    elif expected_type == 'ts':
                        t0    = time.time()
                        first = resp.raw.read(1)
                        ADAPTIVE_BUFFER.update(time.time() - t0)
                        if first == b'\x47':
                            QUALITY_MONITOR.record_segment_time(time.time() - t0)
                            resp._first_byte = first
                            resp._target_url = current_url
                            resp._referer    = current_referer
                            URL_CACHE.set(cache_key, current_url, ttl=90)
                            backoff.reset()
                            return resp, current_url
                        resp.close()
                    elif expected_type == 'key':
                        resp._cached_content = resp.content
                        URL_CACHE.set(cache_key, current_url, ttl=300)
                        backoff.reset()
                        return resp, current_url
                resp.close()
                break
                
        except Exception as e:
            logger.error(f"Erro tentativa {retry+1}: {e}")
            if retry == 0:
                orig = get_original_url()
                if orig:
                    logger.info("Falha na primeira tentativa, forçando URL original para token...")
                    rotate_ua_for_reconnection()
                    new_playlist_url = force_fresh_token(orig, "Falha na tentativa 1")
                    if new_playlist_url:
                        url = update_url_token(url, new_playlist_url)
                        cache_key = (url, referer) if referer else url
            backoff.wait()

    orig = get_original_url()
    if orig:
        rotate_ua_for_reconnection()
        new = force_fresh_token(orig, "todas tentativas falharam")
        if new:
            try:
                final_target = update_url_token(url, new)
                headers = (get_m3u8_request_headers if expected_type == 'm3u8' else get_ts_request_headers)(final_target, referer)
                resp = get_session().get(
                    final_target, headers=headers, stream=True,
                    timeout=get_adaptive_timeout(final_target, max_retries),
                    allow_redirects=False, verify=False
                )
                
                if resp.status_code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get('Location')
                    resp.close()
                    if loc:
                        final_target = urllib.parse.urljoin(final_target, loc)
                        headers = (get_m3u8_request_headers if expected_type == 'm3u8' else get_ts_request_headers)(final_target, final_target)
                        resp = get_session().get(final_target, headers=headers, stream=True, timeout=8.0, allow_redirects=False, verify=False)

                if resp.status_code == 200:
                    if expected_type == 'm3u8':
                        content = resp.content; resp.close()
                        if b'#EXTM3U' in content:
                            return _make_fake_resp(content), final_target
                    elif expected_type == 'ts':
                        first = resp.raw.read(1)
                        if first == b'\x47':
                            resp._first_byte = first
                            resp._target_url = final_target
                            resp._referer    = referer
                            return resp, final_target
                        resp.close()
                resp.close()
            except Exception as e:
                logger.error(f"Último recurso falhou: {e}")

    logger.error(f"Falha total para {url[:100]}...")
    return None, url

def fetch_content(url, expected_type='m3u8', referer=None, attempt=0):
    if expected_type == 'ts':
        return _fetch_content_raw(url, expected_type, referer, attempt)
    return _fetch_with_dedup(url, expected_type, referer)

# ---------------------------------------------------------------
# LAST_KNOWN_URL thread-safe
# ---------------------------------------------------------------
def set_last_known_url(url):
    global LAST_KNOWN_URL
    with _LAST_URL_LOCK:
        LAST_KNOWN_URL = url

def get_last_known_url():
    with _LAST_URL_LOCK:
        return LAST_KNOWN_URL

# ---------------------------------------------------------------
# LIMPEZA DE ESTADO ENTRE CANAIS
# ---------------------------------------------------------------
def clear_stream_state():
    global _PLAYLIST_REFRESH_THREAD
    URL_CACHE.clear()
    PLAYLIST_SEQUENCE.clear()
    SEGMENT_LRU.clear()
    PREBUFFER_STATE.reset()
    with PREFETCH_LOCK:
        PREFETCH_CACHE.clear()
    set_last_known_url(None)
    with _PLAYLIST_REFRESH_LOCK:
        if _PLAYLIST_REFRESH_THREAD and _PLAYLIST_REFRESH_THREAD.is_alive():
            _PLAYLIST_REFRESH_THREAD.stop()
            _PLAYLIST_REFRESH_THREAD = None
    logger.info("Estado de stream limpo (troca de canal)")

# ---------------------------------------------------------------
# HTTP SERVER
# ---------------------------------------------------------------
class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads    = True
    allow_reuse_address = True

# ---------------------------------------------------------------
# PLAYLIST REFRESH THREAD
# ---------------------------------------------------------------
class PlaylistRefreshThread(threading.Thread):
    def __init__(self, original_url, proxy_port, interval=3):
        super().__init__(daemon=True)
        self.original_url     = original_url
        self.proxy_port       = proxy_port
        self.interval         = interval
        self.running          = True
        self.last_playlist_time = 0

    def run(self):
        logger.info("Thread de refresh da playlist iniciada")
        while self.running:
            try:
                time.sleep(self.interval)
                if not self.running: break
                if QUALITY_MONITOR.is_stalled(timeout=15):
                    logger.warning("Stall detectado, forçando refresh")
                    self._force_refresh()
                    continue
                if time.time() - self.last_playlist_time > 10:
                    self._refresh_playlist()
                    self.last_playlist_time = time.time()
            except Exception as e:
                logger.error(f"Erro no refresh: {e}")

    def _refresh_playlist(self):
        try:
            resp, new_url = fetch_content(self.original_url, 'm3u8', self.original_url)
            if resp and hasattr(resp, '_cached_content'):
                content = resp._cached_content
                if content and b'#EXTM3U' in content:
                    URL_CACHE.set(self.original_url, new_url, ttl=90)
                    set_last_known_url(new_url)
                    lines = content.decode('utf-8', errors='ignore').splitlines()
                    ts_seq = []
                    for line in lines:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            abs_ts = urllib.parse.urljoin(new_url, line)
                            if not abs_ts.lower().endswith('.m3u8'):
                                ts_seq.append(abs_ts)
                    if ts_seq:
                        PLAYLIST_SEQUENCE.set(new_url, ts_seq, ttl=90)
                        for ts in ts_seq[:ADAPTIVE_BUFFER.get_buffer_size()]:
                            threading.Thread(
                                target=prefetch_worker,
                                args=(ts, new_url, 3),
                                daemon=True
                            ).start()
                try: resp.close()
                except Exception: pass
        except Exception as e:
            logger.error(f"Erro no refresh da playlist: {e}")

    def _force_refresh(self):
        orig = get_original_url()
        if orig:
            new = force_fresh_token(orig, "stall detectado")
            if new:
                set_original_url(new)
                self.last_playlist_time = 0

    def stop(self):
        self.running = False

def start_playlist_refresh(original_url, proxy_port):
    global _PLAYLIST_REFRESH_THREAD
    with _PLAYLIST_REFRESH_LOCK:
        if _PLAYLIST_REFRESH_THREAD and _PLAYLIST_REFRESH_THREAD.is_alive():
            _PLAYLIST_REFRESH_THREAD.stop()
            time.sleep(0.5)
        _PLAYLIST_REFRESH_THREAD = PlaylistRefreshThread(original_url, proxy_port)
        _PLAYLIST_REFRESH_THREAD.start()

# ---------------------------------------------------------------
# PREFETCH WORKER
# ---------------------------------------------------------------
def prefetch_worker(ts_url, referer, priority=0):
    try:
        if SEGMENT_LRU.contains(ts_url):
            return
        with PREFETCH_LOCK:
            if ts_url in PREFETCH_CACHE:
                return
        if priority > 0:
            time.sleep(0.05 * (3 - min(priority, 3)))

        headers = get_ts_request_headers(ts_url, referer)
        sess    = get_session()
        resp    = sess.get(ts_url, headers=headers, timeout=(3.0, 10.0),
                           allow_redirects=False, verify=False, stream=True)
                           
        if resp.status_code in (301, 302, 303, 307, 308):
            loc = resp.headers.get('Location')
            resp.close()
            if loc:
                ts_url = urllib.parse.urljoin(ts_url, loc)
                headers = get_ts_request_headers(ts_url, ts_url)
                resp = sess.get(ts_url, headers=headers, timeout=(3.0, 10.0), allow_redirects=False, verify=False, stream=True)

        if resp.status_code == 200:
            chunks = []
            total  = 0
            for chunk in resp.iter_content(chunk_size=SEND_CHUNK_SIZE):
                if not chunk: continue
                total += len(chunk)
                if total > PREFETCH_MAX_BYTES:
                    resp.close(); return
                chunks.append(chunk)
            content = b''.join(chunks)
            if content and content[0] == 0x47:
                SEGMENT_LRU.put(ts_url, content)
                PREBUFFER_STATE.mark_segment_ready()
                with PREFETCH_LOCK:
                    if len(PREFETCH_CACHE) >= PREFETCH_MAX_ENTRIES:
                        PREFETCH_CACHE.popitem(last=False)
                    PREFETCH_CACHE[ts_url] = content
        resp.close()
    except Exception:
        pass

# ---------------------------------------------------------------
# REQUEST HANDLER (sempre 200 OK)
# ---------------------------------------------------------------
class ProxyHTTPRequestHandler(http.server.BaseHTTPRequestHandler):

    _NULL_TS_PACKET = bytes([0x47, 0x1F, 0xFF, 0x10] + [0xFF] * 184)
    _NULL_TS_BODY   = _NULL_TS_PACKET * 10

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError, OSError):
            pass
        except Exception as e:
            logger.debug(f"Erro inesperado no handler do proxy: {e}")

    def log_message(self, format, *args):
        pass

    def decode_path(self, path):
        try:
            parts = path.strip("/").split("/")
            if len(parts) != 2: return None, None, None
            prefix, filename = parts
            PREFIX_MAP = {"playlist": "m3u8", "segment": "ts", "key": "key"}
            req_type   = PREFIX_MAP.get(prefix)
            if req_type is None: return None, None, None
            b64 = filename.rsplit(".", 1)[0]
            b64 += "=" * ((4 - len(b64) % 4) % 4)
            decoded   = base64.urlsafe_b64decode(b64).decode('utf-8')
            url, referer = decoded.split("|", 1)
            return req_type, url, referer
        except Exception:
            return None, None, None

    def make_proxy_url(self, req_type, url, referer):
        payload = f"{url}|{referer}".encode('utf-8')
        b64     = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        ext    = "m3u8" if req_type == "m3u8" else "ts" if req_type == "ts" else "key"
        prefix = "playlist" if req_type == "m3u8" else "segment" if req_type == "ts" else "key"
        host, port = self.server.server_address
        return f"http://{host}:{port}/{prefix}/{b64}.{ext}"

    def do_HEAD(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.send_header('Access-Control-Max-Age', '86400')
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        req_type, target_url, referer = self.decode_path(path)

        if not target_url:
            last = get_last_known_url()
            if last:
                if path.endswith('.ts') or '.ts?' in path:
                    target_url = urllib.parse.urljoin(last, self.path.lstrip('/'))
                    req_type   = 'ts'
                    referer    = last
                elif path.endswith('.key') or path.endswith('.bin'):
                    target_url = urllib.parse.urljoin(last, self.path.lstrip('/'))
                    req_type   = 'key'
                    referer    = last
                else:
                    self._send_fallback('m3u8'); return
            else:
                self._send_fallback('m3u8'); return
        else:
            if req_type == 'm3u8':
                set_last_known_url(target_url)

        if referer:
            referer = urllib.parse.unquote(referer)

        if req_type == 'ts':
            lru_data = SEGMENT_LRU.get(target_url)
            if lru_data:
                self._stream_from_buffer(lru_data)
                return
            with PREFETCH_LOCK:
                cached_data = PREFETCH_CACHE.pop(target_url, None)
            if cached_data:
                SEGMENT_LRU.put(target_url, cached_data)
                self._stream_from_buffer(cached_data)
                return

        resp, final_url = fetch_content(target_url, req_type, referer)
        if not resp:
            self._send_fallback(req_type); return

        if req_type   == 'm3u8': self._handle_m3u8(resp, final_url)
        elif req_type == 'ts':   self._handle_ts(resp, target_url, referer)
        elif req_type == 'key':  self._handle_key(resp)

    def _stream_from_buffer(self, data: bytes):
        try:
            self.send_response(200)
            self.send_header('Content-Type',   'video/mp2t')
            self.send_header('Content-Length', str(len(data)))
            self._send_cors_headers()
            self.end_headers()
            
            mv     = memoryview(data)
            offset = 0
            total  = len(data)
            while offset < total:
                end = min(offset + SEND_CHUNK_SIZE, total)
                self.wfile.write(mv[offset:end])
                offset = end
            QUALITY_MONITOR.record_segment_time(0)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        except Exception as e:
            logger.error(f"_stream_from_buffer erro: {e}")

    def _send_fallback(self, req_type):
        try:
            self.send_response(200)
            self._send_cors_headers()

            if req_type == 'm3u8':
                entry_url = get_original_url()
                if entry_url:
                    payload    = f"{entry_url}|".encode('utf-8')
                    b64        = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
                    host, port = self.server.server_address
                    proxy_back = f"http://{host}:{port}/playlist/{b64}.m3u8"
                    body = (
                        "#EXTM3U\n#EXT-X-VERSION:3\n"
                        "#EXT-X-TARGETDURATION:5\n#EXT-X-MEDIA-SEQUENCE:0\n"
                        "#EXT-X-DISCONTINUITY\n#EXTINF:5.0,\n"
                        f"{proxy_back}\n"
                    ).encode('utf-8')
                else:
                    body = (
                        b"#EXTM3U\n#EXT-X-VERSION:3\n"
                        b"#EXT-X-TARGETDURATION:5\n#EXT-X-MEDIA-SEQUENCE:0\n"
                        b"#EXTINF:5.0,\nsegment/null.ts\n"
                    )
                self.send_header('Content-Type',   'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            elif req_type == 'ts':
                body = self._NULL_TS_BODY
                self.send_header('Content-Type',   'video/mp2t')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            elif req_type == 'key':
                body = b'\x00' * 16
                self.send_header('Content-Type',   'application/octet-stream')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        except Exception as e:
            logger.debug(f"Erro em _send_fallback: {e}")

    def _send_cors_headers(self):
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma',        'no-cache')
        self.send_header('Expires',       '0')
        self.send_header('Access-Control-Allow-Origin',  '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Connection', 'keep-alive')

    def _rewrite_key_line(self, line, final_url):
        m = re.search(r'URI=(["\'])(.*?)\1', line)
        if not m: return line
        q, orig_uri = m.group(1), m.group(2)
        if orig_uri.lower().startswith('data:'): return line
        abs_key = urllib.parse.urljoin(final_url, orig_uri)
        proxy_k = self.make_proxy_url("key", abs_key, final_url)
        return line[:m.start()] + f'URI={q}{proxy_k}{q}' + line[m.end():]

    def _handle_m3u8(self, resp, final_url):
        try:
            content = resp._cached_content.decode('utf-8', errors='ignore')
        except Exception:
            self._send_fallback('m3u8'); return
        finally:
            try: resp.close()
            except Exception: pass

        lines     = content.splitlines()
        new_lines = []
        ts_seq    = []

        for line in lines:
            line = line.strip()
            if not line: continue
            if line.startswith('#EXT-X-KEY'):
                new_lines.append(self._rewrite_key_line(line, final_url))
            elif line.startswith('#EXT-X-ENDLIST'):
                continue
            elif not line.startswith('#'):
                abs_ts = urllib.parse.urljoin(final_url, line)
                if abs_ts.lower().split('?')[0].endswith('.m3u8'):
                    new_lines.append(self.make_proxy_url("m3u8", abs_ts, final_url))
                else:
                    ts_seq.append(abs_ts)
                    new_lines.append(self.make_proxy_url("ts", abs_ts, final_url))
            else:
                new_lines.append(line)

        PLAYLIST_SEQUENCE.set(final_url, ts_seq, ttl=90)
        output = '\n'.join(new_lines).encode('utf-8')

        try:
            self.send_response(200)
            self.send_header('Content-Type',   'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(output)))
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(output)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        except Exception:
            pass

    def _handle_ts(self, resp, current_ts_url, referer):
        max_retries = 3
        target_url  = getattr(resp, '_target_url', None) or current_ts_url
        backoff     = ExponentialBackoff(base_delay=0.3, max_delay=5)

        if referer:
            seq = PLAYLIST_SEQUENCE.get(referer, [])
            if seq:
                try:
                    idx = seq.index(current_ts_url)
                    for i in range(1, min(ADAPTIVE_BUFFER.get_buffer_size(), len(seq) - idx)):
                        threading.Thread(
                            target=prefetch_worker,
                            args=(seq[idx + i], referer, min(3, i)),
                            daemon=True
                        ).start()
                except ValueError:
                    pass

        segment_data = None

        for attempt in range(max_retries):
            retry_resp = None
            try:
                if attempt == 0 and resp and hasattr(resp, '_first_byte'):
                    chunks = [resp._first_byte]
                    for chunk in resp.iter_content(chunk_size=SEND_CHUNK_SIZE):
                        if chunk: chunks.append(chunk)
                    segment_data = b''.join(chunks)
                    QUALITY_MONITOR.record_segment_time(0)
                    break

                else:
                    if attempt >= 1:
                        orig = get_original_url()
                        if orig:
                            logger.info(f"Falha no segmento TS. Forçando token na original (tentativa {attempt})")
                            rotate_ua_for_reconnection()
                            new_playlist_url = force_fresh_token(orig, f"TS falhou tentativa {attempt}")
                            if new_playlist_url:
                                target_url = update_url_token(target_url, new_playlist_url)

                    headers = get_ts_request_headers(target_url, referer)
                    retry_resp = get_session().get(
                        target_url, headers=headers, stream=True,
                        timeout=get_adaptive_timeout(target_url, attempt),
                        allow_redirects=False, verify=False
                    )
                    
                    if retry_resp.status_code in (301, 302, 303, 307, 308):
                        loc = retry_resp.headers.get('Location')
                        retry_resp.close()
                        if loc:
                            target_url = urllib.parse.urljoin(target_url, loc)
                            headers = get_ts_request_headers(target_url, target_url)
                            retry_resp = get_session().get(target_url, headers=headers, stream=True, timeout=8.0, allow_redirects=False, verify=False)

                    if retry_resp.status_code in (200, 206):
                        chunks = []
                        for chunk in retry_resp.iter_content(chunk_size=SEND_CHUNK_SIZE):
                            if chunk: chunks.append(chunk)
                        candidate = b''.join(chunks)
                        if candidate and candidate[0] == 0x47:
                            segment_data = candidate
                            QUALITY_MONITOR.record_segment_time(0)
                        break
                    elif retry_resp.status_code in (401, 403, 521):
                        invalidate_cache((current_ts_url, referer) if referer else current_ts_url)
                        get_session().cookies.clear()
                        retry_resp.close(); continue
                    else:
                        backoff.wait()

            except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, OSError):
                logger.debug("Conexão com Kodi interrompida"); break
            except Exception as e:
                logger.error(f"Erro TS attempt {attempt+1}: {e}")
                backoff.wait()
            finally:
                if attempt == 0 and resp:
                    try: resp.close()
                    except Exception: pass
                if retry_resp:
                    try: retry_resp.close()
                    except Exception: pass

        if segment_data and segment_data[0] == 0x47:
            SEGMENT_LRU.put(current_ts_url, segment_data)
            PREBUFFER_STATE.mark_segment_ready()
            self._stream_from_buffer(segment_data)
        else:
            try:
                self.send_response(200)
                self.send_header('Content-Type',   'video/mp2t')
                self.send_header('Content-Length', str(len(self._NULL_TS_BODY)))
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(self._NULL_TS_BODY)
                logger.info("TS: null packets injetados após falha total")
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            except Exception: pass

    def _handle_key(self, resp):
        key_data = getattr(resp, '_cached_content', b'') or b'\x00' * 16
        try:
            self.send_response(200)
            self.send_header('Content-Type',   'application/octet-stream')
            self.send_header('Content-Length', str(len(key_data)))
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(key_data)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        except Exception: pass
        finally:
            try: resp.close()
            except Exception: pass

# ---------------------------------------------------------------
# PLAYBACK MONITOR
# ---------------------------------------------------------------
class PlaybackMonitor(threading.Thread):
    def __init__(self, on_stop, on_start=None, poll_interval=1.0):
        super().__init__(daemon=True)
        self.on_stop      = on_stop
        self.on_start     = on_start
        self.poll_interval = poll_interval
        self._abort       = threading.Event()
        self.is_playing   = False

    def run(self):
        try:
            import xbmc
        except ImportError:
            return
        for _ in range(30):
            if self._abort.is_set(): return
            if xbmc.Player().isPlaying():
                self.is_playing = True
                if self.on_start:
                    try: self.on_start()
                    except Exception: pass
                break
            time.sleep(0.5)
        if not self.is_playing:
            logger.info("Player não iniciou"); return
        logger.info("Monitor de playback iniciado")
        while not self._abort.is_set():
            if not xbmc.Player().isPlaying():
                logger.info("Playback encerrado")
                try: self.on_stop()
                except Exception as e: logger.error(f"Erro no on_stop: {e}")
                return
            time.sleep(self.poll_interval)

    def abort(self):
        self._abort.set()

# ---------------------------------------------------------------
# HLS ADDON — SINGLETON
# ---------------------------------------------------------------
class HLSAddon:

    _instance      = None
    _instance_lock = threading.Lock()

    def __new__(cls, addon_handle=None):
        with cls._instance_lock:
            if cls._instance is None:
                inst = super().__new__(cls)
                inst._initialized = False
                cls._instance = inst
            return cls._instance

    def __init__(self, addon_handle=None):
        if self._initialized:
            if addon_handle is not None:
                self.addon_handle = addon_handle
            return

        self.addon_handle  = addon_handle
        self._monitor      = None
        self._monitor_lock = threading.Lock()

        get_session()

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), ProxyHTTPRequestHandler)
        self.port   = self.server.server_address[1]

        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self._initialized = True
        logger.info(f"Proxy HLS iniciado na porta {self.port}")

    def play_stream(self, original_url, listitem=None):
        with self._monitor_lock:
            if self._monitor and self._monitor.is_alive():
                self._monitor.abort()
                self._monitor = None

        clear_stream_state()
        set_original_url(original_url)

        self._warm_prebuffer(original_url)

        start_playlist_refresh(original_url, self.port)

        payload   = f"{original_url}|".encode('utf-8')
        b64       = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        proxy_url = f"http://127.0.0.1:{self.port}/playlist/{b64}.m3u8"

        def on_start():
            logger.info("Stream iniciada com sucesso")

        def on_stop():
            logger.info("Playback encerrado, limpando estado")
            clear_stream_state()

        with self._monitor_lock:
            self._monitor = PlaybackMonitor(on_stop=on_stop, on_start=on_start)
            self._monitor.start()

        try:
            import xbmcplugin, xbmcgui, xbmc

            if listitem is None or isinstance(listitem, str):
                listitem = xbmcgui.ListItem(path=proxy_url)
            else:
                listitem.setPath(proxy_url)
            listitem.setProperty("IsPlayable", "true")

            handle = -1
            if self.addon_handle is not None:
                try: handle = int(self.addon_handle)
                except Exception: pass

            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, True, listitem)
            else:
                xbmc.Player().play(proxy_url, listitem)

            logger.info(f"Stream iniciada: {proxy_url}")

        except ImportError:
            return proxy_url

    def _warm_prebuffer(self, original_url):
        logger.info("Aquecendo prebuffer...")
        try:
            resp, resolved_url = _fetch_content_raw(original_url, 'm3u8', original_url)
            if not resp or not hasattr(resp, '_cached_content'):
                return
            content = resp._cached_content
            if not content or b'#EXTM3U' not in content:
                return

            ts_urls = []
            for line in content.decode('utf-8', errors='ignore').splitlines():
                line = line.strip()
                if line and not line.startswith('#'):
                    abs_ts = urllib.parse.urljoin(resolved_url, line)
                    if not abs_ts.lower().endswith('.m3u8'):
                        ts_urls.append(abs_ts)
            if not ts_urls:
                return

            for ts in ts_urls[:PREBUFFER_SEGMENTS]:
                threading.Thread(
                    target=prefetch_worker,
                    args=(ts, resolved_url, 0),
                    daemon=True
                ).start()

            deadline = time.time() + 6.0
            while time.time() < deadline:
                if PREBUFFER_STATE.is_ready():
                    logger.info("Prebuffer pronto — iniciando stream")
                    return
                time.sleep(0.1)
            logger.warning("Prebuffer timeout — iniciando stream parcial")

        except Exception as e:
            logger.error(f"Erro no warm_prebuffer: {e}")

    def stop(self):
        logger.info("Encerrando proxy...")

        with self._monitor_lock:
            if self._monitor and self._monitor.is_alive():
                self._monitor.abort()
                self._monitor = None

        global _PLAYLIST_REFRESH_THREAD
        with _PLAYLIST_REFRESH_LOCK:
            if _PLAYLIST_REFRESH_THREAD and _PLAYLIST_REFRESH_THREAD.is_alive():
                _PLAYLIST_REFRESH_THREAD.stop()
                _PLAYLIST_REFRESH_THREAD = None

        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception: pass

        close_session()

        with HLSAddon._instance_lock:
            HLSAddon._instance = None

        logger.info("Proxy HLS encerrado")

    def get_port(self):
        return self.port