import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
import warnings
import os
import re
from collections import OrderedDict
from typing import Optional, Dict
import http.server
import socketserver
# Importa o requests do módulo doh_client para usar DNS-over-HTTPS
from doh_client import requests
import requests.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import m3u8
import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------

MAX_SEGMENT_RETRIES = 10  # Aumentado para 10 para maior resiliência
RETRY_BACKOFF_FACTOR = 2.0  # Aumentado para 2.0 para maior tempo de espera entre retries
CONNECTION_TIMEOUT = 15 # Aumentado para 15 segundos
STREAM_TIMEOUT = 60.0 # Aumentado para 60 segundos para redes mais lentas
DEFAULT_CHUNK_SIZE = 1024 * 512  # Aumentado para 512KB para melhor desempenho em conexões estáveis
MAX_CACHE_MB = 128 # Aumentado o cache para 128MB
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
LOG_FILE = "hlsproxy_iptv.log"
MANIFEST_RELOAD_INTERVAL = 10  # Tempo de recarga proativa do manifesto em segundos
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
THROTTLE_RATE_KBPS = 0  # Limite de 500 KB/s para evitar traffic shaping. Defina como 0 para desabilitar.
# Definição do número máximo de tentativas de reconexão
MAX_RECONNECTION_ATTEMPTS = 15

# ---------------- UTILS ----------------

def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')])
    except Exception as e:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
        logging.error(f"Erro ao configurar o logging para o arquivo: {e}")

# ---------------- PROXY LOGIC ----------------

class ManifestCache:
    def __init__(self, max_size=10):
        self.cache = OrderedDict()
        self.max_size = max_size
        self.lock = threading.Lock()

    def get(self, session_id):
        with self.lock:
            manifest_info = self.cache.get(session_id)
            if manifest_info:
                self.cache.move_to_end(session_id)
            return manifest_info

    def set(self, session_id, manifest_url, manifest_content, last_updated):
        with self.lock:
            if session_id in self.cache:
                self.cache.move_to_end(session_id)
            self.cache[session_id] = {
                'url': manifest_url,
                'content': manifest_content,
                'last_updated': last_updated
            }
            if len(self.cache) > self.max_size:
                self.cache.popitem(last=False)

    def should_reload(self, session_id):
        with self.lock:
            manifest_info = self.cache.get(session_id)
            if manifest_info and (time.time() - manifest_info['last_updated']) > MANIFEST_RELOAD_INTERVAL:
                return True
            return False
            
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    manifest_cache = ManifestCache()

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    def do_HEAD(self):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return
                
            url = urllib.parse.unquote_plus(self.path.split('?url=')[1].split('&')[0])
            parsed_url = urllib.parse.urlparse(url)
            headers = {'User-Agent': USER_AGENT}
            if 'Range' in self.headers:
                headers['Range'] = self.headers['Range']
            
            try:
                r = requests.head(url, headers=headers, stream=True, timeout=CONNECTION_TIMEOUT, allow_redirects=True)
                self.send_response(r.status_code)
                for header, value in r.headers.items():
                    self.send_header(header, value)
                self.end_headers()
            except requests.exceptions.RequestException as e:
                logging.error(f"Erro no HEAD para {url}: {e}")
                self.send_error(502)
        except Exception as e:
            logging.error(f"Erro inesperado no HEAD: {e}")
            self.send_error(500)

    def do_GET(self):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?')[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [None])[0]

            if not url:
                self.send_error(400)
                return
            
            headers = {'User-Agent': USER_AGENT}
            range_header = self.headers.get('Range', None)
            if range_header:
                headers['Range'] = range_header

            parsed_url = urllib.parse.urlparse(url)
            
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self.handle_hls_stream(url, session_id, headers)
            else:
                self.handle_progressive_stream(url, headers)

        except (IndexError, ValueError):
            self.send_error(400)
        except Exception as e:
            logging.error(f"Erro inesperado no GET para {self.path}: {e}")
            self.send_error(500)

    def handle_hls_stream(self, url, session_id, headers):
        manifest_info = self.manifest_cache.get(session_id)
        
        # Lógica de cache e recarga
        if not manifest_info or self.manifest_cache.should_reload(session_id):
            try:
                r = requests.get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False)
                r.raise_for_status()
                manifest_content = r.text
                base_url = r.url
                self.manifest_cache.set(session_id, base_url, manifest_content, time.time())
            except requests.exceptions.RequestException as e:
                logging.error(f"Erro ao obter manifesto HLS para {url}: {e}")
                self.send_error(502)
                return
        else:
            manifest_content = manifest_info['content']
            base_url = manifest_info['url']

        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()

            new_manifest_lines = []
            for line in manifest_content.splitlines():
                if not line.startswith('#') and line.strip():
                    full_segment_url = urllib.parse.urljoin(base_url, line)
                    proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&session_id={session_id}"
                    new_manifest_lines.append(proxy_segment_url)
                else:
                    new_manifest_lines.append(line)
            
            self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
        except Exception as e:
            logging.error(f"Erro ao processar manifesto para {url}: {e}")
            self.send_error(500)

    def handle_progressive_stream(self, url, headers):
        # Configurar sessão com lógica de retry aprimorada para redes instáveis
        session = requests.session()
        retry_strategy = Retry(
            total=MAX_SEGMENT_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        session.mount('http://', HTTPAdapter(max_retries=retry_strategy))
        session.mount('https://', HTTPAdapter(max_retries=retry_strategy))
        
        retries = 0
        start_byte = 0
        if 'range' in headers:
            start_byte_str = headers['range'].split('=')[-1].split('-')[0]
            if start_byte_str:
                start_byte = int(start_byte_str)
            
        while retries < MAX_RECONNECTION_ATTEMPTS:
            try:
                if start_byte > 0:
                    headers['Range'] = f"bytes={start_byte}-"
                
                with session.get(url, headers=headers, stream=True, timeout=STREAM_TIMEOUT, verify=False) as r:
                    r.raise_for_status()
                    
                    if start_byte > 0 and r.status_code == 200:
                        self.send_response(206) # Partial content
                        content_range = r.headers.get('Content-Range')
                        if content_range:
                            self.send_header('Content-Range', content_range)
                        else:
                             # Se Content-Range não estiver presente, construímos um
                            total_size = r.headers.get('Content-Length')
                            self.send_header('Content-Range', f"bytes {start_byte}-{start_byte + len(r.content) - 1}/{total_size or '*'}")
                    else:
                        self.send_response(r.status_code)
                    
                    for header, value in r.headers.items():
                        # Evita headers que podem causar problemas em proxies
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.send_header(header, value)
                    self.end_headers()

                    last_check_time = time.time()
                    bytes_sent_in_period = 0
                    
                    for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        if not chunk:
                            continue
                        
                        try:
                            self.wfile.write(chunk)
                            bytes_sent_in_period += len(chunk)
                            start_byte += len(chunk)
                        except (ConnectionError, BrokenPipeError, OSError) as write_error:
                            logging.warning(f"Conexão do cliente quebrada durante a escrita. Tentando reconectar e continuar. {write_error}")
                            retries += 1
                            time.sleep(retries) # Espera com backoff
                            # Quebra o loop para tentar reconectar
                            break 
                        
                        # Lógica de throttling para evitar traffic shaping
                        if THROTTLE_RATE_KBPS > 0:
                            current_time = time.time()
                            elapsed_time = current_time - last_check_time
                            if elapsed_time >= 1: # Checa a cada segundo
                                expected_bytes = THROTTLE_RATE_KBPS * 1024
                                if bytes_sent_in_period > expected_bytes:
                                    sleep_time = (bytes_sent_in_period - expected_bytes) / (THROTTLE_RATE_KBPS * 1024)
                                    time.sleep(sleep_time)
                                bytes_sent_in_period = 0
                                last_check_time = current_time
                        
                    else: # Se o loop for completado sem 'break'
                        return # Sucesso, sai do loop while
                    
            except requests.exceptions.RequestException as e:
                logging.error(f"Erro ao transmitir arquivo progressivo para {url}: {e}. Tentativa {retries+1}/{MAX_RECONNECTION_ATTEMPTS}")
                retries += 1
                time.sleep(retries) # Espera com backoff
            except (ConnectionError, OSError, BrokenPipeError) as e:
                logging.warning(f"Conexão quebrada para o cliente. Tentando reconectar e continuar. {e}")
                retries += 1
                time.sleep(retries) # Espera com backoff

        logging.error(f"Falha ao transmitir o stream após {MAX_RECONNECTION_ATTEMPTS} tentativas.")

# ---------------- PROXY MANAGER ----------------

class IPTVHLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def is_running(self):
        return self._is_running

    def start(self):
        if self.is_running():
            return True

        self.stop()
        
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                self.active_port = port
                self._is_running = True
                logging.info(f"Proxy iniciado em {self.active_port}")
                return True
            except OSError:
                continue
        return False

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        if self.server_thread:
            self.server_thread.join(1)
        self.server = None
        self.server_thread = None
        self._is_running = False

# ---------------- ADDON ----------------

class HLSProxyAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        # Gerar um ID de sessão único para este stream
        session_id = f"{int(time.time())}_{random.randint(1000, 9999)}"
        
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&session_id={session_id}"
        
        li = xbmcgui.ListItem(path=proxy_url, label=title or "Canal IPTV")
        li.setProperty("IsPlayable", "true")
        if stype == "live":
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true")
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    try:
        h = int(sys.argv[1])
        addon = HLSProxyAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]
        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(stream_url, stream_type, title)
        else:
            xbmcplugin.endOfDirectory(h)
    except Exception as e:
        logging.error(f"Erro no main: {e}")

if __name__ == '__main__':
    main()