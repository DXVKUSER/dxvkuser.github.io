# -*- coding: utf-8 -*-
"""
hlsproxy_fixed_full.py
Correção aplicada: process_m3u8 agora recebe proxy_manager corretamente.
Elimina erro: "process_m3u8() missing 1 required positional argument".
"""

import sys
import threading
import urllib.parse
import warnings
import time
import random
from dataclasses import dataclass, field
from typing import Dict, Optional
import xbmc, xbmcgui, xbmcplugin
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException, ChunkedEncodingError, ConnectionError
from urllib3.util.retry import Retry
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

# --------------- CONFIG ---------------
@dataclass(frozen=True)
class ProxyConfig:
    max_retries: int = 3
    retry_backoff_factor: float = 0.6
    connection_timeout: int = 10
    stream_timeout: float = 30.0
    chunk_size: int = 64 * 1024
    max_reconnect_attempts: int = 4
    default_headers: Dict[str, str] = field(default_factory=lambda: {
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
    })
    verify_ssl: bool = False

PROXY_CONFIG = ProxyConfig()

USER_AGENTS = [
    'VLC/3.0.20',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/116',
    'AppleCoreMedia/1.0.0 (Apple TV)',
    'curl/7.68.0',
    'Lavf/58.76.100'
]

# --------------- SESSIONS ---------------
SESSION_POOL: Dict[str, requests.Session] = {}
SESSION_POOL_LOCK = threading.Lock()

def rand_ua():
    return random.choice(USER_AGENTS)

def create_session_for_host(host: str, ua: Optional[str] = None) -> requests.Session:
    with SESSION_POOL_LOCK:
        if host in SESSION_POOL:
            return SESSION_POOL[host]
        s = requests.Session()
        ua = ua or rand_ua()
        retry = Retry(
            total=PROXY_CONFIG.max_retries,
            read=PROXY_CONFIG.max_retries,
            connect=PROXY_CONFIG.max_retries,
            backoff_factor=PROXY_CONFIG.retry_backoff_factor,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "HEAD", "OPTIONS"]
        )
        adapter = HTTPAdapter(pool_connections=20, pool_maxsize=20, max_retries=retry, pool_block=True)
        s.mount('http://', adapter)
        s.mount('https://', adapter)
        s.verify = PROXY_CONFIG.verify_ssl
        s.trust_env = False
        s.headers.update({'User-Agent': ua})
        warnings.filterwarnings('ignore', 'Unverified HTTPS request')
        SESSION_POOL[host] = s
        return s

# --------------- M3U8 PROCESSOR ---------------
def process_m3u8(content: str, base_url: str, proxy_manager) -> str:
    lines = content.splitlines()
    processed = []
    parsed = urllib.parse.urlparse(base_url)
    root = f"{parsed.scheme}://{parsed.netloc}"
    base_path = base_url.rsplit("/", 1)[0]

    for line in lines:
        if not line or line.startswith("#"):
            if line.startswith("#EXT-X-KEY") and "URI=" in line:
                try:
                    key_uri = line.split("URI=")[1].split('"')[1]
                    abs_url = key_uri if key_uri.startswith("http") else (
                        root + key_uri if key_uri.startswith("/") else f"{base_path}/{key_uri}"
                    )
                    proxied = proxy_manager.url(abs_url)
                    line = line.replace(key_uri, proxied)
                except Exception:
                    pass
            processed.append(line)
            continue

        abs_url = line if line.startswith("http") else (
            root + line if line.startswith("/") else f"{base_path}/{line}"
        )
        proxied = proxy_manager.url(abs_url)
        processed.append(proxied)

    return "\n".join(processed)

# --------------- PROXY CORE ---------------
class HLSProxyManager:
    def __init__(self):
        self._server = None
        self._port = None
        self._lock = threading.Lock()

    def start(self, pr=(15000, 15099)):
        with self._lock:
            if self._server:
                return True
            for port in range(pr[0], pr[1]+1):
                try:
                    self._port = port
                    self._server = ThreadedHTTPServer(('127.0.0.1', port), ProxyHandler)
                    threading.Thread(target=self._server.serve_forever, daemon=True).start()
                    xbmc.log(f"[HLSProxy] iniciado na porta {port}", xbmc.LOGINFO)
                    return True
                except OSError:
                    continue
            xbmc.log("[HLSProxy] erro iniciando servidor", xbmc.LOGERROR)
            return False

    def stop(self):
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None

    def url(self, tgt: str) -> Optional[str]:
        return f"http://127.0.0.1:{self._port}/?url={urllib.parse.quote_plus(tgt)}" if self._port else None

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class ProxyHandler(BaseHTTPRequestHandler):
    timeout = 60

    def do_GET(self):
        self._handle()

    def do_HEAD(self):
        self._handle()

    def _handle(self):
        try:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if 'url' not in qs:
                self.send_error(400, "URL ausente")
                return
            url = urllib.parse.unquote_plus(qs['url'][0])
            is_manifest = '.m3u8' in url.lower()
            resp = self._fetch(url)
            if not resp:
                self.send_error(502, "Falha no backend")
                return

            self.send_response(resp.status_code)
            hop_by_hop = {'connection','keep-alive','proxy-authenticate','proxy-authorization','te','trailers'}
            for k, v in resp.headers.items():
                lk = k.lower()
                if lk in hop_by_hop:
                    continue
                try:
                    self.send_header(k, v)
                except Exception:
                    pass
            self.end_headers()

            if self.command == 'HEAD':
                resp.close()
                return

            try:
                if is_manifest or "mpegurl" in resp.headers.get("content-type", "").lower():
                    processed = process_m3u8(resp.text, resp.url, PROXY_MANAGER)
                    self.wfile.write(processed.encode('utf-8'))
                else:
                    for chunk in resp.iter_content(chunk_size=PROXY_CONFIG.chunk_size):
                        if not chunk:
                            continue
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError):
                            xbmc.log("[HLSProxy] cliente desconectado durante write", xbmc.LOGDEBUG)
                            break
            finally:
                resp.close()
        except Exception as e:
            xbmc.log(f"[HLSProxy] erro no handler: {e}", xbmc.LOGERROR)
            try:
                self.send_error(500, "Erro interno")
            except Exception:
                pass

    def _fetch(self, url):
        parsed = urllib.parse.urlparse(url)
        host = parsed.netloc.split(':')[0] if parsed.netloc else ''
        last_exc = None
        for attempt in range(PROXY_CONFIG.max_reconnect_attempts):
            try:
                ua = rand_ua()
                session = create_session_for_host(host, ua)
                headers = dict(PROXY_CONFIG.default_headers)
                headers.update({
                    'User-Agent': ua,
                    'Host': parsed.netloc,
                    'Referer': f"{parsed.scheme}://{parsed.netloc}/"
                })
                resp = session.request(
                    self.command,
                    url,
                    headers=headers,
                    timeout=(PROXY_CONFIG.connection_timeout, PROXY_CONFIG.stream_timeout),
                    stream=True
                )
                if resp.status_code >= 500 or resp.status_code == 429:
                    raise RequestException(f"Status {resp.status_code}")
                resp.raw.decode_content = True
                return resp
            except (RequestException, ConnectionError, ChunkedEncodingError) as e:
                last_exc = e
                xbmc.log(f"[HLSProxy] tentativa {attempt+1} falhou para {url}: {e}", xbmc.LOGDEBUG)
                time.sleep(min((2 ** attempt) * PROXY_CONFIG.retry_backoff_factor, 5))
        xbmc.log(f"[HLSProxy] máximo de tentativas atingido para {url}: {last_exc}", xbmc.LOGERROR)
        return None

# --------------- ADDON ---------------
class HLSProxyAddon:
    def __init__(self, h):
        self.h = h

    def play_stream(self, url: str, title='Stream HLS'):
        global PROXY_MANAGER
        if not PROXY_MANAGER:
            PROXY_MANAGER = HLSProxyManager()
        if not PROXY_MANAGER.start():
            xbmcgui.Dialog().notification("Erro Proxy", "Falha ao iniciar", xbmcgui.NOTIFICATION_ERROR)
            return
        pu = PROXY_MANAGER.url(url)
        if not pu:
            xbmcgui.Dialog().notification("Erro Proxy", "URL Proxy inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        li = xbmcgui.ListItem(title, path=pu)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(self.h, True, li)

# Instância global
PROXY_MANAGER: Optional[HLSProxyManager] = None

if __name__ == '__main__':
    h = -1
    try:
        h = int(sys.argv[1])
        args = urllib.parse.parse_qs(sys.argv[2][1:] if len(sys.argv) > 2 else '')
        if args.get('action', [None])[0] in ['play', 'play_stream'] and args.get('url', [None])[0]:
            HLSProxyAddon(h).play_stream(
                args['url'][0],
                args.get('title', ['Stream HLS'])[0]
            )
        else:
            xbmcplugin.endOfDirectory(h, succeeded=False)
    except Exception as e:
        xbmc.log(f"[HLSProxy] Erro no addon: {e}", xbmc.LOGERROR)
        if h != -1:
            xbmcplugin.endOfDirectory(h, succeeded=False)