# --- CÓDIGO COMPLETO E CORRIGIDO (PLAYER PADRÃO KODI) ---
# Lida com redirecionamentos e ajusta o cabeçalho Host dinamicamente
# IMPORTANTE: Este código utiliza a biblioteca 'script.module.netunblock'
# para contornar bloqueios de DNS de operadoras.
# Certifique-se de que o módulo está instalado no Kodi.
import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
from collections import OrderedDict
from typing import Optional, Dict
import warnings
import socket

# Tenta importar 'requests' do módulo 'doh_client' para usar DoH (DNS over HTTPS).
# Isso ajuda a contornar bloqueios de DNS de operadoras.
try:
    from doh_client import requests
except ImportError:
    # Se o módulo 'doh_client' não estiver disponível, usa a biblioteca 'requests' padrão.
    import requests

# Importa as exceções de 'requests' separadamente para evitar conflitos.
import requests.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import m3u8
from werkzeug.serving import make_server
from flask import Flask, request, Response, stream_with_context

# Configurações principais
MAX_SEGMENT_RETRIES = 3
RETRY_BACKOFF_FACTOR = 0.5
MAX_BACKOFF_TIME = 10
CONNECTION_TIMEOUT = 5.0
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 64 * 1024
MAX_CACHE_MB = 128
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
SESSION_MAX_AGE = 60

# Definimos User-Agents fixos para maior compatibilidade.
USER_AGENTS = [
    "VLC/3.0.20 LibVLC/3.0.20 (X11; Linux x86_64)",
    "ExoPlayer/2.18.7 (Linux; Android 13)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)",
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
LOG_FILE = "hlsproxy_iptv_proactive_default_player.log"

def setup_logging():
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    logging.basicConfig(
        handlers=[handler, logging.StreamHandler(sys.stdout)],
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s"
    )

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")):
        return "application/vnd.apple.mpegurl"
    if path.endswith((".ts")) or "auth/" in path or "stream/" in path:
        return "video/mp2t"
    if path.endswith(".aac"):
        return "audio/aac"
    if path.endswith(".mp4"):
        return "video/mp4"
    return "application/octet-stream"

def get_headers(url: str, original_url: Optional[str] = None, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    # O Host DEVE ser o do domínio final da URL, não o original.
    parsed_url = urllib.parse.urlparse(url)
    original_host = urllib.parse.urlparse(original_url).netloc if original_url else parsed_url.netloc
    
    headers = {
        "Host": parsed_url.netloc, # Corrigido: Agora o Host é dinâmico
        "User-Agent": "VLC/3.0.20 (Linux)",
        "Accept": "application/vnd.apple.mpegurl, */*",
        "Accept-Encoding": "identity",
        "Connection": "keep-alive",
        # Referer e Origin ainda são do domínio original para validação
        "Referer": f"http://{original_host}/", 
        "Origin": f"http://{original_host}",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache",
    }
    
    if extra: headers.update(extra)
    return headers

class RotatingCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.store = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            item = self.store.get(url)
            if not item: return None
            data, expire = item
            if expire and expire < time.time():
                self._pop(url)
                return None
            self.store.move_to_end(url)
            return data

    def add(self, url: str, data: bytes, ttl: int):
        with self.lock:
            if url in self.store: self._pop(url)
            size = len(data)
            if size > self.max_bytes: return
            while self.total_bytes + size > self.max_bytes: self._popitem(last=False)
            expire = time.time() + ttl if ttl else None
            self.store[url] = (data, expire)
            self.total_bytes += size

    def _pop(self, url: str):
        if url in self.store:
            data, _ = self.store.pop(url)
            self.total_bytes -= len(data)

    def _popitem(self, last: bool):
        try:
            _, (data, _) = self.store.popitem(last=last)
            self.total_bytes -= len(data)
        except KeyError: pass

    def clear(self):
        """Limpa todo o cache."""
        with self.lock:
            self.store.clear()
            self.total_bytes = 0

class IPTVHLSProxyManager:
    def __init__(self):
        self.cache = RotatingCache()
        self.active_port = None
        self.server = None
        self.server_thread = None
        self.lock = threading.Lock()
        self.session_user_agent = "VLC/3.0.20 (Linux)" # Agente de usuário fixo
        self.app = self._create_flask_app()

    def force_reconnect(self, reason: str = "Unknown"):
        with self.lock:
            logging.info(f"Forçando RECONEXÃO ({reason}). Descartando sessão antiga e cache.")
            self.cache.clear()

    def _create_flask_app(self):
        app = Flask("IPTVHLSProxy")
        
        @app.route("/", methods=["GET"])
        def proxy():
            url = request.args.get("url")
            original_url = request.args.get("original_url")
            
            if not url: return Response("Missing 'url' parameter", 400)
            
            decoded_url = urllib.parse.unquote_plus(url)
            if original_url:
                decoded_original_url = urllib.parse.unquote_plus(original_url)
            else:
                decoded_original_url = decoded_url
            
            if decoded_url.endswith((".m3u8", ".m3u")):
                return self.handle_manifest(decoded_url, decoded_original_url)
            else:
                return self.handle_segment_stream(decoded_url, decoded_original_url)
        return app

    def _create_session(self):
        """Cria e configura uma nova sessão de requests com retentativas."""
        session = requests.Session()
        retry_strategy = Retry(
            total=MAX_SEGMENT_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[401, 403, 404, 429, 500, 502, 503, 504, 520, 521, 522],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def _make_request(self, url: str, method: str = "GET", original_url: Optional[str] = None, headers=None, **kwargs):
        """Método unificado para fazer requisições HTTP usando uma nova sessão para cada chamada."""
        session = self._create_session()
        
        # --- Lógica de redirecionamento manual para corrigir o Host header ---
        # Evita redirecionamento automático
        kwargs['allow_redirects'] = False
        
        try:
            r = session.request(method, url, headers=get_headers(url, original_url, extra=headers), **kwargs)

            # Se for um redirecionamento, faz uma nova requisição para a URL de destino
            if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get('Location')
                if location:
                    # Resolve o novo URL, que pode ser relativo
                    new_url = urllib.parse.urljoin(url, location)
                    logging.info(f"Redirecionamento interceptado: {url} -> {new_url}")
                    r.close()
                    # Chama a função recursivamente com a nova URL
                    return self._make_request(new_url, method, original_url, headers, **kwargs)

            return r
        except requests.exceptions.RequestException as e:
            raise e
        finally:
            session.close()

    def handle_manifest(self, url: str, original_url: str) -> Response:
        cached = self.cache.get(url)
        if cached:
            logging.info(f"Manifesto de {url} servido do cache.")
            return Response(cached, mimetype="application/vnd.apple.mpegurl")
        
        try:
            r = self._make_request(url, method="GET", timeout=CONNECTION_TIMEOUT, original_url=original_url)
            r.raise_for_status()
            content = r.text
            final_url = r.url
        except requests.exceptions.RequestException as e:
            logging.error(f"Erro ao carregar manifesto {url}: {e}")
            self.force_reconnect(reason=f"Falha manifesto principal")
            return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")
        
        try:
            proxy_base_url = f"http://{PROXY_HOST}:{self.active_port}/?url="
            original_url_param = f"&original_url={urllib.parse.quote_plus(original_url)}"
            
            m3u8_obj = m3u8.loads(content, uri=final_url)
            is_live = not m3u8_obj.is_endlist
            
            if m3u8_obj.is_variant:
                for playlist in m3u8_obj.playlists:
                    playlist.uri = proxy_base_url + urllib.parse.quote_plus(playlist.absolute_uri) + original_url_param
            
            for segment in m3u8_obj.segments:
                segment.uri = proxy_base_url + urllib.parse.quote_plus(segment.absolute_uri) + original_url_param
                if segment.key and segment.key.uri:
                    segment.key.uri = proxy_base_url + urllib.parse.quote_plus(segment.key.absolute_uri) + original_url_param

            proxied_playlist = m3u8_obj.dumps().encode("utf-8")
            ttl = 3 if is_live else 300
            self.cache.add(url, proxied_playlist, ttl)
            
            response = Response(proxied_playlist, mimetype="application/vnd.apple.mpegurl")
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
            return response
            
        except Exception as e:
            logging.error(f"Erro ao reescrever manifesto: {e}")
            return Response("#EXTM3U\n#EXT-X-ERROR: Playlist processing error\n", status=500, mimetype="application/vnd.apple.mpegurl")

    def handle_segment_stream(self, url: str, original_url: str) -> Response:
        def generate():
            try:
                r = self._make_request(url, method="GET", stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), original_url=original_url)
                r.raise_for_status()
                logging.info(f"Stream do segmento {url.split('/')[-1]} iniciado com sucesso.")
                
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk: yield chunk
                r.close()
            except requests.exceptions.RequestException as e:
                logging.error(f"Falha CRÍTICA ao buscar segmento {url}: {e}")
                self.force_reconnect(reason=f"Falha persistente de segmento")

        return Response(stream_with_context(generate()), mimetype=safe_mime_type(url), status=200)

    def start(self) -> Optional[int]:
        self.stop()
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                self.active_port = port
                logging.info(f"Proxy PROATIVO iniciado em http://{PROXY_HOST}:{port}")
                return port
            except OSError: continue
        logging.error("Falha ao iniciar proxy: nenhuma porta disponível.")
        return None

    def stop(self):
        if self.server:
            try: self.server.shutdown()
            except Exception: pass
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=1)
        self.server = None
        self.server_thread = None
        self.active_port = None

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url: str, title: Optional[str] = None):
        self.proxy.stop()
        self.proxy.cache.clear()
        
        if not self.proxy.start():
            import xbmcgui
            import xbmcplugin
            xbmcgui.Dialog().ok("Erro Proxy IPTV", "Não foi possível iniciar o servidor proxy.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&original_url={urllib.parse.quote_plus(url)}"
        import xbmcgui
        import xbmcplugin
        li = xbmcgui.ListItem(path=proxy_url, label=title or "GIF PEG TV PLUS")
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setProperty("IsLive", "true")
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)
        logging.info(f"Reprodução iniciada com URL do proxy para o PLAYER PADRÃO: {proxy_url}")

    def show_test_streams(self):
        import xbmcgui
        import xbmcplugin
        test_streams = [
            ("Big Buck Bunny", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Elephants Dream", "https://d3u2k51g8x1l3w.cloudfront.net/a/master_elephantsdream.m3u8")
        ]
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=name)
            li.setProperty("IsPlayable", "true")
            plugin_url = f"plugin://{sys.argv[0]}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, li, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    setup_logging()
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        addon = HLSProxyAddon(handle)
        action = params.get("action")
        if action == "play_stream":
            url = params.get("url")
            title = params.get("title", "GIF PEG TV PLUS")
            if url: addon.play_stream(url, title)
            else: addon.show_test_streams()
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.critical(f"Fatal error: {e}", exc_info=True)

if __name__ == "__main__":
    main()