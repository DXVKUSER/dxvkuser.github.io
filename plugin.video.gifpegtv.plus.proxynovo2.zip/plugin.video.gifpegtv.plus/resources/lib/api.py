# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
from doh_client import requests

# Adicionar imports necessários para o cache
import os
import json
import time
import xbmcaddon
import xbmcvfs
import hashlib # Para criar chaves de cache únicas

# Configuração do cache
CACHE_TTL = 3600  # Tempo de vida do cache em segundos (1 hora)

class XtreamAPI:
    def __init__(self, server, username, password):
        self.base_url = f"{server}"
        self.username = username
        self.password = password
        self.session = requests.session
        self.session.headers.update({'User-Agent': 'Mozilla/5.0'})
        
        # Inicialização do Addon e diretório de cache
        self.addon = xbmcaddon.Addon()
        profile_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        self.cache_dir = os.path.join(profile_dir, 'cache')
        # Cria o diretório de cache se não existir
        if not xbmcvfs.exists(self.cache_dir):
            xbmcvfs.mkdir(self.cache_dir)

    def _get_cache_path(self, params):
        """Gera um caminho de arquivo de cache único baseado nos parâmetros da requisição."""
        # Criar uma chave única a partir dos parâmetros de API
        # A ordem das chaves no dicionário 'params' pode variar, então ordenamos antes de serializar
        sorted_params = sorted(params.items())
        cache_key = hashlib.sha1(str(sorted_params).encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, f"{cache_key}.json")

    def _get_cache(self, params):
        """Tenta obter dados do cache. Retorna os dados ou None."""
        cache_path = self._get_cache_path(params)
        if xbmcvfs.exists(cache_path):
            try:
                # O xbmcvfs.File() precisa ser usado para ler o conteúdo
                file_handle = xbmcvfs.File(cache_path, 'r')
                data_str = file_handle.read()
                file_handle.close()
                
                cached_data = json.loads(data_str)
                timestamp = cached_data.get('timestamp', 0)
                
                # Verifica se o cache expirou
                if time.time() < timestamp + CACHE_TTL:
                    xbmc.log(f"[XtreamAPI] Cache hit for {params.get('action')}", level=xbmc.LOGINFO)
                    return cached_data.get('data')
                else:
                    xbmc.log(f"[XtreamAPI] Cache expired for {params.get('action')}", level=xbmc.LOGINFO)
                    # Limpar cache expirado
                    xbmcvfs.delete(cache_path)
            except Exception as e:
                xbmc.log(f"[XtreamAPI] Erro ao ler/deserializar cache: {e}", level=xbmc.LOGERROR)
                # O arquivo de cache pode estar corrompido, deleta para forçar nova requisição
                if xbmcvfs.exists(cache_path):
                    xbmcvfs.delete(cache_path)
        return None

    def _set_cache(self, params, data):
        """Salva os dados da requisição no cache."""
        cache_path = self._get_cache_path(params)
        
        cache_data = {
            'timestamp': int(time.time()),
            'data': data
        }
        
        try:
            # Serializa e escreve no arquivo
            data_str = json.dumps(cache_data, ensure_ascii=False)
            file_handle = xbmcvfs.File(cache_path, 'w')
            file_handle.write(data_str)
            file_handle.close()
            xbmc.log(f"[XtreamAPI] Cache set for {params.get('action')}", level=xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[XtreamAPI] Erro ao escrever no cache: {e}", level=xbmc.LOGERROR)

    def _make_request(self, params):
        params['username'] = self.username
        params['password'] = self.password
        
        # 1. Tentar obter do cache antes de fazer a requisição HTTP
        cached_data = self._get_cache(params)
        if cached_data is not None:
            return cached_data
            
        # 2. Se não houver cache válido, fazer a requisição HTTP
        try:
            response = self.session.get(f"{self.base_url}/player_api.php", params=params, timeout=15)
            
            if response.status_code == 429:
                xbmc.log(f"[XtreamProxy] Erro de API: Too Many Requests (429) - Servidor Rate Limited.", level=xbmc.LOGERROR)
                xbmcgui.Dialog().ok("Erro de Conexão", "Muitas requisições (429). Tente novamente mais tarde.")
                return None
            
            response.raise_for_status() # Lança exceção para 4xx/5xx que não seja 429 (já tratado)
                
            if response.text.strip() == "[]":
                data = []
            else:
                data = response.json()
                
            if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
                xbmcgui.Dialog().ok("Erro de Autenticação", "Usuário ou senha inválidos.")
                return None
                
            # 3. Se a requisição for bem-sucedida e não for um erro de autenticação, salvar no cache
            self._set_cache(params, data)
                
            return data
            
        except requests.exceptions.RequestException as e:
            # Captura erros de requisição (conexão, timeout, raise_for_status para 4xx/5xx)
            xbmc.log(f"[XtreamProxy] Erro de API: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Conexão", f"Não foi possível conectar ao servidor: {e}")
            return None
        except ValueError:
            xbmc.log(f"[XtreamProxy] Erro de API: Resposta não é JSON válido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de API", "O servidor retornou uma resposta inválida.")
            return None

    def get_live_categories(self):
        return self._make_request({'action': 'get_live_categories'})

    def get_live_streams(self, category_id=None):
        params = {'action': 'get_live_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_vod_categories(self):
        return self._make_request({'action': 'get_vod_categories'})

    def get_vod_streams(self, category_id=None):
        params = {'action': 'get_vod_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_categories(self):
        return self._make_request({'action': 'get_series_categories'})

    def get_series(self, category_id=None):
        params = {'action': 'get_series'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_info(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_series_streams(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_live_stream_url(self, stream_id):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.m3u8"

    def get_vod_stream_url(self, stream_id):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.mp4"

    def get_series_stream_url(self, series_id, stream_id, container):
        return f"{self.base_url}/series/{self.username}/{self.password}/{series_id}.{container}"

    def get_epg_url(self):
        return f"{self.base_url}/xmltv.php?username={self.username}&password={self.password}"