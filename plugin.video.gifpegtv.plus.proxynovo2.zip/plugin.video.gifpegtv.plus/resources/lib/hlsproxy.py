# -*- coding: utf-8 -*-
# hlsproxy.py - PROXY HLS IMORTAL 2025 - NUNCA TRAVA, NUNCA FECHA, SEMPRE 200 OK
# COMPATÍVEL COM: Kodi 19, 20, 21 (Omega), Android 9-14, Fire TV, TV Box

import urllib.request
import urllib.parse
import urllib.error
import socket
import socketserver
import threading
import http.server
import sys
import time
import json
import ssl

# Kodi
import xbmcplugin
import xbmcgui

# ==================== CONFIGURAÇÕES GLOBAIS ====================
PROXY_PORT = 8585
PROXY_BASE_URL = f"http://127.0.0.1:{PROXY_PORT}/"
USER_AGENT = "Mozilla/5.0 (Android 14; Mobile; rv:132.0) Gecko/132.0 Firefox/132.0"
CLOUDFLARE_DOH = "https://cloudflare-dns.com/dns-query"
DNS_CACHE = {}

# ==================== RESOLVEDOR DoH CLOUDFLARE ====================
def resolve_doh(domain):
    if domain in DNS_CACHE:
        return DNS_CACHE[domain]
    try:
        headers = {'accept': 'application/dns-json', 'user-agent': USER_AGENT}
        url = f"{CLOUDFLARE_DOH}?name={domain}&type=A"
        req = urllib.request.Request(url, headers=headers)
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, context=ctx, timeout=8) as r:
            data = json.loads(r.read().decode())
            if data.get('Status') == 0 and data.get('Answer'):
                ip = data['Answer'][0]['data'].strip()
                DNS_CACHE[domain] = ip
                return ip
    except:
        pass
    return None

def get_real_ip(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.hostname and not parsed.hostname.replace('.', '').isdigit():
        ip = resolve_doh(parsed.hostname)
        if ip:
            return url.replace(parsed.hostname, ip, 1), ip
    return url, parsed.hostname or "unknown"

# ==================== SERVIDOR IMORTAL ====================
class ImmortalServer(socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True
    timeout = 3

    def __init__(self, server_address, RequestHandlerClass):
        socketserver.TCPServer.__init__(self, server_address, RequestHandlerClass, bind_and_activate=False)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.socket.bind(server_address)
            self.server_address = self.socket.getsockname()
            self.socket.listen(5)
            print(f"[HLSProxy] SERVIDOR ATIVO → {self.server_address}")
        except Exception as e:
            print(f"[HLSProxy] Porta ocupada, usando {server_address[1]+1}", file=sys.stderr)
            self.socket.bind(('127.0.0.1', server_address[1]+1))
            self.server_address = ('127.0.0.1', server_address[1]+1)

    def handle_error(self, request, client_address):
        pass

# ==================== HANDLER IMORTAL ====================
class ImmortalHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        try:
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            src = query.get('source', [None])[0]
            if not src:
                self._ok("#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-STREAM-INF:BANDWIDTH=1000000\nsegment.ts")
                return
            src = urllib.parse.unquote_plus(src)
            self.proxy_stream(src)
        except:
            self._ok("#EXTM3U\n#EXT-X-RETRY-IN:2\nsegment.ts")

    def _ok(self, content="", ctype="application/vnd.apple.mpegurl"):
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Cache-Control', 'no-cache, no-store')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Connection', 'keep-alive')
        self.end_headers()
        self.wfile.write(content.encode('utf-8') if isinstance(content, str) else content)

    def proxy_stream(self, url):
        real_url, host = get_real_ip(url)
        parsed = urllib.parse.urlparse(real_url)
        headers = {
            'User-Agent': USER_AGENT,
            'Host': parsed.hostname or host,
            'Referer': f"{parsed.scheme}://{parsed.netloc}/",
            'Origin': f"{parsed.scheme}://{parsed.netloc}",
            'Connection': 'keep-alive',
            'Accept-Encoding': 'identity',
        }

        try:
            req = urllib.request.Request(real_url, headers=headers)
            if 'Range' in self.headers:
                req.add_header('Range', self.headers['Range'])

            with urllib.request.urlopen(req, timeout=20) as resp:
                final_url = resp.url
                ct = resp.headers.get('Content-Type', '').lower()
                is_m3u8 = (url.lower().endswith('.m3u8') or 'mpegurl' in ct or 'm3u' in ct)

                self.send_response(200)
                if is_m3u8:
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Cache-Control', 'no-cache')
                else:
                    self.send_header('Content-Type', 'video/MP2T')
                    cl = resp.headers.get('Content-Length')
                    if cl: self.send_header('Content-Length', cl)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()

                if is_m3u8:
                    data = resp.read().decode('utf-8', errors='ignore')
                    base = final_url[:final_url.rfind('/') + 1]
                    lines = data.splitlines()
                    out = ["#EXTM3U", "#EXT-X-VERSION:7", "#EXT-X-TARGETDURATION:10", "#EXT-X-MEDIA-SEQUENCE:1"]
                    for line in lines:
                        line = line.strip()
                        if not line or line.startswith('#'):
                            out.append(line)
                            continue
                        seg = urllib.parse.urljoin(base, line) if not line.startswith('http') else line
                        enc = urllib.parse.quote_plus(seg)
                        out.append(f"/?source={enc}")
                    self.wfile.write('\n'.join(out).encode('utf-8'))
                else:
                    while True:
                        chunk = resp.read(131072)
                        if not chunk: break
                        self.wfile.write(chunk)
                        try: self.wfile.flush()
                        except: break
        except urllib.error.HTTPError as e:
            self._ok("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000\nsegment.ts")
        except:
            self._ok("#EXTM3U\n#EXT-X-RETRY-IN:3\nsegment.ts")

    def log_message(self, *args):
        pass

# ==================== CLASSE PRINCIPAL - HLSAddon ====================
class HLSAddon:
    def __init__(self):
        self.port = PROXY_PORT
        self.server = None
        self.thread = None
        self.running = False
        try:
            self.handle = int(sys.argv[1])
        except:
            self.handle = -1
        print("[HLSProxy] Iniciando proxy imortal...")

    def start(self):
        if self.running:
            return True
        try:
            self.server = ImmortalServer(('127.0.0.1', self.port), ImmortalHandler)
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
            time.sleep(1.8)
            self.running = True
            global PROXY_BASE_URL
            PROXY_BASE_URL = f"http://127.0.0.1:{self.server.server_address[1]}/"
            print(f"[HLSProxy] PROXY IMORTAL ATIVO → {PROXY_BASE_URL}")
            return True
        except:
            self.port += 1
            return self.start()

    def play_stream(self, url):
        if not self.start():
            item = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(self.handle, False, item)
            return

        proxy_url = f"{PROXY_BASE_URL}?source={urllib.parse.quote_plus(url)}"

        item = xbmcgui.ListItem(path=proxy_url)
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        item.setProperty('inputstream.adaptive.stream_headers', f'User-Agent={USER_AGENT}')
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)

        xbmcplugin.setResolvedUrl(self.handle, True, item)
        print(f"[HLSProxy] Canal aberto → {url[:70]}...")

    def stop(self):
        if self.server and self.running:
            try:
                self.server.shutdown()
                self.server.server_close()
            except:
                pass

# ==================== EXPORTAÇÃO CORRETA PARA IMPORT ====================
__all__ = ['HLSAddon']

# ==================== USO NO SEU ADDON ====================
# from hlsproxy import HLSAddon
# proxy = HLSAddon()
# proxy.play_stream("http://dominio.com:80/canal/123.m3u8")