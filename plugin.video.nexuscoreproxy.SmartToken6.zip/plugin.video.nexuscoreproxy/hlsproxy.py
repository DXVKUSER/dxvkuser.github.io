#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — NEXUS CORE HLS Proxy Engine
Autor:Deivid Silva
"""

import sys
import os
import re
import socket
import ssl
import json
import time
import random
import threading
import queue
import hashlib
import collections
import urllib.request
import urllib.error
import urllib.parse
import http.client
import http.server
import http.cookiejar
import socketserver
import base64
from urllib.parse import urlparse, urljoin, quote

# ════════════════════════════════════════════════════════════
# LOGGING E CONFIGURAÇÕES GERAIS
# ════════════════════════════════════════════════════════════

_DEBUG_MODE = False  # Alterar para True para logs verbosos de depuração

def _log(msg, level='info'):
    if level == 'debug' and not _DEBUG_MODE:
        return
    try:
        import xbmc
        levels = {
            'info':    xbmc.LOGINFO,
            'error':   xbmc.LOGERROR,
            'warning': xbmc.LOGWARNING,
            'debug':   xbmc.LOGDEBUG,
        }
        xbmc.log(f'[NexusCore-HLS] {msg}', levels.get(level, xbmc.LOGINFO))
    except ImportError:
        print(f'[NexusCore-HLS] [{level}] {msg}')

# Constantes de Otimização
CHUNK_SIZE_MIN = 16384       # 16 KB — origem lenta
CHUNK_SIZE_DEFAULT = 131072  # 128 KB
CHUNK_SIZE_MAX = 524288      # 512 KB — origem rápida
MAX_CONCURRENT_ORIGINS = 12  # Limita explosão de threads contra a origem
MAX_PARALLEL_PER_ORIGIN = 3  # Downloads paralelos controlados por origem
RING_MIN_SEGMENTS = 2
RING_MAX_SEGMENTS = 6
RING_TARGET_LOW = 2
RING_TARGET_HIGH = 4
PREFETCH_BASE = 2
AES_KEY_TTL = 300
PLAYLIST_CACHE_TTL = 12   # live: cache curto evita segmentos expirados
SEGMENT_CACHE_TTL = 30
MAX_ORIGIN_STATS = 64
MAX_CONN_POOL = 12
_TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
_TS_NULL_BURST = _TS_NULL_PACKET * 8  # ~1.5 KB filler para stall recovery

# ── Validação de manifesto / resposta rápida (novo) ──────────
PLAYLIST_ROUNDS = 3          # era 6 — falha rápido, cache/placeholder cobre o resto
PLAYLIST_ROUND_TIMEOUT_BUDGET = 3.0   # teto total (s) gasto tentando a origem antes do fallback
PLAYLIST_FIRST_ATTEMPT_MAX_WAIT = 3.0  # teto duro da 1ª tentativa mesmo sem stats de RTT ainda
MIN_VALID_PLAYLIST_BYTES = 20         # abaixo disso, corpo é lixo/erro mascarado
MAX_TRUSTED_STALE_PLAYLIST_AGE = 20.0  # cache "bom" só é confiável por até N segundos
SEGMENT_FIRST_BYTE_MAX_WAIT = 8.0     # teto duro p/ 1ª tentativa de segmento não travar o player

# ════════════════════════════════════════════════════════════
# BASE64 URL-SAFE ENCODE/DECODE — Path Parameters (Patch Linux)
# ════════════════════════════════════════════════════════════

def _b64_encode_url(url):
    """Codifica URL em Base64 URL-safe (sem '=', '+' trocado por '-', '/' por '_').
    Resultado contém apenas [A-Za-z0-9_-], seguro para uso em path de URL.
    Sufixo .m3u8/.ts/.key é adicionado pelo caller conforme o endpoint.
    """
    if not url:
        return ''
    raw = url.encode('utf-8')
    b64 = base64.urlsafe_b64encode(raw).decode('ascii')
    return b64.rstrip('=')


def _b64_decode_url(token):
    """Decodifica token Base64 URL-safe de volta para a URL original.
    Tolerante a padding ausente e a caracteres legacy (+/)."""
    if not token:
        return None
    try:
        s = token.replace('-', '+').replace('_', '/')
        pad = (-len(s)) % 4
        if pad:
            s += '=' * pad
        raw = base64.b64decode(s)
        return raw.decode('utf-8')
    except Exception:
        return None


def _extract_b64_token(path, suffix):
    """Extrai o token Base64 de um path como '/playlist/<TOKEN>.m3u8'.
    Retorna o token limpo ou None se não casar."""
    if not path or not suffix:
        return None
    # path tipo /playlist/AAAA.m3u8 — pega última componente
    parts = path.split('/')
    if len(parts) < 2:
        return None
    last = parts[-1]
    if not last.endswith(suffix):
        return None
    token = last[:-len(suffix)]
    if not token:
        return None
    return token


# ════════════════════════════════════════════════════════════
# DOH RESOLVER COM CACHE ADAPTATIVO E BACKGROUND REFRESH
# ════════════════════════════════════════════════════════════

_RE_IPV4 = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
_RE_IPV6 = re.compile(r'^[0-9a-fA-F:]+$')

_DNS_CACHE      = {}
_DNS_CACHE_LOCK = threading.Lock()

_in_doh_resolution = threading.local()

DOH_SERVERS = [
    'https://dns.google/resolve',
    'https://cloudflare-dns.com/dns-query',
]

_orig_getaddrinfo = socket.getaddrinfo

def _is_ip(host):
    if not host:
        return False
    host = host.strip('[]')
    if _RE_IPV4.match(host):
        try:
            return all(0 <= int(p) <= 255 for p in host.split('.'))
        except Exception:
            return False
    if ':' in host and _RE_IPV6.match(host):
        return True
    return False

def _doh_resolve(hostname, timeout=5):
    if _is_ip(hostname):
        return hostname

    now = time.time()
    with _DNS_CACHE_LOCK:
        cached = _DNS_CACHE.get(hostname)
        if cached and now - cached[1] < cached[2]:
            return cached[0]

    for doh_url in DOH_SERVERS:
        try:
            req_url = f'{doh_url}?name={quote(hostname)}&type=A'
            req = urllib.request.Request(req_url, headers={
                'Accept': 'application/dns-json',
                'User-Agent': 'NEXUS-CORE-DoH/1.0',
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if 'Answer' in data:
                    for ans in data['Answer']:
                        if ans.get('type') == 1:
                            ip = ans.get('data')
                            if ip and _is_ip(ip):
                                ttl = ans.get('TTL', 300)
                                with _DNS_CACHE_LOCK:
                                    _DNS_CACHE[hostname] = (ip, now, min(ttl, 3600))
                                _log(f'DoH: {hostname} → {ip} (TTL:{ttl}s)')
                                return ip
        except Exception as e:
            _log(f'DoH falhou ({doh_url}): {e}', 'warning')
            continue

    try:
        results = _orig_getaddrinfo(hostname, None)
        if results:
            ip = results[0][4][0]
            with _DNS_CACHE_LOCK:
                _DNS_CACHE[hostname] = (ip, now, 60)
            return ip
    except Exception:
        pass
    return hostname

def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if getattr(_in_doh_resolution, 'active', False):
        return _orig_getaddrinfo(host, port, family, type, proto, flags)
    if host and not _is_ip(host):
        try:
            _in_doh_resolution.active = True
            ip = _doh_resolve(host)
            if ip and _is_ip(ip):
                host = ip
        except Exception:
            pass
        finally:
            _in_doh_resolution.active = False
    return _orig_getaddrinfo(host, port, family, type, proto, flags)

socket.getaddrinfo = _patched_getaddrinfo

def _dns_bg_refresh_loop():
    """Thread em segundo plano para manter o cache DNS quente sem bloquear playback."""
    while True:
        time.sleep(60)
        try:
            with _DNS_CACHE_LOCK:
                hosts = list(_DNS_CACHE.keys())
            for h in hosts:
                _doh_resolve(h)
        except Exception:
            pass

# ════════════════════════════════════════════════════════════
# SSL CONTEXT, COOKIE JAR
# ════════════════════════════════════════════════════════════

_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode = ssl.CERT_NONE

_global_cookie_jar = http.cookiejar.CookieJar()
_cookie_processor = urllib.request.HTTPCookieProcessor(_global_cookie_jar)

_UA_FALLBACK = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
_UA_POOL = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
    'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'AppleCoreMedia/1.0.0.20E252 (Apple TV; U; CPU OS 16_5 like Mac OS X; en_us)',
    'VLC/3.0.20 LibVLC/3.0.20',
]
_ua_lock = threading.Lock()
_ua_last_index = -1

def _rotate_user_agent():
    global _ua_last_index
    with _ua_lock:
        idx = random.randrange(len(_UA_POOL))
        while idx == _ua_last_index and len(_UA_POOL) > 1:
            idx = random.randrange(len(_UA_POOL))
        _ua_last_index = idx
        return _UA_POOL[idx]

# ════════════════════════════════════════════════════════════
# MELHORIA 9 — ESTATÍSTICAS DA ORIGEM
# ════════════════════════════════════════════════════════════

class OriginStats:
    """Estatísticas por host para alimentar algoritmos adaptativos."""
    __slots__ = (
        'host', 'rtt_samples', 'speed_samples', 'failures', 'timeouts',
        'reconnections', 'bytes_total', 'last_activity', 'last_error',
        'lock', 'created'
    )

    def __init__(self, host):
        self.host = host
        self.rtt_samples = collections.deque(maxlen=32)
        self.speed_samples = collections.deque(maxlen=32)
        self.failures = 0
        self.timeouts = 0
        self.reconnections = 0
        self.bytes_total = 0
        self.last_activity = time.time()
        self.last_error = None
        self.lock = threading.Lock()
        self.created = time.time()

    def record_rtt(self, rtt):
        with self.lock:
            if rtt > 0:
                self.rtt_samples.append(rtt)
            self.last_activity = time.time()

    def record_speed(self, bytes_n, elapsed):
        with self.lock:
            if elapsed > 0.001 and bytes_n > 0:
                self.speed_samples.append(bytes_n / elapsed)
                self.bytes_total += bytes_n
            self.last_activity = time.time()

    def record_failure(self, err=None, is_timeout=False):
        with self.lock:
            self.failures += 1
            if is_timeout:
                self.timeouts += 1
            self.last_error = str(err) if err else None
            self.last_activity = time.time()

    def record_reconnect(self):
        with self.lock:
            self.reconnections += 1
            self.last_activity = time.time()

    @property
    def rtt_avg(self):
        with self.lock:
            if not self.rtt_samples:
                return 0.15
            return sum(self.rtt_samples) / len(self.rtt_samples)

    @property
    def rtt_min(self):
        with self.lock:
            return min(self.rtt_samples) if self.rtt_samples else 0.05

    @property
    def rtt_max(self):
        with self.lock:
            return max(self.rtt_samples) if self.rtt_samples else 1.0

    @property
    def speed_avg(self):
        with self.lock:
            if not self.speed_samples:
                return 256000.0  # 256 KB/s default
            return sum(self.speed_samples) / len(self.speed_samples)

    @property
    def speed_instant(self):
        with self.lock:
            return self.speed_samples[-1] if self.speed_samples else 256000.0

    def adaptive_timeout(self, target_duration=6.0):
        rtt = self.rtt_avg
        speed = max(self.speed_avg, 1.0)
        est_seg_time = max(0.5, (512000.0 / speed))
        base = (2.0 * rtt) + est_seg_time + (target_duration * 0.35)
        fail_factor = 1.0 + min(self.failures * 0.08, 1.5)
        timeout = max(3.0, min(base * fail_factor, 45.0))
        return timeout

    def adaptive_chunk(self):
        speed = self.speed_avg
        if speed > 2_000_000:
            return CHUNK_SIZE_MAX
        if speed > 800_000:
            return CHUNK_SIZE_DEFAULT
        if speed > 200_000:
            return max(CHUNK_SIZE_MIN * 2, 65536)
        return CHUNK_SIZE_MIN

    def degradation_score(self):
        with self.lock:
            if not self.rtt_samples or len(self.rtt_samples) < 3:
                return 0.0
            rtt_avg = sum(self.rtt_samples) / len(self.rtt_samples)
            rtt_recent = sum(list(self.rtt_samples)[-3:]) / 3.0
            rtt_ratio = rtt_recent / max(rtt_avg, 0.01)
            speed_drop = 0.0
            if len(self.speed_samples) >= 4:
                older = sum(list(self.speed_samples)[:-2]) / max(len(self.speed_samples) - 2, 1)
                recent = sum(list(self.speed_samples)[-2:]) / 2.0
                if older > 0:
                    speed_drop = max(0.0, 1.0 - (recent / older))
            fail_penalty = min(self.failures * 0.05, 0.4)
            score = min(1.0, max(0.0, (rtt_ratio - 1.0) * 0.4 + speed_drop * 0.4 + fail_penalty))
            return score


_ORIGIN_STATS = {}
_ORIGIN_STATS_LOCK = threading.Lock()

def _get_origin_stats(host):
    if not host:
        host = 'unknown'
    with _ORIGIN_STATS_LOCK:
        s = _ORIGIN_STATS.get(host)
        if s is None:
            if len(_ORIGIN_STATS) >= MAX_ORIGIN_STATS:
                oldest = min(_ORIGIN_STATS.items(), key=lambda x: x[1].last_activity)
                del _ORIGIN_STATS[oldest[0]]
            s = OriginStats(host)
            _ORIGIN_STATS[host] = s
        return s

# ════════════════════════════════════════════════════════════
# MELHORIA 1 — PIPELINE PERSISTENTE DE STREAMING (ConnectionState)
# ════════════════════════════════════════════════════════════

class ConnectionState:
    IDLE = 'Idle'
    CONNECTING = 'Connecting'
    STREAMING = 'Streaming'
    RECOVERING = 'Recovering'
    DEAD = 'Dead'

    __slots__ = (
        'host', 'port', 'is_https', 'conn', 'state', 'last_activity',
        'last_rtt', 'bytes_transferred', 'last_error', 'last_reconnect',
        'born', 'lock', 'in_use'
    )

    def __init__(self, host, port, is_https):
        self.host = host
        self.port = port
        self.is_https = is_https
        self.conn = None
        self.state = self.IDLE
        self.last_activity = 0.0
        self.last_rtt = 0.0
        self.bytes_transferred = 0
        self.last_error = None
        self.last_reconnect = 0.0
        self.born = time.time()
        self.lock = threading.Lock()
        self.in_use = False

    @property
    def age(self):
        return time.time() - self.born

    def is_healthy(self):
        with self.lock:
            if self.state in (self.DEAD, self.RECOVERING):
                return False
            if self.conn is None:
                return False
            if self.state == self.IDLE and (time.time() - self.last_activity) > 55:
                return False
            return True

    def mark_dead(self, err=None):
        with self.lock:
            self.state = self.DEAD
            self.last_error = str(err) if err else self.last_error
            c = self.conn
            self.conn = None
            self.in_use = False
        if c:
            try:
                c.close()
            except Exception:
                pass

    def mark_idle(self):
        with self.lock:
            if self.state != self.DEAD:
                self.state = self.IDLE
                self.last_activity = time.time()
                self.in_use = False

    def mark_streaming(self):
        with self.lock:
            self.state = self.STREAMING
            self.last_activity = time.time()
            self.in_use = True


class OriginPipeline:
    def __init__(self, host, port, is_https):
        self.host = host
        self.port = port
        self.is_https = is_https
        self.states = []
        self.lock = threading.Lock()
        self.semaphore = threading.Semaphore(MAX_PARALLEL_PER_ORIGIN)
        self.stats = _get_origin_stats(host)

    def _create_conn(self):
        t0 = time.time()
        try:
            if self.is_https:
                conn = http.client.HTTPSConnection(
                    self.host, self.port, context=_ssl_ctx, timeout=15
                )
            else:
                conn = http.client.HTTPConnection(self.host, self.port, timeout=15)
            try:
                conn.connect()
            except Exception:
                pass
            rtt = time.time() - t0
            self.stats.record_rtt(rtt)
            st = ConnectionState(self.host, self.port, self.is_https)
            st.conn = conn
            st.state = ConnectionState.IDLE
            st.last_activity = time.time()
            st.last_rtt = rtt
            st.born = time.time()
            return st
        except Exception as e:
            self.stats.record_failure(e)
            raise

    def acquire(self, prefer_fresh=False):
        self.semaphore.acquire()
        with self.lock:
            candidates = [s for s in self.states if s.is_healthy() and not s.in_use]
            if candidates and not prefer_fresh:
                st = candidates[0]
                st.mark_streaming()
                return st

            self.states = [s for s in self.states if s.state != ConnectionState.DEAD]

            if len(self.states) < MAX_PARALLEL_PER_ORIGIN or prefer_fresh:
                try:
                    st = self._create_conn()
                    st.mark_streaming()
                    self.states.append(st)
                    self.stats.record_reconnect()
                    return st
                except Exception as e:
                    self.semaphore.release()
                    raise

            if self.states:
                st = min(self.states, key=lambda x: x.last_activity)
                if st.conn is None:
                    try:
                        st.conn = self._create_conn().conn
                        st.state = ConnectionState.IDLE
                        st.born = time.time()
                    except Exception:
                        self.semaphore.release()
                        raise
                st.mark_streaming()
                return st

        self.semaphore.release()
        raise Exception(f'OriginPipeline acquire failed for {self.host}')

    def release(self, st, success=True, bytes_n=0, elapsed=0.0, err=None):
        if st is None:
            self.semaphore.release()
            return
        if bytes_n > 0 and elapsed > 0:
            self.stats.record_speed(bytes_n, elapsed)
            st.bytes_transferred += bytes_n
        if not success:
            st.mark_dead(err)
            self.stats.record_failure(err, is_timeout=isinstance(err, socket.timeout))
        else:
            st.mark_idle()
        self.semaphore.release()

    def predictive_parallel(self):
        if self.stats.degradation_score() < 0.45:
            return None
        try:
            with self.lock:
                if len(self.states) >= MAX_PARALLEL_PER_ORIGIN:
                    return None
            st = self._create_conn()
            with self.lock:
                self.states.append(st)
            _log(f'Predictive reconnect prepared for {self.host}', 'debug')
            return st
        except Exception:
            return None

    def seamless_switch(self, old_st, new_st):
        if new_st is None:
            return old_st
        with self.lock:
            if old_st in self.states:
                old_st.mark_dead('seamless_switch')
            new_st.mark_streaming()
            if new_st not in self.states:
                self.states.append(new_st)
        return new_st


_PIPELINES = {}
_PIPELINES_LOCK = threading.Lock()
_GLOBAL_ORIGIN_SEM = threading.Semaphore(MAX_CONCURRENT_ORIGINS)

def _get_pipeline(host, port, is_https):
    key = (host, port, is_https)
    with _PIPELINES_LOCK:
        p = _PIPELINES.get(key)
        if p is None:
            p = OriginPipeline(host, port, is_https)
            _PIPELINES[key] = p
        return p

# ════════════════════════════════════════════════════════════
# MELHORIA 2 — BUFFER CIRCULAR INTELIGENTE (Ring Buffer)
# ════════════════════════════════════════════════════════════

class SegmentSlot:
    __slots__ = (
        'url', 'sequence', 'timestamp', 'content', 'size', 'crc',
        'state', 'consumed', 'duration'
    )

    READY = 'Ready'
    DOWNLOADING = 'Downloading'
    FAILED = 'Failed'
    CONSUMED = 'Consumed'
    EMPTY = 'Empty'

    def __init__(self):
        self.url = None
        self.sequence = -1
        self.timestamp = 0.0
        self.content = None
        self.size = 0
        self.crc = 0
        self.state = self.EMPTY
        self.consumed = False
        self.duration = 0.0

    def reset(self):
        self.url = None
        self.sequence = -1
        self.timestamp = 0.0
        self.content = None
        self.size = 0
        self.crc = 0
        self.state = self.EMPTY
        self.consumed = False
        self.duration = 0.0

    def set_content(self, data, url, sequence, duration=0.0):
        self.content = data
        self.size = len(data) if data else 0
        self.crc = hashlib.crc32(data) & 0xffffffff if data else 0
        self.url = url
        self.sequence = sequence
        self.timestamp = time.time()
        self.duration = duration
        self.state = self.READY
        self.consumed = False


class SegmentRingBuffer:
    def __init__(self, capacity=RING_MAX_SEGMENTS):
        self.capacity = max(RING_MIN_SEGMENTS, min(capacity, RING_MAX_SEGMENTS))
        self.slots = [SegmentSlot() for _ in range(self.capacity)]
        self.head = 0
        self.tail = 0
        self.count = 0
        self.lock = threading.Lock()
        self.not_empty = threading.Condition(self.lock)
        self.not_full = threading.Condition(self.lock)
        self.total_bytes = 0
        self.max_bytes = 8 * 1024 * 1024

    def put(self, data, url, sequence, duration=0.0, block=True, timeout=5.0):
        with self.not_full:
            deadline = time.time() + timeout if timeout else None
            while self.count >= self.capacity or (self.total_bytes + len(data or b'')) > self.max_bytes:
                self._evict_consumed_unlocked()
                if self.count >= self.capacity:
                    if not block:
                        return False
                    remaining = (deadline - time.time()) if deadline else None
                    if remaining is not None and remaining <= 0:
                        return False
                    self.not_full.wait(timeout=remaining if remaining else 1.0)
                    continue
                break
            slot = self.slots[self.head]
            if slot.content:
                self.total_bytes -= slot.size
            slot.set_content(data, url, sequence, duration)
            self.total_bytes += slot.size
            self.head = (self.head + 1) % self.capacity
            self.count += 1
            self.not_empty.notify()
            return True

    def get_by_url(self, url, timeout=0.5):
        with self.not_empty:
            deadline = time.time() + timeout
            while True:
                for i in range(self.capacity):
                    idx = (self.tail + i) % self.capacity
                    slot = self.slots[idx]
                    if slot.state == SegmentSlot.READY and slot.url == url and not slot.consumed:
                        data = slot.content
                        slot.consumed = True
                        slot.state = SegmentSlot.CONSUMED
                        while self.count > 0 and self.slots[self.tail].state == SegmentSlot.CONSUMED:
                            old = self.slots[self.tail]
                            self.total_bytes -= old.size
                            old.reset()
                            self.tail = (self.tail + 1) % self.capacity
                            self.count -= 1
                        self.not_full.notify()
                        return data
                remaining = deadline - time.time()
                if remaining <= 0:
                    return None
                self.not_empty.wait(timeout=remaining)

    def peek_ready_count(self):
        with self.lock:
            return sum(1 for s in self.slots if s.state == SegmentSlot.READY and not s.consumed)

    def has_url(self, url):
        with self.lock:
            return any(
                s.state == SegmentSlot.READY and s.url == url and not s.consumed
                for s in self.slots
            )

    def _evict_consumed_unlocked(self):
        while self.count > 0 and self.slots[self.tail].state in (SegmentSlot.CONSUMED, SegmentSlot.FAILED, SegmentSlot.EMPTY):
            old = self.slots[self.tail]
            self.total_bytes -= old.size
            old.reset()
            self.tail = (self.tail + 1) % self.capacity
            self.count -= 1

    def cleanup(self):
        with self.lock:
            for s in self.slots:
                s.reset()
            self.head = self.tail = 0
            self.count = 0
            self.total_bytes = 0

# ════════════════════════════════════════════════════════════
# MELHORIA 14 — CACHE INTELIGENTE (TTL + LRU + limite)
# ════════════════════════════════════════════════════════════

class SmartCache:
    def __init__(self, max_items=48, ttl=SEGMENT_CACHE_TTL, max_bytes=6 * 1024 * 1024):
        self.max_items = max_items
        self.ttl = ttl
        self.max_bytes = max_bytes
        self._data = collections.OrderedDict()
        self._bytes = 0
        self.lock = threading.Lock()

    def get(self, key):
        with self.lock:
            item = self._data.get(key)
            if item is None:
                return None
            val, ts, size = item
            if time.time() - ts > self.ttl:
                del self._data[key]
                self._bytes -= size
                return None
            self._data.move_to_end(key)
            return val

    def put(self, key, value):
        size = len(value) if value else 0
        with self.lock:
            if key in self._data:
                _, _, old_sz = self._data[key]
                self._bytes -= old_sz
            self._data[key] = (value, time.time(), size)
            self._bytes += size
            self._data.move_to_end(key)
            while (len(self._data) > self.max_items or self._bytes > self.max_bytes) and self._data:
                k, (_, _, sz) = self._data.popitem(last=False)
                self._bytes -= sz

    def clear(self):
        with self.lock:
            self._data.clear()
            self._bytes = 0


_SEGMENT_CACHE = SmartCache(max_items=48, ttl=SEGMENT_CACHE_TTL)
_PLAYLIST_BODY_CACHE = SmartCache(max_items=32, ttl=PLAYLIST_CACHE_TTL, max_bytes=2 * 1024 * 1024)

# ════════════════════════════════════════════════════════════
# MELHORIA 17 — GERENCIADOR DE THREADS
# ════════════════════════════════════════════════════════════

class ThreadManager:
    def __init__(self, max_workers=8, name='NexusWorker'):
        self.max_workers = max_workers
        self.name = name
        self._q = queue.Queue(maxsize=64)
        self._workers = []
        self._alive = True
        self._lock = threading.Lock()
        for i in range(max_workers):
            t = threading.Thread(target=self._loop, name=f'{name}-{i}', daemon=True)
            t.start()
            self._workers.append(t)

    def _loop(self):
        while self._alive:
            try:
                job = self._q.get(timeout=2.0)
            except queue.Empty:
                continue
            if job is None:
                break
            fn, args, kwargs = job
            try:
                fn(*args, **kwargs)
            except Exception as e:
                _log(f'ThreadManager job error: {e}', 'warning')
            finally:
                self._q.task_done()

    def submit(self, fn, *args, **kwargs):
        try:
            self._q.put_nowait((fn, args, kwargs))
            return True
        except queue.Full:
            _log('ThreadManager queue full, dropping job', 'warning')
            return False

    def shutdown(self):
        self._alive = False
        for _ in self._workers:
            try:
                self._q.put_nowait(None)
            except Exception:
                pass


_THREAD_MGR = None
_THREAD_MGR_LOCK = threading.Lock()

def _get_thread_mgr():
    global _THREAD_MGR
    with _THREAD_MGR_LOCK:
        if _THREAD_MGR is None:
            _THREAD_MGR = ThreadManager(max_workers=8)
        return _THREAD_MGR

# ════════════════════════════════════════════════════════════
# SMART TOKEN RENEWAL E NEVER-FAIL POLICY
# ════════════════════════════════════════════════════════════

_PROXY_PORT = None
_PROXY_SERVER = None
_PROXY_LOCK = threading.Lock()

_TOKEN_EXPIRED_CODES = (401, 403, 410)
_ENTRY_URL_MAP = {}
_ENTRY_URL_MAP_LOCK = threading.Lock()

_LAST_GOOD_PLAYLIST = {}
_LAST_GOOD_PLAYLIST_LOCK = threading.Lock()
_AES_KEY_CACHE = {}
_AES_KEY_LOCK = threading.Lock()

_STREAM_SESSIONS = {}
_STREAM_SESSIONS_LOCK = threading.Lock()


class StreamSession:
    def __init__(self, entry_url):
        self.entry_url = entry_url
        self.ring = SegmentRingBuffer()
        self.media_sequence = 0
        self.target_duration = 6.0
        self.last_playlist_hash = None
        self.last_playlist_time = 0.0
        self.frozen_count = 0
        self.segment_urls = []
        self.prefetch_depth = PREFETCH_BASE
        self.lock = threading.Lock()
        self.last_byte_time = time.time()
        self.bytes_window = collections.deque(maxlen=20)
        self.alive = True

    def update_playlist_meta(self, media_seq, target_dur, seg_urls, body_hash):
        with self.lock:
            now = time.time()
            if body_hash == self.last_playlist_hash and media_seq == self.media_sequence:
                self.frozen_count += 1
            else:
                self.frozen_count = 0
            self.media_sequence = media_seq
            if target_dur > 0:
                self.target_duration = target_dur
            self.segment_urls = list(seg_urls)
            self.last_playlist_hash = body_hash
            self.last_playlist_time = now
            stats_host = urlparse(self.entry_url).hostname
            st = _get_origin_stats(stats_host) if stats_host else None
            if st:
                spd = st.speed_avg
                if spd > 1_500_000:
                    self.prefetch_depth = 4
                elif spd > 500_000:
                    self.prefetch_depth = 3
                else:
                    self.prefetch_depth = 2
            return self.frozen_count

    def record_bytes(self, n):
        now = time.time()
        with self.lock:
            self.last_byte_time = now
            self.bytes_window.append((now, n))

    def throughput_bps(self):
        with self.lock:
            if len(self.bytes_window) < 2:
                return 0.0
            t0, _ = self.bytes_window[0]
            t1 = self.bytes_window[-1][0]
            total = sum(b for _, b in self.bytes_window)
            dt = t1 - t0
            return total / dt if dt > 0.05 else 0.0

    def stall_seconds(self):
        with self.lock:
            return time.time() - self.last_byte_time


def _get_stream_session(entry_url):
    with _STREAM_SESSIONS_LOCK:
        s = _STREAM_SESSIONS.get(entry_url)
        if s is None:
            if len(_STREAM_SESSIONS) > 16:
                oldest_key = min(
                    _STREAM_SESSIONS.keys(),
                    key=lambda k: _STREAM_SESSIONS[k].last_playlist_time or 0
                )
                old = _STREAM_SESSIONS.pop(oldest_key, None)
                if old:
                    old.alive = False
                    old.ring.cleanup()
            s = StreamSession(entry_url)
            _STREAM_SESSIONS[entry_url] = s
        return s


def _remember_entry_url(resolved_url, entry_url):
    if resolved_url == entry_url:
        return
    with _ENTRY_URL_MAP_LOCK:
        if len(_ENTRY_URL_MAP) >= 256:
            try:
                _ENTRY_URL_MAP.pop(next(iter(_ENTRY_URL_MAP)))
            except Exception:
                pass
        _ENTRY_URL_MAP[resolved_url] = entry_url


def _lookup_entry_url(resolved_url, fallback):
    with _ENTRY_URL_MAP_LOCK:
        return _ENTRY_URL_MAP.get(resolved_url, fallback)


def _is_token_expired_error(exc):
    code = getattr(exc, 'code', None)
    return code in _TOKEN_EXPIRED_CODES


def _purge_session_state(hostname=None):
    try:
        if hostname:
            to_remove = [
                c for c in _global_cookie_jar
                if c.domain and hostname.endswith(c.domain.lstrip('.'))
            ]
            for c in to_remove:
                try:
                    _global_cookie_jar.clear(c.domain, c.path, c.name)
                except Exception:
                    pass
        else:
            _global_cookie_jar.clear()
    except Exception:
        pass


def _cache_good_playlist(entry_url, body_bytes):
    with _LAST_GOOD_PLAYLIST_LOCK:
        if len(_LAST_GOOD_PLAYLIST) >= 64 and entry_url not in _LAST_GOOD_PLAYLIST:
            try:
                _LAST_GOOD_PLAYLIST.pop(next(iter(_LAST_GOOD_PLAYLIST)))
            except Exception:
                pass
        _LAST_GOOD_PLAYLIST[entry_url] = body_bytes
    _PLAYLIST_BODY_CACHE.put(entry_url, body_bytes)


def _get_cached_playlist(entry_url):
    body = _PLAYLIST_BODY_CACHE.get(entry_url)
    if body:
        return body
    with _LAST_GOOD_PLAYLIST_LOCK:
        return _LAST_GOOD_PLAYLIST.get(entry_url)


def _make_placeholder_playlist(media_sequence=0, target_duration=6):
    try:
        media_sequence = int(media_sequence)
    except Exception:
        media_sequence = 0
    try:
        target_duration = int(max(1, target_duration))
    except Exception:
        target_duration = 6
    return (
        f'#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:{target_duration}\n'
        f'#EXT-X-MEDIA-SEQUENCE:{media_sequence}\n'
    ).encode('utf-8')


# ════════════════════════════════════════════════════════════
# VALIDAÇÃO DE MANIFESTO
# ════════════════════════════════════════════════════════════

_RE_HAS_SEGMENT_LINE = re.compile(r'^[^#\s].+', re.MULTILINE)


def _validate_manifest_body(data):
    if not data or len(data) < MIN_VALID_PLAYLIST_BYTES:
        return False, 'corpo vazio ou minúsculo demais'

    if data[:1] == b'\x47':
        return False, 'corpo parece ser um segmento MPEG-TS, não manifesto'

    head = data[:256]
    if b'#EXTM3U' not in head:
        low = data[:512].lower()
        if low.lstrip().startswith((b'<html', b'<!doctype', b'<?xml')):
            return False, 'HTML/XML recebido no lugar de manifesto (200 OK mascarado)'
        if low.lstrip().startswith((b'{', b'[')):
            return False, 'JSON recebido no lugar de manifesto (200 OK mascarado)'
        return False, 'tag #EXTM3U ausente'

    try:
        text = data.decode('utf-8', errors='replace')
    except Exception:
        return False, 'falha ao decodificar corpo'

    if '#EXT-X-STREAM-INF' in text:
        if _RE_HAS_SEGMENT_LINE.search(text):
            return True, 'master playlist válida'
        return False, 'master playlist sem nenhuma variante utilizável'

    if '#EXTINF' in text:
        return True, 'media playlist válida'

    if '#EXT-X-ENDLIST' in text and _RE_HAS_SEGMENT_LINE.search(text):
        return True, 'playlist finalizada com segmentos'

    return False, 'manifesto sem #EXTINF nem #EXT-X-STREAM-INF (corpo suspeito)'

# ════════════════════════════════════════════════════════════
# HTTP CLIENTE STREAMING — Pipeline + Watchdog + Adaptive
# ════════════════════════════════════════════════════════════

def _resolve_and_stream(url, headers=None, max_redirects=5, session=None, max_wait=None):
    current_url = url
    parsed = urlparse(current_url)
    is_https = parsed.scheme == 'https'
    port = parsed.port or (443 if is_https else 80)
    host = parsed.hostname

    _GLOBAL_ORIGIN_SEM.acquire()
    try:
        for _ in range(max_redirects):
            path = parsed.path or '/'
            if parsed.query:
                path += '?' + parsed.query

            pipeline = _get_pipeline(host, port, is_https)
            stats = pipeline.stats
            prefer_fresh = stats.degradation_score() > 0.5

            parallel_st = None
            if prefer_fresh:
                parallel_st = pipeline.predictive_parallel()

            st = None
            for attempt in range(2):
                try:
                    st = pipeline.acquire(prefer_fresh=(attempt > 0 or prefer_fresh))
                    if parallel_st and parallel_st is not st:
                        st = pipeline.seamless_switch(st, parallel_st)
                        parallel_st = None

                    req_headers = {
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Connection': 'keep-alive',
                        'Host': host,
                        'User-Agent': headers.get('User-Agent', _UA_FALLBACK) if headers else _UA_FALLBACK,
                    }
                    req_headers['Origin'] = f'{parsed.scheme}://{host}'
                    req_headers['Referer'] = f'{parsed.scheme}://{host}/'
                    if headers:
                        for k, v in headers.items():
                            kl = k.lower()
                            if kl == 'host':
                                continue
                            if kl == 'range' and not v:
                                continue
                            req_headers[k] = v

                    t0 = time.time()
                    st.conn.request('GET', path, headers=req_headers)
                    timeout = stats.adaptive_timeout(
                        session.target_duration if session else 6.0
                    )
                    if max_wait is not None:
                        timeout = max(0.5, min(timeout, max_wait))
                    try:
                        if st.conn.sock:
                            st.conn.sock.settimeout(timeout)
                    except Exception:
                        pass

                    resp = st.conn.getresponse()
                    rtt = time.time() - t0
                    stats.record_rtt(rtt)
                    st.last_rtt = rtt

                    if resp.status in (301, 302, 307, 308):
                        loc = resp.headers.get('Location')
                        try:
                            resp.read()
                            resp.close()
                        except Exception:
                            pass
                        pipeline.release(st, success=True)
                        st = None
                        if not loc:
                            raise Exception('Redirect sem Location')
                        current_url = urljoin(current_url, loc)
                        parsed = urlparse(current_url)
                        is_https = parsed.scheme == 'https'
                        port = parsed.port or (443 if is_https else 80)
                        host = parsed.hostname
                        break

                    if resp.status >= 400:
                        err = urllib.error.HTTPError(
                            current_url, resp.status, 'Upstream Error', resp.headers, None
                        )
                        try:
                            resp.read(65536)
                            resp.close()
                        except Exception:
                            pass
                        pipeline.release(st, success=False, err=err)
                        st = None
                        raise err

                    return st, resp, current_url, pipeline

                except (http.client.BadStatusLine, http.client.RemoteDisconnected,
                        ConnectionResetError, BrokenPipeError, socket.timeout,
                        OSError) as e:
                    if st:
                        pipeline.release(st, success=False, err=e)
                        st = None
                    if attempt == 0:
                        continue
                    raise
                except urllib.error.HTTPError:
                    raise
                except Exception:
                    if st:
                        pipeline.release(st, success=False, err=sys.exc_info()[1])
                        st = None
                    raise
            else:
                continue
        raise Exception('Muitos redirecionamentos ou falha de conexão')
    except Exception:
        _GLOBAL_ORIGIN_SEM.release()
        raise


def _finish_stream(st, pipeline, resp, success=True, bytes_n=0, elapsed=0.0, err=None):
    try:
        if resp is not None:
            try:
                if not success:
                    try:
                        resp.read(65536)
                    except Exception:
                        pass
                resp.close()
            except Exception:
                pass
    finally:
        try:
            if pipeline is not None and st is not None:
                pipeline.release(st, success=success, bytes_n=bytes_n, elapsed=elapsed, err=err)
        finally:
            try:
                _GLOBAL_ORIGIN_SEM.release()
            except ValueError:
                pass


def _get_adaptive_timeout(host=None, target_duration=6.0):
    if host:
        return _get_origin_stats(host).adaptive_timeout(target_duration)
    return 15.0

# ════════════════════════════════════════════════════════════
# MELHORIA 3 + 13 — PREFETCH INTELIGENTE + SCHEDULER
# ════════════════════════════════════════════════════════════

_RE_EXTINF = re.compile(r'#EXTINF:([\d.]+)')
_RE_MEDIA_SEQ = re.compile(r'#EXT-X-MEDIA-SEQUENCE:(\d+)')
_RE_TARGET_DUR = re.compile(r'#EXT-X-TARGETDURATION:(\d+)')
_RE_URI = re.compile(r'URI="([^"]+)"')


def _parse_playlist_meta(content):
    media_seq = 0
    target_dur = 6.0
    m = _RE_MEDIA_SEQ.search(content)
    if m:
        media_seq = int(m.group(1))
    m = _RE_TARGET_DUR.search(content)
    if m:
        target_dur = float(m.group(1))
    return media_seq, target_dur


def _extract_segment_urls(content, base_url):
    lines = content.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    urls = []
    prev_inf = False
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith('#EXTINF'):
            prev_inf = True
            continue
        if stripped.startswith('#'):
            prev_inf = False
            continue
        if prev_inf:
            absolute = urljoin(base_url, stripped)
            urls.append(absolute)
            prev_inf = False
    return urls


def _prefetch_segment_job(session, seg_url, sequence, duration, headers):
    if not session.alive:
        return
    if session.ring.has_url(seg_url):
        return
    cached = _SEGMENT_CACHE.get(seg_url)
    if cached:
        session.ring.put(cached, seg_url, sequence, duration, block=False)
        return

    st = resp = pipeline = None
    try:
        st, resp, final_url, pipeline = _resolve_and_stream(
            seg_url, headers=headers, session=session
        )
        host = urlparse(final_url).hostname
        stats = _get_origin_stats(host)
        chunk_sz = stats.adaptive_chunk()
        t0 = time.time()
        chunks = []
        total = 0
        while True:
            try:
                if st.conn and st.conn.sock:
                    st.conn.sock.settimeout(stats.adaptive_timeout(session.target_duration))
            except Exception:
                pass
            piece = resp.read(chunk_sz)
            if not piece:
                break
            chunks.append(piece)
            total += len(piece)
            session.record_bytes(len(piece))
            if session.stall_seconds() > max(8.0, session.target_duration * 2):
                raise socket.timeout('prefetch stall')
        data = b''.join(chunks) if len(chunks) != 1 else chunks[0]
        elapsed = time.time() - t0
        _finish_stream(st, pipeline, resp, success=True, bytes_n=total, elapsed=elapsed)
        st = pipeline = resp = None
        _SEGMENT_CACHE.put(seg_url, data)
        session.ring.put(data, seg_url, sequence, duration, block=False)
        _log(f'Prefetch OK seq={sequence} {total}B', 'debug')
    except Exception as e:
        _log(f'Prefetch fail {seg_url[:60]}: {e}', 'debug')
        if st or pipeline:
            _finish_stream(st, pipeline, resp, success=False, err=e)


def _schedule_prefetch(session, headers):
    with session.lock:
        urls = list(session.segment_urls)
        depth = session.prefetch_depth
        media_seq = session.media_sequence
        durations = [session.target_duration] * len(urls)
    if not urls:
        return
    mgr = _get_thread_mgr()
    scheduled = 0
    for i, u in enumerate(urls):
        if scheduled >= depth:
            break
        if session.ring.has_url(u) or _SEGMENT_CACHE.get(u):
            continue
        seq = media_seq + i
        mgr.submit(_prefetch_segment_job, session, u, seq, durations[i] if i < len(durations) else 6.0, headers)
        scheduled += 1

# ════════════════════════════════════════════════════════════
# MELHORIA 4 — WATCHDOG DE STALL
# ════════════════════════════════════════════════════════════

def _watchdog_loop():
    last_log = {}
    while True:
        time.sleep(2.0)
        try:
            with _STREAM_SESSIONS_LOCK:
                sessions = list(_STREAM_SESSIONS.values())
            now = time.time()
            for sess in sessions:
                if not sess.alive:
                    continue
                if sess.last_playlist_time and (now - sess.last_playlist_time) > 90:
                    continue
                stall = sess.stall_seconds()
                threshold = max(12.0, sess.target_duration * 3.0)
                if stall > threshold:
                    host = urlparse(sess.entry_url).hostname
                    if host:
                        with _PIPELINES_LOCK:
                            for key, pipe in list(_PIPELINES.items()):
                                if key[0] == host:
                                    pipe.predictive_parallel()
                    key = sess.entry_url
                    if now - last_log.get(key, 0) > 15:
                        last_log[key] = now
                        _log(f'Watchdog: stall {stall:.1f}s on {sess.entry_url[:60]}', 'warning')
                if sess.frozen_count >= 3 and (now - sess.last_playlist_time) > sess.target_duration:
                    sess.frozen_count = 0
        except Exception as e:
            _log(f'Watchdog error: {e}', 'debug')

# ════════════════════════════════════════════════════════════
# HLS PROXY HTTP HANDLER — PATH PARAMETERS (Patch Linux)
# ════════════════════════════════════════════════════════════

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def do_GET(self):
        parsed = urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        path = parsed.path.rstrip('/') or '/'

        # ── Roteamento por PATH PARAMETERS (formato aceito pelo FFmpeg do Manjaro) ──
        # /playlist/<TOKEN_B64>.m3u8  -> playlist/m3u8
        # /seg/<TOKEN_B64>.ts          -> segmento
        # /key/<TOKEN_B64>.key         -> chave AES
        # Compatibilidade reversa: ainda aceita ?url=... para chamadas legadas.
        if path.startswith('/playlist/'):
            token = _extract_b64_token(path, '.m3u8')
            url = _b64_decode_url(token) if token else None
            if not url and 'url' in params:
                url = params.get('url', [None])[0]
            self._handle_playlist({'url': [url] if url else [None]})
            return
        if path.startswith('/seg/'):
            token = _extract_b64_token(path, '.ts')
            url = _b64_decode_url(token) if token else None
            if not url and 'url' in params:
                url = params.get('url', [None])[0]
            self._handle_segment({'url': [url] if url else [None]})
            return
        if path.startswith('/key/'):
            token = _extract_b64_token(path, '.key')
            url = _b64_decode_url(token) if token else None
            if not url and 'url' in params:
                url = params.get('url', [None])[0]
            self._handle_key({'url': [url] if url else [None]})
            return

        # Endpoints raiz (compatíveis com chamadas legadas via ?url=)
        if path in ('/playlist', '/master.m3u8', '/playlist.m3u8', '/m3u8', '/proxy.m3u8'):
            self._handle_playlist(params)
        elif path in ('/seg', '/segment'):
            self._handle_segment(params)
        elif path == '/key':
            self._handle_key(params)
        elif path == '/favicon.ico':
            self.send_error(404)
        else:
            if 'url' in params:
                self._handle_playlist(params)
            else:
                self.send_error(404, 'Unknown endpoint')

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.end_headers()

    def _get_kodi_headers(self, allow_range=False):
        h = {}
        if allow_range and 'Range' in self.headers:
            h['Range'] = self.headers['Range']
        return h

    def _handle_playlist(self, params):
        url = params.get('url', [None])[0]
        if not url:
            self.send_error(400, 'Missing url param')
            return

        entry_url = url
        session = _get_stream_session(entry_url)
        base_headers = self._get_kodi_headers(allow_range=False)

        round_start = time.time()
        last_reason = None
        for round_n in range(PLAYLIST_ROUNDS):
            elapsed_so_far = time.time() - round_start
            if round_n > 0 and elapsed_so_far > PLAYLIST_ROUND_TIMEOUT_BUDGET:
                last_reason = last_reason or 'orçamento de tempo esgotado'
                break

            st = resp = pipeline = None
            try:
                ua = _rotate_user_agent()
                kodi_h = dict(base_headers)
                kodi_h['User-Agent'] = ua

                remaining_budget = max(0.8, PLAYLIST_ROUND_TIMEOUT_BUDGET - elapsed_so_far)
                remaining_budget = min(remaining_budget, PLAYLIST_FIRST_ATTEMPT_MAX_WAIT)
                st, resp, final_url, pipeline = _resolve_and_stream(
                    entry_url, headers=kodi_h, session=session, max_wait=remaining_budget
                )
                try:
                    data = resp.read()
                    _finish_stream(st, pipeline, resp, success=True, bytes_n=len(data), elapsed=0.01)
                    st = pipeline = resp = None
                except Exception:
                    _finish_stream(st, pipeline, resp, success=False, err=sys.exc_info()[1])
                    st = pipeline = resp = None
                    raise

                valid, reason = _validate_manifest_body(data)
                if not valid:
                    last_reason = reason
                    raise Exception(f'Manifesto inválido/mascarado: {reason}')

                content = data.decode('utf-8', errors='replace')

                media_seq, target_dur = _parse_playlist_meta(content)
                seg_urls = _extract_segment_urls(content, final_url)
                body_hash = hashlib.md5(data).hexdigest()

                frozen = session.update_playlist_meta(media_seq, target_dur, seg_urls, body_hash)
                if frozen >= 4:
                    session.last_playlist_hash = None
                    _log('Playlist frozen detected — forcing refresh path', 'warning')

                rewritten = self._rewrite_playlist(content, final_url, entry_url)
                body = rewritten.encode('utf-8')
                _cache_good_playlist(entry_url, body)
                session.record_bytes(len(body))

                _schedule_prefetch(session, kodi_h)

                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Cache-Control', 'no-cache, no-store')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(memoryview(body))
                return
            except (BrokenPipeError, ConnectionResetError):
                if st or pipeline:
                    _finish_stream(st, pipeline, resp, success=False)
                return
            except Exception as e:
                if st or pipeline:
                    _finish_stream(st, pipeline, resp, success=False, err=e)
                if _is_token_expired_error(e):
                    _purge_session_state(urlparse(entry_url).hostname)
                code = getattr(e, 'code', None)
                _log(f'Playlist round {round_n} failed: {e}', 'warning')
                if code and 500 <= int(code) < 600:
                    time.sleep(0.12 + random.uniform(0, 0.1))
                else:
                    time.sleep(min(0.15 * (2 ** round_n), 0.6) + random.uniform(0, 0.08))

        body = _get_cached_playlist(entry_url)
        cache_age = time.time() - (session.last_playlist_time or 0)
        cache_is_trustworthy = (
            body is not None
            and session.last_playlist_time > 0
            and cache_age <= MAX_TRUSTED_STALE_PLAYLIST_AGE
        )
        if not cache_is_trustworthy:
            if body is not None:
                _log(f'Cache de playlist descartado por idade ({cache_age:.1f}s) — usando placeholder', 'warning')
            body = _make_placeholder_playlist(
                media_sequence=session.media_sequence,
                target_duration=session.target_duration,
            )
        if last_reason:
            _log(f'Playlist fallback para {entry_url[:60]}: {last_reason}', 'warning')
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(memoryview(body))
        except Exception:
            pass

    def _rewrite_playlist(self, content, base_url, entry_url):
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        lines = content.split('\n')
        result = []
        prev_tag = None

        for line in lines:
            stripped = line.strip()
            if not stripped:
                result.append('')
                continue

            if stripped.startswith('#'):
                if '#EXT-X-STREAM-INF' in stripped:
                    prev_tag = 'stream'
                elif '#EXTINF' in stripped:
                    prev_tag = 'segment'
                if 'URI="' in stripped:
                    stripped = self._rewrite_uri_in_tag(stripped, base_url, entry_url)
                result.append(stripped)
                continue

            absolute = urljoin(base_url, stripped)
            _remember_entry_url(absolute, entry_url)
            token = _b64_encode_url(absolute)
            if prev_tag == 'stream':
                # Path parameter: /playlist/<TOKEN>.m3u8 — formato aceito pelo FFmpeg do Manjaro
                result.append(f'http://127.0.0.1:{_PROXY_PORT}/playlist/{token}.m3u8')
            else:
                result.append(f'http://127.0.0.1:{_PROXY_PORT}/seg/{token}.ts')

        return '\n'.join(result)

    def _rewrite_uri_in_tag(self, line, base_url, entry_url):
        def replace_uri(match):
            original = match.group(1)
            if original.startswith('data:'):
                return f'URI="{original}"'
            absolute = urljoin(base_url, original)
            _remember_entry_url(absolute, entry_url)
            token = _b64_encode_url(absolute)
            if '#EXT-X-KEY' in line or '#EXT-X-SESSION-KEY' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/key/{token}.key"'
            elif '#EXT-X-MAP' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg/{token}.ts"'
            elif '#EXT-X-MEDIA' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/playlist/{token}.m3u8"'
            else:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg/{token}.ts"'
        return _RE_URI.sub(replace_uri, line)

    def _handle_segment(self, params):
        url = params.get('url', [None])[0]
        if not url:
            self.send_error(400, 'Missing url param')
            return

        entry_url = _lookup_entry_url(url, url)
        session = _get_stream_session(entry_url)
        headers_sent = False

        data = session.ring.get_by_url(url, timeout=0.05)
        if data is None:
            data = _SEGMENT_CACHE.get(url)

        if data is not None:
            try:
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(memoryview(data))
                session.record_bytes(len(data))
            except (BrokenPipeError, ConnectionResetError):
                pass
            return

        for round_n in range(6):
            st = resp = pipeline = None
            try:
                target = url
                ua = _rotate_user_agent()
                kodi_h = self._get_kodi_headers(allow_range=True)
                kodi_h['User-Agent'] = ua

                st, resp, final_url, pipeline = _resolve_and_stream(
                    target, headers=kodi_h, session=session,
                    max_wait=SEGMENT_FIRST_BYTE_MAX_WAIT
                )
                host = urlparse(final_url).hostname
                stats = _get_origin_stats(host)
                chunk_sz = stats.adaptive_chunk()
                timeout = stats.adaptive_timeout(session.target_duration)

                first_chunk = resp.read(chunk_sz)
                content_type = resp.headers.get('Content-Type', 'video/mp2t')
                if first_chunk and first_chunk[:7] == b'#EXTM3U':
                    _finish_stream(st, pipeline, resp, success=False, err=Exception('got playlist as segment'))
                    st = pipeline = resp = None
                    raise Exception('Upstream returned playlist body for segment URL')
                low_head = (first_chunk or b'')[:256].lstrip().lower()
                if low_head.startswith((b'<html', b'<!doctype', b'<?xml', b'{', b'[')):
                    _finish_stream(st, pipeline, resp, success=False, err=Exception('got error page as segment'))
                    st = pipeline = resp = None
                    raise Exception('Upstream returned HTML/JSON body for segment URL')

                self.send_response(200)
                self.send_header('Content-Type', content_type)
                cl = resp.headers.get('Content-Length')
                if cl:
                    self.send_header('Content-Length', cl)
                else:
                    self.close_connection = True
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                headers_sent = True

                t0 = time.time()
                total = 0
                try:
                    if first_chunk:
                        self.wfile.write(memoryview(first_chunk))
                        total += len(first_chunk)
                        session.record_bytes(len(first_chunk))

                    try:
                        if st.conn and st.conn.sock:
                            st.conn.sock.settimeout(timeout)
                    except Exception:
                        pass

                    last_data = time.time()
                    while True:
                        try:
                            chunk = resp.read(chunk_sz)
                        except socket.timeout:
                            if time.time() - last_data > timeout:
                                raise
                            continue
                        if not chunk:
                            break
                        self.wfile.write(memoryview(chunk))
                        total += len(chunk)
                        session.record_bytes(len(chunk))
                        last_data = time.time()
                        chunk_sz = stats.adaptive_chunk()

                    elapsed = time.time() - t0
                    _finish_stream(st, pipeline, resp, success=True, bytes_n=total, elapsed=elapsed)
                    st = pipeline = resp = None
                except (socket.timeout, BrokenPipeError, ConnectionResetError) as e:
                    try:
                        resp.close()
                    except Exception:
                        pass
                    _finish_stream(st, pipeline, None, success=False, err=e)
                    st = pipeline = resp = None
                    return
                return
            except Exception as e:
                if st or pipeline:
                    _finish_stream(st, pipeline, resp, success=False, err=e)
                if headers_sent:
                    return
                if _is_token_expired_error(e):
                    _purge_session_state(urlparse(url).hostname)
                _log(f'Segment round {round_n} failed: {e}', 'warning')
                code = getattr(e, 'code', None)
                if code and 500 <= int(code) < 600:
                    time.sleep(0.08 + random.uniform(0, 0.08))
                else:
                    time.sleep(min(0.12 * (2 ** round_n), 0.8) + random.uniform(0, 0.05))

        if headers_sent:
            return
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(len(_TS_NULL_BURST)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(_TS_NULL_BURST)
        except Exception:
            pass

    def _handle_key(self, params):
        url = params.get('url', [None])[0]
        if not url:
            self.send_error(400, 'Missing url param')
            return

        with _AES_KEY_LOCK:
            cached = _AES_KEY_CACHE.get(url)
            if cached and time.time() - cached[1] < AES_KEY_TTL:
                data = cached[0]
                try:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/octet-stream')
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(memoryview(data))
                except Exception:
                    pass
                return

        for round_n in range(6):
            st = resp = pipeline = None
            try:
                ua = _rotate_user_agent()
                st, resp, final_url, pipeline = _resolve_and_stream(
                    url, headers={'User-Agent': ua}
                )
                try:
                    data = resp.read()
                    _finish_stream(st, pipeline, resp, success=True, bytes_n=len(data), elapsed=0.01)
                    st = pipeline = resp = None
                except Exception:
                    _finish_stream(st, pipeline, resp, success=False, err=sys.exc_info()[1])
                    st = pipeline = resp = None
                    raise

                with _AES_KEY_LOCK:
                    if len(_AES_KEY_CACHE) >= 64:
                        try:
                            _AES_KEY_CACHE.pop(next(iter(_AES_KEY_CACHE)))
                        except Exception:
                            pass
                    _AES_KEY_CACHE[url] = (data, time.time())

                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(memoryview(data))
                return
            except (BrokenPipeError, ConnectionResetError):
                if st or pipeline:
                    _finish_stream(st, pipeline, resp, success=False)
                return
            except Exception as e:
                if st or pipeline:
                    _finish_stream(st, pipeline, resp, success=False, err=e)
                time.sleep(min(0.2 * (2 ** round_n), 2.0))

        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', '16')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'\x00' * 16)
        except Exception:
            pass

    def log_message(self, format, *args):
        if _DEBUG_MODE:
            _log(f'HTTP: {format % args}', 'debug')

# ════════════════════════════════════════════════════════════
# THREADED HTTP SERVER
# ════════════════════════════════════════════════════════════

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        """Silencia erros benignos de cliente que desconectou antes de enviar
        a requisição completa (WinError 10054 / ConnectionResetError).
        Outros erros continuam sendo logados normalmente."""
        import traceback
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError,
                            BrokenPipeError, ConnectionError)):
            return
        traceback.print_exc()

# ════════════════════════════════════════════════════════════
# SERVER MANAGEMENT
# ════════════════════════════════════════════════════════════

def _ensure_server_running():
    global _PROXY_PORT, _PROXY_SERVER
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None and _PROXY_PORT is not None:
            return _PROXY_PORT

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', 0))
        _PROXY_PORT = sock.getsockname()[1]
        sock.close()

        _PROXY_SERVER = ThreadingHTTPServer(('127.0.0.1', _PROXY_PORT), HLSProxyHandler)

        dns_thread = threading.Thread(target=_dns_bg_refresh_loop, daemon=True)
        dns_thread.start()

        wd_thread = threading.Thread(target=_watchdog_loop, name='NexusWatchdog', daemon=True)
        wd_thread.start()

        _get_thread_mgr()

        thread = threading.Thread(target=_PROXY_SERVER.serve_forever, daemon=True)
        thread.start()

        _log(f'HLS Proxy server iniciado na porta {_PROXY_PORT} (v1.9.0 pipeline+ring+prefetch)')
        return _PROXY_PORT


def _stop_server():
    global _PROXY_SERVER, _PROXY_PORT
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None:
            _PROXY_SERVER.shutdown()
            _PROXY_SERVER.server_close()
            _PROXY_SERVER = None
            _PROXY_PORT = None
            _log('HLS Proxy server parado')
    with _STREAM_SESSIONS_LOCK:
        for s in _STREAM_SESSIONS.values():
            s.alive = False
            s.ring.cleanup()
        _STREAM_SESSIONS.clear()

# ════════════════════════════════════════════════════════════
# KODI ADDON INTERFACE (inalterada — play_stream(url) mantido)
# ════════════════════════════════════════════════════════════

class HLSAddon:
    def __init__(self, addon_handle=None):
        self.addon_handle = addon_handle

    def play_stream(self, url):
        import xbmc
        import xbmcplugin
        import xbmcgui

        port = _ensure_server_running()
        # Path parameter: /playlist/<TOKEN_BASE64>.m3u8
        # URL final tem aparência de arquivo estático — aceita pelo FFmpeg do Manjaro.
        token = _b64_encode_url(url)
        proxy_url = f'http://127.0.0.1:{port}/playlist/{token}.m3u8'

        _log(f'play_stream: {url[:120]}')
        _log(f'proxy_url: {proxy_url[:150]}')

        li = xbmcgui.ListItem(path=proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)

        if self.addon_handle is not None:
            xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
        else:
            xbmc.Player().play(proxy_url, li)