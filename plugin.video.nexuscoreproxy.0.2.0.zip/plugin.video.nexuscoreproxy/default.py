# -*- coding: utf-8 -*-

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, urljoin
from requests.adapters import HTTPAdapter

# Módulos Kodi
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Flask
try:
    from flask import Flask, request, Response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro", "Módulo 'script.module.flask' não encontrado.")
    sys.exit(1)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Instâncias do Addon ---
ADDON = xbmcaddon.Addon()
_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

# --- Configurações do Painel X Codes (Otimizadas) ---
# Tamanhos de Buffer e Chunk ajustados para performance e estabilidade
CHUNK_SIZE = 128 * 1024 
FETCH_TIMEOUT = 30
CONNECT_TIMEOUT = 10
QUEUE_SIZE = 300

# Lógica Anti-Loop (Sutura Splicing) do X Codes
TAIL_PRIMARY = 32 * 1024   # 32 KB para busca primária
TAIL_SECONDARY = 8 * 1024  # 8 KB para busca secundária
SEARCH_WINDOW = 2 * 1024 * 1024 # Janela de 2MB para encontrar o ponto de sutura

# Injeção Anti-EOF
KEEPALIVE_PACKETS = 4500

# Pacote TS Nulo Padrão
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
TS_PACKET_SIZE = 188

# User Agents Realistas do X Codes
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/121.0.0.0 TV Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20',
    'AppleCoreMedia/1.0.0.21G217 (iPhone; U; CPU OS 16_6 like Mac OS X)',
    'Lavf/59.27.100'
]

app = Flask(__name__)

# --- Utilitários X Codes ---

def random_ip():
    """Gera um IP falso aleatório para headers de spoofing."""
    while True:
        o1 = random.randint(1, 223)
        if o1 in [10, 127, 169, 172, 192, 198, 203, 224]: continue
        o2 = random.randint(0, 255)
        o3 = random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31: continue
        if o1 == 192 and o2 == 168: continue
        return f"{o1}.{o2}.{o3}.{o4}"

def get_stealth_headers(target_url):
    """Gera Headers furtivos e realistas para evitar bloqueios."""
    fake_ip = random_ip()
    parsed = urlparse(target_url)
    base_domain = f"{parsed.scheme}://{parsed.netloc}/"
    
    ua = random.choice(USER_AGENTS)
    
    # Detecta plataforma
    if 'Android' in ua: platform = '"Android"'; mobile = '?1'
    elif 'iPhone' in ua: platform = '"iOS"'; mobile = '?1'
    elif 'SMART-TV' in ua: platform = '"SmartTV"'; mobile = '?0'
    else: platform = '"Windows"'; mobile = '?0'
    
    headers = {
        'User-Agent': ua,
        'Accept': '*/*',
        'Accept-Language': random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9,en;q=0.8']),
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': base_domain,
        'Origin': base_domain.rstrip('/'),
        'DNT': '1',
        'X-Forwarded-For': fake_ip,
        'X-Real-IP': fake_ip,
        'Client-IP': fake_ip,
        'Sec-CH-UA': f'"Not;A=Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
        'Sec-CH-UA-Mobile': mobile,
        'Sec-CH-UA-Platform': platform,
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty'
    }
    return headers

# --- Engine X Codes Adaptada para Kodi ---

class XCodesEngine:
    def __init__(self):
        self.active_url_param = None
        self.original_url = None
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self.stop_event = threading.Event()
        
        # Lógica Anti-Loop
        self.stream_tail = b''
        self.residual_buffer = b''
        self.has_initial_lock = False
        
        self.consecutive_failures = 0
        self.session = None

    def _create_fresh_session(self):
        if self.session:
            try:
                self.session.close()
            except:
                pass
        
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=100, pool_maxsize=200, max_retries=0)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if len(urls) < 1:
            raise ValueError("Nenhuma URL fornecida")
        target_url = urls[0]

        if self.active_url_param == url_param:
            xbmc.log("[X-CODES HYBRID] Reutilizando sessão", xbmc.LOGINFO)
            if self.stop_event.is_set() or not self.producer_thread.is_alive():
                self.stop_event.clear()
                with self.data_queue.mutex:
                    self.data_queue.queue.clear()
                self._create_fresh_session()
                self.producer_thread = threading.Thread(target=self._producer_loop, daemon=True)
                self.producer_thread.start()
        else:
            self.stop_event.set()
            if hasattr(self, 'producer_thread') and self.producer_thread.is_alive():
                self.producer_thread.join()
            self.stop_event.clear()
            with self.data_queue.mutex:
                self.data_queue.queue.clear()

            self._create_fresh_session()
            self.active_url_param = url_param
            self.original_url = target_url
            self.stream_tail = b''
            self.residual_buffer = b''
            self.has_initial_lock = False
            self.consecutive_failures = 0

            self.producer_thread = threading.Thread(target=self._producer_loop, daemon=True)
            self.producer_thread.start()
            xbmc.log(f"[X-CODES HYBRID] Iniciando Motor: {target_url[:60]}...", xbmc.LOGINFO)

    def _fill_keepalive(self, multiplier=20):
        """Injeta pacotes nulos para manter o player vivo (Anti-EOF)."""
        null_block = TS_NULL_PACKET * KEEPALIVE_PACKETS
        for _ in range(multiplier):
            try:
                self.data_queue.put_nowait(null_block)
            except queue.Full:
                break

    def _process_chunk_optimized(self, raw_chunk):
        """Processa o chunk bruto, alinha pacotes TS e atualiza o tail."""
        if not raw_chunk:
            return

        current_batch = self.residual_buffer + raw_chunk
        
        if not self.has_initial_lock:
            sync_idx = current_batch.find(b'\x47')
            if sync_idx == -1:
                self.residual_buffer = current_batch[-TS_PACKET_SIZE*2:] 
                return
            
            current_batch = current_batch[sync_idx:]
            self.has_initial_lock = True

        total_len = len(current_batch)
        if total_len < TS_PACKET_SIZE:
            self.residual_buffer = current_batch
            return

        num_packets = total_len // TS_PACKET_SIZE
        bytes_to_send = num_packets * TS_PACKET_SIZE
        
        payload = current_batch[:bytes_to_send]
        self.residual_buffer = current_batch[bytes_to_send:]
        
        # Atualiza a cauda para a próxima sutura
        self.stream_tail += payload
        if len(self.stream_tail) > TAIL_PRIMARY + TAIL_SECONDARY:
            self.stream_tail = self.stream_tail[-TAIL_PRIMARY:]
            
        try:
            self.data_queue.put_nowait(payload)
        except queue.Full:
            # Anti-Grinch: Se encher, descarta dados antigos para dar entrada aos novos
            while not self.data_queue.empty():
                try:
                    self.data_queue.get_nowait()
                except:
                    break
            try:
                self.data_queue.put_nowait(payload)
            except:
                pass

    def _producer_loop(self):
        force_url_refresh = False

        while not self.stop_event.is_set():
            r = None
            try:
                # URL Management (Simulação de refresh do X Codes)
                target_url = self.original_url
                
                headers = get_stealth_headers(target_url)
                # Remover Accept-Encoding para evitar gzip em streams TS problemáticos
                if 'Accept-Encoding' in headers:
                    del headers['Accept-Encoding']

                r = self.session.get(
                    target_url,
                    headers=headers,
                    stream=True,
                    timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT), 
                    verify=False,
                    allow_redirects=True
                )
                
                if r.status_code not in [200, 206]:
                    # TRATAMENTO DE ERROS CRÍTICOS (Token Expirado / Bloqueio)
                    if r.status_code in [401, 403, 406, 410]:
                        xbmc.log(f"[X-CODES HYBRID] Erro {r.status_code} - Forçando Nova URL (Cache Wipe)", xbmc.LOGWARNING)
                        force_url_refresh = True
                        self.consecutive_failures += 1
                        time.sleep(1)
                        if r: r.close()
                        continue
                    
                    if r.status_code == 409:
                        xbmc.log("[X-CODES HYBRID] Erro 409 - Keepalive + Backoff", xbmc.LOGWARNING)
                        self._fill_keepalive(25)
                        time.sleep(1 + random.uniform(0, 1))
                        continue

                    self.consecutive_failures += 1
                    backoff = min(30, 2 ** min(self.consecutive_failures, 5))
                    xbmc.log(f"[X-CODES HYBRID] Status {r.status_code} - Backoff {backoff}s", xbmc.LOGERROR)
                    if r: r.close()
                    self._fill_keepalive(15)
                    time.sleep(backoff + random.uniform(0, 2))
                    continue

                self.consecutive_failures = 0
                xbmc.log(f"[X-CODES HYBRID] Conectado: {r.url[:60]}...", xbmc.LOGINFO)
                
                # LÓGICA ANTI-LOOP (Sutura) do X Codes
                resync_search_buffer = b''
                is_resyncing = len(self.stream_tail) > 0

                for chunk in r.iter_content(chunk_size=CHUNK_SIZE):
                    if self.stop_event.is_set():
                        break
                    if not chunk:
                        continue
                    
                    if is_resyncing:
                        resync_search_buffer += chunk
                        
                        if len(resync_search_buffer) > SEARCH_WINDOW:
                            resync_search_buffer = resync_search_buffer[-(SEARCH_WINDOW // 2):]
                        
                        # Busca Primária (Sutura Perfeita)
                        primary_tail = self.stream_tail[-TAIL_PRIMARY:] if len(self.stream_tail) >= TAIL_PRIMARY else self.stream_tail
                        if primary_tail and primary_tail in resync_search_buffer:
                            idx = resync_search_buffer.rfind(primary_tail)
                            skip_bytes = idx + len(primary_tail)
                            
                            xbmc.log(f"[X-CODES HYBRID] SUTURA PERFEITA. Pulando {skip_bytes} bytes (Anti-Loop)", xbmc.LOGINFO)
                            
                            new_data = resync_search_buffer[skip_bytes:]
                            resync_search_buffer = b''
                            is_resyncing = False
                            
                            self.has_initial_lock = False 
                            self.residual_buffer = b'' 
                            self._process_chunk_optimized(new_data)
                            continue
                        
                        # Busca Secundária (Sutura Rápida)
                        secondary_tail = self.stream_tail[-TAIL_SECONDARY:] if len(self.stream_tail) >= TAIL_SECONDARY else b''
                        if secondary_tail and len(resync_search_buffer) > TAIL_SECONDARY + (188*50) and secondary_tail in resync_search_buffer:
                            idx = resync_search_buffer.rfind(secondary_tail)
                            skip_bytes = idx + len(secondary_tail)
                            
                            xbmc.log(f"[X-CODES HYBRID] SUTURA RÁPIDA. Pulando {skip_bytes} bytes", xbmc.LOGINFO)
                            
                            new_data = resync_search_buffer[skip_bytes:]
                            resync_search_buffer = b''
                            is_resyncing = False
                            
                            self.has_initial_lock = False
                            self.residual_buffer = b'' 
                            self._process_chunk_optimized(new_data)
                            continue
                    
                    else:
                        self._process_chunk_optimized(chunk)

                r.close()

            except Exception as e:
                xbmc.log(f"[X-CODES HYBRID] Erro na conexão: {str(e)}", xbmc.LOGERROR)
                if r:
                    try:
                        r.close()
                    except:
                        pass
                
                # Fallback SSL -> HTTP (Erro Ciphers)
                error_str = str(e).lower()
                if 'no ciphers available' in error_str:
                    http_url = self.original_url.replace('https://', 'http://', 1)
                    if http_url != self.original_url:
                        xbmc.log(f"[X-CODES HYBRID] Erro SSL -> Tentando HTTP: {http_url}", xbmc.LOGWARNING)
                        try:
                            headers = get_stealth_headers(http_url)
                            if 'Accept-Encoding' in headers: del headers['Accept-Encoding']
                            r_http = self.session.get(
                                http_url, headers=headers, stream=True,
                                timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT), verify=False, allow_redirects=True
                            )
                            if r_http.status_code in [200, 206]:
                                xbmc.log("[X-CODES HYBRID] Fallback HTTP OK!", xbmc.LOGINFO)
                                for chunk in r_http.iter_content(chunk_size=CHUNK_SIZE):
                                    if self.stop_event.is_set(): break
                                    if not chunk: continue
                                    self._process_chunk_optimized(chunk)
                                r_http.close()
                                continue
                        except:
                            pass

                self.consecutive_failures += 1
                backoff = min(30, 2 ** min(self.consecutive_failures, 5))
                xbmc.log(f"[X-CODES HYBRID] Backoff {backoff}s", xbmc.LOGERROR)
                self._fill_keepalive(30)
                time.sleep(backoff + random.uniform(0, 2))

    def generator(self):
        xbmc.log("[X-CODES HYBRID] Gerador Iniciado", xbmc.LOGINFO)
        yield TS_NULL_PACKET * KEEPALIVE_PACKETS
        
        try:
            while not self.stop_event.is_set():
                try:
                    chunk = self.data_queue.get(timeout=0.1)
                    yield chunk
                except queue.Empty:
                    yield TS_NULL_PACKET * KEEPALIVE_PACKETS
        finally:
            self.stop_event.set()
            xbmc.log("[X-CODES HYBRID] Sessão finalizada", xbmc.LOGINFO)

engine = XCodesEngine()

@app.route('/stream')
def stream_handler():
    url_param = request.args.get('url')
    if not url_param:
        return "URL não fornecida", 400
    
    engine.start_stream(url_param)
    return Response(
        stream_with_context(engine.generator()),
        mimetype='video/mp2t',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Content-Type': 'video/mp2t'
        }
    )

def get_free_port(start_port=50088):
    port = start_port
    while port < start_port + 100:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('127.0.0.1', port))
                return port
            except OSError:
                port += 1
    xbmcgui.Dialog().ok("Erro", "Não foi possível encontrar porta livre para o servidor local.")
    sys.exit(1)

def start_server(port):
    def run():
        try:
            from werkzeug.serving import run_simple
            run_simple('127.0.0.1', port, app, threaded=True, use_reloader=False)
        except Exception as e:
            xbmc.log(f"[X-CODES HYBRID] Erro Flask: {e}", xbmc.LOGERROR)
    t = threading.Thread(target=run, daemon=True)
    t.start()
    time.sleep(0.7)

SERVER_PORT = get_free_port()
start_server(SERVER_PORT)

def run_addon():
    action = _ARGS.get('action')
    url = _ARGS.get('url')

    if action == 'play' and url:
        local_url = f"http://127.0.0.1:{SERVER_PORT}/stream?url={quote(url)}"
        li = xbmcgui.ListItem(path=local_url)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    elif action == 'settings':
        ADDON.openSettings()
    else:
        li = xbmcgui.ListItem("[COLOR cyan]NEXUS X-CODES HYBRID V20.17[/COLOR]")
        xbmcplugin.addDirectoryItem(_HANDLE, f"{sys.argv[0]}?action=settings", li, False)
        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    run_addon()