# --- CÓDIGO COMPLETO E CORRIGIDO (PLAYER PADRÃO KODI) ---
# Lida com redirecionamentos e ajusta o cabeçalho Host dinamicamente
# IMPORTANTE: Este código utiliza a biblioteca 'script.module.netunblock'
# para contornar bloqueios de DNS de operadoras.
# Certifique-se de que o módulo está instalado no Kodi.
import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
from collections import OrderedDict
from typing import Optional, Dict
import warnings
import socket
import base64

# Tenta importar 'requests' do módulo 'doh_client' para usar DoH (DNS over HTTPS).
# Isso ajuda a contornar bloqueios de DNS de operadoras.
try:
    from doh_client import requests
except ImportError:
    # Se o módulo 'doh_client' não estiver disponível, usa a biblioteca 'requests' padrão.
    import requests

# Importa as exceções de 'requests' separadamente para evitar conflitos.
import requests.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import m3u8
from werkzeug.serving import make_server
from flask import Flask, request, Response, stream_with_context, Blueprint, g, abort, current_app, jsonify

# Configurações principais
MAX_SEGMENT_RETRIES = 5
RETRY_BACKOFF_FACTOR = 0.5
MAX_BACKOFF_TIME = 10
CONNECTION_TIMEOUT = 5.0
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 512 * 1024  # Aumentado para melhor performance em VOD
MAX_CACHE_MB = 128
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
SESSION_MAX_AGE = 60
PROACTIVE_RECONNECT_INTERVAL = 10  # Intervalo para verificação proativa em segundos

# Definimos User-Agents fixos para maior compatibilidade.
USER_AGENTS = [
    "VLC/3.0.20 LibVLC/3.0.20 (X11; Linux x86_64)",
    "ExoPlayer/2.18.7 (Linux; Android 13)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)",
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
LOG_FILE = "hlsproxy_iptv_proactive_default_player.log"

def setup_logging():
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    logging.basicConfig(
        handlers=[handler, logging.StreamHandler(sys.stdout)],
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s"
    )

    # Formatter personalizado para incluir request info (melhora debugging)
    class RequestFormatter(logging.Formatter):
        def format(self, record):
            if hasattr(g, 'request_id'):
                record.msg = f"[Request ID: {g.request_id}] {record.msg}"
            return super().format(record)

    for h in logging.getLogger().handlers:
        h.setFormatter(RequestFormatter("%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s"))

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")):
        return "application/vnd.apple.mpegurl"
    if path.endswith((".ts")) or "auth/" in path or "stream/" in path:
        return "video/mp2t"
    if path.endswith(".aac"):
        return "audio/aac"
    if path.endswith((".mp4", ".mkv")):
        return "video/mp4"
    return "application/octet-stream"

def get_headers(self, url: str, original_url: Optional[str] = None, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    # O Host DEVE ser o do domínio final da URL, não o original.
    parsed_url = urllib.parse.urlparse(url)
    original_host = urllib.parse.urlparse(original_url).netloc if original_url else parsed_url.netloc

    headers = {
        "Host": parsed_url.netloc, # Corrigido: Agora o Host é dinâmico
        "User-Agent": self.user_agent,
        "Accept": "*/*",
        "Accept-Encoding": "identity",
        "Connection": "keep-alive",
        # Referer e Origin ainda são do domínio original para validação
        "Referer": f"http://{original_host}/",
        "Origin": f"http://{original_host}",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache",
        "X-Forwarded-For": self.fake_ip,
    }

    if extra: headers.update(extra)
    return headers

class RotatingCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.store = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            item = self.store.get(url)
            if not item: return None
            data, expire = item
            if expire and expire < time.time():
                self._pop(url)
                return None
            self.store.move_to_end(url)
            return data

    def add(self, url: str, data: bytes, ttl: int):
        with self.lock:
            if url in self.store: self._pop(url)
            size = len(data)
            if size > self.max_bytes: return
            while self.total_bytes + size > self.max_bytes: self._popitem(last=False)
            expire = time.time() + ttl if ttl else None
            self.store[url] = (data, expire)
            self.total_bytes += size

    def _pop(self, url: str):
        if url in self.store:
            data, _ = self.store.pop(url)
            self.total_bytes -= len(data)

    def _popitem(self, last: bool):
        try:
            _, (data, _) = self.store.popitem(last=last)
            self.total_bytes -= len(data)
        except KeyError: pass

    def clear(self):
        """Limpa todo o cache."""
        with self.lock:
            self.store.clear()
            self.total_bytes = 0

class IPTVHLSProxyManager:
    def __init__(self):
        self.cache = RotatingCache()
        self.active_port = None
        self.server = None
        self.server_thread = None
        self.lock = threading.Lock()
        self.user_agent = None
        self.fake_ip = None
        self.app = self._create_flask_app()
        self.current_stream_url = None
        self.proactive_reconnect_timer = None

    def _randomize_headers(self):
        self.user_agent = random.choice(USER_AGENTS)
        self.fake_ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,255)}"

    def force_reconnect(self, reason: str = "Unknown"):
        with self.lock:
            logging.info(f"Forçando RECONEXÃO ({base64.b64encode(reason.encode('utf-8')).decode('utf-8')}). Descartando sessão antiga e cache.")
            self.cache.clear()
            self._randomize_headers()
            if self.current_stream_url:
                logging.info(f"Tentando reconectar ao stream principal: {base64.b64encode(self.current_stream_url.encode('utf-8')).decode('utf-8')}")

    def _start_proactive_reconnect_timer(self):
        if self.proactive_reconnect_timer and self.proactive_reconnect_timer.is_alive():
            self.proactive_reconnect_timer.cancel()
        self.proactive_reconnect_timer = threading.Timer(PROACTIVE_RECONNECT_INTERVAL, self._check_stream_status)
        self.proactive_reconnect_timer.daemon = True
        self.proactive_reconnect_timer.start()

    def _check_stream_status(self):
        if self.current_stream_url:
            logging.info(f"Verificação proativa de status para: {base64.b64encode(self.current_stream_url.encode('utf-8')).decode('utf-8')}")
            try:
                with self.app.app_context():
                    g.session = self._create_session()
                    r = self._make_request(self.current_stream_url, method="HEAD", timeout=CONNECTION_TIMEOUT)
                    r.raise_for_status()
                    logging.info("Verificação proativa bem-sucedida. Conexão estável.")
            except requests.exceptions.RequestException as e:
                logging.warning(f"Falha na verificação proativa do stream. Motivo: {base64.b64encode(str(e).encode('utf-8')).decode('utf-8')}")
                self.force_reconnect(reason="Falha na verificação proativa")
            finally:
                if 'g' in locals() and hasattr(g, 'session'):
                    g.session.close()
        self._start_proactive_reconnect_timer()

    def _create_flask_app(self):
        app = Flask("IPTVHLSProxy")
        proxy_bp = Blueprint('proxy_bp', __name__)

        @proxy_bp.before_request
        def before_request():
            g.request_id = random.randint(1000, 9999)
            g.session = self._create_session()

        @proxy_bp.after_request
        def after_request(response):
            if hasattr(g, 'session') and hasattr(g.session, 'close'):
                g.session.close()
            return response

        @proxy_bp.errorhandler(Exception)
        def handle_generic_exception(e):
            current_app.logger.critical(f"Exceção genérica: {base64.b64encode(str(e).encode('utf-8')).decode('utf-8')}")
            abort(500, description="Erro interno no servidor")

        @proxy_bp.route("/", methods=["GET"])
        def proxy():
            url = request.args.get("url")
            original_url = request.args.get("original_url")
            if not url:
                abort(400, description="Missing 'url' parameter")

            decoded_url = urllib.parse.unquote_plus(url)
            decoded_original_url = urllib.parse.unquote_plus(original_url or decoded_url)
            
            is_main_content = decoded_url.lower().endswith((".m3u8", ".m3u", ".mp4", ".mkv"))
            if is_main_content:
                self.current_stream_url = decoded_url
                if not self.proactive_reconnect_timer or not self.proactive_reconnect_timer.is_alive():
                    self._start_proactive_reconnect_timer()
            
            if decoded_url.lower().endswith((".m3u8", ".m3u")):
                return self.handle_manifest(decoded_url, decoded_original_url)
            elif decoded_url.lower().endswith((".mp4", ".mkv")):
                return self.handle_progressive_stream(decoded_url, decoded_original_url)
            else:
                return self.handle_segment_stream(decoded_url, decoded_original_url)

        app.register_blueprint(proxy_bp)
        return app

    def _create_session(self):
        session = requests.Session()
        retry_strategy = Retry(
            total=MAX_SEGMENT_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[401, 403, 404, 429, 500, 502, 503, 504, 520, 521, 522],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def _make_request(self, url: str, method: str = "GET", original_url: Optional[str] = None, headers=None, **kwargs):
        session = g.session
        kwargs['allow_redirects'] = False
        try:
            r = session.request(method, url, headers=get_headers(self, url, original_url, extra=headers), **kwargs)
            if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get('Location')
                if location:
                    new_url = urllib.parse.urljoin(url, location)
                    current_app.logger.info(f"Redirecionamento interceptado: {base64.b64encode(url.encode('utf-8')).decode('utf-8')} -> {base64.b64encode(new_url.encode('utf-8')).decode('utf-8')}")
                    r.close()
                    return self._make_request(new_url, method, original_url, headers, **kwargs)
            return r
        except requests.exceptions.RequestException as e:
            raise e

    def handle_manifest(self, url: str, original_url: str) -> Response:
        cached = self.cache.get(url)
        if cached:
            return Response(cached, mimetype="application/vnd.apple.mpegurl")
        try:
            r = self._make_request(url, method="GET", timeout=CONNECTION_TIMEOUT, original_url=original_url)
            r.raise_for_status()
            content = r.text
            final_url = r.url
        except requests.exceptions.RequestException as e:
            self.force_reconnect(reason=f"Falha manifesto principal")
            return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")
        try:
            proxy_base_url = f"http://{PROXY_HOST}:{self.active_port}/?url="
            original_url_param = f"&original_url={urllib.parse.quote_plus(original_url)}"
            m3u8_obj = m3u8.loads(content, uri=final_url)
            is_live = not m3u8_obj.is_endlist
            if m3u8_obj.is_variant:
                for playlist in m3u8_obj.playlists:
                    playlist.uri = proxy_base_url + urllib.parse.quote_plus(playlist.absolute_uri) + original_url_param
            for segment in m3u8_obj.segments:
                segment.uri = proxy_base_url + urllib.parse.quote_plus(segment.absolute_uri) + original_url_param
                if segment.key and segment.key.uri:
                    segment.key.uri = proxy_base_url + urllib.parse.quote_plus(segment.key.absolute_uri) + original_url_param
            proxied_playlist = m3u8_obj.dumps().encode("utf-8")
            self.cache.add(url, proxied_playlist, ttl=3 if is_live else 300)
            return Response(proxied_playlist, mimetype="application/vnd.apple.mpegurl")
        except Exception as e:
            return Response("#EXTM3U\n#EXT-X-ERROR: Playlist processing error\n", status=500, mimetype="application/vnd.apple.mpegurl")

    def handle_progressive_stream(self, url: str, original_url: str) -> Response:
        range_header = request.headers.get('Range')
        req_headers = {}
        if range_header:
            req_headers['Range'] = range_header
        try:
            r = self._make_request(url, method="GET", stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), original_url=original_url, headers=req_headers)
            r.raise_for_status()
            resp_headers = {
                'Content-Type': r.headers.get('Content-Type', safe_mime_type(url)),
                'Content-Length': r.headers.get('Content-Length'),
                'Content-Range': r.headers.get('Content-Range'),
                'Accept-Ranges': r.headers.get('Accept-Ranges', 'bytes')
            }
            resp_headers = {k: v for k, v in resp_headers.items() if v}
            def generate():
                try:
                    for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        yield chunk
                except Exception as e:
                    current_app.logger.error(f"Erro durante o stream de VOD {base64.b64encode(url.encode('utf-8')).decode('utf-8')}: {base64.b64encode(str(e).encode('utf-8')).decode('utf-8')}")
                    self.force_reconnect(reason="Erro durante o stream VOD")
                finally:
                    if r: r.close()
            return Response(stream_with_context(generate()), status=r.status_code, headers=resp_headers)
        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"Falha ao iniciar stream VOD {base64.b64encode(url.encode('utf-8')).decode('utf-8')}: {base64.b64encode(str(e).encode('utf-8')).decode('utf-8')}")
            self.force_reconnect(reason="Falha ao iniciar VOD")
            return Response("Erro ao contatar servidor de mídia.", status=502)

    def handle_segment_stream(self, url: str, original_url: str) -> Response:
        def generate():
            try:
                r = self._make_request(url, method="GET", stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), original_url=original_url)
                if r.status_code == 404:
                    yield b''
                    return
                r.raise_for_status()
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk: yield chunk
            except requests.exceptions.RequestException as e:
                self.force_reconnect(reason=f"Falha de segmento")
                yield b''
            finally:
                if 'r' in locals() and hasattr(r, 'close'):
                    r.close()
        return Response(stream_with_context(generate()), mimetype=safe_mime_type(url), status=200)

    def start(self) -> Optional[int]:
        self.stop()
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                self.active_port = port
                self._randomize_headers()
                logging.info(f"Proxy PROATIVO iniciado em http://{PROXY_HOST}:{port}")
                return port
            except OSError: continue
        logging.error("Falha ao iniciar proxy: nenhuma porta disponível.")
        return None

    def stop(self):
        if self.proactive_reconnect_timer and self.proactive_reconnect_timer.is_alive():
            self.proactive_reconnect_timer.cancel()
        if self.server:
            try: self.server.shutdown()
            except Exception: pass
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=1)
        self.server, self.server_thread, self.active_port, self.current_stream_url = None, None, None, None

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url: str, stream_type: str, title: Optional[str] = None):
        self.proxy.stop()
        self.proxy.cache.clear()

        if not self.proxy.start():
            import xbmcgui
            import xbmcplugin
            xbmcgui.Dialog().ok("Erro Proxy IPTV", "Não foi possível iniciar o servidor proxy.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&original_url={urllib.parse.quote_plus(url)}"
        import xbmcgui
        import xbmcplugin
        li = xbmcgui.ListItem(path=proxy_url, label=title or "GIF PEG TV PLUS")
        li.setProperty("IsPlayable", "true")

        if stream_type == 'live':
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true")
        else:  # 'vod' ou 'series'
            li.setProperty("IsLive", "false")
            if url.endswith(".mkv"):
                li.setMimeType("video/x-matroska")
            elif url.endswith(".avi"):
                li.setMimeType("video/x-msvideo")
            else:
                li.setMimeType("video/mp4")

        xbmcplugin.setResolvedUrl(self.handle, True, li)
        logging.info(f"Reprodução ({stream_type}) iniciada com URL do proxy: {base64.b64encode(proxy_url.encode('utf-8')).decode('utf-8')}")

def main():
    setup_logging()
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        addon = HLSProxyAddon(handle)
        if params.get("action") == "play_stream":
            addon.play_stream(params["url"], params["stream_type"], params.get("title"))
    except Exception as e:
        logging.critical(f"Fatal error: {base64.b64encode(str(e).encode('utf-8')).decode('utf-8')}", exc_info=True)

if __name__ == "__main__":
    main()