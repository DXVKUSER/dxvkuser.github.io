#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — Proxy HLS com Renovação Agressiva de Token
Prioriza URL Resolvida -> Reconecta na Original em caso de falha -> Reset Global
"""
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import gc
import socket
from socketserver import ThreadingMixIn

# --- Importação de Requests ---
try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError:
    pass

# --- Compatibilidade Kodi ---
try:
    import xbmc, xbmcvfs, xbmcgui, xbmcplugin
    KODI_ENV = True
    def get_translate_path(path):
        for m in ['translate_path', 'translatePath']:
            if hasattr(xbmcvfs, m): return getattr(xbmcvfs, m)(path)
        return xbmc.translatePath(path)
except:
    KODI_ENV = False
    def get_translate_path(path): return os.getcwd()

# --- Configurações Otimizadas ---
MAX_RETRIES = 2
CONNECTION_TIMEOUT = 4.0 
DEFAULT_CHUNK_SIZE = 128 * 1024 # 128KB (Performance HLS23)
PROXY_HOST = '127.0.0.1'
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def _create_session():
    s = requests.Session()
    adapter = HTTPAdapter(pool_connections=50, pool_maxsize=50)
    s.mount('http://', adapter)
    s.mount('https://', adapter)
    return s

GLOBAL_SESSION = _create_session()

# ---------------- PROXY HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    session = GLOBAL_SESSION
    
    # Cache de tokens: { "url_base": "url_com_token" }
    token_cache = {}
    cache_lock = threading.Lock()

    def setup(self):
        super().setup()
        self.request.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    def handle_one_request(self):
        try: super().handle_one_request()
        except: pass

    def _resolve_new_token(self, original_url):
        """Força a obtenção de um novo token chamando a URL original"""
        try:
            logging.info(f"🔄 Token expirado ou falho. Renovando via origem...")
            r = self.session.head(original_url, headers={'User-Agent': USER_AGENT}, 
                                  allow_redirects=True, timeout=CONNECTION_TIMEOUT, verify=False)
            new_url = r.url
            with self.cache_lock:
                self.token_cache[original_url] = new_url
            return new_url
        except Exception as e:
            logging.error(f"❌ Falha ao renovar token: {e}")
            return original_url

    def do_GET(self):
        if '?url=' not in self.path:
            self.send_error(404); return
        
        query = self.path.split('?', 1)[1]
        params = urllib.parse.parse_qs(query)
        url_original = urllib.parse.unquote_plus(params.get('url', [None])[0])
        session_id = params.get('session_id', ['default'])[0]

        if '.m3u' in url_original.lower() or 'manifest' in url_original.lower():
            self._handle_manifest(url_original, session_id)
        else:
            self._handle_segment(url_original, session_id)

    def _handle_manifest(self, url, session_id):
        try:
            # Manifestos sempre tentam a URL de cache primeiro
            target_url = self.token_cache.get(url, url)
            r = self.session.get(target_url, headers={'User-Agent': USER_AGENT}, timeout=CONNECTION_TIMEOUT, verify=False)
            
            # Se a URL de cache falhar no manifesto, tenta a original imediatamente
            if r.status_code != 200:
                target_url = self._resolve_new_token(url)
                r = self.session.get(target_url, headers={'User-Agent': USER_AGENT}, timeout=CONNECTION_TIMEOUT, verify=False)

            base_url = r.url.rsplit('/', 1)[0] + '/'
            lines = []
            for line in r.text.splitlines():
                if line.strip() and not line.startswith('#'):
                    full_url = urllib.parse.urljoin(base_url, line.strip())
                    lines.append(f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={session_id}")
                else:
                    lines.append(line)
            
            content = '\n'.join(lines).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', len(content))
            self.end_headers()
            self.wfile.write(content)
        except: self.send_error(404)

    def _handle_segment(self, url_original, session_id):
        # PRIORIDADE: URL com Token já resolvido
        url_to_call = self.token_cache.get(url_original, url_original)
        
        for attempt in range(MAX_RETRIES):
            try:
                r = self.session.get(url_to_call, headers={'User-Agent': USER_AGENT}, 
                                     stream=True, timeout=CONNECTION_TIMEOUT, verify=False)
                
                # Se falhar na primeira tentativa com o token do cache (Erro 403, 404, 410, etc)
                if attempt == 0 and r.status_code != 200:
                    logging.warning(f"⚠️ Erro {r.status_code} na URL resolvida. Forçando reconexão na original...")
                    url_to_call = self._resolve_new_token(url_original)
                    continue 

                r.raise_for_status()
                
                self.send_response(200)
                for h in ['Content-Type', 'Content-Length']:
                    if h in r.headers: self.send_header(h, r.headers[h])
                self.end_headers()
                
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk: self.wfile.write(chunk)
                return

            except (requests.exceptions.RequestException, socket.error) as e:
                logging.debug(f"Falha na tentativa {attempt+1}: {e}")
                if attempt == 0: # Na primeira falha de rede, tenta renovar a URL
                    url_to_call = self._resolve_new_token(url_original)
                time.sleep(0.1)

        # Se TUDO falhar (Cache e URL Original)
        logging.critical("🚨 Todas as tentativas falharam. Acionando Recuperação Global.")
        global_recovery.perform_global_reset()
        try: self.send_error(503)
        except: pass

# ---------------- RECUPERAÇÃO GLOBAL ----------------
class GlobalRecoveryManager:
    def perform_global_reset(self):
        global GLOBAL_SESSION
        try:
            GLOBAL_SESSION.close()
        except: pass
        GLOBAL_SESSION = _create_session()
        HLSProxyRequestHandler.session = GLOBAL_SESSION
        with HLSProxyRequestHandler.cache_lock:
            HLSProxyRequestHandler.token_cache.clear()
        gc.collect() # Libera RAM (Essencial para Android/Box)
        logging.info("♻️ Reset Global concluído. Memória e sessões limpas.")

global_recovery = GlobalRecoveryManager()

# ---------------- SERVER ENGINE ----------------
class ThreadingHTTPServer(ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.port = None

    def start(self):
        if self.port: return True
        for _ in range(5):
            try:
                port = random.randint(30000, 40000)
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                threading.Thread(target=self.server.serve_forever, daemon=True).start()
                self.port = port
                return True
            except: continue
        return False

# ---------------- KODI INTERFACE ----------------
class HLSAddon:
    _manager = HLSProxyManager()
    def __init__(self, handle=None): self.handle = handle
    def play_stream(self, url, stype, title=None):
        if not self._manager.start(): return
        p_url = f"http://{PROXY_HOST}:{self._manager.port}/?url={urllib.parse.quote_plus(url)}&session_id=strm_{int(time.time())}"
        if KODI_ENV and self.handle:
            li = xbmcgui.ListItem(path=p_url)
            if hasattr(li, 'getVideoInfoTag'):
                tag = li.getVideoInfoTag(); tag.setTitle(title or "Live"); tag.setMediaType("video")
            else: li.setInfo('video', {'Title': title or "Live"})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(self.handle, True, li)

if __name__ == '__main__':
    mgr = HLSProxyManager()
    if mgr.start():
        while True: time.sleep(1)