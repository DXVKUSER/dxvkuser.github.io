# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import threading
import urllib.parse
import requests
import m3u8
import random
import time
from collections import OrderedDict
from typing import Optional, Dict, Any, List

# ========================= CONFIG =============================
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
LOG_LEVEL = xbmc.LOGINFO

USER_AGENT = "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)"
SPOOF_X_FORWARDED_FOR = True
FIXED_X_FORWARDED_FOR_IP = "1.1.1.1"

MAX_PORT_ATTEMPTS = 5
MAX_CACHE_MB = 64
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_BYTES = 8 * 1024 * 1024
DEFAULT_CHUNK_SIZE = 1024 * 1024
PREFETCH_SEGMENTS_COUNT = 2
FETCHER_MAX_RETRIES = 2
CONNECTION_TIMEOUT = 8.0
STREAM_TIMEOUT = 8.0
RETRY_BACKOFF_FACTOR = 0.2
MAX_CONSECUTIVE_SEGMENT_FAILURES = 3
MAX_STREAM_LIFETIME_SECONDS = 2
LIMIT_COOLDOWN_SECONDS = 10

_SENSITIVE_HEADERS_LOWER = {'x-forwarded-for', 'forwarded', 'via', 'x-real-ip', 'client-ip', 'x-client-ip', 'x-cluster-client-ip', 'content-length', 'connection'}

# =========================== LOGGING ============================
def log(message: str, level: int = xbmc.LOGINFO):
    xbmc.log(f"[HLS TESTER] {message}", level=level)

# ======================= UTILS ==========================
def join_host_port(host: str, port: int) -> str:
    return f'{host}:{port}'

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "*/*",
        "Origin": origin,
        "Referer": origin
    }
    return headers

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    return {
        '.m3u8': 'application/vnd.apple.mpegurl',
        '.m3u': 'application/vnd.apple.mpegurl',
        '.ts': 'video/mp2t',
        '.aac': 'audio/aac',
        '.mp4': 'video/mp4'
    }.get(path[path.rfind('.'):], 'application/octet-stream')

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections", "max session", "#error", "offline", "geoblocked", "stream not found", "access denied", "blocked", "forbidden", "unavailable", "invalid"]
    return any(keyword in txt for keyword in keywords)

# ==================== DNS RESOLVER ================================
class DoHDNSResolver:
    def __init__(self, cache_ttl: int = 300, doh_url: str = 'https://1.1.1.1/dns-query'):
        self._cache: Dict[str, tuple[str, float]] = {}
        self._lock = threading.Lock()
        self.cache_ttl = cache_ttl
        self.doh_url = doh_url
        self.session = requests.Session()

    def _query_doh(self, hostname: str) -> Optional[str]:
        headers = {"Accept": "application/dns-json"}
        params = {"name": hostname, "type": "A"}
        try:
            response = self.session.get(self.doh_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            if data.get('Answer'):
                for answer in data['Answer']:
                    if answer['type'] == 1:
                        log(f"DoH resolved {hostname} -> {answer['data']}", xbmc.LOGDEBUG)
                        return answer['data']
        except Exception as e:
            log(f"DoH failed for {hostname}: {str(e)}", xbmc.LOGWARNING)
        return None

    def resolve(self, hostname: str) -> Optional[str]:
        with self._lock:
            cached = self._cache.get(hostname)
            if cached and time.time() < cached[1]:
                return cached[0]
        ip = self._query_doh(hostname)
        if ip:
            with self._lock:
                self._cache[hostname] = (ip, time.time() + self.cache_ttl)
            return ip
        return hostname

    def clear_cache_for_host(self, hostname: str):
        with self._lock:
            self._cache.pop(hostname, None)
            log(f"DNS cache cleared for: {hostname}", xbmc.LOGINFO)

    def clear_cache(self):
        with self._lock:
            self._cache.clear()
            log("DNS cache fully cleared", xbmc.LOGINFO)

# ===================== CACHE ===============================
class RotatingChunkCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.chunks: OrderedDict[str, bytes] = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            return self.chunks.get(url)

    def add(self, url: str, data: bytes):
        with self.lock:
            chunk_size = len(data)
            if chunk_size > self.max_bytes:
                return
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
            self.chunks[url] = data
            self.total_bytes += chunk_size
            while self.total_bytes > self.max_bytes and self.chunks:
                _, old_data = self.chunks.popitem(last=False)
                self.total_bytes -= len(old_data)

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0

    def has(self, url: str) -> bool:
        with self.lock:
            return url in self.chunks

class StreamCache:
    def __init__(self, chunk_cache: RotatingChunkCache):
        self.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self.chunk_cache = chunk_cache
        self.lock = threading.Lock()

    def get_manifest(self, url: str) -> Optional[str]:
        with self.lock:
            entry = self.manifest_cache.get(url)
            if entry and time.time() < entry['expires']:
                return entry['content']
            return None

    def add_manifest(self, url: str, content: str, ttl: int):
        with self.lock:
            self.manifest_cache[url] = {
                'content': content,
                'expires': time.time() + ttl,
                'last_refresh_time': time.time()
            }

    def invalidate_manifest(self, url: str):
        with self.lock:
            self.manifest_cache.pop(url, None)

    def is_manifest_expired(self, url: str) -> bool:
        with self.lock:
            entry = self.manifest_cache.get(url)
            return not entry or time.time() - entry.get('last_refresh_time', 0) >= MAX_STREAM_LIFETIME_SECONDS

    def get_segment(self, url: str) -> Optional[bytes]:
        return self.chunk_cache.get(url)

    def add_segment(self, url: str, data: bytes):
        self.chunk_cache.add(url, data)

    def has_segment(self, url: str) -> bool:
        return self.chunk_cache.has(url)

    def clear(self):
        with self.lock:
            self.manifest_cache.clear()
        self.chunk_cache.clear()

# ========================= FETCHER ===========================
class UpstreamFetcher:
    def __init__(self, session: requests.Session, dns_resolver: DoHDNSResolver):
        self.session = session
        self.dns_resolver = dns_resolver

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        headers = get_player_headers(url)
        if original_headers:
            cleaned = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned.items() if k in ['Authorization', 'Cookie']})
        if SPOOF_X_FORWARDED_FOR:
            headers['X-Forwarded-For'] = FIXED_X_FORWARDED_FOR_IP
        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    url, stream=stream, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                return resp
            except requests.RequestException as e:
                if attempt < FETCHER_MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))
                else:
                    raise requests.RequestException(f"Failed to fetch {url}: {str(e)}")

class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url

    def rewrite(self) -> str:
        for item in (self.m3u8_obj.playlists + self.m3u8_obj.media + self.m3u8_obj.segments):
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri and not item.key.uri.startswith("data:"):
                item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
        return max(1, int(target_duration * 0.6)) if self.is_live else 3600

# ===================== PROXY MANAGER =======================
class HLSProxyManager:
    def __init__(self):
        self._http_session = self._create_http_session()
        self.dns_resolver = DoHDNSResolver()
        self.chunk_cache = RotatingChunkCache()
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(self._http_session, self.dns_resolver)
        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0
        self._limit_hits: Dict[str, float] = {}
        self.active_port: Optional[int] = None
        self.flask_app = None
        self.flask_thread: Optional[threading.Thread] = None

    def _create_http_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({'User-Agent': USER_AGENT, 'Accept': '*/*'})
        session.trust_env = False
        return session

    def reset_http_session(self):
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher.session = self._http_session
        self.dns_resolver.clear_cache()
        log("HTTP session and DNS cache have been reset.", xbmc.LOGINFO)

    def force_reconnection(self, url: str):
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.hostname:
            self.dns_resolver.clear_cache_for_host(parsed_url.hostname)
        self.stream_cache.clear()
        self.reset_http_session()

    def increment_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures += 1

    def reset_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures = 0

    def should_force_reconnect(self) -> bool:
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES

    def record_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        self._limit_hits[base_url] = time.time()

    def is_in_cooldown(self, url: str) -> bool:
        base_url = self._get_base_url(url)
        hit_time = self._limit_hits.get(base_url)
        return hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS

    def clear_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        self._limit_hits.pop(base_url, None)

    @staticmethod
    def _get_base_url(url: str) -> str:
        parts = urllib.parse.urlparse(url)
        return f"{parts.scheme}://{parts.netloc}"

    def start(self) -> Optional[int]:
        if self.flask_thread and self.flask_thread.is_alive():
            return self.active_port
        try:
            from flask import Flask, Response, request
        except ImportError:
            xbmcgui.Dialog().ok("Erro", "Flask (script.module.flask) não está instalado no Kodi.")
            return None

        def create_flask_app(proxy_manager: HLSProxyManager):
            app = Flask(__name__)
            stream_cache = proxy_manager.stream_cache
            fetcher = proxy_manager.fetcher

            @app.route('/hlsproxy')
            def hlsproxy():
                original_url = request.args.get('url')
                if not original_url:
                    return Response("Missing url param", status=400)
                
                # Handle HEAD requests by simply returning an empty manifest
                if request.method == 'HEAD':
                    return Response("#EXTM3U\n", status=200, content_type='application/vnd.apple.mpegurl')

                is_manifest = ".m3u8" in original_url.lower() or ".m3u" in original_url.lower()
                if is_manifest:
                    if proxy_manager.is_in_cooldown(original_url):
                        return Response("#EXTM3U\n", status=200, content_type='application/vnd.apple.mpegurl')
                    if stream_cache.is_manifest_expired(original_url):
                        proxy_manager.force_reconnection(original_url)
                    cached_content = stream_cache.get_manifest(original_url)
                    if cached_content:
                        return Response(cached_content, status=200, content_type='application/vnd.apple.mpegurl')
                    try:
                        response = fetcher.fetch(original_url, original_headers=request.headers)
                        content = response.text
                        if is_manifest_limit_error(content):
                            proxy_manager.record_limit_hit(original_url)
                            proxy_manager.force_reconnection(original_url)
                            return Response("#EXTM3U\n", status=200, content_type='application/vnd.apple.mpegurl')
                        proxy_base = f"http://{join_host_port(PROXY_HOST, proxy_manager.active_port)}/hlsproxy?url="
                        rewriter = ManifestRewriter(content, response.url, proxy_base)
                        rewritten_content = rewriter.rewrite()
                        stream_cache.add_manifest(original_url, rewritten_content, rewriter.get_ttl())
                        proxy_manager.clear_limit_hit(original_url)
                        if rewriter.is_live:
                            for segment in rewriter.m3u8_obj.segments[-PREFETCH_SEGMENTS_COUNT:]:
                                if not stream_cache.has_segment(segment.absolute_uri):
                                    proxy_manager._prefetch_segment(segment.absolute_uri)
                        return Response(rewritten_content, status=200, content_type='application/vnd.apple.mpegurl')
                    except Exception as e:
                        log(f"Manifest fetch error: {str(e)}", xbmc.LOGERROR)
                        proxy_manager.force_reconnection(original_url)
                        return Response("#EXTM3U\n", status=200, content_type='application/vnd.apple.mpegurl')
                else:
                    mime_type = safe_mime_type(original_url)
                    cached_segment = stream_cache.get_segment(original_url)
                    if cached_segment:
                        proxy_manager.reset_failure_count()
                        return Response(cached_segment, status=200, content_type=mime_type)
                    try:
                        response = fetcher.fetch(original_url, stream=True, original_headers=request.headers)
                        segment_data = bytearray()
                        for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            segment_data.extend(chunk)
                            if len(segment_data) > MAX_SEGMENT_SIZE_BYTES:
                                raise IOError("Segment exceeded max size")
                        final_data = bytes(segment_data)
                        stream_cache.add_segment(original_url, final_data)
                        proxy_manager.reset_failure_count()
                        return Response(final_data, status=200, content_type=mime_type)
                    except Exception as e:
                        log(f"Segment fetch error: {str(e)}", xbmc.LOGERROR)
                        proxy_manager.increment_failure_count()
                        if proxy_manager.should_force_reconnect():
                            proxy_manager.force_reconnection(original_url)
                            proxy_manager.reset_failure_count()
                        return Response("Segment unavailable", status=503, content_type="text/plain")
            return app

        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.flask_app = create_flask_app(self)
                th = threading.Thread(target=self.flask_app.run, kwargs={
                    'host': PROXY_HOST,
                    'port': port,
                    'threaded': True,
                    'use_reloader': False
                }, daemon=True)
                th.start()
                self.flask_thread = th
                self.active_port = port
                log(f"Proxy started on port {port}", xbmc.LOGINFO)
                return port
            except Exception as e:
                log(f"Failed to start Flask on port {port}: {str(e)}", xbmc.LOGWARNING)
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Error: Could not start proxy",5000)')
        return None

    def _prefetch_segment(self, segment_url: str):
        try:
            if not self.stream_cache.has_segment(segment_url):
                response = self.fetcher.fetch(segment_url)
                self.stream_cache.add_segment(segment_url, response.content)
        except Exception:
            pass

    def stop(self):
        self.stream_cache.clear()
        self.reset_http_session()
        self.active_port = None
        self.flask_thread = None
        log("Proxy stopped", xbmc.LOGINFO)

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/hlsproxy?url={encoded_url}"

# ================== KODI ADDON ==========================
class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event

    def onPlayBackEnded(self):
        self.stop_event.set()
    def onPlayBackError(self):
        self.stop_event.set()
    def onPlayBackStopped(self):
        self.stop_event.set()

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)

    def _convert_to_m3u8(self, url: str) -> str:
        try:
            url = url.split('|')[0].split('%7C')[0]
            if '.m3u8' in url.lower() or '.m3u' in url.lower() or '/hl' in url:
                return url
            parts = urllib.parse.urlparse(url)
            path = parts.path.rstrip('/')
            if not path.endswith('.m3u8'):
                url = f"{parts.scheme}://{parts.netloc}{path}.m3u8"
        except Exception:
            pass
        return url

    def play_stream(self, url: str, channel_name: Optional[str] = None):
        processed_url = self._convert_to_m3u8(url)
        if not self.proxy_manager.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        display_name = f"{channel_name or 'Stream'} [COLOR cyan](HLS Tester)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_name)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        threading.Thread(target=self.monitor_playback, daemon=True).start()

    def monitor_playback(self):
        self.playback_stop_event.wait()
        self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Big Buck Bunny (VOD)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Exemplo Live", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
        ]
        for name, url in test_streams:
            list_item = xbmcgui.ListItem(label=name)
            list_item.setProperty('IsPlayable', 'true')
            list_item.setMimeType(safe_mime_type(url))
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, list_item, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get('action')
        addon = HLSProxyAddon(handle)
        if action == 'play':
            addon.play_stream(params.get('url'), params.get('title'))
        else:
            addon.show_test_streams()
    except Exception as e:
        log(f"Addon error: {str(e)}", xbmc.LOGERROR)

if __name__ == '__main__':
    main()