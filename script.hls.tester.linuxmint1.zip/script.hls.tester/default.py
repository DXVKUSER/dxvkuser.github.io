# -*- coding: utf-8 -*-

"""
HLS Proxy Addon para Kodi
Versão com proteção de privacidade - Esconde o IP real do usuário
"""

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
from collections import OrderedDict
from requests.exceptions import Timeout, ConnectionError, HTTPError, InvalidURL

# --- Configurações Iniciais do Addon ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HANDLE = int(sys.argv[1])

# ALTERAÇÃO CHAVE AQUI: Muda o PROXY_HOST para '0.0.0.0' para permitir acesso externo (restream)
PROXY_HOST = '0.0.0.0' 
DEFAULT_PROXY_PORT = random.randint(20000, 65000)
MAX_PORT_ATTEMPTS = 5
LOCK_FILE = os.path.join(ADDON_PROFILE, 'proxy.lock')

# --- Leitura das Configurações do Addon com Fallbacks ---
try:
    max_cache_mb = int(ADDON.getSetting('max_cache_mb'))
    if max_cache_mb <= 0: raise ValueError
except (ValueError, TypeError):
    max_cache_mb = 128
MAX_CACHE_SIZE_BYTES = max_cache_mb * 1024 * 1024

try:
    max_segment_size_mb = int(ADDON.getSetting('max_segment_size_mb'))
    if max_segment_size_mb <= 0: raise ValueError
except (ValueError, TypeError):
    max_segment_size_mb = 15
MAX_SEGMENT_SIZE_BYTES = max_segment_size_mb * 1024 * 1024

try:
    CACHE_TYPE = ADDON.getSetting('cache_type').lower()
except Exception:
    CACHE_TYPE = 'ram'

try:
    SIMULATE_ERRORS = ADDON.getSetting('simulate_errors') == 'true'
except Exception:
    SIMULATE_ERRORS = False

IS_DEV_ENV = os.environ.get('KODI_ENV') == 'development'
if SIMULATE_ERRORS and not IS_DEV_ENV:
    SIMULATE_ERRORS = False
    logging.warning("Simulate errors disabled: not in development environment.")

try:
    ENABLE_IPV6 = ADDON.getSetting('enable_ipv6') == 'true'
except Exception:
    ENABLE_IPV6 = True

try:
    CONNECTION_TIMEOUT = float(ADDON.getSetting('connection_timeout') or 10)
except (ValueError, TypeError):
    CONNECTION_TIMEOUT = 10

try:
    STREAM_TIMEOUT = float(ADDON.getSetting('stream_timeout') or 15)
except (ValueError, TypeError):
    STREAM_TIMEOUT = 20

try:
    LOG_MAX_BYTES = int(ADDON.getSetting('log_max_bytes') or 1048576)
except (ValueError, TypeError):
    LOG_MAX_BYTES = 1048576

try:
    LOG_BACKUP_COUNT = int(ADDON.getSetting('log_backup_count') or 3)
except (ValueError, TypeError):
    LOG_BACKUP_COUNT = 3

CHUNK_SIZE = 65536
LOG_FILE = xbmcvfs.translatePath(ADDON.getSetting('log_file_path') or 'special://temp/hlsproxy.log')
USER_BLOCKLIST = set(filter(None, (ADDON.getSetting('host_blocklist') or '').split(',')))
PROXY_TOKEN = (ADDON.getSetting('proxy_token') or '').strip() or None

try:
    loglevel_raw = ADDON.getSetting("loglevel")
    loglevel = loglevel_raw.upper().strip() if loglevel_raw else "WARNING"
    LOG_LEVEL = int(getattr(logging, loglevel, logging.WARNING))
except Exception:
    LOG_LEVEL = logging.WARNING

log_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
)
logging.basicConfig(
    handlers=[log_handler],
    level=LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s'
)

# --- Constantes de Headers e User-Agents ---
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (WebOS; U; SmartTV; LG NetCast.TV-2013) AppleWebKit/537.41 (KHTML, like Gecko) WebAppManager"
]
ACCEPT_LANGUAGES = ["pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "en-US,en;q=0.9,pt;q=0.8", "es-ES,es;q=0.9,en;q=0.8"]
PLAYER_HEADERS = [{"User-Agent": USER_AGENTS[i], "Accept": "*/*", "Accept-Language": lang, "Origin": "", "Referer": ""} for i, lang in zip(range(len(USER_AGENTS)), ACCEPT_LANGUAGES * 2)]

def clean_headers(headers):
    """Remove cabeçalhos que podem identificar o usuário"""
    sensitive = ['X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP', 
                'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP']
    return {k: v for k, v in headers.items() if k not in sensitive}

def random_player_headers(url):
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.hostname}"
    headers = random.choice(PLAYER_HEADERS).copy()
    headers.update({
        'X-Forwarded-For': '1.1.1.1',
        'Via': 'hls-proxy/1.0',
        'X-Real-IP': '1.1.1.1'
    })
    headers['Origin'] = origin
    headers['Referer'] = origin
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def jitter(base, percent=0.1):
    return base + base * random.uniform(-percent, percent)

# --- Sessão HTTP Global com Proteção de IP ---
HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': random.choice(USER_AGENTS),
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'X-Forwarded-For': '1.1.1.1',
    'Via': 'hls-proxy/1.0',
    'X-Real-IP': '1.1.1.1'
})
HTTP_SESSION.trust_env = False  # Ignora proxies de sistema

class DoHResolver:
    def __init__(self, resolver_urls=None, cache_ttl=300, retries=2, retry_delay=0.7):
        self.resolver_urls = resolver_urls or [
            'https://cloudflare-dns.com/dns-query',
            'https://dns.google/dns-query',
            'https://doh.opendns.com/dns-query'
        ]
        self.cache_ttl = cache_ttl
        self.retries = retries
        self.retry_delay = retry_delay
        self._cache = {}
        self.q_types = ('AAAA', 'A') if ENABLE_IPV6 else ('A',)
        logging.debug(f"DoHResolver initialized with resolvers: {self.resolver_urls}, IPv6 enabled: {ENABLE_IPV6}")

    def resolve(self, hostname, depth=0, max_depth=5):
        if depth > max_depth:
            logging.error(f"Max CNAME resolution depth reached for {hostname}. Aborting DNS resolution.")
            return None
        if self._is_valid_ip(hostname):
            logging.debug(f"Hostname {hostname} is already an IP address.")
            return hostname

        cached_entry = self._cache.get(hostname)
        if cached_entry and time.time() < cached_entry[1]:
            logging.debug(f"Hostname {hostname} found in DoH cache: {cached_entry[0]}")
            return cached_entry[0]
        
        logging.debug(f"Attempting to resolve hostname {hostname} via DoH (depth: {depth})")
        for resolver_url in self.resolver_urls:
            for q_type in self.q_types:
                for attempt in range(self.retries):
                    try:
                        params = {'name': hostname, 'type': q_type}
                        headers = {'accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                        response = HTTP_SESSION.get(resolver_url, params=params, headers=headers, timeout=5)
                        response.raise_for_status()
                        data = response.json()
                        ip_address = self._parse_doh_response(data, hostname, q_type, depth)
                        if ip_address:
                            ttl = data.get("Answer", [{}])[0].get("TTL", self.cache_ttl)
                            self._cache[hostname] = (ip_address, time.time() + ttl)
                            logging.debug(f"Successfully resolved {hostname} to {ip_address} (TTL: {ttl}s) using {resolver_url} for type {q_type}.")
                            return ip_address
                    except Exception as e:
                        logging.warning(f"DoH resolution attempt {attempt + 1}/{self.retries} for {hostname} (type {q_type}) via {resolver_url} failed: {e}")
                        if attempt < self.retries - 1:
                            time.sleep(jitter(self.retry_delay))
                        else:
                            continue
        logging.warning(f"Failed to resolve hostname {hostname} after all attempts.")
        return None

    def _parse_doh_response(self, data, hostname, q_type, depth):
        type_map = {'A': 1, 'AAAA': 28}
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map[q_type] and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data")
        for answer in data.get("Answer", []):
            if answer.get("type") == 5:
                cname = answer.get("data", "").rstrip('.')
                if cname:
                    logging.debug(f"Found CNAME for {hostname}: {cname}. Resolving CNAME.")
                    return self.resolve(cname, depth + 1)
        return None

    @staticmethod
    def _is_valid_ip(address):
        try:
            socket.inet_pton(socket.AF_INET6, address)
            return True
        except socket.error:
            try:
                socket.inet_aton(address)
                return True
            except socket.error:
                return False

class BaseCache:
    def __init__(self, max_bytes):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        logging.info(f"BaseCache initialized with max_bytes: {max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url): raise NotImplementedError
    def add(self, url, data): raise NotImplementedError
    def clear(self): raise NotImplementedError
    def get_stats(self): raise NotImplementedError

class RotatingChunkCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES):
        super().__init__(max_bytes)
        self.chunks = OrderedDict()
        self.total_bytes = 0
        logging.info(f"RotatingChunkCache (RAM) initialized with max size: {max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url):
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
                logging.debug(f"Segment found in RAM cache: {url}")
            return data

    def add(self, url, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
            self.chunks[url] = data
            self.total_bytes += len(data)
            self._shrink_to_limit()
            logging.debug(f"Segment added to RAM cache: {url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
    
    def _shrink_to_limit(self):
        while self.total_bytes > self.max_bytes and self.chunks:
            old_url, old_data = self.chunks.popitem(last=False)
            self.total_bytes -= len(old_data)
            logging.debug(f"Shrinking RAM cache: removed {old_url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0
            logging.info("RAM cache cleared.")
            
    def get_stats(self):
        with self.lock:
            return {"entries": len(self.chunks), "size_MB": round(self.total_bytes / 1048576, 2)}

class PersistentRotatingCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES):
        super().__init__(max_bytes)
        self.cache_dir = os.path.join(ADDON_PROFILE, 'cache')
        logging.info(f"PersistentRotatingCache (Disk) initialized. Cache directory: {self.cache_dir}. Max size: {max_bytes / (1024 * 1024):.2f} MB")
        self._ensure_cache_dir()
        self.metadata = OrderedDict()
        self.total_bytes = 0
        self._load_metadata()

    def _ensure_cache_dir(self):
        if not xbmcvfs.exists(self.cache_dir):
            try:
                xbmcvfs.mkdirs(self.cache_dir)
                logging.info(f"Created cache directory: {self.cache_dir}")
            except Exception as e:
                logging.error(f"Failed to create cache directory {self.cache_dir}: {e}", exc_info=True)
                notify(f"Erro: Não foi possível criar pasta de cache em {self.cache_dir}. Verifique permissões.", 7000)
                raise
        test_file = os.path.join(self.cache_dir, '.test_write_permission')
        try:
            with xbmcvfs.File(test_file, 'w') as f:
                f.write(b'test')
            xbmcvfs.delete(test_file)
            logging.debug(f"Cache directory {self.cache_dir} is writable.")
        except Exception as e:
            logging.error(f"Cache directory {self.cache_dir} is not writable: {e}", exc_info=True)
            notify(f"Erro: A pasta de cache '{self.cache_dir}' não é gravável. O cache em disco não funcionará.", 7000)
            raise

    def _load_metadata(self):
        files, _ = xbmcvfs.listdir(self.cache_dir)
        for f in files:
            if f.startswith('.'): continue
            filepath = os.path.join(self.cache_dir, f)
            try:
                stat = xbmcvfs.Stat(filepath)
                self.metadata[f] = {'size': stat.st_size(), 'atime': stat.st_atime()}
                self.total_bytes += stat.st_size()
            except Exception as e:
                logging.warning(f"Skipping invalid or inaccessible cache file: {filepath} ({e})")
                try: xbmcvfs.delete(filepath)
                except Exception: pass
        sorted_meta = sorted(self.metadata.items(), key=lambda item: item[1]['atime'])
        self.metadata = OrderedDict(sorted_meta)
        logging.info(f"Loaded disk cache metadata. Total entries: {len(self.metadata)}, Total size: {self.total_bytes / (1024 * 1024):.2f} MB")
        self._shrink_to_limit()

    def _url_to_filepath(self, url):
        filename = hashlib.sha256(url.encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, filename), filename

    def get(self, url):
        filepath, filename = self._url_to_filepath(url)
        with self.lock:
            if filename in self.metadata:
                try:
                    with xbmcvfs.File(filepath, 'rb') as f:
                        content = f.readBytes()
                    self.metadata.move_to_end(filename)
                    self.metadata[filename]['atime'] = time.time()
                    logging.debug(f"Segment found in disk cache: {url}")
                    return content
                except Exception as e:
                    logging.error(f"Failed to read segment from disk cache: {filepath} ({e})", exc_info=True)
                    self.metadata.pop(filename, None)
                    try: xbmcvfs.delete(filepath)
                    except Exception: pass
        return None

    def add(self, url, data: bytes):
        filepath, filename = self._url_to_filepath(url)
        with self.lock:
            if filename in self.metadata:
                self.total_bytes -= self.metadata[filename]['size']
                try: xbmcvfs.delete(filepath)
                except Exception as e: logging.warning(f"Could not delete old cache file {filepath}: {e}")

            try:
                with xbmcvfs.File(filepath, 'wb') as f:
                    f.write(data)
                self.metadata[filename] = {'size': len(data), 'atime': time.time()}
                self.total_bytes += len(data)
                self._shrink_to_limit()
                logging.debug(f"Segment added to disk cache: {url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
            except Exception as e:
                logging.error(f"Failed to write segment to disk cache: {filepath} ({e})", exc_info=True)
                self.metadata.pop(filename, None)
                try: xbmcvfs.delete(filepath)
                except Exception: pass

    def _shrink_to_limit(self):
        while self.total_bytes > self.max_bytes and self.metadata:
            filename, meta = self.metadata.popitem(last=False)
            self.total_bytes -= meta['size']
            try:
                filepath_to_delete = os.path.join(self.cache_dir, filename)
                xbmcvfs.delete(filepath_to_delete)
                logging.debug(f"Shrinking disk cache: removed {filepath_to_delete}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
            except Exception as e:
                logging.error(f"Failed to delete old cache file {filename}: {e}", exc_info=True)
                pass
            
    def clear(self):
        with self.lock:
            logging.info("Clearing disk cache...")
            for filename in list(self.metadata.keys()):
                try:
                    xbmcvfs.delete(os.path.join(self.cache_dir, filename))
                    logging.debug(f"Deleted cache file: {filename}")
                except Exception as e:
                    logging.warning(f"Could not delete disk cache file {filename}: {e}")
            self.metadata.clear()
            self.total_bytes = 0
            logging.info("Disk cache cleared.")

    def get_stats(self):
        with self.lock:
            return {"entries": len(self.metadata), "size_MB": round(self.total_bytes / 1048576, 2)}

class StreamCache:
    def __init__(self, chunk_cache: BaseCache):
        self.manifest_cache = {}
        self.chunk_cache = chunk_cache
        logging.info("StreamCache initialized.")
        
    def get_manifest(self, url):
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            logging.debug(f"Manifest found in RAM cache: {url}")
            return entry['content']
        logging.debug(f"Manifest not found or expired in RAM cache: {url}")
        return None
        
    def add_manifest(self, url, content, ttl=1):
        self.manifest_cache[url] = {'content': content, 'expires': time.time() + ttl}
        logging.debug(f"Manifest added to RAM cache: {url} with TTL {ttl}s.")
        
    def get_segment(self, url): return self.chunk_cache.get(url)
    def add_segment(self, url, data): self.chunk_cache.add(url, data)
    def clear(self):
        self.manifest_cache.clear()
        self.chunk_cache.clear()
        logging.info("Stream cache (manifests and chunks) cleared.")

class UpstreamFetcher:
    def __init__(self, session, doh_resolver):
        self.session = session
        self.doh_resolver = doh_resolver
        logging.info("UpstreamFetcher initialized with IP protection")

    def fetch(self, url, stream=False, original_headers=None):
        try:
            headers = random_player_headers(url)
            
            if original_headers:
                original_headers = clean_headers(original_headers)
                if 'Authorization' in original_headers: 
                    headers['Authorization'] = original_headers['Authorization']
                if 'Cookie' in original_headers: 
                    headers['Cookie'] = original_headers['Cookie']
            
            parsed_url = urllib.parse.urlparse(url)
            resolved_ip = None
            if parsed_url.hostname:
                resolved_ip = self.doh_resolver.resolve(parsed_url.hostname)
            
            req_url = url
            if resolved_ip and resolved_ip != parsed_url.hostname:
                # Se for um IPv6, adiciona colchetes ao IP para garantir que a URL seja válida
                if ':' in resolved_ip:
                    new_netloc = f"[{resolved_ip}]"
                    if parsed_url.port:
                        new_netloc += f":{parsed_url.port}"
                else: # IPv4
                    new_netloc = resolved_ip
                    if parsed_url.port:
                        new_netloc += f":{parsed_url.port}"
                
                # Reconstrói a URL com o IP resolvido no netloc
                req_url_parts = parsed_url._replace(netloc=new_netloc)
                req_url = req_url_parts.geturl()

                headers['Host'] = parsed_url.hostname # Mantém o Host original no cabeçalho
                logging.debug(f"Adjusted request URL for DoH: {req_url} (Original Host: {parsed_url.hostname})")

            # --- INÍCIO DA LÓGICA DE RETENTATIVA APRIMORADA ---
            max_retries = 5  # NOVO: Número máximo de tentativas
            base_delay = 0.5 # NOVO: Atraso inicial em segundos

            for attempt in range(max_retries):
                try:
                    resp = self.session.get(req_url, stream=stream, 
                                          timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                                          headers=headers, allow_redirects=True,
                                          verify=False) # Adicionado verify=False para compatibilidade ampla
                    
                    resp.raise_for_status() # Isso levantará um HTTPError para respostas 4xx/5xx

                    # Se a resposta for bem-sucedida (ex: 200 OK), retorna imediatamente
                    return resp

                except (Timeout, ConnectionError, HTTPError) as e:
                    logging.warning(f"Attempt {attempt + 1}/{max_retries} failed for {url}: {e}")
                    
                    # Se for a última tentativa, desiste e levanta a exceção para que o chamador saiba da falha
                    if attempt == max_retries - 1:
                        logging.error(f"All {max_retries} attempts failed for {url}. Giving up.")
                        raise e # Lança o último erro

                    # NOVO: Lógica de Backoff Exponencial com Jitter
                    # O tempo de espera dobra a cada tentativa, com um pequeno fator aleatório
                    delay = (base_delay * (2 ** attempt)) + random.uniform(0.1, 0.5)
                    logging.info(f"Waiting for {delay:.2f} seconds before next retry.")
                    time.sleep(delay)
                
                except InvalidURL as ex:
                    # Erro de URL malformada, não é recuperável com retentativas
                    logging.error(f"Invalid URL encountered while fetching {url}: {ex}. This error is not recoverable with retries.", exc_info=True)
                    return None
                except Exception as ex:
                    # Para qualquer outro erro inesperado, não tenta novamente.
                    logging.error(f"An unexpected non-recoverable error occurred while fetching {url}: {ex}", exc_info=True)
                    return None # Retorna None para indicar falha
            # --- FIM DA LÓGICA DE RETENTATIVA APRIMORADA ---

        except Exception as ex:
            # Pega a exceção final levantada pelo loop ou qualquer outro erro na preparação
            logging.error(f"Failed to fetch {url} after all retries or due to a critical error: {ex}", exc_info=True)
            return None # Retorna None para indicar falha

class ManifestRewriter:
    def __init__(self, content, manifest_url, proxy_base_url):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        logging.debug(f"ManifestRewriter initialized for {manifest_url}. Proxy base: {proxy_base_url}")

    def rewrite(self):
        for playlist in getattr(self.m3u8_obj, 'playlists', []):
            if playlist.uri:
                original_uri = playlist.absolute_uri
                playlist.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote playlist URI from {original_uri} to {playlist.uri}")
        
        for media in getattr(self.m3u8_obj, 'media', []):
            if hasattr(media, 'uri') and media.uri:
                original_uri = media.absolute_uri
                media.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote media URI from {original_uri} to {media.uri}")

        for segment in getattr(self.m3u8_obj, 'segments', []):
            if segment.uri:
                original_uri = segment.absolute_uri
                segment.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote segment URI from {original_uri} to {segment.uri}")
            if segment.key and segment.key.uri:
                original_uri = segment.key.absolute_uri
                segment.key.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote key URI from {original_uri} to {segment.key.uri}")
        
        rewritten_manifest = self.m3u8_obj.dumps()
        logging.debug(f"Manifest rewritten successfully. First 200 chars: {rewritten_manifest[:200]}")
        return rewritten_manifest

    @property
    def is_live(self):
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self):
        target_duration = getattr(self.m3u8_obj, 'target_duration', 0)
        if self.is_live and target_duration:
            ttl = max(1, int(target_duration * 0.75))
            logging.debug(f"Live stream detected. Target duration: {target_duration}s, calculated TTL: {ttl}s.")
            return ttl
        logging.debug("VOD stream detected or no target duration. Default TTL: 600s.")
        return 600

def notify(msg, time_ms=3000): 
    xbmc.executebuiltin(f'Notification({ADDON_NAME},{msg},{time_ms})')

def validate_url(url: str) -> bool:
    u = urllib.parse.urlparse(url)
    if not u.scheme in ('http', 'https'):
        logging.warning(f"Invalid URL scheme for {url}. Must be http or https.")
        return False
    if not u.netloc:
        logging.warning(f"URL has no network location (netloc): {url}.")
        return False
    if u.hostname in USER_BLOCKLIST:
        logging.warning(f"Hostname {u.hostname} is in the user blocklist for URL: {url}.")
        return False
    return True

def safe_mime_type(url, fallback='application/octet-stream'):
    ext = url.lower().split('?')[0]
    if ext.endswith('.m3u8'): return 'application/vnd.apple.mpegurl'
    if ext.endswith('.ts'): return 'video/mp2t'
    logging.debug(f"Could not determine specific MIME type for {url}. Using fallback: {fallback}")
    return fallback

def is_port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('127.0.0.1', port)) # Ainda verificamos na interface local para garantir que a porta está livre
            return True
        except socket.error:
            return False

class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, stream_cache, fetcher, *args, **kwargs):
        self.cache = stream_cache
        self.fetcher = fetcher
        self.log_level_map = {
            'info': logging.info,
            'warning': logging.warning,
            'error': logging.error,
            'debug': logging.debug
        }
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        pass
        
    def _log_request(self, message, level='info'):
        log_func = self.log_level_map.get(level, logging.info)
        client_address = self.address_string()
        log_func(f"[{client_address}] {self.command} {self.path} - {message}")

    def do_GET(self):
        self._log_request("Received request", level='debug')
        if PROXY_TOKEN and self.headers.get('X-Proxy-Token') != PROXY_TOKEN:
            self.send_response(401)
            self.end_headers()
            self._log_request("Unauthorized request due to missing/invalid X-Proxy-Token.", level='warning')
            return

        try:
            parsed_path = urllib.parse.urlparse(self.path)
            query_params = urllib.parse.parse_qs(parsed_path.query)
            original_url = query_params.get('url', [''])[0]

            if not original_url:
                self.send_error(400, "Missing 'url' parameter in proxy request")
                self._log_request("Missing 'url' parameter.", level='warning')
                return

            if SIMULATE_ERRORS and random.random() < 0.008:
                self.send_error(503, "Service Unavailable (simulated)")
                self._log_request(f"Simulated 503 error for {original_url}", level='warning')
                return

            # Limpa cabeçalhos sensíveis antes de processar
            self.headers = clean_headers(self.headers)

            if ".m3u8" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected while serving {original_url}", level='warning')
        except Exception as ex:
            logging.error("General proxy error for %s: %s", original_url, str(ex), exc_info=True)
            if not self.wfile.closed:
                try: self.send_error(500, "Internal Server Error")
                except Exception: pass

    def _handle_manifest(self, url):
        self._log_request(f"Handling manifest: {url}", level='info')
        cached = self.cache.get_manifest(url)
        if cached:
            self._log_request(f"Serving manifest from cache: {url}", level='debug')
            return self._send_response(200, cached, 'application/vnd.apple.mpegurl')

        response = self.fetcher.fetch(url, original_headers=self.headers)
        if not response or not response.ok:
            status_code = response.status_code if response else 502
            self.send_error(status_code, "Bad Gateway or Upstream Error")
            self._log_request(f"Failed to fetch manifest {url} from upstream. Status: {status_code}", level='error')
            return

        try:
            # Ao reescrever o manifesto, usamos o host real do proxy para que outros dispositivos possam se conectar
            # self.server.server_address[0] conterá '0.0.0.0' ou o IP real da interface
            # Se PROXY_HOST é '0.0.0.0', precisamos do IP real da máquina para reescrita de manifestos externos
            # No entanto, para simplicidade e garantir que funcione localmente/remotamente, '0.0.0.0' é tratado
            # de forma que o cliente precisará usar o IP real da máquina.
            # Aqui, para a URL que o player Kodi verá, usamos o PROXY_HOST.
            proxy_actual_host_for_manifest = self.server.server_address[0] if self.server.server_address[0] != '0.0.0.0' else PROXY_HOST # Ou use uma lógica para obter o IP externo se realmente precisar
            
            rewriter = ManifestRewriter(response.text, response.url, f"http://{proxy_actual_host_for_manifest}:{self.server.server_address[1]}/?url=")
            rewritten_content = rewriter.rewrite()
            ttl = rewriter.get_ttl()
            self.cache.add_manifest(url, rewritten_content, ttl=ttl)
            self._log_request(f"Manifest {url} fetched, rewritten, cached (TTL: {ttl}s) and served.", level='info')
            self._send_response(200, rewritten_content, 'application/vnd.apple.mpegurl')
        except Exception as e:
            logging.error(f"Error processing manifest {url}: {e}", exc_info=True)
            self.send_error(500, "Error processing manifest")

    def _handle_segment(self, url):
        self._log_request(f"Handling segment: {url}", level='info')
        mime_type = safe_mime_type(url)
        cached = self.cache.get_segment(url)
        if cached:
            self._log_request(f"Serving segment from cache: {url}", level='debug')
            return self._send_response(200, cached, mime_type)

        response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
        if not response or not response.ok:
            status_code = response.status_code if response else 404
            self.send_error(status_code, "Segment Not Found or Upstream Error")
            self._log_request(f"Failed to fetch segment {url} from upstream. Status: {status_code}", level='error')
            return

        try:
            self.send_response(response.status_code)
            for h, v in response.headers.items():
                if h.lower() not in ('transfer-encoding', 'connection', 'content-encoding', 'content-length'):
                    self.send_header(h, v)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0')
            self.end_headers()

            bytes_sent = 0
            
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                
                try: # Adicionado try-except para BrokenPipeError e ConnectionResetError
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    logging.warning(f"[{self.client_address[0]}] GET {self.path} - Client disconnected (BrokenPipeError/ConnectionResetError) while streaming segment {url}.")
                    break # Sai do loop, pois o cliente não está mais escutando
                
                bytes_sent += len(chunk)
                
                if bytes_sent <= MAX_SEGMENT_SIZE_BYTES:
                    if not hasattr(self, '_cached_data'):
                        self._cached_data = bytearray()
                    self._cached_data.extend(chunk)
            
            self._log_request(f"Segment {url} streamed to client. Total bytes sent: {bytes_sent}.", level='debug')
            
            if hasattr(self, '_cached_data') and len(self._cached_data) <= MAX_SEGMENT_SIZE_BYTES:
                self.cache.add_segment(url, bytes(self._cached_data))
                self._log_request(f"Segment {url} (size: {len(self._cached_data)} bytes) added to cache.", level='debug')
            elif hasattr(self, '_cached_data'):
                self._log_request(f"Segment {url} (size: {len(self._cached_data)} bytes) exceeded MAX_SEGMENT_SIZE_BYTES ({MAX_SEGMENT_SIZE_BYTES} bytes) and was NOT cached.", level='info')

        except Exception as ex:
            logging.error("Error serving segment %s: %s", url, str(ex), exc_info=True)
            if not self.wfile.closed:
                try: self.send_error(500, "Internal Server Error during segment streaming")
                except Exception: pass
        finally:
            if hasattr(self, '_cached_data'):
                del self._cached_data

    def _send_response(self, code, content, content_type):
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        try:
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(encoded)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(encoded)
            self._log_request(f"Response sent (code: {code}, type: {content_type}, size: {len(encoded)} bytes).", level='debug')
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected (BrokenPipeError/ConnectionResetError) while sending response for {content_type}.", level='warning')
        except Exception as ex:
            logging.error("Error sending response: %s", str(ex), exc_info=True)

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self.doh_resolver = DoHResolver() 
        
        if CACHE_TYPE == 'disk':
            try:
                self.chunk_cache = PersistentRotatingCache(MAX_CACHE_SIZE_BYTES)
                logging.info("Using persistent DISK cache.")
            except Exception as e:
                logging.error(f"Failed to initialize persistent disk cache. Falling back to RAM cache: {e}")
                notify("Erro ao iniciar cache em disco. Usando cache em RAM.", 5000)
                self.chunk_cache = RotatingChunkCache(MAX_CACHE_SIZE_BYTES)
                logging.info("Falling back to in-memory RAM cache.")
        else:
            self.chunk_cache = RotatingChunkCache(MAX_CACHE_SIZE_BYTES)
            logging.info("Using in-memory RAM cache.")
        
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(HTTP_SESSION, self.doh_resolver)
        logging.info("HLSProxyManager initialized.")

    def _acquire_lock(self):
        if xbmcvfs.exists(LOCK_FILE):
            logging.error(f"Lock file '{LOCK_FILE}' exists. Another instance of HLS Proxy might be running or previous one crashed.")
            notify(f"Proxy HLS já em execução ou travado. Se o erro persistir, remova o arquivo: {LOCK_FILE}", 7000)
            return False
        try:
            with xbmcvfs.File(LOCK_FILE, 'w') as f:
                f.write(str(os.getpid()).encode('utf-8'))
            logging.info(f"Acquired lock file: {LOCK_FILE}")
            return True
        except Exception as e:
            logging.error(f"Failed to acquire lock {LOCK_FILE}: {e}", exc_info=True)
            notify(f"Erro fatal: Não foi possível criar arquivo de lock '{LOCK_FILE}'. Verifique permissões.", 7000)
            return False

    def _release_lock(self):
        try:
            if xbmcvfs.exists(LOCK_FILE):
                xbmcvfs.delete(LOCK_FILE)
                logging.info(f"Released lock file: {LOCK_FILE}")
        except Exception as e:
            logging.error(f"Failed to release lock {LOCK_FILE}: {e}", exc_info=True)

    def start(self):
        if not self._acquire_lock():
            return None
        self.stop()
        
        handler_with_deps = functools.partial(AdvancedHLSProxyHandler, self.stream_cache, self.fetcher)
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            # A verificação da porta livre ainda é feita em '127.0.0.1' para simplicidade e compatibilidade.
            # Se a porta estiver livre em '127.0.0.1', geralmente estará livre em '0.0.0.0'
            # a menos que outra aplicação esteja vinculada a '0.0.0.0' ou a uma interface específica.
            if not is_port_free(port):
                logging.warning(f"Port {port} is in use, trying another. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.")
                continue
            try:
                # O PROXY_HOST agora é '0.0.0.0'
                self.server = socketserver.TCPServer((PROXY_HOST, port), handler_with_deps)
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy started successfully on port {self.active_port} on host {PROXY_HOST} (accessible by other devices).")
                # notify(f"Proxy HLS iniciado na porta: {self.active_port}", 3000) # Removed this notification
                return self.active_port
            except Exception as ex:
                logging.warning(f"Failed to start proxy on port {port}: {ex}. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.", exc_info=True)
                time.sleep(0.5)
        
        self._release_lock()
        logging.error(f"Failed to start HLS Proxy after {MAX_PORT_ATTEMPTS} attempts. No free port found or general error.")
        notify("Erro fatal: Não foi possível iniciar o proxy HLS. Nenhuma porta livre encontrada ou erro interno.", 7000)
        return None

    def stop(self):
        if self.server:
            logging.info(f"Stopping HLS Proxy on port {self.active_port}")
            try:
                self.server.shutdown()
                self.server.server_close()
                logging.debug("Proxy server shut down and closed.")
            except Exception as e:
                logging.error(f"Error during proxy server shutdown: {e}", exc_info=True)
            self.server = None
        
        if self.server_thread and self.server_thread.is_alive():
            logging.debug("Waiting for proxy server thread to join...")
            self.server_thread.join(timeout=1)
            if self.server_thread.is_alive():
                logging.warning("Proxy server thread did not terminate gracefully.")
            else:
                logging.debug("Proxy server thread joined successfully.")
        
        self.stream_cache.clear()
        self.active_port = None
        self._release_lock()
        logging.info("HLS Proxy completely stopped and resources released.")
        
    def get_proxy_url(self, original_url):
        if not self.active_port: return None
        url_encoded = urllib.parse.quote_plus(original_url)
        # Use o PROXY_HOST configurado (0.0.0.0) aqui.
        # No entanto, para um cliente externo usar, ele precisará do IP real da máquina.
        # Mas para a URL interna do Kodi e para reescrita de manifestos, 0.0.0.0 ou 127.0.0.1 é tratado
        # pelo sistema operacional de forma que ele se liga a todas as interfaces.
        # Para um cliente REAL na rede, você precisará dar o IP REAL da máquina.
        return f"http://{PROXY_HOST}:{self.active_port}/?url={url_encoded}"


class CustomPlayer(xbmc.Player):
    def onPlayBackStarted(self):
        logging.info("Kodi playback started.")
        HLSProxyAddon.playback_active = True
    def onPlayBackEnded(self):
        logging.info("Kodi playback ended.")
        HLSProxyAddon.playback_active = False
    def onPlayBackError(self):
        logging.error("Kodi playback error occurred.")
        HLSProxyAddon.playback_active = False
    def onPlayBackStopped(self):
        logging.info("Kodi playback stopped by user.")
        HLSProxyAddon.playback_active = False

class HLSProxyAddon:
    playback_active = False
    
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.player = CustomPlayer()
        logging.info("HLSProxyAddon instance created.")

    def convert_to_m3u8(self, url):
        logging.debug(f"Attempting to convert URL to M3U8 format: {url}")
        if '|' in url:
            url = url.split('|')[0]
            logging.debug(f"Removed '|' and everything after: {url}")
        elif '%7C' in url:
            url = url.split('%7C')[0]
            logging.debug(f"Removed '%7C' and everything after: {url}")

        if not '.m3u8' in url.lower() and not '/hl' in url.lower() and int(url.count("/")) > 4 and not '.mp4' in url.lower() and not '.avi' in url.lower():
            parsed_url = urllib.parse.urlparse(url)
            try:
                host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                
                if '/live' not in host_part2:
                    url = host_part1 + '/live' + host_part2
                    logging.debug(f"Added '/live' to URL: {url}")

                file = os.path.basename(urllib.parse.urlparse(url).path)
                if '.ts' in file.lower():
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                    logging.debug(f"Replaced .ts with .m3u8: {url}")
                else:
                    url = url + '.m3u8'
                    logging.debug(f"Appended .m3u8 to URL: {url}")
            except Exception as e:
                logging.warning(f"Error during convert_to_m3u8 heuristic conversion for {url}: {e}", exc_info=True)
                pass
        logging.debug(f"Final URL after convert_to_m3u8: {url}")
        return url

    def play_stream(self, url, channel_name=None):
        logging.info(f"Attempting to play stream: {url}")
        
        processed_url = self.convert_to_m3u8(url)
        logging.info(f"URL after convert_to_m3u8: {processed_url}")

        port = self.proxy_manager.start()
        if not port:
            notify("Erro fatal ao iniciar proxy local. Verifique os logs.", 5000)
            logging.error("Failed to start proxy, cannot resolve URL for Kodi.")
            return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if PROXY_TOKEN:
            logging.warning("PROXY_TOKEN is configured but Kodi's setResolvedUrl doesn't directly support custom headers for local proxy. The token check in handler will likely fail if it expects a header from Kodi itself.")

        if channel_name:
            display_label = f"{channel_name} [COLOR lightblue](HLS/TS Tester)[/COLOR]"
        else:
            display_label = "[COLOR lightblue]HLS/TS Tester[/COLOR]"

        list_item = xbmcgui.ListItem(path=proxy_url, label=display_label)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType(safe_mime_type(processed_url))
        if PROXY_TOKEN:
            list_item.setProperty('X-Proxy-Token', PROXY_TOKEN)

        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        logging.info(f"Kodi resolved URL to proxy: {proxy_url}")
        
        monitor_thread = threading.Thread(target=self.monitor_playback, daemon=True)
        monitor_thread.start()
        logging.debug("Playback monitor thread started.")

    def monitor_playback(self):
        HLSProxyAddon.playback_active = True
        
        logging.info("Starting playback monitoring...")
        initial_wait_seconds = 15
        for i in range(initial_wait_seconds):
            if not HLSProxyAddon.playback_active:
                logging.info(f"Playback stopped before starting (during initial {initial_wait_seconds}s wait).")
                break
            if self.player.isPlaying():
                logging.info(f"Playback detected after {i+1} seconds.")
                break
            time.sleep(1)
        
        if not self.player.isPlaying() and HLSProxyAddon.playback_active:
            logging.warning("Playback did not start within initial wait period. Assuming issue or very slow start.")

        while HLSProxyAddon.playback_active:
            if not self.player.isPlaying():
                logging.info("Player reports not playing. Signalling end of playback monitoring.")
                HLSProxyAddon.playback_active = False
                break
            
            stats = self.proxy_manager.chunk_cache.get_stats()
            max_size_mb = self.proxy_manager.chunk_cache.max_bytes / 1048576
            # Removed the notification for cache size
            # if stats["size_MB"] > 0.8 * max_size_mb:
            #     notify(f"Cache HLS: {stats['size_MB']:.1f}/{max_size_mb:.1f} MB", 1500)
            #     logging.debug(f"Cache usage alert: {stats['size_MB']:.1f}/{max_size_mb:.1f} MB.")

            time.sleep(5)
            
        logging.info("Playback finished or stopped. Releasing proxy resources.")
        self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Live Exemplo (Caminho da Web)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Big Buck Bunny (VOD - 1080p)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Apple Test HLS (Advanced)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"),
            ("Google Shaka Test (DRM-Free)", "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8")
        ]
        logging.info("Displaying test streams.")
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=f"{name} [COLOR lightblue](Reprodução via Proxy HLS/TS Tester)[/COLOR]")
            li.setProperty('IsPlayable', 'true')
            li.setMimeType(safe_mime_type(url))
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            logging.debug(f"Added directory item: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url_to_play = params.get('url')
    channel_title = params.get('title')
    
    addon = HLSProxyAddon()
    if action == 'play' and url_to_play:
        addon.play_stream(url_to_play, channel_title)
    else:
        addon.show_test_streams()
