# -*- coding: utf-8 -*-

import sys
import threading
import time
import gc
import queue
import random
import socket
import struct
import uuid
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse
from requests.adapters import HTTPAdapter

# =============================================================================
# 1. RESOLVEDOR DOH CLOUDFLARE (CACHE + CHECK IP)
# =============================================================================

_original_getaddrinfo = socket.getaddrinfo
_dns_cache = {}
_DNS_CACHE_TTL = 7200

def _is_ip_address(host):
    try: socket.inet_pton(socket.AF_INET, host); return True
    except socket.error: pass
    try: socket.inet_pton(socket.AF_INET6, host); return True
    except socket.error: pass
    return False

def _cloudflare_doh(host, port, family=0, type=0, proto=0, flags=0):
    if _is_ip_address(host): return _original_getaddrinfo(host, port, family, type, proto, flags)
    if host in ("1.1.1.1", "cloudflare-dns.com", "dns.google"): return _original_getaddrinfo(host, port, family, type, proto, flags)

    current_time = time.time()
    cached_entry = _dns_cache.get(host)
    ips = []
    if cached_entry:
        timestamp, cached_ips = cached_entry
        if (current_time - timestamp) < _DNS_CACHE_TTL: ips = cached_ips

    if not ips:
        tid = random.randint(0, 0xffff)
        header = struct.pack("!HHHHHH", tid, 0x0100, 1, 0, 0, 0)
        qname = b"".join(bytes([len(part)]) + part.encode("ascii") for part in host.split(".")) + b"\x00"
        query = header + qname + struct.pack("!HH", 1, 1)
        try:
            r = requests.post("https://1.1.1.1/dns-query", data=query, headers={"accept": "application/dns-message", "content-type": "application/dns-message"}, timeout=5)
            if r.status_code == 200:
                data = r.content
                if len(data) >= 12 and struct.unpack("!H", data[:2])[0] == tid:
                    pos, ancount = 12, struct.unpack("!H", data[6:8])[0]
                    qdcount = struct.unpack("!H", data[4:6])[0]
                    for _ in range(qdcount): 
                        while data[pos] != 0:
                            if data[pos] & 0xC0: pos += 2; break
                            pos += data[pos] + 1
                        pos += 5
                    for _ in range(ancount):
                        if data[pos] & 0xC0: pos += 2
                        else:
                            while data[pos] != 0: pos += data[pos] + 1
                            pos += 1
                        atype, _, _, rdlen = struct.unpack("!HHIH", data[pos : pos + 10]); pos += 10
                        if atype == 1 and rdlen == 4:
                            ips.append(socket.inet_ntoa(data[pos : pos + 4]))
                        pos += rdlen
        except: pass
        if ips: _dns_cache[host] = (current_time, ips)
        else: return _original_getaddrinfo(host, port, family, type, proto, flags)

    return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (ip, port)) for ip in ips] + \
           [(socket.AF_INET, socket.SOCK_DGRAM, 0, "", (ip, port)) for ip in ips]

socket.getaddrinfo = _cloudflare_doh

# =============================================================================
# 2. MÓDULOS KODI E FLASK
# =============================================================================

try:
    import xbmc, xbmcgui, xbmcplugin
except ImportError:
    class MockXbmc:
        LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR = 0, 1, 2, 3
        def log(self, msg, level=LOGINFO): print(f"[KODI] {msg}")
    xbmc = MockXbmc()
    xbmcgui = type('obj', (object,), {'Dialog': type('obj', (object,), {'ok': lambda s,a,b: print(a,b)})})()
    xbmcplugin = type('obj', (object,), {'endOfDirectory': lambda h,c: None, 'setResolvedUrl': lambda h,c,i: None})()

try:
    from flask import Flask, request, Response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro", "Módulo Flask ausente.")
    sys.exit(1)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

# --- Configurações Otimizadas ---
CHUNK_SIZE = 128 * 1024 
TS_CHUNK_SIZE = 8 * 1024
FETCH_TIMEOUT = 30
CONNECT_TIMEOUT = 10
QUEUE_SIZE = 300 

# Lógica Anti-Loop (Sutura Splicing)
TAIL_PRIMARY = 32 * 1024   # 32 KB
TAIL_SECONDARY = 8 * 1024  # 8 KB
# Aumentado para 2MB para garantir que a janela deslizante não perca o padrão
SEARCH_WINDOW = 8 * 1024 * 1024 

# Fail-Safe: Se baixar 3x o tamanho da janela e não achar sutura, força sync
FAILSAFE_BYTE_LIMIT = SEARCH_WINDOW * 3 

KEEPALIVE_PACKETS = 4500
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
TS_PACKET_SIZE = 188

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20'
]

app = Flask(__name__)

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in [10, 127, 169, 172, 192, 198, 203, 224]: continue
        o2 = random.randint(0, 255); o3 = random.randint(0, 255); o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31: continue
        if o1 == 192 and o2 == 168: continue
        return f"{o1}.{o2}.{o3}.{o4}"

def get_stealth_headers(target_url, force_new_agent=False):
    fake_ip = random_ip()
    parsed = urlparse(target_url)
    base_domain = f"{parsed.scheme}://{parsed.netloc}/"
    
    ua = random.choice(USER_AGENTS) if (force_new_agent or random.random() < 0.7) else USER_AGENTS[0]
    
    headers = {
        'User-Agent': ua,
        'Accept': '*/*',
        'Accept-Language': random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9']),
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': base_domain,
        'Origin': base_domain.rstrip('/'),
        'DNT': str(random.randint(0, 1)),
        'X-Forwarded-For': fake_ip,
        'X-Real-IP': fake_ip,
        'Client-IP': fake_ip,
        'Sec-CH-UA': f'"Not;A=Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
        'Sec-CH-UA-Mobile': '?0',
        'Sec-CH-UA-Platform': '"Windows"',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Accept-Encoding': 'identity',
        'Upgrade-Insecure-Requests': '1'
    }
    return headers

# --- Engine V11 (True Sliding Window) ---

class XCodesEngine:
    def __init__(self):
        self.active_url_param = None
        self.original_url = None
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self.stop_event = threading.Event()
        
        self.stream_tail = b''
        self.residual_buffer = b''
        self.has_initial_lock = False
        
        self.consecutive_failures = 0
        self.session = None
        self.reconnection_count = 0
        self.last_successful_data_time = time.time()
        self.starvation_counter = 0
        
        self.emergency_buffer = queue.Queue(maxsize=50)
        self._fill_emergency_buffer()

    def _fill_emergency_buffer(self):
        null_block = TS_NULL_PACKET * (KEEPALIVE_PACKETS // 10)
        for _ in range(50):
            try: self.emergency_buffer.put_nowait(null_block)
            except: break

    def _create_fresh_session(self):
        if self.session: 
            try: self.session.close()
            except: pass
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=100, pool_maxsize=200, max_retries=0)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)
        self.reconnection_count += 1
        if self.reconnection_count % 3 == 0: gc.collect()

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls: raise ValueError("Nenhuma URL fornecida")
        target_url = urls[0]

        if self.active_url_param == url_param:
            if self.stop_event.is_set() or not self.producer_thread.is_alive():
                self.stop_event.clear()
                with self.data_queue.mutex: self.data_queue.queue.clear()
                self._create_fresh_session()
                self.producer_thread = threading.Thread(target=self._producer_loop, daemon=True)
                self.producer_thread.start()
        else:
            self.stop_event.set()
            if hasattr(self, 'producer_thread') and self.producer_thread.is_alive(): self.producer_thread.join()
            self.stop_event.clear()
            with self.data_queue.mutex: self.data_queue.queue.clear()

            self._create_fresh_session()
            self.active_url_param = url_param
            self.original_url = target_url
            self.stream_tail = b''
            self.residual_buffer = b''
            self.has_initial_lock = False
            self.consecutive_failures = 0
            self.reconnection_count = 0
            self.last_successful_data_time = time.time()
            self.starvation_counter = 0

            self.producer_thread = threading.Thread(target=self._producer_loop, daemon=True)
            self.producer_thread.start()
            xbmc.log(f"[ENGINE V11] Iniciando Motor: {target_url[:60]}...", xbmc.LOGINFO)

    def _fill_keepalive(self, multiplier=20):
        null_block = TS_NULL_PACKET * KEEPALIVE_PACKETS
        for _ in range(multiplier):
            try: self.data_queue.put_nowait(null_block)
            except queue.Full: break

    def _process_chunk_optimized(self, raw_chunk):
        if not raw_chunk: return
        current_batch = self.residual_buffer + raw_chunk
        
        if not self.has_initial_lock:
            sync_idx = current_batch.find(b'\x47')
            if sync_idx == -1:
                self.residual_buffer = current_batch[-TS_PACKET_SIZE*2:] 
                return
            current_batch = current_batch[sync_idx:]
            self.has_initial_lock = True

        total_len = len(current_batch)
        if total_len < TS_PACKET_SIZE:
            self.residual_buffer = current_batch
            return

        num_packets = total_len // TS_PACKET_SIZE
        bytes_to_send = num_packets * TS_PACKET_SIZE
        
        payload = current_batch[:bytes_to_send]
        self.residual_buffer = current_batch[bytes_to_send:]
        
        self.stream_tail += payload
        if len(self.stream_tail) > TAIL_PRIMARY + TAIL_SECONDARY:
            self.stream_tail = self.stream_tail[-TAIL_PRIMARY:]
            
        self.last_successful_data_time = time.time()
        self.starvation_counter = 0
            
        # Anti-Grinch
        try: self.data_queue.put_nowait(payload)
        except queue.Full:
            while not self.data_queue.empty():
                try: self.data_queue.get_nowait()
                except: break
            try: self.data_queue.put_nowait(payload)
            except: pass

    def _producer_loop(self):
        xbmc.log("[ENGINE V11] Producer Loop iniciado (Sliding Window)", xbmc.LOGINFO)
        r = None
        
        while not self.stop_event.is_set():
            try:
                target_url = self.original_url
                
                force_new_agent = (self.consecutive_failures > 0 or self.reconnection_count > 0)
                headers = get_stealth_headers(target_url, force_new_agent)
                headers.pop('Accept-Encoding', None)

                r = self.session.get(
                    target_url, 
                    headers=headers, 
                    stream=True, 
                    timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT), 
                    verify=False
                )

                if r is None or r.status_code not in [200, 206]:
                    status = r.status_code if r else 0
                    xbmc.log(f"[ENGINE V11] Erro HTTP {status}", xbmc.LOGERROR)
                    
                    if status in [403, 404, 410]:
                        xbmc.log("[ENGINE V11] Erro Token. Resetando.", xbmc.LOGWARNING)
                        self._create_fresh_session()
                    
                    self.consecutive_failures += 1
                    if r: r.close()
                    self._fill_keepalive(15)
                    time.sleep(0.5)
                    continue

                self.consecutive_failures = 0
                xbmc.log(f"[ENGINE V11] Conectado: {r.url[:60]}...", xbmc.LOGINFO)
                
                resync_search_buffer = b''
                is_resyncing = len(self.stream_tail) > 0
                resync_byte_counter = 0 # Contador para Fail-Safe
                reconnection_start_time = time.time()

                is_ts_stream = any(ext in r.url.lower() for ext in ['.ts', '/ts', '.m2ts', '/chunk', '/segment'])
                chunk_size = TS_CHUNK_SIZE if is_ts_stream else CHUNK_SIZE
                
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if self.stop_event.is_set(): break
                    if not chunk: continue
                    
                    # --- ANTI-STALL: Keepalive ---
                    if is_resyncing and time.time() - reconnection_start_time > 0.5:
                        if self.data_queue.qsize() < 20:
                            try: self.data_queue.put_nowait(TS_NULL_PACKET * 100)
                            except: pass

                    if is_resyncing:
                        resync_search_buffer += chunk
                        resync_byte_counter += len(chunk)
                        
                        # --- JANELA DESLIZANTE ESTRITA (TRUE SLIDING WINDOW) ---
                        # Corta o buffer para manter exatamente os últimos SEARCH_WINDOW bytes
                        if len(resync_search_buffer) > SEARCH_WINDOW:
                            resync_search_buffer = resync_search_buffer[-SEARCH_WINDOW:]

                        # --- FAIL-SAFE POR CONTADOR ---
                        # Se já processamos 3x o tamanho da janela e não achamos sutura,
                        # desistimos da procura perfeita para evitar travar o player.
                        if resync_byte_counter > FAILSAFE_BYTE_LIMIT:
                            xbmc.log("[ENGINE V11] Limite de busca atingido (Fail-Safe). Forçando alinhamento.", xbmc.LOGWARNING)
                            last_sync = resync_search_buffer.rfind(b'\x47')
                            new_data = resync_search_buffer[last_sync:] if last_sync > 0 else resync_search_buffer
                            
                            resync_search_buffer = b''
                            is_resyncing = False
                            self.has_initial_lock = False 
                            self.residual_buffer = b''
                            self._process_chunk_optimized(new_data)
                            continue
                        
                        # Busca Primária
                        primary_tail = self.stream_tail[-TAIL_PRIMARY:] if len(self.stream_tail) >= TAIL_PRIMARY else self.stream_tail
                        if primary_tail and primary_tail in resync_search_buffer:
                            idx = resync_search_buffer.rfind(primary_tail)
                            skip_bytes = idx + len(primary_tail)
                            
                            xbmc.log(f"[ENGINE V11] SUTURA PERFEITA. Pulando {skip_bytes} bytes", xbmc.LOGINFO)
                            
                            new_data = resync_search_buffer[skip_bytes:]
                            resync_search_buffer = b''
                            is_resyncing = False
                            
                            self.has_initial_lock = False 
                            self.residual_buffer = b'' 
                            self._process_chunk_optimized(new_data)
                            continue
                        
                        # Busca Secundária
                        secondary_tail = self.stream_tail[-TAIL_SECONDARY:] if len(self.stream_tail) >= TAIL_SECONDARY else b''
                        if secondary_tail and len(resync_search_buffer) > TAIL_SECONDARY + (188*50) and secondary_tail in resync_search_buffer:
                            idx = resync_search_buffer.rfind(secondary_tail)
                            skip_bytes = idx + len(secondary_tail)
                            
                            xbmc.log(f"[ENGINE V11] SUTURA RÁPIDA. Pulando {skip_bytes} bytes", xbmc.LOGINFO)
                            
                            new_data = resync_search_buffer[skip_bytes:]
                            resync_search_buffer = b''
                            is_resyncing = False
                            
                            self.has_initial_lock = False
                            self.residual_buffer = b'' 
                            self._process_chunk_optimized(new_data)
                            continue
                    else:
                        self._process_chunk_optimized(chunk)

                r.close()

            except Exception as e:
                xbmc.log(f"[ENGINE V11] Erro Loop: {str(e)}", xbmc.LOGERROR)
                if r: 
                    try: r.close()
                    except: pass
                
                self.consecutive_failures += 1
                self._fill_keepalive(30)
                time.sleep(0.5)

    def generator(self):
        xbmc.log("[ENGINE V11] Gerador Iniciado", xbmc.LOGINFO)
        yield TS_NULL_PACKET * KEEPALIVE_PACKETS
        try:
            while not self.stop_event.is_set():
                try:
                    chunk = self.data_queue.get(timeout=0.5)
                    yield chunk
                except queue.Empty:
                    if self.data_queue.empty() and not self.emergency_buffer.empty():
                        try:
                            emergency_chunk = self.emergency_buffer.get_nowait()
                            yield emergency_chunk
                            self._fill_emergency_buffer()
                        except: yield TS_NULL_PACKET * KEEPALIVE_PACKETS
                    else: yield TS_NULL_PACKET * KEEPALIVE_PACKETS
        finally:
            self.stop_event.set()

engine = XCodesEngine()

@app.route('/stream')
def stream_handler():
    url = request.args.get('url')
    if not url: return "URL não fornecida", 400
    engine.start_stream(url)
    return Response(stream_with_context(engine.generator()), mimetype='video/mp2t',
                    headers={'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'Content-Type': 'video/mp2t'})

def get_free_port(start_port=59000):
    p = start_port
    while p < start_port + 100:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind(('127.0.0.1', p))
            s.close()
            return p
        except: p+=1
    return 59000

def start_server(port):
    def run():
        try:
            from werkzeug.serving import run_simple
            run_simple('127.0.0.1', port, app, threaded=True, use_reloader=False, use_debugger=False)
        except: pass
    t = threading.Thread(target=run, daemon=True); t.start()
    time.sleep(0.7)

PORT = get_free_port()
start_server(PORT)

def run_addon():
    act = _ARGS.get('action'); url = _ARGS.get('url')
    if act == 'play' and url:
        li = xbmcgui.ListItem(path=f"http://127.0.0.1:{PORT}/stream?url={quote(url)}")
        li.setProperty('IsPlayable', 'true'); li.setMimeType('video/mp2t'); li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, li)
    else:
        li = xbmcgui.ListItem("[COLOR cyan]NEXUS PROXY V11 (TRUE SLIDING)[/COLOR]")
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False); xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__': run_addon()