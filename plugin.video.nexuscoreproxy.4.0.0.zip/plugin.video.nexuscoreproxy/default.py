# -*- coding: utf-8 -*-

import sys
import threading
import time
import gc
import socket
import re
import queue
import random
from urllib.parse import parse_qsl, urljoin, quote

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib3
from requests.adapters import HTTPAdapter

# Desativa avisos de SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    from flask import Flask, request, Response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro", "Módulo 'script.module.flask' não encontrado.")
    sys.exit(1)

# --- Instâncias do Addon ---
ADDON = xbmcaddon.Addon()
_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

# --- Carregamento Dinâmico de Configurações ---
def get_setting_int(id, default):
    val = ADDON.getSetting(id)
    return int(val) if val else default

def get_setting_bool(id, default):
    return ADDON.getSettingBool(id) if ADDON.getSetting(id) != '' else default

# Parâmetros (defaults mais robustos)
FETCH_TIMEOUT = get_setting_int("fetch_timeout", 20)
SEARCH_WINDOW_KB = get_setting_int("search_window_kb", 16384) * 1024  # default 16 MB
TAIL_PRIMARY_KB = get_setting_int("tail_primary_kb", 256) * 1024      # default 256 KB
TAIL_SECONDARY_KB = get_setting_int("tail_secondary_kb", 64) * 1024   # default 64 KB
CHUNK_SIZE = get_setting_int("chunk_size_kb", 128) * 1024              # default 128 KB
QUEUE_SIZE = get_setting_int("queue_size", 2000)
ENABLE_KEEPALIVE = get_setting_bool("enable_keepalive", True)
KEEPALIVE_FALLBACK = get_setting_int("keepalive_multiplier", 100)     # fallback count

# Pacote nulo TS
TS_NULL_BLOCK = b'\x47\x1F\xFF\x10' + b'\xFF' * 184

# Limite máximo de tail em memória
MAX_TAIL_LENGTH = 2 * 1024 * 1024  # 2 MB

app = Flask(__name__)

# ========================================================================
# HEADERS E MOTOR
# ========================================================================

def get_random_headers():
    user_agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Linux; Android 11; Chromecast) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Safari/537.36',
        'VLC/3.0.20 LibVLC/3.0.20',
        'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/15.0 Chrome/94.0.4606.112 TV Safari/537.36',
        'AppleCoreMedia/1.0.0.21B91 (iPad; U; CPU OS 15_1 like Mac OS X; en_us)',
        'Lavf/58.76.100'
    ]
    return {
        'User-Agent': random.choice(user_agents),
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache'
    }

class NexusCoreEngine:
    def __init__(self, target_url):
        self.target_url = target_url
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self.stop_event = threading.Event()
        self.stream_tail = b""
        self.sync_locked = False
        self.reconnect_count = 0

        # Estimativa de bitrate
        self.bitrate_kbps = 0.0
        self.bytes_received = 0
        self.last_measure_time = time.time()
        self.last_bytes = 0

    # --------------------------------------------------------------------
    # Detecção robusta de posição de sincronismo TS
    # --------------------------------------------------------------------
    def find_best_sync_position(self, data):
        if len(data) < 188 * 5:
            return -1
        best_pos = -1
        best_count = 0
        pos = 0
        while pos < len(data) - 188 * 10:
            pos = data.find(b'\x47', pos)
            if pos == -1:
                break
            count = 1
            for i in range(1, 21):
                next_pos = pos + i * 188
                if next_pos >= len(data):
                    break
                if data[next_pos] == 0x47:
                    count += 1
                else:
                    break
            if count > best_count:
                best_count = count
                best_pos = pos
                if count >= 10:
                    break
            pos += 1
        return best_pos if best_count >= 4 else -1

    # --------------------------------------------------------------------
    # Atualização de bitrate
    # --------------------------------------------------------------------
    def update_bitrate(self):
        current_time = time.time()
        if current_time - self.last_measure_time >= 10.0:
            delta_time = current_time - self.last_measure_time
            delta_bytes = self.bytes_received - self.last_bytes
            if delta_time > 0 and delta_bytes > 0:
                instantaneous = (delta_bytes * 8 / delta_time) / 1000
                if self.bitrate_kbps > 0:
                    self.bitrate_kbps = self.bitrate_kbps * 0.9 + instantaneous * 0.1
                else:
                    self.bitrate_kbps = instantaneous
                xbmc.log(f"[NEXUS V17.0] Bitrate estimado: {self.bitrate_kbps:.0f} kbps", xbmc.LOGINFO)
            self.last_bytes = self.bytes_received
            self.last_measure_time = current_time

    # --------------------------------------------------------------------
    # Generator principal
    # --------------------------------------------------------------------
    def generator(self):
        t = threading.Thread(target=self._producer_loop, daemon=True)
        t.start()
        
        xbmc.log("[NEXUS V17.0] Iniciando Fluxo Imortal Dinâmico", xbmc.LOGINFO)
        
        try:
            while not self.stop_event.is_set():
                try:
                    chunk = self.data_queue.get(timeout=1.0)
                    yield chunk
                except queue.Empty:
                    if ENABLE_KEEPALIVE and not self.stop_event.is_set():
                        if self.bitrate_kbps >= 500:  # valor plausível
                            bytes_per_sec = self.bitrate_kbps * 125  # 1000/8
                            inject_bytes = int(bytes_per_sec * 3.0)  # 3 segundos de buffer
                            null_count = max(50, inject_bytes // 188)
                        else:
                            null_count = KEEPALIVE_FALLBACK * 20
                        null_count = min(null_count, 20000)  # limite segurança
                        yield TS_NULL_BLOCK * null_count
        except GeneratorExit:
            self.stop_event.set()
        finally:
            self.stop_event.set()

    # --------------------------------------------------------------------
    # Sutura e envio
    # --------------------------------------------------------------------
    def _stitch_and_send(self, data_source):
        if not data_source:
            return bytearray()

        # Primeira sincronização (se ainda não locked)
        if not self.sync_locked:
            idx = self.find_best_sync_position(data_source)
            if idx != -1:
                data_source = data_source[idx:]
                self.sync_locked = True
                xbmc.log("[NEXUS V17.0] Sincronismo inicial alinhado por múltiplos sync bytes", xbmc.LOGINFO)

        # Corte em pacotes completos de 188 bytes
        packet_count = len(data_source) // 188
        if packet_count == 0:
            return data_source

        data_to_send = data_source[:packet_count * 188]
        remainder = data_source[packet_count * 188:]

        try:
            self.data_queue.put(bytes(data_to_send), timeout=1.0)
            # Atualiza tail (limitado)
            self.stream_tail = (self.stream_tail + data_to_send)[-MAX_TAIL_LENGTH:]
        except queue.Full:
            pass
        return remainder

    # --------------------------------------------------------------------
    # Loop produtor
    # --------------------------------------------------------------------
    def _producer_loop(self):
        session = requests.Session()
        session.mount('http://', HTTPAdapter(pool_connections=10, pool_maxsize=20))
        session.mount('https://', HTTPAdapter(pool_connections=10, pool_maxsize=20))

        while not self.stop_event.is_set():
            try:
                self.sync_locked = False
                headers = get_random_headers()

                # === Parâmetros dinâmicos baseados no bitrate atual ===
                if self.bitrate_kbps >= 500:
                    bps = self.bitrate_kbps * 125
                    dynamic_chunk = max(64 * 1024, min(int(bps * 0.5), 2 * 1024 * 1024))
                    dynamic_search = max(SEARCH_WINDOW_KB, int(bps * 5))
                    dynamic_tail_p = max(TAIL_PRIMARY_KB, int(bps * 1.5))
                    dynamic_tail_s = max(TAIL_SECONDARY_KB, int(bps * 0.5))
                else:
                    dynamic_chunk = CHUNK_SIZE
                    dynamic_search = SEARCH_WINDOW_KB
                    dynamic_tail_p = TAIL_PRIMARY_KB
                    dynamic_tail_s = TAIL_SECONDARY_KB

                with session.get(self.target_url, headers=headers, stream=True,
                                 timeout=(6.0, FETCH_TIMEOUT), verify=False) as r:
                    if r.status_code not in [200, 206]:
                        time.sleep(0.5)
                        continue

                    self.reconnect_count += 1
                    is_resyncing = self.reconnect_count > 1
                    resync_buffer = bytearray()
                    leftover = bytearray()

                    for chunk in r.iter_content(chunk_size=dynamic_chunk):
                        if self.stop_event.is_set():
                            break
                        if not chunk:
                            continue

                        self.bytes_received += len(chunk)
                        self.update_bitrate()

                        if is_resyncing:
                            resync_buffer.extend(chunk)
                            if len(resync_buffer) > dynamic_search:
                                resync_buffer = resync_buffer[-dynamic_search:]

                            # Busca overlap (maior primeiro)
                            found = False
                            for size in sorted([dynamic_tail_p, dynamic_tail_s], reverse=True):
                                if len(self.stream_tail) >= size:
                                    tail = self.stream_tail[-size:]
                                    idx = resync_buffer.find(tail)
                                    if idx != -1:
                                        leftover = resync_buffer[idx + size:]
                                        leftover = self._stitch_and_send(leftover)
                                        is_resyncing = False
                                        xbmc.log(f"[NEXUS V17.0] Sutura perfeita encontrada ({size//1024} KB overlap)", xbmc.LOGINFO)
                                        found = True
                                        break
                            if found:
                                continue

                            # Força com fallback de alinhamento TS
                            if len(resync_buffer) >= dynamic_search:
                                sync_idx = self.find_best_sync_position(resync_buffer)
                                if sync_idx != -1:
                                    leftover = resync_buffer[sync_idx:]
                                    xbmc.log(f"[NEXUS V17.0] Reconexão forçada com alinhamento TS robusto", xbmc.LOGINFO)
                                else:
                                    leftover = resync_buffer
                                    xbmc.log(f"[NEXUS V17.0] Reconexão forçada sem alinhamento perfeito", xbmc.LOGINFO)
                                leftover = self._stitch_and_send(leftover)
                                is_resyncing = False

                        else:
                            leftover.extend(chunk)
                            leftover = self._stitch_and_send(leftover)

            except Exception as e:
                xbmc.log(f"[NEXUS V17.0] Erro de rede: {str(e)}. Tentando reconectar...", xbmc.LOGWARNING)
                time.sleep(0.2)
            finally:
                gc.collect()

# ========================================================================
# ROTAS FLASK
# ========================================================================

@app.route('/stream')
def stream_handler():
    url = request.args.get('url')
    if not url:
        return "URL não fornecida", 400
    engine = NexusCoreEngine(url)
    return Response(
        stream_with_context(engine.generator()),
        mimetype='video/mp2t',
        headers={'Cache-Control': 'no-cache', 'Connection': 'keep-alive'}
    )

def start_server():
    port = 50088
    def run():
        try:
            from werkzeug.serving import run_simple
            run_simple('127.0.0.1', port, app, threaded=True, use_reloader=False)
        except Exception as e:
            xbmc.log(f"[NEXUS] Erro no servidor Flask: {e}", xbmc.LOGERROR)
    t = threading.Thread(target=run, daemon=True)
    t.start()
    time.sleep(0.5)  # pequeno delay para garantir inicialização
    return port

SERVER_PORT = start_server()

def run_addon():
    action = _ARGS.get('action')
    url = _ARGS.get('url')

    if action == 'play' and url:
        local_url = f"http://127.0.0.1:{SERVER_PORT}/stream?url={quote(url)}"
        li = xbmcgui.ListItem(path=local_url)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    elif action == 'settings':
        ADDON.openSettings()
    else:
        li = xbmcgui.ListItem("[COLOR cyan]NEXUS CORE V17.0[/COLOR] - Proxy MPEG-TS Otimizado")
        xbmcplugin.addDirectoryItem(_HANDLE, f"{sys.argv[0]}?action=settings", li, False)
        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    run_addon()