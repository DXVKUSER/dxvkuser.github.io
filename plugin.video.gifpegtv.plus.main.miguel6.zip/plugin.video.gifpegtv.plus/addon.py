# addon.py
# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import time
import xbmcvfs
import html
import hashlib
from datetime import datetime

from resources.lib.api import XtreamAPI
from resources.lib.epg import load_epg, epg_lookup_current_next, normalize_epg_channel_id

from hlsproxy import HLSAddon
from vodproxy import resolve_vod_stream, VODProxyManager

import requests

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADULT_KEYWORDS = ['adult', 'xxx', '+18', 'private']

REMOTE_MENU_URL = "https://raw.githubusercontent.com/DXVKUSER/SRTORRENT/refs/heads/main/servers2.json"
REMOTE_MENU_CACHE_FILE = "remote_menu_cache.json"

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_TTL = 24 * 3600  # 24h
REMOTE_MENU_TTL = 300

VOD_PROXY_MANAGER = None
PAGE_SIZE = 120

def get_setting(setting_id):
    return ADDON.getSetting(setting_id)

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_dir(name, query, icon='https://i.imgur.com/FBK5qFX.png', fanart='https://i.imgur.com/KMlkWXm.jpeg', is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=f"[B][COLOR white]{name}[/COLOR][/B]")
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
    if plot:
        li.setInfo("video", {"title": name, "plot": plot})
    url = build_url(query)
    li.setProperty('TakeFocus', 'true')
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def get_remote_menu():
    cache_path = os.path.join(PROFILE_DIR, REMOTE_MENU_CACHE_FILE)
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)

    if os.path.exists(cache_path):
        file_age = time.time() - os.path.getmtime(cache_path)
        if file_age < REMOTE_MENU_TTL:
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                xbmc.log("[ADDON] Menu remoto carregado do cache.", level=xbmc.LOGINFO)
                return data
            except Exception as e:
                xbmc.log(f"[ADDON] Erro ao ler cache do menu: {e}", level=xbmc.LOGERROR)

    xbmc.log(f"[ADDON] Baixando menu remoto: {REMOTE_MENU_URL}", level=xbmc.LOGINFO)
    try:
        response = requests.get(REMOTE_MENU_URL, timeout=15)
        response.raise_for_status()
        data = json.loads(response.text)
        if not isinstance(data, list) or not data:
            xbmc.log("[ADDON] Menu remoto vazio ou inválido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Menu remoto vazio ou inválido.[/COLOR][/B]")
            return []

        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(data, f)

        return data

    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro ao baixar menu remoto: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLOR white]Erro de Conexão[/COLOR][/B]", "[B][COLOR white]Não foi possível baixar o menu remoto. Tentando cache...[/COLOR][/B]")
        if os.path.exists(cache_path):
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                xbmc.log("[ADDON] Falha de conexão. Servindo menu do cache antigo.", level=xbmc.LOGINFO)
                return data
            except Exception:
                return []
        return []
    except (ValueError, json.JSONDecodeError):
        xbmc.log("[ADDON] Menu remoto não é JSON válido.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLOR white]Erro de Menu[/COLOR][/B]", "[B][COLOR white]O arquivo JSON remoto está inválido.[/COLOR][/B]")
        return []

def servers_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Servidores[/COLOR][/B]")
    menu = get_remote_menu()
    for categoria in menu:
        cat_name = categoria.get("categoria", "[B][COLOR white]Sem Nome[/COLOR][/B]")
        icon = categoria.get("icon", "https://i.imgur.com/SJITntP.png")
        fanart = categoria.get("fanart", "https://i.imgur.com/gaaKYUP.jpeg")
        add_dir(f"{cat_name}", {'action': 'category_menu', 'category_name': cat_name}, icon=icon, fanart=fanart, is_folder=True)
    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def category_menu(category_name):
    menu = get_remote_menu()
    category = next((c for c in menu if c.get("categoria") == category_name), None)
    if not category:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", f"[B][COLOR white]Categoria '{category_name}' não encontrada.[/COLOR][/B]")
        return

    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[B][COLOR white]{category_name}[/COLOR][/B]")
    servidores = category.get("servidores", [])
    for i, server in enumerate(servidores):
        name = server.get("nome", "[B][COLOR white]Servidor[/COLOR][/B]")
        imagem = server.get("icon", "https://i.imgur.com/SJITntP.png")
        add_dir(f"{name}", {'action': 'server_home', 'category_name': category_name, 'server_index': i}, icon=imagem, fanart=imagem, is_folder=True)
    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def main_menu(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Menu Principal[/COLOR][/B]")
    add_dir("TV", {'action': 'list_live_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("Filmes", {'action': 'list_vod_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("Séries", {'action': 'list_series_categories', 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_epg_xml_path(server):
    server_hash = hashlib.md5(server.encode('utf-8')).hexdigest()
    return os.path.join(PROFILE_DIR, f'epg_{server_hash}.xml')

def download_epg(server, username, password):
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)
    epg_xml_path = get_epg_xml_path(server)
    url = f"{server.rstrip('/')}/xmltv.php?username={username}&password={password}"
    xbmc.log(f"[ADDON] Baixando EPG para o servidor: {server}", level=xbmc.LOGINFO)

    dialog = xbmcgui.DialogProgress()
    dialog.create("[B][COLOR white]Atualizando EPG[/COLOR][/B]", "Preparando para baixar dados do EPG...")

    try:
        response = requests.get(url, timeout=90, stream=True)
        response.raise_for_status()

        total_size = int(response.headers.get('content-length', 0))
        block_size = 1024 * 1024
        bytes_downloaded = 0

        with open(epg_xml_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=block_size):
                if dialog.iscanceled():
                    raise Exception("Download Cancelado pelo Usuário")
                f.write(chunk)
                bytes_downloaded += len(chunk)

                if total_size > 0:
                    percent = int(bytes_downloaded * 100 / total_size)
                    dialog.update(percent, f"[B][COLOR white]Baixando EPG:[/COLOR][/B] {bytes_downloaded / (1024*1024):.1f}MB de {total_size / (1024*1024):.1f}MB")
                else:
                    dialog.update(0, f"[B][COLOR white]Baixando EPG (tamanho desconhecido)...[/COLOR][/B]\nBaixados: {bytes_downloaded / (1024*1024):.1f}MB")
        xbmc.log(f"[ADDON] EPG baixado com sucesso: {epg_xml_path}", level=xbmc.LOGINFO)
        return epg_xml_path
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro ao baixar EPG: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLOR white]Erro de EPG[/COLOR][/B]", f"[B][COLOR white]Não foi possível baixar o EPG: {e}[/COLOR][/B]")
        return None
    finally:
        dialog.close()

def format_epg_time(time_str):
    """Helper to format XMLTV time string to HH:MM"""
    if not time_str or len(str(time_str)) < 12:
        return ""
    try:
        s = str(time_str)
        # XMLTV format is typically YYYYMMDDHHMMSS...
        # Extracting HH:MM
        return f"{s[8:10]}:{s[10:12]}"
    except Exception:
        return ""

def list_live_categories(api, server, username, password, category_name, server_index):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    show_epg_enabled = get_setting("show_epg") == 'true'

    epg_xml_path = get_epg_xml_path(server)
    
    # ALTERAÇÃO ANTERIOR: Só baixa o EPG se a configuração estiver ativa
    if show_epg_enabled:
        if not os.path.exists(epg_xml_path) or (time.time() - os.path.getmtime(epg_xml_path) > EPG_TTL):
            download_epg(server, username, password)

    epg = load_epg(epg_xml_path)

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Categorias de TV[/COLOR][/B]")
    add_dir("[COLOR yellow]Buscar Canais[/COLOR]", {'action': 'search_live', 'category_name': category_name, 'server_index': server_index}, is_folder=True)

    categories = None
    error_occurred = False
    error_message = ""

    try:
        categories = api.get_live_categories()
        if categories is None or not isinstance(categories, list):
            raise Exception("Resposta inválida ou vazia para get_live_categories")
    except Exception as e:
        error_occurred = True
        error_message = str(e)
        xbmc.log(f"[ADDON] Falha ao obter categorias: {error_message}", level=xbmc.LOGWARNING)

    has_visible_categories = False

    if not error_occurred and categories:
        for cat in categories:
            cat_name = cat.get('category_name', '').strip()
            if not cat_name:
                continue
            if adult_filter_enabled and any(kw in cat_name.lower() for kw in ADULT_KEYWORDS):
                continue
            add_dir(cat_name, {
                'action': 'list_live_streams',
                'category_id': cat.get('category_id'),
                'category_name': category_name,
                'server_index': server_index
            })
            has_visible_categories = True

    if error_occurred or not has_visible_categories:
        add_dir("[COLOR yellow]Todos os Canais[/COLOR]", {
            'action': 'list_live_streams',
            'category_name': category_name,
            'server_index': server_index
        }, is_folder=True)

        if error_occurred and ("403" in error_message or "forbidden" in error_message.lower()):
            xbmcgui.Dialog().ok(
                "[B][COLOR yellow]Aviso do Servidor[/COLOR][/B]",
                "Este servidor bloqueou o acesso à lista de categorias (provavelmente erro 403).\n\n"
                "Você ainda pode:\n"
                "  • Usar [COLOR yellow]Buscar Canais[/COLOR]\n"
                "  • Acessar [COLOR yellow]Todos os Canais[/COLOR] (lista completa)\n\n"
                "Isso é uma restrição do provedor."
            )

    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_live_streams(api, category_id, server, username, password, category_name, server_index):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    show_epg_enabled = get_setting("show_epg") == 'true'
    epg_xml_path = get_epg_xml_path(server)
    epg = load_epg(epg_xml_path)

    # Se category_id for None → lista TODOS os canais
    streams = api.get_live_streams(category_id if category_id else None)

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Canais[/COLOR][/B]")

    if streams and isinstance(streams, list):
        for stream in streams:
            if adult_filter_enabled and any(kw in stream.get('name', '').lower() for kw in ADULT_KEYWORDS):
                continue

            stream_name = stream.get('name', 'Sem nome')
            stream_id = stream.get('stream_id')
            if not stream_id:
                continue

            stream_icon = stream.get('stream_icon', 'https://i.imgur.com/SJITntP.png')
            epg_channel_id = stream.get('epg_channel_id')

            current_title = ""
            next_title = ""
            plot = ""

            if show_epg_enabled and epg_channel_id:
                current, nextp = epg_lookup_current_next(epg_channel_id, epg)
                if current and current.get('title'):
                    current_title = current['title'].strip()
                    # Formatação do horário atual
                    start_t = format_epg_time(current.get('start'))
                    stop_t = format_epg_time(current.get('stop'))
                    time_str = f" ({start_t} - {stop_t})" if start_t and stop_t else ""
                    
                    plot += f"[B][COLOR white]{current_title}{time_str}[/COLOR][/B]\n{current.get('desc', '')}\n"
                if nextp and nextp.get('title'):
                    next_title = nextp['title'].strip()
                    # Formatação do horário próximo
                    start_t = format_epg_time(nextp.get('start'))
                    stop_t = format_epg_time(nextp.get('stop'))
                    time_str = f" ({start_t} - {stop_t})" if start_t and stop_t else ""

                    plot += f"[B][COLOR white]Próximo: {next_title}{time_str}[/COLOR][/B]"

            # Título principal: Nome do canal + programa atual (se existir)
            display_label = stream_name
            if current_title:
                display_label = f"{stream_name} - {current_title}"

            li = xbmcgui.ListItem(label=f"[B][COLOR white]{display_label}[/COLOR][/B]")
            li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
            li.setProperty('IsPlayable', 'true')
            li.setInfo("video", {"title": display_label, "plot": plot.strip()})

            url = build_url({
                'action': 'play_stream',
                'stream_id': stream_id,
                'stream_type': 'live',
                'category_name': category_name,
                'server_index': server_index,
                'title_name': stream_name
            })
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vod_categories(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Categorias de Filmes[/COLOR][/B]")
    add_dir("[COLOR yellow]Buscar Filmes[/COLOR]", {'action': 'search_vod', 'category_name': category_name, 'server_index': server_index}, is_folder=True)
    categories = api.get_vod_categories()
    if categories:
        for cat in categories:
            add_dir(cat['category_name'], {'action': 'list_vod_streams', 'category_id': cat['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vod_streams(api, category_id, category_name, server_index, offset=0):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    vod_list = api.get_vod_streams(category_id, limit=PAGE_SIZE, offset=offset)
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Filmes[/COLOR][/B]")
    if vod_list:
        for v in vod_list:
            if adult_filter_enabled and any(keyword in v['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            stream_name = v['name']
            stream_id = v['stream_id']
            stream_icon = v.get('stream_icon', 'https://i.imgur.com/SJITntP.png')
            plot = v.get('plot', '')
            li = xbmcgui.ListItem(label=f"[B][COLOR white]{stream_name}[/COLOR][/B]")
            li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
            li.setProperty('IsPlayable', 'true')
            li.setInfo("video", {"title": stream_name, "genre": "[B][COLOR white]Filmes[/COLOR][/B]", "plot": plot})
            url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'category_name': category_name, 'server_index': server_index, 'title_name': stream_name})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
        if len(vod_list) == PAGE_SIZE:
            next_offset = offset + PAGE_SIZE
            add_dir("[COLOR yellow]Próxima Página >>[/COLOR]", {'action': 'list_vod_streams', 'category_id': category_id, 'category_name': category_name, 'server_index': server_index, 'offset': next_offset}, is_folder=True)
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series_categories(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Categorias de Séries[/COLOR][/B]")
    add_dir("[COLOR yellow]Buscar Séries[/COLOR]", {'action': 'search_series', 'category_name': category_name, 'server_index': server_index}, is_folder=True)
    categories = api.get_series_categories()
    if categories:
        for cat in categories:
            add_dir(cat['category_name'], {'action': 'list_series', 'category_id': cat['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.setContent(ADDON_HANDLE, 'files')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series(api, category_id, category_name, server_index, offset=0):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    series_list = api.get_series(category_id, limit=PAGE_SIZE, offset=offset)
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Séries[/COLOR][/B]")
    if series_list:
        for s in series_list:
            if adult_filter_enabled and any(keyword in s['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            series_icon = s.get('cover', 'https://i.imgur.com/SJITntP.png')
            series_id = s['series_id']
            series_name = s['name']
            plot = s.get('plot', '')
            add_dir(series_name, {'action': 'list_episodes', 'series_id': series_id, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon}, icon=series_icon, fanart=series_icon, plot=plot)
        if len(series_list) == PAGE_SIZE:
            next_offset = offset + PAGE_SIZE
            add_dir("[COLOR yellow]Próxima Página >>[/COLOR]", {'action': 'list_series', 'category_id': category_id, 'category_name': category_name, 'server_index': server_index, 'offset': next_offset}, is_folder=True)
    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(api, series_id, category_name, server_index, series_icon):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLOR white]Temporadas[/COLOR][/B]")
    series_info = api.get_series_info(series_id)
    if not series_info:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Não foi possível obter informações da série.[/COLOR][/B]")
        return

    seasons = series_info.get('seasons', [])
    episodes_data = series_info.get('episodes', {})

    season_numbers = []
    season_details = {}

    if seasons:
        for season in seasons:
            season_number = season['season_number']
            season_numbers.append(season_number)
            season_cover = season.get('cover_big') or season.get('cover') or season.get('movie_image') or series_icon
            season_details[season_number] = {
                'cover': season_cover,
                'plot': season.get('plot', '')
            }
    else:
        if isinstance(episodes_data, dict):
            season_numbers = sorted(episodes_data.keys(), key=lambda x: int(x) if x.isdigit() else 0)
            for sn in season_numbers:
                season_details[int(sn)] = {'cover': series_icon, 'plot': ''}
        elif isinstance(episodes_data, list):
            season_set = set()
            for ep in episodes_data:
                sn = ep.get('season') or ep.get('season_num')
                if sn:
                    season_set.add(int(sn) if isinstance(sn, str) and sn.isdigit() else sn)
            season_numbers = sorted(list(season_set), key=lambda x: int(x) if isinstance(x, (int, str)) and str(x).isdigit() else 0)
            for sn in season_numbers:
                season_details[sn] = {'cover': series_icon, 'plot': ''}

    if not season_numbers:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Nenhuma temporada encontrada.[/COLOR][/B]")
        return

    for season_number in season_numbers:
        season_name = f"Temporada {season_number}"
        season_icon = season_details.get(season_number, {}).get('cover', series_icon)
        plot = season_details.get(season_number, {}).get('plot', '')
        add_dir(season_name, {'action': 'list_episodes_for_season', 'series_id': series_id, 'season_number': season_number, 'category_name': category_name, 'server_index': server_index, 'series_icon': season_icon}, icon=season_icon, fanart=season_icon, plot=plot, is_folder=True)

    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes_for_season(api, series_id, season_number, category_name, server_index, series_icon):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[B][COLOR white]Episódios da Temporada {season_number}[/COLOR][/B]")
    series_info = api.get_series_info(series_id)
    if not series_info:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Não foi possível obter informações da série.[/COLOR][/B]")
        return

    episodes_data = series_info.get('episodes', {})
    episodes = []

    if isinstance(episodes_data, dict):
        episodes = episodes_data.get(str(season_number), [])
    elif isinstance(episodes_data, list):
        episodes = [ep for ep in episodes_data if str(ep.get('season', ep.get('season_num'))) == str(season_number)]

    def episode_key(ep):
        try:
            return int(ep.get('episode_num', 0))
        except ValueError:
            return 0

    episodes.sort(key=episode_key)

    if not episodes:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Nenhum episódio encontrado para esta temporada.[/COLOR][/B]")
        return

    for episode in episodes:
        ep_num = episode.get('episode_num')
        title = episode.get('title')
        ep_name = f"Episódio {ep_num}: {title}" if title else f"Episódio {ep_num}"
        plot = episode.get('plot', '')
        stream_id = episode['id']
        info = episode.get('info', {})
        ep_icon = info.get('cover_big') or info.get('movie_image') or info.get('cover') or info.get('poster_path') or series_icon
        ep_fanart = info.get('backdrop_path') or ep_icon
        li = xbmcgui.ListItem(label=f"[B][COLOR white]{ep_name}[/COLOR][/B]")
        li.setArt({'thumb': ep_icon, 'icon': ep_icon, 'fanart': ep_fanart})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": ep_name, "plot": plot, "genre": "[B][COLOR white]Séries[/COLOR][/B]"})
        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'series', 'category_name': category_name, 'server_index': server_index, 'title_name': ep_name})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_live(api, server, username, password, category_name, server_index):
    query = xbmcgui.Dialog().input("[COLOR yellow]Buscar Canais[/COLOR]")
    if not query:
        list_live_categories(api, server, username, password, category_name, server_index)
        return
    streams = api.get_live_streams()
    found = False
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[B][COLOR white]Resultados para: {query}[/COLOR][/B]")
    if streams:
        for stream in streams:
            if adult_filter_enabled and any(keyword in stream['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            if query.lower() in stream['name'].lower():
                found = True
                stream_name = stream['name']
                stream_id = stream['stream_id']
                stream_icon = stream.get('stream_icon', 'https://i.imgur.com/SJITntP.png')
                li = xbmcgui.ListItem(label=f"[B][COLOR white]{stream_name}[/COLOR][/B]")
                li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
                li.setProperty('IsPlayable', 'true')
                li.setInfo("video", {"title": stream_name})
                url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'live', 'category_name': category_name, 'server_index': server_index, 'title_name': stream_name})
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    if not found:
        xbmcgui.Dialog().ok("[B][COLOR white]Nada Encontrado[/COLOR][/B]", f"[B][COLOR white]Nenhum canal encontrado para '{query}'.[/COLOR][/B]")
        list_live_categories(api, server, username, password, category_name, server_index)
        return
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_vod(api, category_name, server_index):
    query = xbmcgui.Dialog().input("[COLOR yellow]Buscar Filmes[/COLOR]")
    if not query:
        list_vod_categories(api, category_name, server_index)
        return
    vod_list = api.get_vod_streams()
    found = False
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[B][COLOR white]Resultados para: {query}[/COLOR][/B]")
    if vod_list:
        for v in vod_list:
            if adult_filter_enabled and any(keyword in v['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            if query.lower() in v['name'].lower():
                found = True
                stream_name = v['name']
                stream_id = v['stream_id']
                stream_icon = v.get('stream_icon', 'https://i.imgur.com/SJITntP.png')
                plot = v.get('plot', '')
                li = xbmcgui.ListItem(label=f"[B][COLOR white]{stream_name}[/COLOR][/B]")
                li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
                li.setProperty('IsPlayable', 'true')
                li.setInfo("video", {"title": stream_name, "genre": "[B][COLOR white]Filmes[/COLOR][/B]", "plot": plot})
                url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'category_name': category_name, 'server_index': server_index, 'title_name': stream_name})
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    if not found:
        xbmcgui.Dialog().ok("[B][COLOR white]Nada Encontrado[/COLOR][/B]", f"[B][COLOR white]Nenhum filme encontrado para '{query}'.[/COLOR][/B]")
        list_vod_categories(api, category_name, server_index)
        return
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_series(api, category_name, server_index):
    query = xbmcgui.Dialog().input("[COLOR yellow]Buscar Séries[/COLOR]")
    if not query:
        list_series_categories(api, category_name, server_index)
        return
    series_list = api.get_series()
    found = False
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[B][COLOR white]Resultados para: {query}[/COLOR][/B]")
    if series_list:
        for s in series_list:
            if adult_filter_enabled and any(keyword in s['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            if query.lower() in s['name'].lower():
                found = True
                series_icon = s.get('cover', 'https://i.imgur.com/SJITntP.png')
                series_id = s['series_id']
                series_name = s['name']
                plot = s.get('plot', '')
                add_dir(series_name, {'action': 'list_episodes', 'series_id': series_id, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon}, icon=series_icon, fanart=series_icon, plot=plot)
    if not found:
        xbmcgui.Dialog().ok("[B][COLOR white]Nada Encontrado[/COLOR][/B]", f"[B][COLOR white]Nenhuma série encontrada para '{query}'.[/COLOR][/B]")
        list_series_categories(api, category_name, server_index)
        return
    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def resolve_and_play_stream(api, stream_id, stream_type, title_name=None):
    global VOD_PROXY_MANAGER
    stream_url = None

    if stream_type == 'live':
        stream_url = api.get_live_stream_url(stream_id)
    elif stream_type == 'vod':
        stream_url = api.get_vod_stream_url(stream_id)
    elif stream_type == 'series':
        stream_url = api.get_series_stream_url(stream_id)
    else:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Tipo de stream desconhecido.[/COLOR][/B]")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        return

    if not stream_url:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", f"[B][COLOR white]Não foi possível obter a URL para o tipo '{stream_type}'.[/COLOR][/B]")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        return

    xbmc.log(f"[ADDON] URL Original Obtida: {stream_url}", level=xbmc.LOGINFO)

    if stream_type == 'live':
        if VOD_PROXY_MANAGER and VOD_PROXY_MANAGER._is_running:
            VOD_PROXY_MANAGER.stop()
            VOD_PROXY_MANAGER = None
            xbmc.log("[ADDON] Manager VOD anterior parado antes de iniciar Live.", level=xbmc.LOGINFO)

        proxy_addon = HLSAddon(ADDON_HANDLE)
        proxy_addon.play_stream(stream_url, stream_type)

    else:
        if VOD_PROXY_MANAGER and VOD_PROXY_MANAGER._is_running:
            VOD_PROXY_MANAGER.stop()
            VOD_PROXY_MANAGER = None
            xbmc.log("[ADDON] Manager VOD anterior parado.", level=xbmc.LOGINFO)

        proxy_url, manager = resolve_vod_stream(stream_url)

        if proxy_url:
            VOD_PROXY_MANAGER = manager
            xbmc.log(f"[ADDON] Stream resolvida com URL do Proxy: {proxy_url}", level=xbmc.LOGINFO)

            li = xbmcgui.ListItem(path=proxy_url)
            li.setProperty('IsPlayable', 'true')

            display_title = title_name if title_name else "VOD Stream (Título Desconhecido)"
            li.setLabel(display_title)
            li.setInfo(type="Video", infoLabels={"Title": display_title, "mediatype": stream_type})

            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

        else:
            xbmc.log("[ADDON] Falha ao iniciar ou resolver o stream via VOD Proxy.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("[B][COLOR white]Erro de Reprodução[/COLOR][/B]", "[B][COLOR white]Não foi possível iniciar o proxy VOD.[/COLOR][/B]")
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    title_name = params.get('title_name')

    if action is None:
        servers_menu()
        return

    if action == 'category_menu':
        category_menu(params.get('category_name'))
        return

    category_name = params.get('category_name')
    server_index = params.get('server_index')
    series_icon = params.get('series_icon')

    if not category_name or server_index is None:
        if 'play_stream' not in action:
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Servidor não selecionado.[/COLOR][/B]")
            return

    try:
        menu = get_remote_menu()
        category = next((c for c in menu if c.get("categoria") == category_name), None)
        if not category:
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Categoria do servidor não encontrada no menu remoto.[/COLOR][/B]")
            return

        server_info = category['servidores'][int(server_index)]
        server = server_info.get('dns')
        username = server_info.get('username')
        password = server_info.get('password')

        if not all([server, username, password]):
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Credenciais inválidas para o servidor.[/COLOR][/B]")
            return
    except (IndexError, ValueError):
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Índice de servidor inválido.[/COLOR][/B]")
        return

    api = XtreamAPI(server, username, password)

    if action == 'server_home':
        main_menu(api, category_name, server_index)
    elif action == 'list_live_categories':
        list_live_categories(api, server, username, password, category_name, server_index)
    elif action == 'list_live_streams':
        list_live_streams(api, params.get('category_id'), server, username, password, category_name, server_index)
    elif action == 'list_vod_categories':
        list_vod_categories(api, category_name, server_index)
    elif action == 'list_vod_streams':
        offset = int(params.get('offset', 0))
        list_vod_streams(api, params.get('category_id'), category_name, server_index, offset=offset)
    elif action == 'list_series_categories':
        list_series_categories(api, category_name, server_index)
    elif action == 'list_series':
        offset = int(params.get('offset', 0))
        list_series(api, params.get('category_id'), category_name, server_index, offset=offset)
    elif action == 'list_episodes':
        list_episodes(api, params.get('series_id'), category_name, server_index, series_icon)
    elif action == 'list_episodes_for_season':
        list_episodes_for_season(api, params.get('series_id'), params.get('season_number'), category_name, server_index, series_icon)
    elif action == 'play_stream':
        resolve_and_play_stream(api, params.get('stream_id'), params.get('stream_type'), title_name)
    elif action == 'search_live':
        search_live(api, server, username, password, category_name, server_index)
    elif action == 'search_vod':
        search_vod(api, category_name, server_index)
    elif action == 'search_series':
        search_series(api, category_name, server_index)

if __name__ == '__main__':
    router(sys.argv[2][1:])