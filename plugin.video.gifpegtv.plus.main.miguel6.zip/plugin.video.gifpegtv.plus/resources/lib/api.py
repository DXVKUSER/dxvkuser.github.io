# resources/lib/api.py
# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
import xbmcaddon
import json
import os
import xbmcvfs
import time
import hashlib
import requests

# Constantes de Cache
CACHE_TTL = 3600  # 1 hora em segundos para o cache da API

try:
    ADDON_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
except Exception as e:
    ADDON_PROFILE = xbmcvfs.translatePath(os.path.join(os.getcwd(), 'profile_cache'))
    xbmc.log(f"[XtreamProxy] Fallback para ADDON_PROFILE: {e}", level=xbmc.LOGERROR)

def get_cache_path(key):
    if not xbmcvfs.exists(ADDON_PROFILE):
        xbmcvfs.mkdirs(ADDON_PROFILE)
    filename = hashlib.sha1(key.encode('utf-8')).hexdigest()
    return os.path.join(ADDON_PROFILE, f"cache_{filename}.json")

def read_cache(key):
    cache_file = get_cache_path(key)
    if not os.path.exists(cache_file):
        return None
    
    file_age = time.time() - os.path.getmtime(cache_file)
    if file_age > CACHE_TTL:
        xbmc.log(f"[XtreamProxy] Cache expirado para {key}. Idade: {file_age:.0f}s", level=xbmc.LOGINFO)
        return None

    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        xbmc.log(f"[XtreamProxy] Cache HIT para {key}", level=xbmc.LOGINFO)
        return data
    except Exception as e:
        xbmc.log(f"[XtreamProxy] Erro ao ler cache: {e}", level=xbmc.LOGERROR)
        return None

def write_cache(key, data):
    cache_file = get_cache_path(key)
    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        xbmc.log(f"[XtreamProxy] Erro ao escrever cache: {e}", level=xbmc.LOGERROR)

class XtreamAPI:
    def __init__(self, server, username, password):
        self.base_url = f"{server}"
        self.username = username
        self.password = password
        self.cache_base_key = f"{server}-{username}"
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': 'Mozilla/5.0'})

    def _make_request(self, params):
        action = params.get('action', 'unknown')
        cat_id = params.get('category_id', 'all')
        limit = params.get('limit', 0)
        offset = params.get('offset', 0)
        # CORREÇÃO: Pegando o series_id para garantir que cada série tenha seu próprio cache
        series_id = params.get('series_id', 'none')
        
        # Chave de cache mais granular (agora inclui limit/offset e o series_id)
        cache_key = f"{self.cache_base_key}-{action}-cat{cat_id}-ser{series_id}-lim{limit}-off{offset}"
        
        cached_data = read_cache(cache_key)
        if cached_data is not None:
            return cached_data
            
        params['username'] = self.username
        params['password'] = self.password
        
        try:
            response = self.session.get(f"{self.base_url}/player_api.php", params=params, timeout=100)
            response.raise_for_status()
            
            if response.text.strip() == "[]":
                result_data = []
            else:
                data = response.json()
                if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
                    xbmcgui.Dialog().ok("Erro de Autenticação", "Usuário ou senha inválidos.")
                    return None
                result_data = data

            write_cache(cache_key, result_data)
            return result_data
            
        except requests.exceptions.RequestException as e:
            xbmc.log(f"[XtreamProxy] Erro de API: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Conexão", f"Não foi possível conectar ao servidor: {e}")
            return None
        except ValueError:
            xbmc.log(f"[XtreamProxy] Erro de API: Resposta não é JSON válido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Servidor", "O servidor retornou uma resposta inválida.")
            return None

    def get_live_categories(self):
        return self._make_request({'action': 'get_live_categories'})

    def get_live_streams(self, category_id=None):
        params = {'action': 'get_live_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_vod_categories(self):
        return self._make_request({'action': 'get_vod_categories'})

    def get_vod_streams(self, category_id=None, limit=120, offset=0):
        params = {'action': 'get_vod_streams', 'limit': limit, 'offset': offset}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_categories(self):
        return self._make_request({'action': 'get_series_categories'})

    def get_series(self, category_id=None, limit=120, offset=0):
        params = {'action': 'get_series', 'limit': limit, 'offset': offset}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_info(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_live_stream_url(self, stream_id):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.m3u8"

    def get_vod_stream_url(self, stream_id):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.mp4"

    def get_series_stream_url(self, stream_id):
        return f"{self.base_url}/series/{self.username}/{self.password}/{stream_id}.mp4"