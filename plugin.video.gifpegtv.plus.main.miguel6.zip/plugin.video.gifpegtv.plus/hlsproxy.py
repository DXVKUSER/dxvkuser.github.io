# -*- coding: utf-8 -*-
import os
import re
import sys
import time
import random
import socket
import threading
import base64
import binascii
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, quote, unquote, parse_qs, urljoin

import xbmc
import xbmcgui
import xbmcplugin

try:
    import requests
    from requests.adapters import HTTPAdapter
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

# --- CONFIGURAÇÃO ---
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1"
]

CONFIG = {
    "HOST": "127.0.0.1",
    "PORT": None,
    "MAX_REDIRECTS": 5,
    "RETRY_ATTEMPTS": 3,
    "TS_CHUNK_SIZE": 65536,
    "CONNECT_TIMEOUT": 5,
    "READ_TIMEOUT": 20,
    "SESSION_TIMEOUT": 45
}

RE_URI_KEY = re.compile(r'URI="([^"]+)"')

# Cache hierárquico
playlist_cache = {}
playlist_cache_lock = threading.Lock()

def encode_url(url):
    return base64.urlsafe_b64encode(url.encode('utf-8')).decode('utf-8').rstrip('=')

def decode_url(encoded):
    padding = 4 - len(encoded) % 4
    if padding != 4:
        encoded += '=' * padding
    try:
        return base64.urlsafe_b64decode(encoded).decode('utf-8')
    except (binascii.Error, ValueError):
        return None

def generate_fake_ip():
    return f"{random.randint(11, 250)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def is_resolved_url(url):
    """Verifica se a URL já possui assinatura/token para não invalidar a sessão"""
    url_lower = url.lower()
    return any(k in url_lower for k in ['token=', 'sign=', 'hash=', 'expires=', 'auth='])

class SessionManager:
    def __init__(self):
        self._session = None
        self._lock = threading.Lock()
        self._last_used = 0
        # Identidade FIXA da sessão atual. Evita quebra de tokens entre TS e M3U8.
        self.identity_ua = random.choice(USER_AGENTS)
        self.identity_ip = generate_fake_ip()
    
    def get_session(self):
        with self._lock:
            if (self._session is None or 
                time.time() - self._last_used > CONFIG['SESSION_TIMEOUT']):
                
                if self._session:
                    try: self._session.close()
                    except: pass
                
                self._session = requests.Session()
                self._session.verify = False
                
                adapter = HTTPAdapter(pool_connections=100, pool_maxsize=20, max_retries=0)
                self._session.mount('http://', adapter)
                self._session.mount('https://', adapter)
            
            self._last_used = time.time()
            return self._session

    def rotate_identity(self):
        """Força a rotação de IP e User-Agent quando o manifesto principal falha"""
        with self._lock:
            self.identity_ua = random.choice(USER_AGENTS)
            self.identity_ip = generate_fake_ip()
            if self._session:
                try: self._session.close()
                except: pass
                self._session = None

session_manager = SessionManager()

class HLSProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        pass  # silencioso

    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            path_only = parsed.path
            target_url = None
            handler_func = None

            if path_only.startswith('/playlist/'):
                token = path_only[len('/playlist/'):].replace('.m3u8', '')
                target_url = decode_url(token)
                handler_func = self.handle_m3u8
            elif path_only.startswith('/segment/'):
                token = path_only[len('/segment/'):].replace('.ts', '')
                target_url = decode_url(token)
                handler_func = self.handle_ts
            elif path_only.startswith('/key/'):
                token = path_only[len('/key/'):].split('.')[0]
                target_url = decode_url(token)
                handler_func = self.handle_key

            if not target_url or not handler_func:
                self.send_response(200)
                self.end_headers()
                return

            handler_func(target_url)

        except Exception:
            return

    def smart_fetch(self, url, referer=None, stream=False, is_playlist=False):
        """Busca blindada: Redirecionamento manual e reconstrução de Headers para CDNs"""
        session = session_manager.get_session()
        max_retries = CONFIG['RETRY_ATTEMPTS']

        for attempt in range(max_retries):
            current_url = url
            current_referer = referer

            try:
                for _ in range(CONFIG['MAX_REDIRECTS']):
                    parsed_url = urlparse(current_url)
                    
                    # 1. Regeneração Dinâmica de Cabeçalhos (Evita erros 521 e 403 em CDNs)
                    headers = {
                        'Host': parsed_url.netloc,
                        'Origin': f"{parsed_url.scheme}://{parsed_url.netloc}",
                        'Connection': 'keep-alive',
                        'Accept': '*/*',
                        'User-Agent': session_manager.identity_ua # Identidade travada
                    }
                    if current_referer:
                        headers['Referer'] = current_referer
                    
                    # Não rotaciona/adiciona IPs fakes se já for uma URL assinada
                    if not is_resolved_url(current_url):
                        headers.update({
                            'X-Forwarded-For': session_manager.identity_ip,
                            'X-Real-IP': session_manager.identity_ip,
                            'Client-IP': session_manager.identity_ip
                        })

                    # Desativa redirecionamento automático
                    resp = session.get(
                        current_url,
                        headers=headers,
                        timeout=(CONFIG['CONNECT_TIMEOUT'], CONFIG['READ_TIMEOUT']),
                        stream=stream,
                        allow_redirects=False
                    )

                    # 2. Tratamento Manual do Redirecionamento
                    if resp.status_code in (200, 206):
                        return resp

                    elif resp.status_code in (301, 302, 303, 307, 308):
                        new_location = resp.headers.get('Location')
                        if not new_location:
                            resp.close()
                            return None
                        resp.close()
                        
                        # Atualiza referer e url para o próximo salto no loop
                        current_referer = current_url
                        current_url = urljoin(current_url, new_location)
                        continue

                    # 3. Tratamento de Erros HTTP
                    elif resp.status_code == 404:
                        resp.close()
                        if not is_playlist:
                            return None # Segmento ausente: Falha imediata (Fail Fast)
                        if attempt < max_retries - 1:
                            time.sleep(0.2)
                            break
                        return None
                        
                    else: # 401, 403, 500, 502, 503
                        resp.close()
                        if attempt < max_retries - 1:
                            time.sleep(0.2)
                            break
                        return None
                        
                return None

            except requests.exceptions.RequestException:
                if attempt < max_retries - 1:
                    time.sleep(0.1)
                else:
                    return None
        return None

    def handle_m3u8(self, url, parent=None):
        resp = self.smart_fetch(url, referer=parent, stream=False, is_playlist=True)

        # Se falhou, forçamos a rotação de identidade (novo IP/UA) e tentamos de novo a principal
        if not resp:
            session_manager.rotate_identity()
            resp = self.smart_fetch(url, referer=parent, stream=False, is_playlist=True)

        if resp:
            try:
                final_url = resp.url
                base_url = final_url.rsplit('/', 1)[0] + '/'
                content = resp.text
                lines = content.splitlines()
                output_lines = []
                proxy_host = f"http://{self.headers.get('Host', CONFIG['HOST'])}"

                for line in lines:
                    line = line.strip()
                    if not line: continue

                    if line.startswith('#'):
                        # INTERCEPTAÇÃO AES-128
                        if line.startswith('#EXT-X-KEY'):
                            match = RE_URI_KEY.search(line)
                            if match:
                                key_url = match.group(1)
                                abs_key = urljoin(base_url, key_url)
                                proxy_key = f'{proxy_host}/key/{encode_url(abs_key)}.key'
                                line = line.replace(f'URI="{key_url}"', f'URI="{proxy_key}"')
                        output_lines.append(line)
                        continue

                    abs_url = urljoin(base_url, line)
                    if '.m3u8' in line:
                        proxy_url = f'{proxy_host}/playlist/{encode_url(abs_url)}.m3u8'
                    else:
                        proxy_url = f'{proxy_host}/segment/{encode_url(abs_url)}.ts'
                    output_lines.append(proxy_url)

                output = '\n'.join(output_lines) + '\n'
                data = output.encode('utf-8')

                with playlist_cache_lock:
                    playlist_cache[url] = output

                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(data)
                return

            finally:
                if resp: resp.close()

        # Fallback de Cache para M3U8
        with playlist_cache_lock:
            if url in playlist_cache:
                output = playlist_cache[url]
                data = output.encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(data)
                return

        # Vazio para não travar
        self.send_response(200)
        self.send_header('Content-Length', '0')
        self.send_header('Connection', 'close')
        self.end_headers()

    def handle_ts(self, url, parent=None):
        resp = self.smart_fetch(url, referer=parent, stream=True, is_playlist=False)
        
        if resp:
            try:
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Accept-Ranges', 'none')
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('Connection', 'close')
                self.end_headers()

                for chunk in resp.iter_content(chunk_size=CONFIG['TS_CHUNK_SIZE']):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                        except (ConnectionResetError, BrokenPipeError, socket.error):
                            break
                        except Exception:
                            break
                return
            finally:
                if resp: resp.close()

        # FALHA SILENCIOSA NO SEGMENTO: Retorna OK com tamanho zero, player pula
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Content-Length', '0')
        self.send_header('Connection', 'close')
        self.end_headers()

    def handle_key(self, url, parent=None):
        # Baixa a chave usando as mesmas regras, IP e Headers do TS
        resp = self.smart_fetch(url, referer=parent, stream=False, is_playlist=False)
        if not resp:
            self.send_response(503)
            self.end_headers()
            return
        try:
            content = resp.content
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(content)
        finally:
            if resp: resp.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 100

    def server_bind(self):
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        super().server_bind()

class HLSAddon(object):
    _instance = None
    _is_running = False
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(HLSAddon, cls).__new__(cls)
        return cls._instance

    def __init__(self, handle=None, *args, **kwargs):
        self.handle = handle
        with HLSAddon._lock:
            if not HLSAddon._is_running:
                self.start_server()

    def start_server(self):
        for _ in range(20):
            port = random.randint(18000, 28000)
            try:
                server = ThreadedHTTPServer((CONFIG['HOST'], port), HLSProxyHandler)
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                CONFIG['PORT'] = port
                HLSAddon._is_running = True
                xbmc.log(f'[HLSProxy] Servidor iniciado em {CONFIG["HOST"]}:{port}', xbmc.LOGINFO)
                return True
            except (OSError, socket.error):
                continue
        xbmc.log('[HLSProxy] Falha ao iniciar servidor', xbmc.LOGERROR)
        return False

    def play_stream(self, stream_url, title=None, headers=None, channel_id=None, epg_id=None):
        if not CONFIG['PORT']:
            return False
        proxy_url = f"http://{CONFIG['HOST']}:{CONFIG['PORT']}/playlist/{encode_url(stream_url)}.m3u8"
        li = xbmcgui.ListItem()
        li.setPath(proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        li.setProperty('IsPlayable', 'true')

        if headers:
            header_str = '&'.join([f"{k}={quote(v)}" for k, v in headers.items()])
            li.setPath(f"{proxy_url}|{header_str}")

        try:
            handle = int(self.handle) if self.handle is not None else int(sys.argv[1])
            xbmcplugin.setResolvedUrl(handle, True, li)
            return True
        except Exception as e:
            xbmc.log(f'[HLSProxy] Erro ao iniciar reprodução: {e}', xbmc.LOGERROR)
            return False

proxy_addon = HLSAddon()