# addon.py
# -*- coding: utf-8 -*-

import sys
import os

# Garante que a pasta raiz do addon esteja no sys.path para imports locais (tsproxy, hlsproxy, etc.)
_ADDON_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)
import urllib.parse
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import time
import xbmcvfs
import html
import hashlib
import base64
from datetime import datetime

from resources.lib.api import XtreamAPI
from resources.lib.epg import load_epg, epg_lookup_current_next, normalize_epg_channel_id

from hlsproxy import HLSAddon
from vodproxy import resolve_vod_stream, VODProxyManager

import requests

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADULT_KEYWORDS = ['adult', 'xxx', '+18', 'private']

# Pré-compilar regex para filtro adulto (mais rápido que any() com 'in')
_ADULT_PATTERN = re.compile('|'.join(re.escape(kw) for kw in ADULT_KEYWORDS), re.IGNORECASE)

REMOTE_MENU_URL = "https://raw.githubusercontent.com/DXVKUSER/SRTORRENT/refs/heads/main/danie.json"
REMOTE_MENU_CACHE_FILE = "remote_menu_cache.json"

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_TTL = 24 * 3600  # 24h
REMOTE_MENU_TTL = 1800  # Aumentado de 100s para 1800s (30 min) — menu muda raramente

VOD_PROXY_MANAGER = None
PAGE_SIZE = 100  # 100 é o ponto de equilíbrio: a skin renderiza a grade quase instantânea e ainda reduz cliques de paginação vs. o padrão de 20-30 da maioria dos addons

# ============================================================
# SISTEMA DE CACHE OTIMIZADO (Memória + Disco)
# ============================================================
_cache_mem = {}
_CACHE_TTL_CATS = 600          # 10 min para categorias
_CACHE_TTL_STREAMS = 300        # 5 min para streams por categoria
_CACHE_TTL_STREAMS_ALL = 600    # 10 min para streams completos (busca)
_CACHE_TTL_EPG_SHORT = 120      # 2 min para short_epg (muda com frequência)
_CACHE_TTL_SERIES_INFO = 1800   # 30 min para series_info (raramente muda)

def _ensure_cache_dir():
    d = os.path.join(PROFILE_DIR, 'api_cache')
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)
    return d

def _cache_key(server, username, method, *args):
    raw = f"{server}|{username}|{method}|{'|'.join(str(a) for a in args)}"
    return hashlib.md5(raw.encode('utf-8')).hexdigest()

def _cache_get(key, ttl):
    # Memória primeiro (mais rápido, sem I/O)
    if key in _cache_mem:
        data, ts = _cache_mem[key]
        if time.time() - ts < ttl:
            return data
        del _cache_mem[key]
    # Disco (persiste entre sessões do addon)
    fpath = os.path.join(_ensure_cache_dir(), f'{key}.json')
    if xbmcvfs.exists(fpath):
        try:
            age = time.time() - os.path.getmtime(fpath)
            if age < ttl:
                with open(fpath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                _cache_mem[key] = (data, time.time())
                return data
        except Exception:
            pass
    return None

def _cache_set(key, data):
    _cache_mem[key] = (data, time.time())
    try:
        fpath = os.path.join(_ensure_cache_dir(), f'{key}.json')
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception:
        pass

def _is_adult(name):
    """Verificação otimizada de conteúdo adulto usando regex pré-compilado"""
    return bool(_ADULT_PATTERN.search(name))

def _clean_old_cache():
    """Remove arquivos de cache antigos (>24h) para não acumular lixo"""
    cache_dir = _ensure_cache_dir()
    try:
        now = time.time()
        for fname in os.listdir(cache_dir):
            fpath = os.path.join(cache_dir, fname)
            if os.path.isfile(fpath):
                try:
                    if now - os.path.getmtime(fpath) > 86400:
                        os.remove(fpath)
                except Exception:
                    pass
    except Exception:
        pass

# EPG parseado em memória (evita re-parsear XML a cada navegação)
_epg_mem_cache = {}

# Sessão HTTP reutilizável com connection pooling
_http_session = None

def _get_http_session():
    global _http_session
    if _http_session is None:
        _http_session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=10, pool_maxsize=10, max_retries=2
        )
        _http_session.mount('http://', adapter)
        _http_session.mount('https://://', adapter)
    return _http_session

# ============================================================
# FUNÇÕES DE CACHE PARA CHAMADAS DE API
# ============================================================

def cached_get_live_categories(api, server, username):
    key = _cache_key(server, username, 'live_cats')
    cached = _cache_get(key, _CACHE_TTL_CATS)
    if cached is not None:
        return cached
    result = api.get_live_categories()
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_live_streams(api, server, username, category_id=None):
    cid = category_id if category_id else 'all'
    ttl = _CACHE_TTL_STREAMS if category_id else _CACHE_TTL_STREAMS_ALL
    key = _cache_key(server, username, 'live_streams', cid)
    cached = _cache_get(key, ttl)
    if cached is not None:
        return cached
    result = api.get_live_streams(category_id)
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_vod_categories(api, server, username):
    key = _cache_key(server, username, 'vod_cats')
    cached = _cache_get(key, _CACHE_TTL_CATS)
    if cached is not None:
        return cached
    result = api.get_vod_categories()
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_vod_streams(api, server, username, category_id=None, limit=None, offset=None):
    cid = category_id if category_id else 'all'
    ttl = _CACHE_TTL_STREAMS if category_id else _CACHE_TTL_STREAMS_ALL
    key = _cache_key(server, username, 'vod_streams', cid, limit or 0, offset or 0)
    cached = _cache_get(key, ttl)
    if cached is not None:
        return cached
    result = api.get_vod_streams(category_id, limit=limit, offset=offset)
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_series_categories(api, server, username):
    key = _cache_key(server, username, 'series_cats')
    cached = _cache_get(key, _CACHE_TTL_CATS)
    if cached is not None:
        return cached
    result = api.get_series_categories()
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_series(api, server, username, category_id=None, limit=None, offset=None):
    cid = category_id if category_id else 'all'
    ttl = _CACHE_TTL_STREAMS if category_id else _CACHE_TTL_STREAMS_ALL
    key = _cache_key(server, username, 'series_list', cid, limit or 0, offset or 0)
    cached = _cache_get(key, ttl)
    if cached is not None:
        return cached
    result = api.get_series(category_id, limit=limit, offset=offset)
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_series_info(api, server, username, series_id):
    key = _cache_key(server, username, 'series_info', series_id)
    cached = _cache_get(key, _CACHE_TTL_SERIES_INFO)
    if cached is not None:
        return cached
    result = api.get_series_info(series_id)
    if result is not None:
        _cache_set(key, result)
    return result

def cached_get_short_epg(api, server, username, stream_id, limit=6):
    # limit=6 (antes 2): com limit=2, se o servidor retornar programas já
    # encerrados no início da lista, o programa ATUAL nem estaria na resposta
    key = _cache_key(server, username, 'short_epg', stream_id, limit)
    cached = _cache_get(key, _CACHE_TTL_EPG_SHORT)
    if cached is not None:
        return cached
    result = api.get_short_epg(stream_id, limit=limit)
    if result is not None:
        _cache_set(key, result)
    return result

def cached_load_epg(epg_xml_path, server):
    """Cache em memória para EPG parseado — evita re-parsear XML pesado"""
    global _epg_mem_cache

    if not os.path.exists(epg_xml_path):
        return {'channels': {}, 'progs': {}, '_starts': {}}

    file_mtime = os.path.getmtime(epg_xml_path)
    cache_key = f"{epg_xml_path}_{file_mtime}"

    if cache_key in _epg_mem_cache:
        return _epg_mem_cache[cache_key]

    # Limitar tamanho do cache de EPG
    if len(_epg_mem_cache) > 5:
        _epg_mem_cache.clear()

    epg = load_epg(epg_xml_path)
    _epg_mem_cache[cache_key] = epg
    return epg

# ============================================================
# FUNÇÕES ORIGINAIS OTIMIZADAS
# ============================================================

def get_setting(setting_id):
    return ADDON.getSetting(setting_id)

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_dir(name, query, icon='https://i.imgur.com/7Y2o0cs.png', fanart='https://i.imgur.com/7Y2o0cs.png', is_folder=True, plot="", poster=None):
    li = xbmcgui.ListItem(label=name)
    art = {'thumb': icon, 'icon': icon, 'fanart': fanart}
    if poster:
        # Skins com grade de capas (Arctic Horizon, Aeon Nox, etc.) priorizam
        # 'poster' (proporção 2:3) sobre 'thumb' para séries/filmes
        art['poster'] = poster
    li.setArt(art)
    if plot:
        li.setInfo("video", {"title": name, "plot": plot})
    url = build_url(query)
    li.setProperty('TakeFocus', 'true')
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def get_remote_menu():
    cache_path = os.path.join(PROFILE_DIR, REMOTE_MENU_CACHE_FILE)
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)

    if os.path.exists(cache_path):
        file_age = time.time() - os.path.getmtime(cache_path)
        if file_age < REMOTE_MENU_TTL:
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                xbmc.log("[ADDON] Menu remoto carregado do cache.", level=xbmc.LOGINFO)
                return data
            except Exception as e:
                xbmc.log(f"[ADDON] Erro ao ler cache do menu: {e}", level=xbmc.LOGERROR)

    xbmc.log(f"[ADDON] Baixando menu remoto: {REMOTE_MENU_URL}", level=xbmc.LOGINFO)
    try:
        session = _get_http_session()
        response = session.get(REMOTE_MENU_URL, timeout=15)
        response.raise_for_status()
        data = json.loads(response.text)
        if not isinstance(data, list) or not data:
            xbmc.log("[ADDON] Menu remoto vazio ou inválido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Menu remoto vazio ou inválido.[/COLOR][/B]")
            return []

        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(data, f)

        return data

    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro ao baixar menu remoto: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLOR white]Erro de Conexão[/COLOR][/B]", "[B][COLOR white]Não foi possível baixar o menu remoto. Tentando cache...[/COLOR][/B]")
        if os.path.exists(cache_path):
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                xbmc.log("[ADDON] Falha de conexão. Servindo menu do cache antigo.", level=xbmc.LOGINFO)
                return data
            except Exception:
                return []
        return []
    except (ValueError, json.JSONDecodeError):
        xbmc.log("[ADDON] Menu remoto não é JSON válido.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLOR white]Erro de Menu[/COLOR][/B]", "[B][COLOR white]O arquivo JSON remoto está inválido.[/COLOR][/B]")
        return []

def servers_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Servidores")
    menu = get_remote_menu()
    for categoria in menu:
        cat_name = categoria.get("categoria", "Sem Nome")
        icon = categoria.get("icon", "https://i.imgur.com/7Y2o0cs.png")
        fanart = categoria.get("fanart", "https://i.imgur.com/7Y2o0cs.png")
        add_dir(cat_name, {'action': 'category_menu', 'category_name': cat_name}, icon=icon, fanart=fanart, poster=icon, is_folder=True)
    # 'movies' faz skins com grade de capas (Arctic Horizon, Aeon Nox, Estuary com
    # widgets) desenharem este hub como cards visuais em vez de lista de arquivos
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def category_menu(category_name):
    menu = get_remote_menu()
    category = next((c for c in menu if c.get("categoria") == category_name), None)
    if not category:
        xbmcgui.Dialog().ok("Erro", f"Categoria '{category_name}' não encontrada.")
        return

    servidores = category.get("servidores", [])

    # Atalho de navegação: categoria com um único servidor pula direto para o
    # menu principal daquele servidor — evita um clique que não oferece escolha real
    if len(servidores) == 1:
        server = servidores[0]
        if all([server.get('dns'), server.get('username'), server.get('password')]):
            api = XtreamAPI(server.get('dns'), server.get('username'), server.get('password'))
            main_menu(api, category_name, 0)
            return

    xbmcplugin.setPluginCategory(ADDON_HANDLE, category_name)
    for i, server in enumerate(servidores):
        name = server.get("nome", "Servidor")
        imagem = server.get("icon", "https://i.imgur.com/7Y2o0cs.png")
        add_dir(name, {'action': 'server_home', 'category_name': category_name, 'server_index': i}, icon=imagem, fanart=imagem, poster=imagem, is_folder=True)
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def main_menu(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Menu Principal")
    add_dir("TV", {'action': 'list_live_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("FILMES", {'action': 'list_vod_categories', 'category_name': category_name, 'server_index': server_index},
            icon='https://i.imgur.com/7Y2o0cs.png', fanart='https://i.imgur.com/7Y2o0cs.png')
    add_dir("SÉRIES", {'action': 'list_series_categories', 'category_name': category_name, 'server_index': server_index},
            icon='https://i.imgur.com/7Y2o0cs.png', fanart='https://i.imgur.com/7Y2o0cs.png')
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_epg_xml_path(server):
    server_hash = hashlib.md5(server.encode('utf-8')).hexdigest()
    return os.path.join(PROFILE_DIR, f'epg_{server_hash}.xml')

def download_epg(server, username, password):
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)
    epg_xml_path = get_epg_xml_path(server)
    url = f"{server.rstrip('/')}/xmltv.php?username={username}&password={password}"
    xbmc.log(f"[ADDON] Baixando EPG para o servidor: {server}", level=xbmc.LOGINFO)

    dialog = xbmcgui.DialogProgress()
    dialog.create("[B][COLOR white]Atualizando EPG[/COLOR][/B]", "Preparando para baixar dados do EPG...")

    try:
        session = _get_http_session()
        response = session.get(url, timeout=90, stream=True)
        response.raise_for_status()

        total_size = int(response.headers.get('content-length', 0))
        block_size = 1024 * 1024
        bytes_downloaded = 0

        with open(epg_xml_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=block_size):
                if dialog.iscanceled():
                    raise Exception("Download Cancelado pelo Usuário")
                f.write(chunk)
                bytes_downloaded += len(chunk)

                if total_size > 0:
                    percent = int(bytes_downloaded * 100 / total_size)
                    dialog.update(percent, f"[B][COLOR white]Baixando EPG:[/COLOR][/B] {bytes_downloaded / (1024*1024):.1f}MB de {total_size / (1024*1024):.1f}MB")
                else:
                    dialog.update(0, f"[B][COLOR white]Baixando EPG (tamanho desconhecido)...[/COLOR][/B]\nBaixados: {bytes_downloaded / (1024*1024):.1f}MB")
        xbmc.log(f"[ADDON] EPG baixado com sucesso: {epg_xml_path}", level=xbmc.LOGINFO)
        return epg_xml_path
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro ao baixar EPG: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLOR white]Erro de EPG[/COLOR][/B]", f"[B][COLOR white]Não foi possível baixar o EPG: {e}[/COLOR][/B]")
        return None
    finally:
        dialog.close()

def format_epg_time(time_str):
    """Helper to format XMLTV time string to HH:MM"""
    if not time_str or len(str(time_str)) < 12:
        return ""
    try:
        s = str(time_str)
        return f"{s[8:10]}:{s[10:12]}"
    except Exception:
        return ""

def _decode_epg_field(value):
    if not value:
        return ""
    try:
        padded = value + '=' * (-len(value) % 4)
        return base64.b64decode(padded).decode('utf-8', errors='replace').strip()
    except Exception:
        return value.strip()

def _format_short_epg_time(ts):
    try:
        return datetime.fromtimestamp(int(ts)).strftime('%H:%M')
    except Exception:
        return ""

# ============================================================
# CORREÇÃO EPG: DETECÇÃO DO PROGRAMA ATUAL POR TIMESTAMP
# ============================================================

def _parse_epg_ts(val):
    """Converte timestamp (string/int) do Xtream para int unix. None se inválido."""
    try:
        v = int(str(val))
        return v if v > 0 else None
    except (TypeError, ValueError):
        return None

def _parse_epg_dt(dt_str):
    """Converte 'YYYY-MM-DD HH:MM:SS' para timestamp unix (fallback)."""
    try:
        return int(datetime.strptime(str(dt_str).strip(), "%Y-%m-%d %H:%M:%S").timestamp())
    except Exception:
        return None

def _epg_current_next(listings):
    """
    CORREÇÃO EPG: determina o programa AGORA e A SEGUIR a partir dos
    listings do get_short_epg.

    Antes o código assumia que listings[0] era o programa atual e
    listings[1] o próximo — porém muitos servidores Xtream retornam a
    lista iniciando em programas JÁ ENCERRADOS (janela do EPG do dia),
    exibindo um programa antigo como se estivesse no ar.

    Agora: ordena por start_timestamp, normaliza horário de fim
    ausente/inválido e localiza o programa cuja janela
    (start <= agora < stop) contém o momento atual — mesma lógica
    aplicada no painel (endpoint /epg/now).

    Retorna (current, next) — dicts com title/desc/start_hm/stop_hm —
    ou (None, None).
    """
    if not listings:
        return None, None

    now = int(time.time())
    items = []

    for e in listings:
        if not isinstance(e, dict):
            continue
        st = _parse_epg_ts(e.get('start_timestamp'))
        et = _parse_epg_ts(e.get('stop_timestamp'))
        if st is None:
            st = _parse_epg_dt(e.get('start'))
        if et is None:
            et = _parse_epg_dt(e.get('end'))
        if st is None:
            continue
        items.append({
            'st': st,
            'et': et,
            'title': _decode_epg_field(e.get('title')),
            'desc': _decode_epg_field(e.get('description')),
        })

    if not items:
        return None, None

    items.sort(key=lambda x: x['st'])

    # Normaliza fim ausente/inválido: usa início do próximo (ou 30min no último)
    for i in range(len(items)):
        if not items[i]['et'] or items[i]['et'] <= items[i]['st']:
            items[i]['et'] = items[i + 1]['st'] if i + 1 < len(items) else items[i]['st'] + 1800

    current = None
    nextp = None

    for i, it in enumerate(items):
        if it['st'] <= now < it['et']:
            current = it
            nextp = items[i + 1] if i + 1 < len(items) else None
            break

    if current is None:
        # Gap no EPG: nenhum programa no ar — o próximo é o primeiro futuro
        for it in items:
            if it['st'] > now:
                nextp = it
                break

    def _pack(p):
        if not p:
            return None
        return {
            'title': p['title'],
            'desc': p['desc'],
            'start_hm': _format_short_epg_time(p['st']),
            'stop_hm': _format_short_epg_time(p['et']),
        }

    return _pack(current), _pack(nextp)

def list_live_categories(api, server, username, password, category_name, server_index):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    show_epg_enabled = get_setting("show_epg") == 'true'
    epg_source = get_setting("epg_source")
    use_xmltv = show_epg_enabled and 'API' not in epg_source

    if use_xmltv:
        epg_xml_path = get_epg_xml_path(server)
        if not os.path.exists(epg_xml_path) or (time.time() - os.path.getmtime(epg_xml_path) > EPG_TTL):
            download_epg(server, username, password)

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias de TV")
    add_dir("[COLOR darkturquoise]Buscar Canais[/COLOR]", {'action': 'search_live', 'category_name': category_name, 'server_index': server_index}, is_folder=True)

    categories = None
    error_occurred = False
    error_message = ""

    try:
        categories = cached_get_live_categories(api, server, username)
        if categories is None or not isinstance(categories, list):
            raise Exception("Resposta inválida ou vazia para get_live_categories")
    except Exception as e:
        error_occurred = True
        error_message = str(e)
        xbmc.log(f"[ADDON] Falha ao obter categorias: {error_message}", level=xbmc.LOGWARNING)

    has_visible_categories = False

    if not error_occurred and categories:
        for cat in categories:
            cat_name = cat.get('category_name', '').strip()
            if not cat_name:
                continue
            if adult_filter_enabled and _is_adult(cat_name):
                continue
            add_dir(cat_name, {
                'action': 'list_live_streams',
                'category_id': cat.get('category_id'),
                'category_name': category_name,
                'server_index': server_index
            })
            has_visible_categories = True

    if error_occurred or not has_visible_categories:
        add_dir("[COLOR darkturquoise]Todos os Canais[/COLOR]", {
            'action': 'list_live_streams',
            'category_name': category_name,
            'server_index': server_index
        }, is_folder=True)

        if error_occurred and ("403" in error_message or "forbidden" in error_message.lower()):
            xbmcgui.Dialog().ok(
                "[B][COLOR darkturquoise]Aviso do Servidor[/COLOR][/B]",
                "Este servidor bloqueou o acesso à lista de categorias (provavelmente erro 403).\n\n"
                "Você ainda pode:\n"
                "  • Usar [COLOR darkturquoise]Buscar Canais[/COLOR]\n"
                "  • Acessar [COLOR darkturquoise]Todos os Canais[/COLOR] (lista completa)\n\n"
                "Isso é uma restrição do provedor."
            )

    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_live_streams(api, category_id, server, username, password, category_name, server_index):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    show_epg_enabled = get_setting("show_epg") == 'true'
    epg_source = get_setting("epg_source")
    use_api_epg = show_epg_enabled and 'API' in epg_source

    epg = None
    if show_epg_enabled and not use_api_epg:
        epg_xml_path = get_epg_xml_path(server)
        epg = cached_load_epg(epg_xml_path, server)

    streams = cached_get_live_streams(api, server, username, category_id if category_id else None)

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Canais")

    if streams and isinstance(streams, list):
        # ============================================================
        # EPG PRE-FETCH EM BLOCOS (PARALELO) PARA API SHORT EPG
        # Busca EPG de todos os canais em paralelo (blocos de 10 canais
        # simultâneos) para acelerar drasticamente o carregamento
        # ============================================================
        _epg_api_cache = {}
        if use_api_epg:
            from concurrent.futures import ThreadPoolExecutor, as_completed

            # Coleta todos os stream_ids que precisam de EPG
            _epg_stream_ids = []
            for stream in streams:
                if adult_filter_enabled and _is_adult(stream.get('name', '')):
                    continue
                sid = stream.get('stream_id')
                if sid:
                    _epg_stream_ids.append(sid)

            # Função wrapper para buscar EPG de um canal
            def _fetch_one_epg(sid):
                try:
                    # limit=6 (antes 2): garante que o programa ATUAL esteja
                    # na lista mesmo quando o servidor retorna programas já
                    # encerrados no início
                    return sid, cached_get_short_epg(api, server, username, sid, limit=6)
                except Exception:
                    return sid, None

            # Busca EPG em paralelo (chunks de 10 requisições simultâneas)
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = [executor.submit(_fetch_one_epg, sid) for sid in _epg_stream_ids]
                for future in as_completed(futures):
                    try:
                        sid, listings = future.result()
                        _epg_api_cache[sid] = listings
                    except Exception:
                        pass

        for stream in streams:
            if adult_filter_enabled and _is_adult(stream.get('name', '')):
                continue

            stream_name = stream.get('name', 'Sem nome')
            stream_id = stream.get('stream_id')
            if not stream_id:
                continue

            stream_icon = stream.get('stream_icon', 'https://i.imgur.com/7Y2o0cs.png')
            epg_channel_id = stream.get('epg_channel_id')

            current_title = ""
            next_title = ""
            plot = ""

            if show_epg_enabled:
                if use_api_epg:
                    # Usa o cache pre-carregado em paralelo (muito mais rapido)
                    # CORREÇÃO EPG: NÃO assume que listings[0] é o programa
                    # atual. Localiza AGORA/A SEGUIR por timestamp (janela
                    # start <= agora < stop), igual ao painel.
                    listings = _epg_api_cache.get(stream_id)
                    cur, nxt = _epg_current_next(listings)
                    if cur and cur['title']:
                        current_title = cur['title']
                        time_str = f" ({cur['start_hm']} - {cur['stop_hm']})" if cur['start_hm'] and cur['stop_hm'] else ""
                        plot += f"{current_title}{time_str}\n{cur['desc']}\n"
                    if nxt and nxt['title']:
                        next_title = nxt['title']
                        time_str = f" ({nxt['start_hm']} - {nxt['stop_hm']})" if nxt['start_hm'] and nxt['stop_hm'] else ""
                        plot += f"Próximo: {next_title}{time_str}"
                else:
                    if epg_channel_id:
                        current, nextp = epg_lookup_current_next(epg_channel_id, epg)
                        if current and current.get('title'):
                            current_title = current['title'].strip()
                            start_t = format_epg_time(current.get('start'))
                            stop_t = format_epg_time(current.get('stop'))
                            time_str = f" ({start_t} - {stop_t})" if start_t and stop_t else ""
                            plot += f"{current_title}{time_str}\n{current.get('desc', '')}\n"
                        if nextp and nextp.get('title'):
                            next_title = nextp['title'].strip()
                            start_t = format_epg_time(nextp.get('start'))
                            stop_t = format_epg_time(nextp.get('stop'))
                            time_str = f" ({start_t} - {stop_t})" if start_t and stop_t else ""
                            plot += f"Próximo: {next_title}{time_str}"

            display_label = stream_name
            if current_title:
                display_label = f"{stream_name} - {current_title}"

            li = xbmcgui.ListItem(label=display_label)
            fanart_img = stream_icon if stream_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/7Y2o0cs.png'
            li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': fanart_img})
            li.setProperty('IsPlayable', 'true')
            li.setInfo("video", {"title": display_label, "plot": plot.strip()})

            url = build_url({
                'action': 'play_stream',
                'stream_id': stream_id,
                'stream_type': 'live',
                'category_name': category_name,
                'server_index': server_index,
                'title_name': stream_name
            })
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vod_categories(api, server, username, category_name, server_index):
    adult_filter_enabled = get_setting("adult_filter") == 'true'

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias de Filmes")
    add_dir("[COLOR darkturquoise]Buscar Filmes[/COLOR]", {'action': 'search_vod', 'category_name': category_name, 'server_index': server_index}, is_folder=True)

    categories = cached_get_vod_categories(api, server, username)
    if categories:
        for cat in categories:
            cat_name = cat.get('category_name', '')
            if adult_filter_enabled and _is_adult(cat_name):
                continue

            add_dir(cat_name, {'action': 'list_vod_streams', 'category_id': cat['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vod_streams(api, server, username, category_id, category_name, server_index, offset=0):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    vod_list = cached_get_vod_streams(api, server, username, category_id, limit=PAGE_SIZE, offset=offset)
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Filmes")
    if vod_list:
        for v in vod_list:
            if adult_filter_enabled and _is_adult(v['name']):
                continue
            stream_name = v['name']
            stream_id = v['stream_id']
            stream_icon = v.get('stream_icon', 'https://i.imgur.com/7Y2o0cs.png')
            plot = v.get('plot', '')
            li = xbmcgui.ListItem(label=stream_name)
            fanart_img = stream_icon if stream_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/gaaKYUP.jpeg'
            # No Xtream Codes, stream_icon de VOD é a capa do filme (não um logo),
            # então também serve como 'poster' para grades verticais estilo Netflix
            li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'poster': stream_icon, 'fanart': fanart_img})
            li.setProperty('IsPlayable', 'true')
            li.setInfo("video", {"title": stream_name, "genre": "Filmes", "plot": plot})
            url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'category_name': category_name, 'server_index': server_index, 'title_name': stream_name})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
        if len(vod_list) == PAGE_SIZE:
            next_offset = offset + PAGE_SIZE
            add_dir("[COLOR darkturquoise]Próxima Página >>[/COLOR]", {'action': 'list_vod_streams', 'category_id': category_id, 'category_name': category_name, 'server_index': server_index, 'offset': next_offset}, is_folder=True)
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series_categories(api, server, username, category_name, server_index):
    adult_filter_enabled = get_setting("adult_filter") == 'true'

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias de Séries")
    add_dir("[COLOR darkturquoise]Buscar Séries[/COLOR]", {'action': 'search_series', 'category_name': category_name, 'server_index': server_index}, is_folder=True)

    categories = cached_get_series_categories(api, server, username)
    if categories:
        for cat in categories:
            cat_name = cat.get('category_name', '')
            if adult_filter_enabled and _is_adult(cat_name):
                continue

            add_dir(cat_name, {'action': 'list_series', 'category_id': cat['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series(api, server, username, category_id, category_name, server_index, offset=0):
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    series_list = cached_get_series(api, server, username, category_id, limit=PAGE_SIZE, offset=offset)
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Séries")
    if series_list:
        for s in series_list:
            if adult_filter_enabled and _is_adult(s['name']):
                continue
            series_icon = s.get('cover', 'https://i.imgur.com/7Y2o0cs.png')
            series_id = s['series_id']
            series_name = s['name']
            plot = s.get('plot', '')
            fanart_img = series_icon if series_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/gaaKYUP.jpeg'
            add_dir(series_name, {'action': 'list_episodes', 'series_id': series_id, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon}, icon=series_icon, fanart=fanart_img, poster=series_icon, plot=plot)
        if len(series_list) == PAGE_SIZE:
            next_offset = offset + PAGE_SIZE
            add_dir("[COLOR darkturquoise]Próxima Página >>[/COLOR]", {'action': 'list_series', 'category_id': category_id, 'category_name': category_name, 'server_index': server_index, 'offset': next_offset}, is_folder=True)
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(api, server, username, series_id, category_name, server_index, series_icon):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Temporadas")
    series_info = cached_get_series_info(api, server, username, series_id)
    if not series_info:
        xbmcgui.Dialog().ok("Erro", "Não foi possível obter informações da série.")
        return

    seasons = series_info.get('seasons', [])
    episodes_data = series_info.get('episodes', {})

    season_numbers = []
    season_details = {}

    if seasons:
        for season in seasons:
            season_number = season['season_number']
            season_numbers.append(season_number)
            season_cover = season.get('cover_big') or season.get('cover') or season.get('movie_image') or series_icon
            season_details[season_number] = {
                'cover': season_cover,
                'plot': season.get('plot', '')
            }
    else:
        if isinstance(episodes_data, dict):
            season_numbers = sorted(episodes_data.keys(), key=lambda x: int(x) if x.isdigit() else 0)
            for sn in season_numbers:
                season_details[int(sn)] = {'cover': series_icon, 'plot': ''}
        elif isinstance(episodes_data, list):
            season_set = set()
            for ep in episodes_data:
                sn = ep.get('season') or ep.get('season_num')
                if sn:
                    season_set.add(int(sn) if isinstance(sn, str) and sn.isdigit() else sn)
            season_numbers = sorted(list(season_set), key=lambda x: int(x) if isinstance(x, (int, str)) and str(x).isdigit() else 0)
            for sn in season_numbers:
                season_details[sn] = {'cover': series_icon, 'plot': ''}

    if not season_numbers:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Nenhuma temporada encontrada.[/COLOR][/B]")
        return

    for season_number in season_numbers:
        season_name = f"Temporada {season_number}"
        season_icon = season_details.get(season_number, {}).get('cover', series_icon)
        plot = season_details.get(season_number, {}).get('plot', '')
        fanart_img = season_icon if season_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/gaaKYUP.jpeg'
        add_dir(season_name, {'action': 'list_episodes_for_season', 'series_id': series_id, 'season_number': season_number, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon}, icon=season_icon, fanart=fanart_img, poster=season_icon, plot=plot, is_folder=True)

    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes_for_season(api, server, username, series_id, season_number, category_name, server_index, series_icon):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Episódios da Temporada {season_number}")
    series_info = cached_get_series_info(api, server, username, series_id)
    if not series_info:
        xbmcgui.Dialog().ok("Erro", "Não foi possível obter informações da série.")
        return

    episodes_data = series_info.get('episodes', {})
    episodes = []

    if isinstance(episodes_data, dict):
        episodes = episodes_data.get(str(season_number), [])
    elif isinstance(episodes_data, list):
        episodes = [ep for ep in episodes_data if str(ep.get('season', ep.get('season_num'))) == str(season_number)]

    def episode_key(ep):
        try:
            return int(ep.get('episode_num', 0))
        except ValueError:
            return 0

    episodes.sort(key=episode_key)

    if not episodes:
        xbmcgui.Dialog().ok("Erro", "Nenhum episódio encontrado para esta temporada.")
        return

    for episode in episodes:
        ep_num = episode.get('episode_num')
        title = episode.get('title')
        ep_name = f"Episódio {ep_num}: {title}" if title else f"Episódio {ep_num}"
        plot = episode.get('plot', '')
        stream_id = episode['id']
        info = episode.get('info', {})
        ep_icon = info.get('cover_big') or info.get('movie_image') or info.get('cover') or info.get('poster_path') or series_icon
        ep_fanart = info.get('backdrop_path') or ep_icon
        li = xbmcgui.ListItem(label=ep_name)
        li.setArt({'thumb': ep_icon, 'icon': ep_icon, 'fanart': ep_fanart})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": ep_name, "plot": plot, "genre": "Séries"})
        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'series', 'category_name': category_name, 'server_index': server_index, 'title_name': ep_name})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(ADDON_HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_live(api, server, username, password, category_name, server_index):
    query = xbmcgui.Dialog().input("[COLOR darkturquoise]Buscar Canais[/COLOR]")
    if not query:
        list_live_categories(api, server, username, password, category_name, server_index)
        return
    streams = cached_get_live_streams(api, server, username, None)
    found = False
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    query_lower = query.lower()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Resultados para: {query}")
    if streams:
        for stream in streams:
            if adult_filter_enabled and _is_adult(stream['name']):
                continue
            if query_lower in stream['name'].lower():
                found = True
                stream_name = stream['name']
                stream_id = stream['stream_id']
                stream_icon = stream.get('stream_icon', 'https://i.imgur.com/7Y2o0cs.png')
                fanart_img = stream_icon if stream_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/gaaKYUP.jpeg'
                li = xbmcgui.ListItem(label=stream_name)
                li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': fanart_img})
                li.setProperty('IsPlayable', 'true')
                li.setInfo("video", {"title": stream_name})
                url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'live', 'category_name': category_name, 'server_index': server_index, 'title_name': stream_name})
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    if not found:
        xbmcgui.Dialog().ok("Nada Encontrado", f"Nenhum canal encontrado para '{query}'.")
        list_live_categories(api, server, username, password, category_name, server_index)
        return
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_vod(api, server, username, category_name, server_index):
    query = xbmcgui.Dialog().input("[COLOR darkturquoise]Buscar Filmes[/COLOR]")
    if not query:
        list_vod_categories(api, server, username, category_name, server_index)
        return
    vod_list = cached_get_vod_streams(api, server, username, None)
    found = False
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    query_lower = query.lower()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Resultados para: {query}")
    if vod_list:
        for v in vod_list:
            if adult_filter_enabled and _is_adult(v['name']):
                continue
            if query_lower in v['name'].lower():
                found = True
                stream_name = v['name']
                stream_id = v['stream_id']
                stream_icon = v.get('stream_icon', 'https://i.imgur.com/7Y2o0cs.png')
                plot = v.get('plot', '')
                fanart_img = stream_icon if stream_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/gaaKYUP.jpeg'
                li = xbmcgui.ListItem(label=stream_name)
                li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'poster': stream_icon, 'fanart': fanart_img})
                li.setProperty('IsPlayable', 'true')
                li.setInfo("video", {"title": stream_name, "genre": "Filmes", "plot": plot})
                url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'category_name': category_name, 'server_index': server_index, 'title_name': stream_name})
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    if not found:
        xbmcgui.Dialog().ok("Nada Encontrado", f"Nenhum filme encontrado para '{query}'.")
        list_vod_categories(api, server, username, category_name, server_index)
        return
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_series(api, server, username, category_name, server_index):
    query = xbmcgui.Dialog().input("[COLOR darkturquoise]Buscar Séries[/COLOR]")
    if not query:
        list_series_categories(api, server, username, category_name, server_index)
        return
    series_list = cached_get_series(api, server, username, None)
    found = False
    adult_filter_enabled = get_setting("adult_filter") == 'true'
    query_lower = query.lower()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Resultados para: {query}")
    if series_list:
        for s in series_list:
            if adult_filter_enabled and _is_adult(s['name']):
                continue
            if query_lower in s['name'].lower():
                found = True
                series_icon = s.get('cover', 'https://i.imgur.com/7Y2o0cs.png')
                series_id = s['series_id']
                series_name = s['name']
                plot = s.get('plot', '')
                fanart_img = series_icon if series_icon != 'https://i.imgur.com/7Y2o0cs.png' else 'https://i.imgur.com/gaaKYUP.jpeg'
                add_dir(series_name, {'action': 'list_episodes', 'series_id': series_id, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon}, icon=series_icon, fanart=fanart_img, poster=series_icon, plot=plot)
    if not found:
        xbmcgui.Dialog().ok("Nada Encontrado", f"Nenhuma série encontrada para '{query}'.")
        list_series_categories(api, server, username, category_name, server_index)
        return
    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def resolve_and_play_stream(api, stream_id, stream_type, title_name=None):
    global VOD_PROXY_MANAGER
    stream_url = None

    if stream_type == 'live':
        stream_url = api.get_live_stream_url(stream_id)
    elif stream_type == 'vod':
        stream_url = api.get_vod_stream_url(stream_id)
    elif stream_type == 'series':
        stream_url = api.get_series_stream_url(stream_id)
    else:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Tipo de stream desconhecido.[/COLOR][/B]")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        return

    if not stream_url:
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", f"[B][COLOR white]Não foi possível obter a URL para o tipo '{stream_type}'.[/COLOR][/B]")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        return

    xbmc.log(f"[ADDON] URL Original Obtida: {stream_url}", level=xbmc.LOGINFO)

    if stream_type == 'live':
        if VOD_PROXY_MANAGER and VOD_PROXY_MANAGER._is_running:
            VOD_PROXY_MANAGER.stop()
            VOD_PROXY_MANAGER = None
            xbmc.log("[ADDON] Manager VOD anterior parado antes de iniciar Live.", level=xbmc.LOGINFO)

        live_format = ADDON.getSetting('live_stream_format')

        if 'TS' in live_format and 'HLS' not in live_format:
            try:
                import importlib
                ts_mod = importlib.import_module('tsproxy')
            except ImportError as e:
                xbmc.log(f"[ADDON] tsproxy não encontrado: {e}", level=xbmc.LOGERROR)
                xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]",
                                    "[B][COLOR white]tsproxy.py não encontrado na pasta do addon.[/COLOR][/B]")
                xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
                return

            ts_url = api.get_live_stream_url_ts(stream_id)
            xbmc.log(f"[ADDON] Live TS URL: {ts_url}", level=xbmc.LOGINFO)

            ts_port = ts_mod._ensure_server_running()
            xbmc.log(f"[ADDON] TSProxy ativo na porta {ts_port}", level=xbmc.LOGINFO)

            proxy_url = f"http://127.0.0.1:{ts_port}/stream?url={urllib.parse.quote(ts_url)}"
            li = xbmcgui.ListItem(path=proxy_url)
            li.setProperty('IsPlayable', 'true')
            li.setMimeType('video/mp2t')
            li.setContentLookup(False)
            display_title = title_name if title_name else "Live TS Stream"
            li.setLabel(display_title)
            li.setInfo(type="Video", infoLabels={"Title": display_title, "mediatype": "video"})
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
        else:
            proxy_addon = HLSAddon(ADDON_HANDLE)
            proxy_addon.play_stream(stream_url)

    else:
        if VOD_PROXY_MANAGER and VOD_PROXY_MANAGER._is_running:
            VOD_PROXY_MANAGER.stop()
            VOD_PROXY_MANAGER = None
            xbmc.log("[ADDON] Manager VOD anterior parado.", level=xbmc.LOGINFO)

        proxy_url, manager = resolve_vod_stream(stream_url)

        if proxy_url:
            VOD_PROXY_MANAGER = manager
            xbmc.log(f"[ADDON] Stream resolvida com URL do Proxy: {proxy_url}", level=xbmc.LOGINFO)

            li = xbmcgui.ListItem(path=proxy_url)
            li.setProperty('IsPlayable', 'true')

            display_title = title_name if title_name else "VOD Stream (Título Desconhecido)"
            li.setLabel(display_title)
            li.setInfo(type="Video", infoLabels={"Title": display_title, "mediatype": stream_type})

            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

        else:
            xbmc.log("[ADDON] Falha ao iniciar ou resolver o stream via VOD Proxy.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("[B][COLOR white]Erro de Reprodução[/COLOR][/B]", "[B][COLOR white]Não foi possível iniciar o proxy VOD.[/COLOR][/B]")
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    title_name = params.get('title_name')

    if action is None:
        servers_menu()
        return

    if action == 'category_menu':
        category_menu(params.get('category_name'))
        return

    category_name = params.get('category_name')
    server_index = params.get('server_index')
    series_icon = params.get('series_icon')

    if not category_name or server_index is None:
        if 'play_stream' not in action:
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Servidor não selecionado.[/COLOR][/B]")
            return

    try:
        menu = get_remote_menu()
        category = next((c for c in menu if c.get("categoria") == category_name), None)
        if not category:
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Categoria do servidor não encontrada no menu remoto.[/COLOR][/B]")
            return

        server_info = category['servidores'][int(server_index)]
        server = server_info.get('dns')
        username = server_info.get('username')
        password = server_info.get('password')

        if not all([server, username, password]):
            xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Credenciais inválidas para o servidor.[/COLOR][/B]")
            return
    except (IndexError, ValueError):
        xbmcgui.Dialog().ok("[B][COLOR white]Erro[/COLOR][/B]", "[B][COLOR white]Índice de servidor inválido.[/COLOR][/B]")
        return

    api = XtreamAPI(server, username, password)

    if action == 'server_home':
        main_menu(api, category_name, server_index)
    elif action == 'list_live_categories':
        list_live_categories(api, server, username, password, category_name, server_index)
    elif action == 'list_live_streams':
        list_live_streams(api, params.get('category_id'), server, username, password, category_name, server_index)
    elif action == 'list_vod_categories':
        list_vod_categories(api, server, username, category_name, server_index)
    elif action == 'list_vod_streams':
        offset = int(params.get('offset', 0))
        list_vod_streams(api, server, username, params.get('category_id'), category_name, server_index, offset=offset)
    elif action == 'list_series_categories':
        list_series_categories(api, server, username, category_name, server_index)
    elif action == 'list_series':
        offset = int(params.get('offset', 0))
        list_series(api, server, username, params.get('category_id'), category_name, server_index, offset=offset)
    elif action == 'list_episodes':
        list_episodes(api, server, username, params.get('series_id'), category_name, server_index, series_icon)
    elif action == 'list_episodes_for_season':
        list_episodes_for_season(api, server, username, params.get('series_id'), params.get('season_number'), category_name, server_index, series_icon)
    elif action == 'play_stream':
        resolve_and_play_stream(api, params.get('stream_id'), params.get('stream_type'), title_name)
    elif action == 'search_live':
        search_live(api, server, username, password, category_name, server_index)
    elif action == 'search_vod':
        search_vod(api, server, username, category_name, server_index)
    elif action == 'search_series':
        search_series(api, server, username, category_name, server_index)

if __name__ == '__main__':
    _clean_old_cache()
    router(sys.argv[2][1:])