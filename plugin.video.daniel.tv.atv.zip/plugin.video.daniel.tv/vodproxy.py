# -*- coding: utf-8 -*-
import sys
import threading
import random
import urllib.parse
import time
import os
import http.server
import socketserver
import socket
import ssl 
import warnings 
import re
import json

# Importações do Kodi
import xbmc
import xbmcaddon
import xbmcvfs

# --- IMPORTAÇÕES DE REDE ---
try:
    import requests
    from requests.adapters import HTTPAdapter
except ImportError:
    xbmc.log("[VOD-PROXY] Erro: Requests não instalado.", xbmc.LOGERROR)

# ---------------- CONFIGURAÇÕES ----------------

DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1MB para VOD
CONNECTION_TIMEOUT = 30.0
CONNECT_TRY_TIMEOUT = 6.0   # timeout de conexão por tentativa (IP DoH / URL original)
STREAM_TIMEOUT = 120.0 
MAX_REDIRECTS = 10

BIND_HOST = '0.0.0.0'      
ACCESS_HOST = '127.0.0.1'  
MAX_PORT_ATTEMPTS = 50

CONFIG = {
    'SESSION_TIMEOUT': 300,
}

warnings.filterwarnings("ignore")
try:
    import urllib3
    urllib3.disable_warnings()
except: pass

# ---------------- DOH RESOLVER ----------------
# Resolvedor DNS over HTTPS - resolve apenas hostnames, ignora IPs

DOH_SERVERS = [
    'https://1.1.1.1/dns-query',
    'https://8.8.8.8/resolve',
    'https://9.9.9.9:5053/dns-query',
    'https://dns.google/resolve',
]

DOH_CACHE_TTL = 300  # 5 minutos

_doh_cache = {}
_doh_cache_lock = threading.Lock()

def _is_ip_address(host):
    """Verifica se o host já é um endereço IP (IPv4 ou IPv6)."""
    if not host:
        return False
    try:
        socket.inet_pton(socket.AF_INET, host)
        return True
    except (OSError, ValueError, socket.error):
        pass
    try:
        socket.inet_pton(socket.AF_INET6, host)
        return True
    except (OSError, ValueError, socket.error):
        return False

def _doh_query_cloudflare(doh_url, hostname):
    """Query DoH no formato Cloudflare (application/dns-json)."""
    headers = {'accept': 'application/dns-json'}
    params = {'name': hostname, 'type': 'A'}
    resp = requests.get(doh_url, headers=headers, params=params,
                        timeout=2, verify=False)
    if resp.status_code != 200:
        return None
    data = resp.json()
    answers = data.get('Answer') or []
    for ans in answers:
        if ans.get('type') == 1:  # A record
            ip = ans.get('data')
            if ip and _is_ip_address(ip):
                return ip
    return None

def _doh_query_google(doh_url, hostname):
    """Query DoH no formato Google (application/dns-json)."""
    headers = {'accept': 'application/dns-json'}
    params = {'name': hostname, 'type': 'A'}
    resp = requests.get(doh_url, headers=headers, params=params,
                        timeout=2, verify=False)
    if resp.status_code != 200:
        return None
    data = resp.json()
    answer = data.get('Answer')
    if isinstance(answer, list):
        for ans in answer:
            if ans.get('type') == 1:
                ip = ans.get('data')
                if ip and _is_ip_address(ip):
                    return ip
    elif isinstance(answer, str) and _is_ip_address(answer):
        return answer
    return None

def doh_resolve(hostname):
    """
    Resolve um hostname usando DoH (DNS over HTTPS).
    Retorna o próprio valor se já for IP, None ou vazio.
    """
    if not hostname:
        return hostname

    # Ignora se já for IP
    if _is_ip_address(hostname):
        xbmc.log(f"[VOD-PROXY] DoH: já é IP, ignorando -> {hostname}", xbmc.LOGDEBUG)
        return hostname

    # Verifica cache
    with _doh_cache_lock:
        cached = _doh_cache.get(hostname)
        if cached and (time.time() - cached[0]) < DOH_CACHE_TTL:
            xbmc.log(f"[VOD-PROXY] DoH cache hit: {hostname} -> {cached[1]}", xbmc.LOGDEBUG)
            return cached[1]

    # Tenta cada servidor DoH
    for doh_url in DOH_SERVERS:
        try:
            if 'dns.google' in doh_url or '8.8.8.8' in doh_url:
                ip = _doh_query_google(doh_url, hostname)
            else:
                ip = _doh_query_cloudflare(doh_url, hostname)

            if ip and _is_ip_address(ip):
                with _doh_cache_lock:
                    _doh_cache[hostname] = (time.time(), ip)
                xbmc.log(f"[VOD-PROXY] DoH resolveu: {hostname} -> {ip} ({doh_url})", xbmc.LOGINFO)
                return ip
        except Exception as e:
            xbmc.log(f"[VOD-PROXY] DoH erro ({doh_url}): {e}", xbmc.LOGDEBUG)
            continue

    # Fallback: DNS local do sistema
    try:
        ip = socket.gethostbyname(hostname)
        if ip and _is_ip_address(ip):
            with _doh_cache_lock:
                _doh_cache[hostname] = (time.time(), ip)
            xbmc.log(f"[VOD-PROXY] DoH fallback DNS local: {hostname} -> {ip}", xbmc.LOGINFO)
            return ip
    except Exception as e:
        xbmc.log(f"[VOD-PROXY] DoH fallback falhou: {e}", xbmc.LOGERROR)

    # Último recurso: retorna o hostname original
    return hostname

def doh_resolve_url(url):
    """
    Resolve o hostname dentro de uma URL usando DoH (somente IPv4).
    Ignora URLs cujo host já seja IP. Mantém userinfo, porta e path.
    """
    if not url:
        return url
    try:
        parsed = urllib.parse.urlparse(url)
        host = parsed.hostname
        if not host or _is_ip_address(host):
            return url

        resolved = doh_resolve(host)
        if not resolved or resolved == host or not _is_ip_address(resolved):
            return url

        userinfo = ''
        if '@' in parsed.netloc:
            userinfo = parsed.netloc.rsplit('@', 1)[0] + '@'
        port = parsed.port
        new_netloc = f"{userinfo}{resolved}" + (f":{port}" if port else "")

        new_url = urllib.parse.urlunparse(parsed._replace(netloc=new_netloc))
        xbmc.log(f"[VOD-PROXY] DoH URL reescrita: {host} -> {resolved}", xbmc.LOGDEBUG)
        return new_url
    except Exception as e:
        xbmc.log(f"[VOD-PROXY] doh_resolve_url erro: {e}", xbmc.LOGDEBUG)
        return url

# ---------------- SESSION MANAGER ----------------

class SessionManager:
    def __init__(self):
        self._session = None
        self._lock = threading.Lock()
        self._last_used = 0
    
    def get_session(self):
        with self._lock:
            if (self._session is None or 
                time.time() - self._last_used > CONFIG['SESSION_TIMEOUT']):
                
                if self._session:
                    try: 
                        self._session.close()
                    except: 
                        pass
                
                self._session = requests.Session()
                self._session.verify = False
                
                adapter = HTTPAdapter(pool_connections=30, pool_maxsize=30, max_retries=0)
                self._session.mount('http://', adapter)
                self._session.mount('https://', adapter)
                
                self._session.headers.update({
                    'Accept': '*/*',
                })
            
            self._last_used = time.time()
            return self._session
    
    def close(self):
        with self._lock:
            if self._session:
                try:
                    self._session.close()
                except:
                    pass
                self._session = None
                self._last_used = 0

SESSION_MANAGER = SessionManager()

# ---------------- STREAM MANAGER ----------------

class StreamManager:
    def __init__(self):
        self.session_manager = SESSION_MANAGER
    
    def is_blocked(self, url):
        if not url:
            return False
        return 'cloudflare-terms-of-service-abuse' in url.lower()
    
    def parse_xc(self, url):
        pattern = r'http[s]?://([^/]+)/([^/]+)/([^/]+)/([^/]+)/(\d+)\.(.+)'
        match = re.match(pattern, url)
        if match:
            return {
                'host': match.group(1),
                'type': match.group(2),
                'username': match.group(3),
                'password': match.group(4),
                'id': match.group(5),
                'ext': match.group(6),
            }
        return None
    
    def generate_headers(self, url, range_header=None):
        """
        Gera headers com Host dinâmico e suporte a Range.
        """
        parsed = urllib.parse.urlparse(url)
        host = parsed.netloc
        
        headers = {
            'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Host': host,
            'Connection': 'keep-alive',  # Keep-alive para reutilizar conexão no seek
        }
        
        # IMPORTANTE: Repassar Range para suportar seek
        if range_header:
            headers['Range'] = range_header
            xbmc.log(f"[VOD-PROXY] Range: {range_header}", xbmc.LOGDEBUG)
        
        return headers
    
    def _candidate_urls(self, url):
        """
        Lista de URLs a tentar para um hop: primeiro IP resolvido via DoH
        (força IPv4 e evita DNS/IPv6 travando), depois a URL original.
        IP só é usado em http (em https o SNI quebraria).
        """
        candidates = []
        try:
            if urllib.parse.urlparse(url).scheme == 'http':
                ip_url = doh_resolve_url(url)
                if ip_url and ip_url != url:
                    candidates.append(ip_url)
        except Exception:
            pass
        candidates.append(url)
        return candidates

    def fetch_with_dynamic_host(self, url, range_header=None, max_redirects=MAX_REDIRECTS):
        """
        Fetch com Host dinâmico, DoH, fallback de conexão e suporte a Range/Seek.
        """
        current_url = url
        redirect_count = 0
        
        while redirect_count < max_redirects:
            # Host sempre do hostname ORIGINAL do hop (mesmo conectando via IP)
            headers = self.generate_headers(current_url, range_header)
            session = self.session_manager.get_session()
            
            resp = None
            last_err = None
            for target in self._candidate_urls(current_url):
                try:
                    resp = session.get(
                        target,
                        headers=headers,
                        stream=True,
                        timeout=(CONNECT_TRY_TIMEOUT, STREAM_TIMEOUT),
                        verify=False,
                        allow_redirects=False
                    )
                    break
                except (requests.exceptions.ConnectTimeout,
                        requests.exceptions.ConnectionError,
                        requests.exceptions.ReadTimeout) as e:
                    last_err = e
                    xbmc.log(f"[VOD-PROXY] Falha conexão ({target[:60]}): {type(e).__name__}", xbmc.LOGWARNING)
                    continue
            
            if resp is None:
                xbmc.log(f"[VOD-PROXY] Erro fetch: {last_err}", xbmc.LOGERROR)
                raise last_err if last_err else Exception("Falha de conexão")
            
            # Verifica redirect
            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get('Location')
                if not location:
                    return resp
                
                next_url = urllib.parse.urljoin(current_url, location)
                
                if self.is_blocked(next_url):
                    xbmc.log(f"[VOD-PROXY] Bloqueio detectado", xbmc.LOGWARNING)
                    resp.close()
                    return None
                
                xbmc.log(f"[VOD-PROXY] Redirect {resp.status_code}: {current_url[:40]}... -> {next_url[:60]}", xbmc.LOGINFO)
                
                resp.close()
                current_url = next_url
                redirect_count += 1
                continue
            
            # Sucesso - verifica se aceita Range
            if resp.status_code in (200, 206):
                accept_ranges = resp.headers.get('Accept-Ranges', 'none')
                content_length = resp.headers.get('Content-Length')
                
                xbmc.log(f"[VOD-PROXY] Status: {resp.status_code} | Accept-Ranges: {accept_ranges} | Length: {content_length}", xbmc.LOGINFO)
                
                if range_header and resp.status_code == 200:
                    xbmc.log(f"[VOD-PROXY] Servidor ignorou Range, retornou 200 completo", xbmc.LOGWARNING)
                
                return resp
            
            xbmc.log(f"[VOD-PROXY] Status inesperado: {resp.status_code} ({current_url[:60]})", xbmc.LOGWARNING)
            return resp
        
        raise Exception(f"Limite de redirects atingido")
    
    def get_direct_link(self, xc_info):
        """
        Tenta obter link direto via API XC.
        """
        try:
            base = f"http://{xc_info['host']}"
            api_url = f"{base}/player_api.php?username={xc_info['username']}&password={xc_info['password']}&action=get_vod_info&vod_id={xc_info['id']}"
            
            xbmc.log(f"[VOD-PROXY] API: {api_url[:80]}", xbmc.LOGINFO)
            
            session = self.session_manager.get_session()
            
            headers = {
                'User-Agent': 'VLC/3.0.20',
                'Accept': 'application/json,*/*',
                'Host': xc_info['host'],
            }
            
            resp = session.get(
                api_url,
                headers=headers,
                timeout=(10, 30),
                verify=False,
                allow_redirects=False
            )
            
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    
                    if 'movie_data' in data:
                        movie = data['movie_data']
                        
                        for key in ['stream_url', 'direct_source', 'video_url', 'url']:
                            if key in movie and movie[key]:
                                url = movie[key]
                                if url.startswith('http') and not self.is_blocked(url):
                                    xbmc.log(f"[VOD-PROXY] API URL ({key}): {url[:60]}", xbmc.LOGINFO)
                                    return url
                        
                        if 'token' in movie:
                            token = movie['token']
                            stream_url = f"{base}/movie/{xc_info['username']}/{xc_info['password']}/{xc_info['id']}.{xc_info['ext']}?token={token}"
                            xbmc.log(f"[VOD-PROXY] URL com token: {stream_url[:60]}", xbmc.LOGINFO)
                            return stream_url
                            
                except Exception as e:
                    xbmc.log(f"[VOD-PROXY] Erro parse API: {e}", xbmc.LOGDEBUG)
            
            resp.close()
            
        except Exception as e:
            xbmc.log(f"[VOD-PROXY] Erro API: {e}", xbmc.LOGDEBUG)
        
        return None
    
    def fetch(self, url, range_header=None):
        """
        Tenta obter stream com suporte a seek.
        """
        xc_info = self.parse_xc(url)
        
        # ESTRATÉGIA 1: API para URL com token
        if xc_info:
            direct_url = self.get_direct_link(xc_info)
            if direct_url:
                xbmc.log(f"[VOD-PROXY] Tentando URL da API", xbmc.LOGINFO)
                try:
                    resp = self.fetch_with_dynamic_host(direct_url, range_header)
                    if resp:
                        return resp
                except Exception as e:
                    xbmc.log(f"[VOD-PROXY] URL da API falhou: {e}", xbmc.LOGWARNING)
        
        # ESTRATÉGIA 2: URL original
        xbmc.log(f"[VOD-PROXY] Tentando URL original", xbmc.LOGINFO)
        return self.fetch_with_dynamic_host(url, range_header)

STREAM_MANAGER = StreamManager()

# ---------------- PROXY HTTP ----------------

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format, *args):
        pass

    def do_HEAD(self):
        self._handle_request(method='HEAD')

    def do_GET(self):
        self._handle_request(method='GET')
    
    def _handle_request(self, method='GET'):
        try:
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            target_url = query.get('url', [None])[0]
            
            if not target_url:
                self.send_error(400, "Missing URL")
                return
            
            target_url = urllib.parse.unquote_plus(target_url)
            
            # IMPORTANTE: Captura o Range do cliente Kodi
            range_header = self.headers.get('Range')
            
            xbmc.log(f"[VOD-PROXY] ========================================", xbmc.LOGINFO)
            xbmc.log(f"[VOD-PROXY] Request: {target_url[:80]}", xbmc.LOGINFO)
            if range_header:
                xbmc.log(f"[VOD-PROXY] Cliente Range: {range_header}", xbmc.LOGINFO)
            
            # Obtém stream
            try:
                resp = STREAM_MANAGER.fetch(target_url, range_header)
            except Exception as e:
                xbmc.log(f"[VOD-PROXY] Upstream falhou: {e}", xbmc.LOGERROR)
                self.send_error(502, "Upstream error")
                return
            
            if not resp:
                xbmc.log(f"[VOD-PROXY] Falha ao obter stream", xbmc.LOGERROR)
                self.send_error(403, "Server blocked access")
                return
            
            # Envia resposta
            self.send_response(resp.status_code)
            
            # Headers que NÃO devem ser repassados
            hop_by_hop = [
                'connection', 'keep-alive', 'proxy-authenticate', 
                'proxy-authorization', 'te', 'trailers', 
                'transfer-encoding', 'upgrade', 'content-encoding',
            ]
            
            # Repassa headers importantes para VOD/Seek
            content_length = None
            for k, v in resp.headers.items():
                kl = k.lower()
                if kl not in hop_by_hop:
                    # Não repassa Content-Length se temos Transfer-Encoding
                    if kl == 'content-length':
                        content_length = v
                    self.send_header(k, v)
            
            # IMPORTANTE: Garante Accept-Ranges para seek
            if 'Accept-Ranges' not in resp.headers:
                self.send_header('Accept-Ranges', 'bytes')
            
            # Se temos Content-Length e é 200, permite seek
            if resp.status_code == 200 and content_length:
                xbmc.log(f"[VOD-PROXY] Content-Length: {content_length}", xbmc.LOGDEBUG)
            
            self.send_header('Connection', 'close')
            self.end_headers()
            
            if method == 'HEAD':
                resp.close()
                return
            
            # Streaming
            bytes_sent = 0
            try:
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.wfile.write(chunk)
                        bytes_sent += len(chunk)
            except (ConnectionResetError, BrokenPipeError, socket.error):
                pass
            except Exception as e:
                xbmc.log(f"[VOD-PROXY] Erro stream: {e}", xbmc.LOGERROR)
            finally:
                resp.close()
                xbmc.log(f"[VOD-PROXY] Enviado: {bytes_sent/1024/1024:.1f}MB", xbmc.LOGINFO)
                xbmc.log(f"[VOD-PROXY] ========================================", xbmc.LOGINFO)
                
        except Exception as e:
            xbmc.log(f"[VOD-PROXY] Erro fatal: {e}", xbmc.LOGERROR)
            try:
                self.send_error(500)
            except:
                pass

class VODProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def start(self):
        if self._is_running:
            return True
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = ThreadedTCPServer((BIND_HOST, port), VODProxyRequestHandler)
                self.server.timeout = 1
                
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                
                self.active_port = port
                self._is_running = True
                xbmc.log(f"[VOD-PROXY] Proxy VOD ativo em {ACCESS_HOST}:{port}", xbmc.LOGINFO)
                return True
                
            except Exception as e:
                if attempt == MAX_PORT_ATTEMPTS - 1:
                    xbmc.log(f"[VOD-PROXY] Falha: {e}", xbmc.LOGERROR)
                continue
        
        return False

    def stop(self):
        self._is_running = False
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except:
                pass
            self.server = None
        
        SESSION_MANAGER.close()
        self.active_port = None

# ---------------- ENTRY POINT ----------------

def resolve_vod_stream(stream_url):
    proxy_manager = VODProxyManager()
    
    if not proxy_manager.start():
        return None, None
    
    if not stream_url:
        return None, proxy_manager
    
    params = {'url': stream_url}
    query_string = urllib.parse.urlencode(params, quote_via=urllib.parse.quote_plus)
    proxy_url = f"http://{ACCESS_HOST}:{proxy_manager.active_port}/?{query_string}"
    
    return proxy_url, proxy_manager

__all__ = ['VODProxyManager', 'resolve_vod_stream', 'SessionManager']