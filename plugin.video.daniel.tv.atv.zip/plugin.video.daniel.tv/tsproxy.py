#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tsproxy.py — NEXUS CORE MPEG-TS SUTURE ENGINE (SINGLE USER MODE)
# Autor: Deivid Silva
#
# ── CORREÇÃO "GRINCH" v3 — MALHA 188/0x47 NA RETOMADA ────────────────────
# Evidência dos logs: "CC ajustados: 0" na 1ª sutura e milhares nas
# seguintes = cascata de fase. A retomada da sutura violava a malha de
# pacotes em 3 pontos:
#
#  1. BURACO: o resíduo parcial (<188 bytes) do SutureSearchState era
#     descartado → o player recebia o RESTO de um pacote sem header 0x47
#     (quebra de sincronia) → demuxer perdia até 184 bytes de vídeo por
#     sutura → artefato até o próximo IDR.
#  2. REPLAY: o "tail" só olhava os últimos 64 pacotes de cada chunk
#     (SUTURE_HASH_WINDOW) — rajadas de null/stuffing maiores que isso
#     (CBR) ficavam fora da conta → retomada cedo demais → pacotes já
#     jogados eram reenviados.
#  3. CC FORÇADO mascarava o replay: o pacote duplicado virava "novo"
#     (CC=último+1) em vez de chegar como duplicata (CC igual) que o
#     demuxer descartaria → payload duplicado dentro do PES → H.264
#     corrompido. E a partir daí a cascata renumerava TUDO.
#
# Correções:
#  - Tail EXATO: varredura de trás para frente por chunk, sem janela.
#  - Resíduo preservado: remaining = accum[skip:] + _buf (malha íntegra).
#  - CC por RE-FASE de delta (só no instante da sutura): dentro da conexão
#    o CC da fonte passa intacto — duplicatas/falhas reais seguem visíveis
#    ao demuxer (que sabe tratá-las). Na sutura, o 1º pacote de cada PID
#    deriva um delta constante e a sequência continua do último CC que o
#    player viu. Sem cascata.
#  - Verificação de contexto no casamento (hasháveis anteriores também
#    precisam bater) — rejeita falso-positivo de conteúdo repetitivo.
#
# Correções anteriores mantidas: pool de sessão única por host, read1 sem
# bloqueio em 64KB, sem lock durante o stream, redirect imediato,
# TCP_NODELAY, server_bind sem getfqdn.
# ─────────────────────────────────────────────────────────────────────────

import http.server
import socketserver
import urllib.parse
import urllib3
import socket
import threading
import time
import random
import queue
import collections
import json
import ipaddress
import xbmc

# ─────────────────────────────────────────────
#  LOG SWITCH (True = ligado / False = desligado)
# ─────────────────────────────────────────────
_LOG_ENABLED = False

def set_log_enabled(enabled: bool):
    """Ativa (True) ou desativa (False) todo o log do tsproxy."""
    global _LOG_ENABLED
    _LOG_ENABLED = bool(enabled)

def _log(msg, level=xbmc.LOGDEBUG):
    if not _LOG_ENABLED:
        return
    try:
        xbmc.log(msg, level)
    except Exception:
        pass

# ─────────────────────────────────────────────
#  CONSTANTES MPEG-TS
# ─────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

def _build_null_burst(count: int = 24) -> bytes:
    burst = bytearray()
    for i in range(count):
        cc = i & 0x0F
        hdr = bytearray([0x47, 0x1F, 0xFF, 0x10 | cc])
        burst.extend(hdr)
        burst.extend(b'\xFF' * 184)
    return bytes(burst)

NULL_PUMP_BURST    = _build_null_burst(24)
NULL_PUMP_INTERVAL = 0.100
NULL_PUMP_MAX_SECS = 2.0

CHUNK_SIZE = TS_PACKET_SIZE * 348  # 65424 bytes (máximo por read1)

MAX_SYNC_ATTEMPTS_PER_CYCLE = 5000
MAX_OUTPUT_BUFFER   = 48
SYNC_CONFIRM_PACKETS = 50

SUTURE_MAX_ACCUM = 5 * 1024 * 1024

MAX_REDIRECT_HOPS = 8

# ─────────────────────────────────────────────
#  CONNECTION POOL (UMA CONEXÃO POR HOST)
# ─────────────────────────────────────────────
class SingleHostConnectionPool:
    """
    Pool de conexão única por host.
    Mantém uma ÚNICA conexão HTTP aberta por host de origem.
    Reutiliza a mesma sessão para evitar múltiplos usuários.
    """
    def __init__(self):
        self._pools = {}  # hostname -> {'session': ..., 'lock': ..., 'last_used': ...}
        self._master_lock = threading.Lock()
        self._cleanup_interval = 60  # limpar conexões inativas
        self._last_cleanup = time.time()

    def _cleanup_inactive(self):
        """Remove conexões inativas por mais de 5 minutos"""
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return

        self._last_cleanup = now
        inactive_threshold = 300  # 5 minutos

        with self._master_lock:
            dead_hosts = []
            for hostname, pool_info in self._pools.items():
                if now - pool_info['last_used'] > inactive_threshold:
                    dead_hosts.append(hostname)

            for hostname in dead_hosts:
                pool_info = self._pools.pop(hostname, None)
                if pool_info:
                    try:
                        pool_info['session'].clear()
                    except Exception:
                        pass
                    _log(f"[Pool] Conexão inativa para {hostname} removida", xbmc.LOGINFO)

    def get_session_for_host(self, hostname: str):
        """
        Obtém sessão ÚNICA para um hostname.
        Cria se não existir; reutiliza se existir.
        """
        self._cleanup_inactive()

        with self._master_lock:
            if hostname not in self._pools:
                # Criar nova sessão única para este host
                session = urllib3.PoolManager(num_pools=4, maxsize=1)
                self._pools[hostname] = {
                    'session': session,
                    'lock': threading.Lock(),
                    'last_used': time.time()
                }
                _log(f"[Pool] Nova sessão criada para {hostname}", xbmc.LOGINFO)

            pool_info = self._pools[hostname]
            pool_info['last_used'] = time.time()
            return pool_info['session'], pool_info['lock']

    def invalidate_host(self, hostname: str):
        """Invalida a sessão para um hostname (ex: após erro 401/403)"""
        with self._master_lock:
            pool_info = self._pools.pop(hostname, None)
            if pool_info:
                try:
                    pool_info['session'].clear()
                except Exception:
                    pass
                _log(f"[Pool] Sessão para {hostname} invalidada", xbmc.LOGWARNING)

    def close_all(self):
        """Fecha todas as conexões"""
        with self._master_lock:
            for hostname, pool_info in self._pools.items():
                try:
                    pool_info['session'].clear()
                except Exception:
                    pass
            self._pools.clear()
            _log(f"[Pool] Todas as conexões fechadas", xbmc.LOGINFO)

_global_pool = SingleHostConnectionPool()

# ─────────────────────────────────────────────
#  DNS-over-HTTPS RESOLVER
# ─────────────────────────────────────────────
_DOH_PROVIDERS = [
    "https://dns.google/resolve",
    "https://dns.cloudflare.com/dns-query",
    "https://1.1.1.1/dns-query",
    "https://1.0.0.1/dns-query",
]
_DOH_HTTP = urllib3.PoolManager(num_pools=4)
_DOH_CACHE = collections.OrderedDict()
_DOH_CACHE_MAX = 20
_DOH_CACHE_LOCK = threading.Lock()
_DOH_TIMEOUT = 3.0
_DOH_SYS_FALLBACK_TTL = 30

def _doh_is_ip_address(value: str) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

def _doh_resolve_system_dns(hostname: str, timeout: float = 1.5):
    result = [None]
    def _do_resolve():
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
            for _family, _, _, _, sockaddr in infos:
                ip = sockaddr[0]
                if ip:
                    result[0] = ip
                    break
        except Exception:
            pass
    t = threading.Thread(target=_do_resolve, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]

def _doh_resolve_provider(hostname: str, provider: str, timeout: float = _DOH_TIMEOUT):
    try:
        query = urllib.parse.urlencode({"name": hostname, "type": "A"})
        resp = _DOH_HTTP.request(
            'GET',
            f"{provider}?{query}",
            headers={"Accept": "application/dns-json", "User-Agent": "Mozilla/5.0"},
            timeout=urllib3.Timeout(connect=timeout, read=timeout),
            retries=False,
        )
        if resp.status != 200:
            return None
        data = json.loads(resp.data.decode("utf-8", "ignore"))
        if data.get("Status", -1) != 0:
            return None
        for answer in data.get("Answer", []):
            if answer.get("type") == 1:
                ip = str(answer.get("data", "")).strip()
                ttl = int(answer.get("TTL", 60))
                try:
                    ipaddress.IPv4Address(ip)
                    return ip, ttl
                except ValueError:
                    continue
    except Exception:
        pass
    return None

def resolve_host_doh(hostname: str):
    if not hostname or _doh_is_ip_address(hostname):
        return hostname
    now = time.time()
    with _DOH_CACHE_LOCK:
        entry = _DOH_CACHE.get(hostname)
        if entry:
            ip, expiry = entry
            if now < expiry:
                return ip
            del _DOH_CACHE[hostname]

    for provider in _DOH_PROVIDERS:
        result = _doh_resolve_provider(hostname, provider)
        if result:
            ip, ttl = result
            with _DOH_CACHE_LOCK:
                if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                    _DOH_CACHE.popitem(last=False)
                _DOH_CACHE[hostname] = (ip, now + 86400)
            return ip

    sys_ip = _doh_resolve_system_dns(hostname, timeout=1.5)
    if sys_ip:
        with _DOH_CACHE_LOCK:
            if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                _DOH_CACHE.popitem(last=False)
            _DOH_CACHE[hostname] = (sys_ip, now + _DOH_SYS_FALLBACK_TTL)
        return sys_ip
    return None

def rewrite_url_with_doh(url: str):
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host or _doh_is_ip_address(host):
        return url, ""
    # HTTPS: trocar o host por IP remove o SNI e quebra o handshake
    # (SSLV3_ALERT_HANDSHAKE_FAILURE). Só reescreve HTTP puro.
    if parsed.scheme.lower() != "http":
        return url, ""
    ip = resolve_host_doh(host)
    if not ip:
        return url, ""
    port = parsed.port
    new_netloc = f"{ip}:{port}" if port else ip
    return urllib.parse.urlunparse(parsed._replace(netloc=new_netloc)), host

def invalidate_doh_cache(hostname: str):
    if hostname:
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.pop(hostname, None)

# ─────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)

# ─────────────────────────────────────────────
#  TsBuffer — ALINHAMENTO + RE-FASE DE CC POR PID
# ─────────────────────────────────────────────
class TsBuffer:
    """
    Alinhamento de pacotes TS + RE-FASE do continuity counter (CC).

    DENTRO de uma conexão o CC da fonte passa INTACTO: duplicatas e falhas
    reais continuam visíveis ao demuxer, que sabe tratá-las (duplicata =
    CC igual → descarta; buraco = CC salta → descontinuidade). O rewrite
    forçado antigo mascarava isso e cascateava após qualquer anomalia — os
    "CC ajustados: 9616" dos logs eram exatamente a cascata.

    SÓ no instante da sutura (conexão nova retomando exato onde a antiga
    parou) cada PID recebe um DELTA DE FASE: o primeiro pacote que chega
    deriva delta = (último_CC_do_player + 1 - CC_da_fonte) & 0xF, e todos
    os pacotes seguintes do PID saem com (CC_fonte + delta). Deslocamento
    constante por PID: o comportamento da fonte é preservado, apenas
    re-fasado para a sequência que o player já viu.
    """

    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._last_cc = {}          # pid -> último CC ENTREGUE ao player
        self._cc_delta = {}         # pid -> deslocamento de fase (0..15)
        self._phase_pending = set() # pids aguardando derivação do delta
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._rewrites_total = 0
        self._refased_pids_total = 0

    def clear_partial_buffer(self):
        # Limpa bytes parciais/alinhamento do fluxo antigo, MANTENDO
        # _last_cc / _cc_delta / _phase_pending — é o _last_cc que costura
        # a fase de CC entre as conexões.
        self._buf.clear()
        self._aligned = False

    def begin_phase_shift(self, align: bool = True):
        """
        Chamar no instante da sutura (align=True): o próximo pacote de cada
        PID conhecido deriva o delta para continuar a sequência do player.
        Com align=False (salto para o live edge) os CC novos são adotados
        como vierem — a descontinuidade fica VISÍVEL ao demuxer de propósito
        (ele reseta o PES e ressincroniza no próximo PUSI).
        """
        self._cc_delta = {}
        if align:
            self._phase_pending = set(self._last_cc.keys())
        else:
            self._phase_pending = set()

    def cc_stats(self):
        """(pids re-faseados, pacotes reescritos) — contadores acumulados."""
        return self._refased_pids_total, self._rewrites_total

    def _confirm_sync(self, data, idx: int, length: int) -> bool:
        checkpoints_needed = SYNC_CONFIRM_PACKETS
        confirmed = 0
        for k in range(checkpoints_needed):
            pos = idx + k * TS_PACKET_SIZE
            if pos >= length:
                break
            if data[pos] != TS_SYNC_BYTE:
                return False
            confirmed += 1
        min_needed = min(checkpoints_needed, max(2, (length - idx) // TS_PACKET_SIZE))
        if confirmed < min_needed:
            return False
        return True

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                self._last_sync_idx = length
                return -1
            self._sync_attempts += 1
            if self._confirm_sync(data, idx, length):
                self._last_sync_idx = idx + TS_PACKET_SIZE
                return idx
            idx += 1
        self._last_sync_idx = idx
        return -1

    def _process_packets(self, data: bytearray):
        """
        Processa o bloco já alinhado (múltiplo de 188):
          - valida o sync byte em CADA pacote (desalinha se quebrar);
          - re-fasa o CC por PID conforme _cc_delta/_phase_pending.

        `data` é cópia privada (slice de _buf), então o patch in-place é
        seguro. Retorna (pacotes_prontos, sobra_a_reprocessar).
        """
        n = len(data) // TS_PACKET_SIZE
        if n == 0:
            return bytearray(), bytearray()

        end = n * TS_PACKET_SIZE
        last_cc = self._last_cc
        deltas = self._cc_delta
        pending = self._phase_pending
        rewrites = 0

        for off in range(0, end, TS_PACKET_SIZE):
            if data[off] != TS_SYNC_BYTE:
                self._error_count += 1
                self._aligned = False
                return data[:off], data[off:]

            b3 = data[off + 3]
            afc = (b3 & 0x30) >> 4
            if afc != 1 and afc != 3:
                continue    # sem payload: CC não avança (ISO 13818-1)

            pid = ((data[off + 1] & 0x1F) << 8) | data[off + 2]
            if pid == 0x1FFF:
                continue    # null: CC irrelevante para o demuxer

            cc = b3 & 0x0F

            if pid in pending:
                # Primeiro pacote do PID após a sutura: deriva o delta de fase
                expected = (last_cc[pid] + 1) & 0x0F
                delta = (expected - cc) & 0x0F
                deltas[pid] = delta
                pending.discard(pid)
                if delta:
                    data[off + 3] = (b3 & 0xF0) | expected
                    rewrites += 1
                    self._refased_pids_total += 1
                last_cc[pid] = expected
            elif pid in deltas:
                delta = deltas[pid]
                if delta:
                    shifted = (cc + delta) & 0x0F
                    data[off + 3] = (b3 & 0xF0) | shifted
                    rewrites += 1
                    last_cc[pid] = shifted
                else:
                    last_cc[pid] = cc
            else:
                # PID novo (nunca jogado): adota o CC da fonte como veio
                last_cc[pid] = cc

        if rewrites:
            self._rewrites_total += rewrites
        return data, bytearray()

    def feed(self, raw: bytes) -> bytes:
        if not raw:
            return b''
        self._buf.extend(raw)
        result = bytearray()
        while True:
            if not self._aligned:
                self._sync_attempts = 0
                self._last_sync_idx = 0
                idx = self._find_sync(self._buf)
                if idx == -1:
                    if len(self._buf) > TS_PACKET_SIZE * 100:
                        keep_tail = TS_PACKET_SIZE * 2
                        del self._buf[:-keep_tail]
                    return bytes(result)
                if idx > 0:
                    del self._buf[:idx]
                self._aligned = True
            buf_len = len(self._buf)
            usable = buf_len - (buf_len % TS_PACKET_SIZE)
            if usable == 0:
                return bytes(result)
            payload = self._buf[:usable]
            del self._buf[:usable]
            processed, leftover = self._process_packets(payload)
            if processed:
                result.extend(processed)
            if leftover:
                self._buf[0:0] = leftover
                continue
            return bytes(result)

# ─────────────────────────────────────────────
#  SutureManager
# ─────────────────────────────────────────────
class SutureManager:
    _NEED = 8   # hasháveis mantidos: 3 da tríade + contexto p/ verificação

    def __init__(self):
        self._recent_hashes = collections.deque(maxlen=256)
        # Pacotes jogados ao player APÓS o último pacote hashável ("tail").
        # A contagem é EXATA: varredura de trás para frente, SEM janela.
        # (A versão com SUTURE_HASH_WINDOW=64 perdia rajadas de null/stuffing
        # maiores que 64 pacotes → retomada cedo demais → pacotes repetidos.)
        self._tail_packets = 0

    @staticmethod
    def _get_packet_hash(pkt) -> int:
        if len(pkt) < 188:
            return None
        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if pid == 0x1FFF:
            return None
        afc = (pkt[3] & 0x30) >> 4
        if afc in (1, 3):
            payload_start = 4
            if afc == 3:
                if len(pkt) < 5:
                    return None
                adapt_len = pkt[4]
                payload_start = 5 + adapt_len
            if payload_start + 16 <= 188:
                return hash(bytes(pkt[payload_start:payload_start + 16]))
        return None

    def add_played(self, data: bytes):
        """
        Varre o chunk DE TRÁS PARA FRENTE:
          - conta EXATAMENTE os pacotes após o último hashável (o "tail"),
            sem limite de janela — rajada de nulls atravessando chunks entra
            na conta;
          - coleta os últimos _NEED hasháveis (só o que importa para o
            casamento e para a verificação de contexto).
        Para ao achar _NEED hasháveis: o resto do chunk é irrelevante.
        """
        if not data:
            return
        mv = memoryview(data)
        n = len(data) // 188
        tail_run = 0
        found_rev = []
        i = n - 1
        while i >= 0:
            h = self._get_packet_hash(mv[i * 188:(i + 1) * 188])
            if h is not None:
                found_rev.append(h)
                if len(found_rev) >= self._NEED:
                    break
            elif not found_rev:
                # ainda não achou o último hashável: conta no tail
                tail_run += 1
            i -= 1

        # found_rev está em ordem reversa (do mais recente para trás)
        for h in reversed(found_rev):
            self._recent_hashes.append(h)

        if found_rev:
            # o último hashável do stream está NESTE chunk: tail exato dele
            self._tail_packets = tail_run
        else:
            # chunk inteiro sem hashável (ex.: só nulls): acumula
            self._tail_packets += tail_run

    def get_target(self):
        """
        Retorna (últimos ≤6 hasháveis em ordem, tail exato) ou None.
        Os últimos 3 formam a tríade de casamento; os anteriores são o
        contexto usado para rejeitar falso-positivo.
        """
        if len(self._recent_hashes) < 3:
            return None
        ctx = list(self._recent_hashes)[-6:]
        return (ctx, self._tail_packets)

    def clear(self):
        self._recent_hashes.clear()
        self._tail_packets = 0

# ─────────────────────────────────────────────
#  SutureSearchState
# ─────────────────────────────────────────────
class SutureSearchState:
    def __init__(self):
        self.accum = bytearray()
        self.hashes = []
        self.last_scanned = 0
        self._buf = bytearray()
        self._aligned = False
        self._packet_count = 0

    def feed(self, raw: bytes):
        self._buf.extend(raw)

        if not self._aligned:
            idx = self._buf.find(TS_SYNC_BYTE)
            if idx == -1:
                self._buf.clear()
                return
            # +1: precisa existir o índice idx + 2*188 (evita IndexError com chunks pequenos)
            if len(self._buf) < idx + TS_PACKET_SIZE * 2 + 1:
                return

            if self._buf[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE and \
               self._buf[idx + TS_PACKET_SIZE * 2] == TS_SYNC_BYTE:
                del self._buf[:idx]
                self._aligned = True
            else:
                del self._buf[:idx + 1]
                return

        usable = len(self._buf) - (len(self._buf) % TS_PACKET_SIZE)
        if usable == 0:
            return

        aligned_raw = bytes(self._buf[:usable])
        del self._buf[:usable]

        self.accum.extend(aligned_raw)
        n = usable // TS_PACKET_SIZE
        mv = memoryview(aligned_raw)

        for i in range(n):
            offset = i * TS_PACKET_SIZE
            pkt = mv[offset:offset + TS_PACKET_SIZE]
            h = SutureManager._get_packet_hash(pkt)
            if h is not None:
                self.hashes.append((self._packet_count, h))
            self._packet_count += 1

    def find_suture(self, target) -> int:
        """
        Retorna o índice do pacote onde o fluxo deve RETOMAR, ou -1.

        O índice inclui o tail EXATO: pacotes não-hasháveis que já foram
        jogados ao player depois do 3º pacote da tríade. A retomada é
        exatamente no próximo pacote NOVO — sem duplicar nada.

        Verificação de contexto: os hasháveis ANTERIORES à tríade também
        precisam bater (quando presentes dos dois lados) — rejeita
        falso-positivo de conteúdo repetitivo/periódico.
        """
        if not target:
            self.last_scanned = len(self.hashes)
            return -1

        ctx, tail = target
        m = len(ctx)
        if m < 3:
            self.last_scanned = len(self.hashes)
            return -1

        t0, t1, t2 = ctx[-3], ctx[-2], ctx[-1]
        pre = ctx[:-3]   # até 3 hasháveis anteriores (contexto)

        start_idx = max(0, self.last_scanned - 2)

        for i in range(start_idx, len(self.hashes) - 2):
            if self.hashes[i][1] == t0 and \
               self.hashes[i+1][1] == t1 and \
               self.hashes[i+2][1] == t2:

                # verificação de contexto anterior
                verified = True
                for k in range(1, len(pre) + 1):
                    j = i - k
                    if j < 0:
                        break   # contexto anterior ainda não chegou — não dá para verificar
                    if self.hashes[j][1] != pre[-k]:
                        verified = False
                        break
                if not verified:
                    continue

                pos = self.hashes[i+2][0] + 1 + tail
                if pos >= self._packet_count:
                    # o tail ainda não chegou completo — guarda o ponto da
                    # varredura e tenta de novo no próximo chunk
                    self.last_scanned = i
                    return -1
                self.last_scanned = i + 3
                return pos

        self.last_scanned = len(self.hashes)
        return -1

    def clear(self):
        self.accum = bytearray()
        self.hashes = []
        self.last_scanned = 0
        self._buf = bytearray()
        self._aligned = False
        self._packet_count = 0

# ─────────────────────────────────────────────
#  OutputBuffer
# ─────────────────────────────────────────────
class OutputBuffer:
    def __init__(self, max_packets: int = MAX_OUTPUT_BUFFER):
        self._queue = queue.Queue(maxsize=max_packets)
        self._lock = threading.Lock()
        self._align_residual = bytearray()

    def put(self, data: bytes) -> bool:
        if not data:
            return True
        with self._lock:
            self._align_residual.extend(data)
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                return True
            chunk = bytes(self._align_residual[:usable])
            del self._align_residual[:usable]
            try:
                self._queue.put_nowait(chunk)
                return True
            except queue.Full:
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._queue.put_nowait(chunk)
                except queue.Full:
                    pass
                return True

    def clear(self):
        with self._lock:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    break
            self._align_residual.clear()

    def flush_to_writer(self, writer_func) -> bool:
        while True:
            try:
                data = self._queue.get_nowait()
                if data:
                    remainder = len(data) % TS_PACKET_SIZE
                    if remainder:
                        data = data[:-remainder]
                    if data and not writer_func(data):
                        return False
            except queue.Empty:
                return True

    def drain_residual(self, writer_func) -> bool:
        with self._lock:
            if not self._align_residual:
                return True
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                self._align_residual.clear()
                return True
            chunk = bytes(self._align_residual[:usable])
            self._align_residual.clear()
        if chunk:
            return writer_func(chunk)
        return True

# ─────────────────────────────────────────────
#  REDIRECT HANDLER
# ─────────────────────────────────────────────
class _HTTPStatusError(Exception):
    """Status HTTP >= 400 (urllib3 não levanta exceção por status)."""
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def _make_reader(response):
    """
    Retorna função de leitura que devolve o que já chegou (não bloqueia
    até completar N bytes). Sem redirect automático: o urllib3 é usado
    com redirect=False.
    """
    r1 = getattr(response, 'read1', None)
    if r1:
        return r1
    r1 = getattr(getattr(response, '_fp', None), 'read1', None)
    if r1:
        return r1
    return lambda n: response.read(n, decode_content=False)

# ─────────────────────────────────────────────
#  SERVIDOR HTTP PROXY
# ─────────────────────────────────────────────
class TSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        _log(f"[NexusCore-TSProxy] {format % args}", xbmc.LOGDEBUG)

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        remainder = len(data) % TS_PACKET_SIZE
        if remainder:
            data = data[:-remainder]
        if not data:
            return True
        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError, ConnectionAbortedError):
            return False

    def _null_pump(self, duration: float) -> bool:
        actual_duration = min(duration, NULL_PUMP_MAX_SECS)
        cycles = max(1, int(actual_duration / NULL_PUMP_INTERVAL))
        for _ in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            time.sleep(NULL_PUMP_INTERVAL)
        return True

    def _calculate_backoff(self, reconnect_num: int) -> float:
        if reconnect_num <= 2:
            return 0.3 + reconnect_num * 0.25
        elif reconnect_num <= 6:
            return 0.8 + (reconnect_num - 2) * 0.4
        return min(4.0, 2.4 + (reconnect_num - 6) * 0.2)

    def _resolve_url(self, url: str, ua: str, hostname: str, session_lock: threading.Lock) -> str:
        """
        Resolve URL com tratamento de redirects.
        Usa a sessão única do pool.
        """
        curr = url
        for _ in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                fetch_url, doh_host = rewrite_url_with_doh(curr)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                }
                if not doh_host:
                    fetch_url = curr
                req_kwargs = dict(headers=headers, preload_content=False, redirect=False, retries=False)

                with session_lock:
                    session = _global_pool.get_session_for_host(hostname)[0]
                    try:
                        with session.request('GET', fetch_url, timeout=urllib3.Timeout(connect=8, read=8), **req_kwargs) as resp:
                            if resp.status in (301, 302, 303, 307, 308):
                                loc = resp.headers.get('Location')
                                if loc:
                                    curr = urllib.parse.urljoin(curr, loc)
                                    continue
                            return curr
                    except Exception:
                        if doh_host:
                            invalidate_doh_cache(doh_host)
                        raise
            except Exception:
                break
        return curr

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(400)
            self.end_headers()
            return

        # Socket do player: sem Nagle + buffer de envio maior (menos stalls no write)
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1024 * 1024)
        except Exception:
            pass

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        # Extrair hostname da URL original
        parsed_original = urllib.parse.urlparse(original_url)
        hostname = parsed_original.hostname or parsed_original.netloc

        # Obter sessão única para este hostname
        session, session_lock = _global_pool.get_session_for_host(hostname)

        resolved_url = original_url
        ua = _pick_ua()
        reconnect_num = 0
        redirect_hops = 0
        ts_buf = TsBuffer()
        output_buf = OutputBuffer()
        last_useful_payload = time.time()

        suture_mgr = SutureManager()
        has_played_data = False
        is_suture_searching = False
        search_state = None
        last_refased = 0
        last_rewrites = 0

        _log(f"[NexusCore-TSProxy] Iniciando stream de {hostname}", xbmc.LOGINFO)

        while True:
            output_buf.clear()
            last_useful_payload = time.time()

            try:
                parsed = urllib.parse.urlparse(resolved_url)
                fetch_url, doh_host = rewrite_url_with_doh(resolved_url)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Referer': original_url,
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive',
                }
                if not doh_host:
                    fetch_url = resolved_url

                # SEM session_lock durante o stream: o lock segurava a sessão
                # inteira e travava qualquer 2ª requisição do Kodi (probe/reabertura)
                with session.request('GET', fetch_url, headers=headers, timeout=urllib3.Timeout(connect=12, read=12), preload_content=False, redirect=False, retries=False) as response:
                    # Redirect: segue imediatamente, sem backoff nem null pump
                    status = response.status
                    if status in (301, 302, 303, 307, 308):
                        loc = response.headers.get('Location')
                        if loc and redirect_hops < MAX_REDIRECT_HOPS:
                            resolved_url = urllib.parse.urljoin(resolved_url, loc)
                            redirect_hops += 1
                            _log(f"[NexusCore-TSProxy] ↪ Redirect {status} -> {resolved_url[:80]}", xbmc.LOGINFO)
                            continue

                    if status >= 400:
                        raise _HTTPStatusError(status)

                    if reconnect_num == 0:
                        _log(f"[NexusCore-TSProxy] ✓ Conectado (sessão única) -> {ua[:40]}...", xbmc.LOGINFO)
                    else:
                        _log(f"[NexusCore-TSProxy] ✓ Reconectado #{reconnect_num} (sessão reutilizada)", xbmc.LOGINFO)
                        reconnect_num = max(0, reconnect_num - 2)

                    if has_played_data and not is_suture_searching:
                        is_suture_searching = True
                        search_state = SutureSearchState()
                        _log("[NexusCore-TSProxy] ⊙ Buscando sutura...", xbmc.LOGINFO)

                    # read1: devolve o que já chegou (read(N) bloqueava até
                    # completar 64KB -> rajadas + starvation = buffering)
                    reader = _make_reader(response)

                    while True:
                        try:
                            raw = reader(CHUNK_SIZE)
                        except Exception:
                            break

                        if not raw:
                            break

                        redirect_hops = 0

                        if is_suture_searching:
                            search_state.feed(raw)
                            target = suture_mgr.get_target()
                            suture_idx = search_state.find_suture(target)

                            if suture_idx != -1:
                                skip = suture_idx * TS_PACKET_SIZE
                                # MALHA 188/0x47 ÍNTEGRA NA RETOMADA:
                                # accum[skip:] + resíduo parcial (_buf).
                                # O resíduo era descartado antes → o player
                                # recebia o resto de um pacote sem header 0x47
                                # → buraco de até 184 bytes de vídeo por sutura.
                                remaining = bytes(search_state.accum[skip:]) + bytes(search_state._buf)
                                search_state = None
                                is_suture_searching = False

                                # NÃO limpamos o mapa de CC do ts_buf: ele guarda
                                # o último CC que o player viu por PID. O delta de
                                # fase derivado aqui faz a nova conexão continuar
                                # exatamente essa sequência — sem cascata.
                                ts_buf.clear_partial_buffer()
                                ts_buf.begin_phase_shift(True)

                                payload = ts_buf.feed(remaining)

                                pt, rt = ts_buf.cc_stats()
                                _log(f"[NexusCore-TSProxy] ✓ Sutura encontrada! Pulando {skip} bytes (CC: {pt - last_refased} pids re-faseados, {rt - last_rewrites} pacotes reescritos).", xbmc.LOGINFO)
                                last_refased, last_rewrites = pt, rt

                                if payload:
                                    output_buf.put(payload)
                                    if not output_buf.flush_to_writer(self._safe_write):
                                        return
                                    suture_mgr.add_played(payload)
                            else:
                                if len(search_state.accum) > SUTURE_MAX_ACCUM:
                                    _log("[NexusCore-TSProxy] ⚠ Sutura nao encontrada em 5MB. Saltando para o live edge.", xbmc.LOGWARNING)
                                    # Mantém o resíduo (malha de pacotes) e descarta
                                    # o backlog: despejar 5MB entregaria PTS antigo.
                                    residue = bytes(search_state._buf)
                                    search_state = None
                                    is_suture_searching = False
                                    ts_buf.clear_partial_buffer()
                                    # align=False: adota os CC novos como vierem —
                                    # a descontinuidade real fica visível ao demuxer
                                    # (ele reseta o PES e ressincroniza no PUSI).
                                    ts_buf.begin_phase_shift(False)
                                    if residue:
                                        ts_buf.feed(residue)
                        else:
                            payload = ts_buf.feed(raw)
                            if payload:
                                last_useful_payload = time.time()
                                output_buf.put(payload)
                                if not output_buf.flush_to_writer(self._safe_write):
                                    return
                                suture_mgr.add_played(payload)
                                has_played_data = True
                            else:
                                last_useful_payload = time.time()

            except _HTTPStatusError as e:
                e_code = e.status
                if e_code in (401, 403):
                    _global_pool.invalidate_host(hostname)
                    session, session_lock = _global_pool.get_session_for_host(hostname)
                    _log(f"[NexusCore-TSProxy] ✗ Auth error {e_code} - invalidando sessão", xbmc.LOGWARNING)
                elif e_code == 429:
                    _log(f"[NexusCore-TSProxy] ✗ Rate limit {e_code} #{reconnect_num} - aguardando...", xbmc.LOGWARNING)
                else:
                    _log(f"[NexusCore-TSProxy] ✗ HTTP {e_code} #{reconnect_num}", xbmc.LOGWARNING)
            except Exception as e:
                err_name = type(e).__name__
                err_msg = str(e)[:80]
                _log(f"[NexusCore-TSProxy] ✗ {err_name} #{reconnect_num}: {err_msg}", xbmc.LOGWARNING)
                _doh_host_failed = locals().get('doh_host')
                if _doh_host_failed:
                    invalidate_doh_cache(_doh_host_failed)

            if is_suture_searching:
                _log("[NexusCore-TSProxy] ⚠ Conexao caiu durante busca. Reiniciando busca.", xbmc.LOGWARNING)
                is_suture_searching = False
                search_state = None

            if not output_buf.flush_to_writer(self._safe_write):
                return
            if not output_buf.drain_residual(self._safe_write):
                return

            reconnect_num += 1
            ua = _pick_ua()
            backoff = self._calculate_backoff(reconnect_num)

            if not self._null_pump(backoff):
                return

            try:
                new_url = self._resolve_url(original_url, ua, hostname, session_lock)
                if new_url != resolved_url:
                    resolved_url = new_url
                    _log(f"[NexusCore-TSProxy] ↻ Token atualizado #{reconnect_num}", xbmc.LOGINFO)
            except Exception:
                pass

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def server_bind(self):
        # HTTPServer.server_bind chama socket.getfqdn(), que pode travar
        # vários segundos em Android/Termux. Pula isso.
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = host
        self.server_port = port

_server_instance = None
_server_thread = None
_lock = threading.Lock()

def _ensure_server_running():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance is None:
            port = 0
            _server_instance = ThreadingHTTPServer(('0.0.0.0', port), TSProxyHandler)
            _server_thread = threading.Thread(target=_server_instance.serve_forever, daemon=True)
            _server_thread.start()
            actual_port = _server_instance.server_address[1]
            _log(f"[NexusCore-TSProxy] ✓ Servidor iniciado na porta {actual_port}", xbmc.LOGINFO)
            return actual_port
        return _server_instance.server_address[1]

def get_proxy_url(stream_url: str, port: int = None) -> str:
    """
    Gera a URL do proxy para um stream IPTV.

    Uso:
        proxy_url = get_proxy_url('http://seu-servidor.com/stream.m3u8')
        # Retorna: http://127.0.0.1:PORTA?url=...
    """
    if port is None:
        port = _ensure_server_running()
    encoded_url = urllib.parse.quote(stream_url, safe='')
    return f"http://127.0.0.1:{port}/?url={encoded_url}"

def shutdown_proxy():
    """Encerra o proxy e fecha todas as conexões"""
    global _server_instance, _server_thread
    with _lock:
        if _server_instance:
            _server_instance.shutdown()
            _server_instance = None
            _server_thread = None
    _global_pool.close_all()
    _log("[NexusCore-TSProxy] ✓ Proxy encerrado", xbmc.LOGINFO)