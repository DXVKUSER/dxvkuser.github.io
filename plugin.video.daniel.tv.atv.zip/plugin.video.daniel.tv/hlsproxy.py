#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# hlsproxy.py â€” NEXUS CORE HLS Proxy Engine
# v1.5.7-SEQ-CACHE â€” requests (sessÃ£o Ãºnica) + DoH Cloudflare
#
# CORREÃ‡Ã•ES v1.5.7 (sobre v1.5.6) â€” CACHE TRUNCADO + ROBUSTEZ:
# - NÃƒO cachear segmento se o buffer de stream (4 MB) nÃ£o cobriu o corpo
#   inteiro. Antes, upstream chunked (sem Content-Length) gravava sÃ³ os
#   primeiros 4 MB sob a chave seq â†’ HIT com TS incompleto â†’ buffering /
#   "Error creating demuxer".
# - SÃ³ cacheia quando len(cache_buf) == total E transferÃªncia completou.
# - _b64d protegido: base64 invÃ¡lido nÃ£o derruba o handler.
# - _is_master_playlist aceita str e bytes.
# - _DOH_INFLIGHT limpa o lock do host apÃ³s a consulta (evita crescimento
#   ilimitado de locks por hostname).
# - Primeiro chunk invÃ¡lido: nÃ£o tenta cachear lixo.
#
# CORREÃ‡Ã•ES v1.5.6 (sobre v1.5.5) â€” RESOLVE BUFFERING DURANTE A REPRODUÃ‡ÃƒO:
# - Cache por SEQUENCE NUMBER (nÃ£o por URL). O CDN gira o token a cada poll
#   da playlist, entÃ£o a URL absoluta do segmento muda â€” antes isso invalidava
#   o cache e forÃ§ava re-download. Agora /hls/seg/<token>/<seq>/<b64>: o
#   handler usa "seq:<N>" como chave de cache. Mesmo segmento entre polls =
#   cache HIT.
# - _stream_segment entrega DIRETO do cache quando disponÃ­vel (sem tocar no
#   CDN). Resposta instantÃ¢nea.
# - PREFETCH PARALELO: 6 Ãºltimos segmentos do live edge, 3 workers
#   concorrentes. Cache fica quente antes do player pedir.
# - RENOVAÃ‡ÃƒO PROATIVA em background por sessÃ£o: dispara _fresh_resolve a
#   cada TTL*0.5s, sem esperar o cliente pedir a playlist. Evita o "token da
#   base expirou" no meio do consumo.
# - Cache 24 entradas / 90s TTL (era 6/18s).
# - Chunk de stream 32K, flush agrupado.
# - Log do tamanho REAL do segmento (antes ia cache_buf[:256] -> sempre "256B").
# - Connection reset by peer (probe do FFmpeg) rebaixado a DEBUG.
#
# CORREÃ‡Ã•ES v1.5.5 (sobre v1.5.4) â€” RESOLVE "Error creating demuxer":
# - Handler de segmento SEMPRE tenta streaming primeiro (ignora Range).
# - Prefetch do live edge. iter_content menor.
#
# CORREÃ‡Ã•ES v1.5.4 (sobre v1.5.3) â€” RESOLVE 403/521 em CDNs com redirect:
# - _stream_segment faz redirect MANUAL (allow_redirects=False + loop).
#   Host/Origin/Referer regenerados a cada hop.
#
# CORREÃ‡Ã•ES v1.5.3 (sobre v1.5.2) â€” streaming chunked, headers antes do
# 1Âº chunk. v1.5.2 (CDN lenta) â€” streaming direto, timeouts maiores.
# v1.5.1 (Variant) â€” _accept_playlist + _playlist_view. v1.5.0 (troca de
# host) â€” afinidade + rebase. v1.4.0 â€” DoH, sessÃ£o Ãºnica. v1.3.0 â€”
# recuperaÃ§Ã£o never-fail.
#
# DependÃªncia: script.module.requests (Kodi) / pip install requests (Termux).

import sys
import os
import re
import ssl
import socket
import base64
import random
import threading
import time
import ipaddress
import http.client
import http.server
import socketserver
from urllib.parse import urlparse, urlunparse, urljoin

import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util import connection as _u3conn

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
if _ADDON_DIR not in sys.path:
    sys.path.insert(0, _ADDON_DIR)

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# DoH CLOUDFLARE + SESSÃƒO HTTP ÃšNICA
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
DOH_ENDPOINTS = ('https://1.1.1.1/dns-query', 'https://1.0.0.1/dns-query')
DOH_TIMEOUT = (2.0, 3.0)
DOH_MIN_TTL = 10
DOH_MAX_TTL = 60
DOH_NEG_TTL = 5
DOH_STALE_MAX = 3600
DOH_MAX_IPS = 3
DOH_PER_IP_TIMEOUT = 2.0
DOH_SYSTEM_FALLBACK = True

HTTP_POOL_HOSTS = 32
HTTP_POOL_SIZE = 16
HTTP_POOL_RESET_MIN = 2.0

_TLS = threading.local()
_DOH_CACHE = {}
_DOH_LOCK = threading.Lock()
_DOH_INFLIGHT = {}

_HTTP = None
_HTTP_LOCK = threading.Lock()
_POOL_RESET_TS = 0.0

_ORIG_CREATE_CONNECTION = _u3conn.create_connection

def _is_ip(host):
    if not host:
        return False
    try:
        ipaddress.ip_address(host.strip('[]').split('%', 1)[0])
        return True
    except ValueError:
        return False

def _get_http():
    global _HTTP
    if _HTTP is None:
        with _HTTP_LOCK:
            if _HTTP is None:
                s = requests.Session()
                s.trust_env = False
                s.headers.clear()
                adapter = HTTPAdapter(
                    pool_connections=HTTP_POOL_HOSTS,
                    pool_maxsize=HTTP_POOL_SIZE,
                    max_retries=0,
                    pool_block=False
                )
                s.mount('http://', adapter)
                s.mount('https://', adapter)
                _HTTP = s
    return _HTTP

def _reset_http_pool():
    global _POOL_RESET_TS
    now = time.monotonic()
    if now - _POOL_RESET_TS < HTTP_POOL_RESET_MIN:
        return
    _POOL_RESET_TS = now
    s = _HTTP
    if s is None:
        return
    for adapter in list(s.adapters.values()):
        try:
            adapter.poolmanager.clear()
        except Exception:
            pass

def _doh_query(host, rtype):
    sess = _get_http()
    want = 1 if rtype == 'A' else 28
    for ep in DOH_ENDPOINTS:
        try:
            r = sess.get(
                ep, params={'name': host, 'type': rtype},
                headers={'accept': 'application/dns-json'},
                timeout=DOH_TIMEOUT
            )
            if r.status_code != 200:
                continue
            data = r.json()
        except Exception:
            continue
        status = data.get('Status')
        if status == 3:
            return [], DOH_NEG_TTL
        if status != 0:
            continue
        ips, ttl = [], None
        for ans in data.get('Answer') or []:
            addr = str(ans.get('data', ''))
            if ans.get('type') == want and _is_ip(addr):
                ips.append(addr)
                t = int(ans.get('TTL', 0) or 0)
                ttl = t if ttl is None else min(ttl, t)
        return ips, ttl
    return None

def _doh_lookup(host, refresh_after=None):
    host = host.strip('[]').rstrip('.').lower()

    def _usable(e, t):
        if e is None or e[1] <= t:
            return False
        return refresh_after is None or e[2] >= refresh_after

    now = time.monotonic()
    with _DOH_LOCK:
        e = _DOH_CACHE.get(host)
        if _usable(e, now):
            return list(e[0])
        lk = _DOH_INFLIGHT.setdefault(host, threading.Lock())

    with lk:
        try:
            now = time.monotonic()
            with _DOH_LOCK:
                e = _DOH_CACHE.get(host)
                if _usable(e, now):
                    return list(e[0])
                stale = e
            ips, ttl, failed = [], None, False
            res = _doh_query(host, 'A')
            if res is None:
                failed = True
            elif res[0]:
                ips, ttl = res
            else:
                res6 = _doh_query(host, 'AAAA')
                if res6 is not None and res6[0]:
                    ips, ttl = res6
            t_done = time.monotonic()
            if ips:
                ttl = min(max(ttl or 0, DOH_MIN_TTL), DOH_MAX_TTL)
                with _DOH_LOCK:
                    _DOH_CACHE[host] = (ips, t_done + ttl, t_done)
                _log(f'[DoH] {host} -> {",".join(ips[:DOH_MAX_IPS])} (ttl {ttl}s)',
                     LOGDEBUG)
                return list(ips)
            if (failed and stale is not None and stale[0]
                    and t_done - stale[2] < DOH_STALE_MAX):
                with _DOH_LOCK:
                    _DOH_CACHE[host] = (stale[0], t_done + DOH_NEG_TTL, stale[2])
                _log(f'[DoH] {host}: DoH indisponÃ­vel, usando IP em cache',
                     LOGWARNING)
                return list(stale[0])
            with _DOH_LOCK:
                _DOH_CACHE[host] = ([], t_done + DOH_NEG_TTL, t_done)
            _log(f'[DoH] {host}: sem resposta', LOGWARNING)
            return []
        finally:
            # Evita crescimento ilimitado de locks por hostname
            with _DOH_LOCK:
                if _DOH_INFLIGHT.get(host) is lk:
                    _DOH_INFLIGHT.pop(host, None)

def _doh_demote(host, ip):
    host = host.strip('[]').rstrip('.').lower()
    with _DOH_LOCK:
        e = _DOH_CACHE.get(host)
        if e is None or ip not in e[0]:
            return
        ips = [x for x in e[0] if x != ip] + [ip]
        _DOH_CACHE[host] = (ips, e[1], e[2])

def _doh_expire(host):
    if not host or _is_ip(host):
        return
    host = host.strip('[]').rstrip('.').lower()
    with _DOH_LOCK:
        e = _DOH_CACHE.get(host)
        if e is not None:
            _DOH_CACHE[host] = (e[0], 0.0, e[2])

def _doh_prewarm(url):
    try:
        host = urlparse(url).hostname
    except Exception:
        return
    if not host or _is_ip(host) or host == 'localhost':
        return

    def _run():
        try:
            _doh_lookup(host)
        except Exception:
            pass

    threading.Thread(target=_run, daemon=True).start()

def _doh_create_connection(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT,
                           source_address=None, socket_options=None):
    host, port = address
    if (not getattr(_TLS, 'doh', False) or _is_ip(host)
            or host.strip('[]') == 'localhost'):
        return _ORIG_CREATE_CONNECTION(
            address, timeout, source_address, socket_options
        )
    t_start = time.monotonic()
    numeric = (isinstance(timeout, (int, float))
               and not isinstance(timeout, bool))
    deadline = t_start + (float(timeout) if numeric else 10.0)
    tried = set()
    err = None
    for rnd in (0, 1):
        ips = _doh_lookup(host, None if rnd == 0 else t_start)
        cand = [ip for ip in ips if ip not in tried][:DOH_MAX_IPS]
        if not cand and rnd == 1 and err is not None:
            cand = ips[:1]
        if not cand:
            break
        for i, ip in enumerate(cand):
            remaining = deadline - time.monotonic()
            if remaining <= 0.05:
                break
            last_of_last_round = (rnd == 1 and i == len(cand) - 1)
            t = remaining if last_of_last_round else min(
                remaining, DOH_PER_IP_TIMEOUT
            )
            tried.add(ip)
            try:
                return _ORIG_CREATE_CONNECTION(
                    (ip, port), t, source_address, socket_options
                )
            except OSError as e:
                err = e
                _doh_demote(host, ip)
        if rnd == 0 and err is not None:
            _log(f'[DoH] {host}: IPs em cache falharam, re-consultando',
                 LOGWARNING)
    if DOH_SYSTEM_FALLBACK:
        try:
            return _ORIG_CREATE_CONNECTION(
                address, timeout, source_address, socket_options
            )
        except OSError as e:
            if err is None:
                err = e
    if err is not None:
        raise err
    raise socket.gaierror(socket.EAI_NONAME, f'DoH sem resposta: {host}')

_u3conn.create_connection = _doh_create_connection

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# LOG
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
try:
    import xbmc as _xbmc
    LOGDEBUG = _xbmc.LOGDEBUG
    LOGINFO = _xbmc.LOGINFO
    LOGWARNING = _xbmc.LOGWARNING
    LOGERROR = _xbmc.LOGERROR
except Exception:
    _xbmc = None
    LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR = 0, 1, 2, 3

LOG_ENABLED = False

def set_logging(enabled):
    global LOG_ENABLED
    LOG_ENABLED = bool(enabled)

def _log(msg, level=None):
    if not LOG_ENABLED:
        return
    if level is None:
        level = LOGINFO
    try:
        if _xbmc is None:
            raise RuntimeError('sem xbmc')
        _xbmc.log(f'[HLSProxy] {msg}', level)
    except Exception:
        print(f'[HLSProxy] {msg}')

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# CONSTANTES v1.5.6
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
HLS_MAX_REDIRECTS = 5
HLS_CONNECT_TIMEOUT = 5
HLS_READ_TIMEOUT = 20            # era 30 â€” CDN morto corta mais rÃ¡pido
HLS_MAX_OPERATION_TIME = 10.0

HLS_CHUNK_SIZE = 32 * 1024       # buffer de leitura de corpos (playlist/key)
HLS_STREAM_CHUNK = 32 * 1024     # v1.5.6: chunk de streaming ao cliente

HLS_PLAYLIST_MAX_RETRIES = 4
HLS_SEGMENT_MAX_RETRIES = 1      # v1.5.6: nÃ£o retenta CDN lento
HLS_RETRY_BACKOFF_BASE = 0.25
HLS_RETRY_BACKOFF_MAX = 3.0
HLS_STALE_SEQUENCE_MAX = 3
HLS_STALE_SEQUENCE_MIN_SECONDS = 30.0
HLS_LAST_GOOD_MAX_AGE = 20.0
HLS_PLAYLIST_RECOVERY_BUDGET = 8.0
HLS_PLAYLIST_COLD_BUDGET = 20.0
HLS_ENTRY_REUSE_SECONDS = 1.0
HLS_FRESH_REUSE_SECONDS = 3.0
HLS_FRESH_FAIL_COOLDOWN = 1.0
HLS_TTL_REFRESH_RATIO = 0.6
HLS_TTL_MIN_LEARN = 2.0
HLS_SEQ_REGRESS_MIN = 10
HLS_SEQ_JUMP_MAX = 30
HLS_AFFINITY_RETRIES = 3
HLS_AFFINITY_BUDGET = 5.0
HLS_SWITCH_KEEP_SEGMENTS = 3
HLS_SEGMENT_TOTAL_BUDGET = 90.0        # era 120
HLS_SEGMENT_MAX_OPERATION_TIME = 60.0  # era 90 â€” CDN real leva ~15s

HLS_HOST_DEAD_MAX_RETRIES = 2
HLS_HOST_DEAD_BACKOFF_MAX = 0.5
HLS_FRESH_RESOLVE_TIMEOUT = 8.0

HLS_MAX_LOCAL_WORKERS = 8
HLS_ACCEPT_QUEUE = 32
HLS_WORKER_WAIT = 60.0

# v1.5.6: cache maior (24 entradas, 90s)
HLS_SEGMENT_CACHE_MAX = 24
HLS_SEGMENT_CACHE_MAX_AGE = 90.0

HLS_DIAG_PLAYLISTS = 3
HLS_DIAG_SEGMENTS = 4

# v1.5.6: prefetch agressivo (6 Ãºltimos, 3 paralelos)
HLS_PREFETCH_COUNT = 6
HLS_PREFETCH_WORKERS = 3

# v1.5.6: renovaÃ§Ã£o proativa (fraÃ§Ã£o do TTL)
HLS_RENEWAL_RATIO = 0.5
HLS_RENEWAL_MIN_INTERVAL = 4.0
HLS_RENEWAL_MAX_INTERVAL = 25.0

HOST_BIND = '0.0.0.0'
HLS_PORT_RANGE = (20000, 60000)
HLS_PORT_BIND_ATTEMPTS = 50

_REDIRECT_CODES = (301, 302, 303, 307, 308)

_HLS_NULL_PACKET = b'\x47\x1f\xff\x10' + (b'\x00' * 184)
HLS_FILLER_TS = _HLS_NULL_PACKET * 8

CLIENT_PROFILES = (
    {
        'User-Agent': 'Kodi/21.0 (Android; Kodi Media Center)',
        'Accept': '*/*',
    },
    {
        'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20',
        'Accept': '*/*',
    },
    {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ),
        'Accept': '*/*',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
    },
)

_SERVER = None
_SERVER_LOCK = threading.Lock()
_SERVER_PORT = 0
_SERVER_SEMAPHORE = None

_SESSIONS = {}
_SESSIONS_LOCK = threading.Lock()

_ACTIVE_TOKEN = None
_ACTIVE_TOKEN_LOCK = threading.Lock()

_PREFETCH_SEM = threading.BoundedSemaphore(HLS_PREFETCH_WORKERS)

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# HELPERS DE URL / HEADERS
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _b64e(s):
    return base64.urlsafe_b64encode(s.encode('utf-8')).decode('ascii').rstrip('=')

def _b64d(s):
    """Decode urlsafe base64; raises ValueError on invalid/empty result."""
    if not s or not isinstance(s, str):
        raise ValueError('base64 vazio')
    try:
        pad = '=' * (-len(s) % 4)
        raw = base64.urlsafe_b64decode((s + pad).encode('ascii'))
        text = raw.decode('utf-8')
    except Exception as e:
        raise ValueError(f'base64 invÃ¡lido: {e}') from e
    if not text:
        raise ValueError('base64 resultou em string vazia')
    return text

def _host_header(parsed):
    if not parsed.hostname:
        return parsed.netloc
    default_port = 443 if parsed.scheme == 'https' else 80
    try:
        port = parsed.port
    except ValueError:
        port = None
    if port and port != default_port:
        return f'{parsed.hostname}:{port}'
    return parsed.hostname

def _origin_header(parsed):
    return f'{parsed.scheme}://{_host_header(parsed)}'

def _pick_profile(idx):
    return CLIENT_PROFILES[idx % len(CLIENT_PROFILES)]

def _build_headers(parsed, entry_parsed, profile_idx, extra=None):
    headers = dict(_pick_profile(profile_idx))
    headers['Host'] = _host_header(parsed)
    headers['Accept-Encoding'] = 'identity'
    headers['Origin'] = _origin_header(entry_parsed)
    headers['Referer'] = urlunparse(entry_parsed)
    if extra:
        headers.update(extra)
    return headers

def _seq_cache_key(seq):
    return f'seq:{seq}'

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# FETCH
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
class _FetchResult:
    __slots__ = ('status', 'headers', 'body', 'final_url', 'error')
    def __init__(self, status=None, headers=None, body=None, final_url=None, error=None):
        self.status = status
        self.headers = headers or {}
        self.body = body
        self.final_url = final_url
        self.error = error

def _describe(result):
    if result is None:
        return 'sem resultado'
    if result.error is not None:
        return f'erro={result.error}'
    n = len(result.body) if result.body else 0
    ct = (result.headers or {}).get('content-type', '?')
    return f'HTTP {result.status}, {n}B, ct={ct}'

_NET_ERRORS = (
    requests.exceptions.RequestException, urllib3.exceptions.HTTPError,
    socket.timeout, ConnectionError, OSError, ssl.SSLError,
    http.client.HTTPException, ValueError,
)

_STALE_CONN_MARKERS = (
    'Connection aborted', 'RemoteDisconnected', 'Connection reset',
    'reset by peer', 'Broken pipe',
)

def _is_stale_conn_error(exc):
    msg = str(exc)
    return any(m in msg for m in _STALE_CONN_MARKERS)

def _http_get(url, headers, op_deadline, connect_timeout):
    sess = _get_http()
    attempt = 0
    while True:
        remaining = max(0.25, op_deadline - time.monotonic())
        timeout = (
            min(connect_timeout, remaining),
            max(0.25, min(float(HLS_READ_TIMEOUT), remaining)),
        )
        try:
            return sess.get(
                url, headers=headers, timeout=timeout,
                stream=True, allow_redirects=False
            )
        except requests.exceptions.ConnectTimeout:
            raise
        except requests.exceptions.ConnectionError as e:
            if (attempt < 2 and _is_stale_conn_error(e)
                    and time.monotonic() < op_deadline):
                attempt += 1
                _reset_http_pool()
                continue
            raise

def _read_body_blocks(resp, deadline=None):
    raw = resp.raw
    sock = None
    try:
        sock = getattr(getattr(raw, '_connection', None), 'sock', None)
    except Exception:
        sock = None
    expected = None
    chunked = (resp.headers.get('Transfer-Encoding') or '').lower() == 'chunked'
    if not chunked:
        try:
            cl = resp.headers.get('Content-Length')
            if cl is not None:
                expected = int(cl)
        except Exception:
            expected = None
    read1 = getattr(raw, 'read1', None)
    buf = bytearray()
    while True:
        if deadline is not None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise socket.timeout('deadline de leitura total excedido')
            if sock is not None:
                try:
                    sock.settimeout(
                        max(0.25, min(float(HLS_READ_TIMEOUT), remaining))
                    )
                except Exception:
                    pass
        if read1 is not None:
            block = read1(HLS_CHUNK_SIZE)
        else:
            block = raw.read(HLS_CHUNK_SIZE // 4)
        if not block:
            break
        buf.extend(block)
    if expected is not None and len(buf) < expected:
        raise ConnectionError(
            f'corpo incompleto: {len(buf)}/{expected} bytes'
        )
    return bytes(buf)

def _fetch(url, entry_parsed, profile_idx=0, timeout=HLS_CONNECT_TIMEOUT,
           max_redirects=HLS_MAX_REDIRECTS, range_header=None,
           max_operation_time=None):
    if max_operation_time is None:
        max_operation_time = HLS_MAX_OPERATION_TIME
    op_deadline = time.monotonic() + max_operation_time
    current = url
    _TLS.doh = True
    try:
        for hop in range(max_redirects + 1):
            if time.monotonic() >= op_deadline:
                return _FetchResult(error='tempo total de operaÃ§Ã£o excedido',
                                    final_url=current)
            parsed = urlparse(current)
            if not parsed.scheme or not parsed.hostname:
                return _FetchResult(error=f'URL invÃ¡lida: {current}')
            extra = {'Range': range_header} if range_header else None
            headers = _build_headers(parsed, entry_parsed, profile_idx, extra)
            resp = None
            try:
                resp = _http_get(current, headers, op_deadline, timeout)
                status = resp.status_code
                if status in _REDIRECT_CODES:
                    location = resp.headers.get('Location')
                    resp.close()
                    resp = None
                    if not location:
                        return _FetchResult(status=status, final_url=current,
                                            error='redirect sem Location')
                    new_url = urljoin(current, location)
                    if new_url == current:
                        return _FetchResult(status=status, final_url=current,
                                            error='redirect loop')
                    current = new_url
                    continue
                body = _read_body_blocks(resp, deadline=op_deadline)
                resp_headers = {
                    k.lower(): v for k, v in resp.headers.items()
                }
                return _FetchResult(
                    status=status, headers=resp_headers, body=body,
                    final_url=current
                )
            except _NET_ERRORS as e:
                if isinstance(e, (OSError, urllib3.exceptions.HTTPError,
                                  http.client.HTTPException)):
                    _doh_expire(parsed.hostname)
                return _FetchResult(error=f'{type(e).__name__}: {e}',
                                    final_url=current)
            finally:
                if resp is not None:
                    try:
                        resp.close()
                    except Exception:
                        pass
        return _FetchResult(error='mÃ¡ximo de redirects excedido',
                            final_url=current)
    finally:
        _TLS.doh = False

def _is_network_level_error(result):
    return result is not None and result.error is not None and result.status is None

def _fetch_with_retry(url, entry_parsed, max_retries, timeout=HLS_CONNECT_TIMEOUT,
                      range_header=None, fast_backoff=False,
                      max_total_time=None, op_time=None,
                      no_retry_4xx=False):
    if op_time is None:
        op_time = HLS_MAX_OPERATION_TIME
    if max_total_time is None:
        max_total_time = op_time * max(1, max_retries)
    total_deadline = time.monotonic() + max_total_time
    last_result = None
    backoff_cap = (
        HLS_HOST_DEAD_BACKOFF_MAX if fast_backoff
        else HLS_RETRY_BACKOFF_MAX
    )
    for attempt in range(max_retries):
        remaining = total_deadline - time.monotonic()
        if remaining <= 0:
            break
        result = _fetch(
            url, entry_parsed, profile_idx=attempt, timeout=timeout,
            range_header=range_header,
            max_operation_time=min(remaining, op_time)
        )
        last_result = result
        if (result.error is None and result.status is not None
                and result.status < 400):
            return result
        if (fast_backoff and _is_network_level_error(result)
                and attempt + 1 >= HLS_HOST_DEAD_MAX_RETRIES):
            break
        if (no_retry_4xx and result.status is not None
                and 400 <= result.status < 500
                and result.status not in (408, 429)):
            break
        if time.monotonic() >= total_deadline:
            break
        wait = min(
            HLS_RETRY_BACKOFF_BASE * (2 ** attempt),
            backoff_cap
        )
        wait *= 0.8 + 0.4 * random.random()
        time.sleep(min(wait, max(0.0, total_deadline - time.monotonic())))
    return last_result

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# VALIDAÃ‡ÃƒO DE CORPO
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_BAD_BODY_PREFIXES = (
    b'<!doctype', b'<html', b'<?xml', b'<head', b'<body', b'{"', b'#extm3u',
)

def _is_bad_media_body(body):
    if not body:
        return True
    head = body[:64].lstrip().lower()
    return head.startswith(_BAD_BODY_PREFIXES)

def _has_ts_sync(body):
    if not body or body[0] != 0x47:
        return False
    return len(body) < 189 or body[188] == 0x47

def _media_ok(result):
    return (result is not None and result.error is None
            and result.status is not None and result.status < 400
            and result.body and not _is_bad_media_body(result.body))

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# SESSÃƒO
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
class _StreamSession:
    def __init__(self, token, entry_url):
        self.token = token
        self.entry_url = entry_url
        self.entry_parsed = urlparse(entry_url)
        self.resolved_base = entry_url
        self.lock = threading.RLock()
        self.last_media_sequence = None
        self.last_seq_change_ts = time.time()
        self.stale_sequence_count = 0
        self.last_good_playlist_body = None
        self.last_good_playlist_base = None
        self.last_good_playlist_time = 0.0
        self.last_good_segments = {}
        self.segment_cache_order = []
        self.profile_idx = 0
        self.created_at = time.time()
        self.last_access = time.time()
        self.killed = threading.Event()
        self.last_good_host = None
        self.discontinuity_pending = False
        self.diag_playlists = 0
        self.diag_segments = 0
        self.resolve_lock = threading.Lock()
        self.fresh_cache = None
        self.fresh_cache_time = 0.0
        self.fresh_fail_time = -1e9
        self.base_born = 0.0
        self.base_ttl = None
        self.seq_offset = 0
        self.last_exposed_end = 0
        self.seq_floor = None
        self.disc_marks = []
        self.log_ts = {}
        self.prefetch_inflight = set()
        self.renewal_started = False

    def touch(self):
        self.last_access = time.time()

    def kill(self):
        self.killed.set()

    def rotate_profile(self):
        with self.lock:
            self.profile_idx += 1

    def force_fresh_resolve(self):
        with self.lock:
            self.resolved_base = self.entry_url
            self.stale_sequence_count = 0
            self.base_born = 0.0
            _log(
                f'[{self.token[:8]}] ForÃ§ando re-resoluÃ§Ã£o pela URL de entrada',
                LOGINFO
            )

    def cache_segment(self, key, body):
        now = time.time()
        with self.lock:
            self.last_good_segments[key] = (body, now)
            try:
                self.segment_cache_order.remove(key)
            except ValueError:
                pass
            self.segment_cache_order.append(key)
            while len(self.segment_cache_order) > HLS_SEGMENT_CACHE_MAX:
                old = self.segment_cache_order.pop(0)
                self.last_good_segments.pop(old, None)

    def get_cached_segment(self, key):
        now = time.time()
        with self.lock:
            item = self.last_good_segments.get(key)
            if item is None:
                return None
            body, ts = item
            if now - ts > HLS_SEGMENT_CACHE_MAX_AGE:
                self.last_good_segments.pop(key, None)
                try:
                    self.segment_cache_order.remove(key)
                except ValueError:
                    pass
                return None
            return item

    def mark_prefetch(self, key):
        with self.lock:
            if key in self.prefetch_inflight:
                return False
            self.prefetch_inflight.add(key)
            if len(self.prefetch_inflight) > 32:
                self.prefetch_inflight = set(
                    list(self.prefetch_inflight)[-16:]
                )
            return True

    def clear_prefetch(self, key):
        with self.lock:
            self.prefetch_inflight.discard(key)

def _get_or_create_session(token, entry_url):
    with _SESSIONS_LOCK:
        sess = _SESSIONS.get(token)
        if sess is None:
            sess = _StreamSession(token, entry_url)
            _SESSIONS[token] = sess
        else:
            sess.touch()
        return sess

def _set_active_channel(token, entry_url):
    global _ACTIVE_TOKEN
    with _ACTIVE_TOKEN_LOCK:
        previous_token = _ACTIVE_TOKEN
        _ACTIVE_TOKEN = token
    if previous_token is not None and previous_token != token:
        with _SESSIONS_LOCK:
            old = _SESSIONS.pop(previous_token, None)
        if old is not None:
            old.kill()
            _log(
                f'Canal trocado: sessÃ£o [{previous_token[:8]}] encerrada',
                LOGINFO
            )
    return _get_or_create_session(token, entry_url)

def _gc_sessions(max_idle=600):
    with _SESSIONS_LOCK:
        now = time.time()
        dead = [
            t for t, s in _SESSIONS.items()
            if now - s.last_access > max_idle
        ]
        for t in dead:
            sess = _SESSIONS.pop(t, None)
            if sess:
                sess.kill()
        if dead:
            _log(f'GC: removidas {len(dead)} sessÃ£o(Ãµes) ociosas', LOGINFO)

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# M3U8
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_RE_MEDIA_SEQUENCE = re.compile(rb'#EXT-X-MEDIA-SEQUENCE:(\d+)')

_RE_KEY_URI = re.compile(
    r'(#EXT-X-(?:SESSION-)?KEY:[^\n]*URI=)(?:"([^"]*)"|([^",\r\n]*))'
)
_RE_MAP_URI = re.compile(r'(#EXT-X-MAP:[^\n]*URI=")([^"]+)(")')
_RE_RENDITION_URI = re.compile(
    r'(#EXT-X-(?:MEDIA|I-FRAME-STREAM-INF):[^\n]*URI=")([^"]+)(")'
)
_RE_STREAM_INF = re.compile(r'#EXT-X-STREAM-INF', re.IGNORECASE)

def _extract_media_sequence(text):
    if isinstance(text, bytes):
        m = _RE_MEDIA_SEQUENCE.search(text)
    else:
        m = re.search(r'#EXT-X-MEDIA-SEQUENCE:(\d+)', text)
    return int(m.group(1)) if m else None

def _is_master_playlist(text):
    if isinstance(text, bytes):
        return bool(re.search(rb'#EXT-X-STREAM-INF', text, re.IGNORECASE))
    return bool(_RE_STREAM_INF.search(text))

def _rewrite_uri(base_url, uri, token, kind):
    absolute = urljoin(base_url, uri)
    return f'/hls/{kind}/{token}/{_b64e(absolute)}'

def _rewrite_playlist(text, base_url, token, insert_discontinuity=False,
                      seq_offset=0, skip_first=0, disc_marks=None):
    is_master = _is_master_playlist(text)
    lines = text.split('\n')
    out = []
    discontinuity_inserted = not insert_discontinuity or is_master
    pending = []

    if is_master:
        skip_first = 0
    marks = (frozenset(disc_marks)
             if (disc_marks and not is_master) else frozenset())
    first_seq = _extract_media_sequence(text) or 0
    seg_idx = 0

    for line in lines:
        line = line.rstrip('\r')
        stripped = line.strip()

        if ((seq_offset or skip_first)
                and stripped.startswith('#EXT-X-MEDIA-SEQUENCE:')):
            try:
                n = int(stripped.split(':', 1)[1]) + skip_first + seq_offset
                out.append(f'#EXT-X-MEDIA-SEQUENCE:{n}')
                continue
            except ValueError:
                pass

        # CHAVE AES-128 (#EXT-X-KEY) â€” reescrita para o proxy
        if (stripped.startswith('#EXT-X-KEY')
                or stripped.startswith('#EXT-X-SESSION-KEY')):
            def sub_key(m):
                quoted = m.group(2)
                unquoted = m.group(3)
                if quoted is not None:
                    return (m.group(1) + '"'
                            + _rewrite_uri(base_url, quoted, token, 'key')
                            + '"')
                return (m.group(1)
                        + _rewrite_uri(base_url, unquoted or '',
                                       token, 'key'))
            out.append(_RE_KEY_URI.sub(sub_key, line))
            continue

        if stripped.startswith('#EXT-X-MAP'):
            def sub_map(m):
                return m.group(1) + _rewrite_uri(
                    base_url, m.group(2), token, 'seg'
                ) + m.group(3)
            out.append(_RE_MAP_URI.sub(sub_map, line))
            continue

        if (stripped.startswith('#EXT-X-MEDIA:')
                or stripped.startswith('#EXT-X-I-FRAME-STREAM-INF')):
            def sub_rend(m):
                return m.group(1) + _rewrite_uri(
                    base_url, m.group(2), token, 'variant'
                ) + m.group(3)
            out.append(_RE_RENDITION_URI.sub(sub_rend, line))
            continue

        # v1.5.6: segmento reescrito COM a seq do player no path.
        # Formato: /hls/seg/<token>/<player_seq>/<b64_url>
        # O handler usa a seq como chave de cache -> cache HIT entre polls.
        if stripped and not stripped.startswith('#'):
            idx = seg_idx
            seg_idx += 1
            if idx < skip_first:
                pending = []
                continue
            if (not discontinuity_inserted
                    or (first_seq + seq_offset + idx) in marks):
                out.append('#EXT-X-DISCONTINUITY')
                discontinuity_inserted = True
            if pending:
                out.extend(pending)
                pending = []
            if is_master:
                out.append(_rewrite_uri(base_url, stripped, token, 'variant'))
            else:
                player_seq = first_seq + seq_offset + idx
                absolute = urljoin(base_url, stripped)
                out.append(
                    f'/hls/seg/{token}/{player_seq}/{_b64e(absolute)}'
                )
            continue

        if (stripped.startswith('#EXTINF')
                or stripped.startswith('#EXT-X-BYTERANGE')
                or stripped.startswith('#EXT-X-PROGRAM-DATE-TIME')):
            pending.append(line)
            continue

        out.append(line)

    if pending:
        out.extend(pending)
    return '\n'.join(out)

def _diag_playlist(sess, rewritten):
    if sess.diag_playlists >= HLS_DIAG_PLAYLISTS:
        return
    sess.diag_playlists += 1
    short = []
    for ln in rewritten.split('\n')[:14]:
        short.append(ln if len(ln) <= 90 else ln[:90] + 'â€¦')
    _log(
        f'[{sess.token[:8]}] Playlist reescrita #{sess.diag_playlists}: '
        + ' | '.join(short),
        LOGINFO
    )

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# PLAYLIST
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _log_throttled(sess, key, msg, level=None, interval=5.0):
    now = time.monotonic()
    with sess.lock:
        if now - sess.log_ts.get(key, -1e9) < interval:
            return
        sess.log_ts[key] = now
    _log(msg, level)

def _count_segments(text):
    n = 0
    for ln in text.split('\n'):
        ln = ln.strip()
        if ln and not ln.startswith('#'):
            n += 1
    return n

def _playlist_ok(result):
    return (result is not None and result.error is None
            and result.status is not None and result.status < 400
            and result.body and b'#EXTM3U' in result.body[:128])

def _take_discontinuity(sess):
    with sess.lock:
        d = sess.discontinuity_pending
        sess.discontinuity_pending = False
    return d

def _rebase_lineage(sess, text, seq, reason):
    n = _count_segments(text)
    dropped = max(0, n - HLS_SWITCH_KEEP_SEGMENTS)
    start = sess.last_exposed_end
    sess.seq_floor = seq + dropped
    sess.seq_offset = start - sess.seq_floor
    if start not in sess.disc_marks:
        sess.disc_marks.append(start)
    sess.last_exposed_end = max(sess.last_exposed_end, start)
    _log(
        f'[{sess.token[:8]}] Nova origem ({reason}): seq {seq} -> exposta '
        f'{start}, pulando {dropped} segmento(s), DISCONTINUITY em {start}',
        LOGINFO
    )

def _playlist_view(sess, text):
    origin_first = _extract_media_sequence(text)
    n = _count_segments(text)
    with sess.lock:
        offset = sess.seq_offset
        floor = sess.seq_floor
        skip = 0
        if floor is not None and origin_first is not None:
            skip = max(0, min(floor - origin_first, n - 1))
        if origin_first is not None:
            window_start = origin_first + skip + offset
            sess.disc_marks = [m for m in sess.disc_marks if m >= window_start]
        marks = tuple(sess.disc_marks)
    return offset, skip, marks

def _iter_output_segments(sess, text):
    """Itera (player_seq, uri) na ordem do OUTPUT da playlist reescrita."""
    origin_first = _extract_media_sequence(text) or 0
    with sess.lock:
        seq_offset = sess.seq_offset
        floor = sess.seq_floor
    n = _count_segments(text)
    skip = 0
    if floor is not None:
        skip = max(0, min(floor - origin_first, n - 1))
    idx = 0
    for ln in text.split('\n'):
        cand = ln.strip()
        if cand and not cand.startswith('#'):
            if idx >= skip:
                yield (origin_first + seq_offset + idx, cand)
            idx += 1

def _accept_playlist(sess, text, seq, used_base, via_fresh, update_base=True):
    need_refresh = False
    with sess.lock:
        now = time.time()
        new_host = urlparse(used_base).hostname
        prev_host = sess.last_good_host
        changed = (
            prev_host is not None and new_host is not None
            and new_host != prev_host
        )
        rebase = None
        if changed:
            _log(
                f'[{sess.token[:8]}] CDN trocou de host: '
                f'{prev_host} -> {new_host}',
                LOGINFO
            )
            rebase = f'host {prev_host} -> {new_host}'
        sess.last_good_host = new_host
        last = None if changed else sess.last_media_sequence
        if seq is None or last is None:
            sess.stale_sequence_count = 0
            sess.last_seq_change_ts = now
        elif seq == last:
            sess.stale_sequence_count += 1
            stalled_for = now - sess.last_seq_change_ts
            if (sess.stale_sequence_count >= HLS_STALE_SEQUENCE_MAX
                    and stalled_for >= HLS_STALE_SEQUENCE_MIN_SECONDS):
                if not via_fresh and used_base != sess.entry_url:
                    need_refresh = True
                else:
                    _log(
                        f'[{sess.token[:8]}] media_sequence {seq} '
                        f'estagnada hÃ¡ {stalled_for:.0f}s; '
                        f'mantendo origem atual',
                        LOGWARNING
                    )
                sess.stale_sequence_count = 0
                sess.last_seq_change_ts = now
        else:
            sess.stale_sequence_count = 0
            sess.last_seq_change_ts = now
            if last - seq > HLS_SEQ_REGRESS_MIN:
                rebase = f'media_sequence regrediu {last} -> {seq}'
            elif seq - last > HLS_SEQ_JUMP_MAX:
                rebase = f'media_sequence saltou {last} -> {seq}'
        if rebase is not None:
            if seq is not None:
                _rebase_lineage(sess, text, seq, rebase)
            else:
                sess.discontinuity_pending = True
        if seq is not None:
            if last is None or seq >= last or last - seq > HLS_SEQ_REGRESS_MIN:
                sess.last_media_sequence = seq
            exposed_first = seq + sess.seq_offset
            sess.last_exposed_end = max(
                sess.last_exposed_end,
                exposed_first + _count_segments(text)
            )
        if update_base:
            sess.resolved_base = used_base
            if via_fresh:
                sess.base_born = now if used_base != sess.entry_url else 0.0
        sess.last_good_playlist_body = text
        sess.last_good_playlist_base = used_base
        sess.last_good_playlist_time = now
    return need_refresh

def _seek_pinned_host(sess, result):
    if HLS_AFFINITY_RETRIES <= 0:
        return result
    with sess.lock:
        pinned = sess.last_good_host
    if not pinned:
        return result
    t_end = time.monotonic() + HLS_AFFINITY_BUDGET
    tries = 0
    while tries < HLS_AFFINITY_RETRIES:
        if urlparse(result.final_url or '').hostname == pinned:
            break
        remaining = t_end - time.monotonic()
        if remaining < 1.0 or sess.killed.is_set():
            break
        tries += 1
        r2 = _fetch_with_retry(
            sess.entry_url, sess.entry_parsed, 1,
            timeout=min(HLS_FRESH_RESOLVE_TIMEOUT, remaining),
            fast_backoff=True, max_total_time=remaining
        )
        if _playlist_ok(r2):
            result = r2
    if tries:
        got = urlparse(result.final_url or '').hostname
        _log(
            f'[{sess.token[:8]}] Afinidade de origem: {pinned} '
            f'{"mantida" if got == pinned else "perdida -> " + str(got)} '
            f'apÃ³s {tries} tentativa(s)',
            LOGINFO
        )
    return result

def _fresh_resolve(sess, min_interval=None, affinity=True):
    if min_interval is None:
        min_interval = HLS_FRESH_REUSE_SECONDS
    if sess.killed.is_set():
        return None
    with sess.resolve_lock:
        if sess.killed.is_set():
            return None
        now = time.monotonic()
        if (sess.fresh_cache is not None
                and now - sess.fresh_cache_time < min_interval):
            return sess.fresh_cache
        if now - sess.fresh_fail_time < HLS_FRESH_FAIL_COOLDOWN:
            return None
        with sess.lock:
            prev_born = sess.base_born
        result = _fetch_with_retry(
            sess.entry_url, sess.entry_parsed,
            HLS_PLAYLIST_MAX_RETRIES,
            timeout=HLS_FRESH_RESOLVE_TIMEOUT,
            fast_backoff=True,
            max_total_time=HLS_FRESH_RESOLVE_TIMEOUT * 2
        )
        if sess.killed.is_set():
            return None
        if affinity and _playlist_ok(result):
            result = _seek_pinned_host(sess, result)
            if sess.killed.is_set():
                return None
        if _playlist_ok(result):
            text = result.body.decode('utf-8', errors='replace')
            final = result.final_url or sess.entry_url
            seq = _extract_media_sequence(result.body)
            _accept_playlist(sess, text, seq, final, via_fresh=True)
            sess.fresh_cache = (text, final)
            sess.fresh_cache_time = time.monotonic()
            age = (time.time() - prev_born) if prev_born else 0
            _log(
                f'[{sess.token[:8]}] Re-resoluÃ§Ã£o OK: '
                f'host={urlparse(final).hostname} seq={seq} '
                f'(base anterior viveu {age:.0f}s)',
                LOGINFO
            )
            return sess.fresh_cache
        sess.fresh_cache = None
        sess.fresh_fail_time = time.monotonic()
        _log_throttled(
            sess, 'fresh_fail',
            f'[{sess.token[:8]}] Re-resoluÃ§Ã£o falhou ({_describe(result)})',
            LOGWARNING
        )
        return None

def _try_resolve_playlist_once(sess):
    with sess.lock:
        base = sess.resolved_base
        born = sess.base_born
        ttl = sess.base_ttl
    entry = sess.entry_url
    if base == entry:
        r = _fresh_resolve(sess, HLS_ENTRY_REUSE_SECONDS)
        if r is None:
            return None
        return r[0], r[1], _take_discontinuity(sess)
    age = (time.time() - born) if born else None
    if ttl and age is not None and age > ttl * HLS_TTL_REFRESH_RATIO:
        r = _fresh_resolve(sess, HLS_FRESH_REUSE_SECONDS)
        if r is not None:
            _log(
                f'[{sess.token[:8]}] RenovaÃ§Ã£o preventiva do token '
                f'(idade {age:.0f}s, ttl ~{ttl:.0f}s)',
                LOGINFO
            )
            return r[0], r[1], _take_discontinuity(sess)
    result = _fetch_with_retry(
        base, sess.entry_parsed, HLS_HOST_DEAD_MAX_RETRIES,
        fast_backoff=True, max_total_time=HLS_FRESH_RESOLVE_TIMEOUT,
        no_retry_4xx=True
    )
    if sess.killed.is_set():
        return None
    if _playlist_ok(result):
        text = result.body.decode('utf-8', errors='replace')
        seq = _extract_media_sequence(result.body)
        used_base = result.final_url or base
        need_refresh = _accept_playlist(
            sess, text, seq, used_base, via_fresh=False
        )
        if need_refresh:
            r = _fresh_resolve(sess, 0.0)
            if r is not None:
                return r[0], r[1], _take_discontinuity(sess)
        return text, used_base, _take_discontinuity(sess)
    if result is not None and result.status == 403:
        sess.rotate_profile()
        _log_throttled(
            sess, 'rot403',
            f'[{sess.token[:8]}] Playlist 403; rotacionando profile',
            LOGWARNING
        )
    if (result is not None and result.status is not None
            and 400 <= result.status < 500
            and age is not None and age >= HLS_TTL_MIN_LEARN):
        with sess.lock:
            sess.base_ttl = min(sess.base_ttl, age) if sess.base_ttl else age
            ttl = sess.base_ttl
        _log(
            f'[{sess.token[:8]}] Token da base expirou com {age:.0f}s '
            f'(ttl aprendido ~{ttl:.0f}s)',
            LOGINFO
        )
    _log_throttled(
        sess, 'base_fail',
        f'[{sess.token[:8]}] Playlist da base falhou ({_describe(result)})',
        LOGWARNING
    )
    r = _fresh_resolve(sess, HLS_FRESH_REUSE_SECONDS,
                       affinity=not _is_network_level_error(result))
    if r is not None:
        return r[0], r[1], _take_discontinuity(sess)
    return None

def _resolve_playlist(sess):
    if sess.killed.is_set():
        return None, sess.resolved_base, False
    with sess.lock:
        have_good = sess.last_good_playlist_body is not None
    budget = (
        HLS_PLAYLIST_RECOVERY_BUDGET if have_good
        else HLS_PLAYLIST_COLD_BUDGET
    )
    deadline = time.monotonic() + budget
    attempt = 0
    while True:
        res = _try_resolve_playlist_once(sess)
        if res is not None:
            return res
        if sess.killed.is_set():
            return None, sess.resolved_base, False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        attempt += 1
        time.sleep(min(0.3 * attempt, 1.5, remaining))
    with sess.lock:
        age = time.time() - sess.last_good_playlist_time
        cached = sess.last_good_playlist_body
        cached_base = sess.last_good_playlist_base or sess.resolved_base
    if cached is not None:
        _log_throttled(
            sess, 'lastgood',
            f'[{sess.token[:8]}] Servindo playlist last-good '
            f'(idade {age:.1f}s{" â€” velha" if age > HLS_LAST_GOOD_MAX_AGE else ""})',
            LOGWARNING
        )
        return cached, cached_base, False
    _log_throttled(
        sess, 'nogood',
        f'[{sess.token[:8]}] Sem nenhuma playlist boa ainda; placeholder',
        LOGERROR
    )
    return None, sess.resolved_base, False

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# RECUPERAÃ‡ÃƒO DE SEGMENTO POR REFERÃŠNCIA
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _extract_filename(url):
    try:
        return urlparse(url).path.rsplit('/', 1)[-1].split('?')[0]
    except Exception:
        return ''

def _find_segment_in_manifest(filename, manifest_text, final_url):
    if not filename or not manifest_text:
        return None
    for line in manifest_text.splitlines():
        cand = line.strip()
        if not cand or cand.startswith('#'):
            continue
        try:
            absolute = urljoin(final_url, cand)
            if _extract_filename(absolute) == filename:
                return absolute
        except Exception:
            pass
    return None

def _retoken_segment(old_url, manifest_text, final_url):
    sample = None
    for line in manifest_text.splitlines():
        cand = line.strip()
        if cand and not cand.startswith('#'):
            sample = urljoin(final_url, cand)
            break
    if not sample:
        return None
    sp = urlparse(sample)
    op = urlparse(old_url)
    if not sp.query:
        return None
    return urlunparse((sp.scheme, sp.netloc, op.path, op.params, sp.query, ''))

def _resolve_seg_via_ref(sess, seg_url):
    filename = _extract_filename(seg_url)
    if not filename:
        return None
    r = _fresh_resolve(sess, HLS_FRESH_REUSE_SECONDS)
    if r is None:
        with sess.lock:
            manifest = sess.last_good_playlist_body
            final_url = sess.last_good_playlist_base or sess.resolved_base
        if manifest is None:
            return None
    else:
        manifest, final_url = r
    return (_find_segment_in_manifest(filename, manifest, final_url)
            or _retoken_segment(seg_url, manifest, final_url))

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# MEDIA
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _diag_segment(sess, url, size, ct):
    if sess.diag_segments >= HLS_DIAG_SEGMENTS:
        return
    sess.diag_segments += 1
    _log(
        f'[{sess.token[:8]}] Segmento #{sess.diag_segments} '
        f'{_extract_filename(url)[:40]}: {size}B ct={ct}',
        LOGINFO
    )

def _resolve_media(sess, absolute_url, cache_key, range_header=None,
                   kind='seg'):
    fallback = HLS_FILLER_TS if kind != 'key' else (b'\x00' * 16)
    if sess.killed.is_set():
        return fallback, None
    t_end = time.monotonic() + HLS_SEGMENT_TOTAL_BUDGET
    result = _fetch_with_retry(
        absolute_url, sess.entry_parsed,
        HLS_SEGMENT_MAX_RETRIES,
        timeout=HLS_READ_TIMEOUT,
        fast_backoff=True,
        max_total_time=HLS_SEGMENT_MAX_OPERATION_TIME + 5,
        op_time=HLS_SEGMENT_MAX_OPERATION_TIME,
        no_retry_4xx=True
    )
    if sess.killed.is_set():
        return fallback, None
    if _media_ok(result):
        sess.cache_segment(cache_key, result.body)
        ct = (result.headers or {}).get('content-type')
        _diag_segment(sess, absolute_url, len(result.body), ct)
        return result.body, ct
    if (result is not None and result.error is None and result.body
            and _is_bad_media_body(result.body)):
        _log(
            f'[{sess.token[:8]}] Segmento invÃ¡lido (texto no lugar de vÃ­deo): '
            f'{_describe(result)} first={result.body[:32]!r}',
            LOGWARNING
        )
    else:
        _log(
            f'[{sess.token[:8]}] Segmento falhou: {_describe(result)}',
            LOGWARNING
        )
    if t_end - time.monotonic() > 2.0 and not sess.killed.is_set():
        recovered_url = _resolve_seg_via_ref(sess, absolute_url)
        remaining = t_end - time.monotonic()
        if recovered_url and recovered_url != absolute_url and remaining > 1.0:
            recovered = _fetch_with_retry(
                recovered_url, sess.entry_parsed,
                HLS_SEGMENT_MAX_RETRIES,
                timeout=HLS_READ_TIMEOUT,
                fast_backoff=True,
                max_total_time=remaining,
                op_time=min(HLS_SEGMENT_MAX_OPERATION_TIME, remaining),
                no_retry_4xx=True
            )
            if _media_ok(recovered):
                _log(
                    f'[{sess.token[:8]}] Segmento recuperado via REF',
                    LOGINFO
                )
                sess.cache_segment(cache_key, recovered.body)
                return recovered.body, (recovered.headers or {}).get('content-type')
            _log(
                f'[{sess.token[:8]}] REF nÃ£o recuperou: {_describe(recovered)}',
                LOGWARNING
            )
    cached = sess.get_cached_segment(cache_key)
    if cached is not None:
        body, ts = cached
        _log(
            f'[{sess.token[:8]}] Servindo segmento last-good '
            f'(idade {time.time()-ts:.1f}s)',
            LOGWARNING
        )
        return body, None
    _log(
        f'[{sess.token[:8]}] Sem last-good; servindo filler',
        LOGERROR
    )
    return fallback, ('video/mp2t' if kind != 'key' else None)

def _seg_content_type(ct):
    if ct:
        low = ct.lower()
        if low.startswith('video/') or low.startswith('audio/'):
            return ct
    return 'video/mp2t'

_RE_RANGE = re.compile(
    r'^\s*bytes\s*=\s*(\d*)\s*-\s*(\d*)\s*(?:,.*)?$', re.IGNORECASE
)

def _apply_range(body, range_header):
    extra = {'Accept-Ranges': 'bytes'}
    if not range_header:
        return 200, body, extra
    m = _RE_RANGE.match(range_header)
    if not m:
        return 200, body, extra
    total = len(body)
    s, e = m.group(1), m.group(2)
    if s == '' and e == '':
        return 200, body, extra
    if s == '':
        n = int(e)
        if n <= 0:
            return 200, body, extra
        start = max(0, total - n)
        end = total - 1
    else:
        start = int(s)
        end = int(e) if e != '' else total - 1
        end = min(end, total - 1)
    if start >= total or start > end:
        return 200, body, extra
    if start == 0 and end == total - 1:
        return 200, body, extra
    extra['Content-Range'] = f'bytes {start}-{end}/{total}'
    return 206, body[start:end + 1], extra

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# v1.5.6 â€” PREFETCH E RENOVAÃ‡ÃƒO PROATIVA
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _prefetch_bg(sess, absolute_url, cache_key):
    """Baixa em background e cacheia. Dedup por cache_key. Ignora erros."""
    if sess.killed.is_set():
        return
    if sess.get_cached_segment(cache_key) is not None:
        return
    if not sess.mark_prefetch(cache_key):
        return

    def _run():
        acquired = False
        try:
            if not _PREFETCH_SEM.acquire(timeout=1.0):
                return
            acquired = True
            if sess.killed.is_set():
                return
            # Pequeno delay: se o player pedir em seguida, ele pega o slot.
            time.sleep(0.15)
            if sess.get_cached_segment(cache_key) is not None:
                return
            result = _fetch_with_retry(
                absolute_url, sess.entry_parsed,
                HLS_SEGMENT_MAX_RETRIES,
                timeout=HLS_READ_TIMEOUT,
                fast_backoff=True,
                max_total_time=HLS_SEGMENT_MAX_OPERATION_TIME + 5,
                op_time=HLS_SEGMENT_MAX_OPERATION_TIME,
                no_retry_4xx=True
            )
            if _media_ok(result):
                sess.cache_segment(cache_key, result.body)
        except Exception:
            pass
        finally:
            if acquired:
                _PREFETCH_SEM.release()
            sess.clear_prefetch(cache_key)

    threading.Thread(target=_run, daemon=True).start()

def _prefetch_last_segments(sess, text, base_url):
    """Prefetch paralelo dos Ãºltimos HLS_PREFETCH_COUNT segmentos do manifesto
    (do live edge para trÃ¡s). Chave = seq do player."""
    if HLS_PREFETCH_COUNT <= 0 or sess.killed.is_set():
        return
    if _is_master_playlist(text):
        return
    try:
        segs = list(_iter_output_segments(sess, text))
    except Exception:
        return
    if not segs:
        return
    tail = segs[-HLS_PREFETCH_COUNT:]
    for seq, uri in tail:
        try:
            absolute = urljoin(base_url, uri)
            _prefetch_bg(sess, absolute, _seq_cache_key(seq))
        except Exception:
            continue

def _renewal_loop(sess):
    """Renova a base em background a cada TTL*HLS_RENEWAL_RATIO. Evita o
    'token da base expirou' entre polls do cliente."""
    while not sess.killed.is_set():
        with sess.lock:
            ttl = sess.base_ttl
            base = sess.resolved_base
        if base == sess.entry_url or not ttl:
            try:
                time.sleep(3.0)
            except Exception:
                break
            continue
        interval = ttl * HLS_RENEWAL_RATIO
        interval = max(HLS_RENEWAL_MIN_INTERVAL,
                       min(interval, HLS_RENEWAL_MAX_INTERVAL))
        try:
            time.sleep(interval)
        except Exception:
            break
        if sess.killed.is_set():
            break
        try:
            _fresh_resolve(sess, min_interval=1.0)
        except Exception:
            pass

def _start_renewal(sess):
    with sess.lock:
        if sess.renewal_started:
            return
        sess.renewal_started = True
    t = threading.Thread(
        target=_renewal_loop, args=(sess,),
        name=f'HLSRenew-{sess.token[:6]}',
        daemon=True
    )
    t.start()

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# HTTP SERVER
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
class _ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = HLS_ACCEPT_QUEUE

    def process_request(self, request, client_address):
        sem = _SERVER_SEMAPHORE
        if sem is None:
            return super().process_request(request, client_address)
        if not sem.acquire(timeout=HLS_WORKER_WAIT):
            _log('Sem worker livre; conexÃ£o descartada', LOGWARNING)
            try:
                self.shutdown_request(request)
            except Exception:
                pass
            return
        try:
            t = threading.Thread(
                target=self._run_limited_request,
                args=(request, client_address, sem),
                daemon=True
            )
            t.start()
        except Exception:
            sem.release()
            raise

    def _run_limited_request(self, request, client_address, sem):
        try:
            self.process_request_thread(request, client_address)
        finally:
            sem.release()

class _Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    timeout = 180

    def log_message(self, fmt, *args):
        pass

    def setup(self):
        super().setup()
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP,
                                       socket.TCP_NODELAY, 1)
            self.connection.setsockopt(socket.SOL_SOCKET,
                                       socket.SO_SNDBUF, 65536)
        except Exception:
            pass

    def _write_ok(self, body, content_type, status=200, extra=None):
        try:
            use_chunked = len(body) > 256 * 1024
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            if use_chunked:
                self.send_header('Transfer-Encoding', 'chunked')
            else:
                self.send_header('Content-Length', str(len(body)))
            self.send_header('Connection', 'close')
            self.send_header('Access-Control-Allow-Origin', '*')
            if extra:
                for k, v in extra.items():
                    self.send_header(k, v)
            self.end_headers()
            if use_chunked:
                off = 0
                total = len(body)
                while off < total:
                    piece = body[off:off + HLS_CHUNK_SIZE]
                    self.wfile.write(f'{len(piece):x}\r\n'.encode('ascii'))
                    self.wfile.write(piece)
                    self.wfile.write(b'\r\n')
                    off += len(piece)
                self.wfile.write(b'0\r\n\r\n')
            else:
                self.wfile.write(body)
            try:
                self.wfile.flush()
            except Exception:
                pass
        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            pass
        except Exception as e:
            _log(f'Erro escrevendo resposta: {e}', LOGERROR)

    def _never_fail_empty_playlist(self, sess=None):
        seq = 0
        if sess is not None:
            with sess.lock:
                seq = sess.last_exposed_end
        body = (
            '#EXTM3U\n'
            '#EXT-X-VERSION:3\n'
            '#EXT-X-TARGETDURATION:5\n'
            f'#EXT-X-MEDIA-SEQUENCE:{seq}\n'
        ).encode('utf-8')
        self._write_ok(body, 'application/vnd.apple.mpegurl',
                       extra={'Cache-Control': 'no-cache'})

    def _write_ended_playlist(self):
        body = (
            '#EXTM3U\n'
            '#EXT-X-VERSION:3\n'
            '#EXT-X-TARGETDURATION:5\n'
            '#EXT-X-MEDIA-SEQUENCE:0\n'
            '#EXT-X-ENDLIST\n'
        ).encode('utf-8')
        self._write_ok(body, 'application/vnd.apple.mpegurl',
                       extra={'Cache-Control': 'no-cache'})

    def _write_neutral(self, kind, sess=None):
        if kind == 'seg':
            self._write_ok(HLS_FILLER_TS, 'video/mp2t')
        elif kind == 'key':
            self._write_ok(b'\x00' * 16, 'application/octet-stream')
        elif kind in ('playlist', 'variant'):
            self._never_fail_empty_playlist(sess)
        else:
            self._write_ok(b'', 'text/plain')

    def _open_upstream_with_redirects(self, sess, absolute_url, op_deadline):
        current_url = absolute_url
        last_status = None
        for hop in range(HLS_MAX_REDIRECTS + 1):
            if time.monotonic() > op_deadline:
                return None, current_url
            if sess.killed.is_set():
                return None, current_url
            parsed = urlparse(current_url)
            if not parsed.scheme or not parsed.hostname:
                return None, current_url
            hop_headers = _build_headers(
                parsed, sess.entry_parsed, sess.profile_idx
            )
            resp = None
            try:
                resp = _get_http().get(
                    current_url, headers=hop_headers,
                    timeout=(HLS_CONNECT_TIMEOUT, HLS_READ_TIMEOUT),
                    stream=True, allow_redirects=False
                )
            except requests.exceptions.ConnectionError as e:
                if _is_stale_conn_error(e):
                    _reset_http_pool()
                    try:
                        resp = _get_http().get(
                            current_url, headers=hop_headers,
                            timeout=(HLS_CONNECT_TIMEOUT, HLS_READ_TIMEOUT),
                            stream=True, allow_redirects=False
                        )
                    except Exception:
                        return None, current_url
                else:
                    return None, current_url
            except Exception:
                return None, current_url
            status = resp.status_code
            last_status = status
            if status in _REDIRECT_CODES:
                location = resp.headers.get('Location')
                try:
                    resp.close()
                except Exception:
                    pass
                if not location:
                    return None, current_url
                new_url = urljoin(current_url, location)
                if new_url == current_url:
                    return None, current_url
                current_url = new_url
                continue
            return resp, current_url
        return None, current_url

    def _serve_from_cache(self, body):
        """Entrega cache hit instantÃ¢neo. Retorna True em sucesso."""
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Connection', 'close')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            off = 0
            total = len(body)
            while off < total:
                self.wfile.write(body[off:off + HLS_STREAM_CHUNK])
                off += HLS_STREAM_CHUNK
            try:
                self.wfile.flush()
            except Exception:
                pass
            return True
        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            return True
        except Exception:
            return False

    def _stream_segment(self, sess, absolute_url, cache_key):
        if sess.killed.is_set():
            return False

        # v1.5.6: cache hit instantÃ¢neo
        cached = sess.get_cached_segment(cache_key)
        if cached is not None:
            body, ts = cached
            age = time.time() - ts
            _log(
                f'[{sess.token[:8]}] Cache HIT {_extract_filename(absolute_url)[:40]} '
                f'({len(body)}B, {age:.1f}s)',
                LOGDEBUG
            )
            if self._serve_from_cache(body):
                return True

        t_start = time.monotonic()
        op_deadline = t_start + HLS_SEGMENT_MAX_OPERATION_TIME
        headers_sent = False
        _TLS.doh = True
        resp = None

        try:
            resp, final_url = self._open_upstream_with_redirects(
                sess, absolute_url, op_deadline
            )
            if resp is None:
                return False
            status = resp.status_code
            if status >= 400:
                _log(f'[{sess.token[:8]}] Stream: HTTP {status} em '
                     f'{urlparse(final_url).hostname}', LOGWARNING)
                return False
            ct = (resp.headers.get('Content-Type') or '').lower()
            if 'html' in ct or 'json' in ct or 'mpegurl' in ct:
                _log(f'[{sess.token[:8]}] Stream: content-type ruim {ct}',
                     LOGWARNING)
                return False

            try:
                self.send_response(200)
                self.send_header('Content-Type', _seg_content_type(ct or None))
                self.send_header('Transfer-Encoding', 'chunked')
                self.send_header('Connection', 'close')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                try:
                    self.wfile.flush()
                except Exception:
                    pass
                headers_sent = True
            except Exception as e:
                _log(f'[{sess.token[:8]}] Stream: headers: '
                     f'{type(e).__name__}: {e}', LOGWARNING)
                return False

            total = 0
            cache_buf = bytearray()
            cache_limit = 4 * 1024 * 1024
            completed = True
            first_chunk = True
            write_since_flush = 0

            def _emit(data):
                nonlocal write_since_flush
                self.wfile.write(f'{len(data):x}\r\n'.encode('ascii'))
                self.wfile.write(data)
                self.wfile.write(b'\r\n')
                write_since_flush += len(data)
                if write_since_flush >= 128 * 1024:
                    try:
                        self.wfile.flush()
                    except Exception:
                        pass
                    write_since_flush = 0

            try:
                for chunk in resp.iter_content(chunk_size=HLS_STREAM_CHUNK):
                    if not chunk:
                        continue
                    if time.monotonic() > op_deadline:
                        completed = False
                        _log(f'[{sess.token[:8]}] Stream: deadline apÃ³s '
                             f'{total}B', LOGWARNING)
                        break
                    if first_chunk:
                        first_chunk = False
                        if _is_bad_media_body(chunk):
                            completed = False
                            _log(f'[{sess.token[:8]}] Stream: 1Âº chunk '
                                 f'invÃ¡lido first={chunk[:32]!r}',
                                 LOGWARNING)
                            break
                    _emit(chunk)
                    total += len(chunk)
                    if len(cache_buf) < cache_limit:
                        take = min(len(chunk), cache_limit - len(cache_buf))
                        cache_buf.extend(chunk[:take])
            except (BrokenPipeError, ConnectionResetError, socket.timeout) as e:
                completed = False
                _log(f'[{sess.token[:8]}] Stream interrompido: {e}',
                     LOGDEBUG)
            except Exception as e:
                completed = False
                _log(f'[{sess.token[:8]}] Stream erro corpo: '
                     f'{type(e).__name__}: {e}', LOGWARNING)

            try:
                self.wfile.write(b'0\r\n\r\n')
                self.wfile.flush()
            except Exception:
                pass

            elapsed = time.monotonic() - t_start
            if total > 0 and completed:
                # v1.5.7: sÃ³ cacheia se o buffer capturou o corpo INTEIRO.
                # Antes: cl is None (chunked) â†’ is_complete=True mesmo com
                # cache_buf truncado em 4 MB â†’ HIT com TS incompleto.
                try:
                    cl = resp.headers.get('Content-Length')
                    cl_ok = (cl is None or int(cl) == total)
                except Exception:
                    cl_ok = False
                body_full = (len(cache_buf) == total)
                if cl_ok and body_full and total > 0:
                    sess.cache_segment(cache_key, bytes(cache_buf))
                    _log(
                        f'[{sess.token[:8]}] Segmento '
                        f'{_extract_filename(absolute_url)[:40]}: '
                        f'{total}B em {elapsed:.1f}s (cacheado)',
                        LOGINFO
                    )
                else:
                    why = (
                        'buffer truncado'
                        if not body_full else
                        'Content-Length divergente / incompleto'
                    )
                    _log(
                        f'[{sess.token[:8]}] Segmento '
                        f'{_extract_filename(absolute_url)[:40]}: '
                        f'{total}B em {elapsed:.1f}s (nÃ£o cacheado: {why})',
                        LOGWARNING
                    )
            elif not headers_sent:
                return False
            return True
        except Exception as e:
            if headers_sent:
                return True
            _log(f'[{sess.token[:8]}] Stream: {type(e).__name__}: {e}',
                 LOGWARNING)
            return False
        finally:
            _TLS.doh = False
            if resp is not None:
                try:
                    resp.close()
                except Exception:
                    pass

    def do_HEAD(self):
        try:
            parts = [p for p in urlparse(self.path).path.split('/') if p]
            kind = parts[1] if len(parts) >= 3 and parts[0] == 'hls' else ''
            if kind in ('playlist', 'variant'):
                ct = 'application/vnd.apple.mpegurl'
            elif kind == 'key':
                ct = 'application/octet-stream'
            elif kind == 'seg':
                ct = 'video/mp2t'
            else:
                ct = 'text/plain'
            self.send_response(200)
            self.send_header('Content-Type', ct)
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Connection', 'close')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
        except Exception:
            pass

    def do_GET(self):
        kind = ''
        sess = None
        try:
            parsed = urlparse(self.path)
            parts = [p for p in parsed.path.split('/') if p]
            if len(parts) < 3 or parts[0] != 'hls':
                self._write_neutral('')
                return
            kind = parts[1]
            token = parts[2]

            if kind == 'playlist':
                with _SESSIONS_LOCK:
                    sess = _SESSIONS.get(token)
                active = False
                if sess is not None:
                    with _ACTIVE_TOKEN_LOCK:
                        active = token == _ACTIVE_TOKEN
                if sess is None or sess.killed.is_set() or not active:
                    self._write_ended_playlist()
                    return
                sess.touch()
                text, base, discontinuity = _resolve_playlist(sess)
                if text is None:
                    self._never_fail_empty_playlist(sess)
                    return
                is_master = _is_master_playlist(text)
                if is_master:
                    seq_off, skip, marks = 0, 0, ()
                else:
                    seq_off, skip, marks = _playlist_view(sess, text)
                rewritten = _rewrite_playlist(
                    text, base, token,
                    insert_discontinuity=(discontinuity and not is_master),
                    seq_offset=seq_off, skip_first=skip, disc_marks=marks
                )
                _diag_playlist(sess, rewritten)
                # Prefetch do live edge (em paralelo)
                if not is_master:
                    try:
                        _prefetch_last_segments(sess, text, base)
                    except Exception:
                        pass
                self._write_ok(
                    rewritten.encode('utf-8'),
                    'application/vnd.apple.mpegurl',
                    extra={'Cache-Control': 'no-cache'}
                )
                return

            if kind in ('seg', 'key', 'variant'):
                if len(parts) < 4:
                    self._write_neutral(kind)
                    return
                with _SESSIONS_LOCK:
                    sess = _SESSIONS.get(token)
                active = False
                if sess is not None:
                    with _ACTIVE_TOKEN_LOCK:
                        active = token == _ACTIVE_TOKEN
                if sess is None or sess.killed.is_set() or not active:
                    if kind == 'variant':
                        self._write_ended_playlist()
                    else:
                        self._write_neutral(kind)
                    return
                sess.touch()

                if kind == 'variant':
                    try:
                        absolute_url = _b64d(parts[3])
                    except ValueError:
                        self._write_neutral(kind, sess)
                        return
                    result = _fetch_with_retry(
                        absolute_url, sess.entry_parsed,
                        HLS_PLAYLIST_MAX_RETRIES,
                        max_total_time=HLS_PLAYLIST_RECOVERY_BUDGET
                    )
                    if _playlist_ok(result):
                        text = result.body.decode('utf-8', errors='replace')
                        base = result.final_url or absolute_url
                        if _is_master_playlist(text):
                            self._write_ok(
                                _rewrite_playlist(
                                    text, base, token
                                ).encode('utf-8'),
                                'application/vnd.apple.mpegurl',
                                extra={'Cache-Control': 'no-cache'}
                            )
                            return
                        seq = _extract_media_sequence(result.body)
                        try:
                            _accept_playlist(
                                sess, text, seq, base,
                                via_fresh=False, update_base=False
                            )
                        except Exception:
                            pass
                        seq_off, skip, marks = _playlist_view(sess, text)
                        rewritten = _rewrite_playlist(
                            text, base, token,
                            seq_offset=seq_off, skip_first=skip,
                            disc_marks=marks
                        )
                        try:
                            _prefetch_last_segments(sess, text, base)
                        except Exception:
                            pass
                        self._write_ok(
                            rewritten.encode('utf-8'),
                            'application/vnd.apple.mpegurl',
                            extra={'Cache-Control': 'no-cache'}
                        )
                    else:
                        _log(
                            f'[{token[:8]}] Variant falhou: '
                            f'{_describe(result)}',
                            LOGWARNING
                        )
                        self._never_fail_empty_playlist(sess)
                    return

                # v1.5.6: segmento com seq no path -> cache por seq
                if kind == 'seg':
                    if len(parts) >= 5:
                        try:
                            seg_seq = int(parts[3])
                        except (ValueError, TypeError):
                            seg_seq = None
                        try:
                            absolute_url = _b64d(parts[4])
                        except ValueError:
                            self._write_neutral(kind, sess)
                            return
                    else:
                        seg_seq = None
                        try:
                            absolute_url = _b64d(parts[3])
                        except ValueError:
                            self._write_neutral(kind, sess)
                            return
                    cache_key = (
                        _seq_cache_key(seg_seq) if seg_seq is not None
                        else 'url:' + absolute_url
                    )
                    if self._stream_segment(sess, absolute_url, cache_key):
                        return
                    body, ct = _resolve_media(
                        sess, absolute_url, cache_key,
                        range_header=self.headers.get('Range'), kind='seg'
                    )
                    if not body:
                        self._write_neutral(kind, sess)
                        return
                    status, out_body, extra = _apply_range(
                        body, self.headers.get('Range')
                    )
                    self._write_ok(out_body, _seg_content_type(ct),
                                   status, extra)
                    return

                # Chave
                if kind == 'key':
                    try:
                        absolute_url = _b64d(parts[3])
                    except ValueError:
                        self._write_neutral(kind, sess)
                        return
                    body, ct = _resolve_media(
                        sess, absolute_url, 'key:' + parts[3],
                        range_header=self.headers.get('Range'), kind='key'
                    )
                    if not body:
                        self._write_neutral(kind, sess)
                        return
                    self._write_ok(body, 'application/octet-stream')
                    return

            self._write_neutral('')

        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            pass
        except Exception as e:
            _log(f'Erro no handler GET: {e}', LOGERROR)
            try:
                self._write_neutral(kind or 'playlist', sess)
            except Exception:
                pass

def _ensure_server_running():
    global _SERVER, _SERVER_PORT, _SERVER_SEMAPHORE
    with _SERVER_LOCK:
        if _SERVER is not None:
            return _SERVER_PORT
        low, high = HLS_PORT_RANGE
        candidates = random.sample(
            range(low, high + 1),
            min(HLS_PORT_BIND_ATTEMPTS, high - low + 1)
        )
        for port in candidates:
            try:
                _SERVER = _ThreadingHTTPServer((HOST_BIND, port), _Handler)
                _SERVER_PORT = port
                break
            except OSError:
                continue
        if _SERVER is None:
            raise RuntimeError(
                'NÃ£o foi possÃ­vel abrir porta local para hlsproxy'
            )
        _SERVER_SEMAPHORE = threading.BoundedSemaphore(HLS_MAX_LOCAL_WORKERS)
        t = threading.Thread(
            target=_SERVER.serve_forever,
            kwargs={'poll_interval': 0.25},
            daemon=True
        )
        t.start()
        gc_t = threading.Thread(
            target=_gc_loop, name='HLSProxy-GC', daemon=True
        )
        gc_t.start()
        _log(
            f'Servidor HLS iniciado em {HOST_BIND}:{_SERVER_PORT} '
            f'(workers={HLS_MAX_LOCAL_WORKERS}, chunk={HLS_CHUNK_SIZE // 1024}K, '
            f'stream=chunked, redirect=manual, prefetch={HLS_PREFETCH_COUNT}, '
            f'seq-cache=on, renewal=on)',
            LOGINFO
        )
        return _SERVER_PORT

def _gc_loop():
    while True:
        time.sleep(120)
        try:
            _gc_sessions()
        except Exception:
            pass

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# API PÃšBLICA
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
class HLSAddon:
    def __init__(self, addon_handle):
        self.handle = addon_handle

    def play_stream(self, url, stream_type=None):
        import xbmcplugin
        import xbmcgui
        import xbmc

        port = _ensure_server_running()
        token = _b64e(f'{os.urandom(12).hex()}|{time.time_ns()}')[:16]
        entry_b64 = _b64e(url)
        sess = _set_active_channel(token, url)
        _doh_prewarm(url)

        def _pre():
            try:
                _fresh_resolve(sess, min_interval=0.0)
            except Exception:
                pass
        threading.Thread(target=_pre, daemon=True).start()
        _start_renewal(sess)

        local_url = (
            f'http://127.0.0.1:{port}/hls/playlist/'
            f'{token}/{entry_b64}'
        )
        _log(f'Play <- local: {local_url}', xbmc.LOGINFO)

        li = xbmcgui.ListItem(path=local_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        try:
            li.setMimeType('application/x-mpegURL')
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(self.handle, True, li)