# -*- coding: utf-8 -*-
import os
import time
import calendar
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
import html
import bisect

def parse_xmltv_time(ts):
    if not ts:
        return int(time.time())
    ts = ts.strip()
    if len(ts) < 14 or not ts[:14].isdigit():
        return int(time.time())
    base = ts[:14]
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except Exception:
        return int(time.time())
    
    offset_secs = 0
    rest = ts[14:].strip()
    if rest:
        rest = rest.replace(' ', '')
        if rest.startswith(('+', '-')) and len(rest) >= 5:
            try:
                sign = 1 if rest[0] == '+' else -1
                hh = int(rest[1:3])
                mm = int(rest[3:5])
                offset_secs = sign * (hh * 3600 + mm * 60)
            except Exception:
                offset_secs = 0

    # Ajusta para o fuso horário local
    tz_local = datetime.now().astimezone().tzinfo
    dt_local = dt.replace(tzinfo=timezone(timedelta(seconds=offset_secs))).astimezone(tz_local)
    
    epoch = dt_local.timestamp()
    return int(epoch) if epoch > 0 else int(time.time())

def normalize_epg_channel_id(cid):
    if not cid:
        return ''
    # remove espaços, minúscula, e converte entidades HTML
    return html.unescape(cid.strip().lower())

def load_epg(epg_xml_path):
    """
    Parse EPG XML usando iterparse para processamento em chunks/blocos.
    Processa o XML incrementalmente, limpando cada elemento após processamento
    para minimizar o uso de memória. Muito mais rápido que ET.parse() para
    arquivos XMLTV grandes.
    """
    if not os.path.exists(epg_xml_path):
        return {'channels': {}, 'progs': {}, '_starts': {}}

    channels = {}
    progs = {}

    try:
        # iterparse processa o XML em chunks, lendo incrementalmente do disco
        # Isso evita carregar toda a árvore XML na memória de uma vez
        context = ET.iterparse(epg_xml_path, events=('start', 'end'))

        for event, elem in context:
            if event == 'end':
                if elem.tag == 'channel':
                    cid = normalize_epg_channel_id(elem.get('id'))
                    dn = html.unescape((elem.findtext('display-name') or '').strip())
                    if cid:
                        channels[cid] = dn
                    # Limpa o elemento para liberar memória imediatamente
                    elem.clear()

                elif elem.tag == 'programme':
                    cid = normalize_epg_channel_id(elem.get('channel'))

                    # Prioriza os atributos start_timestamp e stop_timestamp se existirem
                    start_timestamp_str = elem.get('start_timestamp')
                    stop_timestamp_str = elem.get('stop_timestamp')

                    if start_timestamp_str and stop_timestamp_str:
                        try:
                            start = int(start_timestamp_str)
                            stop = int(stop_timestamp_str)
                        except (ValueError, TypeError):
                            start = parse_xmltv_time(elem.get('start'))
                            stop = parse_xmltv_time(elem.get('stop') or elem.get('end'))
                    else:
                        start = parse_xmltv_time(elem.get('start'))
                        stop = parse_xmltv_time(elem.get('stop') or elem.get('end'))

                    if stop <= start:
                        stop = start + 3600

                    title = html.unescape((elem.findtext('title') or '').strip())
                    desc = html.unescape((elem.findtext('desc') or '').strip())

                    if cid not in progs:
                        progs[cid] = []
                    progs[cid].append({'start': start, 'end': stop, 'title': title, 'desc': desc})

                    # Limpa o elemento para liberar memória imediatamente
                    elem.clear()

        # Limpa referências restantes do iterparse
        del context

        # Ordena programas por start e constrói índice para busca binária
        starts_index = {}
        for cid, arr in progs.items():
            arr.sort(key=lambda x: x['start'])
            starts_index[cid] = [p['start'] for p in arr]

        return {'channels': channels, 'progs': progs, '_starts': starts_index}
    except Exception:
        return {'channels': {}, 'progs': {}, '_starts': {}}

def epg_lookup_current_next(epg_channel_id, epg):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())
    plist = epg['progs'].get(cid, [])

    if not plist:
        return None, None

    starts = epg.get('_starts', {}).get(cid)

    if starts:
        # Busca binária: encontra o programa mais à direita cujo start <= now
        # O(log n) em vez de O(n) da busca linear
        idx = bisect.bisect_right(starts, now) - 1

        current = None
        nextp = None

        # Verifica se o programa em idx está em andamento agora
        if idx >= 0:
            candidate = plist[idx]
            start = candidate.get('start') or now
            end = candidate.get('end') or (start + 3600)
            if end <= start:
                end = start + 3600
            candidate['start'] = start
            candidate['end'] = end
            if start <= now < end:
                current = candidate
                if idx + 1 < len(plist):
                    nextp = plist[idx + 1]
                    ns = nextp.get('start') or now
                    ne = nextp.get('end') or (ns + 3600)
                    if ne <= ns:
                        ne = ns + 3600
                    nextp['start'] = ns
                    nextp['end'] = ne
                return current, nextp

        # Nenhum programa atual em idx, verifica o próximo
        check_idx = idx + 1 if idx >= 0 else 0
        if check_idx < len(plist):
            nextp = plist[check_idx]
            ns = nextp.get('start') or now
            ne = nextp.get('end') or (ns + 3600)
            if ne <= ns:
                ne = ns + 3600
            nextp['start'] = ns
            nextp['end'] = ne

        # Verifica se o programa anterior ainda está em andamento (sobreposição)
        if idx >= 0:
            candidate = plist[idx]
            start = candidate.get('start') or now
            end = candidate.get('end') or (start + 3600)
            if end <= start:
                end = start + 3600
            candidate['start'] = start
            candidate['end'] = end
            if end > now:
                current = candidate

        return current, nextp
    else:
        # Fallback: busca linear (compatibilidade retroativa)
        current, nextp = None, None
        for i, pr in enumerate(plist):
            start = pr.get('start') or now
            end = pr.get('end') or (start + 3600)
            if end <= start:
                end = start + 3600
            pr['start'] = start
            pr['end'] = end
            if start <= now < end:
                current = pr
                if i + 1 < len(plist):
                    nextp = plist[i + 1]
                break
            if start > now:
                nextp = pr
                if i - 1 >= 0 and plist[i-1]['end'] > now:
                    current = plist[i-1]
                break
        return current, nextp