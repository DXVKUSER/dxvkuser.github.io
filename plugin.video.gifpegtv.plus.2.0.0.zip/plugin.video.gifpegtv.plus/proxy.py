

# Proxy HLS Otimizado e Invisível para Kodi com Suporte a DoH
# Versão: 3.4 (Correção de Erros)

"""
Melhorias implementadas:
- Integração com script.module.netunblock para evitar bloqueios de DNS
- Rotação avançada de User-Agents com perfis realistas
- Geração mais realista de X-Forwarded-For
- Adição de cabeçalhos para simular navegadores reais
- Implementação de delays aleatórios entre requisições
- Throttling de requisições para evitar detecção por padrões
- Simulação de comportamento de player legítimo
- Suporte para cookies e sessões persistentes
- Randomização de timeouts para evitar padrões
- Correção de erros de importação e avisos de segurança
- Correção do AttributeError no objeto M3U8
"""

import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
from collections import OrderedDict
from typing import Optional, Dict, List
import hashlib
import hmac
import warnings

import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import requests
import m3u8
from werkzeug.serving import make_server
from flask import Flask, request, Response
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- Configurações Globais ---
PROXY_HOST = "127.0.0.1"
MAX_PORT_ATTEMPTS = 20
MAX_CACHE_MB = 128  # Aumentado para acomodar o prefetch
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024

# --- Constantes de Otimização ---
PREFETCH_SEGMENTS = 3       # Número de segmentos a baixar adiantado
MANIFEST_FETCH_ATTEMPTS = 3
MANIFEST_FETCH_DELAY = 0.5
DEFAULT_MANIFEST_TTL = 5
VOD_MANIFEST_TTL = 3600
SEGMENT_TTL_FACTOR = 10
MANIFEST_TIMEOUT = 10       # (segundos) Timeout para buscar manifestos
SEGMENT_TIMEOUT = 25        # (segundos) Timeout maior para buscar segmentos

# Configurações de Invisibilidade
MIN_REQUEST_DELAY = 0.2     # Delay mínimo entre requisições (segundos)
MAX_REQUEST_DELAY = 1.5     # Delay máximo entre requisições (segundos)
REQUEST_JITTER_FACTOR = 0.3 # Fator de aleatoriedade para delays
CONCURRENT_REQUEST_LIMIT = 4 # Limite de requisições concorrentes

# --- User-Agents Avançados ---
USER_AGENTS = [
    # Chrome/Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
    # Firefox/Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:119.0) Gecko/20100101 Firefox/119.0",
    # Edge/Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
    # Safari/Mac
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
    # Chrome/Android
    "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    # Kodi
    "Kodi/20.1 (Windows NT 10.0; Win64; x64)",
    "Kodi/20.1 (Linux; Android 12; AFTGM)",
    # VLC
    "VLC/3.0.20 LibVLC/3.0.20",
    "VLC/3.0.18 LibVLC/3.0.18",
]

# Lista de aceitáveis para simular navegadores reais
ACCEPT_HEADERS = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "application/json, text/plain, */*",
    "application/xml, text/xml, */*",
    "*/*"
]

# Lista de linguagens de aceitação
ACCEPT_LANGUAGES = [
    "en-US,en;q=0.9",
    "en-GB,en;q=0.9",
    "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "es-ES,es;q=0.9",
    "fr-FR,fr;q=0.9",
    "de-DE,de;q=0.9",
]

# Lista de encodings de aceitação
ACCEPT_ENCODINGS = [
    "gzip, deflate, br",
    "gzip, deflate",
    "deflate, gzip",
]

LOG_FILE = xbmcvfs.translatePath("special://temp/hlsproxy_invisible.log")

# --- Controle de requisições para evitar detecção ---
request_semaphore = threading.Semaphore(CONCURRENT_REQUEST_LIMIT)
last_request_time = 0
request_lock = threading.Lock()

# --- Suprimir avisos de segurança ---
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# --- Tentativa de importar o script.module.netunblock ---
USE_DOH = False
try:
    # Tenta importar o módulo doh_client do script.module.netunblock
    from doh_client import requests as doh_requests
    USE_DOH = True
    logging.info("Módulo DoH (script.module.netunblock) encontrado e ativado")
except ImportError:
    doh_requests = None
    logging.warning("Módulo DoH (script.module.netunblock) não encontrado. Usando DNS padrão.")
except Exception as e:
    doh_requests = None
    logging.error(f"Erro ao importar módulo DoH: {e}. Usando DNS padrão.")

# --- Funções Utilitárias ---

def setup_logging():
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=2, encoding="utf-8")
    logging.basicConfig(handlers=[handler], level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s", force=True)

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")): return "application/vnd.apple.mpegurl"
    if path.endswith(".ts"): return "video/mp2t"
    if path.endswith(".aac"): return "audio/aac"
    if path.endswith(".mp4"): return "video/mp4"
    return "application/octet-stream"

def generate_realistic_ip() -> str:
    """Gera um IP realista baseado em faixas comuns"""
    # Faixas de IP comuns (evitando IPs privados e reservados)
    first_octets = [
        "24", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", 
        "96", "97", "98", "99", "100", "101", "104", "107", "108", "172", "173", "174", 
        "184", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209"
    ]
    
    first = random.choice(first_octets)
    second = str(random.randint(0, 255))
    third = str(random.randint(0, 255))
    fourth = str(random.randint(1, 254))  # Evita 0 e 255
    
    return f"{first}.{second}.{third}.{fourth}"

def get_random_delay() -> float:
    """Gera um delay aleatório entre requisições para evitar padrões"""
    base_delay = random.uniform(MIN_REQUEST_DELAY, MAX_REQUEST_DELAY)
    jitter = base_delay * REQUEST_JITTER_FACTOR * random.uniform(-1, 1)
    return max(0.1, base_delay + jitter)  # Garante um mínimo de 0.1s

def apply_request_delay():
    """Aplica um delay aleatório entre requisições para evitar detecção por padrão"""
    global last_request_time, request_lock
    
    with request_lock:
        current_time = time.time()
        elapsed = current_time - last_request_time
        
        if last_request_time > 0 and elapsed < MIN_REQUEST_DELAY:
            delay = MIN_REQUEST_DELAY - elapsed
            time.sleep(delay)
        
        # Adiciona um jitter adicional
        additional_delay = random.uniform(0, MAX_REQUEST_DELAY * REQUEST_JITTER_FACTOR)
        time.sleep(additional_delay)
        
        last_request_time = time.time()

def get_headers(url: str, extra: Optional[Dict[str, str]]=None) -> Dict[str, str]:
    """Gera cabeçalhos realistas para simular um navegador legítimo"""
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    
    # Escolhe um user-agent aleatório
    user_agent = random.choice(USER_AGENTS)
    
    # Cria um fingerprint baseado no user-agent para consistência
    ua_fingerprint = hashlib.md5(user_agent.encode()).hexdigest()[:8]
    
    headers = {
        "User-Agent": user_agent,
        "Accept": random.choice(ACCEPT_HEADERS),
        "Accept-Language": random.choice(ACCEPT_LANGUAGES),
        "Accept-Encoding": random.choice(ACCEPT_ENCODINGS),
        "Referer": origin,
        "Origin": origin,
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Upgrade-Insecure-Requests": "1",
        "X-Forwarded-For": generate_realistic_ip(),
        # Adiciona um identificador único mas consistente para a sessão
        "X-Request-ID": f"{ua_fingerprint}-{int(time.time())}"
    }
    
    # Adiciona cabeçalhos específicos para alguns browsers
    if "Chrome" in user_agent:
        headers["Sec-Ch-Ua"] = '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"'
        headers["Sec-Ch-Ua-Mobile"] = "?0"
        headers["Sec-Ch-Ua-Platform"] = '"Windows"'
    
    # Adiciona cabeçalhos extras se fornecidos (como Authorization e Cookie)
    if extra:
        for key in ["Authorization", "Cookie", "X-Custom-Header"]:
            if key in extra: 
                headers[key] = extra[key]
    
    return headers

# --- Classes Principais ---

class RotatingCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.store: OrderedDict[str, tuple] = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            item = self.store.get(url)
            if not item: return None
            data, expire_time = item
            if expire_time and expire_time < time.time():
                self._pop(url)
                return None
            self.store.move_to_end(url)
            return data

    def add(self, url: str, data: bytes, ttl: int):
        with self.lock:
            if url in self.store: self._pop(url)
            size = len(data)
            if size > self.max_bytes: return
            while self.total_bytes + size > self.max_bytes:
                self._popitem(last=False)
            expire = time.time() + ttl if ttl else None
            self.store[url] = (data, expire)
            self.total_bytes += size

    def _pop(self, url: str):
        if url in self.store:
            data, _ = self.store.pop(url)
            self.total_bytes -= len(data)

    def _popitem(self, last: bool):
        try:
            _, (data, _) = self.store.popitem(last=last)
            self.total_bytes -= len(data)
        except KeyError: pass
        
class SegmentPrefetcher(threading.Thread):
    """Thread dedicada a baixar os próximos segmentos de uma stream HLS."""
    def __init__(self, m3u8_obj: m3u8.M3U8, manifest_url: str, proxy_manager):
        super().__init__(name=f"Prefetcher-{random.randint(100, 999)}", daemon=True)
        self.m3u8_obj = m3u8_obj
        self.manifest_url = manifest_url  # Armazena a URL do manifesto explicitamente
        self.manager = proxy_manager
        self._stop_event = threading.Event()

    def stop(self):
        """Sinaliza para a thread parar a execução."""
        self._stop_event.set()
        logging.info(f"Sinal de parada enviado para {self.name}")

    def run(self):
        """Lógica principal de prefetching."""
        logging.info(f"{self.name} iniciado para {self.manifest_url}")
        try:
            # Pega os URIs dos últimos N segmentos para fazer prefetch
            segments_to_fetch = [seg for seg in self.m3u8_obj.segments if seg.uri][-PREFETCH_SEGMENTS:]

            for segment in segments_to_fetch:
                if self._stop_event.is_set():
                    logging.info(f"{self.name} parando devido a sinalização.")
                    break
                
                url = segment.absolute_uri
                if not self.manager.cache.get(url):
                    logging.info(f"[{self.name}] Prefetching: {url.split('/')[-1]}")
                    self.manager.fetch_and_cache_segment(url)
                    
                    # Adiciona um delay entre os downloads de segmentos
                    time.sleep(get_random_delay())
                else:
                    logging.info(f"[{self.name}] Segmento já em cache, pulando: {url.split('/')[-1]}")
        except Exception as e:
            logging.error(f"Erro no {self.name}: {e}")
        finally:
            logging.info(f"{self.name} finalizado.")

class HLSProxyManager:
    """Gerencia o ciclo de vida do servidor proxy Flask e o tratamento de requisições."""
    def __init__(self):
        self.cache = RotatingCache()
        self.session = self._create_session()
        self.app = self._create_flask_app()
        self.server = None
        self.server_thread = None
        self.active_port = None
        self.active_prefetcher: Optional[SegmentPrefetcher] = None
        self.session_cookies = {}

    def _create_session(self) -> requests.Session:
        """Cria uma sessão de requisições com retry e configurações de segurança"""
        session = requests.Session()
        session.verify = False
        
        # Configura estratégia de retry mais realista
        retry_strategy = Retry(
            total=3, 
            status_forcelist=[429, 502, 503, 504],
            backoff_factor=1.5, 
            raise_on_status=False,
            respect_retry_after_header=True  # Respeita o cabeçalho Retry-After do servidor
        )
        
        adapter = HTTPAdapter(
            max_retries=retry_strategy, 
            pool_connections=50, 
            pool_maxsize=100,
            pool_block=False
        )
        
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def _make_request(self, method, url, **kwargs):
        """
        Faz uma requisição usando a biblioteca apropriada (DoH ou requests padrão)
        """
        # Adiciona headers se não fornecidos
        if 'headers' not in kwargs:
            kwargs['headers'] = get_headers(url)
        
        # Adiciona timeout se não fornecido
        if 'timeout' not in kwargs:
            kwargs['timeout'] = 10
        
        # Usa DoH se disponível, caso contrário usa requests padrão
        if USE_DOH and doh_requests:
            try:
                # Adiciona verificação SSL se não fornecido
                if 'verify' not in kwargs:
                    kwargs['verify'] = False
                
                # Faz a requisição usando DoH
                response = getattr(doh_requests, method.lower())(url, **kwargs)
                return response
            except Exception as e:
                logging.error(f"Erro na requisição DoH: {e}. Tentando com requests padrão.")
        
        # Fallback para requests padrão
        return getattr(self.session, method.lower())(url, **kwargs)

    def _create_flask_app(self) -> Flask:
        app = Flask("HLSProxy")
        
        @app.route("/", methods=["GET"])
        def route_proxy():
            # Adquire o semáforo para limitar requisições concorrentes
            with request_semaphore:
                # Aplica delay para evitar padrões de requisição
                apply_request_delay()
                
                url = request.args.get("url")
                if not url: 
                    return Response("Parâmetro 'url' ausente.", 400)
                    
                if ".m3u8" in url or ".m3u" in url:
                    return self._handle_manifest(url)
                else:
                    return self._handle_segment(url)
        
        return app

    def _stop_current_prefetcher(self):
        """Para a thread de prefetching ativa, se houver."""
        if self.active_prefetcher and self.active_prefetcher.is_alive():
            self.active_prefetcher.stop()
            self.active_prefetcher.join(timeout=2)
        self.active_prefetcher = None

    def _handle_manifest(self, url: str) -> Response:
        cached = self.cache.get(url)
        if cached:
            return Response(cached, 200, mimetype="application/vnd.apple.mpegurl")

        content = None
        for attempt in range(MANIFEST_FETCH_ATTEMPTS):
            try:
                # Aplica delay entre tentativas para evitar detecção
                if attempt > 0:
                    time.sleep(MANIFEST_FETCH_DELAY * (1 + attempt * 0.5))
                
                # Usa cookies da sessão se existirem
                headers = get_headers(url, request.headers)
                if url in self.session_cookies:
                    headers["Cookie"] = self.session_cookies[url]
                
                # Faz a requisição usando o método apropriado
                r = self._make_request(
                    'GET', 
                    url, 
                    headers=headers,
                    timeout=MANIFEST_TIMEOUT + random.uniform(-1, 2)  # Timeout variável
                )
                
                # Salva cookies se enviados pelo servidor
                if 'set-cookie' in r.headers:
                    self.session_cookies[url] = r.headers['set-cookie']
                
                r.raise_for_status()
                content = r.text
                break
            except Exception as e:
                logging.warning(f"Falha ao buscar manifesto (tentativa {attempt+1}): {url} - Erro: {e}")
                if attempt < MANIFEST_FETCH_ATTEMPTS - 1: 
                    time.sleep(MANIFEST_FETCH_DELAY * (1 + attempt * 0.5))
        
        if content is None:
            return Response("#EXTM3U\n#EXT-X-ERROR: Manifest fetch failed\n", 502, mimetype="application/vnd.apple.mpegurl")

        try:
            proxy_base = f"http://{PROXY_HOST}:{self.active_port}/?url="
            m3u8_obj = m3u8.loads(content, uri=url)
            
            # Reescreve as URLs
            if m3u8_obj.is_variant:
                for p in m3u8_obj.playlists: 
                    p.uri = proxy_base + urllib.parse.quote_plus(p.absolute_uri)
            for s in m3u8_obj.segments:
                s.uri = proxy_base + urllib.parse.quote_plus(s.absolute_uri)
                if s.key and s.key.uri: 
                    s.key.uri = proxy_base + urllib.parse.quote_plus(s.key.absolute_uri)
            
            rewritten_content = m3u8_obj.dumps().encode("utf-8")
            
            # Lógica de cache e prefetching
            if m3u8_obj.is_endlist:
                ttl = VOD_MANIFEST_TTL
            else:
                ttl = int(m3u8_obj.target_duration * 1.5) if m3u8_obj.target_duration else DEFAULT_MANIFEST_TTL
                # Gerencia o prefetcher
                self._stop_current_prefetcher()
                # Correção: passa a URL do manifesto explicitamente
                self.active_prefetcher = SegmentPrefetcher(m3u8_obj, url, self)
                self.active_prefetcher.start()

            self.cache.add(url, rewritten_content, ttl=ttl)
            return Response(rewritten_content, 200, mimetype="application/vnd.apple.mpegurl")
        
        except Exception as e:
            logging.error(f"Erro ao processar o manifesto de {url}: {e}", exc_info=True)
            return Response("#EXTM3U\n#EXT-X-ERROR: Manifest processing failed\n", 500, mimetype="application/vnd.apple.mpegurl")

    def fetch_and_cache_segment(self, url: str) -> Optional[bytes]:
        """Lógica separada para buscar e cachear um segmento, usada pelo prefetcher e pelo handler."""
        try:
            # Usa cookies da sessão se existirem
            headers = get_headers(url)
            for manifest_url, cookies in self.session_cookies.items():
                if manifest_url in url:
                    headers["Cookie"] = cookies
                    break
            
            # Timeout variável para evitar padrões
            timeout = SEGMENT_TIMEOUT + random.uniform(-3, 5)
            
            # Faz a requisição usando o método apropriado
            r = self._make_request('GET', url, headers=headers, timeout=timeout)
            
            # Salva cookies se enviados pelo servidor
            if 'set-cookie' in r.headers:
                # Encontra o manifesto relacionado a este segmento
                for manifest_url in self.session_cookies:
                    if manifest_url in url:
                        self.session_cookies[manifest_url] = r.headers['set-cookie']
                        break
            
            r.raise_for_status()
            segment_data = r.content
            target_duration = float(r.headers.get("X-Target-Duration", 10))
            ttl = int(target_duration * SEGMENT_TTL_FACTOR)
            self.cache.add(url, segment_data, ttl=ttl)
            logging.info(f"Segmento baixado e cacheado: {url.split('/')[-1]}")
            return segment_data
        except Exception as e:
            logging.error(f"Erro ao buscar segmento para cache: {url} - Erro: {e}")
            return None

    def _handle_segment(self, url: str) -> Response:
        cached = self.cache.get(url)
        if cached:
            logging.info(f"Segmento servido do cache: {url.split('/')[-1]}")
            return Response(cached, 200, mimetype=safe_mime_type(url))
        
        logging.warning(f"Cache miss para o segmento: {url.split('/')[-1]}. Baixando sob demanda.")
        segment_data = self.fetch_and_cache_segment(url)
        
        if segment_data:
            return Response(segment_data, 200, mimetype=safe_mime_type(url))
        else:
            return Response(f"Segment fetch error for {url}", 404)

    def start(self) -> Optional[int]:
        self.stop()
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                self.active_port = port
                logging.info(f"Proxy HLS (Invisível + DoH) iniciado em http://{PROXY_HOST}:{port}")
                return port
            except OSError: 
                continue
        logging.error("Não foi possível encontrar uma porta livre para iniciar o proxy.")
        return None

    def stop(self):
        self._stop_current_prefetcher()
        if self.server:
            try: 
                self.server.shutdown()
            except Exception: 
                pass
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
        self.server, self.server_thread, self.active_port = None, None, None

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = HLSProxyManager()
        
    def play_stream(self, url: str, channel_name: Optional[str] = None):
        if not self.proxy.start():
            xbmcgui.Dialog().ok("Erro no Proxy HLS", "Não foi possível iniciar o servidor proxy. Verifique o log.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        # Correção: usar xbmcgui.ListItem em vez de xbmc.ListItem
        li = xbmcgui.ListItem(path=proxy_url, label=channel_name or "HLS Proxy Stream")
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def show_test_streams(self):
        test_streams = [
            ("Big Buck Bunny (Mux)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Elephants Dream (AWS)", "https://d3u2k51g8x1l3w.cloudfront.net/a/master_elephantsdream.m3u8")
        ]
        for name, url in test_streams:
            # Correção: usar xbmcgui.ListItem em vez de xbmc.ListItem
            li = xbmcgui.ListItem(label=name)
            li.setProperty("IsPlayable", "true")
            plugin_url = f"plugin://{sys.argv[0]}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, li, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

def main():
    setup_logging()
    logging.info("================ ADDON INICIADO (v3.4 - Corrigido) ================")
    if USE_DOH:
        logging.info("DNS over HTTPS (DoH) está ATIVO para evitar bloqueios de operadoras")
    else:
        logging.warning("DNS over HTTPS (DoH) está INATIVO. Verifique a instalação do script.module.netunblock")
    
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        addon = HLSProxyAddon(handle)
        
        action = params.get("action")
        if action == "play":
            url = params.get("url")
            title = params.get("title", "Stream")
            if url: 
                addon.play_stream(url, title)
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.critical(f"Erro fatal no addon: {e}", exc_info=True)

if __name__ == "__main__":
    main()