# -*- coding: utf--8 -*-

# =============================================================================
# MÓDULOS PADRÃO E DE TERCEIROS
# =============================================================================
import sys
import os
import threading
import time
import random
import logging
import logging.handlers
import queue
import urllib.parse
from urllib.parse import urlparse
from collections import OrderedDict, deque
from typing import Optional, Dict, Any, List, Tuple, Union

# =============================================================================
# MÓDULOS KODI
# =============================================================================
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin

# =============================================================================
# MÓDULOS DO PROXY (INCLUINDO FLASK)
# =============================================================================
import requests
import m3u8
import ipaddress
from werkzeug.serving import make_server

# Tenta importar o Flask.
try:
    from flask import Flask, request, Response, make_response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro de Dependência", "O addon 'script.module.flask' não foi encontrado. Por favor, instale-o para que o HLS Tester funcione.")
    sys.exit(1)

# =============================================================================
# MÓDULO DE DESBLOQUEIO DE REDE (DoH)
# =============================================================================
try:
    from doh import DNSOverrideDoH
    doh_resolver = DNSOverrideDoH()
    logging.info("Módulo netunblock (DoH) carregado e inicializado com sucesso.")
except ImportError:
    logging.warning("Módulo netunblock (DoH) não encontrado. Usando resolução DNS padrão.")
    doh_resolver = None
except Exception as e:
    logging.error(f"Erro ao inicializar o módulo netunblock (DoH): {e}")
    doh_resolver = None

# =============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO (AJUSTADO PARA TV BOX) ---
# =============================================================================
MAX_CONSECUTIVE_SEGMENT_FAILURES = 5  # Tolerância a falhas consecutivas
FETCHER_MAX_RETRIES = 4  # Tentativas de reconexão
RETRY_BACKOFF_FACTOR = 0.5  # Atraso entre tentativas (aumentado para ser menos agressivo)
CONNECTION_TIMEOUT = 10.0  # Timeout de conexão (ligeiramente aumentado)
STREAM_TIMEOUT = 20.0  # Timeout de stream (ligeiramente aumentado)
DEFAULT_CHUNK_SIZE = 128 * 1024  # Reduzido para 128KB para menor consumo de RAM por operação
MAX_STREAM_LIFETIME_SECONDS = 15  # Vida útil do cache de manifesto
MAX_CACHE_MB = 20  # Reduzido drasticamente para 20MB para baixo consumo de RAM
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_MB = 10  # Tamanho máximo de um segmento em cache
MAX_SEGMENT_SIZE_BYTES = MAX_SEGMENT_SIZE_MB * 1024 * 1024
PREFETCH_SEGMENTS_COUNT = 2  # Reduzido para menor uso de CPU/rede
MAX_PREFETCH_SEGMENTS = 4  # Reduzido para fila de pré-carregamento menor
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 15
LIMIT_COOLDOWN_SECONDS = 10
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Kodi/20.0 (Windows NT 10.0; Win64; x64) App/1.0"
]
LOG_MAX_BYTES = 1048576 * 2  # Reduzido para 2MB para economizar espaço
LOG_BACKUP_COUNT = 1
LOG_FILE = xbmcvfs.translatePath('special://temp/hlstesterflask.log')
LOG_LEVEL = logging.INFO

# Configurações avançadas para reconexão inteligente
ADAPTIVE_BACKOFF_ENABLED = True
MAX_BACKOFF_TIME = 20
HEALTH_CHECK_INTERVAL = 15  # Reduzido para verificações menos frequentes (economia de CPU)

# Configurações de recuperação inteligente
SMART_RECOVERY_ENABLED = True
RECOVERY_ATTEMPTS_BEFORE_RESET = 3

# Qualidade adaptativa desativada pois não é compatível com o player padrão
ADAPTIVE_QUALITY_ENABLED = False

# Configuração para priorizar cache
ALWAYS_PREFER_CACHE = True
MIN_CACHE_BUFFER_SIZE = 512 * 1024  # 512KB mínimo para considerar cache como fonte primária

_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                       'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection', 'Transfer-Encoding'}

_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}


# =============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# =============================================================================

def setup_logging():
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT, encoding='utf-8'
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "*/*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin,
        "X-Forwarded-For": "1.1.1.1"
    }

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith(('.m3u8', '.m3u')):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
               "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid",
                "authentication failed", "unauthorized", "bad request", "service unavailable"]
    return any(keyword in txt for keyword in keywords)

def calculate_backoff(attempt: int) -> float:
    if not ADAPTIVE_BACKOFF_ENABLED:
        return RETRY_BACKOFF_FACTOR
    
    base_backoff = RETRY_BACKOFF_FACTOR * (2 ** min(attempt, 5))
    backoff = min(base_backoff, MAX_BACKOFF_TIME)
    jitter_factor = 0.1 + (0.4 * min(attempt / 5, 1.0))
    jitter = random.uniform(-jitter_factor, jitter_factor) * backoff
    return max(0.1, backoff + jitter)


# =============================================================================
# --- CLASSES DE CACHE E REDE ---
# =============================================================================

class RotatingChunkCache:
    """
    Cache de blocos rotativo otimizado para LRU (Least Recently Used) simplificado.
    CORREÇÃO: Removido o 'continuous_buffer' que causava loops de vídeo em caso de falha.
    """
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.chunks: OrderedDict[str, bytes] = OrderedDict()
        self.total_bytes = 0
        self.access_times: Dict[str, float] = {}
        self.hits = 0
        self.misses = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
                self.access_times[url] = time.time()
                self.hits += 1
                logging.debug(f"[Cache] Hit para {url}")
            else:
                self.misses += 1
            return data

    def add(self, url: str, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
        
            chunk_size = len(data)
            if chunk_size > self.max_bytes:
                return
                
            self.chunks[url] = data
            self.total_bytes += chunk_size
            self.access_times[url] = time.time()
            
            self._manage_cache_size()

    def _manage_cache_size(self):
        evicted = 0
        while self.total_bytes > self.max_bytes and len(self.chunks) > 1:
            oldest_key = next(iter(self.chunks))
            old_data = self.chunks.pop(oldest_key)
            self.total_bytes -= len(old_data)
            self.access_times.pop(oldest_key, None)
            evicted += 1
        
        if evicted > 0:
            logging.debug(f"[Cache] Removidos {evicted} itens do LRU. Total: {self.total_bytes / (1024*1024):.2f}MB")

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0
            self.access_times.clear()
        logging.info("[RECONEXÃO] Cache de segmentos de vídeo limpo.")

    def has(self, url: str) -> bool:
        with self.lock:
            return url in self.chunks

    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            hit_rate = self.hits / (self.hits + self.misses) if (self.hits + self.misses) > 0 else 0
            return {
                'total_bytes': self.total_bytes,
                'total_items': len(self.chunks),
                'max_bytes': self.max_bytes,
                'usage_percent': (self.total_bytes / self.max_bytes) * 100 if self.max_bytes > 0 else 0,
                'hit_rate': hit_rate * 100,
            }

class StreamCache:
    def __init__(self, chunk_cache: RotatingChunkCache):
        self.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self.chunk_cache = chunk_cache
        self.lock = threading.Lock()

    def get_manifest(self, url: str) -> Optional[str]:
        with self.lock:
            entry = self.manifest_cache.get(url)
            if entry and time.time() < entry['expires']:
                return entry['content']
            return None

    def add_manifest(self, url: str, content: str, ttl: int):
        with self.lock:
            self.manifest_cache[url] = {
                'content': content, 
                'expires': time.time() + ttl
            }

    def is_manifest_expired(self, url: str) -> bool:
        with self.lock:
            entry = self.manifest_cache.get(url)
            return not entry or time.time() >= entry.get('expires', 0)

    def get_segment(self, url: str) -> Optional[bytes]:
        return self.chunk_cache.get(url)

    def add_segment(self, url: str, data: bytes):
        self.chunk_cache.add(url, data)

    def has_segment(self, url: str) -> bool:
        return self.chunk_cache.has(url)

    def clear(self):
        with self.lock:
            self.manifest_cache.clear()
        self.chunk_cache.clear()

class UpstreamFetcher:
    def __init__(self, session: requests.Session):
        self.session = session

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        headers = get_player_headers(url)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie']})
        
        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    url, stream=stream, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                return resp
            except requests.RequestException as e:
                logging.warning(f"[Fetcher] Tentativa {attempt + 1} falhou para {url}: {e}")
                if attempt < FETCHER_MAX_RETRIES:
                    backoff = calculate_backoff(attempt)
                    logging.info(f"[Fetcher] Aguardando {backoff:.2f}s antes da próxima tentativa")
                    time.sleep(backoff)
                else:
                    raise

class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        self.original_manifest_url = manifest_url

    def rewrite(self) -> str:
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri and not item.key.uri.startswith("data:"):
                item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
        if self.is_live:
            return max(2, int(target_duration * 0.5))
        else:
            return max(60, int(target_duration * 3))

# =============================================================================
# --- CLASSE PRINCIPAL DE GERENCIAMENTO DO PROXY ---
# =============================================================================

class HLSProxyManager:
    def __init__(self):
        self.server: Optional[make_server] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None
        self.chunk_cache = RotatingChunkCache()
        self.stream_cache = StreamCache(self.chunk_cache)
        self._http_session: requests.Session = self._create_http_session()
        self.fetcher = UpstreamFetcher(self._http_session)
        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0
        self._limit_hits: Dict[str, float] = {}
        self._segment_prefetch_queue = queue.Queue(maxsize=MAX_PREFETCH_SEGMENTS * 2)
        self._prefetch_thread: Optional[threading.Thread] = None
        self._prefetch_stop_event = threading.Event()
        self._health_check_thread: Optional[threading.Thread] = None
        self._health_check_stop_event = threading.Event()
        self._current_manifest_url: Optional[str] = None
        self._recovery_attempts: Dict[str, int] = {}
        self._recovery_lock = threading.Lock()
        self.app = self._create_flask_app()

    def _create_http_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({'User-Agent': random.choice(USER_AGENTS), 'Connection': 'keep-alive'})
        session.trust_env = False
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        retry_strategy = Retry(
            total=FETCHER_MAX_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[500, 502, 503, 504, 408, 429]
        )
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=4,  # Reduzido para menor consumo de recursos
            pool_maxsize=4,      # Reduzido para menor consumo de recursos
            pool_block=False
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def reset_http_session(self):
        logging.info("[RECONEXÃO] Recriando sessão HTTP.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher = UpstreamFetcher(self._http_session)
        with self._segment_prefetch_queue.mutex:
            self._segment_prefetch_queue.queue.clear()

    def force_reconnection(self, url: str):
        logging.info(f"[RECONEXÃO] Forçando reconexão para URL base: {url}")
        self.stream_cache.clear()
        self.reset_http_session()
        with self._failure_lock:
            self._consecutive_failures = 0
        with self._recovery_lock:
            self._recovery_attempts.clear()
        self._limit_hits.clear()

    def increment_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures += 1
            logging.debug(f"Contador de falhas: {self._consecutive_failures}")

    def reset_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures = 0

    def should_force_reconnect(self) -> bool:
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES

    def record_limit_hit(self, url: str):
        self._limit_hits[url] = time.time()

    def is_in_cooldown(self, url: str) -> bool:
        hit_time = self._limit_hits.get(url)
        return hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS

    def clear_limit_hit(self, url: str):
        if url in self._limit_hits:
            del self._limit_hits[url]

    def record_successful_segment(self, url: str):
        self.reset_failure_count()
        with self._recovery_lock:
            if url in self._recovery_attempts:
                del self._recovery_attempts[url]

    def queue_segment_for_prefetch(self, segment_url: str):
        try:
            self._segment_prefetch_queue.put_nowait(segment_url)
        except queue.Full:
            logging.warning("Fila de pré-busca cheia.")

    def _prefetch_worker(self):
        while not self._prefetch_stop_event.is_set():
            try:
                segment_url = self._segment_prefetch_queue.get(timeout=1)
                if self.stream_cache.has_segment(segment_url):
                    self._segment_prefetch_queue.task_done()
                    continue
                try:
                    response = self.fetcher.fetch(segment_url)
                    self.stream_cache.add_segment(segment_url, response.content)
                    logging.debug(f"[Prefetch] Sucesso para {segment_url}")
                except Exception as e:
                    logging.warning(f"[Prefetch] Falha para {segment_url}: {e}")
                finally:
                    self._segment_prefetch_queue.task_done()
            except queue.Empty:
                pass
        logging.info("Thread de pré-busca encerrada.")
    
    def _health_check_worker(self):
        logging.info("Iniciando monitor de saúde do stream")
        while not self._health_check_stop_event.is_set():
            time.sleep(HEALTH_CHECK_INTERVAL)
            if not self._current_manifest_url:
                continue
            
            try:
                # Simplificado: apenas verifica se o manifesto ainda é válido
                response = self.fetcher.fetch(self._current_manifest_url)
                if is_manifest_limit_error(response.text):
                    logging.warning(f"[Health Check] Erro de limite detectado. Forçando reconexão.")
                    self.force_reconnection(self._current_manifest_url)
                else:
                    cache_stats = self.chunk_cache.get_stats()
                    logging.debug(f"[Health Check] Status OK. Cache: {cache_stats['usage_percent']:.1f}%")
            except Exception as e:
                logging.error(f"[Health Check] Erro ao verificar manifesto: {e}")
                self.force_reconnection(self._current_manifest_url)
        logging.info("Monitor de saúde do stream encerrado.")
    
    def _create_flask_app(self) -> Flask:
        app = Flask(ADDON_NAME)
        manager = self
        app.logger.disabled = True
        logging.getLogger('werkzeug').disabled = True

        @app.route('/')
        def proxy_route():
            original_url = request.args.get('url')
            if not original_url:
                return make_response("Parâmetro 'url' ausente", 400)

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                return manager._handle_manifest_flask(original_url)
            else:
                return manager._handle_segment_flask(original_url)
        
        return app

    def _handle_manifest_flask(self, url: str) -> Response:
        logging.info(f"Manipulando manifesto: {url}")
        self._current_manifest_url = url
        
        if self.is_in_cooldown(url):
            logging.warning(f"Manifesto em cooldown. Enviando playlist vazia.")
            return make_response("#EXTM3U\n", 200, {'Content-Type': 'application/vnd.apple.mpegurl'})

        if self.stream_cache.is_manifest_expired(url):
            logging.info(f"Cache do manifesto expirado ou ausente para {url}.")
        
        cached_content = self.stream_cache.get_manifest(url)
        if cached_content:
            return make_response(cached_content, 200, {'Content-Type': 'application/vnd.apple.mpegurl'})

        try:
            response = self.fetcher.fetch(url, original_headers=request.headers)
            content = response.text

            if is_manifest_limit_error(content):
                logging.warning(f"Erro de limite/bloqueio detectado para {url}.")
                self.record_limit_hit(url)
                self.force_reconnection(url)
                return make_response("#EXTM3U\n", 200, {'Content-Type': 'application/vnd.apple.mpegurl'})
            
            proxy_base = f"http://{request.host}/?url="
            rewriter = ManifestRewriter(content, response.url, proxy_base)
            rewritten_content = rewriter.rewrite()
            
            self.stream_cache.add_manifest(url, rewritten_content, rewriter.get_ttl())
            self.clear_limit_hit(url)
            
            segments = rewriter.m3u8_obj.segments
            segments_to_prefetch = segments[:PREFETCH_SEGMENTS_COUNT] if not rewriter.is_live else segments[-PREFETCH_SEGMENTS_COUNT:]
            
            for segment in segments_to_prefetch:
                if not self.stream_cache.has_segment(segment.absolute_uri):
                    self.queue_segment_for_prefetch(segment.absolute_uri)

            return make_response(rewritten_content, 200, {'Content-Type': 'application/vnd.apple.mpegurl'})
        except Exception as e:
            logging.error(f"Falha ao processar manifesto {url}: {e}")
            self.force_reconnection(url)
            return make_response("#EXTM3U\n", 500, {'Content-Type': 'application/vnd.apple.mpegurl'})

    def _handle_segment_flask(self, url: str) -> Response:
        mime_type = safe_mime_type(url)
        
        cached_segment = self.stream_cache.get_segment(url)
        if cached_segment:
            self.record_successful_segment(url)
            return Response(cached_segment, mimetype=mime_type, status=200)

        def stream_generator():
            segment_data = bytearray()
            try:
                with self.fetcher.fetch(url, stream=True, original_headers=request.headers) as response:
                    for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                        if chunk:
                            segment_data.extend(chunk)
                            yield chunk
                
                self.stream_cache.add_segment(url, bytes(segment_data))
                self.record_successful_segment(url)
                logging.info(f"Segmento {url} (tamanho: {len(segment_data)}) streamado e cacheado.")
            except Exception as e:
                self.increment_failure_count()
                logging.error(f"Erro durante o streaming do segmento {url}: {e}")
                
                with self._recovery_lock:
                    self._recovery_attempts[url] = self._recovery_attempts.get(url, 0) + 1
                
                # CORREÇÃO: A lógica de fallback para o 'continuous_buffer' foi removida daqui.
                # Se a falha ocorrer, o gerador simplesmente para, resultando em uma conexão
                # interrompida que o player do Kodi pode manipular corretamente, em vez de
                # receber dados de vídeo antigos que causavam o loop.

        try:
            return Response(stream_with_context(stream_generator()), mimetype=mime_type, status=200)
        except Exception:
            if self.should_force_reconnect():
                logging.error(f"Limite de falhas atingido. Forçando reconexão total.")
                self.force_reconnection(url)
                self.reset_failure_count()
            return make_response("Falha ao obter segmento", 500)

    def start(self) -> Optional[int]:
        self.stop()
        os.environ['WERKZEUG_RUN_MAIN'] = 'true'

        for i in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                
                self._prefetch_stop_event.clear()
                self._prefetch_thread = threading.Thread(target=self._prefetch_worker, daemon=True)
                self._prefetch_thread.start()
                
                self._health_check_stop_event.clear()
                self._health_check_thread = threading.Thread(target=self._health_check_worker, daemon=True)
                self._health_check_thread.start()

                logging.info(f"Proxy HLS (Flask) otimizado iniciado em http://{PROXY_HOST}:{port}")
                return port
            except Exception as e:
                logging.warning(f"Porta {port} em uso ou falhou. Tentativa {i+1}/{MAX_PORT_ATTEMPTS}. Erro: {e}")
        
        logging.error("Não foi possível encontrar uma porta disponível para o proxy.")
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy",5000)')
        return None

    def stop(self):
        if self._health_check_thread and self._health_check_thread.is_alive():
            self._health_check_stop_event.set()
            self._health_check_thread.join(timeout=2)

        if self._prefetch_thread and self._prefetch_thread.is_alive():
            self._prefetch_stop_event.set()
            self._prefetch_thread.join(timeout=2)

        if self.server:
            try:
                self.server.shutdown()
            except Exception as e:
                logging.error(f"Erro ao desligar o servidor proxy: {e}")
            self.server = None
        
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
            self.server_thread = None

        self.stream_cache.clear()
        self.reset_http_session()
        self.active_port = None
        self._current_manifest_url = None
        with self._recovery_lock:
            self._recovery_attempts.clear()
        logging.info("Proxy HLS (Flask) otimizado parado e recursos liberados.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{PROXY_HOST}:{self.active_port}/?url={encoded_url}"


# =============================================================================
# --- INTEGRAÇÃO COM O KODI ---
# =============================================================================

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        self.last_position = 0
        self.stall_count = 0
        self._monitor_thread = None
        self._monitor_stop_event = threading.Event()

    def onPlayBackStarted(self):
        logging.info("Playback iniciado (onPlayBackStarted).")
        self.last_position = 0
        self.stall_count = 0
        self._monitor_stop_event.clear()
        self._monitor_thread = threading.Thread(target=self._monitor_buffer, daemon=True)
        self._monitor_thread.start()

    def onPlayBackEnded(self):
        logging.info("Playback finalizado (onPlayBackEnded).")
        self.stop_event.set()
        self._stop_monitor()

    def onPlayBackError(self):
        logging.error("Erro no Playback (onPlayBackError).")
        self.stop_event.set()
        self._stop_monitor()

    def onPlayBackStopped(self):
        logging.info("Playback parado pelo usuário (onPlayBackStopped).")
        self.stop_event.set()
        self._stop_monitor()
    
    def _stop_monitor(self):
        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_stop_event.set()
            self._monitor_thread.join(timeout=1)
    
    def _monitor_buffer(self):
        logging.info("Monitor de buffer iniciado.")
        while not self._monitor_stop_event.is_set():
            try:
                time.sleep(2)
                if not self.isPlaying():
                    continue
            
                current_position = int(self.getTime())
                
                # Detectar travamento
                if current_position == self.last_position and current_position > 0:
                    self.stall_count += 1
                    logging.warning(f"Buffer possivelmente travado. Contador: {self.stall_count}")
                    
                    if self.stall_count >= 3:
                        logging.error("Detectado travamento de buffer. Tentando recuperar pausando e despausando.")
                        self.pause()
                        time.sleep(0.5)
                        self.pause()
                        self.stall_count = 0
                else:
                    if self.stall_count > 0:
                        logging.info(f"Buffer recuperado. Resetando contador de travamentos.")
                    self.stall_count = 0
                
                self.last_position = current_position
            except Exception as e:
                logging.error(f"Erro no monitor de buffer: {e}")
        logging.info("Monitor de buffer encerrado.")

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)

    def basename(self, file):
        return file.split('/')[-1]

    def convert_to_m3u8(self,url):
        if '|' in url:
            url = url.split('|')[0]
        elif '%7C' in url:
            url = url.split('%7C')[0]
        if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
            parsed_url = urlparse(url)
            try:
                host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                url = host_part1 + '/live' + host_part2
                file = self.basename(url)
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                else:
                    url = url + '.m3u8'
                    # file_new = file + '.m3u8'
                    # new_url = url.replace(file, file_new)
            except:
                pass
        return url

    def run(self, url: str):
        setup_logging()
        
        m3u8_url = self.convert_to_m3u8(url)
        logging.info(f"URL original: {url}")
        logging.info(f"URL convertida para M3U8: {m3u8_url}")
        
        port = self.proxy_manager.start()
        if not port:
            xbmcgui.Dialog().ok("Erro", "Não foi possível iniciar o proxy HLS.")
            return
        
        proxy_url = self.proxy_manager.get_proxy_url(m3u8_url)
        if not proxy_url:
            xbmcgui.Dialog().ok("Erro", "Não foi possível criar a URL do proxy.")
            self.proxy_manager.stop()
            return
        
        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        list_item.setProperty('IsPlayable', 'true')
        
        # As linhas do inputstream.adaptive foram removidas daqui
        
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        
        while not self.playback_stop_event.is_set():
            xbmc.sleep(500)
        
        self.proxy_manager.stop()
        logging.info("Addon HLS Proxy finalizado.")

# =============================================================================
# --- PONTO DE ENTRADA DO ADDON ---
# =============================================================================

if __name__ == '__main__':
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    
    url = params.get('url', '')
    if not url:
        xbmcgui.Dialog().ok("Erro", "URL não fornecida.")
        sys.exit(1)
    
    addon = HLSProxyAddon(handle)
    addon.run(url)