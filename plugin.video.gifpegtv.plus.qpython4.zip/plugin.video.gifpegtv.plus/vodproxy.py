import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import socket

# --- IMPORTAÇÕES DE REDE ---
from requests.adapters import HTTPAdapter
from requests.exceptions import RequestException, ConnectionError, HTTPError, Timeout, StreamConsumedError
from urllib3.util.retry import Retry

# Tenta importar o wrapper DoH (doh_client)
# Se falhar, usa o requests padrão
try:
    from doh_client import requests
except ImportError:
    import requests

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIGURAÇÕES OTIMIZADAS ----------------

DEFAULT_CHUNK_SIZE = 64 * 1024  # 64KB (Otimizado para Kodi)
MAX_RETRIES = 3
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 20.0
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 30
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
LOG_FILE = "vod_proxy.log"

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- LOGGING ----------------

def setup_logging():
    log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
    try:
        logging.basicConfig(
            level=logging.INFO,
            format='[VOD-PROXY] %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        # Fallback para log simples se falhar ao criar arquivo
        logging.basicConfig(level=logging.INFO, format='[VOD-PROXY] %(message)s')

# ---------------- PREPARAÇÃO DA SESSÃO (CORREÇÃO DO ERRO) ----------------

# Lógica para detectar se é doh_client (instância) ou requests padrão (classe)
# Isso corrige o erro "'Session' object is not callable"
def get_global_session():
    session_obj = None
    
    # Verifica se requests.session existe e NÃO é chamável (caso do doh_client)
    if hasattr(requests, 'session') and not callable(requests.session):
        session_obj = requests.session
    # Verifica se requests.Session (maiúsculo) é chamável (caso requests padrão)
    elif hasattr(requests, 'Session') and callable(requests.Session):
        session_obj = requests.Session()
    # Verifica se requests.session (minúsculo) é chamável (alias padrão)
    elif hasattr(requests, 'session') and callable(requests.session):
        session_obj = requests.session()
    else:
        # Fallback de segurança
        import requests as std_requests
        session_obj = std_requests.Session()

    # Configura Adapters e Retries na sessão global
    retry_strategy = Retry(
        total=MAX_RETRIES,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=20, pool_maxsize=20)
    
    # Monta os adapters (pode falhar silenciosamente em algumas versões do doh_client, por isso o try)
    try:
        session_obj.mount("https://", adapter)
        session_obj.mount("http://", adapter)
    except Exception:
        pass
        
    return session_obj

# Inicializa a sessão globalmente para ser reusada pelo Handler
GLOBAL_SESSION = get_global_session()

# ---------------- LÓGICA DO PROXY ----------------

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    
    # Usa a sessão global já configurada corretamente
    session = GLOBAL_SESSION

    def log_message(self, format, *args):
        # Desabilita log padrão do HTTP Server para não poluir o kodi.log
        pass

    def do_HEAD(self):
        self._handle_request(method='HEAD')

    def do_GET(self):
        self._handle_request(method='GET')

    def _handle_request(self, method='GET'):
        target_url = None
        try:
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            target_url = params.get('url', [None])[0]

            if not target_url:
                self.send_error(400, "URL parameter missing")
                return

            target_url = urllib.parse.unquote_plus(target_url)

            # Headers básicos
            headers = {
                'User-Agent': USER_AGENT,
                'Connection': 'keep-alive'
            }
            
            # Repassa Range (Seek) se o Kodi solicitar
            if 'Range' in self.headers:
                headers['Range'] = self.headers['Range']

            # Requisição upstream
            resp = self.session.request(
                method, 
                target_url, 
                headers=headers, 
                stream=True, 
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), 
                verify=False,
                allow_redirects=True
            )

            if resp.status_code >= 400:
                logging.error(f"Erro upstream {resp.status_code} para {target_url}")
                self.send_error(resp.status_code)
                return

            self.send_response(resp.status_code)

            # Headers Hop-by-Hop que não devem ser repassados
            hop_by_hop = [
                'connection', 'keep-alive', 'proxy-authenticate', 
                'proxy-authorization', 'te', 'trailers', 
                'transfer-encoding', 'upgrade', 'content-encoding', 
                'content-length'
            ]

            for k, v in resp.headers.items():
                if k.lower() not in hop_by_hop:
                    self.send_header(k, v)

            if 'Content-Length' in resp.headers:
                self.send_header('Content-Length', resp.headers['Content-Length'])

            self.end_headers()

            if method == 'HEAD':
                return

            # Streaming Direto (Performance Otimizada)
            try:
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.wfile.write(chunk)
            except (ConnectionError, socket.error, StreamConsumedError):
                # Cliente desconectou (Stop/Pause/Seek), comportamento normal
                pass
            except Exception as e:
                logging.error(f"Erro no stream de dados: {e}")

        except Exception as e:
            logging.error(f"Erro fatal no handler: {e}")
            try:
                self.send_error(502)
            except:
                pass

class VODProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def start(self):
        if self._is_running: return True
        self.stop()

        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 55000)
                self.server = ThreadedTCPServer((PROXY_HOST, port), VODProxyRequestHandler)
                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                self.active_port = port
                self._is_running = True
                logging.info(f"VOD Proxy iniciado na porta {port}")
                return True
            except OSError:
                continue
        
        logging.error("Não foi possível iniciar o VOD Proxy (sem portas livres)")
        return False

    def stop(self):
        self._is_running = False
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except: pass
        self.server = None

class VODAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = VODProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        
        li = xbmcgui.ListItem(path=proxy_url)
        if title: 
            li.setLabel(title)
            li.setInfo('video', {'title': title})
        
        # Define MIME type para ajudar o player
        ext = url.lower().split('?')[0].split('.')[-1]
        mime_map = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'avi': 'video/x-msvideo'}
        li.setMimeType(mime_map.get(ext, 'application/octet-stream'))
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.setResolvedUrl(self.handle, True, li)

def main():
    setup_logging()
    try:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        addon = VODAddon(handle)
        
        params = {}
        if len(sys.argv) > 2:
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

        if params.get('action') == 'play_stream':
            addon.play_stream(
                params.get('stream_url'), 
                params.get('stream_type'), 
                params.get('title')
            )
        elif handle != -1:
            xbmcplugin.endOfDirectory(handle)
            
    except Exception as e:
        logging.error(f"Erro Main VODProxy: {e}")

if __name__ == '__main__':
    main()