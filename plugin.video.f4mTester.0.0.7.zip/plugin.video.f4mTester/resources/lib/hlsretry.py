# hlsretry.py
# -*- coding: utf-8 -*-
import os
import requests
import six
if six.PY3:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, urljoin, quote_plus
    import queue # Python 3
else:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from urlparse import urlparse, parse_qs, urljoin
    from urllib import quote, unquote, unquote_plus
    import Queue as queue # Python 2
import threading
import time
import re
import logging
from collections import OrderedDict # For LRU cache

# Configuração de logging para depuração
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def log(msg):
    logger.info(msg)

# --- Configurações do Servidor Proxy ---
HOST_NAME = '127.0.0.1'
PORT_NUMBER = 55894 

# Definindo URLs do proxy
url_proxy_base = 'http://'+HOST_NAME+':'+str(PORT_NUMBER)
url_proxy = url_proxy_base + '/proxy_m3u8?url=' # Para playlists M3U8
url_segment_proxy_prefix = url_proxy_base + '/proxy_segment/' # Para segmentos TS
url_stop = url_proxy_base + '/stop'
url_reset = url_proxy_base + '/reset'
url_check = url_proxy_base + '/check' # Adicionado para verificar o status do servidor

# --- Variáveis Globais para o Estado do Proxy ---
URL_BASE = '' # Base da URL do conteúdo original (e.g., http://example.com/live/)
LAST_URL = '' # Última URL de playlist original que foi proxyficada
HEADERS_BASE = {} # Headers para usar nas requisições ao servidor de origem
STOP_SERVER = False # Flag para sinalizar o encerramento do servidor
CACHE_M3U8 = '' # Conteúdo da última playlist M3U8 proxyficada

# Variáveis relacionadas ao cache e pré-busca
# Modificado para OrderedDict para implementar LRU
SEGMENT_CACHE = OrderedDict() # Dicionário para armazenar segmentos: {url: content}
MAX_CACHE_SIZE_BYTES = 100 * 1024 * 1024 # 100 MB de cache (ajustável)
CURRENT_CACHE_SIZE_BYTES = 0 # Tamanho atual do cache em bytes

SEGMENT_CACHE_LOCK = threading.Lock() # Lock para acesso thread-safe ao cache
PREFETCH_QUEUE = queue.Queue() # Fila para URLs de segmentos a serem pré-buscados
PREFETCH_WORKERS = 3 # Número de threads de pré-busca (ajustável)
PREFETCH_STOP_EVENT = threading.Event() # Evento para sinalizar o fim das threads de pré-busca

# Configurar uma sessão persistente com retries
s = requests.Session()
retries = requests.packages.urllib3.util.retry.Retry(
    total=5, # Total de retries
    backoff_factor=0.5, # Fator de backoff (0.5, 1, 2, 4...)
    status_forcelist=[500, 502, 503, 504, 429], # Status codes para retry
    allowed_methods=frozenset(['GET', 'HEAD']) # Métodos a serem retentados
)
adapter = requests.adapters.HTTPAdapter(max_retries=retries)
s.mount('http://', adapter)
s.mount('https://', adapter)
REQUESTS_SESSION = s # Usar a sessão configurada

# --- Thread de Pré-busca (Prefetch) ---
class PrefetchThread(threading.Thread):
    def __init__(self, queue, cache, lock, stop_event, headers):
        super(PrefetchThread, self).__init__()
        self.daemon = True 
        self.queue = queue
        self.cache = cache
        self.lock = lock
        self.stop_event = stop_event
        self.headers = headers.copy() 
        log("Prefetch thread initialized.")

    def run(self):
        # CURRENT_CACHE_SIZE_BYTES é global e modificado aqui, então precisa da declaração
        global CURRENT_CACHE_SIZE_BYTES 

        while not self.stop_event.is_set():
            try:
                segment_url_to_prefetch = self.queue.get(timeout=1)
            except queue.Empty:
                if self.stop_event.is_set():
                    break 
                time.sleep(0.1) 
                continue

            with self.lock:
                if segment_url_to_prefetch in self.cache:
                    log(f"Segment already in cache, skipping prefetch: {segment_url_to_prefetch}")
                    self.queue.task_done()
                    continue

            log(f"Prefetching segment: {segment_url_to_prefetch}")
            try:
                # Usar a sessão persistente configurada para retries
                r = REQUESTS_SESSION.get(segment_url_to_prefetch, headers=self.headers, stream=True, timeout=10)
                r.raise_for_status() 
                content = r.content 

                with self.lock:
                    if segment_url_to_prefetch not in self.cache: # Apenas adicionar se não foi adicionado por outra thread
                        # Gerenciar o tamanho do cache
                        segment_size = len(content)
                        while CURRENT_CACHE_SIZE_BYTES + segment_size > MAX_CACHE_SIZE_BYTES and len(self.cache) > 0:
                            # Remover o item mais antigo (LRU)
                            oldest_url, oldest_content = self.cache.popitem(last=False) 
                            CURRENT_CACHE_SIZE_BYTES -= len(oldest_content)
                            log(f"Evicting segment from cache (LRU): {oldest_url}")

                        self.cache[segment_url_to_prefetch] = content
                        CURRENT_CACHE_SIZE_BYTES += segment_size
                        log(f"Prefetched and cached: {segment_url_to_prefetch} ({len(content)} bytes). Cache size: {CURRENT_CACHE_SIZE_BYTES / (1024 * 1024):.2f} MB")
                    else:
                        log(f"Segment {segment_url_to_prefetch} was added by another thread while prefetching.")

            except requests.exceptions.RequestException as e:
                log(f"Error prefetching {segment_url_to_prefetch}: {e}")
            finally:
                self.queue.task_done() 

# --- Handler das Requisições HTTP (ProxyHandler) ---
class ProxyHandler(BaseHTTPRequestHandler):

    def basename(self, p):
        i = p.rfind('/') + 1
        return p[i:]

    def fetch_m3u8(self, url, headers):
        log(f"Fetching M3U8: {url}")
        try:
            r = REQUESTS_SESSION.get(url, headers=headers, timeout=10)
            r.raise_for_status()
            log(f"Successfully fetched M3U8 from {url}. Status: {r.status_code}")
            return r.text, r.url 
        except requests.exceptions.RequestException as e:
            log(f"Error fetching M3U8 from {url}: {e}")
            return None, None

    def fetch_chunk(self, url, headers):
        # CURRENT_CACHE_SIZE_BYTES é global e modificado aqui, então precisa da declaração
        global CURRENT_CACHE_SIZE_BYTES 

        with SEGMENT_CACHE_LOCK:
            if url in SEGMENT_CACHE:
                log(f"Serving segment from cache: {url}")
                # Atualizar a ordem do item no OrderedDict para LRU
                SEGMENT_CACHE.move_to_end(url) 
                # Criar um objeto de resposta simulado para compatibilidade com o retorno de requests
                class MockResponse:
                    def __init__(self, content):
                        self._content = content
                        self.headers = {'Content-Length': str(len(content)), 'Content-Type': 'video/mp2t'} 
                        self.status_code = 200
                    def iter_content(self, chunk_size=8192): # Adicionado chunk_size para compatibilidade
                        # Retorna o conteúdo em chunks para simular streaming
                        for i in range(0, len(self._content), chunk_size):
                            yield self._content[i:i + chunk_size]
                    def close(self):
                        pass 
                return MockResponse(SEGMENT_CACHE[url])

        log(f"Fetching segment (not in cache): {url}")
        try:
            # Usar a sessão persistente configurada para retries
            r = REQUESTS_SESSION.get(url, headers=headers, stream=True, timeout=10)
            r.raise_for_status()
            
            # Lê todo o conteúdo e armazena no cache antes de retornar
            content = r.content
            with SEGMENT_CACHE_LOCK:
                if url not in SEGMENT_CACHE: # Apenas adicionar se não foi adicionado por outra thread
                    # Gerenciar o tamanho do cache
                    segment_size = len(content)
                    while CURRENT_CACHE_SIZE_BYTES + segment_size > MAX_CACHE_SIZE_BYTES and len(SEGMENT_CACHE) > 0:
                        oldest_url, oldest_content = SEGMENT_CACHE.popitem(last=False) 
                        CURRENT_CACHE_SIZE_BYTES -= len(oldest_content)
                        log(f"Evicting segment from cache (LRU): {oldest_url}")
                    
                    SEGMENT_CACHE[url] = content
                    CURRENT_CACHE_SIZE_BYTES += segment_size
                    log(f"Successfully fetched and cached segment: {url} ({len(content)} bytes). Cache size: {CURRENT_CACHE_SIZE_BYTES / (1024 * 1024):.2f} MB")
                else:
                    log(f"Segment {url} was added by another thread while fetching.")
                SEGMENT_CACHE.move_to_end(url) # Mover para o final pois acabou de ser acessado
            
            # Criar um MockResponse a partir do conteúdo cacheado para retornar uniformemente
            class MockResponseCached:
                def __init__(self, content, original_headers, original_status_code):
                    self._content = content
                    self.headers = original_headers 
                    self.status_code = original_status_code
                    # Adicionar Content-Length se não estiver presente ou for transfer-encoding
                    if 'Content-Length' not in self.headers or 'transfer-encoding' in self.headers:
                        self.headers['Content-Length'] = str(len(content))
                    if 'transfer-encoding' in self.headers:
                        del self.headers['transfer-encoding'] # Remover para evitar conflitos

                def iter_content(self, chunk_size=8192):
                    for i in range(0, len(self._content), chunk_size):
                        yield self._content[i:i + chunk_size]
                def close(self):
                    pass

            # Retornar uma MockResponse baseada no conteúdo que acabou de ser cacheado
            return MockResponseCached(content, dict(r.headers), r.status_code) # Passar uma cópia dos headers
        except requests.exceptions.RequestException as e:
            log(f"Error fetching segment from {url}: {e}")
            return None

    def modify_m3u8_for_proxy(self, m3u8_content, base_url):
        lines = m3u8_content.splitlines()
        modified_lines = []
        segment_urls_for_prefetch = []

        # Variável para controlar quantos segmentos à frente prefetch
        # Para streams ao vivo, o M3U8 se atualiza rapidamente, prefetch de 3 a 5 segmentos é razoável.
        # Para VOD, pode prefetch mais.
        PREFETCH_SEGMENT_COUNT = 5 
        current_segment_index = 0

        for line in lines:
            if line.startswith('#EXTINF') or \
               line.startswith('#EXT-X-TARGETDURATION') or \
               line.startswith('#EXT-X-MEDIA-SEQUENCE') or \
               line.startswith('#EXT-X-VERSION') or \
               line.startswith('#EXT-X-PLAYLIST-TYPE') or \
               line.startswith('#EXT-X-ENDLIST') or \
               line.startswith('#EXT-X-DISCONTINUITY') or \
               line.startswith('#EXT-X-MAP') or \
               line.startswith('#EXT-X-BYTERANGE'):
                modified_lines.append(line)
            elif line.startswith('#EXT-X-KEY'):
                key_match = re.search(r'URI="([^"]+)"', line)
                if key_match:
                    key_uri = key_match.group(1)
                    if not urlparse(key_uri).scheme:
                        absolute_key_uri = urljoin(base_url, key_uri)
                        line = line.replace(key_uri, absolute_key_uri)
                modified_lines.append(line)
            elif not line.strip().startswith('#') and line.strip(): 
                segment_url = line.strip()
                if not urlparse(segment_url).scheme:
                    segment_url = urljoin(base_url, segment_url)

                proxied_segment_url = url_segment_proxy_prefix + quote_plus(segment_url)
                
                header_params = []
                for key, value in HEADERS_BASE.items():
                    if key.lower() not in ['connection', 'host']: 
                        header_params.append(f"{quote_plus(key)}={quote_plus(value)}")
                
                if header_params:
                    proxied_segment_url += '&' + '&'.join(header_params)

                modified_lines.append(proxied_segment_url)
                
                # Adicionar apenas os N próximos segmentos para pré-busca
                if current_segment_index < PREFETCH_SEGMENT_COUNT:
                    segment_urls_for_prefetch.append(segment_url) 
                current_segment_index += 1

            else: 
                modified_lines.append(line)
        
        log(f"Queueing {len(segment_urls_for_prefetch)} segments for prefetch.")
        for url in segment_urls_for_prefetch:
            # Coloca apenas se não estiver já na fila (para evitar duplicação em atualizações rápidas)
            # Nota: Queue em Python não tem um método 'contains', então teremos que confiar que
            # a thread de prefetch fará a checagem no cache.
            PREFETCH_QUEUE.put(url)
        
        return "\n".join(modified_lines)

    # --- Métodos HTTP ---
    def do_HEAD(self):
        self.handle_request('HEAD')

    def do_GET(self):
        self.handle_request('GET')

    def handle_request(self, method):
        # Corrigido: Todas as declarações 'global' para variáveis modificadas dentro do método
        # devem estar no topo do método.
        global URL_BASE, LAST_URL, HEADERS_BASE, CACHE_M3U8, STOP_SERVER, CURRENT_CACHE_SIZE_BYTES 

        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)

        if path == '/proxy_m3u8':
            if 'url' in query_params and query_params['url']:
                
                url_to_fetch = unquote_plus(query_params['url'][0])
                
                extracted_headers = {}
                for key, values in query_params.items():
                    if key not in ['url'] and values:
                        extracted_headers[key] = unquote_plus(values[0])

                HEADERS_BASE = {} # Reatribuindo HEADERS_BASE
                for h_key in ['User-Agent', 'Referer', 'Origin', 'Connection', 'Host']:
                    if h_key in extracted_headers:
                        HEADERS_BASE[h_key] = extracted_headers[h_key]
                        del extracted_headers[h_key] 
                
                if 'Connection' not in HEADERS_BASE:
                    HEADERS_BASE['Connection'] = 'keep-alive'
                
                HEADERS_BASE.update(extracted_headers)

                log(f"Received proxy request for URL: {url_to_fetch}")
                log(f"Headers to use: {HEADERS_BASE}")

                if url_to_fetch != LAST_URL:
                    log("URL changed, resetting cache and state.")
                    URL_BASE = ''
                    LAST_URL = ''
                    CACHE_M3U8 = ''
                    with SEGMENT_CACHE_LOCK:
                        SEGMENT_CACHE.clear()
                        CURRENT_CACHE_SIZE_BYTES = 0 # Modificação de CURRENT_CACHE_SIZE_BYTES
                    while not PREFETCH_QUEUE.empty():
                        try:
                            PREFETCH_QUEUE.get_nowait()
                            PREFETCH_QUEUE.task_done()
                        except queue.Empty:
                            pass
                    PREFETCH_STOP_EVENT.clear() 

                LAST_URL = url_to_fetch # Modificação de LAST_URL
                
                m3u8_content, final_url = self.fetch_m3u8(url_to_fetch, HEADERS_BASE)

                if m3u8_content: # Corrigido m3u3_content para m3u8_content
                    if not URL_BASE or (final_url and not final_url.startswith(URL_BASE)):
                        URL_BASE = os.path.dirname(final_url) + '/' if '/' in os.path.dirname(final_url) else final_url
                        log(f"Updated URL_BASE to: {URL_BASE}")
                    
                    CACHE_M3U8 = m3u8_content # Modificação de CACHE_M3U8
                    modified_m3u8 = self.modify_m3u8_for_proxy(m3u8_content, URL_BASE)
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/x-mpegURL')
                    self.end_headers()
                    self.wfile.write(modified_m3u8.encode('utf-8'))
                else:
                    log(f"Failed to fetch M3U8 for {url_to_fetch}")
                    self.send_response(404)
                    self.end_headers()
            else:
                log("Missing 'url' parameter in proxy request.")
                self.send_response(400)
                self.end_headers()

        elif path.startswith('/proxy_segment/'):
            encoded_segment_url_and_params = self.path[len('/proxy_segment/'):]
            
            parts = encoded_segment_url_and_params.split('&', 1)
            segment_url_decoded = unquote_plus(parts[0])
            
            segment_query_params = {}
            if len(parts) > 1:
                temp_query_string = parts[1]
                segment_query_params = parse_qs(temp_query_string)

            segment_headers = {}
            for key, values in segment_query_params.items():
                if values:
                    segment_headers[key] = unquote_plus(values[0])
            
            current_segment_headers = HEADERS_BASE.copy()
            current_segment_headers.update(segment_headers)

            log(f"Received proxy request for segment: {segment_url_decoded}")
            log(f"Headers for segment: {current_segment_headers}")

            segment_response = self.fetch_chunk(segment_url_decoded, current_segment_headers)
            if segment_response:
                self.send_response(200)
                for header, value in segment_response.headers.items():
                    if header.lower() not in ['transfer-encoding', 'content-encoding', 'connection', 'content-length']:
                        self.send_header(header, value)
                
                # Ensure Content-Length is set if it's from cache or has been processed
                if 'Content-Length' not in segment_response.headers and hasattr(segment_response, '_content'):
                    self.send_header('Content-Length', str(len(segment_response._content)))
                
                self.end_headers()
                
                try:
                    for chunk in segment_response.iter_content(chunk_size=8192):
                        self.wfile.write(chunk)
                except Exception as e:
                    log(f"Error streaming segment content: {e}")
                finally:
                    segment_response.close()
            else:
                self.send_response(404)
                self.end_headers()
        
        elif path == '/check':
            log("HEAD /check received. Server is responsive.")
            self.send_response(200)
            self.end_headers()

        elif path == '/stop':
            log("HEAD /stop received. Initiating server shutdown.")
            STOP_SERVER = True # Modificação de STOP_SERVER
            
            URL_BASE = ''
            LAST_URL = ''
            HEADERS_BASE = {}
            CACHE_M3U8 = ''
            
            PREFETCH_STOP_EVENT.set()
            while not PREFETCH_QUEUE.empty():
                try:
                    PREFETCH_QUEUE.get_nowait()
                    PREFETCH_QUEUE.task_done()
                except queue.Empty:
                    pass
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE.clear()
                CURRENT_CACHE_SIZE_BYTES = 0 # Modificação de CURRENT_CACHE_SIZE_BYTES
            log("All global proxy variables and segment cache have been reset. Prefetch threads signaled to stop.")
            
            self.send_response(200)
            self.end_headers()

        elif path == '/reset':
            log("HEAD /reset received. Resetting global states.")
            URL_BASE = ''
            LAST_URL = ''
            HEADERS_BASE = {}
            CACHE_M3U8 = ''

            PREFETCH_STOP_EVENT.set()
            while not PREFETCH_QUEUE.empty():
                try:
                    PREFETCH_QUEUE.get_nowait()
                    PREFETCH_QUEUE.task_done()
                except queue.Empty:
                    pass
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE.clear()
                CURRENT_CACHE_SIZE_BYTES = 0 # Modificação de CURRENT_CACHE_SIZE_BYTES
            
            PREFETCH_STOP_EVENT.clear() 
            
            log("All global proxy variables and segment cache have been reset.")
            
            self.send_response(200)
            self.end_headers()
        else:
            log(f"{method} request for unknown path: {self.path}")
            self.send_response(404)
            self.end_headers()

# --- Classe do Servidor HTTP Threaded ---
class ThreadedHTTPServer(threading.Thread):
    def __init__(self, host, port):
        super(ThreadedHTTPServer, self).__init__()
        self.daemon = True 
        self.host = host
        self.port = port
        self.server = None
        self.running = False
        self.prefetch_threads = [] 
        log("Server thread initialized.")

    def run(self):
        try:
            PREFETCH_STOP_EVENT.clear() 
            self.prefetch_threads = []
            for i in range(PREFETCH_WORKERS):
                thread = PrefetchThread(PREFETCH_QUEUE, SEGMENT_CACHE, SEGMENT_CACHE_LOCK, PREFETCH_STOP_EVENT, HEADERS_BASE.copy())
                thread.start()
                self.prefetch_threads.append(thread)
            log(f"{PREFETCH_WORKERS} prefetch threads started.")

            self.server = HTTPServer((self.host, self.port), ProxyHandler)
            log(f"Server initialized and listening on {self.host}:{self.port}")
            self.running = True
            self.server.serve_forever()
        except Exception as e:
            log(f"Error starting HTTP server: {e}")
        finally:
            self.running = False
            if self.server:
                self.server.server_close() 
            PREFETCH_STOP_EVENT.set()
            for thread in self.prefetch_threads:
                thread.join(timeout=2) 
                if thread.is_alive():
                    log(f"Warning: Prefetch thread {thread.name} did not terminate gracefully.")
            log("HTTP server stopped and prefetch threads joined.")

# --- Classe de Controle do Servidor ---
class Server:
    def __init__(self):
        # STOP_SERVER é global e modificado aqui, então precisa da declaração
        global STOP_SERVER 
        STOP_SERVER = False 
        self.server_thread = ThreadedHTTPServer(HOST_NAME, PORT_NUMBER)
        self.server_thread_ok = True 
        log("Server controller initialized, thread created.")

    def in_use(self):
        url = url_check 
        try:
            r = REQUESTS_SESSION.head(url, timeout=1)
            if r.status_code == 200:
                log("Server is already in use.")
                r.close()
                return True
            r.close()
        except requests.exceptions.RequestException as e:
            log(f"Server not responsive or not running: {e}")
        return False

    def start(self):
        # STOP_SERVER é global e modificado aqui indiretamente via url_reset, precisa da declaração
        global STOP_SERVER 
        if not self.in_use():
            if self.server_thread_ok:
                log("Starting new server thread.")
                self.server_thread.start()
                time.sleep(1.0) 
                if not self.in_use():
                    log("Warning: Server thread started but not responding to /check immediately. Retrying start or checking.")
            else:
                log("Server thread not initialized successfully, cannot start.")
        else:
            log("Server already in use. Resetting global states for a new session.")
            url = url_reset 
            try:
                r = REQUESTS_SESSION.head(url, timeout=2)
                r.close()
                log("Sent reset command to existing server.")
            except requests.exceptions.RequestException as e:
                log(f"Failed to send reset command to existing server: {e}. Consider restarting Kodi or checking port.")

# --- Funções de Utilitário para o Kodi ---
def get_hls_url(url, headers=None):
    # url_proxy e HEADERS_BASE são globais e modificados/usados aqui, precisam da declaração
    global url_proxy, HEADERS_BASE 
    
    if headers:
        HEADERS_BASE.update(headers)
    
    proxied_url = url_proxy + quote_plus(url)
    
    for key, value in HEADERS_BASE.items():
        proxied_url += f"&{quote_plus(key)}={quote_plus(value)}"
    
    log(f"Constructed proxied HLS URL: {proxied_url}")
    return proxied_url

def stop_all_proxies():
    # STOP_SERVER e CURRENT_CACHE_SIZE_BYTES são globais e modificados aqui, precisam da declaração
    global STOP_SERVER, CURRENT_CACHE_SIZE_BYTES 
    STOP_SERVER = True
    log("Attempting to stop proxy server...")
    try:
        r = REQUESTS_SESSION.head(url_stop, timeout=5)
        r.close()
        log(f"Stop command sent to proxy server. Status: {r.status_code}")
    except requests.exceptions.RequestException as e:
        log(f"Failed to send stop command to proxy server: {e}")
    
    while not PREFETCH_QUEUE.empty():
        try:
            PREFETCH_QUEUE.get_nowait()
            PREFETCH_QUEUE.task_done()
        except queue.Empty:
            pass
    with SEGMENT_CACHE_LOCK:
        SEGMENT_CACHE.clear()
        CURRENT_CACHE_SIZE_BYTES = 0 # Modificação de CURRENT_CACHE_SIZE_BYTES
    
    PREFETCH_STOP_EVENT.clear() 

# Instanciar o servidor principal (Server controller)
iniciavideo = Server()