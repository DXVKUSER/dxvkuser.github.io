import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import re

# Importa a biblioteca requests original e seus componentes necessários
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Importa o wrapper do requests do netunblock com um apelido para evitar conflito
from doh_client import requests as doh_requests

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------
CONFIG = {
    "MAX_SEGMENT_RETRIES": 15,
    "RETRY_BACKOFF_FACTOR": 0.5,  # não usado mais, mas deixei para compat
    "CONNECTION_TIMEOUT": 15,
    "STREAM_TIMEOUT": 60.0,
    "DEFAULT_CHUNK_SIZE": 1024 * 256,
    "PROXY_HOST": '127.0.0.1',
    "MAX_PORT_ATTEMPTS": 20,
    "LOG_FILE": "hls_proxy_aprimorado.log",
    "MANIFEST_RETRY_DELAY": 1.0,
    "MAX_CONSECUTIVE_SEGMENT_ERRORS": 3,   # reage rápido
    "MANIFEST_DEFAULT_TTL_SECONDS": 3,
    "BASE_USER_AGENT": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/{version}.0.4472.124 Safari/537.36"
}

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------
def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), CONFIG['LOG_FILE'])
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    logging.info("HLS Proxy Aprimorado Iniciado")


def generate_rotating_user_agent():
    """Gera um User-Agent Chrome fixo mas com versão variável"""
    version = random.randint(90, 125)  # faixa de versões plausíveis do Chrome
    return CONFIG["BASE_USER_AGENT"].format(version=version)


def get_forward_headers(client_headers):
    headers = {
        'User-Agent': generate_rotating_user_agent(),
    }
    for header in ['Authorization', 'Cookie', 'Referer']:
        if header in client_headers:
            headers[header] = client_headers[header]
    return headers


# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    session = doh_requests.session
    retry_strategy = Retry(
        total=CONFIG['MAX_SEGMENT_RETRIES'],
        backoff_factor=CONFIG['RETRY_BACKOFF_FACTOR'],
        status_forcelist=[429, 500, 502, 503, 504, 403]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount('http://', adapter)
    session.mount('https://', adapter)

    manifest_cache = {}
    cache_lock = threading.Lock()
    error_counter = {}

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404, "URL parameter missing")
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400, "URL parameter is empty")
                return

            headers = get_forward_headers(self.headers)
            parsed_url = urllib.parse.urlparse(url)

            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, head_only)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado no GET: {e}", exc_info=True)
            if not self.wfile.closed:
                self.send_error(500)

    def _rewrite_manifest_urls(self, manifest_content, base_url):
        new_lines = []
        for line in manifest_content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                if stripped.startswith('#EXT-X-KEY'):
                    uri_match = re.search(r'URI="([^"]+)"', stripped)
                    if uri_match:
                        key_url = uri_match.group(1)
                        full_key_url = urllib.parse.urljoin(base_url, key_url)
                        proxy_key_url = f"http://{CONFIG['PROXY_HOST']}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_key_url)}"
                        new_line = stripped.replace(key_url, proxy_key_url)
                        new_lines.append(new_line)
                        continue
                new_lines.append(line)
            else:
                full_segment_url = urllib.parse.urljoin(base_url, stripped)
                proxy_segment_url = f"http://{CONFIG['PROXY_HOST']}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}"
                new_lines.append(proxy_segment_url)
        return '\n'.join(new_lines)

    def _handle_manifest(self, url, headers, head_only):
        try:
            r = self.session.get(url, headers=headers, timeout=CONFIG['CONNECTION_TIMEOUT'], verify=False, allow_redirects=True)
            r.raise_for_status()

            manifest_content = r.text
            base_url = r.url

            target_duration_match = re.search(r'#EXT-X-TARGETDURATION:(\d+)', manifest_content)
            if target_duration_match:
                ttl = max(int(target_duration_match.group(1)), CONFIG['MANIFEST_DEFAULT_TTL_SECONDS'])
            else:
                ttl = CONFIG['MANIFEST_DEFAULT_TTL_SECONDS']

            with self.cache_lock:
                self.manifest_cache[url] = {
                    'content': manifest_content,
                    'base_url': base_url,
                    'expires': time.time() + ttl
                }

        except requests.exceptions.RequestException as e:
            logging.error(f"Falha ao obter manifesto {url}: {e}")
            with self.cache_lock:
                cached = self.manifest_cache.get(url)
                if cached:
                    manifest_content = cached['content']
                    base_url = cached['base_url']
                else:
                    self.send_error(502, "Falha ao obter manifesto")
                    return

        rewritten_manifest = self._rewrite_manifest_urls(manifest_content, base_url)

        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.end_headers()

        if not head_only:
            self.wfile.write(rewritten_manifest.encode('utf-8'))

    def _handle_segment(self, url, session_id, headers, head_only):
        retries = 0
        success = False

        while retries < CONFIG['MAX_SEGMENT_RETRIES']:
            try:
                with self.session.get(url, headers=headers, stream=True, timeout=CONFIG['STREAM_TIMEOUT'], verify=False) as r:
                    r.raise_for_status()

                    self.send_response(r.status_code)
                    for header, value in r.headers.items():
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.send_header(header, value)
                    self.end_headers()

                    if head_only:
                        return

                    for chunk in r.iter_content(chunk_size=CONFIG['DEFAULT_CHUNK_SIZE']):
                        if chunk:
                            self.wfile.write(chunk)

                    # Resetar contador de erros ao sucesso
                    self.error_counter[session_id] = 0
                    success = True
                    return

            except requests.exceptions.RequestException:
                retries += 1
                time.sleep(0.5)  # 👈 atraso fixo curto
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception:
                break

        if not success:
            # Incrementa contador de falhas
            current_errors = self.error_counter.get(session_id, 0) + 1
            self.error_counter[session_id] = current_errors
            logging.warning(f"Segmento falhou ({current_errors}x) - {url}")

            # Se passou do limite, força refresh do manifesto
            if current_errors >= CONFIG['MAX_CONSECUTIVE_SEGMENT_ERRORS']:
                logging.warning(f"Forçando refresh do manifesto para sessão {session_id}")
                with self.cache_lock:
                    self.manifest_cache.clear()
                self.error_counter[session_id] = 0

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie, Referer')
        self.end_headers()


# ---------------- MANAGER ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(CONFIG['MAX_PORT_ATTEMPTS']):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((CONFIG['PROXY_HOST'], port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy HLS iniciado em http://{CONFIG['PROXY_HOST']}:{port}")
                return True
            except OSError:
                continue
        logging.error("Não foi possível iniciar o proxy em nenhuma porta disponível.")
        return False


# ---------------- KODI ADDON INTEGRATION ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro no Proxy", "Não foi possível iniciar o servidor proxy local.", xbmcgui.NOTIFICATION_ERROR)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{CONFIG['PROXY_HOST']}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        li = xbmcgui.ListItem(path=proxy_url, label=title or "HLS Stream")
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")

        if stype == "live":
            li.setProperty("IsLive", "true")

        xbmcplugin.setResolvedUrl(self.handle, True, li)


def main():
    setup_logging()
    try:
        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', ['vod'])[0]
            title = args.get('title', [None])[0]
            if stream_url:
                addon.play_stream(stream_url, stream_type, title)
            else:
                xbmcplugin.endOfDirectory(h, succeeded=False)
        else:
            xbmcplugin.endOfDirectory(h)
    except Exception as e:
        logging.error(f"Erro fatal na função main: {e}", exc_info=True)


if __name__ == '__main__':
    main()