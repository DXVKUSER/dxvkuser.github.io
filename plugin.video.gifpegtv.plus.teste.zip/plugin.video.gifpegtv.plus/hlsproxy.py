import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import urllib3
import time
import random
import base64
from collections import OrderedDict

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------
# LRU CACHE COM LIMITE DE TAMANHO
# ---------------------------------------------------------------
class LRUCache:
    def __init__(self, maxsize=200):
        self._data    = OrderedDict()
        self._maxsize = maxsize
        self._lock    = threading.Lock()

    def get(self, key, default=None):
        with self._lock:
            if key not in self._data:
                return default
            self._data.move_to_end(key)
            return self._data[key]

    def set(self, key, value):
        with self._lock:
            if key in self._data:
                self._data.move_to_end(key)
            self._data[key] = value
            if len(self._data) > self._maxsize:
                self._data.popitem(last=False)

    def pop(self, key, default=None):
        with self._lock:
            return self._data.pop(key, default)

    def delete(self, key):
        with self._lock:
            self._data.pop(key, None)

    def clear(self):
        with self._lock:
            self._data.clear()

    def __contains__(self, key):
        with self._lock:
            return key in self._data

    def __len__(self):
        with self._lock:
            return len(self._data)


# ---------------------------------------------------------------
# ESTADO GLOBAL DA SESSÃO
# ---------------------------------------------------------------
URL_CACHE         = LRUCache(maxsize=200)
PLAYLIST_SEQUENCE = LRUCache(maxsize=20)

PREFETCH_CACHE      = OrderedDict()
PREFETCH_LOCK       = threading.Lock()
PREFETCH_MAX_ENTRIES = 5
PREFETCH_MAX_BYTES   = 20 * 1024 * 1024  # 20MB

_LAST_URL_LOCK = threading.Lock()
LAST_KNOWN_URL = None

# ---------------------------------------------------------------
# URL ORIGINAL DO CANAL ATIVO — usada para renovação de token
# ---------------------------------------------------------------
_ORIGINAL_URL_LOCK   = threading.Lock()
_CURRENT_ORIGINAL_URL = None   # ex.: http://ip10.cfd:80/live/.../127031.m3u8

def set_original_url(url):
    global _CURRENT_ORIGINAL_URL
    with _ORIGINAL_URL_LOCK:
        _CURRENT_ORIGINAL_URL = url

def get_original_url():
    with _ORIGINAL_URL_LOCK:
        return _CURRENT_ORIGINAL_URL

# ---------------------------------------------------------------
# SESSÃO HTTP PERSISTENTE
# Uma única sessão para toda a vida do proxy.
# Só é recriada em caso de falha de rede (reset_session).
# Fechada explicitamente em HLSAddon.stop().
# ---------------------------------------------------------------
SESSION      = requests.Session()
_SESSION_LOCK = threading.Lock()

def _build_adapter():
    return requests.adapters.HTTPAdapter(
        pool_connections=10, pool_maxsize=10, max_retries=1
    )

SESSION.mount('http://',  _build_adapter())
SESSION.mount('https://', _build_adapter())

def reset_session():
    """Recria a sessão quando há falha de rede — rotaciona UA na recriação."""
    global SESSION
    with _SESSION_LOCK:
        try:
            SESSION.close()
        except Exception:
            pass
        SESSION = requests.Session()
        SESSION.mount('http://',  _build_adapter())
        SESSION.mount('https://', _build_adapter())
    # Avança o índice de UA para que a próxima requisição use identidade nova
    next_ua()
    print("[PROXY] Sessão HTTP reiniciada por falha de rede (UA rotacionado).")

def get_session():
    with _SESSION_LOCK:
        return SESSION

def close_session():
    """Fecha a sessão de forma limpa — chamado apenas em HLSAddon.stop()."""
    with _SESSION_LOCK:
        try:
            SESSION.close()
        except Exception:
            pass
    print("[PROXY] Sessão HTTP encerrada.")

# ---------------------------------------------------------------
# USER-AGENTS
# ---------------------------------------------------------------
UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.119 Mobile Safari/537.36",
]

_UA_INDEX_LOCK = threading.Lock()
_UA_INDEX = 0

def next_ua():
    global _UA_INDEX
    with _UA_INDEX_LOCK:
        ua = UAS[_UA_INDEX % len(UAS)]
        _UA_INDEX += 1
    return ua

def random_ua():
    return random.choice(UAS)

# ---------------------------------------------------------------
# LAST_KNOWN_URL thread-safe
# ---------------------------------------------------------------
def set_last_known_url(url):
    global LAST_KNOWN_URL
    with _LAST_URL_LOCK:
        LAST_KNOWN_URL = url

def get_last_known_url():
    with _LAST_URL_LOCK:
        return LAST_KNOWN_URL

# ---------------------------------------------------------------
# LIMPEZA DE ESTADO ENTRE CANAIS
# Chamado quando o usuário troca de canal.
# NÃO fecha a sessão HTTP — só descarta caches da stream anterior.
# ---------------------------------------------------------------
def clear_stream_state():
    URL_CACHE.clear()
    PLAYLIST_SEQUENCE.clear()
    with PREFETCH_LOCK:
        PREFETCH_CACHE.clear()
    set_last_known_url(None)
    set_original_url(None)
    print("[PROXY] Estado de stream limpo (troca de canal).")

# ---------------------------------------------------------------
# HTTP SERVER
# ---------------------------------------------------------------
class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

# ---------------------------------------------------------------
# CABEÇALHOS
# ---------------------------------------------------------------
def get_anti_block_headers(url, referer=None, ua=None):
    parsed = urllib.parse.urlparse(url)
    return {
        'User-Agent':                ua if ua else random_ua(),
        'Accept':                   '*/*',
        'Accept-Encoding':          'gzip, deflate, br',
        'Accept-Language':          'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection':               'keep-alive',
        'Host':                     parsed.netloc,
        'Origin':                   f"{parsed.scheme}://{parsed.netloc}",
        'Referer':                  referer if referer else f"{parsed.scheme}://{parsed.netloc}/",
        'Sec-Fetch-Dest':           'empty',
        'Sec-Fetch-Mode':           'cors',
        'Sec-Fetch-Site':           'same-origin',
        'Cache-Control':            'no-cache',
        'Pragma':                   'no-cache',
        'DNT':                      '1',
        'Upgrade-Insecure-Requests':'1',
        'X-Forwarded-For': (
            f"{random.randint(1,255)}.{random.randint(1,255)}."
            f"{random.randint(1,255)}.{random.randint(1,255)}"
        ),
        'X-Forwarded-Host':  parsed.netloc,
        'X-Forwarded-Proto': parsed.scheme,
    }

def invalidate_cache(cache_key):
    URL_CACHE.delete(cache_key)

# ---------------------------------------------------------------
# RENOVAÇÃO FORÇADA DE TOKEN
# Segue redirects da URL original até obter a URL CDN com token novo.
# Retorna (nova_url_resolvida, novo_token_url_base) ou (None, None).
# ---------------------------------------------------------------
def force_fresh_token(original_url, reason="token expirado"):
    """
    Conecta na URL original do canal (ex.: http://ip10.cfd:80/live/.../127031.m3u8)
    e segue os redirects manualmente até a URL CDN com novo token.
    Invalida todo o cache do canal e atualiza URL_CACHE com o novo token.
    Retorna a nova URL resolvida (CDN com token) ou None em caso de falha total.
    """
    if not original_url:
        print("[PROXY] force_fresh_token: URL original não disponível.")
        return None

    print(f"[PROXY] force_fresh_token → razão: {reason} | original: {original_url}")

    # Invalida todo cache para forçar uso do novo token
    URL_CACHE.clear()

    max_redirects = 12
    current_url   = original_url

    try:
        sess = get_session()
        for hop in range(max_redirects):
            ua      = next_ua()   # UA novo a cada hop para evitar bloqueio
            headers = get_anti_block_headers(current_url, ua=ua)
            resp = sess.get(
                current_url, headers=headers, stream=True,
                timeout=(5.0, 15.0), allow_redirects=False, verify=False
            )

            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get('Location', '').strip()
                resp.close()
                if not location:
                    print(f"[PROXY] force_fresh_token: redirect sem Location no hop {hop}.")
                    break
                current_url = urllib.parse.urljoin(current_url, location)
                print(f"[PROXY] force_fresh_token: hop {hop+1} → {current_url[:80]}...")
                continue

            if resp.status_code == 200:
                content = resp.content
                resp.close()
                if b'#EXTM3U' in content:
                    print(f"[PROXY] force_fresh_token: novo token obtido → {current_url[:80]}...")
                    # Armazena a nova URL resolvida no cache
                    URL_CACHE.set(original_url, current_url)
                    set_last_known_url(current_url)
                    return current_url
                else:
                    print(f"[PROXY] force_fresh_token: 200 sem #EXTM3U — conteúdo inesperado.")
                    break

            # Erro definitivo
            print(f"[PROXY] force_fresh_token: status {resp.status_code} na URL original.")
            resp.close()
            break

    except requests.exceptions.ConnectionError as e:
        print(f"[PROXY] force_fresh_token: ConnectionError: {e} → reiniciando sessão.")
        reset_session()
    except requests.exceptions.Timeout:
        print(f"[PROXY] force_fresh_token: Timeout na URL original.")
    except Exception as e:
        print(f"[PROXY] force_fresh_token: Erro inesperado: {e}")

    print(f"[PROXY] force_fresh_token: FALHOU para {original_url}")
    return None


# ---------------------------------------------------------------
# FETCH CONTENT
# Prioridade: URL resolvida com token (cache) → falha → força token novo via URL original
# ---------------------------------------------------------------
def fetch_content(url, expected_type='m3u8', referer=None):
    cache_key     = (url, referer) if referer else url
    cached_target = URL_CACHE.get(cache_key)
    req_timeout   = (4.0, 8.0) if expected_type == 'ts' else (4.0, 18.0)

    # --- Cache hit: tenta URL resolvida com token ---
    if cached_target:
        token_failed = False
        try:
            ua      = next_ua()
            headers = get_anti_block_headers(cached_target, referer, ua=ua)
            sess    = get_session()
            resp    = sess.get(
                cached_target, headers=headers, stream=True,
                timeout=req_timeout, allow_redirects=False, verify=False
            )

            if resp.status_code == 200:
                if expected_type == 'm3u8':
                    content = resp.content
                    resp.close()
                    if b'#EXTM3U' in content:
                        fake = type('R', (), {
                            '_cached_content': content,
                            'close': lambda self: None
                        })()
                        return fake, cached_target
                elif expected_type == 'ts':
                    first_byte = resp.raw.read(1)
                    if first_byte == b'\x47':
                        resp._first_byte = first_byte
                        resp._target_url = cached_target
                        resp._referer    = referer
                        return resp, cached_target
                    resp.close()
                elif expected_type == 'key':
                    resp._cached_content = resp.content
                    return resp, cached_target

            if resp.status_code in (401, 403, 404, 410):
                print(f"[PROXY] Token expirado no cache ({resp.status_code}) → forçando renovação (UA rotacionado).")
                resp.close()
                invalidate_cache(cache_key)
                if resp.status_code in (401, 403):
                    get_session().cookies.clear()
                # Rotaciona UA imediatamente na detecção de bloqueio
                next_ua()
                token_failed = True
            else:
                resp.close()

        except requests.exceptions.ConnectionError as e:
            print(f"[PROXY] Conexão morta no cache: {e} → forçando renovação de token.")
            invalidate_cache(cache_key)
            reset_session()
            token_failed = True
        except requests.exceptions.Timeout:
            print(f"[PROXY] Timeout no cache → forçando renovação de token.")
            invalidate_cache(cache_key)
            token_failed = True
        except Exception as e:
            print(f"[PROXY] Erro no cache: {e} → forçando renovação de token.")
            invalidate_cache(cache_key)
            token_failed = True

        # --- Falha na URL com token: força renovação via URL original ---
        if token_failed:
            original_url = get_original_url()
            if original_url:
                new_resolved = force_fresh_token(
                    original_url,
                    reason=f"cache falhou para {expected_type}"
                )
                if new_resolved:
                    # Atualiza a URL alvo para a nova URL resolvida e continua o fetch normal
                    url = new_resolved
                    # Recalcula cache_key para a nova URL raiz
                    cache_key = (url, referer) if referer else url
                    print(f"[PROXY] Retomando fetch com novo token: {url[:80]}...")
                else:
                    print(f"[PROXY] Renovação de token FALHOU — abortando fetch.")
                    return None, url
            else:
                print(f"[PROXY] Sem URL original disponível para renovar token.")
                # Continua para tentativa fresh abaixo (url ainda é a original da requisição)

    # --- Fresh fetch com redirect manual ---
    max_redirects   = 10
    max_retries     = 4
    consec_failures = 0

    for attempt in range(max_retries):
        current_url     = url
        current_referer = referer
        ua = next_ua()

        if consec_failures >= 2:
            print(f"[PROXY] {consec_failures} falhas consecutivas → reiniciando sessão.")
            reset_session()
            consec_failures = 0
            time.sleep(1.0)

        try:
            for _ in range(max_redirects):
                headers = get_anti_block_headers(current_url, current_referer, ua=ua)
                sess    = get_session()
                resp    = sess.get(
                    current_url, headers=headers, stream=True,
                    timeout=req_timeout, allow_redirects=False, verify=False
                )

                if resp.status_code in (401, 403):
                    print(f"[PROXY] Auth falhou ({resp.status_code}) tentativa {attempt+1}.")
                    resp.close()
                    get_session().cookies.clear()
                    # Tenta renovar token via URL original se for primeira vez nesta tentativa
                    if attempt == 0:
                        original_url = get_original_url()
                        if original_url and original_url != url:
                            new_resolved = force_fresh_token(
                                original_url,
                                reason=f"auth {resp.status_code} no fresh fetch"
                            )
                            if new_resolved:
                                url       = new_resolved
                                cache_key = (url, referer) if referer else url
                    break

                if resp.status_code in (404, 410):
                    print(f"[PROXY] Recurso não encontrado ({resp.status_code}). Tentativa {attempt+1}.")
                    resp.close()
                    # Tenta renovar via URL original antes de desistir definitivamente
                    if attempt < max_retries - 1:
                        original_url = get_original_url()
                        if original_url and original_url != url:
                            new_resolved = force_fresh_token(
                                original_url,
                                reason=f"404/410 no fresh fetch"
                            )
                            if new_resolved:
                                url       = new_resolved
                                cache_key = (url, referer) if referer else url
                                break  # volta pro loop de attempt com nova URL
                    else:
                        return None, current_url
                    break

                if resp.status_code in (301, 302, 303, 307, 308):
                    location = resp.headers.get('Location')
                    resp.close()
                    if not location:
                        break
                    current_referer = current_url
                    current_url     = urllib.parse.urljoin(current_url, location)
                    continue

                if resp.status_code == 200:
                    if expected_type == 'm3u8':
                        content = resp.content
                        resp.close()
                        if b'#EXTM3U' in content:
                            fake = type('R', (), {
                                '_cached_content': content,
                                'close': lambda self: None
                            })()
                            URL_CACHE.set(cache_key, current_url)
                            consec_failures = 0
                            return fake, current_url
                        else:
                            print(f"[PROXY] 200 sem #EXTM3U. Tentativa {attempt+1}.")
                            break

                    elif expected_type == 'ts':
                        first_byte = resp.raw.read(1)
                        if first_byte == b'\x47':
                            resp._first_byte = first_byte
                            resp._target_url = current_url
                            resp._referer    = current_referer
                            URL_CACHE.set(cache_key, current_url)
                            consec_failures = 0
                            return resp, current_url
                        else:
                            resp.close()
                            print(f"[PROXY] TS sem sync 0x47. Tentativa {attempt+1}.")
                            break

                    elif expected_type == 'key':
                        resp._cached_content = resp.content
                        URL_CACHE.set(cache_key, current_url)
                        consec_failures = 0
                        return resp, current_url

                resp.close()
                break

        except requests.exceptions.ConnectionError as e:
            consec_failures += 1
            print(f"[PROXY] ConnectionError tentativa {attempt+1}: {e}")
            # Falha de conexão total na URL resolvida → tenta renovar via original
            if attempt == 0:
                original_url = get_original_url()
                if original_url and original_url != url:
                    print(f"[PROXY] ConnectionError → forçando token via URL original.")
                    new_resolved = force_fresh_token(
                        original_url,
                        reason="ConnectionError no fresh fetch"
                    )
                    if new_resolved:
                        url       = new_resolved
                        cache_key = (url, referer) if referer else url
        except requests.exceptions.Timeout:
            consec_failures += 1
            print(f"[PROXY] Timeout tentativa {attempt+1}.")
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            return None, current_url
        except Exception as e:
            consec_failures += 1
            print(f"[PROXY] Erro inesperado tentativa {attempt+1}: {e}")

        if attempt < max_retries - 1:
            delay = 0.5 * (attempt + 1)
            print(f"[PROXY] Aguardando {delay:.1f}s antes da tentativa {attempt+2}…")
            time.sleep(delay)

    # --- Todas as tentativas falharam: último recurso — força token via URL original ---
    original_url = get_original_url()
    if original_url and original_url != url:
        print(f"[PROXY] Todas as tentativas falharam → último recurso: URL original.")
        new_resolved = force_fresh_token(
            original_url,
            reason="todas as tentativas falharam"
        )
        if new_resolved:
            # Uma última tentativa direta com o token novo
            try:
                ua      = next_ua()
                headers = get_anti_block_headers(new_resolved, referer, ua=ua)
                sess    = get_session()
                resp    = sess.get(
                    new_resolved, headers=headers, stream=True,
                    timeout=req_timeout, allow_redirects=False, verify=False
                )
                if resp.status_code == 200:
                    if expected_type == 'm3u8':
                        content = resp.content
                        resp.close()
                        if b'#EXTM3U' in content:
                            fake = type('R', (), {
                                '_cached_content': content,
                                'close': lambda self: None
                            })()
                            return fake, new_resolved
                    elif expected_type == 'ts':
                        first_byte = resp.raw.read(1)
                        if first_byte == b'\x47':
                            resp._first_byte = first_byte
                            resp._target_url = new_resolved
                            resp._referer    = referer
                            return resp, new_resolved
                        resp.close()
                    elif expected_type == 'key':
                        resp._cached_content = resp.content
                        return resp, new_resolved
                else:
                    resp.close()
            except Exception as e:
                print(f"[PROXY] Último recurso falhou: {e}")

    print(f"[PROXY] Todas as {max_retries} tentativas + renovação falharam para {url}")
    return None, url

# ---------------------------------------------------------------
# PREFETCH WORKER
# ---------------------------------------------------------------
def prefetch_worker(ts_url, referer):
    try:
        with PREFETCH_LOCK:
            if ts_url in PREFETCH_CACHE:
                return

        ua      = next_ua()
        headers = get_anti_block_headers(ts_url, referer, ua=ua)
        sess    = get_session()
        resp    = sess.get(ts_url, headers=headers, timeout=(4.0, 22.0),
                           verify=False, stream=True)

        if resp.status_code == 200:
            chunks = []
            total  = 0
            for chunk in resp.iter_content(chunk_size=65536):
                if not chunk:
                    continue
                total += len(chunk)
                if total > PREFETCH_MAX_BYTES:
                    print(f"[PREFETCH] Segmento excede limite — descartando.")
                    resp.close()
                    return
                chunks.append(chunk)
            content = b''.join(chunks)
            if content and content[0] == 0x47:
                with PREFETCH_LOCK:
                    if len(PREFETCH_CACHE) >= PREFETCH_MAX_ENTRIES:
                        PREFETCH_CACHE.popitem(last=False)
                    PREFETCH_CACHE[ts_url] = content
        elif resp.status_code in (401, 403):
            cache_key = (ts_url, referer) if referer else ts_url
            invalidate_cache(cache_key)

        resp.close()
    except Exception:
        pass

# ---------------------------------------------------------------
# REQUEST HANDLER
# ---------------------------------------------------------------
class ProxyHTTPRequestHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass

    def decode_path(self, path):
        try:
            parts = path.strip("/").split("/")
            if len(parts) != 2:
                return None, None, None
            prefix, filename = parts
            PREFIX_MAP = {"playlist": "m3u8", "segment": "ts", "key": "key"}
            req_type = PREFIX_MAP.get(prefix)
            if req_type is None:
                return None, None, None
            b64  = filename.rsplit(".", 1)[0]
            b64 += "=" * ((4 - len(b64) % 4) % 4)
            decoded      = base64.urlsafe_b64decode(b64).decode('utf-8')
            url, referer = decoded.split("|", 1)
            return req_type, url, referer
        except Exception:
            return None, None, None

    def make_proxy_url(self, req_type, url, referer):
        payload = f"{url}|{referer}".encode('utf-8')
        b64     = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        ext     = "m3u8" if req_type == "m3u8" else "ts" if req_type == "ts" else "key"
        prefix  = "playlist" if req_type == "m3u8" else "segment" if req_type == "ts" else "key"
        host, port = self.server.server_address
        return f"http://{host}:{port}/{prefix}/{b64}.{ext}"

    def do_HEAD(self):
        self.send_response(200)
        if self.path.startswith('/playlist/'):
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        elif self.path.startswith('/segment/'):
            self.send_header('Content-Type', 'video/mp2t')
        else:
            self.send_header('Content-Type', 'application/octet-stream')
        self._send_cors_headers()
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.send_header('Access-Control-Max-Age', '86400')
        self.end_headers()

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path        = parsed_path.path
        req_type, target_url, referer = self.decode_path(path)

        if not target_url:
            last = get_last_known_url()
            if last and (path.endswith('.ts') or '.ts?' in self.path):
                target_url = urllib.parse.urljoin(last, self.path.lstrip('/'))
                req_type   = 'ts'
                referer    = last
            elif last and (path.endswith('.key') or path.endswith('.bin')):
                target_url = urllib.parse.urljoin(last, self.path.lstrip('/'))
                req_type   = 'key'
                referer    = last
            else:
                # NUNCA retornar 4xx ao Kodi — fallback silencioso
                print(f"[PROXY] Rota inválida: {self.path} → fallback m3u8")
                self._send_fallback('m3u8')
                return
        else:
            if req_type == 'm3u8':
                set_last_known_url(target_url)

        if referer:
            referer = urllib.parse.unquote(referer)
        else:
            referer = None

        if req_type == 'ts':
            with PREFETCH_LOCK:
                cached_data = PREFETCH_CACHE.pop(target_url, None)
            if cached_data:
                self.send_response(200)
                self.send_header('Content-Type',   'video/mp2t')
                self.send_header('Content-Length', str(len(cached_data)))
                self.send_anti_block_headers()
                self.end_headers()
                try:
                    self.wfile.write(cached_data)
                except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                    pass
                return

        resp, final_url = fetch_content(target_url, req_type, referer)

        if not resp:
            self._send_fallback(req_type)
            return

        if req_type == 'm3u8':
            self._handle_m3u8(resp, final_url)
        elif req_type == 'ts':
            self._handle_ts(resp, target_url, referer)
        elif req_type == 'key':
            self._handle_key(resp)

    # ----------------------------------------------------------
    # NULL-PACKET TS — 7 pacotes MPEG-TS nulos (0x47 + PID 0x1FFF)
    # Mantém o demuxer do Kodi vivo sem dados de vídeo reais.
    # Nunca retornamos Content-Length:0 pois isso encerra a stream.
    # ----------------------------------------------------------
    _NULL_TS_PACKET = bytes([0x47, 0x1F, 0xFF, 0x10] + [0xFF] * 184)
    _NULL_TS_BODY   = _NULL_TS_PACKET * 7   # 7 × 188 = 1316 bytes

    def _send_fallback(self, req_type):
        """
        NUNCA retorna status de erro (4xx/5xx) ao Kodi.
        - m3u8: playlist com EXT-X-DISCONTINUITY + segmento apontando de
                volta para a entry_url para forçar reconexão transparente.
        - ts  : null-packets MPEG-TS válidos (sync 0x47) para manter
                o demuxer vivo enquanto a reconexão acontece em background.
        - key : chave nula 16 bytes (AES-128 fallback).
        """
        self.send_response(200)
        self.send_anti_block_headers()

        if req_type == 'm3u8':
            # Reconstrói uma playlist que aponta de volta para a entry_url
            # via proxy, forçando o Kodi a re-resolver o canal inteiro.
            entry_url = get_original_url()
            if entry_url:
                proxy_seg = self.make_proxy_url("m3u8", entry_url, entry_url)
                # Playlist com um único sub-manifesto apontando para a entry
                # e EXT-X-DISCONTINUITY para suprimir avisos de sequência.
                body = (
                    "#EXTM3U\n"
                    "#EXT-X-VERSION:3\n"
                    "#EXT-X-TARGETDURATION:10\n"
                    "#EXT-X-MEDIA-SEQUENCE:0\n"
                    "#EXT-X-DISCONTINUITY\n"
                    f"{proxy_seg}\n"
                ).encode('utf-8')
            else:
                # Sem entry_url: playlist mínima aberta (sem EXT-X-ENDLIST)
                # — o Kodi ficará em polling aguardando novos segmentos.
                body = (
                    b"#EXTM3U\n#EXT-X-VERSION:3\n"
                    b"#EXT-X-TARGETDURATION:10\n"
                    b"#EXT-X-MEDIA-SEQUENCE:0\n"
                )
            self.send_header('Content-Type',   'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except Exception:
                pass

        elif req_type == 'ts':
            # Null-packets válidos — NUNCA Content-Length:0
            body = self._NULL_TS_BODY
            self.send_header('Content-Type',   'video/mp2t')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except Exception:
                pass

        elif req_type == 'key':
            body = b'\x00' * 16
            self.send_header('Content-Type',   'application/octet-stream')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except Exception:
                pass

    def _send_cors_headers(self):
        self.send_header('Cache-Control',           'no-cache, no-store, must-revalidate')
        self.send_header('Pragma',                  'no-cache')
        self.send_header('Expires',                 '0')
        self.send_header('Access-Control-Allow-Origin',  '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')

    def send_anti_block_headers(self):
        self._send_cors_headers()
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options',        'SAMEORIGIN')
        self.send_header('X-XSS-Protection',       '1; mode=block')

    def _rewrite_key_line(self, line, final_url):
        uri_match = re.search(r'URI=(["\'])(.*?)\1', line)
        if not uri_match:
            return line
        quote_char   = uri_match.group(1)
        original_uri = uri_match.group(2)
        if original_uri.lower().startswith('data:'):
            return line
        abs_key_url   = urllib.parse.urljoin(final_url, original_uri)
        proxy_key_url = self.make_proxy_url("key", abs_key_url, final_url)
        print(f"[PROXY] AES-128 KEY interceptada: {abs_key_url}")
        return (
            line[:uri_match.start()]
            + f'URI={quote_char}{proxy_key_url}{quote_char}'
            + line[uri_match.end():]
        )

    def _handle_m3u8(self, resp, final_url):
        try:
            content = resp._cached_content.decode('utf-8', errors='ignore')
        except Exception:
            self._send_fallback('m3u8')
            return
        finally:
            try:
                resp.close()
            except Exception:
                pass

        lines       = content.splitlines()
        new_lines   = []
        ts_sequence = []

        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXT-X-KEY'):
                line = self._rewrite_key_line(line, final_url)
                new_lines.append(line)
            elif not line.startswith('#'):
                abs_ts = urllib.parse.urljoin(final_url, line)
                if abs_ts.lower().split('?')[0].endswith('.m3u8'):
                    proxy_ts = self.make_proxy_url("m3u8", abs_ts, final_url)
                else:
                    ts_sequence.append(abs_ts)
                    proxy_ts = self.make_proxy_url("ts", abs_ts, final_url)
                new_lines.append(proxy_ts)
            else:
                new_lines.append(line)

        PLAYLIST_SEQUENCE.set(final_url, ts_sequence)
        output = '\n'.join(new_lines).encode('utf-8')

        self.send_response(200)
        self.send_header('Content-Type',   'application/vnd.apple.mpegurl')
        self.send_header('Content-Length', str(len(output)))
        self.send_anti_block_headers()
        self.end_headers()
        try:
            self.wfile.write(output)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass

    def _handle_ts(self, resp, current_ts_url, referer):
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_anti_block_headers()
        self.end_headers()

        bytes_written        = 0
        max_internal_retries = 4   # +1 para incluir tentativa com token novo
        target_url           = getattr(resp, '_target_url', None)

        if referer:
            seq = PLAYLIST_SEQUENCE.get(referer, [])
            if seq:
                try:
                    idx = seq.index(current_ts_url)
                    if idx + 1 < len(seq):
                        threading.Thread(
                            target=prefetch_worker,
                            args=(seq[idx + 1], referer),
                            daemon=True
                        ).start()
                except ValueError:
                    pass

        chunk_size = 65536

        for attempt in range(max_internal_retries):
            retry_resp = None
            retry_ua   = next_ua() if attempt > 0 else None
            try:
                if attempt == 0:
                    self.wfile.write(resp._first_byte)
                    bytes_written += 1
                    for chunk in resp.iter_content(chunk_size=chunk_size):
                        if chunk:
                            self.wfile.write(chunk)
                            bytes_written += len(chunk)
                    break

                else:
                    if not target_url:
                        break

                    # Na última tentativa interna: força renovação de token via URL original
                    if attempt == max_internal_retries - 1:
                        original_url = get_original_url()
                        if original_url:
                            print(f"[PROXY] TS retry {attempt}: forçando token via URL original.")
                            new_resolved = force_fresh_token(
                                original_url,
                                reason=f"TS stream falhou após {attempt} tentativas"
                            )
                            if new_resolved:
                                # Tenta buscar o segmento TS equivalente na nova URL base
                                # Reconstrói a URL do segmento substituindo a base
                                try:
                                    old_parsed = urllib.parse.urlparse(target_url)
                                    new_parsed = urllib.parse.urlparse(new_resolved)
                                    # Usa o path do TS antigo com o novo host/token
                                    new_ts_url = urllib.parse.urlunparse((
                                        new_parsed.scheme,
                                        new_parsed.netloc,
                                        old_parsed.path,
                                        '', old_parsed.query, ''
                                    ))
                                    target_url = new_ts_url
                                    print(f"[PROXY] TS novo URL: {target_url[:80]}...")
                                except Exception as e:
                                    print(f"[PROXY] Erro ao reconstruir URL TS: {e}")

                    print(f"[PROXY] Retry TS {attempt} a partir do byte {bytes_written}.")
                    headers = get_anti_block_headers(target_url, referer, ua=retry_ua)
                    if bytes_written > 0:
                        headers['Range'] = f"bytes={bytes_written}-"
                    sess       = get_session()
                    retry_resp = sess.get(
                        target_url, headers=headers, stream=True,
                        timeout=(4.0, 8.0), verify=False
                    )
                    if retry_resp.status_code in (200, 206):
                        for chunk in retry_resp.iter_content(chunk_size=chunk_size):
                            if chunk:
                                self.wfile.write(chunk)
                                bytes_written += len(chunk)
                        break
                    elif retry_resp.status_code in (401, 403):
                        cache_key = (current_ts_url, referer) if referer else current_ts_url
                        invalidate_cache(cache_key)
                        get_session().cookies.clear()
                        # Se token expirou durante o TS, força renovação na próxima iteração
                        if attempt < max_internal_retries - 2:
                            original_url = get_original_url()
                            if original_url:
                                print(f"[PROXY] TS auth {retry_resp.status_code} → renovando token imediatamente.")
                                retry_resp.close()
                                new_resolved = force_fresh_token(
                                    original_url,
                                    reason=f"TS auth {retry_resp.status_code}"
                                )
                                if new_resolved:
                                    try:
                                        old_parsed = urllib.parse.urlparse(target_url)
                                        new_parsed = urllib.parse.urlparse(new_resolved)
                                        target_url = urllib.parse.urlunparse((
                                            new_parsed.scheme,
                                            new_parsed.netloc,
                                            old_parsed.path,
                                            '', old_parsed.query, ''
                                        ))
                                    except Exception:
                                        pass
                                retry_resp = None
                                continue
                        break
                    else:
                        time.sleep(0.5 * attempt)

            except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                break
            except requests.exceptions.ConnectionError as e:
                print(f"[PROXY] ConnectionError TS attempt {attempt+1}: {e}")
                if attempt < max_internal_retries - 1:
                    reset_session()   # reset já rotaciona UA internamente
                    time.sleep(0.5 * (attempt + 1))
            except Exception as e:
                print(f"[PROXY] Erro TS attempt {attempt+1}: {e}")
                if attempt < max_internal_retries - 1:
                    time.sleep(0.5 * (attempt + 1))
            finally:
                if attempt == 0 and resp:
                    try:
                        resp.close()
                    except Exception:
                        pass
                if retry_resp:
                    try:
                        retry_resp.close()
                    except Exception:
                        pass

        # Se nenhum byte real foi escrito após todos os retries,
        # injeta null-packets para NÃO deixar a conexão sem dados
        # (demuxer vazio causa stop no Kodi).
        if bytes_written == 0:
            try:
                null_body = ProxyHTTPRequestHandler._NULL_TS_BODY
                self.wfile.write(null_body)
                print(f"[PROXY] TS: todos retries falharam → null-packets injetados ({len(null_body)}B).")
            except Exception:
                pass

    def _handle_key(self, resp):
        key_data = getattr(resp, '_cached_content', b'') or b'\x00' * 16
        self.send_response(200)
        self.send_header('Content-Type',   'application/octet-stream')
        self.send_header('Content-Length', str(len(key_data)))
        self.send_anti_block_headers()
        self.end_headers()
        try:
            self.wfile.write(key_data)
            print(f"[PROXY] Chave AES-128 entregue ({len(key_data)} bytes).")
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass
        finally:
            try:
                resp.close()
            except Exception:
                pass


# ---------------------------------------------------------------
# MONITOR DE PLAYBACK
# Roda em thread dedicada. Detecta stop/end e dispara callback.
# Usa xbmc.Player().isPlaying() com polling leve (1s).
# Não depende de xbmc.Monitor para maior compatibilidade com Kodi Android.
# ---------------------------------------------------------------
class PlaybackMonitor(threading.Thread):
    """
    Detecta fim de reprodução via polling em xbmc.Player.
    Quando o player para, chama on_stop() e encerra a thread.
    """
    def __init__(self, on_stop, poll_interval=1.0):
        super().__init__(daemon=True)
        self.on_stop       = on_stop
        self.poll_interval = poll_interval
        self._abort        = threading.Event()

    def run(self):
        try:
            import xbmc
        except ImportError:
            # Fora do Kodi — monitor não faz nada
            return

        # Aguarda o player iniciar (até 10s)
        started = False
        for _ in range(20):
            if self._abort.is_set():
                return
            if xbmc.Player().isPlaying():
                started = True
                break
            time.sleep(0.5)

        if not started:
            print("[MONITOR] Player não iniciou em 10s — monitor encerrado.")
            return

        print("[MONITOR] Reprodução detectada — monitorando.")

        # Polling enquanto está tocando
        while not self._abort.is_set():
            if not xbmc.Player().isPlaying():
                print("[MONITOR] Playback encerrado — executando on_stop.")
                try:
                    self.on_stop()
                except Exception as e:
                    print(f"[MONITOR] Erro no on_stop: {e}")
                return
            time.sleep(self.poll_interval)

    def abort(self):
        self._abort.set()


# ---------------------------------------------------------------
# HLS ADDON — SINGLETON COM SESSÃO PERSISTENTE
# ---------------------------------------------------------------
class HLSAddon:
    """
    Singleton. O servidor HTTP e a sessão requests vivem para sempre.
    Ciclo de vida:

      HLSAddon()          → cria servidor e sessão (uma vez)
      .play_stream(url)   → limpa estado anterior, registra URL original, inicia monitor
      [usuário dá stop]   → monitor detecta, chama _on_playback_stop
      _on_playback_stop() → limpa caches, NÃO fecha sessão
      .play_stream(url2)  → reutiliza sessão existente para o próximo canal
      .stop()             → encerra servidor e fecha sessão (saída do addon)
    """

    _instance = None
    _instance_lock = threading.Lock()

    def __new__(cls, addon_handle=None):
        with cls._instance_lock:
            if cls._instance is None:
                inst = super().__new__(cls)
                inst._initialized = False
                cls._instance = inst
            return cls._instance

    def __init__(self, addon_handle=None):
        if self._initialized:
            # Singleton já existe — só atualiza o handle se fornecido
            if addon_handle is not None:
                self.addon_handle = addon_handle
            return

        self.addon_handle   = addon_handle
        self._monitor       = None
        self._monitor_lock  = threading.Lock()

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), ProxyHTTPRequestHandler)
        self.port   = self.server.server_address[1]

        self._server_thread = threading.Thread(
            target=self.server.serve_forever, daemon=True
        )
        self._server_thread.start()

        self._initialized = True
        print(
            f"[PROXY HLS] Iniciado na porta {self.port} "
            f"— Sessão Persistente | LRU Cache | Prefetch | UA Rotativo | AES-128 | Token Renewal"
        )

    # ----------------------------------------------------------
    def play_stream(self, original_url, listitem=None):
        """
        Prepara e inicia reprodução de um novo canal.
        Registra a URL original para renovação de token.
        Limpa estado da stream anterior e inicia monitor de playback.
        A sessão HTTP é reutilizada.
        """
        # Cancela monitor anterior se ainda estiver ativo
        with self._monitor_lock:
            if self._monitor and self._monitor.is_alive():
                self._monitor.abort()
                self._monitor = None

        # Limpa caches do canal anterior — sessão HTTP fica intacta
        clear_stream_state()

        # *** Registra URL original para renovação de token ***
        set_original_url(original_url)
        print(f"[PROXY] URL original registrada para renovação de token: {original_url}")

        # Codifica URL em Base64 para o proxy local
        payload   = f"{original_url}|".encode('utf-8')
        b64       = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        proxy_url = f"http://127.0.0.1:{self.port}/playlist/{b64}.m3u8"

        # Inicia monitor de playback
        with self._monitor_lock:
            self._monitor = PlaybackMonitor(on_stop=self._on_playback_stop)
            self._monitor.start()

        try:
            import xbmcplugin, xbmcgui, xbmc

            if listitem is None or isinstance(listitem, str):
                listitem = xbmcgui.ListItem(path=proxy_url)
            else:
                listitem.setPath(proxy_url)

            handle = -1
            if self.addon_handle is not None:
                try:
                    handle = int(self.addon_handle)
                except Exception:
                    pass

            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, True, listitem)
            else:
                xbmc.Player().play(proxy_url, listitem)

        except ImportError:
            # Fora do Kodi (testes)
            return proxy_url

    # ----------------------------------------------------------
    def _on_playback_stop(self):
        """
        Callback chamado pelo PlaybackMonitor quando o usuário para o vídeo.
        Limpa estado da stream. NÃO fecha a sessão HTTP.
        """
        print("[PROXY] Playback encerrado pelo usuário — limpando estado da stream.")
        clear_stream_state()
        with self._monitor_lock:
            self._monitor = None

    # ----------------------------------------------------------
    def stop(self):
        """
        Encerra completamente o proxy (saída do addon).
        Fecha servidor HTTP e sessão requests.
        """
        print("[PROXY HLS] Encerrando proxy...")

        # Para monitor se ativo
        with self._monitor_lock:
            if self._monitor and self._monitor.is_alive():
                self._monitor.abort()
                self._monitor = None

        # Para servidor HTTP
        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception:
            pass

        # Fecha sessão HTTP (único momento em que isso ocorre)
        close_session()

        # Reseta singleton para permitir reinício se necessário
        with HLSAddon._instance_lock:
            HLSAddon._instance = None

        print("[PROXY HLS] Encerrado.")
