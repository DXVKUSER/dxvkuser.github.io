# -*- coding: utf-8 -*-
# NEXUS X-CODES HYBRID V20.57
# Base: V20.56
# Fix definitivo:
#   - Watchdog sem sleep bloqueante: reinicia producer em ate 0.5s apos starvation
#   - Keepalive injetado agressivamente (fila < 16 itens)
#   - Producer fecha conexao morta em thread daemon, nao bloqueia o loop
#   - Backoff maximo 3s em passos de 50ms
#   - STARVATION_TIMEOUT=5s, WATCHDOG_POLL=0.5s
#   - Sutura intocada

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import collections
import concurrent.futures
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, parse_qs
from requests.adapters import HTTPAdapter
from http.server import HTTPServer, BaseHTTPRequestHandler

import xbmc
import xbmcgui
import xbmcplugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS   = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

# ---- Tamanhos de buffer / chunk ---------------------------------------------
CHUNK_SIZE      = 128 * 1024
TS_CHUNK_SIZE   = 8   * 1024
# Timeout de leitura menor que o timeout do Kodi (~30s):
# o proxy detecta stall antes e ja injeta keepalive
FETCH_TIMEOUT   = 8
CONNECT_TIMEOUT = 5
QUEUE_SIZE      = 512

# ---- Sutura / Anti-Loop -----------------------------------------------------
TAIL_PRIMARY   = 32 * 1024
TAIL_SECONDARY = 8  * 1024
SEARCH_WINDOW  = 5 * 1024 * 1024

# ---- LRU Tail Cache ---------------------------------------------------------
LRU_TAIL_CAPACITY = 8
LRU_QUEUE_SIZE    = 16

# ---- Anti-EOF / Keepalive ---------------------------------------------------
KEEPALIVE_PACKETS  = 7
KEEPALIVE_INTERVAL = 0.03   # ~33 Hz — mais rapido que V20.56 (era 0.04)

# ---- Watchdog ---------------------------------------------------------------
WATCHDOG_POLL      = 0.5    # checagem a cada 500ms

# ---- Deteccao de falha -------------------------------------------------------
MANIFEST_FAIL_TIMEOUT  = 5
STARVATION_TIMEOUT     = 5   # detecta starvation em 5s (era 8s)
STARVATION_RESET_LIMIT = 1

# ---- Token Decay ------------------------------------------------------------
TOKEN_EXPIRED_CODES = {401, 403, 404, 410}

# ---- Pacote TS Nulo ---------------------------------------------------------
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
TS_PACKET_SIZE = 188
NULL_BLOCK     = TS_NULL_PACKET * KEEPALIVE_PACKETS

# ---- User Agents ------------------------------------------------------------
_UA_BASE = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/121.0.0.0 TV Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20',
    'AppleCoreMedia/1.0.0.21G217 (iPhone; U; CPU OS 16_6 like Mac OS X)',
    'Lavf/59.27.100',
]
_UA_ROTATION = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone14,3; U; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/19A346 Safari/602.1',
    'Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 7.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.0 Chrome/122.0.0.0 TV Safari/537.36',
    'Kodi/20.5 (Windows NT 10.0; Win64; x64) App_Bitness/64 Version/20.5',
    'Lavf/60.3.100',
    'FFmpeg/6.0',
    'streamlink/6.0.0',
    'python-requests/2.31.0',
    'curl/8.4.0',
]
ALL_UA = _UA_BASE + _UA_ROTATION


# ---- Utilitarios ------------------------------------------------------------

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in (10, 127, 169, 172, 192, 198, 203, 224):
            continue
        o2 = random.randint(0, 255)
        o3 = random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31:
            continue
        if o1 == 192 and o2 == 168:
            continue
        return '%d.%d.%d.%d' % (o1, o2, o3, o4)


def get_stealth_headers(target_url):
    fake_ip = random_ip()
    parsed  = urlparse(target_url)
    base    = '%s://%s/' % (parsed.scheme, parsed.netloc)
    ua      = random.choice(ALL_UA)

    if   'Android'   in ua: plat, mob = '"Android"', '?1'
    elif 'iPhone'    in ua or 'iPad' in ua: plat, mob = '"iOS"', '?1'
    elif 'SMART-TV'  in ua: plat, mob = '"SmartTV"', '?0'
    elif 'Windows'   in ua: plat, mob = '"Windows"', '?0'
    elif 'Macintosh' in ua: plat, mob = '"macOS"',   '?0'
    elif 'Linux'     in ua: plat, mob = '"Linux"',   '?0'
    else:                    plat, mob = '"Unknown"', '?0'

    cv = random.choice(['121', '122', '123', '124'])
    h = {
        'User-Agent':                ua,
        'Accept':                    '*/*',
        'Accept-Language':           random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9,en;q=0.8',
                                                    'es-ES,es;q=0.9', 'fr-FR,fr;q=0.9']),
        'Connection':                'keep-alive',
        'Cache-Control':             'no-cache',
        'Pragma':                    'no-cache',
        'Referer':                   base,
        'Origin':                    base.rstrip('/'),
        'DNT':                       str(random.randint(0, 1)),
        'X-Forwarded-For':           fake_ip,
        'X-Real-IP':                 fake_ip,
        'Client-IP':                 fake_ip,
        'Sec-CH-UA':                 '"Not;A=Brand";v="99","Google Chrome";v="%s","Chromium";v="%s"' % (cv, cv),
        'Sec-CH-UA-Mobile':          mob,
        'Sec-CH-UA-Platform':        plat,
        'Sec-Fetch-Site':            random.choice(['same-origin', 'cross-site', 'none']),
        'Sec-Fetch-Mode':            'cors',
        'Sec-Fetch-Dest':            'empty',
        'Upgrade-Insecure-Requests': '1',
        'TE':                        'trailers',
    }
    if random.random() < 0.4:
        h['X-Requested-With'] = 'XMLHttpRequest'
    return h


def _close_response_async(resp):
    """Fecha uma resposta HTTP em thread daemon para nao bloquear o caller."""
    def _do():
        try:
            resp.close()
        except Exception:
            pass
    t = threading.Thread(target=_do, daemon=True)
    t.start()


# ---- LRU Tail Cache ---------------------------------------------------------

class LRUTailCache(object):
    def __init__(self, capacity=LRU_TAIL_CAPACITY):
        self.capacity = capacity
        self._cache   = collections.OrderedDict()
        self._lock    = threading.Lock()

    def push(self, tail):
        if not tail:
            return
        with self._lock:
            self._cache[str(uuid.uuid4())] = tail
            if len(self._cache) > self.capacity:
                self._cache.popitem(last=False)

    def get_all(self):
        with self._lock:
            return list(reversed(list(self._cache.values())))

    def clear(self):
        with self._lock:
            self._cache.clear()


# ---- Sistema de Reconexao ---------------------------------------------------

class ReconnectionSystem(object):
    def __init__(self):
        self.history          = []
        self.last_success_idx = None

    @staticmethod
    def _make_session():
        s = requests.Session()
        a = HTTPAdapter(pool_connections=50, pool_maxsize=100, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        return s

    @staticmethod
    def _do_get(session, url, extra=None, t_add=(0, 0)):
        h = get_stealth_headers(url)
        h.pop('Accept-Encoding', None)
        if extra:
            h.update(extra)
        return session.get(
            url, headers=h, stream=True,
            timeout=(CONNECT_TIMEOUT + t_add[0], FETCH_TIMEOUT + t_add[1]),
            verify=False, allow_redirects=True)

    def _s0_fast(self, session, url):
        return self._do_get(session, url, {'X-Request-Id': str(uuid.uuid4())})

    def _s1_backoff(self, session, url):
        time.sleep(random.uniform(0.2, 0.5))
        return self._do_get(session, url, t_add=(1, 3))

    def _s2_new_session(self, session, url):
        ns = self._make_session()
        return self._do_get(ns, url, {'Accept-Encoding': 'identity'})

    def _s3_alt_proto(self, session, url):
        alt = (url.replace('https://', 'http://', 1)
               if url.startswith('https://')
               else url.replace('http://', 'https://', 1))
        return self._do_get(session, alt, {'Accept-Encoding': 'identity'})

    def _s4_new_ip(self, session, url):
        time.sleep(random.uniform(0.2, 0.6))
        return self._do_get(session, url, {
            'X-Device-ID':  str(uuid.uuid4()),
            'X-Session-ID': str(uuid.uuid4()),
        })

    def _s5_cache_bust(self, session, url):
        sep  = '&' if '?' in url else '?'
        bust = '%s%s_t=%d&_r=%d' % (url, sep, int(time.time()), random.randint(1000, 9999))
        return self._do_get(session, bust, {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma':        'no-cache',
            'Expires':       '0',
        })

    _STRATEGIES = [_s0_fast, _s1_backoff, _s2_new_session,
                   _s3_alt_proto, _s4_new_ip, _s5_cache_bust]

    def next_idx(self):
        if self.last_success_idx is not None:
            return self.last_success_idx
        if not self.history:
            return 0
        used      = set(self.history[-3:])
        available = [i for i in range(len(self._STRATEGIES)) if i not in used]
        if available:
            return random.choice(available)
        counts = {}
        for s in self.history:
            counts[s] = counts.get(s, 0) + 1
        return min(counts, key=counts.get)

    def execute(self, idx, session, url):
        fn = self._STRATEGIES[idx % len(self._STRATEGIES)]
        return fn(self, session, url)


# ---- Engine Principal -------------------------------------------------------

class XCodesEngine(object):

    def __init__(self):
        self.entry_url    = None
        self.resolved_url = None
        self.active_param = None

        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self.stop_event = threading.Event()
        self._lock      = threading.Lock()

        # Estado de sutura — NAO MODIFICAR
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False

        # Executor para sutura multithread — NAO MODIFICAR
        self.suture_executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=6, thread_name_prefix='XCodes-Suture')

        # Contadores
        self.consecutive_failures = 0
        self.reconnection_count   = 0
        self.last_data_time       = 0.0
        self.starvation_counter   = 0
        self.token_expired_count  = 0

        self.session = None

        self.lru    = LRUTailCache()
        self.reconn = ReconnectionSystem()

        self.emergency = queue.Queue(maxsize=500)
        self._refill_emergency()

        self.producer_thread = None

        self._watchdog_stop   = threading.Event()
        self._watchdog_thread = None

        self._keepalive_stop   = threading.Event()
        self._keepalive_thread = None

        self._lru_queue  = queue.Queue(maxsize=LRU_QUEUE_SIZE)
        self._lru_stop   = threading.Event()
        self._lru_thread = None

        self._generator_active = threading.Event()

    # =========================================================================
    # Keepalive helpers
    # =========================================================================

    def _refill_emergency(self):
        for _ in range(500):
            try:
                self.emergency.put_nowait(NULL_BLOCK)
            except queue.Full:
                break

    def _push_keepalive(self, n=8):
        for _ in range(n):
            try:
                self.data_queue.put_nowait(NULL_BLOCK)
            except queue.Full:
                break

    def _flood_keepalive(self):
        """Enche metade da fila com NULL_BLOCKs imediatamente."""
        target = QUEUE_SIZE // 2
        count  = 0
        while count < target:
            try:
                self.data_queue.put_nowait(NULL_BLOCK)
                count += 1
            except queue.Full:
                break

    def _wait_interruptible(self, seconds, step=0.05):
        """Sleep fracionado que respeita stop_event."""
        deadline = time.time() + seconds
        while time.time() < deadline:
            if self.stop_event.is_set():
                return
            time.sleep(step)

    # =========================================================================
    # Session management
    # =========================================================================

    def _new_session(self):
        old = self.session
        s = requests.Session()
        a = HTTPAdapter(pool_connections=50, pool_maxsize=100, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        self.session = s
        # Fecha a sessao antiga de forma async para nao bloquear
        if old:
            def _close_old():
                try:
                    old.close()
                except Exception:
                    pass
            threading.Thread(target=_close_old, daemon=True).start()
        self.reconnection_count += 1
        if self.reconnection_count % 5 == 0:
            gc.collect()

    # =========================================================================
    # Reset
    # =========================================================================

    def _soft_reset(self):
        if self.stream_tail:
            try:
                self._lru_queue.put_nowait(self.stream_tail)
            except queue.Full:
                pass
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False
        with self.data_queue.mutex:
            self.data_queue.queue.clear()
        self._new_session()
        # Injeta keepalive imediatamente apos limpar a fila
        self._flood_keepalive()

    def _hard_reset(self):
        while not self._lru_queue.empty():
            try:
                self._lru_queue.get_nowait()
            except Exception:
                break
        self.lru.clear()
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False
        self.resolved_url     = None
        with self.data_queue.mutex:
            self.data_queue.queue.clear()
        self._new_session()

    # =========================================================================
    # Process — NAO MODIFICAR (logica de alinhamento TS)
    # =========================================================================

    def _process(self, raw):
        if not raw:
            return
        batch = self.residual_buffer + raw

        if not self.has_initial_lock:
            idx = batch.find(b'\x47')
            if idx == -1:
                self.residual_buffer = batch[-(TS_PACKET_SIZE * 2):]
                return
            batch = batch[idx:]
            self.has_initial_lock = True

        n = len(batch) // TS_PACKET_SIZE
        if n == 0:
            self.residual_buffer = batch
            return

        used                 = n * TS_PACKET_SIZE
        payload              = batch[:used]
        self.residual_buffer = batch[used:]

        self.stream_tail += payload
        if len(self.stream_tail) > TAIL_PRIMARY + TAIL_SECONDARY:
            self.stream_tail = self.stream_tail[-TAIL_PRIMARY:]

        self.last_data_time     = time.time()
        self.starvation_counter = 0

        try:
            self.data_queue.put_nowait(payload)
        except queue.Full:
            # Descarta metade mais antiga e insere o novo payload
            with self.data_queue.mutex:
                lst = list(self.data_queue.queue)
                self.data_queue.queue.clear()
                for item in lst[len(lst) // 2:]:
                    self.data_queue.queue.append(item)
            try:
                self.data_queue.put_nowait(payload)
            except Exception:
                pass

    # =========================================================================
    # Sutura LRU Multithreading — NAO MODIFICAR
    # =========================================================================

    def _suture_worker(self, label, tail, buf):
        primary = tail[-TAIL_PRIMARY:] if len(tail) >= TAIL_PRIMARY else tail
        if primary and primary in buf:
            idx = buf.rfind(primary)
            return ('perfeita', label, idx + len(primary))

        secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
        if secondary and len(buf) > TAIL_SECONDARY + 188 * 50 and secondary in buf:
            idx = buf.rfind(secondary)
            return ('rapida', label, idx + len(secondary))
        return None

    def _try_suture(self, buf):
        candidates = []
        if self.stream_tail:
            candidates.append(('atual', self.stream_tail))
        for i, t in enumerate(self.lru.get_all()):
            candidates.append(('LRU#%d' % (i + 1), t))

        futures = []
        for label, tail in candidates:
            futures.append(self.suture_executor.submit(
                self._suture_worker, label, tail, buf))

        for future in concurrent.futures.as_completed(futures):
            res = future.result()
            if res:
                tipo, label, skip = res
                if tipo == 'perfeita':
                    xbmc.log('[SUTURA] Perfeita via %s pulando %dB' % (label, skip),
                             xbmc.LOGINFO)
                return True, buf[skip:]

        return False, b''

    # =========================================================================
    # Watchdog — SEM sleep bloqueante; usa wait() fracionado
    # =========================================================================

    def _watchdog_loop(self):
        while not self._watchdog_stop.is_set():
            # Espera fracionada: acorda a cada WATCHDOG_POLL segundos
            self._watchdog_stop.wait(WATCHDOG_POLL)
            if self._watchdog_stop.is_set():
                break

            if self.last_data_time <= 0:
                continue

            elapsed = time.time() - self.last_data_time
            if elapsed <= STARVATION_TIMEOUT:
                continue

            # Starvation detectado — injeta keepalive IMEDIATAMENTE
            self.starvation_counter += 1
            self._flood_keepalive()

            # Para o producer — o generator continua rodando (stop_event e separado)
            self.stop_event.set()
            if self.producer_thread and self.producer_thread.is_alive():
                self.producer_thread.join(timeout=2)

            # Soft reset (preserva LRU para sutura)
            self._soft_reset()
            self.consecutive_failures = max(self.consecutive_failures, 1)
            self.last_data_time       = time.time()
            self._start_producer()

    # =========================================================================
    # Keepalive loop — injeta NULL_BLOCK agressivamente
    # =========================================================================

    def _keepalive_loop(self):
        while not self._keepalive_stop.is_set():
            self._keepalive_stop.wait(KEEPALIVE_INTERVAL)
            if self._keepalive_stop.is_set():
                break
            # Injeta sempre que a fila tiver menos de 16 itens
            if self.data_queue.qsize() < 16:
                try:
                    self.data_queue.put_nowait(NULL_BLOCK)
                except queue.Full:
                    pass

    # =========================================================================
    # LRU writer
    # =========================================================================

    def _lru_writer_loop(self):
        while not self._lru_stop.is_set():
            try:
                tail = self._lru_queue.get(timeout=1.0)
                self.lru.push(tail)
            except queue.Empty:
                continue
            except Exception:
                pass

        while not self._lru_queue.empty():
            try:
                tail = self._lru_queue.get_nowait()
                self.lru.push(tail)
            except Exception:
                break

    # =========================================================================
    # Thread management
    # =========================================================================

    def _start_aux_threads(self):
        if self._watchdog_thread is None or not self._watchdog_thread.is_alive():
            self._watchdog_stop.clear()
            self._watchdog_thread = threading.Thread(
                target=self._watchdog_loop, daemon=True,
                name='XCodes-Watchdog')
            self._watchdog_thread.start()

        if self._keepalive_thread is None or not self._keepalive_thread.is_alive():
            self._keepalive_stop.clear()
            self._keepalive_thread = threading.Thread(
                target=self._keepalive_loop, daemon=True,
                name='XCodes-Keepalive')
            self._keepalive_thread.start()

        if self._lru_thread is None or not self._lru_thread.is_alive():
            self._lru_stop.clear()
            self._lru_thread = threading.Thread(
                target=self._lru_writer_loop, daemon=True,
                name='XCodes-LRUWriter')
            self._lru_thread.start()

    def _stop_aux_threads(self):
        self._watchdog_stop.set()
        self._keepalive_stop.set()
        self._lru_stop.set()

        for t in (self._watchdog_thread,
                  self._keepalive_thread,
                  self._lru_thread):
            if t and t.is_alive():
                t.join(timeout=3)

    def _stop_producer(self):
        self.stop_event.set()
        if self.producer_thread and self.producer_thread.is_alive():
            self.producer_thread.join(timeout=4)

    def _start_producer(self):
        self.stop_event.clear()
        self.producer_thread = threading.Thread(
            target=self._producer_loop, daemon=True,
            name='XCodes-Producer')
        self.producer_thread.start()

    def _do_restart(self, entry, keep_lru=True):
        self.stop_event.clear()
        if keep_lru:
            self._soft_reset()
        else:
            self._hard_reset()
        self.entry_url            = entry
        self.resolved_url         = None
        self.consecutive_failures = 0
        self.starvation_counter   = 0
        self.token_expired_count  = 0
        self.last_data_time       = time.time()
        self._start_producer()

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls:
            raise ValueError('Nenhuma URL fornecida')
        entry = urls[0]

        with self._lock:
            self._start_aux_threads()

            if self.active_param == url_param:
                need_restart = self.stop_event.is_set() or (
                    self.producer_thread is not None and
                    not self.producer_thread.is_alive())
                if need_restart:
                    self._do_restart(entry, keep_lru=True)
            else:
                self._stop_producer()
                self._hard_reset()
                self.active_param            = url_param
                self.entry_url               = entry
                self.resolved_url            = None
                self.consecutive_failures    = 0
                self.reconnection_count      = 0
                self.last_data_time          = time.time()
                self.starvation_counter      = 0
                self.token_expired_count     = 0
                self.reconn.history          = []
                self.reconn.last_success_idx = None
                self._refill_emergency()
                self._start_producer()

    # =========================================================================
    # Producer loop
    # Regra de ouro: NUNCA usar time.sleep() direto — sempre _wait_interruptible()
    # Backoff maximo: 3s
    # =========================================================================

    def _producer_loop(self):
        strategy_idx = 0

        while not self.stop_event.is_set():
            r = None
            try:
                target_url = self.resolved_url if self.resolved_url else self.entry_url

                needs_reconn = (self.consecutive_failures >= 1 or
                                self.token_expired_count >= 1)

                if needs_reconn:
                    if self.resolved_url:
                        self.resolved_url = None
                        target_url = self.entry_url

                    strategy_idx = self.reconn.next_idx()
                    self.reconn.history.append(strategy_idx)

                    if self.stream_tail:
                        try:
                            self._lru_queue.put_nowait(self.stream_tail)
                        except queue.Full:
                            pass

                    self.stream_tail      = b''
                    self.residual_buffer  = b''
                    self.has_initial_lock = False
                    self._new_session()
                    # Garante keepalive durante reconexao
                    self._push_keepalive(20)
                    r = self.reconn.execute(strategy_idx, self.session, target_url)
                else:
                    h = get_stealth_headers(target_url)
                    h.pop('Accept-Encoding', None)
                    r = self.session.get(
                        target_url, headers=h, stream=True,
                        timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT),
                        verify=False, allow_redirects=True)

                if r is None:
                    self.consecutive_failures += 1
                    self._push_keepalive(20)
                    self._wait_interruptible(1.0)
                    continue

                status = r.status_code

                if status in TOKEN_EXPIRED_CODES:
                    self.token_expired_count += 1
                    self.resolved_url = None
                    _close_response_async(r)
                    r = None
                    wait = min(3.0, self.token_expired_count * 0.8)
                    self._flood_keepalive()
                    self._wait_interruptible(wait)
                    self.consecutive_failures = 0
                    continue

                if status == 409:
                    _close_response_async(r)
                    r = None
                    self._push_keepalive(20)
                    self._wait_interruptible(1.0)
                    continue

                if status not in (200, 206):
                    self.consecutive_failures += 1
                    backoff = min(3.0, 2 ** min(self.consecutive_failures - 1, 2))
                    _close_response_async(r)
                    r = None
                    self._flood_keepalive()
                    self._wait_interruptible(backoff)
                    continue

                self.consecutive_failures    = 0
                self.token_expired_count     = 0
                self.reconn.last_success_idx = strategy_idx

                if r.url != self.entry_url:
                    self.resolved_url = r.url

                is_ts = any(x in r.url.lower()
                            for x in ('.ts', '/ts', '.m2ts', '/chunk', '/segment'))
                chunk_sz = TS_CHUNK_SIZE if is_ts else CHUNK_SIZE

                resync_buf  = b''
                need_suture = bool(self.stream_tail) or bool(self.lru.get_all())
                real_bytes  = 0
                conn_start  = time.time()

                for chunk in r.iter_content(chunk_size=chunk_sz):
                    if self.stop_event.is_set():
                        break

                    if not chunk:
                        if real_bytes == 0 and time.time() - conn_start > MANIFEST_FAIL_TIMEOUT:
                            break
                        continue

                    real_bytes += 1

                    if need_suture:
                        resync_buf += chunk
                        if len(resync_buf) > SEARCH_WINDOW:
                            resync_buf = resync_buf[-(SEARCH_WINDOW // 2):]

                        ok, remainder = self._try_suture(resync_buf)
                        if ok:
                            resync_buf            = b''
                            need_suture           = False
                            self.has_initial_lock = False
                            self.residual_buffer  = b''
                            self._process(remainder)
                        elif len(resync_buf) >= SEARCH_WINDOW:
                            need_suture           = False
                            self.has_initial_lock = False
                            self.residual_buffer  = b''
                            self._process(resync_buf)
                            resync_buf = b''
                    else:
                        self._process(chunk)

                if real_bytes == 0 and not self.stop_event.is_set():
                    self.consecutive_failures += 1
                    self._push_keepalive(8)

                # Fecha a resposta de forma async para nao bloquear a proxima tentativa
                if r is not None:
                    _close_response_async(r)
                    r = None

            except Exception as exc:
                if r is not None:
                    _close_response_async(r)
                    r = None

                err = str(exc).lower()
                if 'ssl' in err or 'cipher' in err:
                    for fb in range(len(ReconnectionSystem._STRATEGIES)):
                        if self.stop_event.is_set():
                            break
                        try:
                            res = self.reconn.execute(fb, self.session, self.entry_url)
                            if res and res.status_code in (200, 206):
                                for ch in res.iter_content(chunk_size=TS_CHUNK_SIZE):
                                    if self.stop_event.is_set():
                                        break
                                    if ch:
                                        self._process(ch)
                                _close_response_async(res)
                                break
                        except Exception:
                            continue

                self.consecutive_failures += 1
                backoff = min(3.0, 2 ** min(self.consecutive_failures - 1, 2))
                self._flood_keepalive()
                self._wait_interruptible(backoff)

    # =========================================================================
    # Generator — NUNCA encerra enquanto o player estiver conectado
    # =========================================================================

    def generator(self):
        self._generator_active.set()

        # Pre-buffer inicial para o player nao dar timeout no handshake
        for _ in range(150):
            yield NULL_BLOCK

        next_kp = time.time() + KEEPALIVE_INTERVAL

        try:
            while True:
                # NUNCA quebra por stop_event — so encerra por GeneratorExit
                now = time.time()
                try:
                    chunk = self.data_queue.get(timeout=KEEPALIVE_INTERVAL)
                    yield chunk
                    next_kp = time.time() + KEEPALIVE_INTERVAL
                except queue.Empty:
                    if now >= next_kp:
                        try:
                            yield self.emergency.get_nowait()
                            self._refill_emergency()
                        except queue.Empty:
                            yield NULL_BLOCK
                        next_kp = time.time() + KEEPALIVE_INTERVAL

        except GeneratorExit:
            pass
        except Exception:
            pass
        finally:
            self._generator_active.clear()
            self.stop_event.set()
            self._stop_aux_threads()


# ---- Instancia Global do Motor ----------------------------------------------
engine = XCodesEngine()


# ---- HTTP Server / Handler --------------------------------------------------

class TSProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)

        if parsed_path.path == '/stream':
            query     = parse_qs(parsed_path.query)
            url_param = query.get('url', [None])[0]

            # Sempre responde 200 — nunca retorna erro ao player
            self.send_response(200)
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'keep-alive')
            self.send_header('Content-Type', 'video/mp2t')
            self.end_headers()

            if url_param:
                engine.start_stream(url_param)

            try:
                for chunk in engine.generator():
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except (ConnectionResetError, BrokenPipeError):
                pass
            except Exception:
                pass
        else:
            self.send_response(200)
            self.end_headers()

    def log_message(self, format, *args):
        pass


class TSProxyServer(threading.Thread):
    def __init__(self, port):
        super(TSProxyServer, self).__init__(daemon=True)
        self.port   = port
        self.server = HTTPServer(('127.0.0.1', self.port), TSProxyHandler)

    def run(self):
        try:
            self.server.serve_forever()
        except Exception:
            pass

    def stop(self):
        self.server.shutdown()
        self.server.server_close()


# ---- Server Start Logic -----------------------------------------------------

def get_free_port(start=50088):
    for port in range(start, start + 100):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            return port
        except OSError:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    return random.randint(50088, 50188)

proxy_server = None

def start_server():
    global proxy_server
    port = get_free_port()
    proxy_server = TSProxyServer(port)
    proxy_server.start()
    time.sleep(0.7)
    return port

SERVER_PORT = start_server()


# ---- Addon Entry Point ------------------------------------------------------

def run_addon():
    action = _ARGS.get('action')
    url    = _ARGS.get('url')

    if action == 'play' and url:
        local = 'http://127.0.0.1:%d/stream?url=%s' % (SERVER_PORT, quote(url))
        li = xbmcgui.ListItem(path=local)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    else:
        li = xbmcgui.ListItem('[COLOR cyan]NEXUS X-CODES HYBRID V20.57[/COLOR]')
        li.setInfo('video', {'title': 'Nexus X-Codes Hybrid Proxy'})
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(_HANDLE)


if __name__ == '__main__':
    run_addon()
