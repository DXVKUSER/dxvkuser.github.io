#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
HLS Proxy Kodi Mode v12.7 - Otimizado com Chunk Dinâmico e Estabilidade (Anti-Buffering)
Usa script.module.netunblock (DNS-over-HTTPS)
Executa via xbmcplugin.setResolvedUrl()
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os

from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

# Usa o requests do script.module.netunblock (com DNS-over-HTTPS)
from doh_client import requests
# Importa exceções específicas do requests para um tratamento de erro mais preciso
from requests.exceptions import ConnectionError, Timeout, ReadTimeout, RequestException

# ---- Tentativa de importar Kodi ----
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
except ImportError:
    class MockKodi:
        def log(self, msg, level=None):
            print(msg)
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    xbmcvfs = None

# ---------------- CONFIG OTIMIZADA ----------------

# Aumentamos os retries para maior resiliência contra 'RemoteDisconnected'
MAX_SEGMENT_RETRIES = 5 
MAX_MANIFEST_RETRIES = 3 

CONNECTION_TIMEOUT = 6.0
# Aumentamos o Read Timeout para permitir mais tempo em redes instáveis/lentas
READ_TIMEOUT = 15.0 

SEGMENT_CACHE_SIZE = 20
SEGMENT_CACHE_TTL = 60
MANIFEST_CACHE_TTL = 3
SESSION_TIMEOUT_SECONDS = 600

# Valores Base e Limites do Chunk Dinâmico
BASE_CHUNK_SIZE = 64 * 1024 # 64 KB
MIN_CHUNK_SIZE = 32 * 1024  # 32 KB (Aumentado de 16k para melhor throughput)
MAX_CHUNK_SIZE = 256 * 1024 # 256 KB

PROXY_HOST = "127.0.0.1"
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy_kodi.log"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; SM-A536E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
]

warnings.filterwarnings("ignore")

MANIFEST_CACHE = {}
SEGMENT_CACHE = {}
SESSION_STORE = {}
STATE_LOCK = threading.Lock()

# ---------------- LOGGING ----------------

def setup_logging():
    try:
        if xbmcvfs:
            log_dir = xbmcvfs.translatePath('special://logpath')
        else:
            log_dir = "."
        if not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        # Configuração para logar no arquivo
        logging.basicConfig(
            filename=os.path.join(log_dir, LOG_FILE),
            level=logging.INFO,
            format='[%(asctime)s] %(message)s',
            datefmt='%H:%M:%S'
        )
    except Exception:
        # Fallback para console
        logging.basicConfig(level=logging.INFO)

def kodi_log(msg):
    try:
        xbmc.log(f"[HLS-PROXY] {msg}")
    except Exception:
        print(f"[HLS-PROXY] {msg}")

# ---------------- DYNAMIC CHUNK MANAGER ----------------

class DynamicChunkManager:
    """Gerencia o ajuste dinâmico do chunk_size por sessão, visando estabilidade."""

    def __init__(self, session_data):
        self.data = session_data

    def get_chunk_size(self):
        return self.data.get("chunk_size", BASE_CHUNK_SIZE)

    def adjust_chunk_size(self, segment_download_time_sec, segment_size_bytes, success=True):
        """Ajusta o chunk_size com base no desempenho do download."""
        current_chunk = self.get_chunk_size()
        new_chunk = current_chunk

        if not success:
            # Em caso de falha, diminuir o chunk agressivamente para tentar resolver o problema de RemoteDisconnected/Timeout
            new_chunk = max(MIN_CHUNK_SIZE, current_chunk // 2)
            kodi_log(f"ChunkManager: FALHA. Reduzindo chunk para {new_chunk / 1024:.0f} KB para tentar estabilizar.")
        else:
            if segment_download_time_sec <= 0 or segment_size_bytes <= 0:
                return current_chunk

            # Calcula a taxa de transferência em Mbps
            transfer_rate_bps = (segment_size_bytes * 8) / segment_download_time_sec
            transfer_rate_mbps = transfer_rate_bps / (1024 * 1024)
            
            # Limites de ajuste:
            LOW_RATE_MBPS = 4
            HIGH_RATE_MBPS = 15

            if transfer_rate_mbps > HIGH_RATE_MBPS:
                # Rede muito rápida: Aumentar o chunk para melhor throughput
                new_chunk = min(MAX_CHUNK_SIZE, current_chunk + BASE_CHUNK_SIZE // 2) # Aumenta 32KB
                kodi_log(f"ChunkManager: Alta taxa ({transfer_rate_mbps:.1f} Mbps). Aumentando chunk: {new_chunk / 1024:.0f} KB")
            elif transfer_rate_mbps < LOW_RATE_MBPS:
                # Rede lenta: Diminuir o chunk para reduzir a latência inicial e evitar timeouts (conservador)
                new_chunk = max(MIN_CHUNK_SIZE, current_chunk - BASE_CHUNK_SIZE // 4) # Diminui 16KB
                kodi_log(f"ChunkManager: Baixa taxa ({transfer_rate_mbps:.1f} Mbps). Diminuindo chunk: {new_chunk / 1024:.0f} KB")
            # Se a taxa estiver entre LOW e HIGH, o chunk permanece o mesmo (zona de estabilidade)
        
        # Aplica o novo valor e mantém dentro dos limites
        self.data["chunk_size"] = max(MIN_CHUNK_SIZE, min(MAX_CHUNK_SIZE, new_chunk))
        return self.data["chunk_size"]

# ---------------- SESSION MANAGER ----------------

class SessionManager:
    def __init__(self):
        thread = threading.Thread(target=self._cleanup_idle_sessions_loop, daemon=True)
        thread.start()

    def get_session_data(self, session_id):
        with STATE_LOCK:
            if session_id not in SESSION_STORE:
                self._create_new_session_entry(session_id)
            SESSION_STORE[session_id]["last_activity_time"] = time.time()
            return SESSION_STORE[session_id]

    def _create_new_session_entry(self, session_id):
        ua = random.choice(USER_AGENTS)
        SESSION_STORE[session_id] = {
            "session": requests,
            "ua": ua,
            "last_activity_time": time.time(),
            "chunk_size": BASE_CHUNK_SIZE 
        }
        kodi_log(f"Sessão criada (DoH): {session_id} | Chunk inicial: {BASE_CHUNK_SIZE / 1024:.0f} KB")

    def get_camouflaged_headers(self, session_id):
        sdata = self.get_session_data(session_id)
        return {
            "User-Agent": sdata["ua"],
            "Accept": "*/*",
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.7",
            "Connection": "keep-alive",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache"
        }

    def _cleanup_idle_sessions_loop(self):
        while True:
            time.sleep(60)
            now = time.time()
            with STATE_LOCK:
                expired = [
                    sid for sid, s in SESSION_STORE.items()
                    if now - s["last_activity_time"] > SESSION_TIMEOUT_SECONDS
                ]
                for sid in expired:
                    del SESSION_STORE[sid]
                    kodi_log(f"Sessão expirada: {sid}")

session_manager = SessionManager()

# ---------------- CACHE ----------------
# Funções de Cache (Mantidas)
def get_segment_from_cache(url):
    with STATE_LOCK:
        if url in SEGMENT_CACHE:
            ts, data = SEGMENT_CACHE[url]
            if time.time() - ts < SEGMENT_CACHE_TTL:
                return data
            else:
                del SEGMENT_CACHE[url]
    return None

def cache_segment(url, data):
    with STATE_LOCK:
        SEGMENT_CACHE[url] = (time.time(), data)
        if len(SEGMENT_CACHE) > SEGMENT_CACHE_SIZE:
            oldest = sorted(SEGMENT_CACHE.items(), key=lambda kv: kv[1][0])[:5]
            for k, _ in oldest:
                del SEGMENT_CACHE[k]

# ---------------- HANDLER ----------------

class HLSProxyRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        try:
            if "?url=" not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split("?", 1)[1])
            url = urllib.parse.unquote_plus(params.get("url", [None])[0])
            session_id = params.get("session_id", [f"sess_{int(time.time())}"])[0]

            if not url:
                self.send_error(400)
                return

            if ".m3u8" in url:
                self._handle_manifest(url, session_id)
            else:
                self._handle_segment(url, session_id)

        except Exception as e:
            kodi_log(f"Erro Handler (Geral): {e}")
            try:
                self.send_error(500)
            except:
                pass

    def _handle_manifest(self, url, session_id):
        sdata = session_manager.get_session_data(session_id)
        headers = session_manager.get_camouflaged_headers(session_id)
        
        for attempt in range(MAX_MANIFEST_RETRIES):
            try:
                r = sdata["session"].get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False)
                if r.status_code == 200:
                    content = r.text
                    base_url = r.url
                    lines = content.splitlines()
                    new_lines = []
                    
                    for line in lines:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            new_lines.append(line)
                            continue
                        full_url = urllib.parse.urljoin(base_url, line)
                        enc = urllib.parse.quote_plus(full_url)
                        proxy_url = (
                            f"http://{self.server.server_address[0]}:{self.server.server_address[1]}"
                            f"/?url={enc}&session_id={session_id}"
                        )
                        new_lines.append(proxy_url)
                        
                    final_content = "\n".join(new_lines).encode("utf-8")
                    MANIFEST_CACHE[session_id] = {"content": final_content, "timestamp": time.time()}
                    self._send_content(final_content, "application/vnd.apple.mpegurl")
                    return
                else:
                    kodi_log(f"Manifesto: Status HTTP {r.status_code} para {url}. Tentativa {attempt+1}/{MAX_MANIFEST_RETRIES}")
                    time.sleep(1.0)
            except RequestException as e:
                kodi_log(f"Erro de Conexão/Timeout no Manifesto: {e}. Tentativa {attempt+1}/{MAX_MANIFEST_RETRIES}")
                time.sleep(1.5)

        # Fallback: tentar servir manifesto em cache ou erro 503
        if session_id in MANIFEST_CACHE:
            kodi_log("Manifesto: Falha na busca, servindo versão em cache.")
            self._send_content(MANIFEST_CACHE[session_id]["content"], "application/vnd.apple.mpegurl")
        else:
            kodi_log("Manifesto: Falha na busca e sem cache disponível.")
            self.send_error(503)

    def _handle_segment(self, url, session_id):
        cached = get_segment_from_cache(url)
        if cached:
            self._send_content(cached, "video/MP2T")
            return
            
        sdata = session_manager.get_session_data(session_id)
        chunk_manager = DynamicChunkManager(sdata)
        headers = session_manager.get_camouflaged_headers(session_id)
        
        for attempt in range(MAX_SEGMENT_RETRIES):
            current_chunk_size = chunk_manager.get_chunk_size()
            
            try:
                # O stream=True é crucial para permitir o chunking
                r = sdata["session"].get(url, headers=headers, timeout=READ_TIMEOUT, stream=True, verify=False)
                
                if r.status_code != 200:
                    kodi_log(f"Segmento: Status HTTP {r.status_code}. Tentativa {attempt+1}/{MAX_SEGMENT_RETRIES}. Chunk: {current_chunk_size / 1024:.0f} KB")
                    time.sleep(1.0)
                    continue

                # --- Download/Streaming Bem-Sucedido ---
                
                self.send_response(200)
                self.send_header("Content-Type", "video/MP2T")
                
                content_length = r.headers.get('Content-Length')
                if content_length:
                    self.send_header("Content-Length", content_length)
                
                self.end_headers()
                
                start_time = time.time()
                segment_data_parts = []
                bytes_downloaded = 0
                
                # Download e streaming com chunk_size dinâmico
                for chunk in r.iter_content(chunk_size=current_chunk_size):
                    if chunk:
                        self.wfile.write(chunk)
                        segment_data_parts.append(chunk)
                        bytes_downloaded += len(chunk)
                        
                end_time = time.time()
                download_time = end_time - start_time
                full_data = b"".join(segment_data_parts)
                cache_segment(url, full_data)
                
                kodi_log(f"Segmento OK. Chunk: {current_chunk_size / 1024:.0f} KB | Tempo: {download_time:.3f}s | Tx: {(bytes_downloaded * 8) / (download_time * 1024 * 1024):.1f} Mbps")

                # Ajusta o chunk_size (Sucesso)
                chunk_manager.adjust_chunk_size(download_time, len(full_data), success=True)
                return

            except (ConnectionError, ReadTimeout, RequestException) as e:
                kodi_log(f"Erro de Conexão/Timeout no Segmento: {e.__class__.__name__}. Tentativa {attempt+1}/{MAX_SEGMENT_RETRIES}")
                # Ajusta o chunk_size (Falha) antes da próxima tentativa
                chunk_manager.adjust_chunk_size(0, 0, success=False)
                time.sleep(2.0) # Aumenta o tempo de espera entre tentativas para aliviar a pressão na rede
            
            except Exception as e:
                kodi_log(f"Erro inesperado no segmento: {e}")
                chunk_manager.adjust_chunk_size(0, 0, success=False)
                break # Sai do loop em caso de erro não tratado
        
        # Falha total após todas as tentativas
        kodi_log(f"Segmento: Falha persistente após {MAX_SEGMENT_RETRIES} tentativas.")
        self.send_error(503) # Service Unavailable

    def _send_content(self, content, mime):
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

# ---------------- SERVER ----------------
# Classes de Server (Mantidas)
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

def find_available_port():
    port = 8081
    for _ in range(MAX_PORT_ATTEMPTS):
        try:
            server = ThreadedHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
            kodi_log(f"Servidor iniciado na porta {port}")
            return server, port
        except OSError:
            port += 1
    raise Exception("Nenhuma porta disponível encontrada.")

# ---------------- HLSAddon Wrapper ----------------

class HLSAddon:
    """Classe compatível com Kodi para iniciar/parar o proxy e reproduzir streams de forma segura"""
    def __init__(self, handle=None):
        self.handle = handle
        self.server = None
        self.port = None
        self.thread = None
        kodi_log(f"HLSAddon inicializado (handle={handle})")

    def start(self):
        if self.server:
            return f"http://{PROXY_HOST}:{self.port}"
        
        setup_logging()
        self.server, self.port = find_available_port()
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        kodi_log(f"HLSAddon iniciado na porta {self.port}")
        return f"http://{PROXY_HOST}:{self.port}"

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server = None
            kodi_log("HLSAddon parado")

    def get_url(self, target_url, session_id=None, auto_start=True):
        if auto_start and not self.server:
            self.start()
            
        if not self.server:
            raise Exception("O proxy não está em execução.")
            
        if not session_id:
            session_id = f"sess_{int(time.time())}" 
            
        return f"http://{PROXY_HOST}:{self.port}/?url={urllib.parse.quote_plus(target_url)}&session_id={session_id}"

    def play_stream(self, url, stream_type="video"):
        """Usa xbmcplugin.setResolvedUrl() (seguro no Android)"""
        try:
            proxy_url = self.get_url(url) 
            kodi_log(f"Reproduzindo via proxy seguro: {proxy_url}")

            if xbmcplugin and xbmcgui and self.handle is not None:
                listitem = xbmcgui.ListItem(path=proxy_url)
                listitem.setMimeType("application/vnd.apple.mpegurl")
                listitem.setContentLookup(False)
                xbmcplugin.setResolvedUrl(self.handle, True, listitem)
                kodi_log("Stream entregue ao player via setResolvedUrl()")
            else:
                print(f"[PLAY SIMULADO] {proxy_url}")
        except Exception as e:
            kodi_log(f"Erro em play_stream: {e}")

# ---------------- MAIN ----------------

def run_proxy():
    setup_logging()
    try:
        server, port = find_available_port()
        kodi_log(f"Proxy HLS autônomo iniciado na porta {port}")
        server.serve_forever()
    except Exception as e:
        kodi_log(f"Erro ao iniciar proxy autônomo: {e}")
    except KeyboardInterrupt:
        kodi_log("Encerrando servidor...")
        if 'server' in locals() and server:
            server.shutdown()

if __name__ == "__main__":
    run_proxy()