#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hlsproxy.py — NEXUS CORE HLS Proxy Engine
v1.9.0 — Path Parameters + STRICT Single Persistent Session (1 Conexão/Host) + Pool Dinâmico por CDN

Recursos:
  • SESSÃO ESTRITA (1 Conexão): Serialização de threads para evitar ban/erros 400/500 no provedor.
  • POOL DINÂMICO POR CDN (NOVO): Chave de conexão inclui o IP resolvido — troca de edge/IP
    por trás do mesmo hostname (round-robin de CDN, failover) abre um novo pool automaticamente
    em vez de reaproveitar um socket keep-alive que já aponta pro IP antigo (morto no servidor,
    mas "vivo" do lado do cliente até o próximo write falhar).
  • PATH PARAMETERS (Base64): Compatível com FFmpeg do Manjaro Linux
  • DEBUG LOG TOGGLE: Controle de logs silencioso por padrão
  • DoH (DNS-over-HTTPS) resolver no topo (sem recursão)
  • Sessão HTTP Persistente: Uma conexão keep-alive real por (host lógico, IP resolvido)
  • Cache de Playlist + Single-Flight: Evita requisições duplicadas
  • Detecção de Falso 200 OK: Manifesto vazio, páginas de erro HTML
  • Reconexão Automática: Sem interromper a reprodução
  • Zero-Error ao Kodi: Nunca envia status de erro ao player
  • Interceptação e proxy de chaves AES-128
"""

import sys
import os
import re
import socket
import ssl
import json
import time
import base64
import threading
import urllib.request
import urllib.error
import urllib.parse
import http.client
import http.server
import http.cookiejar
import socketserver
from urllib.parse import urlparse, urljoin, quote
from collections import defaultdict

# ════════════════════════════════════════════════════════════
# DEBUG LOG CONTROL
# ════════════════════════════════════════════════════════════

DEBUG_LOG_ENABLED = False

def set_debug_log(enabled: bool):
    """Função para ativar ou desativar os logs do Proxy."""
    global DEBUG_LOG_ENABLED
    DEBUG_LOG_ENABLED = enabled


def _log(msg, level='info'):
    if not DEBUG_LOG_ENABLED:
        return
    try:
        import xbmc
        levels = {
            'info':    xbmc.LOGINFO,
            'error':   xbmc.LOGERROR,
            'warning': xbmc.LOGWARNING,
        }
        xbmc.log(f'[NexusCore-HLS] {msg}', levels.get(level, xbmc.LOGINFO))
    except ImportError:
        pass

# ════════════════════════════════════════════════════════════
# BASE64 URL ENCODER/DECODER (Path Parameters Fix)
# ════════════════════════════════════════════════════════════

def _b64_encode_url(url: str) -> str:
    """Codifica a URL para Base64 URL-safe (sem '=', '+' ou '/')."""
    return base64.urlsafe_b64encode(url.encode('utf-8')).decode('utf-8').rstrip('=')


def _b64_decode_url(encoded: str) -> str:
    """Decodifica a URL Base64 URL-safe de volta para string."""
    padding = '=' * (-len(encoded) % 4)
    return base64.urlsafe_b64decode(encoded + padding).decode('utf-8')


# ════════════════════════════════════════════════════════════
# DoH RESOLVER
# ════════════════════════════════════════════════════════════

_RE_IPV4 = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
_RE_IPV6 = re.compile(r'^[0-9a-fA-F:]+$')

_DNS_CACHE      = {}
_DNS_CACHE_LOCK = threading.Lock()
_DNS_CACHE_TTL  = 300

_in_doh_resolution = threading.local()

DOH_SERVERS = [
    'https://dns.google/resolve',
    'https://cloudflare-dns.com/dns-query',
]

# Fallback intermediário: DNS UDP direto (porta 53), sem passar por
# HTTPS. Útil quando a rede bloqueia/filtra tráfego HTTPS de saída
# pros servidores DoH (DPI de operadora, TV box em rede restrita)
# mas UDP porta 53 pra IPs públicos específicos ainda passa — comum
# o suficiente pra valer como camada extra antes de cair pro DNS
# do sistema (que pode estar apontando pro DNS do próprio provedor,
# que é frequentemente a origem do bloqueio de domínios de CDN).
_UDP_DNS_SERVERS = ['1.1.1.1', '8.8.8.8', '9.9.9.9']


def _build_dns_query(hostname, query_id=0x1234):
    """Monta uma query DNS tipo A mínima (RFC 1035), só com stdlib."""
    header = query_id.to_bytes(2, 'big') + bytes([
        0x01, 0x00,  # flags: recursão desejada
        0x00, 0x01,  # QDCOUNT=1
        0x00, 0x00,  # ANCOUNT=0
        0x00, 0x00,  # NSCOUNT=0
        0x00, 0x00,  # ARCOUNT=0
    ])
    question = b''
    for label in hostname.split('.'):
        encoded = label.encode('ascii', errors='ignore')
        question += bytes([len(encoded)]) + encoded
    question += b'\x00'          # fim do nome
    question += b'\x00\x01'      # QTYPE=A
    question += b'\x00\x01'      # QCLASS=IN
    return header + question


def _parse_dns_a_response(data):
    """Extrai o primeiro IPv4 de uma resposta DNS crua (RFC 1035)."""
    if len(data) < 12:
        return None
    ancount = int.from_bytes(data[6:8], 'big')
    if ancount == 0:
        return None

    pos = 12
    qdcount = int.from_bytes(data[4:6], 'big')
    for _ in range(qdcount):
        while pos < len(data) and data[pos] != 0:
            if data[pos] & 0xC0 == 0xC0:  # ponteiro de compressão
                pos += 2
                break
            pos += data[pos] + 1
        else:
            pos += 1
        pos += 4  # QTYPE + QCLASS

    for _ in range(ancount):
        if pos >= len(data):
            return None
        if data[pos] & 0xC0 == 0xC0:
            pos += 2
        else:
            while pos < len(data) and data[pos] != 0:
                pos += data[pos] + 1
            pos += 1
        if pos + 10 > len(data):
            return None
        rtype = int.from_bytes(data[pos:pos + 2], 'big')
        rdlength = int.from_bytes(data[pos + 8:pos + 10], 'big')
        pos += 10
        if rtype == 1 and rdlength == 4:  # tipo A
            return '.'.join(str(b) for b in data[pos:pos + 4])
        pos += rdlength

    return None


def _udp_dns_resolve(hostname, timeout=3):
    query = _build_dns_query(hostname)
    for dns_ip in _UDP_DNS_SERVERS:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(query, (dns_ip, 53))
            data, _ = sock.recvfrom(512)
            ip = _parse_dns_a_response(data)
            if ip and _is_ip(ip):
                return ip
        except Exception as e:
            _log(f'DNS UDP falhou ({dns_ip}): {e}', 'warning')
            continue
        finally:
            sock.close()
    return None

_orig_getaddrinfo = socket.getaddrinfo


def _is_ip(host):
    if not host:
        return False
    host = host.strip('[]')
    if _RE_IPV4.match(host):
        try:
            parts = host.split('.')
            return all(0 <= int(p) <= 255 for p in parts)
        except Exception:
            return False
    if ':' in host and _RE_IPV6.match(host):
        return True
    return False


def _doh_resolve(hostname, timeout=5):
    if _is_ip(hostname):
        return hostname

    now = time.time()
    with _DNS_CACHE_LOCK:
        cached = _DNS_CACHE.get(hostname)
        if cached and now - cached[1] < _DNS_CACHE_TTL:
            return cached[0]

    for doh_url in DOH_SERVERS:
        try:
            req_url = f'{doh_url}?name={quote(hostname)}&type=A'
            req = urllib.request.Request(req_url, headers={
                'Accept': 'application/dns-json',
                'User-Agent': 'NEXUS-CORE-DoH/1.0',
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if 'Answer' in data:
                    for ans in data['Answer']:
                        if ans.get('type') == 1:
                            ip = ans.get('data')
                            if ip and _is_ip(ip):
                                with _DNS_CACHE_LOCK:
                                    _DNS_CACHE[hostname] = (ip, now)
                                _log(f'DoH: {hostname} -> {ip}')
                                return ip
        except Exception as e:
            _log(f'DoH falhou ({doh_url}): {e}', 'warning')
            continue

    # Camada intermediária: DoH via HTTPS falhou (bloqueado/filtrado?),
    # tenta DNS UDP direto antes de recorrer ao DNS do sistema — que
    # em muitas redes é o próprio DNS do provedor, frequentemente a
    # origem do problema que estamos tentando contornar
    try:
        ip = _udp_dns_resolve(hostname)
        if ip and _is_ip(ip):
            with _DNS_CACHE_LOCK:
                _DNS_CACHE[hostname] = (ip, now)
            _log(f'DNS UDP: {hostname} -> {ip}')
            return ip
    except Exception as e:
        _log(f'DNS UDP falhou completamente: {e}', 'warning')

    try:
        results = _orig_getaddrinfo(hostname, None)
        if results:
            ip = results[0][4][0]
            with _DNS_CACHE_LOCK:
                _DNS_CACHE[hostname] = (ip, now)
            _log(f'DNS local: {hostname} -> {ip}')
            return ip
    except Exception:
        pass

    _log(f'Não foi possível resolver: {hostname}', 'error')
    return hostname


def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if getattr(_in_doh_resolution, 'active', False):
        return _orig_getaddrinfo(host, port, family, type, proto, flags)

    if host and not _is_ip(host):
        try:
            _in_doh_resolution.active = True
            ip = _doh_resolve(host)
            if ip and _is_ip(ip):
                host = ip
        except Exception:
            pass
        finally:
            _in_doh_resolution.active = False

    return _orig_getaddrinfo(host, port, family, type, proto, flags)


socket.getaddrinfo = _patched_getaddrinfo
_log('DoH resolver ativado (socket.getaddrinfo patcheado com anti-recursão)')

# ════════════════════════════════════════════════════════════
# SSL CONTEXT
# ════════════════════════════════════════════════════════════

_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode   = ssl.CERT_NONE

_UA_FALLBACK = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# ════════════════════════════════════════════════════════════
# COOKIE STORE
# ════════════════════════════════════════════════════════════

_simple_cookies = {}
_cookie_lock    = threading.Lock()


def _get_cookie_header(url):
    netloc = urlparse(url).netloc
    parts = []
    with _cookie_lock:
        for domain, cookies in _simple_cookies.items():
            d = domain.lstrip('.')
            if d == netloc or netloc.endswith('.' + d) or d in netloc:
                for name, value in cookies.items():
                    parts.append(f'{name}={value}')
    return '; '.join(parts) if parts else None


def _save_cookies(url, set_cookie_headers):
    if not set_cookie_headers:
        return
    netloc = urlparse(url).netloc
    if isinstance(set_cookie_headers, str):
        set_cookie_headers = [set_cookie_headers]
    with _cookie_lock:
        for sc in set_cookie_headers:
            parts = sc.split(';')[0].split('=', 1)
            if len(parts) != 2:
                continue
            name  = parts[0].strip()
            value = parts[1].strip()
            domain = netloc
            for attr in sc.split(';')[1:]:
                a = attr.strip()
                if a.lower().startswith('domain='):
                    domain = a.split('=', 1)[1].strip()
                    break
            key_domain = domain.lstrip('.')
            if key_domain not in _simple_cookies:
                _simple_cookies[key_domain] = {}
            _simple_cookies[key_domain][name] = value


# ════════════════════════════════════════════════════════════
# FALSE 200 DETECTION
# ════════════════════════════════════════════════════════════

_HTML_ERROR_INDICATORS = [
    b'<html', b'<!doctype', b'<head>', b'<title>', b'<?xml',
    b'<body', b'<center>', b'<h1>', b'<h2>',
]

_TEXT_ERROR_INDICATORS = [
    b'error 500', b'error 404', b'error 403', b'error 400',
    b'internal server error', b'access denied', b'forbidden',
    b'service unavailable', b'maintenance mode', b'timeout',
    b'not found', b'unauthorized', b'bad request', b'overload',
    b'rate limit', b'too many requests', b'server error',
]


def _is_false_200(body, is_playlist=False):
    if not body or len(body) == 0:
        return True

    if is_playlist:
        text = body.decode('utf-8', errors='ignore').strip()
        if not text:
            return True
        if '#EXTM3U' not in text:
            return True
        if _is_empty_playlist(body):
            return True

    head = body[:1024].lower()

    for indicator in _HTML_ERROR_INDICATORS:
        if indicator in head:
            return True

    for indicator in _TEXT_ERROR_INDICATORS:
        if indicator in head:
            return True

    if not is_playlist and len(body) < 8:
        return True

    return False


def _is_empty_playlist(body):
    text = body.decode('utf-8', errors='ignore').replace('\r\n', '\n')
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('#'):
            continue
        return False
    return True


# ════════════════════════════════════════════════════════════
# ANTI-TRAVA OTT — MEDIA-SEQUENCE STALL/ROTATION DETECTOR
# ════════════════════════════════════════════════════════════
# Detecta manifesto "falso saudável": passa em _is_false_200 e
# _is_empty_playlist, mas o EXT-X-MEDIA-SEQUENCE não avança (CDN
# devolvendo o mesmo manifesto em loop) ou regride (failover de
# origem sem coordenação). Nenhum dos dois é um erro HTTP — o
# player simplesmente trava reproduzindo o mesmo trecho.

_RE_MEDIA_SEQUENCE = re.compile(rb'#EXT-X-MEDIA-SEQUENCE:\s*(\d+)')
_RE_DISCONTINUITY_SEQ = re.compile(rb'#EXT-X-DISCONTINUITY-SEQUENCE:\s*(\d+)')

_sequence_state      = {}
_sequence_state_lock = threading.Lock()

_SEQUENCE_STALL_LIMIT = 4      # nº de fetches seguidos com a mesma sequence antes de forçar bypass de cache
_SEQUENCE_STALL_WINDOW = 6.0   # segundos de estagnação real tolerados antes de considerar travado


def _extract_media_sequence(body):
    m = _RE_MEDIA_SEQUENCE.search(body[:2048])
    if not m:
        return None
    try:
        return int(m.group(1))
    except (ValueError, TypeError):
        return None


def _check_sequence_health(url, body, origin_netloc=None):
    """
    Retorna (is_stalled, is_regressed, origin_changed). Atualiza o
    estado interno a cada chamada — deve ser chamado uma vez por
    fetch bem-sucedido de playlist, mesmo quando o resultado vem do
    cache normal (não do stale), para o relógio de estagnação
    refletir tempo real.

    origin_netloc é o host físico que respondeu (após seguir todos
    os redirects) — cada CDN/edge mantém sua própria numeração de
    MEDIA-SEQUENCE, então uma "regressão" grande é quase sempre uma
    troca de origem, não uma regressão real da mesma timeline. Os
    dois sinais (troca de host, regressão de sequence) são reportados
    separadamente porque cada um pode acontecer sem o outro: o
    provedor pode trocar de host mantendo sequence coerente, ou
    regredir sequence no mesmo host (jitter de cache do edge).
    """
    seq = _extract_media_sequence(body)
    now = time.time()

    with _sequence_state_lock:
        prev = _sequence_state.get(url)

        if prev is None:
            _sequence_state[url] = {
                'seq': seq, 'origin': origin_netloc,
                'first_seen': now, 'last_change': now, 'repeats': 0,
            }
            return False, False, False

        origin_changed = (
            origin_netloc is not None
            and prev.get('origin') is not None
            and origin_netloc != prev['origin']
        )

        if seq is None:
            # manifesto sem MEDIA-SEQUENCE (raro, mas válido em VOD) —
            # só atualiza a origem conhecida, não mexe no relógio de seq
            prev['origin'] = origin_netloc or prev.get('origin')
            return False, False, origin_changed

        if seq < prev['seq']:
            _log(
                f'MEDIA-SEQUENCE regressiva detectada: {prev["seq"]} -> {seq}'
                + (f' (origem mudou: {prev.get("origin")} -> {origin_netloc})'
                   if origin_changed else ' (mesma origem — jitter de edge)'),
                'warning'
            )
            _sequence_state[url] = {
                'seq': seq, 'origin': origin_netloc,
                'first_seen': now, 'last_change': now, 'repeats': 0,
            }
            return False, True, origin_changed

        if seq == prev['seq']:
            stalled_for = now - prev['last_change']
            prev['repeats'] += 1
            prev['origin'] = origin_netloc or prev.get('origin')
            is_stalled = (
                prev['repeats'] >= _SEQUENCE_STALL_LIMIT
                and stalled_for >= _SEQUENCE_STALL_WINDOW
            )
            if is_stalled:
                _log(
                    f'MEDIA-SEQUENCE estagnada há {stalled_for:.1f}s '
                    f'({prev["repeats"]} fetches repetidos) — forçando bypass',
                    'warning'
                )
            return is_stalled, False, origin_changed

        prev['seq'] = seq
        prev['origin'] = origin_netloc or prev.get('origin')
        prev['last_change'] = now
        prev['repeats'] = 0
        if origin_changed:
            _log(
                f'Origem trocou com sequence coerente: '
                f'{prev.get("origin")} -> {origin_netloc} (seq={seq})',
                'warning'
            )
        return False, False, origin_changed


def _reset_sequence_state(url):
    with _sequence_state_lock:
        _sequence_state.pop(url, None)


# ════════════════════════════════════════════════════════════
# ANTI-TRAVA OTT — COOLDOWN DIFERENCIADO POR CÓDIGO DE ERRO
# ════════════════════════════════════════════════════════════
# Nem todo erro HTTP pede a mesma espera: 429 (rate limit) e 403
# (provável limite de sessão excedido) indicam que insistir rápido
# piora a situação; 404 não tem motivo pra esperar muito, o recurso
# simplesmente não existe naquela URL. Um sleep genérico único
# trata os dois casos igual, o que é tempo perdido num caso e
# insistência agressiva demais no outro.

_ERROR_COOLDOWNS = {
    429: 4.0,   # Too Many Requests — servidor está limitando ativamente
    500: 1.0,   # Internal Server Error
    502: 1.0,   # Bad Gateway
    503: 1.5,   # Service Unavailable
    403: 2.5,   # Forbidden — provável limite de sessão/conexão excedido
    404: 0.2,   # Not Found — não adianta esperar muito
}
_ERROR_COOLDOWN_DEFAULT = 0.3  # mesmo valor base que já era usado antes desta mudança


def _cooldown_for_status(status, attempt):
    """
    Tempo de espera (segundos) antes da próxima tentativa, escalado
    pelo número de tentativas já feitas (mesma lógica incremental de
    antes: attempt+1), com o PISO diferenciado pelo código. O teto
    efetivo contra o watchdog de tempo dos handlers não vem de um
    cap artificial aqui (que precisaria ser tão baixo a ponto de
    anular a diferenciação por código) — vem do parâmetro `deadline`
    opcional de HttpSession.fetch(), que interrompe o loop de
    retries de dentro, onde o tempo é de fato gasto.
    """
    base = _ERROR_COOLDOWNS.get(status, _ERROR_COOLDOWN_DEFAULT)
    return base * (attempt + 1)


# ════════════════════════════════════════════════════════════
# CDN POOL REGISTRY — Pool dinâmico por IP resolvido
# ════════════════════════════════════════════════════════════
# Problema real que isto resolve: HttpSession antes chaveava conexões
# só por (scheme, netloc) — ou seja, por HOSTNAME lógico. Mas um
# hostname de CDN frequentemente resolve pra IPs diferentes ao longo
# do tempo (round-robin de edge, failover, GSLB por carga/latência).
# Quando isso acontece NO MEIO de uma sessão keep-alive já aberta, o
# socket TCP continua "vivo" do ponto de vista do cliente (a conexão
# em si não caiu), mas o servidor do lado antigo pode já ter reciclado
# aquele slot — resultando em respostas vazias, RST tardio, ou pior:
# uma resposta 200 servida por um edge que não é mais o dono canônico
# do stream (manifesto/segmento fora de sincronia com o que os outros
# handlers esperam).
#
# A resolução DoH já roda por baixo (via socket.getaddrinfo patcheado)
# antes de toda conexão TCP nova — então já SABEMOS o IP que vai ser
# usado antes de abrir o socket. O registry abaixo captura esse IP e
# o injeta na chave do pool de conexões da HttpSession: uma troca de
# IP por trás do mesmo hostname passa a abrir um NOVO pool (nova
# conexão física), em vez de reaproveitar cegamente o socket antigo
# que aponta pro edge anterior. O pool velho não é destruído
# imediatamente — fica órfão e é coletado por TTL de ociosidade
# (_CDN_POOL_IDLE_TTL), então um IP que "volta" dentro da janela ainda
# reaproveita a conexão sem reabrir do zero.

_CDN_POOL_IDLE_TTL = 90.0  # segundos sem uso antes de um pool órfão (IP antigo) ser fechado
_CDN_POOL_SWEEP_INTERVAL = 30.0  # intervalo mínimo entre varreduras de limpeza


def _resolve_pool_ip(hostname, timeout=5):
    """
    Resolve o IP que será efetivamente usado para `hostname`, reaproveitando
    o mesmo cache/DoH/fallback UDP/fallback local que já protege o resto do
    proxy — não é uma segunda lógica de resolução, é a mesma (_doh_resolve),
    chamada explicitamente aqui para capturar o IP ANTES de abrir a conexão
    TCP, ao invés de deixá-lo implícito dentro do connect() via getaddrinfo
    patcheado. Se `hostname` já for um literal IP, _doh_resolve devolve ele
    mesmo (short-circuit no topo da função).
    """
    try:
        return _doh_resolve(hostname, timeout=timeout)
    except Exception as e:
        _log(f'Resolução de IP para pool falhou ({hostname}): {e} — usando hostname como chave', 'warning')
        return hostname


# ════════════════════════════════════════════════════════════
# PERSISTENT HTTP SESSION (STRICTLY Single Connection Per Host,
# com Pool Dinâmico por CDN/IP resolvido)
# ════════════════════════════════════════════════════════════

class HttpSession:
    # Piso de tempo entre o FIM de uma requisição bem-sucedida a um
    # host e o INÍCIO da próxima ao mesmo host — mesmo com só 1
    # conexão TCP serializada, uma sequência rápida demais de
    # requisições seriais ainda pode ser lida como rajada suspeita
    # por alguns provedores.
    MIN_INTER_REQUEST_DELAY = 0.10

    def __init__(self):
        self._conns = {}
        self._locks = {}
        self._meta_lock = threading.Lock()
        self._last_request_at = {}   # key -> timestamp da última resposta recebida
        self._last_used_at = {}      # key -> timestamp de último uso (para eviction por IDLE_TTL)
        self._host_current_ip = {}   # netloc lógico -> IP atualmente ativo (para log/diagnóstico)
        self._last_sweep_at = 0.0

    def _get_lock(self, key):
        with self._meta_lock:
            if key not in self._locks:
                self._locks[key] = threading.RLock()
            return self._locks[key]

    def _pool_key(self, scheme, netloc, timeout):
        """
        Monta a chave de pool incluindo o IP resolvido, não só o netloc
        lógico. `netloc` aqui pode já conter porta (ex: 'cdn.exemplo.com:443')
        — separamos host/porta antes de resolver, e recompomos a chave como
        (scheme, host_logico, ip_resolvido, porta) para que:
          • troca de IP por trás do mesmo host = nova chave = novo pool
          • host lógico continua rastreável nos logs/diagnóstico
          • porta explícita não se perde na resolução
        """
        if netloc.startswith('['):
            # IPv6 com colchetes: ']' fecha o literal, o que vier depois
            # de ']:' é a porta. rpartition(':') sozinho quebraria aqui
            # porque um endereço IPv6 tem vários ':' internos.
            close_idx = netloc.find(']')
            if close_idx != -1:
                host_part = netloc[1:close_idx]
                rest = netloc[close_idx + 1:]
                port_part = rest[1:] if rest.startswith(':') else ''
            else:
                host_part, port_part = netloc, ''
        elif netloc.count(':') == 1:
            # host:porta padrão (hostname ou IPv4) — exatamente um ':'
            host_part, _, port_part = netloc.rpartition(':')
        else:
            # IPv6 cru sem colchetes (sem porta) ou qualquer coisa com
            # múltiplos ':' sem colchetes: não há como separar porta de
            # forma não-ambígua, trata como host puro
            host_part, port_part = netloc, ''

        resolved_ip = _resolve_pool_ip(host_part, timeout=min(timeout, 5))

        with self._meta_lock:
            prev_ip = self._host_current_ip.get(netloc)
            if prev_ip is not None and prev_ip != resolved_ip:
                _log(
                    f'CDN Pool: IP mudou para {host_part}: {prev_ip} -> {resolved_ip} '
                    f'— abrindo novo pool (conexão antiga fica órfã, TTL={_CDN_POOL_IDLE_TTL:.0f}s)',
                    'warning'
                )
            self._host_current_ip[netloc] = resolved_ip

        return (scheme, host_part, resolved_ip, port_part)

    def _get_conn(self, scheme, netloc, timeout, pool_key):
        # pool_key já vem pronto de _pool_key() (inclui o IP resolvido).
        # Conectamos usando o HOST LÓGICO (netloc original, com porta) —
        # não o IP puro — porque http.client precisa do hostname original
        # para SNI/Host header corretos em HTTPS; a resolução de IP em si
        # já acontece por baixo via socket.getaddrinfo patcheado (DoH), e
        # o cache DoH garante que o mesmo IP já resolvido aqui é o mesmo
        # que será usado na conexão real — não há corrida entre os dois.
        with self._meta_lock:
            conn = self._conns.get(pool_key)
            now = time.time()
            if conn is None:
                if scheme == 'https':
                    conn = http.client.HTTPSConnection(
                        netloc, timeout=timeout, context=_ssl_ctx
                    )
                else:
                    conn = http.client.HTTPConnection(
                        netloc, timeout=timeout
                    )
                self._conns[pool_key] = conn
                _log(f'CDN Pool: nova conexão física para {pool_key[1]} @ {pool_key[2]}')
            self._last_used_at[pool_key] = now
            return conn

    def _kill_conn(self, key):
        with self._meta_lock:
            conn = self._conns.pop(key, None)
            self._last_used_at.pop(key, None)
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    def _sweep_idle_pools(self):
        """
        Fecha pools (IPs antigos de CDN) ociosos há mais de _CDN_POOL_IDLE_TTL.
        Chamado oportunisticamente a cada fetch (taxa limitada por
        _CDN_POOL_SWEEP_INTERVAL, então não é overhead por-requisição real)
        em vez de precisar de uma thread de manutenção dedicada — mantém o
        modelo "sem ThreadPoolExecutor global" já adotado no restante do
        proxy. Sem isso, cada troca de IP de CDN deixaria uma conexão TCP
        pendurada para sempre (vazamento de socket em sessões longas com
        rotação frequente de edge).
        """
        now = time.time()
        with self._meta_lock:
            if now - self._last_sweep_at < _CDN_POOL_SWEEP_INTERVAL:
                return
            self._last_sweep_at = now
            stale_keys = [
                k for k, last_used in self._last_used_at.items()
                if now - last_used >= _CDN_POOL_IDLE_TTL
            ]
            stale_conns = []
            for k in stale_keys:
                conn = self._conns.pop(k, None)
                self._last_used_at.pop(k, None)
                if conn is not None:
                    stale_conns.append((k, conn))

        for k, conn in stale_conns:
            try:
                conn.close()
            except Exception:
                pass
            _log(f'CDN Pool: fechado pool órfão (IP antigo) {k[1]} @ {k[2]} — ocioso >= {_CDN_POOL_IDLE_TTL:.0f}s')

    def _build_headers(self, url, extra=None):
        parsed = urlparse(url)
        h = {
            'Accept':          '*/*',
            'Accept-Language':  'en-US,en;q=0.5',
            'Connection':      'keep-alive',
            'Host':            parsed.netloc,
            'User-Agent':      _UA_FALLBACK,
        }

        if parsed.scheme == 'https':
            h['Origin']  = f'https://{parsed.netloc}'
            h['Referer'] = f'https://{parsed.netloc}/'
        else:
            h['Origin']  = f'http://{parsed.netloc}'
            h['Referer'] = f'http://{parsed.netloc}/'

        cookie_str = _get_cookie_header(url)
        if cookie_str:
            h['Cookie'] = cookie_str

        if extra:
            for k, v in extra.items():
                kl = k.lower()
                if kl not in ('host', 'connection', 'accept-encoding',
                              'user-agent', 'cookie'):
                    h[k] = v
        return h

    def fetch(self, url, extra_headers=None, timeout=30, retries=3,
              is_playlist=False, channel='meta', deadline=None):
        current_url  = url
        last_body    = b''
        last_status  = 200
        last_headers = {}

        self._sweep_idle_pools()

        for _redirect_iter in range(10):
            parsed = urlparse(current_url)

            # A SERIALIZAÇÃO (lock/rate-limit "1 conexão/host") continua
            # sendo por HOST LÓGICO — isso é uma regra de negócio do painel
            # provedor ("1 usuário = 1 conexão"), não sobre qual IP físico
            # atende a conexão. O pool de sockets físicos (pool_key) é uma
            # camada abaixo dessa: pode trocar de IP sem violar o limite de
            # 1 conexão lógica ativa por vez, porque o lock_key serializa
            # ANTES de decidirmos qual pool_key/socket físico usar.
            lock_key = (parsed.scheme, parsed.netloc)
            lock = self._get_lock(lock_key)
            headers = self._build_headers(current_url, extra_headers)
            path = (parsed.path or '/') + (
                ('?' + parsed.query) if parsed.query else ''
            )

            is_redirect = False
            status = 0

            # O Lock garante que NENHUMA requisição simultânea vai para o mesmo servidor
            with lock:
                with self._meta_lock:
                    last_at = self._last_request_at.get(lock_key)
                if last_at is not None:
                    elapsed = time.time() - last_at
                    remaining = self.MIN_INTER_REQUEST_DELAY - elapsed
                    if remaining > 0:
                        time.sleep(remaining)

                # pool_key resolve o IP atual DENTRO do lock — se o IP
                # mudou desde a última requisição a este host, a troca de
                # pool (e o log correspondente) acontece aqui, já
                # serializada, antes de qualquer tentativa de socket.
                pool_key = self._pool_key(parsed.scheme, parsed.netloc, timeout)

                for attempt in range(retries):
                    if deadline is not None and time.time() >= deadline:
                        _log('Deadline de fetch atingido — abortando retries internos', 'warning')
                        break
                    try:
                        conn = self._get_conn(
                            parsed.scheme, parsed.netloc, timeout, pool_key
                        )

                        try:
                            conn.request('GET', path, headers=headers)
                            resp = conn.getresponse()
                        except (http.client.CannotSendRequest, http.client.ResponseNotReady, ConnectionError):
                            # Se a conexão antiga fechar ociosamente, nós a matamos e tentamos no mesmo loop
                            self._kill_conn(pool_key)
                            conn = self._get_conn(parsed.scheme, parsed.netloc, timeout, pool_key)
                            conn.request('GET', path, headers=headers)
                            resp = conn.getresponse()

                        status = resp.status
                        body   = resp.read()

                        resp_headers_list = resp.getheaders()
                        resp_headers = {}
                        set_cookies   = []
                        for k, v in resp_headers_list:
                            if k.lower() == 'set-cookie':
                                set_cookies.append(v)
                            else:
                                resp_headers[k] = v

                        # Precisamos garantir a leitura total do body antes de liberar para a próxima requisição keep-alive
                        resp.close()

                        with self._meta_lock:
                            self._last_request_at[lock_key] = time.time()
                            self._last_used_at[pool_key] = time.time()

                        if set_cookies:
                            _save_cookies(current_url, set_cookies)

                        if resp_headers.get('Connection', '').lower() == 'close':
                            self._kill_conn(pool_key)

                        if status in (301, 302, 307, 308):
                            location = resp_headers.get('Location', '')
                            if location:
                                current_url = urljoin(current_url, location)
                                _log(f'Redirect: -> {current_url[:120]}')
                                is_redirect = True
                                break
                            else:
                                raise Exception("Redirect sem Location header")

                        if status >= 400:
                            cooldown = _cooldown_for_status(status, attempt)
                            if deadline is not None:
                                cooldown = max(0.0, min(cooldown, deadline - time.time()))
                            _log(
                                f'HTTP {status} upstream, '
                                f'retry {attempt + 1}/{retries} '
                                f'(cooldown {cooldown:.1f}s)',
                                'warning'
                            )
                            self._kill_conn(pool_key)
                            time.sleep(cooldown)
                            last_status  = status
                            last_body    = body
                            last_headers = resp_headers
                            continue

                        if _is_false_200(body, is_playlist):
                            _log(
                                f'Falso 200 OK detectado ({len(body)}b), '
                                f'retry {attempt + 1}/{retries}',
                                'warning'
                            )
                            self._kill_conn(pool_key)
                            time.sleep(0.3 * (attempt + 1))
                            continue

                        return body, current_url, status, resp_headers

                    except Exception as e:
                        _log(
                            f'Fetch error retry {attempt + 1}/{retries}: {e}',
                            'warning'
                        )
                        self._kill_conn(pool_key)
                        time.sleep(0.3 * (attempt + 1))

            if is_redirect:
                continue

            return last_body or b'', current_url, last_status, last_headers

        raise Exception("Muitos redirecionamentos")

    def close(self):
        with self._meta_lock:
            for conn in self._conns.values():
                try:
                    conn.close()
                except Exception:
                    pass
            self._conns.clear()
            self._locks.clear()
            self._last_used_at.clear()
            self._host_current_ip.clear()


_session = HttpSession()

# ════════════════════════════════════════════════════════════
# PLAYLIST CACHE + SINGLE-FLIGHT
# ════════════════════════════════════════════════════════════

_playlist_cache     = {}
_playlist_cache_lock = threading.Lock()
_PLAYLIST_CACHE_TTL  = 2

_playlist_flight_locks = {}
_playlist_flight_meta  = threading.Lock()


def _get_flight_lock(url):
    with _playlist_flight_meta:
        if url not in _playlist_flight_locks:
            _playlist_flight_locks[url] = threading.Lock()
        return _playlist_flight_locks[url]


def _get_cached_playlist(url, allow_stale=False):
    with _playlist_cache_lock:
        entry = _playlist_cache.get(url)
        if entry:
            ts, body, final_url = entry
            if allow_stale or (time.time() - ts) < _PLAYLIST_CACHE_TTL:
                return (body, final_url)
    return None


def _set_cached_playlist(url, body, final_url):
    with _playlist_cache_lock:
        _playlist_cache[url] = (time.time(), body, final_url)


# ════════════════════════════════════════════════════════════
# SEGMENT CACHE (com eviction por contagem e por bytes)
# ════════════════════════════════════════════════════════════
# Preenche uma lacuna real: até aqui só playlist e chave eram
# cacheadas. Se duas requisições batem no mesmo segmento (retry do
# player, corrida entre prefetch e pedido real), buscávamos 2x no
# upstream sem necessidade — desperdiçando a única conexão que o
# provedor permite. TTL curto porque segmento é conteúdo efêmero
# (só faz sentido reaproveitar numa janela pequena de tempo);
# eviction dupla (contagem E bytes) evita que poucos segmentos
# grandes estourem a memória de um dispositivo fraco mesmo com
# poucas entradas.

_segment_cache      = {}
_segment_cache_lock = threading.Lock()
_SEGMENT_CACHE_TTL   = 8       # segundos — bem menor que playlist: segmento não deve "revalidar", só evitar fetch duplicado imediato
_SEGMENT_CACHE_MAX_ENTRIES = 24
_SEGMENT_CACHE_MAX_BYTES   = 24 * 1024 * 1024  # 24MB — teto conservador pra TV box de 1GB RAM

_segment_cache_bytes = 0


def _get_cached_segment(url, allow_stale=False):
    with _segment_cache_lock:
        entry = _segment_cache.get(url)
        if entry:
            ts, body, headers = entry
            if allow_stale or (time.time() - ts) < _SEGMENT_CACHE_TTL:
                return (body, headers)
    return None


def _set_cached_segment(url, body, headers):
    global _segment_cache_bytes
    size = len(body)
    if size == 0 or size > _SEGMENT_CACHE_MAX_BYTES:
        # segmento vazio não vale cachear; segmento maior que o teto
        # inteiro sozinho também não — evitaria qualquer outra entrada
        return
    with _segment_cache_lock:
        old = _segment_cache.get(url)
        if old:
            _segment_cache_bytes -= len(old[1])
        _segment_cache[url] = (time.time(), body, headers)
        _segment_cache_bytes += size

        # eviction: por contagem OU por bytes totais, o que vier primeiro
        while (len(_segment_cache) > _SEGMENT_CACHE_MAX_ENTRIES
               or _segment_cache_bytes > _SEGMENT_CACHE_MAX_BYTES):
            oldest_url = min(_segment_cache, key=lambda k: _segment_cache[k][0])
            _, oldest_body, _ = _segment_cache.pop(oldest_url)
            _segment_cache_bytes -= len(oldest_body)


# ════════════════════════════════════════════════════════════
# KEY CACHE
# ════════════════════════════════════════════════════════════

_key_cache      = {}
_key_cache_lock = threading.Lock()


def _get_cached_key(url):
    with _key_cache_lock:
        return _key_cache.get(url)


def _set_cached_key(url, data):
    with _key_cache_lock:
        _key_cache[url] = data


# ════════════════════════════════════════════════════════════
# GLOBAL STATE
# ════════════════════════════════════════════════════════════

_PROXY_PORT   = None
_PROXY_SERVER = None
_PROXY_LOCK   = threading.Lock()

# Teto duro de tempo total por request (watchdog) — independe do nº de
# tentativas do loop interno. Sem isso, retries com sleep crescente podem
# somar mais tempo do que o Kodi tolera antes de considerar o player travado.
_PLAYLIST_HARD_DEADLINE = 8.0
_SEGMENT_HARD_DEADLINE  = 12.0


# ════════════════════════════════════════════════════════════
# HLS PROXY HTTP HANDLER
# ════════════════════════════════════════════════════════════

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):

    protocol_version = 'HTTP/1.1'
    timeout = 15

    def do_GET(self):
        parsed = urlparse(self.path)
        # Exemplo esperado: /playlist/CHAVE_BASE64.m3u8
        clean_path = parsed.path.strip('/')
        parts = clean_path.split('/', 1)
        
        endpoint = parts[0]
        encoded = parts[1] if len(parts) > 1 else ''
        
        if encoded.endswith('.m3u8'):
            encoded = encoded[:-5]
            
        if endpoint == 'favicon.ico' or not encoded:
            self._send_ok_empty()
            return
            
        try:
            original_url = _b64_decode_url(encoded)
        except Exception:
            self._send_ok_empty()
            return
            
        if endpoint in ('playlist', 'master.m3u8', 'playlist.m3u8', 'm3u8'):
            self._handle_playlist({'url': original_url})
        elif endpoint in ('seg', 'segment'):
            self._handle_segment({'url': original_url})
        elif endpoint == 'key':
            self._handle_key({'url': original_url})
        else:
            self._send_ok_empty()

    def do_HEAD(self):
        """HEAD sempre retorna 200 — nunca envia erro ao Kodi."""
        self._send_ok_empty()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin',  '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Content-Length', '0')
        self.end_headers()

    # ──────────────────────────────────────────────────────
    # HELPERS — Nunca envia erro ao Kodi
    # ──────────────────────────────────────────────────────

    def _get_kodi_headers(self):
        kodi_h = {}
        if 'Range' in self.headers:
            kodi_h['Range'] = self.headers['Range']
        return kodi_h

    def _send_ok_playlist(self, body):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send playlist error: {e}', 'warning')

    def _send_ok_segment(self, body, headers=None):
        try:
            self.send_response(200)
            ct = 'video/mp2t'
            if headers:
                ct = headers.get('Content-Type', ct)
            self.send_header('Content-Type', ct)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')

            if headers:
                cr = headers.get('Content-Range')
                if cr:
                    self.send_header('Content-Range', cr)

            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send segment error: {e}', 'warning')

    def _send_ok_key(self, data):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send key error: {e}', 'warning')

    def _send_ok_empty(self):
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', '0')
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _log(f'Send empty error: {e}', 'warning')

    # ──────────────────────────────────────────────────────
    # PLAYLIST HANDLER
    # ──────────────────────────────────────────────────────

    def _handle_playlist(self, params):
        url = params.get('url')
        if not url:
            self._send_ok_playlist(b'#EXTM3U\n#EXT-X-ENDLIST\n')
            return

        flight_lock = _get_flight_lock(url)
        request_deadline = time.time() + _PLAYLIST_HARD_DEADLINE

        with flight_lock:
            cached = _get_cached_playlist(url)
            if cached:
                body, final_url = cached
                origin_netloc = urlparse(final_url).netloc
                is_stalled, is_regressed, origin_changed = _check_sequence_health(
                    url, body, origin_netloc
                )
                if not is_stalled:
                    rewritten = self._rewrite_playlist(
                        body.decode('utf-8', errors='replace'), final_url,
                        inject_discontinuity=(is_regressed or origin_changed),
                    )
                    self._send_ok_playlist(rewritten.encode('utf-8'))
                    return
                # sequence estagnada mesmo no cache "fresco" (TTL curto
                # mascarando repetição real do upstream) — ignora cache
                # e força um fetch novo abaixo
                _log('Cache saudável porém sequence estagnada — bypass forçado', 'warning')

            max_outer_retries = 3
            for outer in range(max_outer_retries):
                if time.time() >= request_deadline:
                    _log('Teto duro de tempo atingido — abortando retries de playlist', 'warning')
                    break
                try:
                    body, final_url, status, headers = _session.fetch(
                        url,
                        extra_headers=self._get_kodi_headers(),
                        timeout=15,
                        retries=3,
                        is_playlist=True,
                        channel='meta',
                        deadline=request_deadline,
                    )

                    if body and not _is_false_200(body, is_playlist=True) \
                       and not _is_empty_playlist(body):
                        origin_netloc = urlparse(final_url).netloc
                        _, is_regressed, origin_changed = _check_sequence_health(
                            url, body, origin_netloc
                        )
                        if is_regressed or origin_changed:
                            # timeline de PTS/DTS pode ter descontinuado —
                            # aceita o manifesto (o estado já foi atualizado
                            # dentro do check) e sinaliza a descontinuidade
                            # ao ffmpeg via EXT-X-DISCONTINUITY em vez de só
                            # trocar de origem silenciosamente (RFC 8216
                            # §4.3.2.3: obrigatório quando muda a sequência
                            # de timestamp entre segmentos)
                            _log(
                                'Playlist aceito com descontinuidade real '
                                f'(regressão={is_regressed}, origem_mudou={origin_changed}) '
                                '— marcando EXT-X-DISCONTINUITY',
                                'warning'
                            )
                        _set_cached_playlist(url, body, final_url)
                        rewritten = self._rewrite_playlist(
                            body.decode('utf-8', errors='replace'), final_url,
                            inject_discontinuity=(is_regressed or origin_changed),
                        )
                        self._send_ok_playlist(rewritten.encode('utf-8'))
                        return
                    else:
                        _log(
                            f'Playlist inválido/empty, '
                            f'tentativa externa {outer + 1}/{max_outer_retries}',
                            'warning'
                        )
                        time.sleep(0.5 * (outer + 1))

                except Exception as e:
                    _log(
                        f'Playlist fetch error, '
                        f'tentativa {outer + 1}/{max_outer_retries}: {e}',
                        'warning'
                    )
                    time.sleep(0.5 * (outer + 1))

            stale = _get_cached_playlist(url, allow_stale=True)
            if stale:
                _log('Servindo playlist do cache stale', 'warning')
                body, final_url = stale
                rewritten = self._rewrite_playlist(
                    body.decode('utf-8', errors='replace'), final_url
                )
                self._send_ok_playlist(rewritten.encode('utf-8'))
                return

            _log('Playlist esgotado — enviando playlist terminal', 'warning')
            self._send_ok_playlist(b'#EXTM3U\n#EXT-X-ENDLIST\n')

    def _rewrite_playlist(self, content, base_url, inject_discontinuity=False):
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        lines   = content.split('\n')
        result  = []
        prev_tag = None
        discontinuity_pending = inject_discontinuity

        for line in lines:
            stripped = line.strip()

            if not stripped:
                result.append('')
                continue

            if stripped.startswith('#'):
                if stripped == '#EXT-X-DISCONTINUITY':
                    # o próprio upstream já está sinalizando a
                    # descontinuidade — o requisito do RFC já está
                    # cumprido por ele, não precisamos (nem devemos)
                    # inserir uma segunda tag em nenhum ponto adiante
                    discontinuity_pending = False
                elif '#EXT-X-STREAM-INF' in stripped:
                    prev_tag = 'stream'
                elif '#EXTINF' in stripped:
                    prev_tag = 'segment'
                    if discontinuity_pending:
                        # a tag precisa vir ANTES do #EXTINF do segmento
                        # afetado, e só se aplica a segmentos de mídia
                        # reais (não a entradas de master playlist, que
                        # apontam para outra playlist e não têm timeline
                        # de PTS própria aqui)
                        result.append('#EXT-X-DISCONTINUITY')
                        discontinuity_pending = False

                if 'URI="' in stripped:
                    stripped = self._rewrite_uri_in_tag(stripped, base_url)

                result.append(stripped)
                continue

            absolute = urljoin(base_url, stripped)
            b64_url  = _b64_encode_url(absolute)

            if prev_tag == 'stream':
                proxy_url = f'http://127.0.0.1:{_PROXY_PORT}/playlist/{b64_url}.m3u8'
            else:
                proxy_url = f'http://127.0.0.1:{_PROXY_PORT}/seg/{b64_url}'

            result.append(proxy_url)

        return '\n'.join(result)

    def _rewrite_uri_in_tag(self, line, base_url):
        def replace_uri(match):
            original = match.group(1)
            if original.startswith('data:'):
                return f'URI="{original}"'

            absolute = urljoin(base_url, original)
            b64_url  = _b64_encode_url(absolute)

            if '#EXT-X-KEY' in line or '#EXT-X-SESSION-KEY' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/key/{b64_url}"'
            elif '#EXT-X-MAP' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg/{b64_url}"'
            elif '#EXT-X-MEDIA' in line:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/playlist/{b64_url}.m3u8"'
            else:
                return f'URI="http://127.0.0.1:{_PROXY_PORT}/seg/{b64_url}"'

        return re.sub(r'URI="([^"]+)"', replace_uri, line)

    # ──────────────────────────────────────────────────────
    # SEGMENT HANDLER
    # ──────────────────────────────────────────────────────

    def _handle_segment(self, params):
        url = params.get('url')
        if not url:
            self._send_ok_empty()
            return

        cached = _get_cached_segment(url)
        if cached:
            body, headers = cached
            self._send_ok_segment(body, headers)
            return

        # coalesce: se outra thread já está buscando este MESMO segmento
        # agora, espera o resultado dela em vez de disparar um segundo
        # fetch idêntico ao upstream (reaproveita a mesma estrutura de
        # lock por URL que a playlist já usa — espaços de URL distintos,
        # sem colisão possível entre os dois usos)
        flight_lock = _get_flight_lock(url)

        with flight_lock:
            cached = _get_cached_segment(url)
            if cached:
                body, headers = cached
                self._send_ok_segment(body, headers)
                return

            request_deadline = time.time() + _SEGMENT_HARD_DEADLINE

            max_outer_retries = 3
            for outer in range(max_outer_retries):
                if time.time() >= request_deadline:
                    _log('Teto duro de tempo atingido — abortando retries de segmento', 'warning')
                    break
                try:
                    body, final_url, status, headers = _session.fetch(
                        url,
                        extra_headers=self._get_kodi_headers(),
                        timeout=30,
                        retries=3,
                        is_playlist=False,
                        channel='data',
                        deadline=request_deadline,
                    )

                    if body and len(body) > 0 \
                       and not _is_false_200(body, is_playlist=False):
                        _set_cached_segment(url, body, headers)
                        self._send_ok_segment(body, headers)
                        return
                    else:
                        _log(
                            f'Segment inválido/empty ({len(body)}b), '
                            f'tentativa {outer + 1}/{max_outer_retries}',
                            'warning'
                        )
                        time.sleep(0.3 * (outer + 1))

                except Exception as e:
                    _log(
                        f'Segment fetch error, '
                        f'tentativa {outer + 1}/{max_outer_retries}: {e}',
                        'warning'
                    )
                    time.sleep(0.3 * (outer + 1))

            stale = _get_cached_segment(url, allow_stale=True)
            if stale:
                _log('Servindo segmento do cache stale (upstream esgotado)', 'warning')
                body, headers = stale
                self._send_ok_segment(body, headers)
                return

            _log(f'Segment esgotado — enviando vazio: {url[:80]}', 'warning')
            self._send_ok_empty()

    # ──────────────────────────────────────────────────────
    # KEY HANDLER (AES-128)
    # ──────────────────────────────────────────────────────

    def _handle_key(self, params):
        url = params.get('url')
        if not url:
            self._send_ok_key(b'\x00' * 16)
            return

        cached_key = _get_cached_key(url)
        if cached_key:
            self._send_ok_key(cached_key)
            return

        request_deadline = time.time() + _SEGMENT_HARD_DEADLINE

        max_outer_retries = 3
        for outer in range(max_outer_retries):
            if time.time() >= request_deadline:
                _log('Teto duro de tempo atingido — abortando retries de chave', 'warning')
                break
            try:
                body, final_url, status, headers = _session.fetch(
                    url,
                    extra_headers=self._get_kodi_headers(),
                    timeout=15,
                    retries=3,
                    is_playlist=False,
                    channel='meta',
                    deadline=request_deadline,
                )

                if body and len(body) >= 16 \
                   and not _is_false_200(body, is_playlist=False):
                    key_hex = body[:16].hex()
                    _log(
                        f'AES-128 Key: {len(body)}b '
                        f'hex={key_hex[:32]}... <- {url[:80]}'
                    )
                    _set_cached_key(url, body)
                    self._send_ok_key(body)
                    return
                else:
                    _log(
                        f'Key inválida ({len(body)}b), '
                        f'tentativa {outer + 1}/{max_outer_retries}',
                        'warning'
                    )
                    time.sleep(0.3 * (outer + 1))

            except Exception as e:
                _log(
                    f'Key fetch error, '
                    f'tentativa {outer + 1}/{max_outer_retries}: {e}',
                    'warning'
                )
                time.sleep(0.3 * (outer + 1))

        _log(f'Key esgotada — enviando zeros: {url[:80]}', 'warning')
        self._send_ok_key(b'\x00' * 16)

    def log_message(self, format, *args):
        pass


# ════════════════════════════════════════════════════════════
# THREADED HTTP SERVER
# ════════════════════════════════════════════════════════════

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads      = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        """
        Sobrescreve o handler de erros do SocketServer para silenciar 
        o log de ConnectionResetError e BrokenPipeError no Kodi.
        """
        e_type, e_value, e_tb = sys.exc_info()
        if e_type in (ConnectionResetError, BrokenPipeError, ssl.SSLError, TimeoutError):
            return
        if DEBUG_LOG_ENABLED:
            _log(f"Erro no SocketServer: {e_type.__name__}: {e_value}", 'error')


# ════════════════════════════════════════════════════════════
# SERVER MANAGEMENT
# ════════════════════════════════════════════════════════════

def _ensure_server_running():
    global _PROXY_PORT, _PROXY_SERVER
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None and _PROXY_PORT is not None:
            return _PROXY_PORT

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', 0))
        _PROXY_PORT = sock.getsockname()[1]
        sock.close()

        _PROXY_SERVER = ThreadingHTTPServer(
            ('127.0.0.1', _PROXY_PORT), HLSProxyHandler
        )

        thread = threading.Thread(
            target=_PROXY_SERVER.serve_forever, daemon=True
        )
        thread.start()

        _log(f'HLS Proxy server iniciado na porta {_PROXY_PORT}')
        return _PROXY_PORT


def _stop_server():
    global _PROXY_SERVER, _PROXY_PORT
    with _PROXY_LOCK:
        if _PROXY_SERVER is not None:
            _PROXY_SERVER.shutdown()
            _PROXY_SERVER.server_close()
            _PROXY_SERVER = None
            _PROXY_PORT   = None
            _log('HLS Proxy server parado')
    _session.close()


# ════════════════════════════════════════════════════════════
# KODI ADDON INTERFACE
# ════════════════════════════════════════════════════════════

class HLSAddon:
    def __init__(self, addon_handle=None):
        self.addon_handle = addon_handle

    def play_stream(self, url):
        import xbmc
        import xbmcplugin
        import xbmcgui

        port = _ensure_server_running()
        _reset_sequence_state(url)
        b64_url = _b64_encode_url(url)
        # A URL agora usa Path Parameters em vez de Query String
        proxy_url = f'http://127.0.0.1:{port}/playlist/{b64_url}.m3u8'

        _log(f'play_stream: {url[:120]}')
        _log(f'proxy_url: {proxy_url[:150]}')

        li = xbmcgui.ListItem(path=proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)

        if self.addon_handle is not None:
            xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
        else:
            xbmc.Player().play(proxy_url, li)