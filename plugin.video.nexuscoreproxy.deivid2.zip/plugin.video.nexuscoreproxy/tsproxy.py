#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tsproxy.py — NEXUS CORE MPEG-TS SUTURE ENGINE (DYNAMIC REAL-TIME)
# Autor: Deivid Silva
# Versão: 9.7 — OTT Plus (Sliding Window Suture + Alignment Fix)
#          FIX: Sutura agora usa Sliding Window Front-to-Back real.
#          FIX: Alinhamento estrito de 188 bytes na sutura (sem cortar pacotes).
#          FIX: Tail capturado dos bytes RAW exatos (previne falsos positivos).
#          FIX: Retomada instantânea quando não há sobreposição (live edge).

import http.server
import socketserver
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue
import collections
import json
import ipaddress
import sys

# ─────────────────────────────────────────────
#  LOG SWITCH
# ─────────────────────────────────────────────
_LOG_ENABLED = False

try:
    import xbmc
    _HAS_XBMC = True
except Exception:
    xbmc = None
    _HAS_XBMC = False

_LOG_LEVELS = {}
if _HAS_XBMC:
    _LOG_LEVELS = {
        "DEBUG": xbmc.LOGDEBUG,
        "INFO": xbmc.LOGINFO,
        "WARNING": xbmc.LOGWARNING,
        "ERROR": xbmc.LOGERROR,
    }

def set_log_enabled(enabled: bool):
    global _LOG_ENABLED
    _LOG_ENABLED = bool(enabled)

def _log(msg, level="INFO"):
    if not _LOG_ENABLED:
        return
    try:
        if _HAS_XBMC:
            lvl = _LOG_LEVELS.get(level, xbmc.LOGDEBUG)
            xbmc.log(msg, lvl)
        else:
            print(f"[NexusCore] {msg}", file=sys.stderr)
    except Exception:
        pass

# ─────────────────────────────────────────────
#  CONSTANTES MPEG-TS E SUTURA
# ─────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

CHUNK_SIZE = TS_PACKET_SIZE * 348
MAX_OUTPUT_BUFFER = 10
MAX_SYNC_ATTEMPTS_PER_CYCLE = 5000
SYNC_CONFIRM_PACKETS = 20
SUTURE_SYNC_CONFIRM = 20

# FIX: Tail size múltiplo de 188 para manter alinhamento estrito
TAIL_SIZE = TS_PACKET_SIZE * 700  # 131 KB

SUTURE_WINDOW_LIMIT = 512 * 1024  # 512 KB

READ_CHUNK_DEADLINE = 15.0
READ_SOCKET_TIMEOUT = READ_CHUNK_DEADLINE

CONSECUTIVE_EOF_BACKOFF_START = 2
CONSECUTIVE_EOF_BACKOFF_STEP = 1.5
CONSECUTIVE_EOF_BACKOFF_MAX = 10.0

BACKOFF_MAX_SECONDS = 45.0

SUTURE_SEARCH_DEADLINE = 15.0
SUTURE_SEARCH_HEARTBEAT_INTERVAL = 5.0

RAPID_DROP_THRESHOLD = 5.0
RAPID_DROP_BACKOFF_BASE = 3.0
RAPID_DROP_BACKOFF_STEP = 2.0
RAPID_DROP_BACKOFF_MAX = 20.0

def _build_null_burst(count: int = 24) -> bytes:
    burst = bytearray()
    for i in range(count):
        cc = i & 0x0F
        hdr = bytearray([0x47, 0x1F, 0xFF, 0x10 | cc])
        burst.extend(hdr)
        burst.extend(b'\xFF' * 184)
    return bytes(burst)

NULL_PUMP_BURST = _build_null_burst(24)

# ─────────────────────────────────────────────
#  HELPERS DE ALINHAMENTO
# ─────────────────────────────────────────────
def _strict_ts_align(data: bytes) -> bytes:
    if not data:
        return b''
    remainder = len(data) % TS_PACKET_SIZE
    if remainder:
        return bytes(data[:-remainder])
    return bytes(data)

def _verify_aligned_sync(data, offset: int, max_check: int = 10) -> bool:
    length = len(data)
    if offset >= length or data[offset] != TS_SYNC_BYTE:
        return False
    check_count = min(max_check, (length - offset) // TS_PACKET_SIZE)
    if check_count < 3:
        return False
    for k in range(check_count):
        pos = offset + k * TS_PACKET_SIZE
        if pos >= length or data[pos] != TS_SYNC_BYTE:
            return False
    return True

def _mark_packet_discontinuity(packet: bytearray) -> bool:
    afc = (packet[3] & 0x30) >> 4
    if afc == 3 and len(packet) > 5 and packet[4] > 0:
        packet[5] |= 0x80
        return True
    if afc == 2 and len(packet) > 5 and packet[4] > 0:
        packet[5] |= 0x80
        return True
    return False

def _detect_live_stream(url: str) -> bool:
    if not url:
        return False
    url_lower = url.lower()
    live_patterns = ['/live/', '/live?', '/stream/live', '/iptv/live', '/hls/live', '/live.m3u8']
    for pattern in live_patterns:
        if pattern in url_lower:
            return True
    return False

# ─────────────────────────────────────────────
#  SMART HEADERS ANTI-BLOQUEIO
# ─────────────────────────────────────────────
def build_stream_headers(ua: str, referer: str = None, host: str = None) -> dict:
    headers = {
        'User-Agent': ua,
        'Accept': '*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache, no-store',
        'Pragma': 'no-cache',
        'TE': 'trailers',
        'DNT': '1',
        'Sec-Fetch-Dest': 'video',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'cross-site',
        'X-Forwarded-For': f"{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}",
        'X-Real-IP': f"{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}",
    }
    if referer:
        headers['Referer'] = referer
        headers['Origin'] = '/'.join(referer.split('/')[:3])
    if host:
        headers['Host'] = host
    return headers

# ─────────────────────────────────────────────
#  CONNECTION POOL
# ─────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

class SingleHostConnectionPool:
    def __init__(self):
        self._pools = {}
        self._master_lock = threading.Lock()
        self._cleanup_interval = 60
        self._last_cleanup = time.time()

    def _cleanup_inactive(self):
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return
        self._last_cleanup = now
        inactive_threshold = 300
        with self._master_lock:
            dead_hosts = []
            for hostname, pool_info in self._pools.items():
                if now - pool_info['last_used'] > inactive_threshold and pool_info.get('active_streams', 0) == 0:
                    dead_hosts.append(hostname)
            for hostname in dead_hosts:
                pool_info = self._pools.pop(hostname, None)
                if pool_info:
                    try:
                        pool_info['session'].close()
                    except Exception:
                        pass
                    _log(f"[Pool] Conexão inativa para {hostname} removida", "INFO")

    def _create_session(self):
        return urllib.request.build_opener(
            urllib.request.HTTPHandler(debuglevel=0),
            urllib.request.HTTPSHandler(debuglevel=0),
            NoRedirectHandler()
        )

    def acquire_session(self, target_host: str):
        self._cleanup_inactive()
        with self._master_lock:
            if target_host not in self._pools:
                self._pools[target_host] = {
                    'session': self._create_session(),
                    'lock': threading.Lock(),
                    'last_used': time.time(),
                    'active_streams': 0
                }
                _log(f"[Pool] Nova sessão persistente criada para {target_host}", "INFO")
            pool_info = self._pools[target_host]
            pool_info['last_used'] = time.time()

        pool_info['lock'].acquire()

        with self._master_lock:
            pool_info['active_streams'] += 1

        def release():
            with self._master_lock:
                if target_host in self._pools:
                    self._pools[target_host]['active_streams'] = max(0, self._pools[target_host]['active_streams'] - 1)
            pool_info['lock'].release()

        return pool_info['session'], release

    def invalidate_host(self, target_host: str):
        with self._master_lock:
            pool_info = self._pools.pop(target_host, None)
            if pool_info:
                try:
                    pool_info['session'].close()
                except Exception:
                    pass
                _log(f"[Pool] Sessão para {target_host} invalidada e recriada", "WARNING")

    def close_all(self):
        with self._master_lock:
            for hostname, pool_info in self._pools.items():
                try:
                    pool_info['session'].close()
                except Exception:
                    pass
            self._pools.clear()
            _log(f"[Pool] Todas as conexões fechadas", "INFO")

_global_pool = SingleHostConnectionPool()

# ─────────────────────────────────────────────
#  DNS-over-HTTPS RESOLVER
# ─────────────────────────────────────────────
_DOH_PROVIDERS = [
    "https://dns.google/resolve",
    "https://dns.cloudflare.com/dns-query",
    "https://1.1.1.1/dns-query",
    "https://1.0.0.1/dns-query",
]
_DOH_CACHE = collections.OrderedDict()
_DOH_CACHE_MAX = 50
_DOH_CACHE_LOCK = threading.Lock()
_DOH_TIMEOUT = 3.0
_DOH_SYS_FALLBACK_TTL = 30

def _doh_is_ip_address(value: str) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

def _doh_resolve_system_dns(hostname: str, timeout: float = 1.5):
    result = [None]
    def _do_resolve():
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
            for _family, _, _, _, sockaddr in infos:
                ip = sockaddr[0]
                if ip:
                    result[0] = ip
                    break
        except Exception:
            pass
    t = threading.Thread(target=_do_resolve, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]

def _doh_resolve_provider(hostname: str, provider: str, timeout: float = _DOH_TIMEOUT):
    try:
        query = urllib.parse.urlencode({"name": hostname, "type": "A"})
        req = urllib.request.Request(
            f"{provider}?{query}",
            headers={"Accept": "application/dns-json", "User-Agent": "Mozilla/5.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8", "ignore"))
        if data.get("Status", -1) != 0:
            return None
        for answer in data.get("Answer", []):
            if answer.get("type") == 1:
                ip = str(answer.get("data", "")).strip()
                ttl = int(answer.get("TTL", 60))
                try:
                    ipaddress.IPv4Address(ip)
                    return ip, ttl
                except ValueError:
                    continue
    except Exception:
        pass
    return None

def resolve_host_doh(hostname: str):
    if not hostname or _doh_is_ip_address(hostname):
        return hostname
    now = time.time()
    with _DOH_CACHE_LOCK:
        entry = _DOH_CACHE.get(hostname)
        if entry:
            ip, expiry = entry
            if now < expiry:
                return ip
            del _DOH_CACHE[hostname]

    for provider in _DOH_PROVIDERS:
        result = _doh_resolve_provider(hostname, provider)
        if result:
            ip, ttl = result
            with _DOH_CACHE_LOCK:
                if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                    _DOH_CACHE.popitem(last=False)
                _DOH_CACHE[hostname] = (ip, now + min(ttl, 86400))
            return ip

    sys_ip = _doh_resolve_system_dns(hostname, timeout=1.5)
    if sys_ip:
        with _DOH_CACHE_LOCK:
            if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                _DOH_CACHE.popitem(last=False)
            _DOH_CACHE[hostname] = (sys_ip, now + _DOH_SYS_FALLBACK_TTL)
        return sys_ip
    return None

def rewrite_url_with_doh(url: str):
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host or _doh_is_ip_address(host):
        return url, ""
    ip = resolve_host_doh(host)
    if not ip:
        return url, ""
    port = parsed.port
    new_netloc = f"{ip}:{port}" if port else ip
    new_url = urllib.parse.urlunparse(parsed._replace(netloc=new_netloc))
    return new_url, host

def invalidate_doh_cache(hostname: str):
    if hostname:
        with _DOH_CACHE_LOCK:
            if hostname in _DOH_CACHE:
                del _DOH_CACHE[hostname]
                _log(f"[DoH] Cache invalidado para {hostname}", "DEBUG")

# ─────────────────────────────────────────────
#  CACHE DE URL RESOLVIDA
# ─────────────────────────────────────────────
_RESOLVED_URL_CACHE = {}
_RESOLVED_URL_CACHE_LOCK = threading.Lock()
_RESOLVED_URL_CACHE_TTL = 20.0
_RESOLVED_URL_CACHE_MAX = 50

def _get_cached_resolved_url(original_url: str):
    now = time.time()
    with _RESOLVED_URL_CACHE_LOCK:
        entry = _RESOLVED_URL_CACHE.get(original_url)
        if entry:
            resolved, expiry, host = entry
            if now < expiry:
                return resolved, host
            del _RESOLVED_URL_CACHE[original_url]
    return None, None

def _set_cached_resolved_url(original_url: str, resolved_url: str, host: str):
    with _RESOLVED_URL_CACHE_LOCK:
        if len(_RESOLVED_URL_CACHE) >= _RESOLVED_URL_CACHE_MAX:
            oldest_key = next(iter(_RESOLVED_URL_CACHE))
            del _RESOLVED_URL_CACHE[oldest_key]
        _RESOLVED_URL_CACHE[original_url] = (resolved_url, time.time() + _RESOLVED_URL_CACHE_TTL, host)

def _invalidate_cached_resolved_url(original_url: str):
    with _RESOLVED_URL_CACHE_LOCK:
        if original_url in _RESOLVED_URL_CACHE:
            del _RESOLVED_URL_CACHE[original_url]
            _log(f"[Cache] URL resolvida invalidada para {original_url}", "DEBUG")

# ─────────────────────────────────────────────
#  USER-AGENT ROTATION
# ─────────────────────────────────────────────
_USER_AGENTS = [
    "ExoPlayer/2.18.7",
    "ExoPlayer/2.19.1",
    "VLC/3.0.18 LibVLC/3.0.18",
    "VLC/3.0.20 LibVLC/3.0.20",
    "Kodi/20.0 (Windows; Windows 10) Kodi/20.0",
    "Kodi/21.0 (Windows; Windows 11) Kodi/21.0",
    "Lavf/58.76.100",
    "Lavf/60.16.100",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:116.0) Gecko/20100101 Firefox/116.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
    "AppleCoreMedia/1.0.0.20A362 (iPhone; U; CPU OS 16_0 like Mac OS X; en_us)",
    "okhttp/4.10.0",
    "okhttp/4.12.0",
    "Dalvik/2.1.0 (Linux; U; Android 13; SM-G991B Build/TP1A.220624.014)",
    "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)

# ─────────────────────────────────────────────
#  TsBuffer
# ─────────────────────────────────────────────
class TsBuffer:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = False
        self._pids_pending_discontinuity = set()

    def reset_stream_state(self):
        self._buf.clear()
        self._aligned = False
        self._cc_map.clear()
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = True
        self._pids_pending_discontinuity = set()

    def arm_discontinuity(self):
        self._armed_discontinuity = True
        self._pids_pending_discontinuity.clear()
        for pid in self._cc_map:
            self._pids_pending_discontinuity.add(pid)

    def clear_partial_buffer(self):
        self._buf.clear()
        self._aligned = False

    def _confirm_sync(self, data, idx: int, length: int) -> bool:
        checkpoints_needed = SYNC_CONFIRM_PACKETS
        confirmed = 0
        for k in range(checkpoints_needed):
            pos = idx + k * TS_PACKET_SIZE
            if pos >= length:
                break
            if data[pos] != TS_SYNC_BYTE:
                return False
            confirmed += 1
        min_needed = min(checkpoints_needed, max(2, (length - idx) // TS_PACKET_SIZE))
        if confirmed < min_needed:
            return False
        return True

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                self._last_sync_idx = length
                return -1
            self._sync_attempts += 1
            if self._confirm_sync(data, idx, length):
                self._last_sync_idx = idx + TS_PACKET_SIZE
                return idx
            idx += 1
        self._last_sync_idx = idx
        return -1

    def _set_discontinuity_bit(self, packet: bytearray) -> bool:
        return _mark_packet_discontinuity(packet)

    def _process_packets(self, data: bytearray):
        n = len(data) // TS_PACKET_SIZE
        out = bytearray()
        mv = memoryview(data)
        armed_this_batch = self._armed_discontinuity
        seen_this_batch = set()
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            packet_view = mv[offset:offset + TS_PACKET_SIZE]
            if packet_view[0] != TS_SYNC_BYTE:
                self._error_count += 1
                self._aligned = False
                leftover = bytearray(mv[offset:])
                return out, leftover
            packet = bytearray(packet_view)
            pid = ((packet[1] & 0x1F) << 8) | packet[2]
            afc = (packet[3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            cc = packet[3] & 0x0F

            if pid == 0x1FFF:
                out.extend(packet)
                continue

            if armed_this_batch and pid not in seen_this_batch:
                self._pids_pending_discontinuity.add(pid)
                seen_this_batch.add(pid)

            if has_payload:
                self._cc_map[pid] = cc

            if pid in self._pids_pending_discontinuity:
                self._set_discontinuity_bit(packet)
                self._pids_pending_discontinuity.discard(pid)

            out.extend(packet)

        if self._armed_discontinuity and n > 0:
            self._armed_discontinuity = False
        return out, bytearray()

    def feed(self, raw: bytes) -> bytes:
        if not raw:
            return b''
        self._buf.extend(raw)
        result = bytearray()
        while True:
            if not self._aligned:
                self._sync_attempts = 0
                self._last_sync_idx = 0
                idx = self._find_sync(self._buf)
                if idx == -1:
                    if len(self._buf) > TS_PACKET_SIZE * 100:
                        keep_tail = TS_PACKET_SIZE * 2
                        del self._buf[:-keep_tail]
                    return bytes(result)
                if idx > 0:
                    del self._buf[:idx]
                self._aligned = True
            buf_len = len(self._buf)
            usable = buf_len - (buf_len % TS_PACKET_SIZE)
            if usable == 0:
                return bytes(result)
            payload = self._buf[:usable]
            del self._buf[:usable]
            processed, leftover = self._process_packets(payload)
            if processed:
                result.extend(_strict_ts_align(processed))
            if leftover:
                self._buf = leftover + self._buf
                continue
            return _strict_ts_align(result)

# ─────────────────────────────────────────────
#  OutputBuffer
# ─────────────────────────────────────────────
class OutputBuffer:
    def __init__(self, max_packets: int = MAX_OUTPUT_BUFFER):
        self._queue = queue.Queue(maxsize=max_packets)
        self._align_residual = bytearray()
        self._is_active_callback = None

    def set_active_callback(self, callback):
        self._is_active_callback = callback

    def put(self, data: bytes) -> bool:
        if not data:
            return True

        self._align_residual.extend(data)
        total = len(self._align_residual)
        usable = total - (total % TS_PACKET_SIZE)
        if usable == 0:
            return True

        max_chunk = TS_PACKET_SIZE * 348
        offset = 0

        while offset < usable:
            chunk_size = min(max_chunk, usable - offset)
            chunk = bytes(self._align_residual[offset:offset + chunk_size])

            while True:
                if self._is_active_callback and not self._is_active_callback():
                    del self._align_residual[:usable]
                    return False
                try:
                    self._queue.put(chunk, timeout=1.0)
                    break
                except queue.Full:
                    pass

            offset += chunk_size

        del self._align_residual[:usable]
        return True

    def clear(self):
        self._align_residual.clear()
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break

# ─────────────────────────────────────────────
#  StreamContext
# ─────────────────────────────────────────────
class StreamContext:
    def __init__(self, original_url: str, hostname: str):
        self.original_url = original_url
        self.resolved_url = original_url
        self.hostname = hostname
        self.ua = _pick_ua()
        self.reconnect_num = 0
        self.ts_buf = TsBuffer()
        self.output_buf = OutputBuffer()
        self.output_buf.set_active_callback(lambda: self.active)
        self.is_suture_searching = False
        self.has_played_data = False
        self.last_useful_payload = time.time()
        self.created_at = time.time()
        self.total_bytes_streamed = 0
        self.lock = threading.Lock()
        self.active = True
        self.is_live = _detect_live_stream(original_url)
        if self.is_live:
            _log(f"[NexusCore-TSProxy] Live stream detectado pela URL — sutura desabilitada, usando descontinuidade", "INFO")

        self.last_discontinuity_at = None
        self.last_resolved_host = None
        self.cdn_switch_count = 0
        self.last_reconnect_was_cdn_switch = False

        self.consecutive_immediate_eof = 0
        self.rapid_drop_count = 0
        self.connection_started_at = None

        self.stream_tail = bytearray()
        self.current_response = None

    def add_raw_tail(self, data: bytes):
        """FIX: Captura bytes RAW (pré-TsBuffer) e mantém alinhamento estrito de 188 bytes."""
        if not data:
            return
        self.stream_tail.extend(data)
        # Mantém o tamanho do tail múltiplo de 188 para não quebrar alinhamento na busca
        if len(self.stream_tail) > TAIL_SIZE:
            excess = len(self.stream_tail) - TAIL_SIZE
            # Alinha o excesso para remover pacotes inteiros apenas
            aligned_excess = (excess // TS_PACKET_SIZE) * TS_PACKET_SIZE
            if aligned_excess > 0:
                del self.stream_tail[:aligned_excess]

    def get_tail(self) -> bytes:
        return bytes(self.stream_tail)

    def update_activity(self):
        self.last_useful_payload = time.time()

    def is_stale(self, timeout: float = 60.0) -> bool:
        return time.time() - self.last_useful_payload > timeout

_stream_contexts = {}
_stream_contexts_lock = threading.Lock()

def register_stream_context(stream_id: str, ctx: StreamContext):
    with _stream_contexts_lock:
        _stream_contexts[stream_id] = ctx

def unregister_stream_context(stream_id: str):
    with _stream_contexts_lock:
        _stream_contexts.pop(stream_id, None)

def get_stream_context(stream_id: str):
    with _stream_contexts_lock:
        return _stream_contexts.get(stream_id)

def cleanup_stale_contexts():
    with _stream_contexts_lock:
        stale = []
        for sid, ctx in _stream_contexts.items():
            if not ctx.active or ctx.is_stale(timeout=120):
                stale.append(sid)
        for sid in stale:
            _stream_contexts.pop(sid, None)

# ─────────────────────────────────────────────
#  SERVIDOR HTTP PROXY
# ─────────────────────────────────────────────
class TSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        _log(f"[NexusCore-TSProxy] {format % args}", "DEBUG")

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError,
                ConnectionError, OSError) as e:
            _log(f"[NexusCore-TSProxy] Conexão fechada pelo cliente: {type(e).__name__}", "DEBUG")
        except Exception as e:
            _log(f"[NexusCore-TSProxy] Erro no handle: {type(e).__name__}: {str(e)[:80]}", "DEBUG")

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError,
                ConnectionError, OSError):
            self.close_connection = True
        except Exception:
            self.close_connection = True

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        data = _strict_ts_align(data)
        if not data:
            return True
        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError, ConnectionAbortedError):
            return False

    def _consumer_loop(self, ctx: StreamContext):
        while ctx.active:
            try:
                data = ctx.output_buf._queue.get(timeout=0.05)
                if data:
                    if not self._safe_write(data):
                        ctx.active = False
                        self._force_close_upstream(ctx)
                        break
            except queue.Empty:
                if not self._safe_write(NULL_PUMP_BURST):
                    ctx.active = False
                    self._force_close_upstream(ctx)
                    break

        ctx.output_buf.clear()
        _log("[NexusCore-TSProxy] Consumidor encerrado.", "DEBUG")

    def _force_close_upstream(self, ctx: StreamContext):
        resp = ctx.current_response
        if resp is None:
            return
        try:
            resp.close()
        except Exception:
            pass

    def _calculate_backoff(self, reconnect_num: int) -> float:
        base = 0.5
        capped_n = min(reconnect_num, 8)
        raw = base * (2 ** capped_n)
        jitter = raw * random.uniform(-0.2, 0.2)
        with_jitter = raw + jitter
        return max(0.3, min(with_jitter, BACKOFF_MAX_SECONDS))

    def _resolve_url(self, ctx: StreamContext, url: str) -> str:
        cached_resolved, cached_host = _get_cached_resolved_url(url)
        if cached_resolved is not None:
            _log(f"[NexusCore-TSProxy] URL resolvida do cache (evitou resolve HTTP): {cached_host or '?'}", "DEBUG")
            return cached_resolved

        resolve_started_at = time.time()
        curr = url
        for hop in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                fetch_url, doh_host = rewrite_url_with_doh(curr)

                headers = build_stream_headers(ctx.ua, referer=url, host=parsed.hostname)

                if not doh_host:
                    fetch_url = curr
                req = urllib.request.Request(fetch_url, headers=headers)

                target_host = parsed.hostname
                session, release_session = _global_pool.acquire_session(target_host)
                try:
                    with session.open(req, timeout=8) as resp:
                        if resp.code in (301, 302, 303, 307, 308):
                            loc = resp.headers.get('Location')
                            if loc:
                                curr = urllib.parse.urljoin(curr, loc)
                                elapsed = time.time() - resolve_started_at
                                next_host = urllib.parse.urlparse(curr).hostname
                                _log(
                                    f"[NexusCore-TSProxy] Resolve hop {hop + 1}/5 "
                                    f"({elapsed:.1f}s decorridos) -> {next_host}", "DEBUG"
                                )
                                continue
                        break
                finally:
                    release_session()
            except Exception as e:
                elapsed = time.time() - resolve_started_at
                _log(
                    f"[NexusCore-TSProxy] Resolve falhou no hop {hop + 1}/5 "
                    f"({elapsed:.1f}s decorridos, host={parsed.netloc}): "
                    f"{type(e).__name__}: {str(e)[:80]}", "WARNING"
                )
                if doh_host:
                    invalidate_doh_cache(doh_host)
                break
        else:
            elapsed = time.time() - resolve_started_at
            _log(
                f"[NexusCore-TSProxy] Resolve esgotou as 5 tentativas de redirect "
                f"({elapsed:.1f}s decorridos), usando última URL alcançada", "WARNING"
            )

        total_elapsed = time.time() - resolve_started_at
        if total_elapsed > 3.0:
            _log(
                f"[NexusCore-TSProxy] Resolve levou {total_elapsed:.1f}s no total "
                f"(acima do normal — upstream de auth/redirect lento)", "WARNING"
            )

        final_host = urllib.parse.urlparse(curr).hostname
        _set_cached_resolved_url(url, curr, final_host)
        return curr

    def _watchdog_read(self, response, amt: int, deadline: float):
        result_q = queue.Queue(maxsize=1)

        def _do_read():
            try:
                data = response.read(amt)
                try:
                    result_q.put_nowait(('ok', data))
                except queue.Full:
                    pass
            except Exception as e:
                try:
                    result_q.put_nowait(('error', e))
                except queue.Full:
                    pass

        reader_thread = threading.Thread(target=_do_read, daemon=True)
        reader_thread.start()

        try:
            kind, payload = result_q.get(timeout=deadline)
        except queue.Empty:
            try:
                response.fp.raw._sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            raise socket.timeout(
                f"leitura upstream sem completar em {deadline:.0f}s (gotejamento lento ou silêncio)"
            )

        if kind == 'error':
            raise payload
        return payload

    def _read_aligned_chunk(self, response, leftover: bytearray):
        raw = self._watchdog_read(response, CHUNK_SIZE - len(leftover), READ_CHUNK_DEADLINE)
        if not raw:
            return b'', bytearray()

        data = leftover + raw
        leftover.clear()

        idx = data.find(TS_SYNC_BYTE)
        if idx == -1:
            return b'', bytearray()

        data = data[idx:]

        usable = len(data) - (len(data) % TS_PACKET_SIZE)
        if usable == 0:
            leftover.extend(data)
            return b'', leftover

        aligned = data[:usable]
        if usable < len(data):
            leftover.extend(data[usable:])

        return bytes(aligned), leftover

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(400)
            self.end_headers()
            return

        self.close_connection = True

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Connection', 'close')
        self.end_headers()

        parsed_original = urllib.parse.urlparse(original_url)
        hostname = parsed_original.hostname or parsed_original.netloc

        stream_id = f"{hostname}:{id(self)}"
        ctx = StreamContext(original_url, hostname)
        register_stream_context(stream_id, ctx)

        _log(f"[NexusCore-TSProxy] Iniciando stream de {hostname} (UA: {ctx.ua}, Live: {ctx.is_live})", "INFO")

        consumer_thread = threading.Thread(target=self._consumer_loop, args=(ctx,))
        consumer_thread.start()

        try:
            try:
                ctx.resolved_url = self._resolve_url(ctx, ctx.original_url)
                ctx.last_resolved_host = urllib.parse.urlparse(ctx.resolved_url).hostname
            except Exception:
                pass

            self._run_stream_loop(ctx)
        finally:
            ctx.active = False
            self._force_close_upstream(ctx)
            consumer_thread.join(timeout=5.0)
            unregister_stream_context(stream_id)
            _log(f"[NexusCore-TSProxy] Stream finalizado: {hostname} "
                 f"(bytes: {ctx.total_bytes_streamed}, reconexões: {ctx.reconnect_num})", "INFO")

    def _run_stream_loop(self, ctx: StreamContext):
        while ctx.active:
            ctx.output_buf.clear()
            ctx.last_useful_payload = time.time()
            ctx.connection_started_at = time.time()

            doh_host = None
            release_session = None
            leftover = bytearray()

            try:
                parsed = urllib.parse.urlparse(ctx.resolved_url)
                fetch_url, doh_host = rewrite_url_with_doh(ctx.resolved_url)

                headers = build_stream_headers(ctx.ua, referer=ctx.original_url, host=parsed.hostname)

                if not doh_host:
                    fetch_url = ctx.resolved_url
                req = urllib.request.Request(fetch_url, headers=headers)

                target_host = parsed.hostname
                session, release_session = _global_pool.acquire_session(target_host)
                try:
                    response = session.open(req, timeout=12)
                except Exception:
                    if doh_host:
                        invalidate_doh_cache(doh_host)
                    raise

                try:
                    response.fp.raw._sock.settimeout(READ_CHUNK_DEADLINE)
                except Exception:
                    pass

                ctx.current_response = response

                if not ctx.active:
                    try:
                        response.close()
                    except Exception:
                        pass
                    ctx.current_response = None
                    break

                if ctx.reconnect_num == 0:
                    _log(f"[NexusCore-TSProxy] Conectado -> {ctx.ua}", "INFO")
                else:
                    _log(f"[NexusCore-TSProxy] Reconectado #{ctx.reconnect_num}", "INFO")
                    ctx.reconnect_num = max(0, ctx.reconnect_num - 2)

                need_suture = ctx.has_played_data and not ctx.is_live

                if need_suture:
                    ctx.is_suture_searching = True
                    _log("[NexusCore-TSProxy] Buscando sutura (sliding window front-to-back)...", "INFO")
                elif ctx.has_played_data and ctx.is_live:
                    ctx.ts_buf.arm_discontinuity()
                    ctx.last_discontinuity_at = time.time()
                    _log("[NexusCore-TSProxy] Live stream — retomando do live edge com descontinuidade", "INFO")

                resync_buf = bytearray()
                first_read_of_connection = True

                suture_search_started_at = time.time() if need_suture else None
                last_suture_heartbeat_at = suture_search_started_at

                while ctx.active:
                    if need_suture and suture_search_started_at is not None:
                        now = time.time()
                        elapsed_searching = now - suture_search_started_at
                        if elapsed_searching >= SUTURE_SEARCH_DEADLINE:
                            _log(f"[NexusCore-TSProxy] Busca de sutura excedeu "
                                 f"{SUTURE_SEARCH_DEADLINE:.0f}s sem dados suficientes — "
                                 f"processando o que temos.", "WARNING")

                            need_suture = False
                            suture_search_started_at = None

                            remaining_raw = bytes(resync_buf)
                            resync_buf.clear()

                            ctx.ts_buf.arm_discontinuity()
                            ctx.last_discontinuity_at = time.time()
                            ctx.add_raw_tail(remaining_raw)

                            payload = ctx.ts_buf.feed(remaining_raw)
                            if payload:
                                payload = _strict_ts_align(payload)
                                if not ctx.output_buf.put(payload):
                                    break
                            continue

                        if now - last_suture_heartbeat_at >= SUTURE_SEARCH_HEARTBEAT_INTERVAL:
                            _log(f"[NexusCore-TSProxy] ...ainda buscando sutura "
                                 f"({elapsed_searching:.1f}s decorridos, "
                                 f"janela: {len(resync_buf)} bytes, "
                                 f"tail: {len(ctx.stream_tail)} bytes)",
                                 "DEBUG")
                            last_suture_heartbeat_at = now

                    try:
                        raw, leftover = self._read_aligned_chunk(response, leftover)
                    except socket.timeout:
                        _log(f"[NexusCore-TSProxy] Timeout de leitura upstream "
                             f"({READ_SOCKET_TIMEOUT:.0f}s sem dados) #{ctx.reconnect_num}", "WARNING")
                        resync_buf.clear()
                        break
                    except Exception:
                        resync_buf.clear()
                        break

                    if not raw:
                        if first_read_of_connection:
                            ctx.consecutive_immediate_eof += 1
                            _log(f"[NexusCore-TSProxy] EOF imediato ao conectar "
                                 f"(CDN aceitou e não enviou dados) — "
                                 f"{ctx.consecutive_immediate_eof} em sequência", "WARNING")
                        else:
                            if ctx.connection_started_at:
                                duration = time.time() - ctx.connection_started_at
                                if duration < RAPID_DROP_THRESHOLD:
                                    ctx.rapid_drop_count += 1
                                    _log(f"[NexusCore-TSProxy] Queda rápida do stream "
                                         f"({duration:.1f}s) — "
                                         f"{ctx.rapid_drop_count} quedas rápidas em sequência",
                                         "WARNING")
                                else:
                                    ctx.rapid_drop_count = 0
                        break

                    first_read_of_connection = False
                    ctx.consecutive_immediate_eof = 0
                    ctx.total_bytes_streamed += len(raw)

                    if need_suture:
                        resync_buf.extend(raw)

                        # Janela deslizante: mantém limite máximo descartando bytes antigos alinhados
                        if len(resync_buf) > SUTURE_WINDOW_LIMIT:
                            excess = len(resync_buf) - SUTURE_WINDOW_LIMIT
                            excess = (excess // TS_PACKET_SIZE) * TS_PACKET_SIZE
                            if excess > 0:
                                del resync_buf[:excess]

                        if len(resync_buf) >= TS_PACKET_SIZE * 2:
                            tail = ctx.get_tail()
                            if len(tail) >= TS_PACKET_SIZE * 2:
                                # FIX: Sliding Window Front-to-Back
                                # Procura o INÍCIO do novo fluxo no FINAL do tail antigo
                                needle1 = bytes(resync_buf[:TS_PACKET_SIZE])
                                suture_idx = tail.find(needle1)
                                
                                if suture_idx != -1:
                                    needle2 = bytes(resync_buf[TS_PACKET_SIZE:TS_PACKET_SIZE*2])
                                    if tail.find(needle2) == suture_idx + TS_PACKET_SIZE:
                                        # Confirmado! Sutura encontrada.
                                        overlap_size = len(tail) - suture_idx
                                        _log(f"[NexusCore-TSProxy] Sutura encontrada! Pulando {overlap_size} bytes já reproduzidos.", "INFO")
                                        
                                        need_suture = False
                                        suture_search_started_at = None
                                        
                                        remaining_raw = bytes(resync_buf[overlap_size:])
                                        resync_buf.clear()
                                        
                                        ctx.add_raw_tail(remaining_raw)
                                        payload = ctx.ts_buf.feed(remaining_raw)
                                        if payload:
                                            payload = _strict_ts_align(payload)
                                            if not ctx.output_buf.put(payload):
                                                break
                                        continue
                                
                                # Se não encontrou, assume que o live edge avançou (sem sobreposição)
                                _log("[NexusCore-TSProxy] Sem sobreposição no início do stream. Retomando diretamente.", "INFO")
                                need_suture = False
                                suture_search_started_at = None
                                
                                remaining_raw = bytes(resync_buf)
                                resync_buf.clear()
                                
                                ctx.add_raw_tail(remaining_raw)
                                payload = ctx.ts_buf.feed(remaining_raw)
                                if payload:
                                    payload = _strict_ts_align(payload)
                                    if not ctx.output_buf.put(payload):
                                        break
                                continue
                            else:
                                _log("[NexusCore-TSProxy] Tail muito pequeno para sutura. Retomando do live edge.", "WARNING")
                                need_suture = False
                                suture_search_started_at = None
                                
                                remaining_raw = bytes(resync_buf)
                                resync_buf.clear()
                                
                                ctx.ts_buf.arm_discontinuity()
                                ctx.last_discontinuity_at = time.time()
                                ctx.add_raw_tail(remaining_raw)
                                
                                payload = ctx.ts_buf.feed(remaining_raw)
                                if payload:
                                    payload = _strict_ts_align(payload)
                                    if not ctx.output_buf.put(payload):
                                        break
                                continue
                    else:
                        ctx.add_raw_tail(raw)

                        payload = ctx.ts_buf.feed(raw)
                        if payload:
                            payload = _strict_ts_align(payload)
                            ctx.update_activity()
                            if not ctx.output_buf.put(payload):
                                break
                            ctx.has_played_data = True
                        else:
                            ctx.update_activity()

                try:
                    response.close()
                except Exception:
                    pass

            except urllib.error.HTTPError as e:
                _log(f"[NexusCore-TSProxy] HTTP {e.code} #{ctx.reconnect_num}", "WARNING")
                if e.code in (401, 403, 406, 410, 451):
                    _log("[NexusCore-TSProxy] Token expirado/bloqueado. Forçando renovação...", "WARNING")
                    _invalidate_cached_resolved_url(ctx.original_url)
                    ctx.resolved_url = ctx.original_url

                    if doh_host:
                        invalidate_doh_cache(doh_host)
                    if 'target_host' in locals() and target_host:
                        _global_pool.invalidate_host(target_host)
                elif e.code == 404:
                    _log("[NexusCore-TSProxy] 404 — stream pode estar temporariamente indisponível", "WARNING")
                    _invalidate_cached_resolved_url(ctx.original_url)
                    if doh_host:
                        invalidate_doh_cache(doh_host)

            except Exception as e:
                err_name = type(e).__name__
                err_msg = str(e)[:80]
                _log(f"[NexusCore-TSProxy] {err_name} #{ctx.reconnect_num}: {err_msg}", "WARNING")
                if doh_host:
                    invalidate_doh_cache(doh_host)
            finally:
                ctx.current_response = None
                if release_session:
                    release_session()

            if not ctx.active:
                break

            ctx.reconnect_num += 1
            ctx.ua = _pick_ua()
            backoff = self._calculate_backoff(ctx.reconnect_num)

            MIN_DISCONTINUITY_SPACING = 2.5
            if ctx.last_discontinuity_at is not None:
                elapsed_since_discontinuity = time.time() - ctx.last_discontinuity_at
                if elapsed_since_discontinuity < MIN_DISCONTINUITY_SPACING:
                    extra_wait = MIN_DISCONTINUITY_SPACING - elapsed_since_discontinuity
                    if extra_wait > backoff:
                        _log(f"[NexusCore-TSProxy] Descontinuidade recente "
                             f"({elapsed_since_discontinuity:.2f}s atrás) — "
                             f"estendendo espera para {extra_wait:.2f}s "
                             f"(piso de estabilidade do decoder).", "INFO")
                        backoff = extra_wait

            if ctx.consecutive_immediate_eof >= CONSECUTIVE_EOF_BACKOFF_START:
                eof_extra = min(
                    CONSECUTIVE_EOF_BACKOFF_MAX,
                    (ctx.consecutive_immediate_eof - CONSECUTIVE_EOF_BACKOFF_START + 1)
                    * CONSECUTIVE_EOF_BACKOFF_STEP,
                )
                if eof_extra > backoff:
                    _log(f"[NexusCore-TSProxy] {ctx.consecutive_immediate_eof} EOFs "
                         f"imediatos em sequência (CDN cortando ativamente) — "
                         f"estendendo espera para {eof_extra:.2f}s.", "WARNING")
                    backoff = eof_extra

            if ctx.rapid_drop_count >= 2:
                rapid_extra = min(
                    RAPID_DROP_BACKOFF_MAX,
                    RAPID_DROP_BACKOFF_BASE +
                    (ctx.rapid_drop_count - 1) * RAPID_DROP_BACKOFF_STEP
                )
                if rapid_extra > backoff:
                    _log(f"[NexusCore-TSProxy] {ctx.rapid_drop_count} quedas rápidas "
                         f"em sequência (CDN cortando após poucos segundos) — "
                         f"estendendo espera para {rapid_extra:.2f}s.", "WARNING")
                    backoff = rapid_extra

            _log(f"[NexusCore-TSProxy] Reconectando em {backoff:.2f}s (tentativa #{ctx.reconnect_num})", "INFO")

            time.sleep(backoff)

            if not ctx.active:
                break

            try:
                new_url = self._resolve_url(ctx, ctx.original_url)
                new_host = urllib.parse.urlparse(new_url).hostname

                switched = bool(
                    ctx.last_resolved_host and new_host
                    and new_host != ctx.last_resolved_host
                )
                ctx.last_reconnect_was_cdn_switch = switched

                if switched:
                    ctx.cdn_switch_count += 1
                    _log(
                        f"[NexusCore-TSProxy] Troca de CDN detectada: "
                        f"{ctx.last_resolved_host} -> {new_host} "
                        f"(#{ctx.cdn_switch_count} nesta sessão)", "WARNING"
                    )
                    _invalidate_cached_resolved_url(ctx.original_url)
                    _set_cached_resolved_url(ctx.original_url, new_url, new_host)

                if new_url != ctx.resolved_url:
                    ctx.resolved_url = new_url
                    ctx.last_resolved_host = new_host
                    _log(f"[NexusCore-TSProxy] Token atualizado #{ctx.reconnect_num} (Novo UA: {ctx.ua})", "INFO")
            except Exception:
                pass

            if ctx.reconnect_num % 5 == 0:
                cleanup_stale_contexts()

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

_server_instance = None
_server_thread = None
_lock = threading.Lock()

def _ensure_server_running():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance is None:
            port = 0
            _server_instance = ThreadingHTTPServer(('127.0.0.1', port), TSProxyHandler)
            _server_thread = threading.Thread(target=_server_instance.serve_forever, daemon=True)
            _server_thread.start()
            actual_port = _server_instance.server_address[1]
            _log(f"[NexusCore-TSProxy] Servidor OTT Plus iniciado na porta {actual_port}", "INFO")
            return actual_port
        return _server_instance.server_address[1]

def get_proxy_url(stream_url: str, port: int = None) -> str:
    if port is None:
        port = _ensure_server_running()
    encoded_url = urllib.parse.quote(stream_url, safe='')
    return f"http://127.0.0.1:{port}/?url={encoded_url}"

def shutdown_proxy():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance:
            _server_instance.shutdown()
            _server_instance.server_close()
            _server_instance = None
            _server_thread = None
    _global_pool.close_all()
    with _stream_contexts_lock:
        _stream_contexts.clear()
    _log("[NexusCore-TSProxy] Proxy encerrado", "INFO")