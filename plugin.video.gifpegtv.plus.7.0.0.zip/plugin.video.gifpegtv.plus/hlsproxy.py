# -*- coding: utf-8 -*-
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver

# Importa a biblioteca requests original e seus componentes necessários
import requests
from requests.adapters import HTTPAdapter

# Importa o wrapper do requests do netunblock com um apelido para evitar conflito
from doh_client import requests as doh_requests

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------
# Aumentado o número total de retentativas automáticas pela biblioteca requests
MAX_RETRIES = 15
# Fator de espera entre retentativas (ex: 4s, 8s, 16s, 32s...). Aumentado para waits mais longos.
RETRY_BACKOFF_FACTOR = 4.0
CONNECTION_TIMEOUT = 10
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 1024 * 64  # 1 MB
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"
# Número máximo de erros 404 (segmento não encontrado) antes de desistir
MAX_CONSECUTIVE_SEGMENT_ERRORS = 5
# Aumentamos o número de retentativas para o manifesto
MAX_MANIFEST_RETRIES = 15
# ----------------------------------

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILS ----------------
def setup_logging():
    """Configura o sistema de logging."""
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')


def get_forward_headers(client_headers):
    """Encaminha alguns headers importantes e adiciona um User-Agent rotativo."""
    chrome_version = random.randint(90, 110)
    user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_version}.0.0.0 Safari/537.36"
    
    headers = {
        'User-Agent': user_agent,
        'Connection': 'keep-alive',
    }
    if 'Authorization' in client_headers:
        headers['Authorization'] = client_headers['Authorization']
    if 'Cookie' in client_headers:
        headers['Cookie'] = client_headers['Cookie']
    
    return headers


# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    """
    Manipulador de requisições para o proxy HLS.
    Utiliza uma sessão 'requests' única e persistente sem retentativas automáticas.
    """
    session = doh_requests.session
    adapter = HTTPAdapter(max_retries=0)  # Desabilita retentativas automáticas para lidar manualmente
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    
    # Dicionário para rastrear erros 404 consecutivos por sessão de cliente
    error_counter = {}

    def log_message(self, format, *args):
        """Reduz o ruído no log, usando o logger configurado."""
        logging.info(f"{self.client_address[0]} - \"{format % args}\"")

    def do_HEAD(self):
        """Suporte para requisições HEAD, chamando do_GET."""
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        """Lida com as requisições GET para manifestos e segmentos."""
        try:
            if '?url=' not in self.path:
                self.send_error(404, "Not Found")
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            # Usa o IP do cliente como fallback para o ID da sessão
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400, "Bad Request: 'url' parameter missing")
                return

            headers = get_forward_headers(self.headers)

            parsed_url = urllib.parse.urlparse(url)
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, session_id, head_only)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou a conexão de forma abrupta.")
        except Exception as e:
            logging.error(f"Erro inesperado no handler GET: {e}", exc_info=True)
            if not self.wfile.closed:
                try:
                    self.send_error(500, "Internal Proxy Error")
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    logging.warning("Cliente fechou a conexão durante o envio de erro 500.")

    def _handle_manifest(self, url, headers, session_id, head_only):
        """Serve o manifest com URLs reescritas para apontar para o proxy."""
        for i in range(MAX_MANIFEST_RETRIES):
            try:
                r = self.session.get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                r.raise_for_status()  # Lança uma exceção se o status for de erro
                
                # Se a requisição for bem-sucedida, saímos do loop
                break

            except requests.exceptions.HTTPError as e:
                # Tratamento específico para o erro 429
                if e.response and e.response.status_code == 429:
                    retry_after = e.response.headers.get('Retry-After')
                    if retry_after:
                        try:
                            wait_time = int(retry_after)
                        except ValueError:
                            wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                    else:
                        wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                    logging.warning(f"Recebido 429 para o manifesto. Tentando novamente em {wait_time:.2f}s... (Tentativa {i+1}/{MAX_MANIFEST_RETRIES})")
                    time.sleep(wait_time)
                    continue  # Continua para a próxima tentativa no loop
                
                # Para outros erros HTTP, tentamos novamente com backoff
                wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                logging.warning(f"Erro HTTP no manifesto: {e}. Tentando novamente em {wait_time:.2f}s...")
                time.sleep(wait_time)
                continue

            except requests.exceptions.RequestException as e:
                # Lida com outros erros da biblioteca requests (ex: Timeout, ConnectionError)
                wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                logging.warning(f"Erro na requisição do manifesto: {e}. Tentando novamente em {wait_time:.2f}s...")
                time.sleep(wait_time)
                continue

            except Exception as e:
                logging.error(f"Erro ao manipular manifesto {url}: {e}", exc_info=True)
                self.send_error(502, "Bad Gateway: Error processing manifest")
                return
        else: # Este bloco 'else' é executado se o loop terminar sem um 'break'
            logging.error("Limite de retentativas do manifesto atingido. Abortando.")
            self.send_error(503, "Service Unavailable: Retries exhausted for manifest")
            return

        # Se a requisição foi bem-sucedida (o 'break' foi executado), continuamos o processamento
        manifest_content = r.text
        base_url = r.url

        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.end_headers()

        if head_only:
            return

        new_manifest_lines = []
        for line in manifest_content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                new_manifest_lines.append(line)
            else:
                full_segment_url = urllib.parse.urljoin(base_url, stripped)
                proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&session_id={session_id}"
                new_manifest_lines.append(proxy_segment_url)
        
        self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
        self.wfile.flush()

    def _handle_segment(self, url, session_id, headers, head_only):
        """Serve o segmento de mídia individual."""
        r = None
        for i in range(MAX_RETRIES):
            try:
                r = self.session.get(url, headers=headers, stream=True, timeout=STREAM_TIMEOUT, verify=False)
                if r.status_code == 404:
                    if r:
                        r.close()
                    consecutive_errors = self.error_counter.get(session_id, 0) + 1
                    self.error_counter[session_id] = consecutive_errors
                    logging.warning(f"Segmento não encontrado (404): {url} | Erros consecutivos: {consecutive_errors}")
                    
                    if consecutive_errors >= MAX_CONSECUTIVE_SEGMENT_ERRORS:
                        logging.error("Limite de erros 404 consecutivos atingido. Abortando.")
                        self.send_error(404, "Not Found")
                    else:
                        self.send_error(503, "Segment Temporarily Unavailable")
                    return

                r.raise_for_status()
                
                self.error_counter[session_id] = 0

                self.send_response(r.status_code)
                for header, value in r.headers.items():
                    if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                        self.send_header(header, value)
                self.end_headers()

                if head_only:
                    if r:
                        r.close()
                    return

                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    self.wfile.write(chunk)
                    self.wfile.flush()
                
                if r:
                    r.close()
                return  # Sucesso

            except requests.exceptions.HTTPError as e:
                if r:
                    r.close()
                if e.response and e.response.status_code == 429:
                    retry_after = e.response.headers.get('Retry-After')
                    if retry_after:
                        try:
                            wait_time = int(retry_after)
                        except ValueError:
                            wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                    else:
                        wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                    logging.warning(f"Recebido 429 para o segmento. Tentando novamente em {wait_time:.2f}s... (Tentativa {i+1}/{MAX_RETRIES})")
                    time.sleep(wait_time)
                    continue
                else:
                    wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                    logging.warning(f"Erro HTTP no segmento: {e}. Tentando novamente em {wait_time:.2f}s...")
                    time.sleep(wait_time)
                    continue

            except requests.exceptions.RequestException as e:
                if r:
                    r.close()
                wait_time = RETRY_BACKOFF_FACTOR * (2 ** i) + random.uniform(0, 1)
                logging.warning(f"Erro na requisição do segmento: {e}. Tentando novamente em {wait_time:.2f}s...")
                time.sleep(wait_time)
                continue

            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                if r:
                    r.close()
                logging.warning(f"Cliente fechou a conexão ao baixar o segmento: {url}")
                return

            except Exception as e:
                if r:
                    r.close()
                logging.error(f"Erro inesperado no segmento {url}: {e}", exc_info=True)
                if not self.wfile.closed:
                    self.send_error(500, "Internal Proxy Error")
                return
        
        # Se o loop terminar sem sucesso
        logging.error("Limite de retentativas do segmento atingido. Abortando.")
        self.send_error(502, "Bad Gateway: Retries exhausted for segment")

    def do_OPTIONS(self):
        """Responde a requisições OPTIONS para compatibilidade com CORS."""
        self.send_response(200, "OK")
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()


# ---------------- MANAGER ----------------
class HLSProxyManager:
    """Gerencia o ciclo de vida do servidor proxy."""
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        """Inicia o servidor proxy em uma porta livre e aleatória."""
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyRequestHandler, bind_and_activate=False)
                self.server.allow_reuse_address = True
                self.server.server_bind()
                self.server.server_activate()
                
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy HLS iniciado em http://{PROXY_HOST}:{self.active_port}")
                return True
            except OSError as e:
                logging.warning(f"Porta {port} em uso, tentando outra. Erro: {e}")
                continue
        logging.error("Não foi possível iniciar o proxy HLS. Todas as portas tentadas estão em uso.")
        return False

    def stop(self):
        """Para o servidor proxy."""
        if self.server:
            logging.info("Parando o servidor proxy HLS...")
            self.server.shutdown()
            self.server.server_close()
            self.thread.join()
            logging.info("Servidor proxy HLS parado.")


# ---------------- ADDON ----------------
class HLSAddon:
    """Classe principal do addon que interage com o Kodi."""
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        """Inicia o proxy e passa a URL modificada para o Kodi."""
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro no Proxy HLS", "Não foi possível iniciar o servidor local.", xbmcgui.NOTIFICATION_ERROR)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        
        li = xbmcgui.ListItem(path=proxy_url)
        if title:
            li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        
        if stype == "live":
            li.setMimeType("application/vnd.apple.mpegurl")
        
        xbmcplugin.setResolvedUrl(self.handle, True, li)


def main():
    """Ponto de entrada do script quando chamado pelo Kodi."""
    setup_logging()
    try:
        handle = int(sys.argv[1])
        addon = HLSAddon(handle)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', ['live'])[0] # Default para 'live'
            title = args.get('title', [None])[0]

            if stream_url:
                addon.play_stream(stream_url, stream_type, title)
            else:
                logging.error("Ação 'play_stream' chamada sem 'stream_url'.")
                xbmcplugin.endOfDirectory(handle, succeeded=False)
        else:
            # Finaliza o script se nenhuma ação for correspondida
            xbmcplugin.endOfDirectory(handle)
            
    except Exception as e:
        logging.error(f"Erro fatal na execução principal: {e}", exc_info=True)
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        if handle != -1:
            xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == '__main__':
    main()