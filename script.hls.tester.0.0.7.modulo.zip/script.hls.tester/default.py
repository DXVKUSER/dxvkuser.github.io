import sys
import xbmc
import xbmcgui
import xbmcplugin
import urllib.parse
import xbmcaddon
import requests
import time
from urllib.parse import parse_qs
from requests.exceptions import RequestException
from collections import deque
from http.server import BaseHTTPRequestHandler, HTTPServer
import threading

ADDON = xbmcaddon.Addon('script.hls.tester')

# Configurações de buffer
BUFFER_CHUNK_SIZE = 5   # quantidade de segmentos a manter na memória
REQUEST_TIMEOUT = 5     # timeout por requisição em segundos
MAX_RETRIES = 1         # tentativas antes de falhar

# Buffer rotativo em memória
chunk_buffer = {}
chunk_order = deque(maxlen=BUFFER_CHUNK_SIZE)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[script.hls.tester] {msg}", level)


def check_proxy_status(port):
    try:
        response = requests.get(f"http://127.0.0.1:{port}/status", timeout=2)
        return response.status_code == 200
    except RequestException:
        return False


def start_proxy_service():
    log("Tentando iniciar o serviço proxy")
    try:
        thread = threading.Thread(target=run_proxy_server, daemon=True)
        thread.start()
        log("Serviço proxy iniciado em thread")
        return True
    except Exception as e:
        log(f"Erro ao iniciar serviço proxy: {str(e)}", xbmc.LOGERROR)
        return False


def fetch_with_retries(url):
    """Baixa chunk com retry e timeout"""
    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.get(url, timeout=REQUEST_TIMEOUT)
            if resp.status_code == 200:
                return resp.content
        except Exception as e:
            log(f"Tentativa {attempt+1} falhou para {url}: {str(e)}", xbmc.LOGWARNING)
        time.sleep(0.5 * (attempt+1))
    return None


class ProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/status":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")
            return

        if parsed.path == "/play":
            target_url = query.get("url", [None])[0]
            token = query.get("token", [None])[0]
            if not target_url:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Missing url")
                return

            # Gera playlist m3u8 que aponta para /segment
            playlist = "#EXTM3U\n"
            playlist += "#EXT-X-VERSION:3\n"
            playlist += "#EXT-X-TARGETDURATION:6\n"
            playlist += "#EXT-X-MEDIA-SEQUENCE:0\n"

            for i in range(BUFFER_CHUNK_SIZE):
                playlist += f"#EXTINF:6.0,\n/segment?url={urllib.parse.quote_plus(target_url)}&seq={i}\n"

            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.apple.mpegurl")
            self.end_headers()
            self.wfile.write(playlist.encode("utf-8"))
            return

        if parsed.path == "/segment":
            target_url = query.get("url", [None])[0]
            seq = query.get("seq", [None])[0]

            if not target_url or seq is None:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Missing parameters")
                return

            key = f"{target_url}_{seq}"

            if key in chunk_buffer:
                data = chunk_buffer[key]
                log(f"Servindo chunk {seq} do buffer")
            else:
                data = fetch_with_retries(target_url)
                if not data:
                    self.send_response(502)
                    self.end_headers()
                    self.wfile.write(b"Failed to fetch chunk")
                    return
                chunk_buffer[key] = data
                chunk_order.append(key)
                log(f"Chunk {seq} baixado e armazenado no buffer")

                # se buffer cheio, remove mais antigo
                if len(chunk_order) > BUFFER_CHUNK_SIZE:
                    oldest = chunk_order.popleft()
                    if oldest in chunk_buffer:
                        del chunk_buffer[oldest]
                        log(f"Chunk {oldest} removido do buffer")

            self.send_response(200)
            self.send_header("Content-Type", "video/MP2T")
            self.end_headers()
            self.wfile.write(data)
            return

        self.send_response(404)
        self.end_headers()


def run_proxy_server():
    port = int(ADDON.getSetting('proxy_port'))
    server = HTTPServer(("127.0.0.1", port), ProxyHandler)
    log(f"Servidor proxy rodando na porta {port}")
    server.serve_forever()


def play_stream(url, token=None):
    log(f"Reproduzindo stream: {url}")
    proxy_port = ADDON.getSetting('proxy_port')
    log(f"Usando porta do proxy: {proxy_port}")

    if not check_proxy_status(proxy_port):
        log("Proxy não está rodando, tentando iniciar...")
        if not start_proxy_service():
            xbmcgui.Dialog().notification(
                "HLS Tester",
                "Não foi possível iniciar o serviço proxy",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        # Aguarda inicialização
        for _ in range(10):
            time.sleep(0.5)
            if check_proxy_status(proxy_port):
                break

    proxy_url_params = {'url': urllib.parse.quote_plus(url)}
    if token:
        proxy_url_params['token'] = urllib.parse.quote_plus(token)

    proxy_url = f"http://127.0.0.1:{proxy_port}/play?{urllib.parse.urlencode(proxy_url_params)}"
    log(f"URL do proxy: {proxy_url}")

    item = xbmcgui.ListItem(path=proxy_url)
    item.setMimeType('application/vnd.apple.mpegurl')

    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def router(params):
    action = params.get('action', [''])[0]

    if action == 'play':
        url = params.get('url', [''])[0]
        token = params.get('token', [None])[0]
        if url:
            try:
                play_stream(urllib.parse.unquote_plus(url), token)
            except Exception as e:
                log(f"Erro ao reproduzir stream: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().notification(
                    "HLS Tester",
                    "Falha ao reproduzir o stream",
                    xbmcgui.NOTIFICATION_ERROR
                )
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    elif action == 'start_service':
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)
    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)


if __name__ == '__main__':
    router(parse_qs(sys.argv[2][1:]))