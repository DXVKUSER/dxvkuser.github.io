import sys
import xbmc
import xbmcgui
import xbmcplugin
import urllib.parse
import xbmcaddon
import requests
import time
from urllib.parse import parse_qs
from requests.exceptions import RequestException
import threading

ADDON = xbmcaddon.Addon('script.hls.tester')

# Configurações de buffer (estes agora são gerenciados principalmente pelo service.py)
# No entanto, estas variáveis são mantidas para compatibilidade com a função fetch_with_retries,
# que pode ser usada em cenários alternativos ou para testes diretos.
REQUEST_TIMEOUT = int(ADDON.getSetting('REQUEST_TIMEOUT')) if ADDON.getSetting('REQUEST_TIMEOUT') else 5
MAX_RETRIES = int(ADDON.getSetting('MAX_RETRIES')) if ADDON.getSetting('MAX_RETRIES') else 1


def log(msg, level=xbmc.LOGINFO):
    """Função de log para mensagens no Kodi."""
    xbmc.log(f"[script.hls.tester] {msg}", level)


def check_proxy_status(port):
    """Verifica se o serviço proxy está rodando."""
    try:
        response = requests.get(f"http://127.0.0.1:{port}/status", timeout=2)
        return response.status_code == 200
    except RequestException as e:
        log(f"Falha ao verificar status do proxy na porta {port}: {e}", xbmc.LOGDEBUG)
        return False


def start_proxy_service():
    """Tenta iniciar o serviço proxy chamando o serviço principal do Kodi."""
    log("Tentando iniciar o serviço proxy Kodi (service.py)")
    try:
        # Nota: Em um ambiente Kodi real, o service.py é iniciado automaticamente
        # ou por uma chamada específica do Kodi. Esta função é um placeholder
        # para simular a inicialização ou para depuração.
        # No entanto, a lógica principal de proxy é no service.py.
        # Não é necessário um thread separado aqui, pois o service.py deve rodar como um serviço.
        return True # Assumimos que o service.py será iniciado pelo Kodi
    except Exception as e:
        log(f"Erro ao 'iniciar' serviço proxy: {str(e)}", xbmc.LOGERROR)
        return False


def play_stream(url, token=None):
    """Prepara e resolve a URL do stream para ser reproduzida pelo Kodi via proxy."""
    log(f"Reproduzindo stream: {url}")
    
    # Obtém a porta do proxy das configurações do addon.
    # Garante um valor padrão seguro caso a configuração esteja vazia.
    proxy_port_setting = ADDON.getSetting('proxy_port')
    if not proxy_port_setting:
        log("Configuração 'proxy_port' vazia, usando o padrão 5000.", xbmc.LOGWARNING)
        proxy_port = 5000
    else:
        try:
            proxy_port = int(proxy_port_setting)
        except ValueError:
            log(f"Valor inválido para 'proxy_port': '{proxy_port_setting}', usando o padrão 5000.", xbmc.LOGERROR)
            proxy_port = 5000

    log(f"Usando porta do proxy: {proxy_port}")

    # Verifica se o serviço proxy está rodando. Se não, tenta 'iniciar'.
    # A lógica real de inicialização do serviço reside no service.py
    # e é gerenciada pelo sistema de serviços do Kodi.
    if not check_proxy_status(proxy_port):
        log("Proxy não está respondendo, pode estar inicializando ou com problemas.")
        # Em vez de iniciar um novo thread aqui, assumimos que o serviço já está
        # sendo executado ou será iniciado pelo Kodi.
        # Adicionamos um pequeno atraso para dar tempo ao serviço para inicializar,
        # o que é uma prática comum para serviços Kodi.
        for _ in range(5): # Tenta verificar por 5 segundos
            time.sleep(1)
            if check_proxy_status(proxy_port):
                log("Proxy respondeu após atraso.", xbmc.LOGINFO)
                break
        else:
            log("Proxy ainda não responde após tentar iniciar/aguardar.", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(
                "HLS Tester",
                "Serviço proxy não está ativo ou não responde.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return


    # Constrói a URL do proxy para o Kodi.
    proxy_url_params = {'url': urllib.parse.quote_plus(url)}
    if token:
        proxy_url_params['token'] = urllib.parse.quote_plus(token)

    proxy_url = f"http://127.0.0.1:{proxy_port}/play?{urllib.parse.urlencode(proxy_url_params)}"
    log(f"URL do proxy para reprodução: {proxy_url}")

    item = xbmcgui.ListItem(path=proxy_url)
    item.setMimeType('application/vnd.apple.mpegurl') # Define o mimetype para HLS

    # Resolve a URL para o Kodi reproduzir.
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def router(params):
    """Roteador para lidar com ações do plugin."""
    log(f"Parâmetros do roteador: {params}")
    action = params.get('action', [''])[0]

    if action == 'play':
        url = params.get('url', [''])[0]
        token = params.get('token', [None])[0]
        if url:
            try:
                play_stream(urllib.parse.unquote_plus(url), token)
            except Exception as e:
                log(f"Erro ao reproduzir stream: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().notification(
                    "HLS Tester",
                    "Falha ao reproduzir o stream",
                    xbmcgui.NOTIFICATION_ERROR
                )
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        else:
            log("URL para reprodução não fornecida.", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                "HLS Tester",
                "URL de stream ausente",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    elif action == 'start_service':
        # Esta ação pode ser usada para sinalizar que o serviço deve ser iniciado
        # ou para garantir que o serviço principal do Kodi esteja ciente do addon.
        log("Ação 'start_service' recebida. Finalizando diretório com sucesso.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)
    else:
        log(f"Ação desconhecida: '{action}'. Finalizando diretório com falha.", xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)


if __name__ == '__main__':
    # Quando o script é executado pelo Kodi, sys.argv[2] contém os parâmetros da query.
    # parse_qs retorna um dicionário onde os valores são listas.
    router(parse_qs(sys.argv[2][1:]))