import os
import xbmc
import xbmcaddon
import threading
import socket
import urllib.parse
import requests
import time
import re
from collections import OrderedDict
from flask import Flask, request, Response, session, jsonify, abort, g
from werkzeug.serving import make_server
from requests.exceptions import RequestException

ADDON = xbmcaddon.Addon('script.hls.tester')

class LRUCache:
    def __init__(self, capacity, max_size_mb=100):
        self.cache = OrderedDict()
        self.capacity = capacity
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.lock = threading.Lock()
        self.current_size = 0
        self.access_times = {}

    def get(self, key):
        with self.lock:
            if key not in self.cache:
                return None
            self.access_times[key] = time.time()
            return self.cache[key]

    def put(self, key, value):
        with self.lock:
            value_size = len(value)
            if value_size > self.max_size_bytes:
                return
            
            if key in self.cache:
                self.current_size -= len(self.cache[key])
                del self.cache[key]
            
            while self.current_size + value_size > self.max_size_bytes or len(self.cache) >= self.capacity:
                oldest_key = next(iter(self.cache))
                self.current_size -= len(self.cache[oldest_key])
                del self.cache[oldest_key]
                del self.access_times[oldest_key]
            
            self.cache[key] = value
            self.current_size += value_size
            self.access_times[key] = time.time()

    def clear(self):
        with self.lock:
            self.cache.clear()
            self.current_size = 0
            self.access_times.clear()

class HLSService:
    def __init__(self):
        self.log("Iniciando HLS Proxy Service")
        self.port = int(ADDON.getSetting('proxy_port'))
        self.log(f"Porta do proxy: {self.port}")
        self.host = '127.0.0.1'
        self.log(f"Host do proxy: {self.host}")
        self.app = Flask(__name__)
        self.app.secret_key = os.urandom(24)
        self.timeout = int(ADDON.getSetting('timeout'))
        self.log(f"Timeout do proxy: {self.timeout}")
        self.max_retries = int(ADDON.getSetting('max_retries'))
        self.log(f"Máximo de tentativas: {self.max_retries}")
        self.user_agent = "Kodi/20.0 HLS-Proxy/1.0"
        self.server = None
        self.running = False
        self.session_requests = self._create_requests_session()
        
        # Cache LRU para segmentos
        self.segment_cache = LRUCache(capacity=30, max_size_mb=150)
        
        # Controle de chunksize dinâmico
        self.chunk_sizes = [4 * 1024, 8 * 1024, 16 * 1024, 32 * 1024, 64 * 1024, 128 * 1024, 256 * 1024, 512 * 1024]
        self.current_chunk_index = 0
        self.chunk_lock = threading.Lock()
        
        # Estatísticas para ajuste dinâmico
        self.download_stats = {
            'total_downloaded': 0,
            'successful_downloads': 0,
            'failed_downloads': 0,
            'avg_download_time': 0,
            'last_adjustment': time.time()
        }
        
        self.setup_routes()

    def log(self, msg, level=xbmc.LOGINFO):
        xbmc.log(f"[script.hls.tester] {msg}", level)

    def _create_requests_session(self):
        session = requests.Session()
        session.headers.update({
            'User-Agent': self.user_agent,
            'Accept': '*/*',
            'Connection': 'keep-alive'
        })
        return session

    def adjust_chunk_size(self, success=True, download_time=0):
        with self.chunk_lock:
            self.download_stats['total_downloaded'] += 1
            
            if success:
                self.download_stats['successful_downloads'] += 1
                if download_time > 0:
                    if self.download_stats['avg_download_time'] == 0:
                        self.download_stats['avg_download_time'] = download_time
                    else:
                        self.download_stats['avg_download_time'] = (
                            0.8 * self.download_stats['avg_download_time'] + 0.2 * download_time
                        )
            else:
                self.download_stats['failed_downloads'] += 1
            
            # Ajuste a cada 5 downloads ou se houver falhas
            now = time.time()
            if (self.download_stats['total_downloaded'] % 5 == 0 or 
                self.download_stats['failed_downloads'] > 0 or
                now - self.download_stats['last_adjustment'] > 30):
                
                failure_rate = self.download_stats['failed_downloads'] / max(1, self.download_stats['total_downloaded'])
                
                # Se taxa de falha > 20%, reduzir chunk size
                if failure_rate > 0.2 and self.current_chunk_index > 0:
                    self.current_chunk_index -= 1
                    self.log(f"Reduzindo chunk size para {self.chunk_sizes[self.current_chunk_index]} bytes devido a falhas")
                
                # Se tempo médio de download > 2s e chunk size não é mínimo, reduzir
                elif (self.download_stats['avg_download_time'] > 2.0 and 
                      self.current_chunk_index > 0 and 
                      failure_rate < 0.1):
                    self.current_chunk_index -= 1
                    self.log(f"Reduzindo chunk size para {self.chunk_sizes[self.current_chunk_index]} bytes devido a lentidão")
                
                # Se tudo está bem e não estamos no chunk máximo, aumentar
                elif (failure_rate < 0.05 and 
                      self.download_stats['avg_download_time'] < 0.5 and 
                      self.current_chunk_index < len(self.chunk_sizes) - 1):
                    self.current_chunk_index += 1
                    self.log(f"Aumentando chunk size para {self.chunk_sizes[self.current_chunk_index]} bytes")
                
                # Resetar estatísticas após ajuste
                self.download_stats['failed_downloads'] = 0
                self.download_stats['last_adjustment'] = now

    def get_current_chunk_size(self):
        with self.chunk_lock:
            return self.chunk_sizes[self.current_chunk_index]

    def setup_routes(self):
        @self.app.errorhandler(400)
        def bad_request(error):
            self.log(f"Erro 400 Bad Request: {error.description}", xbmc.LOGWARNING)
            return jsonify({'error': error.description}), 400

        @self.app.errorhandler(500)
        def internal_server_error(error):
            self.log(f"Erro 500 Internal Server Error: {error}", xbmc.LOGERROR)
            return jsonify({'error': 'Erro interno do servidor'}), 500

        @self.app.before_request
        def get_auth_token():
            url = request.args.get('url')
            if url:
                original_url = urllib.parse.unquote_plus(url)
                g.token = session.get(original_url)
            else:
                g.token = None

        @self.app.route('/play')
        def play():
            self.log("Requisição recebida em /play")
            url = request.args.get('url')
            token = request.args.get('token')
            if not url:
                abort(400, "URL ausente")
            
            self.log(f"URL: {url}, Token: {'Sim' if token else 'Não'}")

            try:
                original_url = urllib.parse.unquote_plus(url)
                if token:
                    session[original_url] = urllib.parse.unquote_plus(token)
                    self.log(f"Token de autenticação armazenado na sessão para {original_url}")
                
                if '.m3u8' in original_url.lower():
                    self.log("URL é uma playlist M3U8")
                    return self.handle_playlist(original_url)
                self.log("URL não é uma playlist M3U8, tratando como segmento")
                return self.handle_segment(original_url)

            except Exception as e:
                self.log(f"Erro no proxy: {str(e)}", xbmc.LOGERROR)
                abort(500, f"Erro no servidor: {str(e)}")

        @self.app.route('/segment')
        def segment():
            self.log("Requisição recebida em /segment")
            url = request.args.get('url')
            if not url:
                abort(400, "URL ausente")
            try:
                original_url = urllib.parse.unquote_plus(url)
                self.log(f"Processando segmento: {original_url}")
                return self.handle_segment(original_url)
            except Exception as e:
                self.log(f"Erro ao buscar segmento: {str(e)}", xbmc.LOGERROR)
                abort(500, f"Erro ao buscar segmento: {str(e)}")

        @self.app.route('/status')
        def status():
            self.log("Requisição de status recebida")
            return Response("OK", status=200, mimetype='text/plain')

        @self.app.route('/clear_cache')
        def clear_cache():
            self.log("Requisição para limpar cache recebida")
            self.segment_cache.clear()
            return Response("Cache limpo", status=200, mimetype='text/plain')

    def _get_headers_with_auth(self, url):
        headers = self.session_requests.headers.copy()
        if g.token:
            headers['Authorization'] = f'Bearer {g.token}'
            self.log(f"Adicionando cabeçalho de autenticação para {url}")
        return headers

    def handle_playlist(self, url):
        self.log(f"Manipulando playlist: {url}")
        base_url = url.rsplit('/', 1)[0] + '/'
        self.log(f"URL base: {base_url}")
        
        headers = self._get_headers_with_auth(url)

        for attempt in range(self.max_retries):
            try:
                self.log(f"Buscando playlist (tentativa {attempt + 1})")
                start_time = time.time()
                response = self.session_requests.get(url, timeout=self.timeout, headers=headers)
                response.raise_for_status()
                download_time = time.time() - start_time
                self.log(f"Playlist recebida com status: {response.status_code} em {download_time:.2f}s")
                self.adjust_chunk_size(success=True, download_time=download_time)

                lines = []
                for line in response.text.splitlines():
                    if line.startswith('#EXT-X-KEY'):
                        key_match = re.search(r'URI="([^"]+)"', line)
                        if key_match:
                            key_url = key_match.group(1)
                            if not key_url.startswith('http'):
                                absolute_key_url = urllib.parse.urljoin(base_url, key_url)
                                proxy_key_url = f"http://{self.host}:{self.port}/segment?url={urllib.parse.quote_plus(absolute_key_url)}"
                                self.log(f"Substituindo URL da chave: {key_url} -> {proxy_key_url}")
                                line = line.replace(key_url, proxy_key_url)
                        lines.append(line)
                    elif line.startswith('#') or not line.strip():
                        lines.append(line)
                    else:
                        segment_url = urllib.parse.urljoin(base_url, line)
                        proxy_url = f"http://{self.host}:{self.port}/segment?url={urllib.parse.quote_plus(segment_url)}"
                        self.log(f"Substituindo segmento: {line} -> {proxy_url}")
                        lines.append(proxy_url)

                self.log(f"Retornando playlist modificada com {len(lines)} linhas")
                return Response(
                    '\n'.join(lines),
                    mimetype='application/vnd.apple.mpegurl',
                    headers={
                        'Content-Disposition': 'inline',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    }
                )

            except RequestException as e:
                self.log(f"Erro de requisição ao buscar playlist (tentativa {attempt + 1}): {str(e)}", xbmc.LOGWARNING)
                self.adjust_chunk_size(success=False)
                if attempt == self.max_retries - 1:
                    raise
                time.sleep(1)

    def handle_segment(self, url):
        self.log(f"Manipulando segmento: {url}")
        
        # Verificar cache primeiro
        cached_data = self.segment_cache.get(url)
        if cached_data is not None:
            self.log(f"Segmento encontrado no cache: {url} ({len(cached_data)} bytes)")
            return Response(
                cached_data,
                mimetype='video/MP2T',
                headers={
                    'Content-Length': len(cached_data),
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                }
            )
        
        headers = self._get_headers_with_auth(url)
        buffer = bytearray()
        chunk_size = self.get_current_chunk_size()
        total_downloaded = 0
        start_time = time.time()

        for attempt in range(self.max_retries):
            try:
                self.log(f"Buscando segmento (tentativa {attempt + 1}) com chunk_size={chunk_size}")
                response = self.session_requests.get(
                    url,
                    timeout=self.timeout,
                    stream=True,
                    headers=headers
                )
                response.raise_for_status()
                self.log(f"Segmento recebido com status: {response.status_code}")

                def generate():
                    nonlocal total_downloaded, chunk_size
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            buffer.extend(chunk)
                            total_downloaded += len(chunk)
                            
                            # Ajustar dinamicamente o chunk size durante o download
                            if total_downloaded % (2 * 1024 * 1024) == 0:  # A cada 2MB baixados
                                new_chunk_size = self.get_current_chunk_size()
                                if new_chunk_size != chunk_size:
                                    self.log(f"Ajustando chunk_size durante download: {chunk_size} -> {new_chunk_size}")
                                    chunk_size = new_chunk_size
                            
                            yield chunk

                # Armazenar no cache após o download completo
                def store_in_cache():
                    if len(buffer) > 0:
                        self.segment_cache.put(url, bytes(buffer))
                        self.log(f"Segmento armazenado no cache: {url} ({len(buffer)} bytes)")

                # Iniciar thread para armazenar no cache
                cache_thread = threading.Thread(target=store_in_cache)
                cache_thread.daemon = True
                cache_thread.start()

                download_time = time.time() - start_time
                self.adjust_chunk_size(success=True, download_time=download_time)
                
                content_type = response.headers.get('Content-Type', 'video/MP2T')
                self.log(f"Retornando segmento com tipo: {content_type}, tamanho: {total_downloaded} bytes, tempo: {download_time:.2f}s")
                
                return Response(
                    generate(),
                    mimetype=content_type,
                    headers={
                        'Content-Length': response.headers.get('Content-Length'),
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    }
                )

            except RequestException as e:
                self.log(f"Erro de requisição ao buscar segmento (tentativa {attempt + 1}): {str(e)}", xbmc.LOGWARNING)
                self.adjust_chunk_size(success=False)
                if attempt == self.max_retries - 1:
                    raise
                time.sleep(1)

    def error_response(self, message, status_code):
        self.log(f"Retornando erro: {message} (status: {status_code})", xbmc.LOGERROR)
        return jsonify({'error': message}), status_code

    def run(self):
        self.log(f"Servidor proxy iniciado em http://{self.host}:{self.port}")
        self.running = True
        try:
            self.server = make_server(self.host, self.port, self.app)
            self.server.serve_forever()
        except Exception as e:
            self.log(f"Erro ao iniciar servidor: {str(e)}", xbmc.LOGERROR)
            self.running = False

    def stop(self):
        if self.server:
            self.log("Parando servidor proxy")
            self.server.shutdown()
            self.log("Servidor proxy parado")
            self.running = False
        self.segment_cache.clear()

    def is_running(self):
        return self.running

class MainService:
    def __init__(self):
        self.log("Iniciando MainService")
        self.hls_service = HLSService()
        self.monitor = xbmc.Monitor()

    def log(self, msg, level=xbmc.LOGINFO):
        xbmc.log(f"[script.hls.tester] {msg}", level)

    def run(self):
        self.log("Iniciando thread do serviço HLS")
        try:
            thread = threading.Thread(target=self.hls_service.run)
            thread.daemon = True
            thread.start()
            self.log("Thread do serviço HLS iniciada")
            
            while not self.monitor.abortRequested():
                if self.monitor.waitForAbort(5):
                    break
        except Exception as e:
            self.log(f"Erro no serviço principal: {str(e)}", xbmc.LOGERROR)
        finally:
            self.log("Parando serviço HLS")
            self.hls_service.stop()

if __name__ == '__main__':
    MainService().run()