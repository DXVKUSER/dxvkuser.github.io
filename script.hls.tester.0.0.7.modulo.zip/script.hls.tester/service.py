import os
import xbmc
import xbmcaddon
import threading
import socket
import urllib.parse
import requests
import time
import re
from collections import OrderedDict
from flask import Flask, request, Response, session, jsonify, abort, g
from werkzeug.serving import make_server
from requests.exceptions import RequestException

ADDON = xbmcaddon.Addon('script.hls.tester')

class LRUCache:
    """
    Cache LRU (Least Recently Used) com capacidade máxima de itens e tamanho máximo em MB.
    Garante que o cache não exceda nem o número de itens nem o tamanho total em memória.
    """
    def __init__(self, capacity, max_size_mb=100):
        self.cache = OrderedDict()
        self.capacity = capacity
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.lock = threading.Lock() # Para garantir thread-safety
        self.current_size = 0 # Tamanho atual do cache em bytes
        self.access_times = {} # Dicionário para rastrear o tempo de acesso para LRU

    def get(self, key):
        """
        Retorna o valor associado à chave, se existir, e atualiza o tempo de acesso.
        """
        with self.lock:
            if key not in self.cache:
                return None
            # Move o item para o final (mais recentemente usado)
            self.cache.move_to_end(key)
            self.access_times[key] = time.time() # Atualiza o tempo de acesso
            return self.cache[key]

    def put(self, key, value):
        """
        Adiciona um item ao cache. Se a capacidade ou o tamanho máximo for excedido,
        os itens menos recentemente usados são removidos.
        """
        with self.lock:
            value_size = len(value)
            
            # Se o item sozinho é maior que o cache, não o armazena
            if value_size > self.max_size_bytes:
                HLSService.log(f"Item muito grande para cache: {key} ({value_size} bytes)", xbmc.LOGDEBUG)
                return
            
            # Se a chave já existe, remove o antigo para atualizar
            if key in self.cache:
                self.current_size -= len(self.cache[key])
                del self.cache[key]
                del self.access_times[key]
            
            # Remove itens antigos até que haja espaço ou a capacidade seja respeitada
            while self.current_size + value_size > self.max_size_bytes or len(self.cache) >= self.capacity:
                if not self.cache: # Não há nada para remover
                    break
                
                # Remove o item menos recentemente usado (primeiro item do OrderedDict)
                oldest_key = next(iter(self.cache))
                self.current_size -= len(self.cache[oldest_key])
                del self.cache[oldest_key]
                del self.access_times[oldest_key]
                HLSService.log(f"Item removido do cache por LRU: {oldest_key}", xbmc.LOGDEBUG)
            
            # Adiciona o novo item ao cache
            self.cache[key] = value
            self.current_size += value_size
            self.access_times[key] = time.time()
            self.cache.move_to_end(key) # Marca como mais recentemente usado
            HLSService.log(f"Item adicionado/atualizado no cache: {key} ({value_size} bytes)", xbmc.LOGDEBUG)

    def clear(self):
        """Limpa todo o cache."""
        with self.lock:
            self.cache.clear()
            self.current_size = 0
            self.access_times.clear()
            HLSService.log("Cache LRU limpo.", xbmc.LOGINFO)

class HLSService:
    """
    Serviço de proxy HLS que intercepta requisições de stream,
    realiza caching, retries e ajuste dinâmico do tamanho do chunk.
    """
    def __init__(self):
        self.log("Iniciando HLS Proxy Service")
        
        # Obtendo configurações do addon com tratamento de erro e valores padrão
        self.port = self._get_setting_int('proxy_port', 5000)
        self.log(f"Porta do proxy: {self.port}")
        self.host = '127.0.0.1'
        self.log(f"Host do proxy: {self.host}")
        
        self.timeout = self._get_setting_int('REQUEST_TIMEOUT', 5)
        self.log(f"Timeout de requisição: {self.timeout}s")
        self.max_retries = self._get_setting_int('MAX_RETRIES', 1)
        self.log(f"Máximo de tentativas: {self.max_retries}")
        
        self.app = Flask(__name__)
        self.app.secret_key = os.urandom(24) # Chave secreta para sessões Flask
        self.user_agent = "Kodi/20.0 HLS-Proxy/1.0"
        self.server = None
        self.running = False
        self.session_requests = self._create_requests_session()
        
        # Cache LRU para segmentos, configurado com capacidade e tamanho máximo
        self.segment_cache = LRUCache(capacity=30, max_size_mb=150)
        
        # Controle de chunksize dinâmico para downloads de segmentos
        self.chunk_sizes = [4 * 1024, 8 * 1024, 16 * 1024, 32 * 1024, 64 * 1024, 128 * 1024, 256 * 1024, 512 * 1024]
        self.current_chunk_index = 0
        self.chunk_lock = threading.Lock() # Para proteger o acesso ao índice do chunk
        
        # Estatísticas para ajuste dinâmico do chunk size
        self.download_stats = {
            'total_downloaded': 0,
            'successful_downloads': 0,
            'failed_downloads': 0,
            'avg_download_time': 0.0, # Inicializado como float
            'last_adjustment': time.time()
        }
        
        self.setup_routes()

    @staticmethod
    def log(msg, level=xbmc.LOGINFO):
        """Método estático de log para facilitar o uso em toda a classe."""
        xbmc.log(f"[script.hls.tester] {msg}", level)

    def _get_setting_int(self, setting_id, default_value):
        """
        Obtém uma configuração do addon e tenta convertê-la para int.
        Retorna um valor padrão se a configuração estiver vazia ou for inválida.
        """
        setting_value = ADDON.getSetting(setting_id)
        if not setting_value:
            self.log(f"Configuração '{setting_id}' está vazia, usando o padrão {default_value}.", xbmc.LOGWARNING)
            return default_value
        try:
            return int(setting_value)
        except ValueError:
            self.log(f"Valor inválido para configuração '{setting_id}': '{setting_value}', usando o padrão {default_value}.", xbmc.LOGERROR)
            return default_value

    def _create_requests_session(self):
        """Cria e configura uma sessão de requests."""
        session = requests.Session()
        session.headers.update({
            'User-Agent': self.user_agent,
            'Accept': '*/*',
            'Connection': 'keep-alive'
        })
        return session

    def adjust_chunk_size(self, success=True, download_time=0.0):
        """
        Ajusta dinamicamente o tamanho do chunk com base no sucesso/falha do download
        e no tempo médio de download.
        """
        with self.chunk_lock:
            self.download_stats['total_downloaded'] += 1
            
            if success:
                self.download_stats['successful_downloads'] += 1
                if download_time > 0:
                    # Média móvel ponderada para o tempo de download
                    if self.download_stats['avg_download_time'] == 0.0:
                        self.download_stats['avg_download_time'] = download_time
                    else:
                        self.download_stats['avg_download_time'] = (
                            0.8 * self.download_stats['avg_download_time'] + 0.2 * download_time
                        )
            else:
                self.download_stats['failed_downloads'] += 1
            
            now = time.time()
            # Ajuste a cada 5 downloads, se houver falhas, ou a cada 30 segundos
            if (self.download_stats['total_downloaded'] % 5 == 0 or 
                self.download_stats['failed_downloads'] > 0 or
                now - self.download_stats['last_adjustment'] > 30):
                
                failure_rate = self.download_stats['failed_downloads'] / max(1, self.download_stats['total_downloaded'])
                
                # Reduzir chunk size se a taxa de falha for alta
                if failure_rate > 0.2 and self.current_chunk_index > 0:
                    self.current_chunk_index -= 1
                    self.log(f"Reduzindo chunk size para {self.chunk_sizes[self.current_chunk_index]} bytes devido a falhas ({failure_rate:.2f} taxa)")
                
                # Reduzir chunk size se o download estiver lento
                elif (self.download_stats['avg_download_time'] > 2.0 and 
                      self.current_chunk_index > 0 and 
                      failure_rate < 0.1): # Não reduzir se já houver muitas falhas
                    self.current_chunk_index -= 1
                    self.log(f"Reduzindo chunk size para {self.chunk_sizes[self.current_chunk_index]} bytes devido a lentidão ({self.download_stats['avg_download_time']:.2f}s avg)")
                
                # Aumentar chunk size se o desempenho for bom
                elif (failure_rate < 0.05 and 
                      self.download_stats['avg_download_time'] < 0.5 and 
                      self.current_chunk_index < len(self.chunk_sizes) - 1):
                    self.current_chunk_index += 1
                    self.log(f"Aumentando chunk size para {self.chunk_sizes[self.current_chunk_index]} bytes (desempenho bom)")
                
                # Resetar estatísticas após ajuste
                self.download_stats['failed_downloads'] = 0
                self.download_stats['total_downloaded'] = 0
                self.download_stats['last_adjustment'] = now

    def get_current_chunk_size(self):
        """Retorna o tamanho do chunk atual para download."""
        with self.chunk_lock:
            return self.chunk_sizes[self.current_chunk_index]

    def setup_routes(self):
        """Configura as rotas da aplicação Flask para o proxy HLS."""
        @self.app.errorhandler(400)
        def bad_request(error):
            self.log(f"Erro 400 Bad Request: {error.description}", xbmc.LOGWARNING)
            return jsonify({'error': error.description}), 400

        @self.app.errorhandler(500)
        def internal_server_error(error):
            self.log(f"Erro 500 Internal Server Error: {error}", xbmc.LOGERROR)
            return jsonify({'error': 'Erro interno do servidor'}), 500

        @self.app.before_request
        def get_auth_token():
            """
            Antes de cada requisição, tenta obter um token de autenticação
            armazenado na sessão para a URL original.
            """
            url = request.args.get('url')
            if url:
                original_url = urllib.parse.unquote_plus(url)
                g.token = session.get(original_url)
                if g.token:
                    self.log(f"Token encontrado na sessão para URL: {original_url}", xbmc.LOGDEBUG)
            else:
                g.token = None

        @self.app.route('/play')
        def play():
            """
            Rota principal para iniciar a reprodução de um stream HLS.
            Pode receber uma URL de playlist M3U8 ou um segmento direto.
            """
            self.log("Requisição recebida em /play")
            url = request.args.get('url')
            token = request.args.get('token')
            if not url:
                abort(400, "URL ausente")
            
            self.log(f"URL recebida: {url}, Token: {'Sim' if token else 'Não'}")

            try:
                original_url = urllib.parse.unquote_plus(url)
                if token:
                    session[original_url] = urllib.parse.unquote_plus(token)
                    self.log(f"Token de autenticação armazenado na sessão para {original_url}", xbmc.LOGDEBUG)
                
                if '.m3u8' in original_url.lower() or 'm3u8' in original_url.lower():
                    self.log("URL parece ser uma playlist M3U8.")
                    return self.handle_playlist(original_url)
                else:
                    self.log("URL não é uma playlist M3U8, tratando como segmento (fallback).")
                    return self.handle_segment(original_url)

            except Exception as e:
                self.log(f"Erro inesperado no proxy para /play: {str(e)}", xbmc.LOGERROR)
                abort(500, f"Erro interno do servidor ao processar /play: {str(e)}")

        @self.app.route('/segment')
        def segment():
            """
            Rota para servir segmentos individuais de vídeo, com caching e retries.
            """
            self.log("Requisição recebida em /segment")
            url = request.args.get('url')
            if not url:
                abort(400, "URL de segmento ausente")
            try:
                original_url = urllib.parse.unquote_plus(url)
                self.log(f"Processando segmento: {original_url}", xbmc.LOGDEBUG)
                return self.handle_segment(original_url)
            except Exception as e:
                self.log(f"Erro ao buscar segmento: {str(e)}", xbmc.LOGERROR)
                abort(500, f"Erro interno do servidor ao buscar segmento: {str(e)}")

        @self.app.route('/status')
        def status():
            """Rota para verificar o status do serviço proxy."""
            self.log("Requisição de status recebida.", xbmc.LOGDEBUG)
            return Response("OK", status=200, mimetype='text/plain')

        @self.app.route('/clear_cache')
        def clear_cache():
            """Rota para limpar o cache de segmentos."""
            self.log("Requisição para limpar cache recebida.")
            self.segment_cache.clear()
            return Response("Cache limpo", status=200, mimetype='text/plain')

    def _get_headers_with_auth(self, url):
        """
        Retorna os cabeçalhos HTTP, incluindo o token de autorização
        se um token global (g.token) estiver disponível.
        """
        headers = self.session_requests.headers.copy()
        if g.token:
            headers['Authorization'] = f'Bearer {g.token}'
            self.log(f"Adicionando cabeçalho de autenticação para {url}", xbmc.LOGDEBUG)
        return headers

    def handle_playlist(self, url):
        """
        Baixa e modifica uma playlist M3U8, reescrevendo as URLs dos segmentos
        e chaves de criptografia para apontar para o proxy.
        """
        self.log(f"Manipulando playlist: {url}")
        
        # Determina a URL base para resolver URLs relativas na playlist
        base_url = url.rsplit('/', 1)[0] + '/' if '/' in url else url + '/'
        self.log(f"URL base da playlist: {base_url}", xbmc.LOGDEBUG)
        
        headers = self._get_headers_with_auth(url)

        for attempt in range(self.max_retries):
            try:
                self.log(f"Buscando playlist (tentativa {attempt + 1}/{self.max_retries}) de: {url}")
                start_time = time.time()
                response = self.session_requests.get(url, timeout=self.timeout, headers=headers)
                response.raise_for_status() # Lança HTTPError para respostas de erro
                download_time = time.time() - start_time
                self.log(f"Playlist recebida com status: {response.status_code} em {download_time:.2f}s", xbmc.LOGDEBUG)
                self.adjust_chunk_size(success=True, download_time=download_time) # Ajusta chunk size

                lines = []
                for line in response.text.splitlines():
                    if line.startswith('#EXT-X-KEY'):
                        # Se for uma linha de chave de criptografia, reescreve a URI da chave
                        key_match = re.search(r'URI="([^"]+)"', line)
                        if key_match:
                            key_url = key_match.group(1)
                            if not key_url.startswith('http'):
                                absolute_key_url = urllib.parse.urljoin(base_url, key_url)
                                proxy_key_url = f"http://{self.host}:{self.port}/segment?url={urllib.parse.quote_plus(absolute_key_url)}"
                                self.log(f"Substituindo URL da chave: {key_url} -> {proxy_key_url}", xbmc.LOGDEBUG)
                                line = line.replace(key_url, proxy_key_url)
                        lines.append(line)
                    elif line.startswith('#') or not line.strip():
                        # Mantém linhas de comentário e linhas vazias
                        lines.append(line)
                    else:
                        # Se for uma URL de segmento, reescreve para apontar para o proxy
                        segment_url = urllib.parse.urljoin(base_url, line)
                        proxy_url = f"http://{self.host}:{self.port}/segment?url={urllib.parse.quote_plus(segment_url)}"
                        self.log(f"Substituindo segmento: {line} -> {proxy_url}", xbmc.LOGDEBUG)
                        lines.append(proxy_url)

                modified_playlist = '\n'.join(lines)
                self.log(f"Retornando playlist modificada com {len(lines)} linhas.", xbmc.LOGDEBUG)
                
                return Response(
                    modified_playlist,
                    mimetype='application/vnd.apple.mpegurl',
                    headers={
                        'Content-Disposition': 'inline',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    }
                )

            except RequestException as e:
                self.log(f"Erro de requisição ao buscar playlist (tentativa {attempt + 1}): {str(e)}", xbmc.LOGWARNING)
                self.adjust_chunk_size(success=False) # Ajusta chunk size em caso de falha
                if attempt == self.max_retries - 1:
                    raise # Relança a exceção se todas as tentativas falharem
                time.sleep(1) # Pequeno atraso antes de tentar novamente

    def handle_segment(self, url):
        """
        Baixa e serve um segmento de vídeo, utilizando cache LRU,
        ajuste dinâmico de chunk size e retries.
        """
        self.log(f"Manipulando segmento: {url}")
        
        # 1. Verificar cache primeiro
        cached_data = self.segment_cache.get(url)
        if cached_data is not None:
            self.log(f"Segmento encontrado no cache: {url} ({len(cached_data)} bytes)", xbmc.LOGDEBUG)
            return Response(
                cached_data,
                mimetype='video/MP2T', # Tipo MIME padrão para segmentos HLS
                headers={
                    'Content-Length': str(len(cached_data)),
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                }
            )
        
        headers = self._get_headers_with_auth(url)
        buffer_data = bytearray() # Usamos bytearray para construir o segmento
        chunk_size = self.get_current_chunk_size()
        total_downloaded = 0
        start_time = time.time()

        for attempt in range(self.max_retries):
            try:
                self.log(f"Buscando segmento (tentativa {attempt + 1}/{self.max_retries}) com chunk_size={chunk_size} de: {url}")
                response = self.session_requests.get(
                    url,
                    timeout=self.timeout,
                    stream=True, # Importante para baixar o conteúdo em chunks
                    headers=headers
                )
                response.raise_for_status() # Lança HTTPError para respostas de erro
                self.log(f"Segmento recebido com status: {response.status_code}", xbmc.LOGDEBUG)

                def generate():
                    nonlocal total_downloaded, chunk_size, buffer_data
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            buffer_data.extend(chunk)
                            total_downloaded += len(chunk)
                            
                            # Ajustar dinamicamente o chunk size durante o download
                            # Isso pode ajudar a otimizar a velocidade de download em tempo real
                            if total_downloaded % (2 * 1024 * 1024) == 0: # A cada 2MB baixados
                                new_chunk_size = self.get_current_chunk_size()
                                if new_chunk_size != chunk_size:
                                    self.log(f"Ajustando chunk_size durante download: {chunk_size} -> {new_chunk_size}", xbmc.LOGDEBUG)
                                    chunk_size = new_chunk_size
                            
                            yield chunk
                
                # Armazenar no cache em uma thread separada após o download completo
                def store_in_cache_thread_target():
                    if len(buffer_data) > 0:
                        self.segment_cache.put(url, bytes(buffer_data)) # Converte para bytes antes de armazenar
                        self.log(f"Segmento armazenado no cache em segundo plano: {url} ({len(buffer_data)} bytes)", xbmc.LOGDEBUG)

                # Iniciar thread para armazenar no cache
                cache_thread = threading.Thread(target=store_in_cache_thread_target)
                cache_thread.daemon = True # Define como daemon para que termine com o processo principal
                cache_thread.start()

                download_time = time.time() - start_time
                self.adjust_chunk_size(success=True, download_time=download_time)
                
                content_type = response.headers.get('Content-Type', 'video/MP2T') # Fallback para tipo MIME
                content_length = response.headers.get('Content-Length')
                self.log(f"Retornando segmento com tipo: {content_type}, tamanho esperado: {content_length if content_length else 'Desconhecido'}, tempo: {download_time:.2f}s", xbmc.LOGDEBUG)
                
                return Response(
                    generate(),
                    mimetype=content_type,
                    headers={
                        'Content-Length': content_length, # Mantém o Content-Length original se disponível
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    }
                )

            except RequestException as e:
                self.log(f"Erro de requisição ao buscar segmento (tentativa {attempt + 1}): {str(e)}", xbmc.LOGWARNING)
                self.adjust_chunk_size(success=False) # Ajusta chunk size em caso de falha
                if attempt == self.max_retries - 1:
                    raise # Relança a exceção se todas as tentativas falharem
                time.sleep(1) # Pequeno atraso antes de tentar novamente

    def error_response(self, message, status_code):
        """Retorna uma resposta de erro padronizada em JSON."""
        self.log(f"Retornando erro: {message} (status: {status_code})", xbmc.LOGERROR)
        return jsonify({'error': message}), status_code

    def run(self):
        """Inicia o servidor Flask para o serviço proxy HLS."""
        self.log(f"Servidor proxy HLS iniciando em http://{self.host}:{self.port}")
        self.running = True
        try:
            # make_server cria um servidor WSGI, compatível com Flask
            self.server = make_server(self.host, self.port, self.app)
            self.server.serve_forever() # Inicia o servidor e o mantém rodando
        except socket.error as e:
            self.log(f"Erro de socket ao iniciar servidor: {str(e)}. A porta {self.port} pode estar em uso.", xbmc.LOGERROR)
            self.running = False
        except Exception as e:
            self.log(f"Erro inesperado ao iniciar servidor: {str(e)}", xbmc.LOGERROR)
            self.running = False
        finally:
            if not self.running:
                # Notifica o usuário no Kodi se o serviço falhou ao iniciar.
                xbmcgui.Dialog().notification(
                    "HLS Tester",
                    f"Falha ao iniciar serviço proxy na porta {self.port}.",
                    xbmcgui.NOTIFICATION_ERROR
                )

    def stop(self):
        """Para o servidor Flask e limpa o cache."""
        if self.server:
            self.log("Parando servidor proxy HLS...")
            self.server.shutdown() # Desliga o servidor
            self.log("Servidor proxy HLS parado.")
            self.running = False
        self.segment_cache.clear() # Limpa o cache ao parar o serviço

    def is_running(self):
        """Verifica se o serviço proxy está em execução."""
        return self.running

class MainService:
    """
    Classe de serviço principal para o Kodi, responsável por iniciar e gerenciar
    o HLSService em uma thread separada e monitorar requisições de aborto do Kodi.
    """
    def __init__(self):
        self.log("Iniciando MainService")
        self.hls_service = HLSService() # Instancia o serviço HLS
        self.monitor = xbmc.Monitor() # Monitor para detectar requisições de aborto do Kodi

    def log(self, msg, level=xbmc.LOGINFO):
        """Função de log para o MainService."""
        xbmc.log(f"[script.hls.tester] {msg}", level)

    def run(self):
        """
        Executa o serviço principal, iniciando o HLSService em uma thread
        e mantendo-o ativo enquanto o Kodi não solicita o aborto.
        """
        self.log("Iniciando thread do serviço HLS...")
        service_thread = threading.Thread(target=self.hls_service.run)
        service_thread.daemon = True # Permite que a thread seja encerrada com o programa principal
        service_thread.start()
        self.log("Thread do serviço HLS iniciada.")
        
        try:
            while not self.monitor.abortRequested():
                # Espera por um curto período ou até que uma requisição de aborto seja feita.
                # Isso mantém o serviço principal ativo sem consumir CPU excessivamente.
                if self.monitor.waitForAbort(1): # Espera por 1 segundo
                    break
        except Exception as e:
            self.log(f"Erro no serviço principal: {str(e)}", xbmc.LOGERROR)
        finally:
            self.log("Requisição de aborto detectada ou erro. Parando serviço HLS...")
            self.hls_service.stop() # Garante que o serviço HLS seja parado corretamente
            self.log("MainService finalizado.")

if __name__ == '__main__':
    # Este bloco é executado quando service.py é iniciado como um serviço pelo Kodi.
    MainService().run()