# -*- coding: utf-8 -*-
# HLSHOST9.py - Proxy HLS Local TCP/HTTP Otimizado v8.8.2 (PORT-FIX & PERFORMANCE)
# Senior IPTV Specialist Implementation - Kodi/Android

import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import time
import random
import socket
import sys
import os
import logging
from collections import OrderedDict
from requests.adapters import HTTPAdapter

# --- KODI IMPORTS & PATHS ---
try:
    import xbmc, xbmcgui, xbmcplugin, xbmcvfs
    ADDON_DATA = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.gifpegtv.plus/")
    if not os.path.exists(ADDON_DATA): os.makedirs(ADDON_DATA)
    LOG_FILE = os.path.join(ADDON_DATA, 'hls_proxy.log')
except ImportError:
    LOG_FILE = 'hls_proxy.log'
    class Mock:
        def log(self, *a): pass
    xbmc = Mock()

# --- LOGGING CONFIG ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.FileHandler(LOG_FILE, encoding='utf-8'), logging.StreamHandler()]
)
logger = logging.getLogger("HLSHOST9")

# --- OTIMIZAÇÃO: Regex Pré-compilada ---
REGEX_URI = re.compile(r'URI=["\'](.*?)["\']')

# --- CONFIGURAÇÃO GLOBAL ---
CONFIG = {
    'PORT': 8010,
    'POOL_SIZE': 40, 
    'MAX_RETRIES': 2,
    'CONN_TIMEOUT': 5, 
    'READ_TIMEOUT': 15,
    'CACHE_TTL': 7200,
    'CHUNK_SIZE': 65536,
    'USER_AGENTS': [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/119.0 Firefox/119.0",
        "Kodi/20.2 (Linux; Android 11) App_Version/20.2.0"
    ]
}

# --- SURVIVAL SESSION MANAGER ---
class SessionManager:
    def __init__(self):
        self.session = requests.Session()
        adapter = HTTPAdapter(
            pool_connections=CONFIG['POOL_SIZE'], 
            pool_maxsize=CONFIG['POOL_SIZE'], 
            max_retries=CONFIG['MAX_RETRIES'],
            pool_block=False
        )
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        self.cache = OrderedDict()
        self._lock = threading.Lock()
        self._ua_cache = random.choice(CONFIG['USER_AGENTS'])

    def get_headers(self, url, referer=None):
        try:
            netloc = urllib.parse.urlsplit(url).netloc
        except:
            netloc = ""
        headers = {
            'User-Agent': self._ua_cache,
            'Accept': '*/*',
            'Connection': 'keep-alive',
            'Host': netloc,
            'X-Forwarded-For': f"192.168.{random.randint(0,255)}.{random.randint(1,254)}"
        }
        if referer: headers['Referer'] = referer
        return headers

    def invalidate(self, original_url):
        with self._lock:
            if original_url in self.cache:
                self.cache.pop(original_url, None)

    def resolve_url(self, url, force_new=False):
        if not force_new:
            with self._lock:
                entry = self.cache.get(url)
                if entry and entry['expires'] > time.time():
                    return entry['resolved']
        curr = url
        ref = None
        for _ in range(4):
            try:
                headers = self.get_headers(curr, ref)
                r = self.session.get(curr, headers=headers, allow_redirects=False, timeout=(CONFIG['CONN_TIMEOUT'], 8))
                if r.status_code in [301, 302, 303, 307, 308]:
                    ref = curr
                    location = r.headers.get('Location')
                    if location:
                        curr = urllib.parse.urljoin(curr, location)
                        continue
                if ".m3u8" in curr.lower() and "#EXTM3U" not in r.text:
                    return None
                with self._lock:
                    self.cache[url] = {'resolved': curr, 'expires': time.time() + CONFIG['CACHE_TTL']}
                return curr
            except Exception:
                break
        return curr

session_mgr = SessionManager()

# --- PROXY HANDLER ---
class HLSHostHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format, *args): pass

    def handle_one_request(self):
        try:
            return super().handle_one_request()
        except (ConnectionResetError, BrokenPipeError, socket.error):
            self.close_connection = True
        except Exception:
            self.close_connection = True

    def do_GET(self):
        try:
            if '?' in self.path:
                query_string = self.path.split('?', 1)[1]
                params = urllib.parse.parse_qs(query_string)
                orig_url = params.get('url', [None])[0]
                req_type = params.get('type', ['manifest'])[0]
            else:
                return

            if not orig_url: return

            if req_type == 'manifest':
                self.handle_manifest(orig_url)
            elif req_type == 'segment':
                self.handle_segment(orig_url)
            elif req_type == 'key':
                self.handle_key(orig_url)
        except (ConnectionResetError, BrokenPipeError, socket.error):
            pass
        except Exception as e:
            logger.error(f"Erro Handler: {e}")

    def handle_manifest(self, orig_url, retry=True):
        resolved = session_mgr.resolve_url(orig_url)
        if not resolved: 
            self.send_error(404)
            return
        try:
            r = session_mgr.session.get(resolved, headers=session_mgr.get_headers(resolved), timeout=(CONFIG['CONN_TIMEOUT'], CONFIG['READ_TIMEOUT']))
            if r.status_code != 200 or "#EXTM3U" not in r.text:
                if retry:
                    session_mgr.invalidate(orig_url)
                    self.handle_manifest(orig_url, retry=False)
                    return
                raise ValueError("Manifesto invalido")
            
            proxy_base = f"http://{self.headers.get('Host')}/"
            lines = r.text.splitlines()
            output = []
            for line in lines:
                line = line.strip()
                if not line: continue
                if line.startswith('#EXT-X-KEY'):
                    uri_match = REGEX_URI.search(line)
                    if uri_match:
                        uri = uri_match.group(1)
                        abs_key = urllib.parse.urljoin(resolved, uri)
                        proxy_key = f"{proxy_base}?type=key&url={urllib.parse.quote_plus(abs_key)}"
                        line = line.replace(uri, proxy_key)
                    output.append(line)
                elif line.startswith('#'):
                    output.append(line)
                else:
                    abs_url = urllib.parse.urljoin(resolved, line)
                    ptype = "manifest" if ".m3u8" in line.lower() else "segment"
                    new_line = f"{proxy_base}?type={ptype}&url={urllib.parse.quote_plus(abs_url)}"
                    output.append(new_line)
            content = "\n".join(output).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Connection', 'keep-alive')
            self.end_headers()
            self.wfile.write(content)
        except (ConnectionResetError, BrokenPipeError, socket.error):
            pass
        except Exception:
            self.send_error(502)

    def handle_segment(self, seg_url):
        headers = session_mgr.get_headers(seg_url)
        if 'Range' in self.headers: headers['Range'] = self.headers['Range']
        try:
            with session_mgr.session.get(seg_url, headers=headers, stream=True, timeout=(CONFIG['CONN_TIMEOUT'], CONFIG['READ_TIMEOUT'])) as r:
                if r.status_code >= 400:
                    self.send_error(503)
                    return
                self.send_response(r.status_code)
                for k, v in r.headers.items():
                    if k.lower() in ['content-type', 'content-length', 'content-range']:
                        self.send_header(k, v)
                self.send_header('Connection', 'keep-alive')
                self.end_headers()
                for chunk in r.iter_content(chunk_size=CONFIG['CHUNK_SIZE']):
                    if not chunk: break
                    self.wfile.write(chunk)
        except (socket.timeout, ConnectionResetError, BrokenPipeError, socket.error):
            pass 
        except Exception as e:
            logger.error(f"Erro segmento: {str(e)[:50]}")

    def handle_key(self, key_url):
        try:
            r = session_mgr.session.get(key_url, headers=session_mgr.get_headers(key_url), timeout=(CONFIG['CONN_TIMEOUT'], 10))
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.end_headers()
            self.wfile.write(r.content)
        except:
            self.send_error(404)

# --- SERVER CORE CORRIGIDO PARA LIBERAÇÃO DE PORTA ---
class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 60

    def server_bind(self):
        # Garante a reutilização do endereço (SO_REUSEADDR)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        # Tenta aplicar SO_REUSEPORT (Específico para Linux/Android) para evitar "Address already in use"
        try:
            if hasattr(socket, 'SO_REUSEPORT'):
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except socket.error:
            pass

        try:
            self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except (AttributeError, socket.error): pass
        
        super().server_bind()

    def handle_error(self, request, client_address):
        try:
            exc_type, exc_value, _ = sys.exc_info()
            if issubclass(exc_type, (ConnectionResetError, BrokenPipeError, socket.timeout, socket.error)):
                return
            logger.error(f"Server Error ({client_address}): {exc_value}")
        except:
            pass

class HLSAddon:
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(HLSAddon, cls).__new__(cls)
            cls._instance.port = CONFIG['PORT']
            cls._instance.started = False
        return cls._instance

    def __init__(self, handle=None):
        self.handle = handle

    def start_proxy(self):
        if not self.started:
            try:
                # Tenta iniciar o servidor; se falhar, limpa o estado para permitir nova tentativa
                server = ThreadedServer(('127.0.0.1', self.port), HLSHostHandler)
                t = threading.Thread(target=server.serve_forever, daemon=True)
                t.start()
                self.started = True
                logger.info(f"Proxy Online na porta {self.port}")
            except Exception as e:
                self.started = False
                logger.error(f"Falha ao iniciar servidor: {e}")

    def play_stream(self, stream_url, stream_type='live'):
        self.start_proxy()
        proxy_url = f"http://127.0.0.1:{self.port}/?type=manifest&url={urllib.parse.quote_plus(stream_url)}"
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        listitem = xbmcgui.ListItem(path=proxy_url)
        listitem.setProperty('IsPlayable', 'true')
        if stream_type == 'live':
            listitem.setProperty('IsLiveStream', 'true')
        xbmcplugin.setResolvedUrl(handle, True, listitem)
        return True