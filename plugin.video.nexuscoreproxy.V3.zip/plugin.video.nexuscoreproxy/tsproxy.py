import http.server
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES MPEG-TS (Otimizadas para Sincronia Perfeita e Início Rápido)
# ─────────────────────────────────────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

_NULL_HDR      = bytes([0x47, 0x1F, 0xFF, 0x10])
TS_NULL_PACKET = _NULL_HDR + b'\xFF' * 184

# 7 pacotes = 1316 bytes (Encaixe perfeito no MTU UDP e tamanho ideal de chunk)
CHUNK_SIZE = TS_PACKET_SIZE * 7  
NULL_PUMP_BURST = TS_NULL_PACKET * 7

STALL_TIMEOUT = 2.5  # Segundos sem dados úteis para forçar reconexão

HOST = "127.0.0.1"
PORT = 8083

# Buffers de saída ajustados para contrapressão sem causar timeout inicial
MAX_OUTPUT_BUFFER = 56  # Limite máximo da fila antes de aplicar contrapressão

# ─────────────────────────────────────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)


# ─────────────────────────────────────────────────────────────────────────────
#  TsParser — Versão Otimizada com Correção In-Place (Zero-Copy)
# ─────────────────────────────────────────────────────────────────────────────
class TsParser:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}

    def reset(self):
        self._buf.clear()
        self._aligned = False
        self._cc_map.clear()

    def _find_sync(self, data: bytearray) -> int:
        idx = data.find(TS_SYNC_BYTE)
        while idx != -1 and idx + TS_PACKET_SIZE <= len(data):
            # Confirma sincronia checando o próximo pacote
            if data[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE:
                return idx
            idx = data.find(TS_SYNC_BYTE, idx + 1)
        return -1

    def feed(self, raw: bytes) -> bytes:
        if raw:
            self._buf.extend(raw)

        if not self._aligned:
            idx = self._find_sync(self._buf)
            if idx == -1:
                # Evita memory leak descartando buffers sem sync
                if len(self._buf) > TS_PACKET_SIZE * 100:
                    self._buf.clear()
                return b''
            if idx > 0:
                del self._buf[:idx]
            self._aligned = True

        buf_len = len(self._buf)
        usable = buf_len - (buf_len % TS_PACKET_SIZE)
        if usable == 0:
            return b''

        chunk = self._buf[:usable]
        del self._buf[:usable]

        # Validação e Correção In-Place (Evita realocação de memória)
        mv = memoryview(chunk)
        n = usable // TS_PACKET_SIZE

        for i in range(n):
            off = i * TS_PACKET_SIZE
            
            if mv[off] != TS_SYNC_BYTE:
                # Pacote corrompido: substitui por Null Packet in-place para manter o CBR
                chunk[off:off+TS_PACKET_SIZE] = TS_NULL_PACKET
                continue

            pid = ((mv[off + 1] & 0x1F) << 8) | mv[off + 2]
            
            if pid == 0x1FFF: # Null packets não possuem regras de CC
                continue

            cc = mv[off + 3] & 0x0F
            afc = (mv[off + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)

            if pid in self._cc_map and has_payload:
                expected_cc = (self._cc_map[pid] + 1) & 0x0F
                
                if cc == expected_cc:
                    self._cc_map[pid] = cc
                elif cc == self._cc_map[pid]:
                    pass # Pacote duplicado
                else:
                    # Salto de CC (Perda de pacote). Atualiza para o CC atual sem descartar.
                    self._cc_map[pid] = cc
            else:
                self._cc_map[pid] = cc

        return bytes(chunk)


# ─────────────────────────────────────────────────────────────────────────────
#  StreamWriter — Thread Dedicada com Null Pump Inteligente
# ─────────────────────────────────────────────────────────────────────────────
class StreamWriter(threading.Thread):
    def __init__(self, wfile):
        super().__init__(daemon=True)
        self.wfile = wfile
        self.queue = queue.Queue(maxsize=MAX_OUTPUT_BUFFER)
        self.running = True
        self.last_data_time = time.time()

    def run(self):
        while self.running:
            try:
                # Timeout de 50ms para verificar se o Kodi desconectou ou se precisa injetar Null Packets
                data = self.queue.get(timeout=0.05)
                
                # Envio imediato para o Kodi (Sem buffer inicial artificial)
                self.wfile.write(data)
                self.wfile.flush()
                self.last_data_time = time.time()
                
            except queue.Empty:
                # Fila vazia: a origem está lenta ou caiu. 
                # Injeta Null Packets controlados para manter o clock do Kodi vivo
                time_since_last = time.time() - self.last_data_time
                if self.running and time_since_last > 0.1 and time_since_last < STALL_TIMEOUT:
                    try:
                        self.wfile.write(NULL_PUMP_BURST)
                        self.wfile.flush()
                        # Reseta o tempo para não inundar o Kodi (gotejamento)
                        self.last_data_time = time.time() 
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        self.running = False
            except (BrokenPipeError, ConnectionResetError, OSError):
                self.running = False

    def stop(self):
        self.running = False


# ─────────────────────────────────────────────────────────────────────────────
#  HANDLERS AUXILIARES
# ─────────────────────────────────────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers): return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

class SessionManager:
    def __init__(self):
        self._opener = None
        self._last_clean = 0
    
    def get_opener(self):
        if self._opener is None or time.time() - self._last_clean > 60:
            if self._opener:
                try: self._opener.close()
                except: pass
            self._opener = urllib.request.build_opener(
                urllib.request.HTTPHandler(),
                urllib.request.HTTPSHandler(),
                NoRedirectHandler
            )
            self._last_clean = time.time()
        return self._opener


# ─────────────────────────────────────────────────────────────────────────────
#  SERVIDOR
# ─────────────────────────────────────────────────────────────────────────────
def _ensure_server_running():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.5)
    try:
        sock.connect((HOST, PORT))
        return PORT
    except Exception:
        pass
    finally:
        sock.close()

    srv = http.server.ThreadingHTTPServer((HOST, PORT), ZeroSuturaProxy)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    time.sleep(0.5)
    return PORT


# ─────────────────────────────────────────────────────────────────────────────
#  PROXY HANDLER
# ─────────────────────────────────────────────────────────────────────────────
class ZeroSuturaProxy(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args): 
        return

    def _resolve_url(self, url: str, ua: str) -> str:
        curr = url
        for _ in range(3):
            try:
                parsed = urllib.parse.urlparse(curr)
                req = urllib.request.Request(curr, headers={
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Connection': 'keep-alive',
                })
                
                opener = SessionManager().get_opener()
                # Usa GET e lê apenas 1 byte para forçar o redirect sem baixar o vídeo inteiro
                with opener.open(req, timeout=5) as resp:
                    if resp.code in (301, 302, 303, 307, 308):
                        loc = resp.headers.get('Location', '')
                        if loc:
                            curr = urllib.parse.urljoin(curr, loc)
                            continue
                    return curr
            except Exception:
                break
        return curr

    def _calculate_backoff(self, reconnect_num: int, error_type: str = 'network') -> float:
        base = 0.15 if error_type in ('reset', 'network') else 0.3
        if reconnect_num <= 2:
            return base * reconnect_num
        return min(3.0, base * (reconnect_num ** 1.3))

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'keep-alive')
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'keep-alive')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        # Inicia a Thread Dedicada de Escrita
        writer = StreamWriter(self.wfile)
        writer.start()

        resolved_url = original_url
        ua = _pick_ua()
        reconnect_num = 0
        ts_parser = TsParser()
        session_mgr = SessionManager()
        
        last_useful_payload = time.time()
        error_type = 'network'

        try:
            while writer.running:
                ts_parser.reset()
                last_useful_payload = time.time()
                
                try:
                    parsed = urllib.parse.urlparse(resolved_url)
                    req = urllib.request.Request(resolved_url, headers={
                        'User-Agent': ua,
                        'Accept': '*/*',
                        'Host': parsed.netloc,
                        'Referer': original_url,
                        'Connection': 'keep-alive',
                        'Icy-MetaData': '0',
                    })

                    opener = session_mgr.get_opener()
                    
                    with opener.open(req, timeout=15) as response:
                        if reconnect_num == 0:
                            print(f"[ZeroSutura] Conectado → {ua[:25]}...")
                        else:
                            reconnect_num = max(0, reconnect_num - 2)

                        while writer.running:
                            raw = response.read(32768)

                            if not raw:
                                break

                            payload = ts_parser.feed(raw)
                            
                            if payload:
                                last_useful_payload = time.time()
                                try:
                                    # Contrapressão segura: bloqueia se a fila estiver cheia
                                    writer.queue.put(payload, block=True, timeout=5.0)
                                except queue.Full:
                                    print("[!] Buffer de saída cheio, Kodi está lento. Descartando...")
                            else:
                                if time.time() - last_useful_payload > STALL_TIMEOUT:
                                    print("[!] Stream stall detectado - forçando reconexão")
                                    break

                except urllib.error.HTTPError as e:
                    error_type = 'http'
                except urllib.error.URLError as e:
                    reason = str(e.reason).lower()
                    error_type = 'timeout' if 'timeout' in reason else 'reset' if 'reset' in reason else 'network'
                except socket.timeout:
                    error_type = 'timeout'
                except ConnectionResetError:
                    error_type = 'reset'
                except (BrokenPipeError, OSError):
                    break # Kodi encerrou
                except Exception:
                    error_type = 'network'

                if not writer.running:
                    break

                reconnect_num += 1
                ua = _pick_ua()
                backoff = self._calculate_backoff(reconnect_num, error_type)
                
                print(f"[!] Falha ({error_type}) #{reconnect_num}. Reconectando em {backoff:.2f}s")
                time.sleep(backoff)

                try:
                    new_url = self._resolve_url(original_url, ua)
                    if new_url != resolved_url:
                        resolved_url = new_url
                        print(f"[+] Token/URL atualizado #{reconnect_num}")
                except Exception:
                    pass

        finally:
            writer.stop()
            writer.join(timeout=1.0)


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = _ensure_server_running()
    print(f"[ZeroSutura v5 Pro] Proxy rodando em http://{HOST}:{port}/stream?url=<URL>")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("[ZeroSutura] Encerrado.")