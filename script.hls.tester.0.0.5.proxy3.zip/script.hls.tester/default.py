# -*- coding: utf-8 -*-

# --- Kodi Imports ---
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# --- Standard Library Imports ---
import http.server
import socketserver
import requests
import socket
import os
import time
import threading
import re
import urllib3

# Desabilitar avisos de requisições inseguras para logs mais limpos
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Configuração do Addon Kodi ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
_handle = int(sys.argv[1])
_base_url = sys.argv[0]
_params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

# ==============================================================================
# CONFIGURAÇÕES DE OTIMIZAÇÃO DO PROXY
# ==============================================================================

N_TENTATIVAS_GERAIS = 5
DELAY_INICIAL_SEGMENTO = 0.5
CONNECT_TIMEOUT = 10.0
READ_TIMEOUT = 20.0
USER_AGENT_PADRAO = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
TAMANHO_BLOCO_KB = 128

DELAY_FIXO_404 = 0.5
N_TENTATIVAS_404 = 15

GLOBAL_USERNAME = None
GLOBAL_PASSWORD = None
KEY_URI_RE = re.compile(r'URI="([^"]+)"')

GLOBAL_MANIFEST_URL = None

def get_free_port():
    """Encontra uma porta livre na máquina local para iniciar o servidor proxy."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        return s.getsockname()[1]

def download_resource(url, headers, stream=False):
    """
    Função otimizada para baixar recursos (manifestos e segmentos).
    - Usa timeouts separados para conexão e leitura.
    - Implementa uma lógica de nova tentativa rápida e específica para erros 404 em segmentos.
    """
    ultima_excecao = None
    is_segment = '.ts' in url.lower() or '.aac' in url.lower()

    with requests.Session() as s:
        s.headers.update(headers)
        for tentativa in range(N_TENTATIVAS_GERAIS):
            try:
                response = s.get(url, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), stream=stream, allow_redirects=True, verify=False)
                response.raise_for_status()
                return response
            except requests.exceptions.HTTPError as e:
                ultima_excecao = e
                if is_segment and e.response is not None and e.response.status_code == 404:
                    xbmc.log(f"[{ADDON_ID}] Segmento {os.path.basename(url)} retornou 404. Servidor lento. Sendo mais persistente...", level=xbmc.LOGWARNING)
                    for i in range(N_TENTATIVAS_404):
                        time.sleep(DELAY_FIXO_404)
                        try:
                            retry_response = s.get(url, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), stream=stream, allow_redirects=True, verify=False)
                            if retry_response.ok:
                                xbmc.log(f"[{ADDON_ID}] Sucesso na tentativa rápida {i+1}/{N_TENTATIVAS_404} para o segmento 404.", level=xbmc.LOGINFO)
                                return retry_response
                        except Exception as ex:
                            xbmc.log(f"[{ADDON_ID}] Tentativa rápida {i+1}/{N_TENTATIVAS_404} falhou: {ex}", level=xbmc.LOGDEBUG)
                    xbmc.log(f"[{ADDON_ID}] Falha persistente no segmento 404 após {N_TENTATIVAS_404} tentativas rápidas.", level=xbmc.LOGERROR)
                xbmc.log(f"[{ADDON_ID}] Falha HTTP na tentativa {tentativa + 1}/{N_TENTATIVAS_GERAIS} para {url}: {e}", level=xbmc.LOGWARNING)
            except requests.exceptions.RequestException as e:
                ultima_excecao = e
                xbmc.log(f"[{ADDON_ID}] Falha de conexão na tentativa {tentativa + 1}/{N_TENTATIVAS_GERAIS} para {url}: {e}", level=xbmc.LOGWARNING)
            if (tentativa + 1) < N_TENTATIVAS_GERAIS:
                time.sleep(DELAY_INICIAL_SEGMENTO * (2 ** tentativa))
    xbmc.log(f"[{ADDON_ID}] Falha definitiva ao baixar {url} após {N_TENTATIVAS_GERAIS} tentativas. Última exceção: {ultima_excecao}", level=xbmc.LOGERROR)
    return None

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _prepare_headers_for_forwarding(self):
        """ Prepara os cabeçalhos para a requisição ao servidor de origem. """
        return {
            'User-Agent': USER_AGENT_PADRAO,
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'Keep-Alive',
            'Referer': self.headers.get('Referer', ''),
            'Origin': self.headers.get('Origin', ''),
        }

    def _process_manifest(self, content, target_url):
        """ Processa o manifesto M3U8 para reescrever as URLs e retornar o conteúdo modificado. """
        modified_content_lines = []
        base_url_manifest = os.path.dirname(target_url) + '/'

        for line in content.splitlines():
            line = line.strip()
            if not line:
                continue

            if line.startswith('#EXT-X-KEY'):
                match = KEY_URI_RE.search(line)
                if match:
                    key_uri = match.group(1)
                    absolute_key_uri = urllib.parse.urljoin(base_url_manifest, key_uri)
                    encoded_key_uri = urllib.parse.quote(absolute_key_uri, safe='')
                    proxied_key_uri = f"/proxy/{encoded_key_uri}"
                    line = KEY_URI_RE.sub(f'URI="{proxied_key_uri}"', line)
                modified_content_lines.append(line)
            elif line.startswith('#'):
                modified_content_lines.append(line)
            else:
                absolute_url = urllib.parse.urljoin(base_url_manifest, line)
                encoded_url = urllib.parse.quote(absolute_url, safe='')
                modified_content_lines.append(f"/proxy/{encoded_url}")

        return "\n".join(modified_content_lines) + "\n"

    def _serve_manifest_after_segment_404(self):
        """
        Tenta buscar o manifesto principal novamente e o serve para o player
        para forçar uma reconexão e obter uma nova lista de segmentos.
        """
        global GLOBAL_MANIFEST_URL
        xbmc.log(f"[{ADDON_ID}] Tentando reconexão forçada. Rebuscando manifesto: {GLOBAL_MANIFEST_URL}", level=xbmc.LOGINFO)

        if not GLOBAL_MANIFEST_URL:
            xbmc.log(f"[{ADDON_ID}] Não há URL de manifesto principal para reconectar.", level=xbmc.LOGERROR)
            self.send_error(502, "Manifesto principal não encontrado para reconexão.")
            return

        try:
            forward_headers = self._prepare_headers_for_forwarding()
            response = download_resource(GLOBAL_MANIFEST_URL, headers=forward_headers, stream=False)

            if response and response.ok:
                xbmc.log(f"[{ADDON_ID}] Manifesto principal recarregado com sucesso.", level=xbmc.LOGINFO)
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()

                content = response.content.decode('utf-8', errors='replace')
                modified_content = self._process_manifest(content, GLOBAL_MANIFEST_URL)
                self.wfile.write(modified_content.encode('utf-8'))
                return True
            else:
                xbmc.log(f"[{ADDON_ID}] Falha ao recarregar o manifesto principal.", level=xbmc.LOGERROR)
                self.send_error(502, "Falha na reconexão forçada.")
                return False

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] Erro durante a reconexão forçada: {e}", level=xbmc.LOGERROR)
            self.send_error(500, "Erro interno durante a reconexão forçada.")
            return False

    def _proxy_and_stream_data(self, target_url, client_headers):
        """ Baixa o recurso, modifica se for um manifesto, e o transmite para o player. """
        is_m3u8 = '.m3u8' in target_url.lower()
        stream_mode = not is_m3u8

        response = download_resource(target_url, headers=client_headers, stream=stream_mode)

        if response:
            try:
                self.send_response(response.status_code)
                for key, value in response.headers.items():
                    if key.lower() in ['content-length', 'accept-ranges', 'content-range', 'date']:
                        self.send_header(key, value)

                self.send_header('Access-Control-Allow-Origin', '*')

                if is_m3u8:
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.end_headers()

                    content = response.content.decode('utf-8', errors='replace')
                    modified_content = self._process_manifest(content, target_url)
                    self.wfile.write(modified_content.encode('utf-8'))
                else:
                    if 'content-type' in response.headers:
                        self.send_header('Content-Type', response.headers['content-type'])
                    self.end_headers()

                    try:
                        for chunk in response.iter_content(chunk_size=TAMANHO_BLOCO_KB * 1024):
                            if chunk:
                                self.wfile.write(chunk)
                                self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError):
                        xbmc.log(f"[{ADDON_ID}] Player fechou a conexão (streaming de {os.path.basename(target_url)}).", level=xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[{ADDON_ID}] Erro durante o streaming de {os.path.basename(target_url)}: {e}", level=xbmc.LOGERROR)

            except (BrokenPipeError, ConnectionResetError):
                xbmc.log(f"[{ADDON_ID}] Player fechou a conexão antes do envio dos headers.", level=xbmc.LOGINFO)
            finally:
                response.close()
        else:
            is_segment = '.ts' in target_url.lower() or '.aac' in target_url.lower()
            if is_segment and GLOBAL_MANIFEST_URL:
                self._serve_manifest_after_segment_404()
            else:
                try:
                    self.send_error(502, f"Proxy falhou ao buscar o recurso: {target_url}")
                except Exception:
                    pass

    def do_GET(self):
        if self.path.startswith("/proxy/"):
            try:
                encoded_url = self.path.split('/proxy/', 1)[1]
                target_url = urllib.parse.unquote(encoded_url)

                global GLOBAL_MANIFEST_URL
                if '.m3u8' in target_url.lower() and not GLOBAL_MANIFEST_URL:
                    xbmc.log(f"[{ADDON_ID}] URL do manifesto principal capturada: {target_url}", level=xbmc.LOGINFO)
                    GLOBAL_MANIFEST_URL = target_url

                forward_headers = self._prepare_headers_for_forwarding()
                self._proxy_and_stream_data(target_url, forward_headers)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}][ProxyServer] Erro crítico no handler GET: {e}", level=xbmc.LOGERROR)
                try:
                    if not self.wfile.closed:
                        self.send_error(500, f"Erro interno do proxy: {e}")
                except Exception:
                    pass
        else:
            try:
                if not self.wfile.closed:
                    self.send_error(404, "Not Found")
            except Exception:
                pass

    def log_message(self, format, *args):
        xbmc.log(f"[{ADDON_ID}][ProxyServer] {format % args}", level=xbmc.LOGDEBUG)

class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    allow_reuse_address = True
    daemon_threads = True

def play_item(url):
    """Inicia o servidor proxy local e instrui o Kodi a reproduzir o stream através dele."""
    global GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_MANIFEST_URL

    parsed_url = urllib.parse.urlparse(url)
    url_params = urllib.parse.parse_qs(parsed_url.query)
    GLOBAL_USERNAME = url_params.get('username', [None])[0]
    GLOBAL_PASSWORD = url_params.get('password', [None])[0]

    clean_url = url.split('?')[0]
    GLOBAL_MANIFEST_URL = clean_url  # Define a URL do manifesto principal aqui

    if GLOBAL_USERNAME:
        xbmc.log(f"[{ADDON_ID}] Credenciais extraídas da URL para uso no proxy.", level=xbmc.LOGINFO)

    try:
        port = get_free_port()
        server_address = ('127.0.0.1', port)
        httpd = ThreadedHTTPServer(server_address, HLSProxyHandler)
        server_thread = threading.Thread(target=httpd.serve_forever)
        server_thread.daemon = True
        server_thread.start()
        xbmc.log(f"[{ADDON_ID}] Servidor proxy local iniciado em http://127.0.0.1:{port}", level=xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Falha ao iniciar o servidor proxy: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, f"Erro ao iniciar proxy: {e}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
        return

    encoded_original_url = urllib.parse.quote(clean_url, safe='')
    local_proxy_url = f"http://127.0.0.1:{port}/proxy/{encoded_original_url}"

    list_item = xbmcgui.ListItem(path=local_proxy_url)

    title = os.path.basename(urllib.parse.unquote(clean_url))
    list_item.setLabel(f"{title} (via Proxy)")

    list_item.setProperty('IsPlayable', 'true')
    # Não defina inputstream, deixe vazio ou remova se não necessário
    # list_item.setProperty('inputstream', '')

    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)

    xbmcplugin.setResolvedUrl(_handle, True, listitem=list_item)

def list_root():
    """Mostra uma mensagem explicando como usar o plugin."""
    xbmcplugin.setPluginCategory(_handle, "HLS Proxy Otimizado")
    xbmcplugin.setContent(_handle, 'files')

    info_text = (
        "Este plugin de proxy HLS funciona em segundo plano para melhorar a estabilidade da reprodução.\n\n"
        "Para usá-lo, aponte um item de uma lista .m3u para este plugin, como no exemplo abaixo:\n\n"
        "#EXTINF:-1,Canal Exemplo\n"
        f"plugin://{ADDON_ID}/?action=play&url=http://seuservidor.com/stream.m3u8\n\n"
        "[B]Para streams com autenticação:[/B]\n"
        f"plugin://{ADDON_ID}/?action=play&url=http://.../stream.m3u8&username=USUARIO&password=SENHA"
    )
    list_item = xbmcgui.ListItem(label='HLS Proxy (Não Clicável)')
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle('Como Usar o Proxy')
    info_tag.setPlot(info_text)

    xbmcplugin.addDirectoryItem(handle=_handle, url=_base_url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(_handle)

def router():
    """Roteador principal do plugin."""
    action = _params.get('action')
    url = _params.get('url')

    if action == 'play':
        if url:
            play_item(url)
        else:
            xbmc.log(f"[{ADDON_ID}] Ação 'play' chamada sem uma URL.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, "Erro: URL do stream não foi especificada.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
    else:
        list_root()

if __name__ == '__main__':
    router()