# -*- coding: utf-8 -*-
"""
Proxy HLS Ultra-Resiliente para Kodi e InputStream Adaptive

Otimizações Aplicadas (Versão de Máxima Compatibilidade - Troca Inteligente de Perfil):
- CORREÇÃO 8 (Troca de Perfil): Introduz a troca de perfil de cliente (Chrome > VLC) após falha inicial do manifesto.
- CLIENT PROFILES: Adiciona um perfil completo de Chrome (incluindo Client-Hints) para máxima compatibilidade com servidores modernos.
- SSL/TLS: Verificação SSL desativada ('verify=False').
- Headers Dinâmicos: O cabeçalho 'Host' e 'Referer' são redefinidos dinamicamente em CADA PASSO do redirecionamento.
- Octet-Stream: Content-Type dos SEGMENTOS e CHAVES é definido como 'application/octet-stream'.
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import re
from collections import OrderedDict

# Bibliotecas de requisição
try:
    import requests as real_requests
    import requests.exceptions as req_exc
except ImportError:
    print("Erro: A biblioteca 'requests' é necessária. Instale com: pip install requests")
    sys.exit(1)

# Cliente DNS-over-HTTPS (DoH) para maior resiliência
try:
    from doh_client import requests as doh_requests
except ImportError:
    logging.warning("doh_client não encontrado. Usando requests padrão, o que pode ser menos resiliente a bloqueios de DNS.")
    doh_requests = real_requests

# Mock para o ambiente Kodi, permitindo testes fora dele
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    class XBMCMock:
        def translatePath(self, path): return os.getcwd()
        def log(self, msg, level=0): print(f"[KODI-MOCK] {msg}")
    xbmc = XBMCMock()
    xbmcgui = xbmcplugin = xbmc

# ---------------- CONFIGURAÇÕES ----------------
PROXY_HOST = "127.0.0.1"
MAX_PORT_ATTEMPTS = 20
CONNECTION_TIMEOUT = 15
STREAM_TIMEOUT = 30
SEGMENT_TTL = 300
MANIFEST_TTL = 6.0
MAX_CACHE_SIZE = 100 * 1024 * 1024

# Caches e Dados Globais
manifest_cache = OrderedDict()
segment_cache = OrderedDict()
current_cache_size = 0
DUMMY_TS = bytes([0x47] + [0x1F] * 187) * (2 * 1024 * 1024 // 188)
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# --- PERFIS DE CLIENTE ---
CLIENT_PROFILES = {
    # Perfil 0: Chrome Completo (Mais agressivo, para servidores modernos)
    'chrome': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Sec-Ch-Ua': '"Chromium";v="128", "Google Chrome";v="128", "Not=A?Brand";v="99"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
    },
    # Perfil 1: Emulação VLC (Mais simples e tolerante, para servidores antigos ou estritos)
    'vlc': {
        'User-Agent': 'VLC/3.0.18 LibVLC/3.0.18',
        'Accept': '*/*',
        'Connection': 'keep-alive',
    }
}
DEFAULT_PROFILE = 'chrome' # Tenta o mais completo primeiro

# ---------------- FUNÇÃO DE HEADERS DINÂMICOS ----------------
def get_dynamic_headers(url, profile_key=DEFAULT_PROFILE):
    """Gera um conjunto de cabeçalhos dinâmicos, com Host e Referer baseados na URL atual."""
    try:
        headers = CLIENT_PROFILES[profile_key].copy()
        parsed_url = urllib.parse.urlparse(url)
        host = parsed_url.netloc
        origin = f"{parsed_url.scheme}://{host}"
        
        # Garante que Host e Referer estejam corretos para o domínio/IP atual
        headers.pop('Host', None)
        headers.pop('Referer', None)

        headers.update({
            'Host': host,
            'Referer': origin + '/',
        })
        
        return headers
    except Exception:
        # Fallback para User-Agent e Host mínimos
        return {'User-Agent': 'VLC/3.0.18', 'Host': urllib.parse.urlparse(url).netloc}

# ---------------- GERENCIADOR DE SESSÃO ----------------
class SessionManager:
    def __init__(self): self._sessions = {}; self._lock = threading.Lock()
    def _create_session(self):
        if isinstance(doh_requests, type(real_requests.Session())): session = doh_requests
        else: session = real_requests.Session()
        session.max_redirects = 10
        return session
    
    # As sessões são indexadas pela URL base do manifesto E pelo profile_key
    def get_session(self, sid):
        with self._lock:
            if sid not in self._sessions: self._sessions[sid] = self._create_session()
            return self._sessions[sid]
    
    def reset_session(self, sid):
        with self._lock:
            logging.warning(f"[{sid}] Resetando sessão devido a falha.")
            self._sessions[sid] = self._create_session()
            return self._sessions[sid]

session_manager = SessionManager()
current_profiles = {} # Map de {session_id: profile_key}

# ---------------- GERENCIADOR DE CACHE ----------------
def _evict_cache_if_needed():
    global current_cache_size
    while current_cache_size > MAX_CACHE_SIZE:
        if segment_cache: _, (ts, data, _) = segment_cache.popitem(last=False); current_cache_size -= len(data)
        elif manifest_cache: _, (ts, data, _, _) = manifest_cache.popitem(last=False); current_cache_size -= len(data.encode("utf-8"))
        else: break
        
def cache_get(url):
    now = time.time()
    if url in segment_cache: 
        ts, data, headers = segment_cache[url]
        if now - ts < SEGMENT_TTL: 
            segment_cache.move_to_end(url)
            return data, headers
    if url in manifest_cache: 
        ts, data, base_url, ttl = manifest_cache[url]
        if now - ts < ttl: 
            manifest_cache.move_to_end(url)
            return data, base_url
    return None
    
def cache_set_manifest(url, data, base_url, ttl):
    global current_cache_size; size = len(data.encode("utf-8")); manifest_cache[url] = (time.time(), data, base_url, ttl)
    manifest_cache.move_to_end(url); current_cache_size += size; _evict_cache_if_needed()
    
def cache_set_segment(url, data, headers):
    global current_cache_size; size = len(data); segment_cache[url] = (time.time(), data, headers)
    segment_cache.move_to_end(url); current_cache_size += size; _evict_cache_if_needed()
    
def clear_manifest_cache():
    global current_cache_size; logging.warning("Limpando cache de manifestos para forçar atualização.")
    while manifest_cache: _, (ts, data, _, _) = manifest_cache.popitem(last=False); current_cache_size -= len(data.encode("utf-8"))

# ---------------- UTILITÁRIOS ----------------
def _obfuscate_url_for_log(url):
    try: return "***" + os.path.basename(urllib.parse.urlparse(url).path)
    except Exception: return "****"

# ---------------- MANIPULADOR DO PROXY HLS (MELHORADO) ----------------
class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if "?" not in self.path: self.send_response(200); self.end_headers(); return
        
        params = urllib.parse.parse_qs(self.path.split("?", 1)[1])
        url = urllib.parse.unquote_plus(params.get("url", [None])[0])
        sid = params.get("session_id", ["default"])[0]
        
        if not url: self.send_response(200); self.end_headers(); return
        
        # Garante que o profile_key esteja definido para a sessão
        if sid not in current_profiles: current_profiles[sid] = DEFAULT_PROFILE
        profile_key = current_profiles[sid]

        if url.lower().endswith(".m3u8"): self._handle_manifest(url, sid, profile_key)
        elif ".key" in url.lower() or "/key/" in url.lower(): self._handle_key(url, sid, profile_key)
        else: self._handle_segment(url, sid, profile_key)

    def _fetch_with_redirect_handling(self, sess, url, timeout, profile_key, is_stream=False, sid="default"):
        """Implementa o redirecionamento manual. Headers dinâmicos com base no profile_key."""
        current_url = url
        r = None
        
        for _ in range(10): 
            # Headers são gerados dinamicamente para a URL ATUAL E o perfil selecionado
            headers = get_dynamic_headers(current_url, profile_key) 
            
            r = sess.get(current_url, headers=headers, timeout=timeout, verify=False, allow_redirects=False, stream=is_stream)

            if r.status_code in (301, 302, 307, 308):
                new_url = r.headers.get('Location')
                r.close() 
                if new_url:
                    current_url = urllib.parse.urljoin(current_url, new_url)
                    logging.warning(f"[{sid}|{profile_key}] Redirecionamento {r.status_code} para {current_url}")
                    continue
                else:
                    raise req_exc.RequestException(f"Erro: Redirecionamento {r.status_code} sem cabeçalho Location.")
            
            return r

        if r: r.close()
        raise req_exc.RequestException("Excedido o limite de redirecionamentos.")

    def _handle_manifest(self, url, sid, profile_key, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        cached = cache_get(url)
        if cached and retry_count == 0: content, base_url = cached; return self._send_manifest(content, base_url, sid)
        r = None
        
        # Lógica de tentativa de perfil
        try_profiles = [profile_key]
        if profile_key == 'chrome': try_profiles.append('vlc') # Tenta Chrome, depois VLC

        for current_profile in try_profiles:
            try:
                if current_profile != profile_key:
                    logging.warning(f"[{sid}] Tentativa inicial falhou. Trocando perfil para: {current_profile}")
                    current_profiles[sid] = current_profile
                    session_manager.reset_session(sid) # Resetar sessão ao trocar de perfil
                
                sess = session_manager.get_session(sid)
                r = self._fetch_with_redirect_handling(sess, url, (CONNECTION_TIMEOUT, STREAM_TIMEOUT), current_profile, is_stream=False, sid=sid)

                if r.status_code in (401, 403, 404, 429):
                    raise req_exc.RequestException(f"Erro de cliente: {r.status_code}")
                r.raise_for_status(); 
                
                content, base_url = r.text, r.url 
                
                # Se o manifesto não for HLS (e o código de status for 200), tente o próximo perfil (se houver)
                if not content.strip().startswith("#EXTM3U") and current_profile != try_profiles[-1]:
                    logging.warning(f"[{sid}] Conteúdo 200 OK, mas não é EXTM3U. Tentando próximo perfil.")
                    r.close(); continue 
                    
                ttl = self._detect_manifest_ttl(content); cache_set_manifest(url, content, base_url, ttl)
                return self._send_manifest(content, base_url, sid)

            except req_exc.RequestException as e:
                logging.error(f"[{sid}|{current_profile}] Erro ao baixar manifesto {log_url}: {e}")
                if current_profile == try_profiles[-1]: # Último perfil falhou
                    session_manager.reset_session(sid)
                    time.sleep(min(2 ** retry_count, 8)) 
                    return self._handle_manifest(url, sid, profile_key, retry_count + 1) if retry_count < 4 else None
            finally:
                if r: r.close(); r = None

    def _detect_manifest_ttl(self, content):
        """Calcula o tempo de vida do cache com base nas informações do manifesto."""
        match = re.search(r"#EXT-X-TARGETDURATION:([\d\.]+)", content);
        if match: return max(2.0, float(match.group(1)) * 0.95) # TTL um pouco abaixo do TARGETDURATION
        matches = re.findall(r"#EXTINF:([\d\.]+)", content)
        if matches:
            # TTL mais conservador e baseado na média de duração dos segmentos
            avg_duration = sum(float(x) for x in matches) / len(matches)
            return max(3.0, avg_duration * 1.5)
        return MANIFEST_TTL
        
    def _send_manifest(self, content, base_url, sid):
        proxy_lines = []
        for line in content.splitlines():
            # REMOÇÃO DE EXT-X-ENDLIST para simular stream ao vivo
            if line.strip() == "#EXT-X-ENDLIST": continue 
            
            if line.startswith("#EXT-X-KEY"):
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    key_url = urllib.parse.urljoin(base_url, match.group(1))
                    proxy_key_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(key_url)}&session_id={sid}"
                    line = line.replace(match.group(1), proxy_key_url)
                proxy_lines.append(line)
            elif line.startswith("#") or not line.strip(): proxy_lines.append(line)
            else:
                full_url = urllib.parse.urljoin(base_url, line)
                proxy_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={sid}"
                proxy_lines.append(proxy_url)
                
        self.send_response(200); self.send_header("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate"); self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0"); self.end_headers(); self.wfile.write("\n".join(proxy_lines).encode("utf-8"))
        
    def _handle_key(self, url, sid, profile_key, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        r = None
        try:
            sess = session_manager.get_session(sid)
            r = self._fetch_with_redirect_handling(sess, url, (CONNECTION_TIMEOUT, STREAM_TIMEOUT), profile_key, is_stream=False, sid=sid)
            
            if r.status_code in (401, 403, 404, 429): raise req_exc.RequestException(f"Erro de cliente ao buscar chave: {r.status_code}")
            r.raise_for_status(); 
            
            resp_headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding", "content-type"]}
            resp_headers["Content-Type"] = "application/octet-stream" # OCTET-STREAM para chaves
            
            self._send_response(r.content, resp_headers)
        except Exception as e:
            logging.error(f"[{sid}|{profile_key}] Falha crítica ao buscar chave {log_url}: {e}."); session_manager.reset_session(sid)
            time.sleep(min(2 ** retry_count, 5)); return self._handle_key(url, sid, profile_key, retry_count + 1)
        finally:
            if r: r.close()
            
    def _handle_segment(self, url, sid, profile_key, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        r = None
        try:
            cached = cache_get(url)
            if cached and retry_count == 0:
                data, headers = cached
                return self._send_response(data, headers)

            sess = session_manager.get_session(sid)
            r = self._fetch_with_redirect_handling(sess, url, (CONNECTION_TIMEOUT, STREAM_TIMEOUT), profile_key, is_stream=True, sid=sid)

            if r.status_code in (401, 403, 404, 429): 
                r.close()
                raise req_exc.RequestException(f"Erro de cliente no segmento: {r.status_code}")
            
            r.raise_for_status()
            
            resp_headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding", "content-type"]}
            resp_headers["Content-Type"] = "application/octet-stream" # OCTET-STREAM para segmentos
            
            data = r.content 
            cache_set_segment(url, data, resp_headers)
            return self._send_response(data, resp_headers)
            
        except req_exc.RequestException as e:
            if r: r.close()
            if retry_count < 1:
                logging.warning(f"[{sid}|{profile_key}] Falha no segmento {log_url} (Tentativa {retry_count + 1}/1): {e}. Tentando novamente.")
                session_manager.reset_session(sid)
                time.sleep(min(1.5 ** retry_count, 1)) 
                return self._handle_segment(url, sid, profile_key, retry_count + 1)
            
            logging.error(f"[{sid}|{profile_key}] Falha no segmento {log_url} após 3 tentativas: {e}. Forçando atualização do manifesto e enviando dummy.")
            clear_manifest_cache()
            session_manager.reset_session(sid)
            return self._send_response(DUMMY_TS, {"Content-Type": "application/octet-stream"})

        except Exception as e:
            if r: r.close()
            logging.error(f"[{sid}|{profile_key}] Erro inesperado ao buscar segmento {log_url}: {e}. Forçando atualização do manifesto e enviando dummy.")
            clear_manifest_cache()
            session_manager.reset_session(sid)
            return self._send_response(DUMMY_TS, {"Content-Type": "application/octet-stream"})
            
        finally:
            if r: r.close()
            
    def _send_response(self, content, headers):
        self.send_response(200)
        for k, v in headers.items(): self.send_header(k, v)
        self.end_headers()
        try: self.wfile.write(content)
        except BrokenPipeError: pass
        
    def log_message(self, format, *args): return

# ---------------- GERENCIADOR DO PROXY ----------------
class HLSProxyManager:
    def __init__(self): self.server = None; self.thread = None; self.port = None
    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000); self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyHandler)
                self.server.daemon_threads = True; self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start(); self.port = port; xbmc.log(f"Proxy HLS Resiliente iniciado em http://{PROXY_HOST}:{port}", xbmc.LOGINFO); return True
            except OSError: continue
        xbmc.log("FALHA: Não foi possível iniciar o proxy HLS.", xbmc.LOGERROR); return False
    def stop(self):
        if self.server: xbmc.log("Parando proxy HLS...", xbmc.LOGINFO); self.server.shutdown(); self.server.server_close()

# ---------------- INTEGRAÇÃO COM O ADDON KODI ----------------
class HLSAddon:
    def __init__(self, handle): self.handle = handle; self.proxy = HLSProxyManager()
    def play_stream(self, url, stype="live"):
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro de Proxy", "Não foi possível iniciar.", xbmcgui.NOTIFICATION_ERROR); return
        sid = f"stream_{int(time.time())}"
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.port}/?url={urllib.parse.quote_plus(url)}&session_id={sid}"
        
        # O Kodi PRECISA usar o User-Agent do perfil inicial (Chrome) para o manifesto
        initial_profile_key = DEFAULT_PROFILE
        initial_headers = get_dynamic_headers(url, initial_profile_key)
        
        manifest_headers = urllib.parse.urlencode({
            'User-Agent': initial_headers.get('User-Agent'),
            'Host': initial_headers.get('Host')
        })
        
        li = xbmcgui.ListItem(path=proxy_url); li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl"); li.setContentLookup(False)
        if stype == "live":
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls"); li.setProperty("IsLive", "true")
            li.setProperty("inputstream.adaptive.manifest_headers", manifest_headers)
            li.setProperty("inputstream.adaptive.live_delay", "99"); li.setProperty("inputstream.adaptive.play_segment_stall_timeout", "60")
        xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- PONTO DE ENTRADA ----------------
def setup_logging(): logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
def main():
    setup_logging()
    if len(sys.argv) < 3: xbmc.log("Script chamado sem argumentos suficientes.", xbmc.LOGERROR); return
    handle = int(sys.argv[1]); addon = HLSAddon(handle); args = urllib.parse.parse_qs(sys.argv[2][1:])
    if args.get("action", [None])[0] == "play_stream":
        stream_url = args.get("stream_url", [None])[0]
        if stream_url: addon.play_stream(stream_url)
        else: xbmc.log("Nenhuma URL de stream fornecida.", xbmc.LOGERROR)

if __name__ == "__main__": main()