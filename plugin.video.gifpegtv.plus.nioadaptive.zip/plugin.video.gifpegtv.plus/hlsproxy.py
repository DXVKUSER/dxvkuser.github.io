#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# -----------------------------------------------------------------------------------
# Proxy HLS Local TCP/HTTP v11.1 (FIX CRASH + RETRY 3X + ROTAÇÃO)
# -----------------------------------------------------------------------------------
# CORREÇÕES DE ERRO (LOG):
# 1. Corrigido 'TypeError' em play_stream: Agora aceita (url, stream_type).
#
# OTIMIZAÇÕES:
# 1. RETRY LIMIT: 3 tentativas exatas por segmento.
# 2. FAILOVER: Falha 3x -> Roda User-Agent/IP -> Limpa URL Resolvida (Novo Token).
# 3. FAST RESPONSE: Timeouts curtos e TCP_NODELAY ativado.
# -----------------------------------------------------------------------------------

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import socket
from urllib.parse import urlparse, urljoin, quote, unquote_plus, parse_qs
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import ConnectionError, Timeout, ReadTimeout

# ---------------- MOCK KODI (PARA TESTES FORA DO KODI) ----------------
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    def kodi_log(msg, level=xbmc.LOGINFO):
        if xbmc:
            xbmc.log(f"[HLSProxy] {msg}", level=level)
except ImportError:
    class MockKodi:
        def log(self, msg, level=None):
            print(f"[MOCK] {msg}")
        LOGINFO = 1
        LOGDEBUG = 0
        LOGWARNING = 2
        LOGERROR = 3
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    def kodi_log(msg, level=xbmc.LOGINFO):
        print(f"[HLSProxy] {msg}")

# ---------------- CONFIGURAÇÕES ----------------
MAX_SEGMENT_RETRIES = 3             # Limite estrito de 3 tentativas
CONNECTION_TIMEOUT = 3.0            # Timeout de conexão rápido (Fail-fast)
READ_TIMEOUT = 8.0                  # Timeout de leitura
SESSION_TIMEOUT_SECONDS = 120
MAX_ACTIVE_SESSIONS = 50
DEFAULT_CHUNK_SIZE = 128 * 1024     # 128KB - Equilíbrio entre CPU e Rede
PROXY_HOST = '0.0.0.0'
HTTP_PORT = 8010
LOG_FILE = "hls_proxy_v11.log"
MANIFEST_CACHE_TTL = 4              # Cache curto para manter stream ao vivo

USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.{version} Safari/537.36"
NULL_TS_PACKET = b'\x47\x1f\xff\x10' + (b'\xff' * 184)

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- ESTADO GLOBAL ----------------
MANIFEST_CACHE = {}
SESSION_STORE = {}
STATE_LOCK = threading.Lock()
PROXY_SERVER_INSTANCE = None
PROXY_SERVER_PORT = 0

# ---------------- UTILS ----------------
def _generate_fake_ip():
    """Gera um IP aleatório evitando faixas locais."""
    while True:
        octets = [random.randint(1, 254) for _ in range(4)]
        if (octets[0] == 10 or (octets[0] == 192 and octets[1] == 168) or
            (octets[0] == 172 and 16 <= octets[1] <= 31) or octets[0] == 127 or
            octets[0] >= 224):
            continue
        return ".".join(map(str, octets))

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

HOST_NAME_FOR_URLS = get_local_ip()

def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    try:
        # Limpa handlers anteriores para evitar duplicidade
        if logger.hasHandlers(): logger.handlers.clear()
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler = logging.FileHandler(LOG_FILE, mode='w', encoding='utf-8')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception: pass
    logging.getLogger('urllib3').setLevel(logging.ERROR)
    logging.getLogger('requests').setLevel(logging.ERROR)

# ---------------- GERENCIAMENTO DE SESSÃO ----------------
class SessionManager:
    def __init__(self):
        self._cleanup_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self._cleanup_thread.start()

    def _generate_ua(self):
        return USER_AGENT_TEMPLATE.format(version=random.randint(1000, 9999))

    def _create_session(self, session_id, original_url, origin_host):
        sess = requests.Session()
        # Adapter otimizado para reutilização de conexões
        adapter = HTTPAdapter(
            pool_connections=20,
            pool_maxsize=40,
            max_retries=Retry(total=1, backoff_factor=0.1)
        )
        sess.mount('http://', adapter)
        sess.mount('https://', adapter)
        
        SESSION_STORE[session_id] = {
            'session': sess,
            'original_url': original_url,
            'resolved_url': None,   # URL com token
            'origin_host': origin_host,
            'user_agent': self._generate_ua(),
            'fake_ip': _generate_fake_ip(),
            'last_activity': time.time()
        }
        kodi_log(f"Sessão Criada: {session_id}", xbmc.LOGDEBUG)

    def get_session(self, session_id, original_url=None, origin_host=None):
        with STATE_LOCK:
            if session_id not in SESSION_STORE:
                if not original_url: raise Exception("Sessão inexistente")
                if len(SESSION_STORE) >= MAX_ACTIVE_SESSIONS:
                    # Remove a mais antiga se cheio
                    oldest = min(SESSION_STORE.keys(), key=lambda k: SESSION_STORE[k]['last_activity'])
                    del SESSION_STORE[oldest]
                self._create_session(session_id, original_url, origin_host)
            
            SESSION_STORE[session_id]['last_activity'] = time.time()
            return SESSION_STORE[session_id]

    def update_resolved_url(self, session_id, url):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                SESSION_STORE[session_id]['resolved_url'] = url

    def clear_resolved_url(self, session_id):
        """Força o reset para URL original (busca novo token)."""
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                SESSION_STORE[session_id]['resolved_url'] = None
                kodi_log(f"♻️ URL Limpa -> Resetando para Original.", xbmc.LOGWARNING)
            if session_id in MANIFEST_CACHE:
                del MANIFEST_CACHE[session_id]

    def rotate_identity(self, session_id):
        """Rotaciona UA e IP e limpa cookies."""
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                s = SESSION_STORE[session_id]
                old_ip = s['fake_ip']
                s['fake_ip'] = _generate_fake_ip()
                s['user_agent'] = self._generate_ua()
                s['session'].cookies.clear() # Limpa cookies antigos
                kodi_log(f"🔄 Rotação de Identidade: {old_ip} -> {s['fake_ip']}", xbmc.LOGINFO)

    def _cleanup_loop(self):
        while True:
            time.sleep(60)
            with STATE_LOCK:
                now = time.time()
                to_remove = [sid for sid, data in SESSION_STORE.items() 
                             if now - data['last_activity'] > SESSION_TIMEOUT_SECONDS]
                for sid in to_remove:
                    try: SESSION_STORE[sid]['session'].close()
                    except: pass
                    del SESSION_STORE[sid]
                    if sid in MANIFEST_CACHE: del MANIFEST_CACHE[sid]

session_manager = SessionManager()

# ---------------- SERVIDOR HTTP & PROXY ----------------
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class ProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args): return # Silencia logs padrão do HTTP

    def do_GET(self):
        # Otimização TCP para resposta mais rápida
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except: pass

        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        try:
            if path.startswith('/play/') and path.endswith('.m3u8'):
                self.handle_manifest(path)
            elif path == '/stream':
                self.handle_segment(query)
            elif path == '/alive':
                self.send_response(200); self.end_headers()
            else:
                self.send_error(404)
        except (BrokenPipeError, ConnectionResetError):
            pass # Cliente desconectou, normal
        except Exception as e:
            kodi_log(f"Erro Handler: {e}", xbmc.LOGERROR)
            try: self.send_error(500)
            except: pass

    def get_headers(self, s_data, referer=None):
        return {
            'User-Agent': s_data['user_agent'],
            'X-Forwarded-For': s_data['fake_ip'],
            'X-Real-IP': s_data['fake_ip'],
            'Referer': referer if referer else f"http://{s_data['origin_host']}/",
            'Origin': f"http://{s_data['origin_host']}",
            'Connection': 'keep-alive',
            'Accept': '*/*'
        }

    def handle_manifest(self, path):
        try:
            sid = path.split('/')[2]
            s_data = session_manager.get_session(sid)
        except:
            self.send_error(400)
            return

        # Verifica cache de manifesto (para reduzir requests ao servidor)
        now = time.time()
        if sid in MANIFEST_CACHE and (now - MANIFEST_CACHE[sid]['ts'] < MANIFEST_CACHE_TTL):
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            self.wfile.write(MANIFEST_CACHE[sid]['data'])
            return

        # Lógica de URL: Tenta a Resolvida (com token), se falhar, vai na Original
        target_url = s_data['resolved_url'] if s_data['resolved_url'] else s_data['original_url']
        content, final_url = self._request_url(s_data, target_url)

        # Se falhou usando a URL resolvida, tenta a original imediatamente
        if not content and s_data['resolved_url']:
            kodi_log("Falha na URL resolvida, tentando original...", xbmc.LOGWARNING)
            session_manager.clear_resolved_url(sid)
            content, final_url = self._request_url(s_data, s_data['original_url'])

        if not content:
            kodi_log("Falha total no manifesto", xbmc.LOGERROR)
            self.send_error(503)
            return

        # Se obtivemos sucesso na original e ela redirecionou (tem token), salva.
        if final_url and final_url != s_data['original_url']:
            session_manager.update_resolved_url(sid, final_url)

        # Reescreve o m3u8
        new_lines = []
        base_url = final_url # Base para caminhos relativos
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                new_lines.append(line)
            else:
                abs_url = urljoin(base_url, line)
                enc_url = quote(abs_url, safe='')
                # Aponta para o proxy
                new_lines.append(f"http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}/stream?url={enc_url}&sid={sid}")

        final_data = "\n".join(new_lines).encode('utf-8')
        MANIFEST_CACHE[sid] = {'data': final_data, 'ts': now}
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.end_headers()
        self.wfile.write(final_data)

    def _request_url(self, s_data, url):
        try:
            h = self.get_headers(s_data)
            r = s_data['session'].get(url, headers=h, timeout=CONNECTION_TIMEOUT, verify=False)
            if r.status_code == 200:
                return r.text, r.url
        except: pass
        return None, None

    def handle_segment(self, query):
        url_enc = query.get('url', [None])[0]
        sid = query.get('sid', [None])[0]
        if not url_enc or not sid: return

        try: target_url = unquote_plus(url_enc)
        except: return

        # Prepara resposta para o Player
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.end_headers()

        s_data = session_manager.get_session(sid)
        success = False

        # --- LÓGICA DE RETRY (3 VEZES) ---
        for i in range(MAX_SEGMENT_RETRIES):
            try:
                # Referer é o host do próprio segmento
                host = urlparse(target_url).netloc
                h = self.get_headers(s_data, f"http://{host}/")
                
                with s_data['session'].get(target_url, headers=h, stream=True, 
                                           timeout=(CONNECTION_TIMEOUT, READ_TIMEOUT), verify=False) as r:
                    if r.status_code == 200:
                        for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            if chunk: self.wfile.write(chunk)
                        success = True
                        break # Sucesso! Sai do loop.
                    elif r.status_code in [403, 401]:
                        kodi_log(f"Erro 403/401 na tentativa {i+1}", xbmc.LOGWARNING)
                        # Não sai do loop, tenta novamente (talvez cookie/sessão)
            except Exception as e:
                # Erro de conexão, tenta novamente
                pass

        # --- FALHA NAS 3 TENTATIVAS -> AÇÃO CORRETIVA ---
        if not success:
            kodi_log(f"❌ Falha Definitiva (3 tentativas). Rotacionando e Resetando.", xbmc.LOGERROR)
            
            # 1. Rotaciona User Agent e IP
            session_manager.rotate_identity(sid)
            
            # 2. Reseta para URL Original (Próximo manifesto buscará novo token)
            session_manager.clear_resolved_url(sid)
            
            # 3. Envia pacotes nulos para não travar o player abruptamente
            try: self.wfile.write(NULL_TS_PACKET * 50)
            except: pass

# ---------------- CONTROLADOR DO SERVIDOR ----------------
class ProxyController:
    def __init__(self):
        self.lock = threading.Lock()

    def start(self):
        global PROXY_SERVER_INSTANCE, PROXY_SERVER_PORT
        with self.lock:
            if PROXY_SERVER_INSTANCE: return True
            
            # Tenta portas aleatórias se a padrão falhar
            ports = [HTTP_PORT] + [random.randint(20000, 30000) for _ in range(5)]
            for port in ports:
                try:
                    server = ThreadedHTTPServer((PROXY_HOST, port), ProxyHandler)
                    PROXY_SERVER_INSTANCE = server
                    PROXY_SERVER_PORT = port
                    threading.Thread(target=server.serve_forever, daemon=True).start()
                    kodi_log(f"Proxy Iniciado na porta {port}", xbmc.LOGINFO)
                    return True
                except OSError: continue
            
            kodi_log("Falha ao iniciar servidor: Sem portas livres", xbmc.LOGERROR)
            return False

    def stop(self):
        global PROXY_SERVER_INSTANCE
        with self.lock:
            if PROXY_SERVER_INSTANCE:
                PROXY_SERVER_INSTANCE.shutdown()
                PROXY_SERVER_INSTANCE.server_close()
                PROXY_SERVER_INSTANCE = None

_controller = ProxyController()

# ---------------- INTERFACE DO ADDON ----------------
class HLSAddon:
    def __init__(self, handle=None):
        self.handle = handle

    def get_proxy_url(self, target_url):
        if not _controller.start(): return target_url
        
        # Cria ID único baseado na URL
        sid = str(abs(hash(target_url)))
        try:
            host = urlparse(target_url).netloc
            session_manager.get_session(sid, target_url, host)
            return f"http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}/play/{sid}/index.m3u8"
        except Exception as e:
            kodi_log(f"Erro ao gerar URL proxy: {e}", xbmc.LOGERROR)
            return target_url

    # --- CORREÇÃO DO ERRO AQUI ---
    # Adicionado argumento 'stream_type=None' para casar com a chamada do addon.py
    def play_stream(self, url, stream_type=None):
        """Inicia a reprodução via Proxy."""
        if not xbmcgui: return
        
        kodi_log(f"Iniciando Playback Seguro. Tipo: {stream_type}", xbmc.LOGINFO)
        proxy_url = self.get_proxy_url(url)
        
        li = xbmcgui.ListItem(path=proxy_url)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        li.setProperty('IsLive', 'true')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.live_delay', '99')
        
        if self.handle:
            xbmcplugin.setResolvedUrl(int(self.handle), True, li)
        else:
            xbmc.Player().play(proxy_url, li)

# ---------------- MAIN ----------------
if __name__ == '__main__':
    setup_logging()
    _controller.start()
    try:
        print(f"HLS PROXY v11.1 RODANDO EM http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}")
        while True: time.sleep(1)
    except KeyboardInterrupt:
        _controller.stop()