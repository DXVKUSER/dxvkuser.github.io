import asyncio
import urllib.request
import urllib.parse
import urllib.error
import socket
import time
import random
import threading
import struct
from collections import deque
from concurrent.futures import ThreadPoolExecutor

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES MPEG-TS
# ─────────────────────────────────────────────────────────────────────────────
TS_PACKET_SIZE  = 188
TS_SYNC_BYTE    = 0x47

_NULL_HDR       = bytes([0x47, 0x1F, 0xFF, 0x10])
TS_NULL_PACKET  = _NULL_HDR + b'\xFF' * 184

NULL_PUMP_BURST    = TS_NULL_PACKET * 96
NULL_PUMP_INTERVAL = 0.065

MIN_VALID_PACKETS = 7

SYNC_WINDOW_SIZE            = 100
MAX_SYNC_ATTEMPTS_PER_CYCLE = 5

HOST = "127.0.0.1"
PORT = 8010

_PORT_CANDIDATES = list(range(8080, 8100))

STALL_TIMEOUT = 3.0

MIN_OUTPUT_BUFFER = 1
MAX_OUTPUT_BUFFER = 2

TAIL_BUFFER_PACKETS = 64

_IDR_SIGNATURES = (
    b'\x00\x00\x01\x65',
    b'\x00\x00\x01\x26',
    b'\x00\x00\x01\x00',
    b'\x00\x00\x01\x67',
    b'\x00\x00\x01\x68',
    b'\x00\x00\x01\x6E',
    b'\x00\x00\x01\x42',
    b'\x00\x00\x01\x44',
)

PTS_STALL_THRESHOLD = 90_000

CHUNK_INITIAL = 65_536
CHUNK_MIN     = 16_384
CHUNK_MAX     = 131_072

_PID_WHITELIST_STATIC = {0x0000, 0x0001, 0x0011, 0x0012, 0x1FFF}

_EXECUTOR = ThreadPoolExecutor(max_workers=32)

MAX_QUEUE_SIZE    = 128
MAX_BUFFER_BYTES  = 4 * 1024 * 1024
SEND_TIMEOUT      = 3.0

STATS_INTERVAL = 5.0

DRAIN_INTERVAL_PACKETS = 8

_active_session_task = None
_active_session_lock = threading.Lock()


def _get_session_lock():
    global _active_session_lock
    return _active_session_lock


# ─────────────────────────────────────────────────────────────────────────────
#  Helper: aguarda uma task sem propagar NENHUMA exceção
#  CORRIGIDO para Python 3.11+: verifica .cancelled() antes de .exception()
#  Em Python 3.11+, chamar .exception() em task cancelada levanta CancelledError
# ─────────────────────────────────────────────────────────────────────────────
async def _wait_task_safe(task, timeout=None):
    """Aguarda uma task capturando TODAS as exceções, incluindo CancelledError.
    Usa asyncio.wait() para evitar o bug do shield+wait_for no Python 3.11."""
    if task is None:
        return
    if task.done():
        # CORRIGIDO: verifica .cancelled() antes de chamar .exception()
        if task.cancelled():
            return
        try:
            task.exception()
        except (asyncio.CancelledError, Exception):
            pass
        return
    try:
        if timeout is not None:
            done, pending = await asyncio.wait({task}, timeout=timeout)
            # Consome exceção da task se completou
            for t in done:
                # CORRIGIDO: verifica .cancelled() antes de chamar .exception()
                if t.cancelled():
                    continue
                try:
                    t.exception()
                except (asyncio.CancelledError, Exception):
                    pass
        else:
            done, _ = await asyncio.wait({task})
            for t in done:
                # CORRIGIDO: verifica .cancelled() antes de chamar .exception()
                if t.cancelled():
                    continue
                try:
                    t.exception()
                except (asyncio.CancelledError, Exception):
                    pass
    except asyncio.CancelledError:
        pass
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  ConnectionGuard — impede writes em socket morto
# ─────────────────────────────────────────────────────────────────────────────
class ConnectionGuard:
    def __init__(self):
        self._alive = True
        self._lock  = threading.Lock()

    def mark_dead(self):
        with self._lock:
            self._alive = False

    @property
    def alive(self):
        with self._lock:
            return self._alive


# ─────────────────────────────────────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]


def _pick_ua():
    return random.choice(_USER_AGENTS)


# ─────────────────────────────────────────────────────────────────────────────
#  Telemetria
# ─────────────────────────────────────────────────────────────────────────────
class SessionStats:
    def __init__(self):
        self._rx_total    = 0
        self._tx_total    = 0
        self._rx_last     = 0
        self._tx_last     = 0
        self._last_report = time.monotonic()
        self._last_rx_ts  = time.monotonic()
        self._last_tx_ts  = time.monotonic()
        self._buf_size    = 0
        self._queue_size  = 0

    def on_rx(self, n):
        self._rx_total  += n
        self._last_rx_ts = time.monotonic()

    def on_tx(self, n):
        self._tx_total  += n
        self._last_tx_ts = time.monotonic()

    def update_buffer(self, n):
        self._buf_size = n

    def update_queue(self, n):
        self._queue_size = n

    def maybe_log(self):
        now = time.monotonic()
        elapsed = now - self._last_report
        if elapsed < STATS_INTERVAL:
            return
        rx_delta = self._rx_total - self._rx_last
        tx_delta = self._tx_total - self._tx_last
        rx_speed = rx_delta / elapsed if elapsed > 0 else 0.0
        tx_speed = tx_delta / elapsed if elapsed > 0 else 0.0
        idle_rx = now - self._last_rx_ts
        idle_tx = now - self._last_tx_ts
        try:
            n_threads = threading.active_count()
        except Exception:
            n_threads = -1
        print(
            "[NexusCore Stats] "
            "RX={}KB "
            "TX={}KB "
            "RXspd={:.1f}KB/s "
            "TXspd={:.1f}KB/s "
            "Buffer={}KB "
            "Queue={} "
            "Threads={} "
            "IdleRX={:.1f}s "
            "IdleTX={:.1f}s".format(
                self._rx_total // 1024,
                self._tx_total // 1024,
                rx_speed / 1024,
                tx_speed / 1024,
                self._buf_size // 1024,
                self._queue_size,
                n_threads,
                idle_rx,
                idle_tx,
            )
        )
        self._rx_last    = self._rx_total
        self._tx_last    = self._tx_total
        self._last_report = now


def _drain_queue(q):
    drained = 0
    while True:
        try:
            q.get_nowait()
            drained += 1
        except Exception:
            break
    return drained


def _close_socket_safe(sock):
    if sock is None:
        return
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass
    try:
        sock.close()
    except OSError:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  PAT/PMT Cache — reinjeta tabelas na reconexão
# ─────────────────────────────────────────────────────────────────────────────
class PatPmtCache:
    def __init__(self):
        self._pat_packets = bytearray()
        self._pmt_packets = bytearray()
        self._pmt_pids    = set()

    def reset_cache(self):
        self._pat_packets = bytearray()
        self._pmt_packets = bytearray()

    def feed(self, data):
        n = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        for i in range(n):
            off = i * TS_PACKET_SIZE
            pkt = mv[off: off + TS_PACKET_SIZE]
            if pkt[0] != TS_SYNC_BYTE:
                continue
            pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
            if pid == 0x0000:
                self._pat_packets = bytearray(pkt)
            elif pid in self._pmt_pids and pid != 0x1FFF:
                self._pmt_packets = bytearray(pkt)

    def set_pmt_pids(self, pids):
        self._pmt_pids = pids

    def get_injection_data(self):
        result = bytearray()
        if self._pat_packets:
            result.extend(self._pat_packets)
        if self._pmt_packets:
            result.extend(self._pmt_packets)
        return bytes(result)

    @property
    def has_cache(self):
        return bool(self._pat_packets) or bool(self._pmt_packets)


# ─────────────────────────────────────────────────────────────────────────────
#  PID Filter
# ─────────────────────────────────────────────────────────────────────────────
class PidFilter:
    def __init__(self):
        self._allowed = set(_PID_WHITELIST_STATIC)
        self._pmt_pids = set()
        self._learned = False
        self._pmt_buf = {}

    def reset(self):
        self._allowed  = set(_PID_WHITELIST_STATIC)
        self._pmt_pids = set()
        self._learned  = False
        self._pmt_buf  = {}

    @property
    def pmt_pids(self):
        return self._pmt_pids

    def _parse_pat(self, payload):
        if len(payload) < 8:
            return
        sec_len = ((payload[1] & 0x0F) << 8) | payload[2]
        end = min(3 + sec_len - 4, len(payload))
        i = 8
        while i + 4 <= end:
            prog = (payload[i] << 8) | payload[i + 1]
            pid  = ((payload[i + 2] & 0x1F) << 8) | payload[i + 3]
            if prog != 0:
                self._pmt_pids.add(pid)
                self._allowed.add(pid)
            i += 4

    def _parse_pmt(self, pid, payload):
        if len(payload) < 12:
            return
        sec_len  = ((payload[1] & 0x0F) << 8) | payload[2]
        prog_info_len = ((payload[10] & 0x0F) << 8) | payload[11]
        i = 12 + prog_info_len
        end = min(3 + sec_len - 4, len(payload))
        while i + 5 <= end:
            epid = ((payload[i + 1] & 0x1F) << 8) | payload[i + 2]
            es_info_len = ((payload[i + 3] & 0x0F) << 8) | payload[i + 4]
            self._allowed.add(epid)
            i += 5 + es_info_len
        self._learned = True

    def _accumulate_section(self, pid, pkt):
        pusi = (pkt[1] & 0x40) != 0
        afc  = (pkt[3] & 0x30) >> 4
        hdr  = 4
        if afc in (2, 3):
            hdr += 1 + pkt[4]
        if hdr >= TS_PACKET_SIZE:
            return None
        payload_data = bytes(pkt[hdr:])
        if pusi:
            ptr = payload_data[0]
            self._pmt_buf[pid] = bytearray(payload_data[1 + ptr:])
        else:
            if pid not in self._pmt_buf:
                return None
            self._pmt_buf[pid].extend(payload_data)
        if pid not in self._pmt_buf or len(self._pmt_buf[pid]) < 3:
            return None
        buf = self._pmt_buf[pid]
        sec_len = ((buf[1] & 0x0F) << 8) | buf[2]
        total   = 3 + sec_len
        if len(buf) >= total:
            result = bytes(buf[:total])
            del self._pmt_buf[pid]
            return result
        return None

    def filter(self, data):
        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        out = bytearray()
        for i in range(n):
            off = i * TS_PACKET_SIZE
            pkt = mv[off: off + TS_PACKET_SIZE]
            if pkt[0] != TS_SYNC_BYTE:
                out.extend(pkt)
                continue
            pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
            if pid == 0x0000:
                sec = self._accumulate_section(pid, pkt)
                if sec:
                    self._parse_pat(sec)
                out.extend(pkt)
                continue
            if pid in self._pmt_pids:
                sec = self._accumulate_section(pid, pkt)
                if sec:
                    self._parse_pmt(pid, sec)
                out.extend(pkt)
                continue
            if pid in self._allowed:
                out.extend(pkt)
                continue
            if self._learned:
                out.extend(TS_NULL_PACKET)
            else:
                out.extend(pkt)
        return out


# ─────────────────────────────────────────────────────────────────────────────
#  Tail Buffer
# ─────────────────────────────────────────────────────────────────────────────
class TailBuffer:
    def __init__(self, capacity=TAIL_BUFFER_PACKETS):
        self._capacity = capacity
        self._buf = bytearray()

    def push(self, data):
        self._buf.extend(data)
        max_size = self._capacity * TS_PACKET_SIZE
        if len(self._buf) > max_size:
            del self._buf[: len(self._buf) - max_size]

    def find_stitch(self, new_data):
        if not self._buf or len(new_data) < TS_PACKET_SIZE:
            return 0
        fp_size = min(4 * TS_PACKET_SIZE, len(self._buf))
        fingerprint = bytes(self._buf[-fp_size:])
        idx = new_data.find(fingerprint)
        if idx != -1:
            skip = idx + fp_size
            skip = skip - (skip % TS_PACKET_SIZE)
            return min(skip, len(new_data))
        return 0

    def clear(self):
        self._buf.clear()


# ─────────────────────────────────────────────────────────────────────────────
#  PCR Restamping com timestamp base
# ─────────────────────────────────────────────────────────────────────────────
class PcrRestamper:
    def __init__(self):
        self._last_pcr      = None
        self._offset        = 0
        self._active        = False
        self._first_session = True
        self._base_pcr      = None

    def reset(self, last_pcr):
        self._last_pcr      = last_pcr
        self._offset        = 0
        self._active        = last_pcr is not None
        self._first_session = False

    def _read_pcr(self, pkt, off):
        if pkt[off + 3] & 0x20 == 0:
            return None
        af_len = pkt[off + 4]
        if af_len < 6:
            return None
        flags = pkt[off + 5]
        if not (flags & 0x10):
            return None
        b = pkt[off + 6: off + 11]
        pcr_base = (b[0] << 25) | (b[1] << 17) | (b[2] << 9) | (b[3] << 1) | (b[4] >> 7)
        return pcr_base

    def _write_pcr(self, pkt, off, pcr_base):
        pcr_base &= 0x1_FFFF_FFFF
        ext = 0
        pkt[off + 6]  = (pcr_base >> 25) & 0xFF
        pkt[off + 7]  = (pcr_base >> 17) & 0xFF
        pkt[off + 8]  = (pcr_base >>  9) & 0xFF
        pkt[off + 9]  = (pcr_base >>  1) & 0xFF
        pkt[off + 10] = ((pcr_base & 0x01) << 7) | 0x7E | ((ext >> 8) & 0x01)
        pkt[off + 11] = ext & 0xFF

    def stamp(self, data):
        if self._first_session and not self._active:
            n  = len(data) // TS_PACKET_SIZE
            mv = memoryview(data)
            for i in range(n):
                off = i * TS_PACKET_SIZE
                pcr = self._read_pcr(mv, off)
                if pcr is not None:
                    if self._base_pcr is None:
                        self._base_pcr = pcr
                    out = bytearray(data)
                    for j in range(n):
                        off_j = j * TS_PACKET_SIZE
                        pcr_j = self._read_pcr(mv, off_j)
                        if pcr_j is not None:
                            new_pcr = (pcr_j - self._base_pcr) & 0x1_FFFF_FFFF
                            self._write_pcr(out, off_j, new_pcr)
                            self._last_pcr = new_pcr
                    return bytes(out)
            for i in range(n - 1, -1, -1):
                off = i * TS_PACKET_SIZE
                pcr = self._read_pcr(mv, off)
                if pcr is not None:
                    self._last_pcr = pcr
                    break
            return data

        if not self._active:
            n  = len(data) // TS_PACKET_SIZE
            mv = memoryview(data)
            for i in range(n - 1, -1, -1):
                off = i * TS_PACKET_SIZE
                pcr = self._read_pcr(mv, off)
                if pcr is not None:
                    self._last_pcr = pcr
                    break
            return data

        n   = len(data) // TS_PACKET_SIZE
        out = bytearray(data)
        mv  = memoryview(data)
        first_new_pcr = None

        for i in range(n):
            off = i * TS_PACKET_SIZE
            pcr = self._read_pcr(mv, off)
            if pcr is None:
                continue
            if first_new_pcr is None:
                first_new_pcr = pcr
                if self._last_pcr is not None:
                    self._offset = (self._last_pcr - pcr + 3 * 3003) & 0x1_FFFF_FFFF
            new_pcr = (pcr + self._offset) & 0x1_FFFF_FFFF
            self._write_pcr(out, off, new_pcr)
            self._last_pcr = new_pcr

        return out

    @property
    def last_pcr(self):
        return self._last_pcr


# ─────────────────────────────────────────────────────────────────────────────
#  PTS Monitor
# ─────────────────────────────────────────────────────────────────────────────
class PtsMonitor:
    def __init__(self):
        self._last_pts  = None
        self._last_time = 0.0
        self._video_pid = None

    def reset(self):
        self._last_pts  = None
        self._last_time = 0.0

    def set_video_pid(self, pid):
        self._video_pid = pid

    def _extract_pts(self, pkt, off):
        afc     = (pkt[off + 3] & 0x30) >> 4
        hdr_end = 4
        if afc in (2, 3):
            hdr_end += 1 + pkt[off + 4]
        if hdr_end + 9 >= TS_PACKET_SIZE:
            return None
        if (pkt[off + hdr_end]     != 0x00 or
            pkt[off + hdr_end + 1] != 0x00 or
            pkt[off + hdr_end + 2] != 0x01):
            return None
        pts_dts_flags = pkt[off + hdr_end + 7] >> 6
        if pts_dts_flags == 0:
            return None
        p = off + hdr_end + 9
        if p + 5 > TS_PACKET_SIZE:
            return None
        pts = (
            ((pkt[p]     & 0x0E) << 29) |
            ((pkt[p + 1]       ) << 22) |
            ((pkt[p + 2] & 0xFE) << 14) |
            ((pkt[p + 3]       ) <<  7) |
            ((pkt[p + 4] & 0xFE) >>  1)
        )
        return pts

    def feed(self, data):
        if self._video_pid is None:
            return True
        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        now = time.monotonic()
        for i in range(n):
            off = i * TS_PACKET_SIZE
            if mv[off] != TS_SYNC_BYTE:
                continue
            pid = ((mv[off + 1] & 0x1F) << 8) | mv[off + 2]
            if pid != self._video_pid:
                continue
            pusi = (mv[off + 1] & 0x40) != 0
            if not pusi:
                continue
            pts = self._extract_pts(mv, off)
            if pts is None:
                continue
            if self._last_pts is None:
                self._last_pts  = pts
                self._last_time = now
                return True
            delta = (pts - self._last_pts) & 0x1_FFFF_FFFF
            if delta > PTS_STALL_THRESHOLD:
                self._last_pts  = pts
                self._last_time = now
            elif now - self._last_time > STALL_TIMEOUT:
                return False
        return True


# ─────────────────────────────────────────────────────────────────────────────
#  CC Rewriter
# ─────────────────────────────────────────────────────────────────────────────
class CcRewriter:
    def __init__(self):
        self._cc_out = {}
        self._active = False

    def reset(self, cc_snapshot):
        self._cc_out = dict(cc_snapshot)
        self._active = True

    def rewrite(self, data):
        if not self._active:
            return data
        n   = len(data) // TS_PACKET_SIZE
        out = bytearray(data)
        for i in range(n):
            off = i * TS_PACKET_SIZE
            if out[off] != TS_SYNC_BYTE:
                continue
            pid = ((out[off + 1] & 0x1F) << 8) | out[off + 2]
            if pid == 0x1FFF:
                continue
            afc         = (out[off + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            if not has_payload:
                continue
            next_cc = (self._cc_out.get(pid, 15) + 1) & 0x0F
            self._cc_out[pid] = next_cc
            out[off + 3] = (out[off + 3] & 0xF0) | next_cc
        return out


# ─────────────────────────────────────────────────────────────────────────────
#  TsBuffer
# ─────────────────────────────────────────────────────────────────────────────
class TsBuffer:
    def __init__(self):
        self._buf           = bytearray()
        self._aligned       = False
        self._held          = bytearray()
        self._held_count    = 0
        self._cc_map        = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count   = 0
        self._total_packets = 0
        self.video_pid      = None

    def reset(self):
        self._buf.clear()
        self._aligned       = False
        self._held.clear()
        self._held_count    = 0
        self._cc_map.clear()
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count   = 0
        self._total_packets = 0

    @property
    def cc_snapshot(self):
        return dict(self._cc_map)

    def _find_sync(self, data):
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                return -1
            self._sync_attempts += 1
            if idx + TS_PACKET_SIZE * SYNC_WINDOW_SIZE <= length:
                valid = all(
                    data[idx + TS_PACKET_SIZE * k] == TS_SYNC_BYTE
                    for k in range(1, SYNC_WINDOW_SIZE)
                )
                if valid:
                    self._last_sync_idx = idx
                    return idx
            elif idx + TS_PACKET_SIZE <= length:
                if data[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE:
                    self._last_sync_idx = idx
                    return idx
            idx += 1
        return -1

    def _validate_continuity(self, data):
        if not data:
            return data
        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        valid_packets = []
        severe_errors = 0
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            if mv[offset] != TS_SYNC_BYTE:
                self._error_count += 1
                if self._error_count > 3:
                    self._aligned = False
                    return data[:offset]
                continue
            pid = ((mv[offset + 1] & 0x1F) << 8) | mv[offset + 2]
            if pid == 0x1FFF:
                valid_packets.append(i)
                continue
            cc          = mv[offset + 3] & 0x0F
            afc         = (mv[offset + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            if pid in self._cc_map and has_payload:
                expected_cc = (self._cc_map[pid] + 1) & 0x0F
                if cc == expected_cc:
                    self._cc_map[pid] = cc
                    valid_packets.append(i)
                elif cc == self._cc_map[pid]:
                    self._error_count += 1
                    continue
                else:
                    self._cc_map[pid] = cc
                    valid_packets.append(i)
                    self._error_count += 1
                    if self._error_count > 10:
                        severe_errors += 1
            else:
                self._cc_map[pid] = cc
                valid_packets.append(i)
        if severe_errors > 5:
            self._aligned = False
            return data[:valid_packets[0] * TS_PACKET_SIZE] if valid_packets else bytearray()
        if len(valid_packets) == n:
            return data
        result = bytearray()
        for idx in valid_packets:
            start = idx * TS_PACKET_SIZE
            result.extend(data[start:start + TS_PACKET_SIZE])
        return result

    def feed(self, raw):
        if raw:
            self._buf.extend(raw)
            if len(self._buf) > MAX_BUFFER_BYTES:
                excess = len(self._buf) - MAX_BUFFER_BYTES
                discard = excess + (TS_PACKET_SIZE - excess % TS_PACKET_SIZE) % TS_PACKET_SIZE
                del self._buf[:discard]
                print("[TsBuffer] Backpressure: descartado {} pkts antigos".format(discard // TS_PACKET_SIZE))
        if not self._aligned:
            self._sync_attempts = 0
            idx = self._find_sync(self._buf)
            if idx == -1:
                if len(self._buf) > TS_PACKET_SIZE * 100:
                    self._buf.clear()
                return b''
            if idx > 0:
                del self._buf[:idx]
            self._aligned = True
        buf_len = len(self._buf)
        usable  = buf_len - (buf_len % TS_PACKET_SIZE)
        if usable == 0:
            return b''
        payload = self._buf[:usable]
        del self._buf[:usable]
        payload = self._validate_continuity(payload)
        if not payload:
            return b''
        self._total_packets += len(payload) // TS_PACKET_SIZE
        if self._held_count < MIN_VALID_PACKETS:
            pkts = len(payload) // TS_PACKET_SIZE
            self._held.extend(payload)
            self._held_count += pkts
            if self._held_count >= MIN_VALID_PACKETS:
                out = bytes(self._held)
                self._held.clear()
                return out
            return b''
        return bytes(payload)


# ─────────────────────────────────────────────────────────────────────────────
#  IDR Gate com SPS/PPS/VPS
# ─────────────────────────────────────────────────────────────────────────────
class IdrGate:
    def __init__(self):
        self._open   = False
        self._active = False

    def arm(self):
        self._open   = False
        self._active = True

    def disarm(self):
        self._open   = True
        self._active = False

    @property
    def is_open(self):
        return self._open

    def _has_sig(self, data):
        for sig in _IDR_SIGNATURES:
            if sig in data:
                return True
        return False

    def filter(self, data):
        if not self._active or self._open:
            return data
        if not self._has_sig(data):
            return b''
        self._open = True
        n  = len(data) // TS_PACKET_SIZE
        mv = memoryview(data)
        for i in range(n):
            off = i * TS_PACKET_SIZE
            chunk = bytes(mv[off: off + TS_PACKET_SIZE])
            if self._has_sig(chunk):
                return data[off:]
        return data


# ─────────────────────────────────────────────────────────────────────────────
#  Keepalive — usa asyncio.sleep() simples, com proteção total
# ─────────────────────────────────────────────────────────────────────────────
async def _keepalive_task(writer, stop_event, slow_event, guard, owning_loop):
    """Keepalive que NUNCA propaga exceções"""
    while True:
        try:
            if stop_event.is_set():
                return

            try:
                current_loop = asyncio.get_running_loop()
                if current_loop is not owning_loop:
                    return
            except RuntimeError:
                return

            await asyncio.sleep(NULL_PUMP_INTERVAL)

            if stop_event.is_set() or not guard.alive:
                return

            if slow_event.is_set():
                if not guard.alive:
                    return

                try:
                    if writer.is_closing():
                        guard.mark_dead()
                        stop_event.set()
                        return
                except Exception:
                    guard.mark_dead()
                    stop_event.set()
                    return

                try:
                    writer.write(NULL_PUMP_BURST)
                    await writer.drain()
                except Exception:
                    guard.mark_dead()
                    stop_event.set()
                    return
        except asyncio.CancelledError:
            return
        except Exception:
            return


# ─────────────────────────────────────────────────────────────────────────────
#  Redirect Handler
# ─────────────────────────────────────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


# ─────────────────────────────────────────────────────────────────────────────
#  Session Manager
# ─────────────────────────────────────────────────────────────────────────────
class SessionManager:
    def __init__(self):
        self._opener     = None
        self._last_clean = 0.0

    def get_session(self):
        now = time.time()
        if self._opener is None or now - self._last_clean > 30:
            self._opener = urllib.request.build_opener(
                urllib.request.HTTPHandler(),
                urllib.request.HTTPSHandler(),
                NoRedirectHandler,
            )
            self._last_clean = now
        return self._opener


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers bloqueantes
# ─────────────────────────────────────────────────────────────────────────────
def _resolve_url_sync(url, ua):
    curr = url
    for _ in range(5):
        try:
            parsed = urllib.parse.urlparse(curr)
            req = urllib.request.Request(curr, headers={
                'User-Agent': ua,
                'Accept':     '*/*',
                'Host':       parsed.netloc,
                'Connection': 'keep-alive',
            })
            opener = urllib.request.build_opener(NoRedirectHandler)
            with opener.open(req, timeout=10) as resp:
                if resp.code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get('Location', '')
                    if loc:
                        curr = urllib.parse.urljoin(curr, loc)
                        continue
            return curr
        except Exception as exc:
            print("[resolve_url] {}: {}".format(type(exc).__name__, exc))
            break
    return curr


def _open_upstream_sync(url, ua, original_url, session_mgr):
    parsed = urllib.parse.urlparse(url)
    req = urllib.request.Request(url, headers={
        'User-Agent':   ua,
        'Accept':       '*/*',
        'Host':         parsed.netloc,
        'Referer':      original_url,
        'Connection':   'keep-alive',
        'Icy-MetaData': '0',
    })
    return session_mgr.get_session().open(req, timeout=15)


def _read_chunk_sync(response, size):
    return response.read(size)


# ─────────────────────────────────────────────────────────────────────────────
#  Adaptive Chunk
# ─────────────────────────────────────────────────────────────────────────────
class AdaptiveChunk:
    def __init__(self):
        self._size        = CHUNK_INITIAL
        self._ok_streak   = 0
        self._err_streak  = 0

    def reset(self):
        self._size       = CHUNK_INITIAL
        self._ok_streak  = 0
        self._err_streak = 0

    def on_success(self):
        self._err_streak = 0
        self._ok_streak += 1
        if self._ok_streak >= 10:
            self._size      = min(self._size * 2, CHUNK_MAX)
            self._ok_streak = 0

    def on_error(self):
        self._ok_streak  = 0
        self._err_streak += 1
        if self._err_streak >= 3:
            self._size       = max(self._size // 2, CHUNK_MIN)
            self._err_streak = 0

    @property
    def size(self):
        return self._size


# ─────────────────────────────────────────────────────────────────────────────
#  Backoff
# ─────────────────────────────────────────────────────────────────────────────
def _calculate_backoff(reconnect_num, error_type='network'):
    base_delays = {
        'network': 0.15,
        'http':    0.30,
        'timeout': 0.20,
        'reset':   0.10,
    }
    base = base_delays.get(error_type, 0.20)
    if reconnect_num <= 2:
        return base * reconnect_num
    elif reconnect_num <= 5:
        return base * (reconnect_num ** 1.2)
    else:
        return min(2.5, base * (reconnect_num ** 1.3))


# ─────────────────────────────────────────────────────────────────────────────
#  ASYNC HTTP SERVER
# ─────────────────────────────────────────────────────────────────────────────
async def _parse_request(reader):
    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=10.0)
        request_line = request_line.decode('utf-8', errors='replace').strip()
        if not request_line:
            return None, None
        parts = request_line.split()
        if len(parts) < 2:
            return None, None
        method, path = parts[0], parts[1]
        while True:
            line = await asyncio.wait_for(reader.readline(), timeout=5.0)
            if line in (b'\r\n', b'\n', b''):
                break
            if not line:
                break
        return method, path
    except asyncio.CancelledError:
        return None, None
    except Exception:
        return None, None


async def _send_headers(writer, status=200):
    try:
        headers = (
            "HTTP/1.1 {} OK\r\n"
            "Content-Type: video/mp2t\r\n"
            "Connection: keep-alive\r\n"
            "Cache-Control: no-cache, no-store, must-revalidate\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "\r\n"
        ).format(status)
        writer.write(headers.encode())
        await writer.drain()
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  _safe_write
# ─────────────────────────────────────────────────────────────────────────────
async def _safe_write(writer, data, stats=None, guard=None, force_drain=False):
    """Versão segura que NUNCA propaga exceções"""
    if not data:
        return True
    if guard is not None and not guard.alive:
        return False

    try:
        if writer.is_closing():
            if guard is not None:
                guard.mark_dead()
            return False
    except Exception:
        if guard is not None:
            guard.mark_dead()
        return False

    try:
        writer.write(data)
        if stats:
            stats.on_tx(len(data))
    except asyncio.CancelledError:
        if guard is not None:
            guard.mark_dead()
        return False
    except Exception:
        if guard is not None:
            guard.mark_dead()
        return False

    should_drain = force_drain
    if not should_drain:
        try:
            buf_size = writer.transport.get_write_buffer_size()
            should_drain = buf_size > 131072
        except Exception:
            should_drain = True

    if should_drain:
        try:
            await writer.drain()
        except asyncio.CancelledError:
            if guard is not None:
                guard.mark_dead()
            return False
        except Exception:
            if guard is not None:
                guard.mark_dead()
            return False

    return True


async def _null_pump(writer, cycles=4, stats=None, guard=None):
    for _ in range(cycles):
        if guard is not None and not guard.alive:
            return False
        if not await _safe_write(writer, NULL_PUMP_BURST, stats, guard):
            return False
        try:
            await asyncio.sleep(NULL_PUMP_INTERVAL)
        except asyncio.CancelledError:
            return False
        except Exception:
            return False
    return True


async def _adaptive_null_pump(writer, reconnect_time, stats=None, guard=None):
    if reconnect_time < 0.5:
        return await _null_pump(writer, cycles=1, stats=stats, guard=guard)
    elif reconnect_time < 2.0:
        return await _null_pump(writer, cycles=2, stats=stats, guard=guard)
    else:
        return await _null_pump(writer, cycles=4, stats=stats, guard=guard)


# ─────────────────────────────────────────────────────────────────────────────
#  Token Renewer
# ─────────────────────────────────────────────────────────────────────────────
class TokenRenewer:
    def __init__(self):
        self._connect_times = []
        self._last_connect  = 0.0
        self._avg_lifetime  = 0.0
        self._renewal_ratio = 0.80

    def on_connect(self):
        now = time.monotonic()
        if self._last_connect > 0:
            lifetime = now - self._last_connect
            self._connect_times.append(lifetime)
            if len(self._connect_times) > 5:
                self._connect_times.pop(0)
            self._avg_lifetime = sum(self._connect_times) / len(self._connect_times)
        self._last_connect = now

    def should_renew(self):
        if self._avg_lifetime < 10.0:
            return False
        elapsed = time.monotonic() - self._last_connect
        return elapsed >= self._avg_lifetime * self._renewal_ratio

    @property
    def avg_lifetime(self):
        return self._avg_lifetime


# ─────────────────────────────────────────────────────────────────────────────
#  _writer_wait_closed — wrapper 100% seguro para writer.wait_closed()
#  CORRIGIDO: verifica .cancelled() antes de .exception()
# ─────────────────────────────────────────────────────────────────────────────
async def _writer_close_safe(writer, timeout=2.0):
    """Fecha writer sem jamais propagar exceções."""
    if writer is None:
        return
    try:
        if not writer.is_closing():
            writer.close()
    except Exception:
        pass
    # Aguarda wait_closed() com timeout usando asyncio.wait() puro
    try:
        coro = writer.wait_closed()
        task = asyncio.ensure_future(coro)
        try:
            done, pending = await asyncio.wait({task}, timeout=timeout)
            for t in done:
                # CORRIGIDO: verifica .cancelled() antes de .exception()
                if t.cancelled():
                    continue
                try:
                    t.exception()
                except Exception:
                    pass
            for t in pending:
                t.cancel()
                try:
                    await asyncio.wait({t}, timeout=0.5)
                except Exception:
                    pass
        except Exception:
            try:
                task.cancel()
            except Exception:
                pass
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  Shutdown — 100% seguro, nunca propaga exceções
# ─────────────────────────────────────────────────────────────────────────────
async def _shutdown_session(stop_event, output_q, response_holder,
                            ka_task, writer, guard):
    """Shutdown 100% seguro - NUNCA propaga exceções"""
    try:
        guard.mark_dead()
    except Exception:
        pass

    try:
        stop_event.set()
    except Exception:
        pass

    # Cancela e aguarda ka_task
    if ka_task is not None and not ka_task.done():
        try:
            ka_task.cancel()
        except Exception:
            pass
        await _wait_task_safe(ka_task, timeout=1.0)

    # Fecha resposta upstream
    resp = response_holder[0] if response_holder else None
    if resp is not None:
        try:
            resp.close()
        except Exception:
            pass
        response_holder[0] = None

    # Drena queue
    try:
        _drain_queue(output_q)
    except Exception:
        pass

    # Fecha writer
    await _writer_close_safe(writer, timeout=2.0)


# ─────────────────────────────────────────────────────────────────────────────
#  CORE: STREAM LOOP
# ─────────────────────────────────────────────────────────────────────────────
async def _stream_loop(writer, original_url):
    loop          = asyncio.get_event_loop()
    resolved_url  = original_url
    ua            = _pick_ua()
    reconnect_num = 0
    error_type    = 'network'

    ts_buf      = TsBuffer()
    pid_filter  = PidFilter()
    tail_buf    = TailBuffer()
    pcr_stamp   = PcrRestamper()
    pts_mon     = PtsMonitor()
    cc_rewriter = CcRewriter()
    idr_gate    = IdrGate()
    chunk_ctrl  = AdaptiveChunk()
    token_ren   = TokenRenewer()
    session_mgr = SessionManager()
    pat_pmt_cache = PatPmtCache()
    stats = SessionStats()
    output_q = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
    stop_event  = asyncio.Event()
    slow_event  = asyncio.Event()
    guard = ConnectionGuard()
    response_holder = [None]

    ka_task = asyncio.ensure_future(
        _keepalive_task(writer, stop_event, slow_event, guard, loop)
    )

    idr_gate.arm()
    packets_since_drain = 0

    try:
        while not stop_event.is_set():
            output_q = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
            ts_buf.reset()
            pts_mon.reset()
            last_useful_payload = loop.time()
            response = None
            response_holder[0] = None
            slow_event.set()
            last_rx_time = time.monotonic()

            try:
                if pat_pmt_cache.has_cache:
                    injection = pat_pmt_cache.get_injection_data()
                    if injection:
                        if not await _safe_write(writer, injection, stats, guard, force_drain=True):
                            print("[ZeroSutura] Kodi encerrou durante injeção PAT/PMT.")
                            stop_event.set()
                            return

                response = await loop.run_in_executor(
                    _EXECUTOR,
                    _open_upstream_sync,
                    resolved_url, ua, original_url, session_mgr,
                )
                response_holder[0] = response
                token_ren.on_connect()

                if reconnect_num == 0:
                    print("[ZeroSutura] Conectado → {}...".format(ua[:25]))
                else:
                    print("[ZeroSutura] Reconectado #{} → {}...".format(reconnect_num, ua[:25]))
                    reconnect_num = max(0, reconnect_num - 2)

                first_payload_this_session = True

                while not stop_event.is_set():
                    if not guard.alive:
                        print("[ZeroSutura] ConnectionGuard detectou desconexão.")
                        stop_event.set()
                        return

                    if time.monotonic() - last_rx_time > STALL_TIMEOUT:
                        print("[!] Watchdog: nenhum dado recebido — forçando reconexão")
                        break

                    if token_ren.should_renew():
                        print("[+] Renovação proativa de token (vida média {:.0f}s)".format(
                            token_ren.avg_lifetime))
                        try:
                            new_url = await loop.run_in_executor(
                                _EXECUTOR, _resolve_url_sync, original_url, ua,
                            )
                            if new_url != resolved_url:
                                resolved_url = new_url
                        except Exception as exc:
                            print("[token_renew] {}: {}".format(type(exc).__name__, exc))
                        token_ren.on_connect()

                    raw = await loop.run_in_executor(
                        _EXECUTOR,
                        _read_chunk_sync,
                        response, chunk_ctrl.size,
                    )

                    if not raw:
                        break

                    stats.on_rx(len(raw))
                    last_rx_time = time.monotonic()
                    chunk_ctrl.on_success()
                    payload = ts_buf.feed(raw)

                    stats.update_buffer(len(ts_buf._buf))
                    stats.update_queue(output_q.qsize())
                    stats.maybe_log()

                    if not payload:
                        if loop.time() - last_useful_payload > STALL_TIMEOUT:
                            print("[!] Stream stall detectado - forçando reconexão")
                            break
                        continue

                    slow_event.clear()
                    last_useful_payload = loop.time()

                    ba = bytearray(payload)

                    if first_payload_this_session and reconnect_num == 0:
                        first_payload_this_session = False
                    elif first_payload_this_session:
                        first_payload_this_session = False
                        skip = tail_buf.find_stitch(ba)
                        if skip > 0:
                            print("[~] Sutura: descartando {} pacotes sobrepostos".format(
                                skip // TS_PACKET_SIZE))
                            ba = ba[skip:]
                        if not ba:
                            continue

                    ba = pid_filter.filter(ba)
                    pat_pmt_cache.set_pmt_pids(pid_filter.pmt_pids)
                    pat_pmt_cache.feed(ba)

                    if not ba:
                        continue

                    ba = pcr_stamp.stamp(ba)
                    ba = cc_rewriter.rewrite(ba)

                    if ts_buf.video_pid is not None:
                        pts_mon.set_video_pid(ts_buf.video_pid)
                    if not pts_mon.feed(ba):
                        print("[!] PTS stall detectado - forçando reconexão")
                        break

                    payload_out = bytes(ba)
                    payload_out = idr_gate.filter(payload_out)
                    if not payload_out:
                        continue

                    tail_buf.push(payload_out)

                    try:
                        output_q.put_nowait(payload_out)
                    except asyncio.QueueFull:
                        try:
                            output_q.get_nowait()
                        except asyncio.QueueEmpty:
                            pass
                        try:
                            output_q.put_nowait(payload_out)
                        except asyncio.QueueFull:
                            pass

                    packets_since_drain = 0
                    while output_q.qsize() >= MIN_OUTPUT_BUFFER:
                        try:
                            out = output_q.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                        packets_since_drain += 1
                        force_drain = (
                            packets_since_drain >= DRAIN_INTERVAL_PACKETS or
                            output_q.qsize() < MIN_OUTPUT_BUFFER
                        )
                        if not await _safe_write(writer, out, stats, guard,
                                                 force_drain=force_drain):
                            print("[ZeroSutura] Kodi encerrou a conexão.")
                            stop_event.set()
                            try:
                                response.close()
                            except Exception:
                                pass
                            response_holder[0] = None
                            return
                        if force_drain:
                            packets_since_drain = 0

            except urllib.error.HTTPError as e:
                print("[!] HTTP {} #{}".format(e.code, reconnect_num))
                error_type = 'http'
                chunk_ctrl.on_error()
            except urllib.error.URLError as e:
                print("[!] URLError #{}: {}".format(reconnect_num, e.reason))
                reason = str(e.reason).lower()
                error_type = ('timeout' if 'timeout' in reason
                              else 'reset' if 'reset' in reason
                              else 'network')
                chunk_ctrl.on_error()
            except TimeoutError:
                print("[!] Timeout #{}".format(reconnect_num))
                error_type = 'timeout'
                chunk_ctrl.on_error()
            except ConnectionResetError:
                print("[!] Connection reset #{}".format(reconnect_num))
                error_type = 'reset'
                chunk_ctrl.on_error()
            except BrokenPipeError:
                print("[ZeroSutura] BrokenPipe — cliente desconectou")
                guard.mark_dead()
                stop_event.set()
                return
            except ConnectionAbortedError:
                print("[ZeroSutura] ConnectionAborted — cliente abortou")
                guard.mark_dead()
                stop_event.set()
                return
            except OSError as e:
                print("[!] OSError #{}: {}[{}]: {}".format(
                    reconnect_num, type(e).__name__, e.errno, e))
                error_type = 'network'
                chunk_ctrl.on_error()
            except asyncio.CancelledError:
                print("[ZeroSutura] Stream loop cancelado")
                guard.mark_dead()
                stop_event.set()
                return
            except Exception as e:
                print("[!] Erro #{}: {}: {}".format(reconnect_num, type(e).__name__, e))
                error_type = 'network'
                chunk_ctrl.on_error()
            finally:
                if response is not None:
                    try:
                        response.close()
                    except Exception:
                        pass
                    response_holder[0] = None

            if stop_event.is_set():
                break

            last_pcr    = pcr_stamp.last_pcr
            cc_snapshot = ts_buf.cc_snapshot
            reconnect_num += 1
            ua = _pick_ua()
            idr_gate.arm()
            pcr_stamp.reset(last_pcr)
            cc_rewriter.reset(cc_snapshot)

            backoff = _calculate_backoff(reconnect_num, error_type)
            slow_event.set()

            if not await _adaptive_null_pump(writer, reconnect_time=backoff,
                                             stats=stats, guard=guard):
                guard.mark_dead()
                stop_event.set()
                break

            extra_cycles = int(backoff / NULL_PUMP_INTERVAL) + 1
            if not await _null_pump(writer, cycles=extra_cycles,
                                    stats=stats, guard=guard):
                guard.mark_dead()
                stop_event.set()
                break

            try:
                new_url = await loop.run_in_executor(
                    _EXECUTOR, _resolve_url_sync, original_url, ua,
                )
                if new_url != resolved_url:
                    resolved_url = new_url
                    print("[+] Token atualizado #{}".format(reconnect_num))
            except Exception as exc:
                print("[resolve] {}: {}".format(type(exc).__name__, exc))

    except asyncio.CancelledError:
        print("[ZeroSutura] Stream loop cancelado (top level)")
    except Exception as e:
        print("[ZeroSutura] Stream loop error: {}: {}".format(type(e).__name__, e))
    finally:
        print("[ZeroSutura] Executando shutdown_session()")
        await _shutdown_session(stop_event, output_q, response_holder,
                                ka_task, writer, guard)


# ─────────────────────────────────────────────────────────────────────────────
#  ZeroSuturaProxy
# ─────────────────────────────────────────────────────────────────────────────
class ZeroSuturaProxy:
    async def handle(self, reader, writer):
        global _active_session_task
        my_task = None
        try:
            method, path = await _parse_request(reader)
            if not method or not path:
                await _writer_close_safe(writer)
                return

            if method.upper() not in ('GET', 'HEAD'):
                try:
                    writer.write(b"HTTP/1.1 405 Method Not Allowed\r\n\r\n")
                    await writer.drain()
                except Exception:
                    pass
                return

            query        = urllib.parse.urlparse(path).query
            params       = urllib.parse.parse_qs(query)
            original_url = params.get('url', [None])[0]

            if not original_url:
                await _writer_close_safe(writer)
                return

            if method.upper() == 'HEAD':
                await _send_headers(writer)
                return

            with _get_session_lock():
                old_task = _active_session_task
                if old_task is not None and not old_task.done():
                    print("[ZeroSutura] Nova conexão — encerrando sessão anterior.")
                    try:
                        old_task.cancel()
                    except Exception:
                        pass
                    await _wait_task_safe(old_task, timeout=2.0)

                loop = asyncio.get_event_loop()
                my_task = loop.create_task(_run_handle(writer, original_url))
                _active_session_task = my_task

            await _wait_task_safe(my_task)

        except asyncio.CancelledError:
            pass
        except Exception:
            pass
        finally:
            await _writer_close_safe(writer)


async def _run_handle(writer, original_url):
    """NUNCA propaga exceções"""
    try:
        await _send_headers(writer)
        writer.write(NULL_PUMP_BURST)
        try:
            await writer.drain()
        except asyncio.CancelledError:
            return
        except Exception:
            return
        await _null_pump(writer, cycles=1)
        await _stream_loop(writer, original_url)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        print("[_run_handle] Error: {}: {}".format(type(e).__name__, e))


# ─────────────────────────────────────────────────────────────────────────────
#  SERVIDOR ASYNC
# ─────────────────────────────────────────────────────────────────────────────
async def _run_server():
    proxy = ZeroSuturaProxy()

    async def _conn(r, w):
        try:
            await proxy.handle(r, w)
        except asyncio.CancelledError:
            pass
        except Exception:
            pass

    server = await asyncio.start_server(
        _conn, HOST, PORT,
        reuse_address=True,
        backlog=256,
    )
    print("[ZeroSutura Async] Proxy rodando em http://{}:{}/stream?url=<URL>".format(HOST, PORT))
    async with server:
        await server.serve_forever()


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
_server_thread = None


def _port_is_available(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((HOST, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _port_accepts_connection(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5)
    try:
        s.connect((HOST, port))
        return True
    except Exception:
        return False
    finally:
        _close_socket_safe(s)


def _pick_free_port():
    candidates = list(_PORT_CANDIDATES)
    random.shuffle(candidates)
    for p in candidates:
        if _port_is_available(p):
            return p
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((HOST, 0))
        p = s.getsockname()[1]
        s.close()
        return p
    except OSError:
        return None


def _ensure_server_running():
    global PORT, _server_thread

    if _port_accepts_connection(PORT):
        return PORT

    if _server_thread is not None and _server_thread.is_alive():
        print("[ZeroSutura] Thread anterior pendurada na porta {} "
              "— subindo nova instância em porta diferente.".format(PORT))
        candidates_sem_atual = [p for p in _PORT_CANDIDATES if p != PORT]
        nova_porta = None
        random.shuffle(candidates_sem_atual)
        for p in candidates_sem_atual:
            if _port_is_available(p):
                nova_porta = p
                break
        if nova_porta is None:
            nova_porta = _pick_free_port()
        if nova_porta is None:
            print("[ZeroSutura] ERRO: nenhuma porta livre disponível!")
            return PORT
        PORT = nova_porta
    else:
        nova_porta = _pick_free_port()
        if nova_porta is None:
            print("[ZeroSutura] ERRO: nenhuma porta livre disponível!")
            return PORT
        PORT = nova_porta

    ready  = threading.Event()
    failed = threading.Event()

    def _thread():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            asyncio._set_running_loop(None)
        except (AttributeError, TypeError):
            pass

        async def _start():
            proxy = ZeroSuturaProxy()

            async def _conn(r, w):
                try:
                    await proxy.handle(r, w)
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass

            try:
                server = await asyncio.start_server(
                    _conn, HOST, PORT,
                    reuse_address=True,
                    backlog=256,
                )
            except OSError as e:
                print("[ZeroSutura] Falha ao bind na porta {}: {}".format(PORT, e))
                failed.set()
                ready.set()
                return

            print("[ZeroSutura] Servidor bind OK na porta {}".format(PORT))
            ready.set()
            async with server:
                await server.serve_forever()

        try:
            loop.run_until_complete(_start())
        except Exception as e:
            print("[ZeroSutura] Server thread error: {}: {}".format(
                type(e).__name__, e))
            failed.set()
            ready.set()

    t = threading.Thread(target=_thread, daemon=True, name="ZeroSutura-{}".format(PORT))
    t.start()
    _server_thread = t

    ready.wait(timeout=5.0)

    if failed.is_set():
        print("[ZeroSutura] Bind falhou na porta {}".format(PORT))
        return PORT

    for attempt in range(20):
        if _port_accepts_connection(PORT):
            print("[ZeroSutura] Porta {} validada após {} tentativa(s).".format(
                PORT, attempt + 1))
            return PORT
        time.sleep(0.05)

    print("[ZeroSutura] AVISO: porta {} não validou após 1s — retornando mesmo assim.".format(PORT))
    return PORT


if __name__ == "__main__":
    try:
        asyncio.run(_run_server())
    except KeyboardInterrupt:
        print("[ZeroSutura] Encerrado.")