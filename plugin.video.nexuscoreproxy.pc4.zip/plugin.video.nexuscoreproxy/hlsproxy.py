#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NexusCore HLS Proxy - ASYNC v28.6
Proxy HLS 100% assincrono usando apenas stdlib (asyncio).

CORRECAO v28.6 (eliminacao FINAL de CancelledError em Python 3.11+ Android/Kodi):
FIX1. _safe_await(): Verifica task.cancelled() ANTES de task.result().
      Em Python 3.11+, task.result() em uma task cancelada ainda propaga
      CancelledError mesmo dentro de _safe_await. A verificacao de 
      task.cancelled() antes do .result() resolve isso.
      
FIX2. _safe_wait_closed(): Envolve a chamada a _safe_await em try/except
      para capturar qualquer CancelledError residual.
      
FIX3. handle_client(): O finally envolve _safe_wait_closed em try/except
      adicional para garantir que NADA vaze para o callback do
      StreamReaderProtocol.
      
FIX4. _safe_await(): Adiciona try/except em task.result() para capturar
      CancelledError que possa escapar da verificacao de cancelled().
"""

import sys
import os
import socket
import urllib.parse
import ssl
import hashlib
import time
import asyncio
import threading
from collections import OrderedDict

# ============================================================================
# Usa SelectorEventLoop no Windows
# ============================================================================
if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

try:
    import xbmc
    import xbmcplugin
    import xbmcgui
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False
    class MockXBMC:
        LOGINFO = 0
        LOGERROR = 1
        LOGWARNING = 3
        def log(self, msg, level=0): pass
    xbmc = MockXBMC()

# ============================================================================
# CONFIGURACAO
# ============================================================================

PROXY_HOST = "127.0.0.1"
ACTIVE_PORT = 0
DEBUG = os.environ.get('NEXUSCORE_DEBUG', '0') == '1'

UPSTREAM_TIMEOUT = 15
UPSTREAM_READ_TIMEOUT = 30
MAX_REDIRECTS = 8
MAX_RETRIES = 3
CHUNK = 16384

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.4564.62 Mobile Safari/537.36",
    "VLC/3.0.20 LibVLC/3.0.20",
    "Kodi/21.0",
    "Lavf/60.3.100",
]

# ============================================================================
# FIX v28.6: _safe_await - verificacao de task.cancelled() antes de .result()
# ============================================================================

async def _safe_await(coro, default=None, timeout=None):
    """
    FIX v28.6: Executa uma coroutine em uma task ISOLADA que NAO herda o
    estado de cancelamento da task pai.
    
    VERIFICA task.cancelled() ANTES de task.result() para evitar que
    CancelledError escape no Python 3.11+ do Android/Kodi.
    
    Adiciona try/except em task.result() como camada extra de protecao.
    """
    task = None
    try:
        task = asyncio.ensure_future(coro)
        if timeout is not None:
            try:
                done, pending = await asyncio.wait({task}, timeout=timeout)
            except asyncio.CancelledError:
                # Se o wait foi cancelado, cancela a task filha
                if task is not None:
                    task.cancel()
                    try:
                        await asyncio.wait({task}, timeout=0.5)
                    except Exception:
                        pass
                return default
            
            if task in done:
                # FIX v28.6: Verifica cancelled() ANTES de result()
                if task.cancelled():
                    return default
                try:
                    return task.result()
                except asyncio.CancelledError:
                    return default
                except Exception:
                    return default
            else:
                # Timeout - cancela a task pendente
                task.cancel()
                try:
                    await asyncio.wait({task}, timeout=0.5)
                except Exception:
                    pass
                return default
        else:
            try:
                done, _ = await asyncio.wait({task})
            except asyncio.CancelledError:
                if task is not None:
                    task.cancel()
                return default
            
            if task in done:
                # FIX v28.6: Verifica cancelled() ANTES de result()
                if task.cancelled():
                    return default
                try:
                    return task.result()
                except asyncio.CancelledError:
                    return default
                except Exception:
                    return default
            return default
    except asyncio.CancelledError:
        # Captura silenciosa - nunca propaga
        if task is not None:
            task.cancel()
        if DEBUG:
            print("[NexusCore] _safe_await top-level cancelled")
        return default
    except Exception as e:
        if DEBUG:
            print(f"[NexusCore] _safe_await error: {e}")
        return default
    finally:
        # Garante que a task seja cancelada se ainda estiver pendente
        if task is not None and not task.done():
            task.cancel()

# ============================================================================
# IDENTITY MANAGER
# ============================================================================

class IdentityManager:
    def __init__(self):
        self._map = {}
        self._lock = threading.Lock()
        self._idx = 0

    def get(self, key):
        with self._lock:
            if key not in self._map:
                ua = USER_AGENTS[self._idx % len(USER_AGENTS)]
                self._idx += 1
                self._map[key] = {'User-Agent': ua}
            return self._map[key]

    def rotate(self, key):
        with self._lock:
            self._map.pop(key, None)

identities = IdentityManager()

# ============================================================================
# DNS CACHE
# ============================================================================

class DNSCache:
    def __init__(self, ttl=300):
        self._c = OrderedDict()
        self._ttl = ttl
        self._lock = threading.Lock()

    def _sync_resolve(self, host):
        now = time.time()
        with self._lock:
            if host in self._c:
                ip, ts = self._c[host]
                if now - ts < self._ttl:
                    return ip
                del self._c[host]
        try:
            ip = socket.gethostbyname(host)
            with self._lock:
                self._c[host] = (ip, now)
                if len(self._c) > 150:
                    self._c.popitem(last=False)
            return ip
        except socket.gaierror:
            return host

    async def resolve(self, host):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._sync_resolve, host)

dns = DNSCache()

# ============================================================================
# SEGMENT CACHE
# ============================================================================

class SegmentCache:
    def __init__(self, max_entries=50, max_mb=48, ttl=120):
        self._c = OrderedDict()
        self._max = max_entries
        self._max_b = max_mb * 1024 * 1024
        self._ttl = ttl
        self._used = 0
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            if key in self._c:
                e = self._c[key]
                if time.time() - e[1] < self._ttl:
                    self._c.move_to_end(key)
                    return e[0]
                self._used -= len(e[0])
                del self._c[key]
        return None

    def put(self, key, data):
        sz = len(data)
        if sz > self._max_b or sz == 0:
            return
        with self._lock:
            if key in self._c:
                self._used -= len(self._c[key][0])
                del self._c[key]
            while (self._used + sz > self._max_b or len(self._c) >= self._max) and self._c:
                _, e = self._c.popitem(last=False)
                self._used -= len(e[0])
            self._c[key] = (data, time.time())
            self._used += sz

    def purge_expired(self):
        now = time.time()
        with self._lock:
            to_del = [k for k, (_, ts) in self._c.items() if now - ts > self._ttl]
            for k in to_del:
                self._used -= len(self._c[k][0])
                del self._c[k]

seg_cache = SegmentCache()

# ============================================================================
# PLAYLIST FAILOVER
# ============================================================================

_fo = {}
_fo_lock = threading.Lock()

def save_failover(key, data):
    with _fo_lock:
        _fo[key] = data

def get_failover(key):
    with _fo_lock:
        return _fo.get(key)

# ============================================================================
# PLAYLIST REWRITER
# ============================================================================

def rewrite_manifest(raw, base_url):
    try:
        text = raw.decode('utf-8', errors='ignore')
        out = []
        for line in text.split('\n'):
            s = line.rstrip()
            if s.startswith('#'):
                if (s.startswith('#EXT-X-KEY:') or
                    s.startswith('#EXT-X-SESSION-KEY:')) and 'URI="' in s:
                    i = s.find('URI="') + 5
                    j = s.find('"', i)
                    if j > i:
                        orig = s[i:j]
                        abs_u = urllib.parse.urljoin(base_url, orig)
                        pxy = f"http://{PROXY_HOST}:{ACTIVE_PORT}/?type=key&url={urllib.parse.quote_plus(abs_u)}"
                        s = s[:i] + pxy + s[j:]
                elif s.startswith('#EXT-X-MAP:') and 'URI="' in s:
                    i = s.find('URI="') + 5
                    j = s.find('"', i)
                    if j > i:
                        orig = s[i:j]
                        abs_u = urllib.parse.urljoin(base_url, orig)
                        pxy = f"http://{PROXY_HOST}:{ACTIVE_PORT}/?url={urllib.parse.quote_plus(abs_u)}"
                        s = s[:i] + pxy + s[j:]
                out.append(s)
            elif s and not s.startswith('#'):
                abs_u = urllib.parse.urljoin(base_url, s)
                pxy = f"http://{PROXY_HOST}:{ACTIVE_PORT}/?url={urllib.parse.quote_plus(abs_u)}"
                out.append(pxy)
            else:
                out.append(s)
        return '\n'.join(out).encode('utf-8')
    except Exception:
        return raw

# ============================================================================
# ASYNC HTTP HELPERS - FIX v28.6: _safe_await com verificacao de cancelled()
# ============================================================================

async def _read_exact(reader, n, timeout=UPSTREAM_READ_TIMEOUT):
    """Leitura exata com _safe_await para protecao contra cancelamento"""
    buf = bytearray()
    while len(buf) < n:
        data = await _safe_await(
            asyncio.wait_for(reader.read(n - len(buf)), timeout=timeout),
            default=b''
        )
        if not data:
            break
        buf.extend(data)
    return bytes(buf)

async def _read_http_headers(reader, timeout=UPSTREAM_TIMEOUT):
    """
    FIX v28.6: Usa _safe_await para TODAS as operacoes de I/O.
    NUNCA propaga CancelledError.
    """
    status_line = await _safe_await(
        asyncio.wait_for(reader.readline(), timeout=timeout),
        default=b''
    )
    
    if not status_line:
        return 0, {}

    parts = status_line.decode(errors='ignore').strip().split(' ', 2)
    try:
        status = int(parts[1])
    except (IndexError, ValueError):
        return 0, {}

    headers = {}
    while True:
        line = await _safe_await(
            asyncio.wait_for(reader.readline(), timeout=timeout),
            default=b''
        )
        if line in (b'\r\n', b'\n', b''):
            break
        if b':' in line:
            d = line.decode(errors='ignore')
            ci = d.index(':')
            headers[d[:ci].strip().lower()] = d[ci + 1:].strip()

    return status, headers

async def upstream_get(url, headers=None, timeout=UPSTREAM_TIMEOUT):
    """
    FIX v28.6: Usa _safe_await para TODAS as operacoes de I/O.
    NUNCA propaga CancelledError.
    """
    if not headers:
        headers = {}

    cur = url
    status = 0
    rh = {}
    r = None
    w = None

    for _ in range(MAX_REDIRECTS + 1):
        p = urllib.parse.urlparse(cur)
        host = p.hostname
        port = p.port or (443 if p.scheme == 'https' else 80)
        path = p.path or '/'
        if p.query:
            path += '?' + p.query
        use_ssl = p.scheme == 'https'

        h_host = f"{host}:{port}" if port not in (80, 443) else host
        origin = f"{p.scheme}://{h_host}"
        referer = f"{p.scheme}://{h_host}/"

        connect_host = await dns.resolve(host)

        ssl_ctx = None
        if use_ssl:
            ssl_ctx = ssl.create_default_context()
            ssl_ctx.check_hostname = False
            ssl_ctx.verify_mode = ssl.CERT_NONE

        # Conexao com _safe_await
        if use_ssl:
            conn_result = await _safe_await(
                asyncio.wait_for(
                    asyncio.open_connection(connect_host, port, ssl=ssl_ctx, server_hostname=host),
                    timeout=timeout
                ),
                default=(None, None)
            )
        else:
            conn_result = await _safe_await(
                asyncio.wait_for(
                    asyncio.open_connection(connect_host, port),
                    timeout=timeout
                ),
                default=(None, None)
            )
        
        r, w = conn_result
        if r is None or w is None:
            return 0, {}, None, None, cur

        ua = headers.get('User-Agent', 'VLC/3.0.20 LibVLC/3.0.20')

        req = f"GET {path} HTTP/1.1\r\n"
        req += f"Host: {h_host}\r\n"
        req += f"User-Agent: {ua}\r\n"
        req += f"Origin: {origin}\r\n"
        req += f"Referer: {referer}\r\n"
        req += "Accept: */*\r\n"
        req += "Accept-Encoding: identity\r\n"
        req += "Connection: close\r\n"
        for k, v in headers.items():
            if k.lower() not in ('host', 'user-agent', 'origin', 'referer',
                                  'accept', 'accept-encoding', 'connection'):
                req += f"{k}: {v}\r\n"
        req += "\r\n"

        # Envio da requisicao
        try:
            w.write(req.encode())
        except Exception:
            _close_upstream(w)
            return 0, {}, None, None, cur
        
        drain_ok = await _safe_await(_drain_safe(w), default=False)
        if not drain_ok:
            _close_upstream(w)
            return 0, {}, None, None, cur

        # Leitura dos headers
        status, rh = await _read_http_headers(r, timeout)
        
        if status == 0:
            _close_upstream(w)
            return 0, {}, None, None, cur

        if status in (301, 302, 303, 307, 308):
            loc = rh.get('location', '')
            _close_upstream(w)
            if loc:
                cur = urllib.parse.urljoin(cur, loc)
                if DEBUG:
                    print(f"[NexusCore] Redirect {status} -> {cur}")
                continue
            return status, rh, None, None, cur

        return status, rh, r, w, cur

    return status if status else 0, rh, r, w, cur

async def _drain_safe(w):
    """Drain seguro que captura todas as excecoes"""
    try:
        await w.drain()
        return True
    except Exception:
        return False

# ============================================================================
# BODY READING - FIX v28.6: _safe_await em todas as operacoes
# ============================================================================

async def read_body(reader, headers, timeout=UPSTREAM_READ_TIMEOUT):
    """
    FIX v28.6: Usa _safe_await para TODAS as operacoes de I/O.
    NUNCA propaga CancelledError.
    """
    te = headers.get('transfer-encoding', '').lower()
    cl_str = headers.get('content-length', '')

    if 'chunked' in te:
        body = bytearray()
        while True:
            size_line = await _safe_await(
                asyncio.wait_for(reader.readline(), timeout=timeout),
                default=b''
            )
            if not size_line:
                break

            size_str = size_line.decode(errors='ignore').strip()
            if ';' in size_str:
                size_str = size_str.split(';')[0].strip()
            if not size_str:
                continue
            try:
                csz = int(size_str, 16)
            except ValueError:
                break

            if csz == 0:
                while True:
                    t = await _safe_await(
                        asyncio.wait_for(reader.readline(), timeout=2),
                        default=b''
                    )
                    if t in (b'\r\n', b'\n', b''):
                        break
                break

            chunk_data = await _read_exact(reader, csz, timeout)
            body.extend(chunk_data)

            await _safe_await(
                asyncio.wait_for(reader.readline(), timeout=timeout),
                default=b''
            )
        return bytes(body)

    if cl_str:
        try:
            total = int(cl_str)
            return await _read_exact(reader, total, timeout)
        except ValueError:
            pass

    body = bytearray()
    while True:
        data = await _safe_await(
            asyncio.wait_for(reader.read(CHUNK), timeout=timeout),
            default=b''
        )
        if not data:
            break
        body.extend(data)
    return bytes(body)


# ============================================================================
# HELPER: encerra upstream silenciosamente
# ============================================================================

def _close_upstream(uw):
    if uw is None:
        return
    try:
        uw.close()
    except Exception:
        pass


# ============================================================================
# HELPER: escrita segura no writer do cliente - FIX v28.6: _safe_await
# ============================================================================

async def _safe_write(writer, data):
    """
    FIX v28.6: Usa _safe_await para o drain.
    Retorna True se sucesso, False se o cliente desconectou.
    """
    if writer.is_closing():
        return False
    try:
        writer.write(data)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
        return False
    except Exception:
        return False

    if writer.is_closing():
        return False
    
    drain_ok = await _safe_await(_drain_safe(writer), default=False)
    return drain_ok


async def stream_body(reader, writer, headers, uw=None, timeout=UPSTREAM_READ_TIMEOUT):
    """
    FIX v28.6: Usa _safe_await para TODAS as operacoes de I/O.
    NUNCA propaga CancelledError.
    """
    te = headers.get('transfer-encoding', '').lower()
    cl_str = headers.get('content-length', '')

    def _abort(uw_ref):
        _close_upstream(uw_ref)

    if 'chunked' in te:
        while True:
            if writer.is_closing():
                _abort(uw)
                return

            size_line = await _safe_await(
                asyncio.wait_for(reader.readline(), timeout=timeout),
                default=b''
            )

            if not size_line:
                return

            size_str = size_line.decode(errors='ignore').strip()
            if ';' in size_str:
                size_str = size_str.split(';')[0].strip()
            if not size_str:
                continue
            try:
                csz = int(size_str, 16)
            except ValueError:
                return
            if csz == 0:
                return

            remaining = csz
            while remaining > 0:
                if writer.is_closing():
                    _abort(uw)
                    return

                data = await _safe_await(
                    asyncio.wait_for(reader.read(min(remaining, CHUNK)), timeout=timeout),
                    default=b''
                )

                if not data:
                    return

                ok = await _safe_write(writer, data)
                if not ok:
                    _abort(uw)
                    return

                remaining -= len(data)

            await _safe_await(
                asyncio.wait_for(reader.readline(), timeout=timeout),
                default=b''
            )
        return

    if cl_str:
        try:
            total = int(cl_str)
            sent = 0
            while sent < total:
                if writer.is_closing():
                    _abort(uw)
                    return

                to_read = min(total - sent, CHUNK)
                data = await _safe_await(
                    asyncio.wait_for(reader.read(to_read), timeout=timeout),
                    default=b''
                )

                if not data:
                    return

                ok = await _safe_write(writer, data)
                if not ok:
                    _abort(uw)
                    return
                sent += len(data)
            return
        except ValueError:
            pass

    # stream sem content-length (live)
    while True:
        if writer.is_closing():
            _abort(uw)
            return

        data = await _safe_await(
            asyncio.wait_for(reader.read(CHUNK), timeout=timeout),
            default=b''
        )
        if not data:
            break

        ok = await _safe_write(writer, data)
        if not ok:
            _abort(uw)
            return

# ============================================================================
# HTTP RESPONSE SENDER - FIX v28.6: _safe_await
# ============================================================================

async def send_response(writer, status, body=b'', headers=None):
    if writer.is_closing():
        return

    if headers is None:
        headers = {}
    reasons = {200: 'OK', 206: 'Partial Content', 400: 'Bad Request',
               502: 'Bad Gateway', 500: 'Internal Server Error'}
    reason = reasons.get(status, 'Unknown')

    h = OrderedDict()
    h['Content-Type'] = headers.get('Content-Type', 'text/plain')
    h['Content-Length'] = str(len(body))
    h['Access-Control-Allow-Origin'] = '*'
    h['Connection'] = 'close'
    h['Cache-Control'] = 'no-cache'
    for k, v in headers.items():
        h[k] = v

    resp = f"HTTP/1.1 {status} {reason}\r\n"
    for k, v in h.items():
        resp += f"{k}: {v}\r\n"
    resp += "\r\n"

    if writer.is_closing():
        return

    try:
        writer.write(resp.encode() + body)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
        return
    except Exception:
        return

    if writer.is_closing():
        return
    
    await _safe_await(_drain_safe(writer), default=False)


async def send_stream_headers(writer, status, headers):
    if writer.is_closing():
        return

    reasons = {200: 'OK', 206: 'Partial Content'}
    reason = reasons.get(status, 'OK')

    resp = f"HTTP/1.1 {status} {reason}\r\n"
    for k, v in headers.items():
        resp += f"{k}: {v}\r\n"
    resp += "Access-Control-Allow-Origin: *\r\n"
    resp += "Connection: close\r\n"
    resp += "\r\n"

    if writer.is_closing():
        return

    try:
        writer.write(resp.encode())
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
        return
    except Exception:
        return

    if writer.is_closing():
        return
    
    await _safe_await(_drain_safe(writer), default=False)

# ============================================================================
# HELPER: wait_closed seguro - FIX v28.6: try/except adicional
# ============================================================================

async def _safe_wait_closed(writer, timeout=5):
    """
    FIX v28.6: Envolve _safe_await em try/except adicional para garantir
    que NENHUM CancelledError escape para o callback do StreamReaderProtocol.
    """
    if not hasattr(writer, 'wait_closed'):
        return
    
    # FIX v28.6: try/except extra como camada final de protecao
    try:
        await _safe_await(
            asyncio.wait_for(writer.wait_closed(), timeout=timeout),
            default=None
        )
    except asyncio.CancelledError:
        # Captura final - NUNCA propaga
        pass
    except Exception:
        pass

# ============================================================================
# CLIENT HANDLER - FIX v28.6: try/except no finally para _safe_wait_closed
# ============================================================================

async def handle_client(client_reader, client_writer):
    """
    FIX v28.6: Usa _safe_await para TODAS as operacoes de I/O com o cliente.
    O finally envolve _safe_wait_closed em try/except para garantir que
    NENHUM CancelledError escape para o callback do StreamReaderProtocol.
    """
    uw = None
    try:
        # Leitura da requisicao com _safe_await
        req_line = await _safe_await(
            asyncio.wait_for(client_reader.readline(), timeout=30),
            default=b''
        )
            
        if not req_line:
            await send_response(client_writer, 400, b"Bad Request")
            return

        parts = req_line.decode(errors='ignore').strip().split(' ', 2)
        if len(parts) < 2:
            await send_response(client_writer, 400, b"Bad Request")
            return

        method = parts[0].upper()
        path = parts[1]

        # Leitura dos headers com _safe_await
        while True:
            hl = await _safe_await(
                asyncio.wait_for(client_reader.readline(), timeout=10),
                default=b''
            )
            if hl in (b'\r\n', b'\n', b''):
                break

        pp = urllib.parse.urlparse(path)
        params = urllib.parse.parse_qs(pp.query)
        real_url = params.get('url', [None])[0]
        req_type = params.get('type', [None])[0]

        if not real_url:
            await send_response(client_writer, 400, b"Missing url")
            return

        if req_type == 'key':
            url_hash = hashlib.md5(real_url.encode()).hexdigest()[:12]
            ident = identities.get(url_hash)
            
            s, rh, ur, uw, _ = await upstream_get(real_url, ident)
            
            if s in (200, 206) and ur is not None:
                key_data = await read_body(ur, rh)
                _close_upstream(uw)
                uw = None
                await send_response(client_writer, 200, key_data,
                                    {'Content-Type': 'application/octet-stream'})
            else:
                _close_upstream(uw)
                uw = None
                await send_response(client_writer, 502, b"Key fetch error")
            return

        url_hash = hashlib.md5(real_url.encode()).hexdigest()[:12]
        is_m3u8 = ('.m3u8' in real_url.lower() or '.m3u' in real_url.lower())

        if method == 'HEAD':
            ct = 'application/vnd.apple.mpegurl' if is_m3u8 else 'video/mp2t'
            await send_response(client_writer, 200, headers={'Content-Type': ct})
            return

        if not is_m3u8:
            cached = seg_cache.get(url_hash)
            if cached is not None:
                await send_response(client_writer, 200, cached, {'Content-Type': 'video/mp2t'})
                return

        ident = identities.get(url_hash)

        status = 0
        rh = {}
        ur = None
        uw = None
        final_url = real_url

        for attempt in range(MAX_RETRIES):
            s, rh, ur, uw, final_url = await upstream_get(
                real_url if attempt == 0 else final_url, ident
            )

            if s in (200, 206):
                status = s
                break

            _close_upstream(uw)
            uw = None

            if s == 403:
                identities.rotate(url_hash)
                ident = identities.get(url_hash)

            if attempt < MAX_RETRIES - 1:
                await _safe_await(asyncio.sleep(0.5 * (attempt + 1)), default=None)

        if status not in (200, 206):
            if is_m3u8:
                fb = get_failover(url_hash)
                if fb:
                    await send_response(client_writer, 200, fb,
                                        {'Content-Type': 'application/vnd.apple.mpegurl'})
                    return

            identities.rotate(url_hash)
            await send_response(client_writer, 502, b"Upstream error")
            return

        ct_remote = rh.get('content-type', '')
        is_m3u8 = is_m3u8 or ('mpegurl' in ct_remote.lower() or 'mpeg-url' in ct_remote.lower())

        if is_m3u8:
            body = await read_body(ur, rh)
            _close_upstream(uw)
            uw = None

            if not body:
                fb = get_failover(url_hash)
                if fb:
                    await send_response(client_writer, 200, fb,
                                        {'Content-Type': 'application/vnd.apple.mpegurl'})
                    return
                await send_response(client_writer, 502, b"Empty manifest")
                return

            rewritten = rewrite_manifest(body, final_url)
            save_failover(url_hash, rewritten)

            await send_response(client_writer, 200, rewritten,
                                 {'Content-Type': 'application/vnd.apple.mpegurl'})
        else:
            cl_str = rh.get('content-length', '')
            cl_val = 0
            try:
                cl_val = int(cl_str) if cl_str else 0
            except ValueError:
                pass

            if 0 < cl_val < 2 * 1024 * 1024:
                body = await read_body(ur, rh)
                _close_upstream(uw)
                uw = None

                if body and len(body) > 0:
                    seg_cache.put(url_hash, body)
                    await send_response(client_writer, 200, body, {
                        'Content-Type': 'video/mp2t',
                        'Content-Length': str(len(body))
                    })
                else:
                    await send_response(client_writer, 502, b"Empty segment")
                return

            stream_h = OrderedDict()
            stream_h['Content-Type'] = 'video/mp2t'
            if cl_str:
                stream_h['Content-Length'] = cl_str
            stream_h['Cache-Control'] = 'no-cache'

            if client_writer.is_closing():
                _close_upstream(uw)
                uw = None
                return

            await send_stream_headers(client_writer, status, stream_h)

            if client_writer.is_closing():
                _close_upstream(uw)
                uw = None
                return

            await stream_body(ur, client_writer, rh, uw=uw)

            _close_upstream(uw)
            uw = None

    except asyncio.CancelledError:
        if DEBUG:
            print("[NexusCore] handle_client cancelled (top level)")
        _close_upstream(uw)
        uw = None
    except Exception as e:
        if DEBUG:
            print(f"[NexusCore] Handler error: {e}")
        _close_upstream(uw)
        uw = None
        try:
            await send_response(client_writer, 500, b"Internal error")
        except Exception:
            pass
    finally:
        # FIX v28.6: try/except EXTRA no finally para garantir que NADA vaze
        try:
            try:
                if not client_writer.is_closing():
                    client_writer.close()
            except Exception:
                pass
            
            # Envolve _safe_wait_closed em try/except para capturar
            # qualquer CancelledError que possa escapar do _safe_await
            try:
                await _safe_wait_closed(client_writer, timeout=5)
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        except Exception:
            # Captura final de qualquer coisa que possa vazar
            pass

# ============================================================================
# SERVIDOR ASYNC
# ============================================================================

_server = None
_loop = None
_started = False

async def _run_server():
    global _server, ACTIVE_PORT
    try:
        if _server is not None:
            _server.close()
            try:
                await _server.wait_closed()
            except Exception:
                pass
            _server = None

        _server = await asyncio.start_server(handle_client, PROXY_HOST, 0)
        ACTIVE_PORT = _server.sockets[0].getsockname()[1]

    except OSError as e:
        if DEBUG:
            print(f"[NexusCore] Port bind failed: {e}")
        if KODI_AVAILABLE:
            xbmc.log(f"[NexusCore] Port bind failed: {e}", xbmc.LOGERROR)
        ACTIVE_PORT = 0
        return

    if KODI_AVAILABLE:
        xbmc.log(f"[NexusCore] Async proxy running on {PROXY_HOST}:{ACTIVE_PORT}", xbmc.LOGINFO)

    try:
        async with _server:
            await _server.serve_forever()
    except asyncio.CancelledError:
        if DEBUG:
            print("[NexusCore] Server cancelled")
    except Exception as e:
        if DEBUG:
            print(f"[NexusCore] Server error: {e}")
        ACTIVE_PORT = 0

def _loop_thread():
    global _loop, _started
    try:
        _loop = asyncio.new_event_loop()
        try:
            asyncio._set_running_loop(None)
        except (AttributeError, TypeError):
            pass
        asyncio.set_event_loop(_loop)
        _loop.run_forever()
    except Exception as e:
        if DEBUG:
            print(f"[NexusCore] Loop error: {e}")
    finally:
        _started = False

def start_proxy():
    global _started, _loop, ACTIVE_PORT

    def check_port():
        if ACTIVE_PORT == 0:
            return False
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            s.connect((PROXY_HOST, ACTIVE_PORT))
            s.close()
            return True
        except Exception:
            return False

    if _started and _loop is not None and _loop.is_running():
        if check_port():
            return True
        else:
            asyncio.run_coroutine_threadsafe(_run_server(), _loop)
            for _ in range(15):
                if check_port():
                    return True
                time.sleep(0.2)
            return False

    if _started:
        _started = False

    try:
        t = threading.Thread(target=_loop_thread, daemon=True)
        t.start()

        for _ in range(30):
            if _loop is not None:
                break
            time.sleep(0.1)

        if _loop is None:
            return False

        asyncio.run_coroutine_threadsafe(_run_server(), _loop)

        for _ in range(30):
            if check_port():
                _started = True
                return True
            time.sleep(0.2)

        return False
    except Exception as e:
        if DEBUG:
            print(f"[NexusCore] Start fail: {e}")
        if KODI_AVAILABLE:
            xbmc.log(f"[NexusCore] Start fail: {e}", xbmc.LOGERROR)
        return False

# ============================================================================
# CACHE CLEANUP PERIODICO
# ============================================================================

_cleanup_thread = None

def _periodic_cleanup():
    while True:
        time.sleep(60)
        try:
            seg_cache.purge_expired()
        except Exception:
            pass

def start_cleanup():
    global _cleanup_thread
    if _cleanup_thread is None:
        _cleanup_thread = threading.Thread(target=_periodic_cleanup, daemon=True)
        _cleanup_thread.start()

# ============================================================================
# KODI ADDON
# ============================================================================

class HLSAddon:
    def __init__(self, addon_handle=-1, **kwargs):
        self.handle = addon_handle
        if self.handle == -1 and len(sys.argv) > 1:
            try:
                self.handle = int(sys.argv[1])
            except (ValueError, IndexError):
                pass
        start_proxy()
        start_cleanup()

    def play_stream(self, url, **kwargs):
        if not url or ACTIVE_PORT == 0:
            return

        proxy_url = f"http://{PROXY_HOST}:{ACTIVE_PORT}/?url={urllib.parse.quote_plus(url)}"

        if KODI_AVAILABLE:
            try:
                li = xbmcgui.ListItem(label="NexusCore HLS")

                is_hls = '.m3u8' in url.lower() or '.m3u' in url.lower()

                li.setProperty('inputstream', 'inputstream.ffmpegdirect')
                li.setProperty('inputstream.ffmpegdirect.is_live', 'true')
                li.setProperty('inputstream.ffmpegdirect.playback_buffer', 'cache')
                li.setProperty('inputstream.ffmpegdirect.buffer_size', '67108864')

                if is_hls:
                    li.setProperty('inputstream.ffmpegdirect.mime_type', 'application/vnd.apple.mpegurl')
                    li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
                else:
                    li.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp2t')
                    li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')

                li.setPath(proxy_url)

                if self.handle != -1:
                    xbmcplugin.setResolvedUrl(self.handle, True, li)
                else:
                    xbmc.Player().play(proxy_url, li)
            except Exception as e:
                if DEBUG:
                    print(f"[NexusCore] Play error: {e}")

    def play(self, url, **kwargs):
        self.play_stream(url, **kwargs)

    def run(self):
        if len(sys.argv) > 2:
            try:
                params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
                url = params.get('url')
                if url:
                    self.play_stream(url)
            except Exception:
                pass

        if KODI_AVAILABLE:
            monitor = xbmc.Monitor()
            while not monitor.abortRequested():
                if monitor.waitForAbort(10):
                    break

if __name__ == '__main__':
    addon = HLSAddon()
    if KODI_AVAILABLE:
        addon.run()
    else:
        print(f"[NexusCore HLS Proxy] Demo mode - http://{PROXY_HOST}:{ACTIVE_PORT}")
        start_proxy()
        start_cleanup()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("[NexusCore] Stopped")