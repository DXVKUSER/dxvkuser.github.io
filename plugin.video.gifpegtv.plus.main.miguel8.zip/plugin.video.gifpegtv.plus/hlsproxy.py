import http.server
import socketserver
import threading
import urllib.parse
import requests
import re
import sys
import urllib3
import time
import random
import io
import socket
import base64

# Desativa avisos de segurança
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- ESTRUTURAS GLOBAIS PARA PRE-FETCH (BUFFER DE SEGURANÇA) ---
PREFETCH_CACHE = {}
PREFETCH_LOCK = threading.Lock()
PLAYLIST_SEQUENCE = {}

URL_CACHE = {}
SESSION = requests.Session()

# Armazena a última URL base para o Fallback de Requisições Diretas (Passo 4)
LAST_KNOWN_URL = None

# AUMENTO DO POOL DE CONEXÕES
adapter = requests.adapters.HTTPAdapter(pool_connections=100, pool_maxsize=100, max_retries=1)
SESSION.mount('http://', adapter)
SESSION.mount('https://', adapter)

# ---------------------------------------------------------------
# USER-AGENTS: lista expandida, indexada para rotação sequencial
# ---------------------------------------------------------------
UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.119 Mobile Safari/537.36",
]

# Índice global de UA para rotação sequencial por tentativa
_UA_INDEX_LOCK = threading.Lock()
_UA_INDEX = 0

def next_ua():
    """Retorna o próximo User-Agent na sequência (thread-safe)."""
    global _UA_INDEX
    with _UA_INDEX_LOCK:
        ua = UAS[_UA_INDEX % len(UAS)]
        _UA_INDEX += 1
    return ua

def random_ua():
    """Retorna um User-Agent aleatório."""
    return random.choice(UAS)

# ---------------------------------------------------------------
# GERENCIAMENTO DE SESSÃO: recria a sessão quando ela está podre
# ---------------------------------------------------------------
_SESSION_LOCK = threading.Lock()

def reset_session():
    """Recria a sessão HTTP global, limpando cookies e conexões mortas."""
    global SESSION
    with _SESSION_LOCK:
        try:
            SESSION.close()
        except Exception:
            pass
        SESSION = requests.Session()
        new_adapter = requests.adapters.HTTPAdapter(
            pool_connections=100, pool_maxsize=100, max_retries=1
        )
        SESSION.mount('http://', new_adapter)
        SESSION.mount('https://', new_adapter)
        print("[PROXY] Sessão HTTP reiniciada.")

def get_session():
    """Retorna a sessão global de forma thread-safe."""
    with _SESSION_LOCK:
        return SESSION

# ---------------------------------------------------------------

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True


def get_anti_block_headers(url, referer=None, ua=None):
    parsed = urllib.parse.urlparse(url)

    # Passo 3: Cabeçalhos de Host Estáticos resolvido aqui.
    # O parsed.netloc é extraído dinamicamente a cada requisição (incluindo após redirects).
    headers = {
        'User-Agent': ua if ua else random_ua(),
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'keep-alive',
        'Host': parsed.netloc,
        'Origin': f"{parsed.scheme}://{parsed.netloc}",
        'Referer': referer if referer else f"{parsed.scheme}://{parsed.netloc}/",
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'DNT': '1',
        'Upgrade-Insecure-Requests': '1',
        'X-Forwarded-For': (
            f"{random.randint(1,255)}.{random.randint(1,255)}."
            f"{random.randint(1,255)}.{random.randint(1,255)}"
        ),
        'X-Forwarded-Host': parsed.netloc,
        'X-Forwarded-Proto': parsed.scheme,
    }

    return headers


def invalidate_cache(cache_key):
    """Remove entrada do URL_CACHE de forma segura."""
    try:
        if cache_key in URL_CACHE:
            del URL_CACHE[cache_key]
    except Exception:
        pass


def fetch_content(url, expected_type='m3u8', referer=None):
    cache_key = (url, referer) if referer else url
    cached_target = URL_CACHE.get(cache_key)

    # Timeouts: 4s conectar, 18s ler
    req_timeout = (4.0, 18.0)

    # --- Tentativa com URL em cache ---
    if cached_target:
        try:
            ua = next_ua()
            headers = get_anti_block_headers(cached_target, referer, ua=ua)
            sess = get_session()
            resp = sess.get(
                cached_target, headers=headers, stream=True,
                timeout=req_timeout, allow_redirects=False, verify=False
            )

            if resp.status_code == 200:
                if expected_type == 'm3u8' and b'#EXTM3U' in resp.content:
                    resp._cached_content = resp.content
                    return resp, cached_target
                elif expected_type == 'ts':
                    first_byte = resp.raw.read(1)
                    if first_byte == b'\x47':
                        resp._first_byte = first_byte
                        resp._target_url = cached_target
                        resp._referer = referer
                        return resp, cached_target
                    resp.close()
                elif expected_type == 'key':
                    resp._cached_content = resp.content
                    return resp, cached_target

            if resp.status_code in [401, 403, 404, 410]:
                print(
                    f"[PROXY] Token expirado no cache ({resp.status_code}) → "
                    f"invalidando e refazendo com UA rotacionado."
                )
                resp.close()
                invalidate_cache(cache_key)
                if resp.status_code in [401, 403]:
                    get_session().cookies.clear()
            else:
                resp.close()

        except requests.exceptions.ConnectionError as e:
            print(f"[PROXY] Conexão morta no cache: {e} → reiniciando sessão.")
            invalidate_cache(cache_key)
            reset_session()
        except requests.exceptions.Timeout as e:
            print(f"[PROXY] Timeout no cache: {e} → invalidando.")
            invalidate_cache(cache_key)
        except Exception as e:
            print(f"[PROXY] Erro inesperado no cache: {e} → invalidando.")
            invalidate_cache(cache_key)

    # --- Tentativa fresh com URL original, múltiplas tentativas ---
    max_redirects = 10
    max_retries = 4
    consecutive_network_failures = 0

    for attempt in range(max_retries):
        current_url = url
        current_referer = referer
        ua = next_ua()

        if consecutive_network_failures >= 2:
            print(f"[PROXY] {consecutive_network_failures} falhas de rede → reiniciando sessão.")
            reset_session()
            consecutive_network_failures = 0
            time.sleep(1.0)

        try:
            for _ in range(max_redirects):
                headers = get_anti_block_headers(current_url, current_referer, ua=ua)
                sess = get_session()

                resp = sess.get(
                    current_url, headers=headers, stream=True,
                    timeout=req_timeout, allow_redirects=False, verify=False
                )

                if resp.status_code in [401, 403]:
                    print(
                        f"[PROXY] Auth falhou ({resp.status_code}) na tentativa "
                        f"{attempt+1}, UA={ua[:40]}… rotacionando."
                    )
                    resp.close()
                    get_session().cookies.clear()
                    break

                if resp.status_code in [404, 410]:
                    print(f"[PROXY] Recurso não encontrado ({resp.status_code}). Abortando.")
                    resp.close()
                    return None, current_url

                if resp.status_code in [301, 302, 303, 307, 308]:
                    location = resp.headers.get('Location')
                    resp.close()
                    if not location:
                        break
                    current_referer = current_url
                    current_url = urllib.parse.urljoin(current_url, location)
                    continue

                if resp.status_code == 200:
                    if expected_type == 'm3u8':
                        content = resp.content
                        resp.close()
                        if b'#EXTM3U' in content:
                            fake = type('R', (), {
                                '_cached_content': content,
                                'close': lambda self: None
                            })()
                            URL_CACHE[cache_key] = current_url
                            consecutive_network_failures = 0
                            return fake, current_url
                        else:
                            print(f"[PROXY] Resposta 200 mas sem #EXTM3U. Tentativa {attempt+1}.")
                            break

                    elif expected_type == 'ts':
                        first_byte = resp.raw.read(1)
                        if first_byte == b'\x47':
                            resp._first_byte = first_byte
                            resp._target_url = current_url
                            resp._referer = current_referer
                            URL_CACHE[cache_key] = current_url
                            consecutive_network_failures = 0
                            return resp, current_url
                        else:
                            resp.close()
                            print(f"[PROXY] TS sem sync byte 0x47. Tentativa {attempt+1}.")
                            break

                    elif expected_type == 'key':
                        resp._cached_content = resp.content
                        URL_CACHE[cache_key] = current_url
                        consecutive_network_failures = 0
                        return resp, current_url

                resp.close()
                break

        except requests.exceptions.ConnectionError as e:
            consecutive_network_failures += 1
            print(f"[PROXY] ConnectionError na tentativa {attempt+1}: {e}")
        except requests.exceptions.Timeout as e:
            consecutive_network_failures += 1
            print(f"[PROXY] Timeout na tentativa {attempt+1}: {e}")
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            return None, current_url
        except Exception as e:
            consecutive_network_failures += 1
            print(f"[PROXY] Erro inesperado na tentativa {attempt+1}: {e}")

        if attempt < max_retries - 1:
            delay = 0.5 * (attempt + 1)
            print(f"[PROXY] Aguardando {delay:.1f}s antes da tentativa {attempt+2}…")
            time.sleep(delay)

    print(f"[PROXY] Todas as {max_retries} tentativas falharam para {url}")
    return None, url


def prefetch_worker(ts_url, referer):
    try:
        with PREFETCH_LOCK:
            if ts_url in PREFETCH_CACHE:
                return

        ua = next_ua()
        headers = get_anti_block_headers(ts_url, referer, ua=ua)
        sess = get_session()
        resp = sess.get(ts_url, headers=headers, timeout=(4.0, 22.0), verify=False)

        if resp.status_code == 200:
            content = resp.content
            if content and content[0] == 0x47:
                with PREFETCH_LOCK:
                    if len(PREFETCH_CACHE) > 5:
                        PREFETCH_CACHE.popitem()
                    PREFETCH_CACHE[ts_url] = content
        elif resp.status_code in [401, 403]:
            cache_key = (ts_url, referer) if referer else ts_url
            invalidate_cache(cache_key)

        resp.close()
    except Exception:
        pass


class ProxyHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def decode_path(self, path):
        """Descodifica a rota base64 (Passo 5) e retorna (req_type, url, referer)"""
        try:
            parts = path.strip("/").split("/")
            if len(parts) != 2: return None, None, None
            prefix, filename = parts

            # Mapeia prefixos explicitamente — sem fallback implícito
            PREFIX_MAP = {
                "playlist": "m3u8",
                "segment":  "ts",
                "key":      "key",
            }
            req_type = PREFIX_MAP.get(prefix)
            if req_type is None:
                return None, None, None

            # Remove a extensão para decodificar apenas o Base64
            b64 = filename.rsplit(".", 1)[0]
            # Readiciona o padding '=' necessário para o base64
            b64 += "=" * ((4 - len(b64) % 4) % 4)

            decoded = base64.urlsafe_b64decode(b64).decode('utf-8')
            url, referer = decoded.split("|", 1)

            return req_type, url, referer
        except Exception:
            return None, None, None

    def make_proxy_url(self, req_type, url, referer):
        """Cria rotas estáticas Base64 para evitar Query Strings no Manjaro (Passo 5)"""
        payload = f"{url}|{referer}".encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        
        ext = "m3u8" if req_type == "m3u8" else "ts" if req_type == "ts" else "key"
        prefix = "playlist" if req_type == "m3u8" else "segment" if req_type == "ts" else "key"
        
        return f"http://{self.server.server_address[0]}:{self.server.server_address[1]}/{prefix}/{b64}.{ext}"

    def do_HEAD(self):
        # Passo 2: Correção do Handler do_HEAD (Detecção dinâmica por rota)
        self.send_response(200)
        
        if self.path.startswith('/playlist/'):
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        elif self.path.startswith('/segment/'):
            self.send_header('Content-Type', 'video/mp2t')
        elif self.path.startswith('/key/'):
            self.send_header('Content-Type', 'application/octet-stream')
        else:
            self.send_header('Content-Type', 'application/octet-stream')

        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Access-Control-Max-Age', '86400')
        self.end_headers()

    def do_GET(self):
        global LAST_KNOWN_URL
        
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path

        req_type, target_url, referer = self.decode_path(path)

        # Passo 4: Fallback para Requisições Diretas Relativas (Ignoram a reescrita do proxy)
        if not target_url:
            if LAST_KNOWN_URL and (path.endswith('.ts') or '.ts?' in self.path):
                target_url = urllib.parse.urljoin(LAST_KNOWN_URL, self.path.lstrip('/'))
                req_type = 'ts'
                referer = LAST_KNOWN_URL
            elif LAST_KNOWN_URL and (path.endswith('.key') or path.endswith('.bin')):
                target_url = urllib.parse.urljoin(LAST_KNOWN_URL, self.path.lstrip('/'))
                req_type = 'key'
                referer = LAST_KNOWN_URL
            else:
                self.send_error(400, "URL ausente ou rota inválida para o Player")
                return
        else:
            if req_type == 'm3u8':
                LAST_KNOWN_URL = target_url

        if referer:
            referer = urllib.parse.unquote(referer)
        else:
            referer = None

        if req_type == 'ts':
            with PREFETCH_LOCK:
                cached_data = PREFETCH_CACHE.pop(target_url, None)

            if cached_data:
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Content-Length', str(len(cached_data)))
                self.send_anti_block_headers()
                self.end_headers()
                try:
                    self.wfile.write(cached_data)
                except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                    pass
                return

        resp, final_url = fetch_content(target_url, req_type, referer)

        if not resp:
            self._send_fallback(req_type)
            return

        if req_type == 'm3u8':
            self.handle_m3u8(resp, final_url)
        elif req_type == 'ts':
            self.handle_ts(resp, target_url, referer)
        elif req_type == 'key':
            self.handle_key(resp)

    def _send_fallback(self, req_type):
        self.send_response(200)
        self.send_anti_block_headers()

        if req_type == 'm3u8':
            body = (
                b"#EXTM3U\n"
                b"#EXT-X-VERSION:3\n"
                b"#EXT-X-TARGETDURATION:10\n"
                b"#EXT-X-MEDIA-SEQUENCE:0\n"
            )
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except Exception:
                pass

        elif req_type == 'ts':
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', '0')
            self.end_headers()

        elif req_type == 'key':
            body = b'\x00' * 16
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except Exception:
                pass

    def send_anti_block_headers(self):
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'SAMEORIGIN')
        self.send_header('X-XSS-Protection', '1; mode=block')

    def _rewrite_key_line(self, line, final_url):
        """
        Intercepta #EXT-X-KEY reescrevendo a URI da chave AES-128 para passar
        pelo proxy local — garantindo que User-Agent e cabeçalhos anti-bloqueio
        sejam aplicados na busca da chave de descriptografia.

        Suporta:
          - URIs relativas e absolutas
          - Múltiplos atributos na tag (METHOD, URI, IV, KEYFORMAT…)
          - Aspas simples e duplas na URI
          - Chaves inline (data: URI) — mantidas sem alteração
        """
        uri_match = re.search(r'URI=(["\'])(.*?)\1', line)
        if not uri_match:
            # Sem URI (ex: METHOD=NONE) — mantém linha intacta
            return line

        quote_char = uri_match.group(1)
        original_uri = uri_match.group(2)

        # Chaves inline (data:) não precisam de proxy
        if original_uri.lower().startswith('data:'):
            return line

        # Converte URI relativa → absoluta usando a URL base do manifesto
        abs_key_url = urllib.parse.urljoin(final_url, original_uri)

        # Cria URL de proxy local para a chave
        proxy_key_url = self.make_proxy_url("key", abs_key_url, final_url)

        print(f"[PROXY] AES-128 KEY interceptada: {abs_key_url}")

        # Substitui apenas a URI dentro da tag, preservando todos os outros atributos
        new_line = line[:uri_match.start()] \
                   + f'URI={quote_char}{proxy_key_url}{quote_char}' \
                   + line[uri_match.end():]
        return new_line

    def handle_m3u8(self, resp, final_url):
        try:
            content = resp._cached_content.decode('utf-8', errors='ignore')
        except Exception:
            self._send_fallback('m3u8')
            return
        finally:
            try:
                resp.close()
            except Exception:
                pass

        lines = content.splitlines()
        new_lines = []
        ts_sequence = []

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith('#EXT-X-KEY'):
                # INTERCEPTAÇÃO AES-128: reescreve URI da chave para o proxy local
                line = self._rewrite_key_line(line, final_url)
                new_lines.append(line)

            elif not line.startswith('#'):
                abs_ts = urllib.parse.urljoin(final_url, line)

                # Se for uma sub-playlist, reescreve mantendo a extensão m3u8.
                if abs_ts.lower().split('?')[0].endswith('.m3u8'):
                    proxy_ts = self.make_proxy_url("m3u8", abs_ts, final_url)
                else:
                    ts_sequence.append(abs_ts)
                    proxy_ts = self.make_proxy_url("ts", abs_ts, final_url)

                new_lines.append(proxy_ts)

            else:
                new_lines.append(line)

        with PREFETCH_LOCK:
            PLAYLIST_SEQUENCE[final_url] = ts_sequence

        output = '\n'.join(new_lines).encode('utf-8')

        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Content-Length', str(len(output)))
        self.send_anti_block_headers()
        self.end_headers()
        try:
            self.wfile.write(output)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass

    def handle_ts(self, resp, current_ts_url, referer):
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_anti_block_headers()
        self.end_headers()

        bytes_written = 0
        max_internal_retries = 3
        target_url = getattr(resp, '_target_url', None)

        if referer:
            with PREFETCH_LOCK:
                seq = PLAYLIST_SEQUENCE.get(referer, [])

            if seq:
                try:
                    current_idx = seq.index(current_ts_url)
                    if current_idx + 1 < len(seq):
                        next_ts_url = seq[current_idx + 1]
                        threading.Thread(
                            target=prefetch_worker,
                            args=(next_ts_url, referer),
                            daemon=True
                        ).start()
                except ValueError:
                    pass

        chunk_size = 65536

        for attempt in range(max_internal_retries):
            retry_resp = None
            retry_ua = next_ua() if attempt > 0 else None

            try:
                if attempt == 0:
                    self.wfile.write(resp._first_byte)
                    bytes_written += 1
                    for chunk in resp.iter_content(chunk_size=chunk_size):
                        if chunk:
                            self.wfile.write(chunk)
                            bytes_written += len(chunk)
                    break 

                else:
                    if not target_url:
                        break

                    print(
                        f"[PROXY] Retry TS {attempt}/{max_internal_retries-1} "
                        f"a partir do byte {bytes_written}, UA={retry_ua[:40]}…"
                    )

                    headers = get_anti_block_headers(target_url, referer, ua=retry_ua)

                    if bytes_written > 0:
                        headers['Range'] = f"bytes={bytes_written}-"

                    sess = get_session()
                    retry_resp = sess.get(
                        target_url, headers=headers, stream=True,
                        timeout=(4.0, 18.0), verify=False
                    )

                    if retry_resp.status_code in [200, 206]:
                        for chunk in retry_resp.iter_content(chunk_size=chunk_size):
                            if chunk:
                                self.wfile.write(chunk)
                                bytes_written += len(chunk)
                        break 

                    elif retry_resp.status_code in [401, 403]:
                        print(
                            f"[PROXY] Auth falhou no retry TS ({retry_resp.status_code})."
                            f" Invalidando cache e abortando segmento."
                        )
                        cache_key = (current_ts_url, referer) if referer else current_ts_url
                        invalidate_cache(cache_key)
                        get_session().cookies.clear()
                        break

                    else:
                        print(f"[PROXY] Status {retry_resp.status_code} no retry TS.")
                        time.sleep(0.5 * attempt)

            except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                break
            except requests.exceptions.ConnectionError as e:
                print(f"[PROXY] ConnectionError no TS attempt {attempt+1}: {e}")
                if attempt < max_internal_retries - 1:
                    reset_session()
                    time.sleep(0.5 * (attempt + 1))
            except Exception as e:
                print(f"[PROXY] Erro no TS attempt {attempt+1}: {e}")
                if attempt < max_internal_retries - 1:
                    time.sleep(0.5 * (attempt + 1))
            finally:
                if attempt == 0 and resp:
                    try:
                        resp.close()
                    except Exception:
                        pass
                if retry_resp:
                    try:
                        retry_resp.close()
                    except Exception:
                        pass

    def handle_key(self, resp):
        key_data = getattr(resp, '_cached_content', b'')
        if not key_data:
            print("[PROXY] AVISO: chave AES-128 vazia — enviando fallback nulo.")
            key_data = b'\x00' * 16

        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(len(key_data)))
        self.send_anti_block_headers()
        self.end_headers()
        try:
            self.wfile.write(key_data)
            print(f"[PROXY] Chave AES-128 entregue ao player ({len(key_data)} bytes).")
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass
        finally:
            try:
                resp.close()
            except Exception:
                pass


class HLSAddon:
    def __init__(self, addon_handle=None):
        self.addon_handle = addon_handle
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), ProxyHTTPRequestHandler)
        self.port = self.server.server_port
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.daemon = True
        self.thread.start()
        print(
            f"[PROXY HLS] Iniciado na porta {self.port} "
            f"— Pre-Fetch Ativo | Reconexão Robusta | UA Rotativo | Base64 Nativo ({len(UAS)} agentes)"
        )

    def play_stream(self, original_url, listitem=None):
        # Passo 5 / Passo 1: Inicializa a reprodução codificando o Base64 em Path sem inputstream
        payload = f"{original_url}|".encode('utf-8')
        b64 = base64.urlsafe_b64encode(payload).decode('utf-8').rstrip("=")
        proxy_url = f"http://127.0.0.1:{self.port}/playlist/{b64}.m3u8"

        try:
            import xbmcplugin, xbmcgui, xbmc
            if listitem is None or isinstance(listitem, str):
                listitem = xbmcgui.ListItem(path=proxy_url)
            else:
                listitem.setPath(proxy_url)

            handle = -1
            if self.addon_handle is not None:
                try:
                    handle = int(self.addon_handle)
                except Exception:
                    pass

            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, True, listitem)
            else:
                xbmc.Player().play(proxy_url, listitem)
        except ImportError:
            return proxy_url

    def stop(self):
        self.server.shutdown()
        self.server.server_close()