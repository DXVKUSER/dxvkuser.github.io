# -*- coding: utf-8 -*-

"""
HLS Proxy Addon para Kodi
Versão Refatorada com Múltiplas Melhorias:
- Suporte a IPv6 (DoH)
- Cache em Disco Persistente (opcional)
- Tratamento de Exceção Específico
- Código Refatorado em classes (Fetcher, Rewriter)
- Configurações avançadas via settings.xml
- Melhorias adicionais: verificação de portas, timeouts configuráveis, cache adaptativo, rotação de logs, etc.
"""

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
from collections import OrderedDict
from requests.exceptions import Timeout, ConnectionError, HTTPError

# --- Configurações Iniciais do Addon ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HANDLE = int(sys.argv[1])

PROXY_HOST = '127.0.0.1'
DEFAULT_PROXY_PORT = random.randint(20000, 65000)
MAX_PORT_ATTEMPTS = 5 # Aumentado de 3 para 5 tentativas de porta
LOCK_FILE = os.path.join(ADDON_PROFILE, 'proxy.lock')

# --- Leitura das Configurações do Addon com Fallbacks ---
try:
    max_cache_mb = int(ADDON.getSetting('max_cache_mb'))
    if max_cache_mb <= 0: raise ValueError
except (ValueError, TypeError):
    max_cache_mb = 64 # Valor padrão aumentado de 8 para 64 MB
MAX_CACHE_SIZE_BYTES = max_cache_mb * 1024 * 1024

try:
    max_segment_size_mb = int(ADDON.getSetting('max_segment_size_mb'))
    if max_segment_size_mb <= 0: raise ValueError
except (ValueError, TypeError):
    max_segment_size_mb = 4 # Valor padrão aumentado de 2 para 4 MB
MAX_SEGMENT_SIZE_BYTES = max_segment_size_mb * 1024 * 1024

try:
    CACHE_TYPE = ADDON.getSetting('cache_type').lower()
except Exception:
    CACHE_TYPE = 'ram' # Padrão ainda é RAM

try:
    SIMULATE_ERRORS = ADDON.getSetting('simulate_errors') == 'true'
except Exception:
    SIMULATE_ERRORS = False

# Controle para simulação de erros apenas em ambiente de desenvolvimento
IS_DEV_ENV = os.environ.get('KODI_ENV') == 'development'
if SIMULATE_ERRORS and not IS_DEV_ENV:
    SIMULATE_ERRORS = False
    logging.warning("Simulate errors disabled: not in development environment.")

try:
    ENABLE_IPV6 = ADDON.getSetting('enable_ipv6') == 'true'
except Exception:
    ENABLE_IPV6 = True

try:
    CONNECTION_TIMEOUT = float(ADDON.getSetting('connection_timeout') or 15) # Aumentado de 10 para 15 segundos
except (ValueError, TypeError):
    CONNECTION_TIMEOUT = 15

try:
    STREAM_TIMEOUT = float(ADDON.getSetting('stream_timeout') or 20) # Aumentado de 15 para 20 segundos
except (ValueError, TypeError):
    STREAM_TIMEOUT = 20

try:
    LOG_MAX_BYTES = int(ADDON.getSetting('log_max_bytes') or 2097152)  # Aumentado para 2 MB
except (ValueError, TypeError):
    LOG_MAX_BYTES = 2097152

try:
    LOG_BACKUP_COUNT = int(ADDON.getSetting('log_backup_count') or 5) # Aumentado de 3 para 5 backups
except (ValueError, TypeError):
    LOG_BACKUP_COUNT = 5

CHUNK_SIZE = 32768
LOG_FILE = xbmcvfs.translatePath(ADDON.getSetting('log_file_path') or 'special://temp/hlsproxy.log')
USER_BLOCKLIST = set(filter(None, (ADDON.getSetting('host_blocklist') or '').split(',')))
PROXY_TOKEN = (ADDON.getSetting('proxy_token') or '').strip() or None

try:
    loglevel_raw = ADDON.getSetting("loglevel")
    loglevel = loglevel_raw.upper().strip() if loglevel_raw else "INFO" # Padrão para INFO
    LOG_LEVEL = int(getattr(logging, loglevel, logging.INFO)) # Usar INFO como padrão
except Exception:
    LOG_LEVEL = logging.INFO

# Configuração de log com rotação
log_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
)
logging.basicConfig(
    handlers=[log_handler],
    level=LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s'
)

# --- Constantes de Headers e User-Agents ---
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (WebOS; U; SmartTV; LG NetCast.TV-2013) AppleWebKit/537.41 (KHTML, like Gecko) WebAppManager"
]
ACCEPT_LANGUAGES = ["pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "en-US,en;q=0.9,pt;q=0.8", "es-ES,es;q=0.9,en;q=0.8"]
PLAYER_HEADERS = [{"User-Agent": USER_AGENTS[i], "Accept": "*/*", "Accept-Language": lang, "Origin": "", "Referer": ""} for i, lang in zip(range(len(USER_AGENTS)), ACCEPT_LANGUAGES * 2)]

def random_player_headers(url):
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.hostname}"
    headers = random.choice(PLAYER_HEADERS).copy()
    headers['Origin'] = origin
    headers['Referer'] = origin
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def jitter(base, percent=0.2):
    return base + base * random.uniform(-percent, percent)

# --- Sessão HTTP Global e Resolvedor DoH ---
HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': random.choice(USER_AGENTS),
    'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate, br', 'Connection': 'keep-alive',
    'Accept-Language': random.choice(ACCEPT_LANGUAGES)
})

class DoHResolver:
    def __init__(self, resolver_urls=None, cache_ttl=300, retries=2, retry_delay=0.7):
        self.resolver_urls = resolver_urls or ['https://chrome.cloudflare-dns.com/dns-query', 'https://dns.google/dns-query']
        self.cache_ttl = cache_ttl
        self.retries = retries
        self.retry_delay = retry_delay
        self._cache = {}
        self.q_types = ('AAAA', 'A') if ENABLE_IPV6 else ('A',)
        logging.debug(f"DoHResolver initialized with resolvers: {self.resolver_urls}, IPv6 enabled: {ENABLE_IPV6}")

    def resolve(self, hostname, depth=0, max_depth=5):
        if depth > max_depth:
            logging.error(f"Max CNAME resolution depth reached for {hostname}. Aborting DNS resolution.")
            return None
        if self._is_valid_ip(hostname):
            logging.debug(f"Hostname {hostname} is already an IP address.")
            return hostname

        cached_entry = self._cache.get(hostname)
        if cached_entry and time.time() < cached_entry[1]:
            logging.debug(f"Hostname {hostname} found in DoH cache: {cached_entry[0]}")
            return cached_entry[0]
        
        logging.debug(f"Attempting to resolve hostname {hostname} via DoH (depth: {depth})")
        for resolver_url in self.resolver_urls:
            for q_type in self.q_types:
                for attempt in range(self.retries):
                    try:
                        params = {'name': hostname, 'type': q_type}
                        headers = {'accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                        response = HTTP_SESSION.get(resolver_url, params=params, headers=headers, timeout=5)
                        response.raise_for_status()
                        data = response.json()
                        ip_address = self._parse_doh_response(data, hostname, q_type, depth)
                        if ip_address:
                            ttl = data.get("Answer", [{}])[0].get("TTL", self.cache_ttl)
                            self._cache[hostname] = (ip_address, time.time() + ttl)
                            logging.debug(f"Successfully resolved {hostname} to {ip_address} (TTL: {ttl}s) using {resolver_url} for type {q_type}.")
                            return ip_address
                    except Exception as e:
                        logging.warning(f"DoH resolution attempt {attempt + 1}/{self.retries} for {hostname} (type {q_type}) via {resolver_url} failed: {e}")
                        if attempt < self.retries - 1:
                            time.sleep(jitter(self.retry_delay))
                        else:
                            continue # Try next q_type or resolver
        logging.warning(f"Failed to resolve hostname {hostname} after all attempts.")
        return None

    def _parse_doh_response(self, data, hostname, q_type, depth):
        type_map = {'A': 1, 'AAAA': 28}
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map[q_type] and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data")
        # Handle CNAME
        for answer in data.get("Answer", []):
            if answer.get("type") == 5: # CNAME record type
                cname = answer.get("data", "").rstrip('.')
                if cname:
                    logging.debug(f"Found CNAME for {hostname}: {cname}. Resolving CNAME.")
                    return self.resolve(cname, depth + 1)
        return None

    @staticmethod
    def _is_valid_ip(address):
        try:
            socket.inet_pton(socket.AF_INET6, address)
            return True
        except socket.error:
            try:
                socket.inet_aton(address)
                return True
            except socket.error:
                return False

# --- Classes de Cache (RAM e Disco) ---
class BaseCache:
    def __init__(self, max_bytes):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        logging.info(f"BaseCache initialized with max_bytes: {max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url): raise NotImplementedError
    def add(self, url, data): raise NotImplementedError
    def clear(self): raise NotImplementedError
    def get_stats(self): raise NotImplementedError

class RotatingChunkCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES):
        super().__init__(max_bytes)
        self.chunks = OrderedDict()
        self.total_bytes = 0
        logging.info(f"RotatingChunkCache (RAM) initialized with max size: {max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url):
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
                logging.debug(f"Segment found in RAM cache: {url}")
            return data

    def add(self, url, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
            self.chunks[url] = data
            self.total_bytes += len(data)
            self._shrink_to_limit()
            logging.debug(f"Segment added to RAM cache: {url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
    
    def _shrink_to_limit(self):
        while self.total_bytes > self.max_bytes and self.chunks:
            old_url, old_data = self.chunks.popitem(last=False)
            self.total_bytes -= len(old_data)
            logging.debug(f"Shrinking RAM cache: removed {old_url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0
            logging.info("RAM cache cleared.")
            
    def get_stats(self):
        with self.lock:
            return {"entries": len(self.chunks), "size_MB": round(self.total_bytes / 1048576, 2)}

class PersistentRotatingCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES):
        super().__init__(max_bytes)
        self.cache_dir = os.path.join(ADDON_PROFILE, 'cache')
        logging.info(f"PersistentRotatingCache (Disk) initialized. Cache directory: {self.cache_dir}. Max size: {max_bytes / (1024 * 1024):.2f} MB")
        self._ensure_cache_dir()
        self.metadata = OrderedDict()
        self.total_bytes = 0
        self._load_metadata()

    def _ensure_cache_dir(self):
        if not xbmcvfs.exists(self.cache_dir):
            try:
                xbmcvfs.mkdirs(self.cache_dir)
                logging.info(f"Created cache directory: {self.cache_dir}")
            except Exception as e:
                logging.error(f"Failed to create cache directory {self.cache_dir}: {e}", exc_info=True)
                notify(f"Erro: Não foi possível criar pasta de cache em {self.cache_dir}. Verifique permissões.", 7000)
                raise
        # Verifica permissões de escrita
        test_file = os.path.join(self.cache_dir, '.test_write_permission')
        try:
            with xbmcvfs.File(test_file, 'w') as f:
                f.write(b'test')
            xbmcvfs.delete(test_file)
            logging.debug(f"Cache directory {self.cache_dir} is writable.")
        except Exception as e:
            logging.error(f"Cache directory {self.cache_dir} is not writable: {e}", exc_info=True)
            notify(f"Erro: A pasta de cache '{self.cache_dir}' não é gravável. O cache em disco não funcionará.", 7000)
            raise

    def _load_metadata(self):
        files, _ = xbmcvfs.listdir(self.cache_dir)
        for f in files:
            if f.startswith('.'): continue # Ignora arquivos de sistema/teste
            filepath = os.path.join(self.cache_dir, f)
            try:
                stat = xbmcvfs.Stat(filepath)
                self.metadata[f] = {'size': stat.st_size(), 'atime': stat.st_atime()}
                self.total_bytes += stat.st_size()
            except Exception as e:
                logging.warning(f"Skipping invalid or inaccessible cache file: {filepath} ({e})")
                try: xbmcvfs.delete(filepath)
                except Exception: pass # Tenta deletar se não conseguir ler
        sorted_meta = sorted(self.metadata.items(), key=lambda item: item[1]['atime'])
        self.metadata = OrderedDict(sorted_meta)
        logging.info(f"Loaded disk cache metadata. Total entries: {len(self.metadata)}, Total size: {self.total_bytes / (1024 * 1024):.2f} MB")
        self._shrink_to_limit()

    def _url_to_filepath(self, url):
        filename = hashlib.sha256(url.encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, filename), filename

    def get(self, url):
        filepath, filename = self._url_to_filepath(url)
        with self.lock:
            if filename in self.metadata:
                try:
                    with xbmcvfs.File(filepath, 'rb') as f:
                        content = f.readBytes()
                    self.metadata.move_to_end(filename)
                    self.metadata[filename]['atime'] = time.time() # Atualiza tempo de acesso
                    logging.debug(f"Segment found in disk cache: {url}")
                    return content
                except Exception as e:
                    logging.error(f"Failed to read segment from disk cache: {filepath} ({e})", exc_info=True)
                    self.metadata.pop(filename, None) # Remove entrada inválida
                    try: xbmcvfs.delete(filepath)
                    except Exception: pass
        return None

    def add(self, url, data: bytes):
        filepath, filename = self._url_to_filepath(url)
        with self.lock:
            if filename in self.metadata:
                self.total_bytes -= self.metadata[filename]['size']
                # Remove o arquivo antigo para garantir que não haja sobras de tamanho diferente
                try: xbmcvfs.delete(filepath)
                except Exception as e: logging.warning(f"Could not delete old cache file {filepath}: {e}")

            try:
                with xbmcvfs.File(filepath, 'wb') as f:
                    f.write(data)
                self.metadata[filename] = {'size': len(data), 'atime': time.time()}
                self.total_bytes += len(data)
                self._shrink_to_limit()
                logging.debug(f"Segment added to disk cache: {url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
            except Exception as e:
                logging.error(f"Failed to write segment to disk cache: {filepath} ({e})", exc_info=True)
                # Remove a entrada de metadados se a escrita falhar
                self.metadata.pop(filename, None)
                try: xbmcvfs.delete(filepath)
                except Exception: pass

    def _shrink_to_limit(self):
        while self.total_bytes > self.max_bytes and self.metadata:
            filename, meta = self.metadata.popitem(last=False)
            self.total_bytes -= meta['size']
            try:
                filepath_to_delete = os.path.join(self.cache_dir, filename)
                xbmcvfs.delete(filepath_to_delete)
                logging.debug(f"Shrinking disk cache: removed {filepath_to_delete}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
            except Exception as e:
                logging.error(f"Failed to delete old cache file {filename}: {e}", exc_info=True)
                # Se não conseguiu deletar o arquivo, ainda assim remove do metadata para não travar a lógica
                pass
            
    def clear(self):
        with self.lock:
            logging.info("Clearing disk cache...")
            for filename in list(self.metadata.keys()):
                try:
                    xbmcvfs.delete(os.path.join(self.cache_dir, filename))
                    logging.debug(f"Deleted cache file: {filename}")
                except Exception as e:
                    logging.warning(f"Could not delete disk cache file {filename}: {e}")
            self.metadata.clear()
            self.total_bytes = 0
            logging.info("Disk cache cleared.")

    def get_stats(self):
        with self.lock:
            return {"entries": len(self.metadata), "size_MB": round(self.total_bytes / 1048576, 2)}

class StreamCache:
    def __init__(self, chunk_cache: BaseCache):
        self.manifest_cache = {}
        self.chunk_cache = chunk_cache
        logging.info("StreamCache initialized.")
        
    def get_manifest(self, url):
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            logging.debug(f"Manifest found in RAM cache: {url}")
            return entry['content']
        logging.debug(f"Manifest not found or expired in RAM cache: {url}")
        return None
        
    def add_manifest(self, url, content, ttl=1):
        self.manifest_cache[url] = {'content': content, 'expires': time.time() + ttl}
        logging.debug(f"Manifest added to RAM cache: {url} with TTL {ttl}s.")
        
    def get_segment(self, url): return self.chunk_cache.get(url)
    def add_segment(self, url, data): self.chunk_cache.add(url, data)
    def clear(self):
        self.manifest_cache.clear()
        self.chunk_cache.clear()
        logging.info("Stream cache (manifests and chunks) cleared.")

# --- Classes Refatoradas (Fetcher e Rewriter) ---
class UpstreamFetcher:
    def __init__(self, session, doh_resolver):
        self.session = session
        self.doh_resolver = doh_resolver
        logging.info("UpstreamFetcher initialized.")

    def fetch(self, url, stream=False, original_headers=None):
        try:
            headers = random_player_headers(url)
            # Prioriza cabeçalhos Authorization e Cookie do player Kodi, se existirem
            if original_headers:
                if 'Authorization' in original_headers: headers['Authorization'] = original_headers['Authorization']
                if 'Cookie' in original_headers: headers['Cookie'] = original_headers['Cookie']
            
            parsed_url = urllib.parse.urlparse(url)
            resolved_ip = None
            if parsed_url.hostname: # Garante que há um hostname para resolver
                resolved_ip = self.doh_resolver.resolve(parsed_url.hostname)
            
            req_url = url
            if resolved_ip and resolved_ip != parsed_url.hostname: # Só reescreve se o IP for diferente
                req_url = url.replace(parsed_url.hostname, resolved_ip, 1)
                headers['Host'] = parsed_url.hostname # Mantém o cabeçalho Host original
                logging.debug(f"URL rewritten from {url} to {req_url} using resolved IP {resolved_ip} with Host header {parsed_url.hostname}.")
            else:
                logging.debug(f"Fetching {url}. No IP resolution applied or hostname is already an IP.")

            for attempt in range(3): # Mantém 3 tentativas de requisição
                try:
                    resp = self.session.get(req_url, stream=stream, timeout=(jitter(CONNECTION_TIMEOUT), jitter(STREAM_TIMEOUT)), headers=headers, allow_redirects=True)
                    resp.raise_for_status()
                    logging.debug(f"Successfully fetched {url} (status: {resp.status_code}). Attempt {attempt + 1}/3.")
                    return resp
                except Timeout:
                    logging.warning("Attempt %d/%d failed with timeout for %s", attempt + 1, 3, url)
                except ConnectionError as e:
                    logging.warning("Attempt %d/%d failed with connection error for %s: %s", attempt + 1, 3, url, e)
                except HTTPError as e:
                    if e.response.status_code in [401, 403, 404]:
                        logging.error("Access denied/not found (%d) for %s. Aborting retries.", e.response.status_code, url)
                        return e.response # Retorna a resposta de erro para que o handler possa enviá-la
                    logging.warning("Attempt %d/%d failed with HTTP error %d for %s", attempt + 1, 3, e.response.status_code, url)
                
                if attempt < 2:
                    delay = 0.5 * (attempt + 1) # Aumenta o delay para cada tentativa
                    logging.debug(f"Waiting {delay} seconds before retrying {url}.")
                    time.sleep(delay)
            
            logging.error(f"Failed to fetch {url} after 3 attempts.")
            return None
        except Exception as ex:
            logging.error("Unhandled error fetching url %s: %s", url, str(ex), exc_info=True)
            return None

class ManifestRewriter:
    def __init__(self, content, manifest_url, proxy_base_url):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        logging.debug(f"ManifestRewriter initialized for {manifest_url}. Proxy base: {proxy_base_url}")

    def rewrite(self):
        # Rewrite playlists
        for playlist in getattr(self.m3u8_obj, 'playlists', []):
            if playlist.uri:
                original_uri = playlist.absolute_uri
                playlist.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote playlist URI from {original_uri} to {playlist.uri}")
        
        # Rewrite media (subtitles, audio, etc.)
        for media in getattr(self.m3u8_obj, 'media', []):
            if hasattr(media, 'uri') and media.uri:
                original_uri = media.absolute_uri
                media.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote media URI from {original_uri} to {media.uri}")

        # Rewrite segments and keys
        for segment in getattr(self.m3u8_obj, 'segments', []):
            if segment.uri:
                original_uri = segment.absolute_uri
                segment.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote segment URI from {original_uri} to {segment.uri}")
            if segment.key and segment.key.uri:
                original_uri = segment.key.absolute_uri
                segment.key.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote key URI from {original_uri} to {segment.key.uri}")
        
        rewritten_manifest = self.m3u8_obj.dumps()
        logging.debug(f"Manifest rewritten successfully. First 200 chars: {rewritten_manifest[:200]}")
        return rewritten_manifest

    @property
    def is_live(self):
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self):
        target_duration = getattr(self.m3u8_obj, 'target_duration', 0)
        if self.is_live and target_duration:
            # Para streams ao vivo, TTL é um pouco menor que o target_duration
            ttl = max(1, int(target_duration * 0.75)) # 75% do target duration
            logging.debug(f"Live stream detected. Target duration: {target_duration}s, calculated TTL: {ttl}s.")
            return ttl
        logging.debug("VOD stream detected or no target duration. Default TTL: 600s.")
        return 600 # Default para VOD (10 minutos)

# --- Handler do Proxy e Funções Auxiliares ---
def notify(msg, time_ms=3000): xbmc.executebuiltin(f'Notification[{ADDON_NAME},{msg},{time_ms}]')

def validate_url(url: str) -> bool:
    u = urllib.parse.urlparse(url)
    if not u.scheme in ('http', 'https'):
        logging.warning(f"Invalid URL scheme for {url}. Must be http or https.")
        return False
    if not u.netloc:
        logging.warning(f"URL has no network location (netloc): {url}.")
        return False
    if u.hostname in USER_BLOCKLIST:
        logging.warning(f"Hostname {u.hostname} is in the user blocklist for URL: {url}.")
        return False
    return True

def safe_mime_type(url, fallback='application/octet-stream'):
    ext = url.lower().split('?')[0]
    if ext.endswith('.m3u8'): return 'application/vnd.apple.mpegurl'
    if ext.endswith('.ts'): return 'video/mp2t'
    logging.debug(f"Could not determine specific MIME type for {url}. Using fallback: {fallback}")
    return fallback

def is_port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('127.0.0.1', port))
            return True
        except socket.error:
            return False

class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, stream_cache, fetcher, *args, **kwargs):
        self.cache = stream_cache
        self.fetcher = fetcher
        # Para que o logging do http.server não polua, mas ainda possamos logar
        self.log_level_map = {
            'info': logging.info,
            'warning': logging.warning,
            'error': logging.error,
            'debug': logging.debug
        }
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        # Desabilita o log padrão do http.server.BaseHTTPRequestHandler
        pass
        
    def _log_request(self, message, level='info'):
        # Adiciona log personalizado para requisições do proxy
        log_func = self.log_level_map.get(level, logging.info)
        client_address = self.address_string()
        log_func(f"[{client_address}] {self.command} {self.path} - {message}")

    def do_GET(self):
        self._log_request("Received request", level='debug')
        if PROXY_TOKEN and self.headers.get('X-Proxy-Token') != PROXY_TOKEN:
            self.send_response(401)
            self.end_headers()
            self._log_request("Unauthorized request due to missing/invalid X-Proxy-Token.", level='warning')
            return

        try:
            parsed_path = urllib.parse.urlparse(self.path)
            original_url = urllib.parse.unquote_plus(parsed_path.path.lstrip('/'))
            
            if not validate_url(original_url):
                self.send_error(400, "Invalid URL in proxy request")
                self._log_request(f"Invalid URL: {original_url}", level='warning')
                return

            if SIMULATE_ERRORS and random.random() < 0.008:
                self.send_error(503, "Service Unavailable (simulated)")
                self._log_request(f"Simulated 503 error for {original_url}", level='warning')
                return

            if ".m3u8" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except BrokenPipeError:
            self._log_request(f"BrokenPipeError while serving {original_url}", level='warning')
        except Exception as ex:
            logging.error("General proxy error for %s: %s", original_url, str(ex), exc_info=True)
            if not self.wfile.closed:
                try: self.send_error(500, "Internal Server Error")
                except Exception: pass

    def _handle_manifest(self, url):
        self._log_request(f"Handling manifest: {url}", level='info')
        cached = self.cache.get_manifest(url)
        if cached:
            self._log_request(f"Serving manifest from cache: {url}", level='debug')
            return self._send_response(200, cached, 'application/vnd.apple.mpegurl')

        response = self.fetcher.fetch(url, original_headers=self.headers)
        if not response or not response.ok:
            status_code = response.status_code if response else 502
            self.send_error(status_code, "Bad Gateway or Upstream Error")
            self._log_request(f"Failed to fetch manifest {url} from upstream. Status: {status_code}", level='error')
            return

        try:
            rewriter = ManifestRewriter(response.text, response.url, f"http://{PROXY_HOST}:{self.server.server_address[1]}/")
            rewritten_content = rewriter.rewrite()
            ttl = rewriter.get_ttl()
            self.cache.add_manifest(url, rewritten_content, ttl=ttl)
            self._log_request(f"Manifest {url} fetched, rewritten, cached (TTL: {ttl}s) and served.", level='info')
            self._send_response(200, rewritten_content, 'application/vnd.apple.mpegurl')
        except Exception as e:
            logging.error(f"Error processing manifest {url}: {e}", exc_info=True)
            self.send_error(500, "Error processing manifest")


    def _handle_segment(self, url):
        self._log_request(f"Handling segment: {url}", level='info')
        mime_type = safe_mime_type(url)
        cached = self.cache.get_segment(url)
        if cached:
            self._log_request(f"Serving segment from cache: {url}", level='debug')
            return self._send_response(200, cached, mime_type)

        response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
        if not response or not response.ok:
            status_code = response.status_code if response else 404
            self.send_error(status_code, "Segment Not Found or Upstream Error")
            self._log_request(f"Failed to fetch segment {url} from upstream. Status: {status_code}", level='error')
            return

        try:
            self.send_response(response.status_code)
            for h, v in response.headers.items():
                if h.lower() not in ('transfer-encoding', 'connection', 'content-encoding', 'content-length'): # Removed content-length as we stream
                    self.send_header(h, v)
            self.send_header("Access-Control-Allow-Origin", "*")
            # Adiciona cabeçalho Cache-Control para segments que não devem ser cacheados pelo cliente (só pelo proxy)
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0')
            self.end_headers()

            data = bytearray()
            bytes_sent = 0
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk: continue
                self.wfile.write(chunk)
                data.extend(chunk)
                bytes_sent += len(chunk)
            
            self._log_request(f"Segment {url} streamed to client. Total bytes sent: {bytes_sent}.", level='debug')
            
            if len(data) <= MAX_SEGMENT_SIZE_BYTES:
                self.cache.add_segment(url, bytes(data))
                self._log_request(f"Segment {url} (size: {len(data)} bytes) added to cache.", level='debug')
            else:
                self._log_request(f"Segment {url} (size: {len(data)} bytes) exceeded MAX_SEGMENT_SIZE_BYTES ({MAX_SEGMENT_SIZE_BYTES} bytes) and was NOT cached.", level='info')

        except BrokenPipeError:
            self._log_request(f"BrokenPipeError while streaming segment {url}. Client disconnected.", level='warning')
        except Exception as ex:
            logging.error("Error serving segment %s: %s", url, str(ex), exc_info=True)
            if not self.wfile.closed:
                try: self.send_error(500, "Internal Server Error during segment streaming")
                except Exception: pass

    def _send_response(self, code, content, content_type):
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        try:
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(encoded)))
            self.send_header('Cache-Control', 'no-store') # Manifests and cached segments should not be cached by player
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(encoded)
            self._log_request(f"Response sent (code: {code}, type: {content_type}, size: {len(encoded)} bytes).", level='debug')
        except BrokenPipeError:
            self._log_request(f"BrokenPipeError while sending response for {content_type}. Client disconnected.", level='warning')
        except Exception as ex:
            logging.error("Error sending response: %s", str(ex), exc_info=True)

# --- Gerenciador do Proxy e Integração com Kodi ---
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self.doh_resolver = DoHResolver()
        
        if CACHE_TYPE == 'disk':
            try:
                self.chunk_cache = PersistentRotatingCache(MAX_CACHE_SIZE_BYTES)
                logging.info("Using persistent DISK cache.")
            except Exception as e:
                logging.error(f"Failed to initialize persistent disk cache. Falling back to RAM cache: {e}")
                notify("Erro ao iniciar cache em disco. Usando cache em RAM.", 5000)
                self.chunk_cache = RotatingChunkCache(MAX_CACHE_SIZE_BYTES)
                logging.info("Falling back to in-memory RAM cache.")
        else:
            self.chunk_cache = RotatingChunkCache(MAX_CACHE_SIZE_BYTES)
            logging.info("Using in-memory RAM cache.")
        
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(HTTP_SESSION, self.doh_resolver)
        logging.info("HLSProxyManager initialized.")

    def _acquire_lock(self):
        if xbmcvfs.exists(LOCK_FILE):
            logging.error(f"Lock file '{LOCK_FILE}' exists. Another instance of HLS Proxy might be running or previous one crashed.")
            # Sugestão de notificação para o usuário se o lock existir
            notify(f"Proxy HLS já em execução ou travado. Se o erro persistir, remova o arquivo: {LOCK_FILE}", 7000)
            return False
        try:
            with xbmcvfs.File(LOCK_FILE, 'w') as f:
                f.write(str(os.getpid()).encode('utf-8'))
            logging.info(f"Acquired lock file: {LOCK_FILE}")
            return True
        except Exception as e:
            logging.error(f"Failed to acquire lock {LOCK_FILE}: {e}", exc_info=True)
            notify(f"Erro fatal: Não foi possível criar arquivo de lock '{LOCK_FILE}'. Verifique permissões.", 7000)
            return False

    def _release_lock(self):
        try:
            if xbmcvfs.exists(LOCK_FILE):
                xbmcvfs.delete(LOCK_FILE)
                logging.info(f"Released lock file: {LOCK_FILE}")
        except Exception as e:
            logging.error(f"Failed to release lock {LOCK_FILE}: {e}", exc_info=True)

    def start(self):
        if not self._acquire_lock():
            return None
        self.stop() # Ensure any previous server is stopped clean
        
        handler_with_deps = functools.partial(AdvancedHLSProxyHandler, self.stream_cache, self.fetcher)
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            if not is_port_free(port):
                logging.warning(f"Port {port} is in use, trying another. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.")
                continue
            try:
                self.server = socketserver.TCPServer((PROXY_HOST, port), handler_with_deps)
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy started successfully on port {self.active_port}")
                notify(f"Proxy HLS iniciado na porta: {self.active_port}", 3000)
                return self.active_port
            except Exception as ex:
                logging.warning(f"Failed to start proxy on port {port}: {ex}. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.", exc_info=True)
                time.sleep(0.5) # Pequeno delay antes de tentar a próxima porta
        
        self._release_lock()
        logging.error(f"Failed to start HLS Proxy after {MAX_PORT_ATTEMPTS} attempts. No free port found or general error.")
        notify("Erro fatal: Não foi possível iniciar o proxy HLS. Nenhuma porta livre encontrada ou erro interno.", 7000)
        return None

    def stop(self):
        if self.server:
            logging.info(f"Stopping HLS Proxy on port {self.active_port}")
            try:
                self.server.shutdown()
                self.server.server_close()
                logging.debug("Proxy server shut down and closed.")
            except Exception as e:
                logging.error(f"Error during proxy server shutdown: {e}", exc_info=True)
            self.server = None
        
        if self.server_thread and self.server_thread.is_alive():
            logging.debug("Waiting for proxy server thread to join...")
            self.server_thread.join(timeout=3) # Increased timeout to 3 seconds
            if self.server_thread.is_alive():
                logging.warning("Proxy server thread did not terminate gracefully.")
            else:
                logging.debug("Proxy server thread joined successfully.")
        
        self.stream_cache.clear()
        self.active_port = None
        self._release_lock()
        logging.info("HLS Proxy completely stopped and resources released.")
        
    def get_proxy_url(self, original_url):
        if not self.active_port: return None
        url_encoded = urllib.parse.quote_plus(original_url)
        # Usar um token no URL se PROXY_TOKEN estiver definido
        # Isso não é o que o cliente Kodi envia, o token vai no header X-Proxy-Token
        # A URL é apenas o path.
        # return f"http://{PROXY_HOST}:{self.active_port}/{url_encoded}" # Linha original
        return f"http://{PROXY_HOST}:{self.active_port}/{url_encoded}"


class CustomPlayer(xbmc.Player):
    def onPlayBackStarted(self): # Adiciona log quando a reprodução começa
        logging.info("Kodi playback started.")
        HLSProxyAddon.playback_active = True
    def onPlayBackEnded(self):
        logging.info("Kodi playback ended.")
        HLSProxyAddon.playback_active = False
    def onPlayBackError(self):
        logging.error("Kodi playback error occurred.")
        HLSProxyAddon.playback_active = False
    def onPlayBackStopped(self):
        logging.info("Kodi playback stopped by user.")
        HLSProxyAddon.playback_active = False

class HLSProxyAddon:
    playback_active = False
    
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.player = CustomPlayer()
        logging.info("HLSProxyAddon instance created.")

    def play_stream(self, url):
        logging.info(f"Attempting to play stream: {url}")
        port = self.proxy_manager.start()
        if not port:
            notify("Erro fatal ao iniciar proxy local. Verifique os logs.", 5000)
            logging.error("Failed to start proxy, cannot resolve URL for Kodi.")
            return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            
        proxy_url = self.proxy_manager.get_proxy_url(url)
        if PROXY_TOKEN:
            # O Kodi não tem uma forma direta de adicionar headers a URLs de reprodução por ListItem
            # O proxy handler precisa verificar o token de alguma outra forma ou confiar na rede local.
            # Para este cenário, o token no header HTTPRequestHandler (X-Proxy-Token) é a melhor abordagem.
            # O `UpstreamFetcher` passa os `original_headers` para o servidor remoto, mas o Kodi não
            # manda `X-Proxy-Token` para o proxy local.
            # Se o proxy_token for estritamente necessário para o proxy local, ele teria que ser parte da URL,
            # o que pode ser indesejável (ex: ?token=XYZ).
            # Para o contexto de um proxy local, confiar que a requisição vem do próprio Kodi na máquina local
            # já é uma boa medida de segurança. O check de token foi mantido no handler, mas saiba que
            # não é trivial para o Kodi enviar este header para um proxy local via setResolvedUrl.
            logging.warning("PROXY_TOKEN is configured but Kodi's setResolvedUrl doesn't directly support custom headers for local proxy. The token check in handler will likely fail if it expects a header from Kodi itself.")

        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType(safe_mime_type(url))
        # Adiciona o token de proxy como uma propriedade, se necessário para o Player,
        # mas a forma como o token é usado (X-Proxy-Token header) já é controlada no proxy handler.
        if PROXY_TOKEN:
            list_item.setProperty('X-Proxy-Token', PROXY_TOKEN) # Esta propriedade NÃO é enviada pelo Kodi para o proxy local

        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        logging.info(f"Kodi resolved URL to proxy: {proxy_url}")
        
        # Inicia o monitoramento em uma nova thread para não bloquear o thread principal do Kodi
        monitor_thread = threading.Thread(target=self.monitor_playback, daemon=True)
        monitor_thread.start()
        logging.debug("Playback monitor thread started.")


    def monitor_playback(self):
        HLSProxyAddon.playback_active = True
        
        logging.info("Starting playback monitoring...")
        # Espera inicial para a reprodução começar ou falhar
        initial_wait_seconds = 15
        for i in range(initial_wait_seconds):
            if not HLSProxyAddon.playback_active:
                logging.info(f"Playback stopped before starting (during initial {initial_wait_seconds}s wait).")
                break
            if self.player.isPlaying():
                logging.info(f"Playback detected after {i+1} seconds.")
                break
            time.sleep(1)
        
        if not self.player.isPlaying() and HLSProxyAddon.playback_active:
            logging.warning("Playback did not start within initial wait period. Assuming issue or very slow start.")
            # Não parar o proxy aqui, pode ser apenas um carregamento muito lento.
            # A flag `playback_active` será setada como False se onPlayBackError/Stopped for chamado.

        while HLSProxyAddon.playback_active:
            if not self.player.isPlaying():
                logging.info("Player reports not playing. Signalling end of playback monitoring.")
                HLSProxyAddon.playback_active = False # Player parou por algum motivo
                break
            
            stats = self.proxy_manager.chunk_cache.get_stats()
            max_size_mb = self.proxy_manager.chunk_cache.max_bytes / 1048576
            if stats["size_MB"] > 0.8 * max_size_mb: # Notifica a 80% do cache
                notify(f"Cache quase cheio: {stats['size_MB']:.1f}/{max_size_mb:.1f} MB", 2000)
                logging.debug(f"Cache usage alert: {stats['size_MB']:.1f}/{max_size_mb:.1f} MB.")

            time.sleep(5) # Verifica a cada 5 segundos
            
        logging.info("Playback finished or stopped. Releasing proxy resources.")
        self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Live Exemplo (Caminho da Web)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Big Buck Bunny (VOD - 1080p)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Apple Test HLS (Advanced)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"),
            ("Google Shaka Test (DRM-Free)", "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8")
        ]
        logging.info("Displaying test streams.")
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=name)
            li.setProperty('IsPlayable', 'true')
            li.setMimeType(safe_mime_type(url))
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            logging.debug(f"Added directory item: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url_to_play = params.get('url')
    
    addon = HLSProxyAddon()
    if action == 'play' and url_to_play:
        addon.play_stream(url_to_play)
    else:
        addon.show_test_streams()