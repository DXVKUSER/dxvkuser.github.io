# /plugin.video.youraddon/resources/lib/proxy.py
# --- PROXY HLS PARA KODI COM HARDENING ANTI-BLOQUEIO (versão final corrigida e mais tolerante) ---

import sys
import threading
import random
import logging
import logging.handlers
import urllib.parse
import time
import base64
from collections import OrderedDict
from typing import Optional, Dict
import warnings
import socket

# requests via DoH if disponível, senão requests normal
try:
    from doh_client import requests  # type: ignore
except Exception:
    import requests  # type: ignore

import requests.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import m3u8
from werkzeug.serving import make_server
from flask import Flask, request, Response, stream_with_context

# ---------------- Config ----------------
MAX_SEGMENT_RETRIES = 3
RETRY_BACKOFF_FACTOR = 0.5
CONNECTION_TIMEOUT = 5.0
STREAM_TIMEOUT = 30.0
DEFAULT_CHUNK_SIZE = 256 * 1024
MAX_CACHE_MB = 128
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
WATCHDOG_TIMEOUT = 25

USER_AGENTS = [
    "VLC/3.0.20 LibVLC/3.0.20 (X11; Linux x86_64)",
    "ExoPlayer/2.18.7 (Linux; Android 13)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "AppleCoreMedia/1.0.0.20G75 (iPhone; U; CPU OS 16_6 like Mac OS X; en_us)",
    "GStreamer/1.18.5",
    "Opera/9.80 (Android 4.0.4; Opera Mini/7.5.31885/29.3510; U; en) Presto/2.8.119 Version/11.10",
]

ACCEPT_LANG_POOL = [
    "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "pt-PT,pt;q=0.9,en;q=0.6",
    "en-US,en;q=0.9,pt-BR;q=0.8",
    "es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7",
]

X_REQUESTED_WITH_POOL = [
    "XMLHttpRequest", 
    "com.google.android.tv", 
    "org.videolan.vlc",
    "io.github.palexdev.dev",
    "com.kodi.kodi",
]

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
LOG_FILE = "hlsproxy_iptv_hardened.log"

# ---------------- Logging ----------------

def setup_logging():
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    logging.basicConfig(
        handlers=[handler, logging.StreamHandler(sys.stdout)],
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] (%(threadName)s) - %(message)s"
    )

# ---------------- Utils ----------------

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith((".m3u8", ".m3u")):
        return "application/vnd.apple.mpegurl"
    if path.endswith((".ts")) or "auth/" in path or "stream/" in path:
        return "video/mp2t"
    if path.endswith(".aac"):
        return "audio/aac"
    if path.endswith(".mp4"):
        return "video/mp4"
    return "application/octet-stream"

class RotatingCache:
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.store = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            item = self.store.get(url)
            if not item:
                return None
            data, expire = item
            if expire and expire < time.time():
                self._pop(url)
                return None
            self.store.move_to_end(url)
            return data

    def add(self, url: str, data: bytes, ttl: int):
        with self.lock:
            if url in self.store:
                self._pop(url)
            size = len(data)
            if size > self.max_bytes:
                return
            while self.total_bytes + size > self.max_bytes:
                self._popitem(last=False)
            expire = time.time() + ttl if ttl else None
            self.store[url] = (data, expire)
            self.total_bytes += size

    def _pop(self, url: str):
        if url in self.store:
            data, _ = self.store.pop(url)
            self.total_bytes -= len(data)

    def _popitem(self, last: bool):
        try:
            _, (data, _) = self.store.popitem(last=last)
            self.total_bytes -= len(data)
        except KeyError:
            pass

    def clear(self):
        with self.lock:
            self.store.clear()
            self.total_bytes = 0

# ---------------- Base64 helpers ----------------

def _b64e(s: str) -> str:
    return base64.urlsafe_b64encode(s.encode("utf-8")).decode("ascii")

def _b64d(s: str) -> str:
    return base64.urlsafe_b64decode(s.encode("ascii")).decode("utf-8")

# ---------------- Headers ----------------

def get_headers(self, url: str, original_url: Optional[str] = None, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    parsed_url = urllib.parse.urlparse(url)
    original_host = urllib.parse.urlparse(original_url).netloc if original_url else parsed_url.netloc
    
    headers = {
        "Host": parsed_url.netloc,
        "User-Agent": self.user_agent,
        "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "identity",
        "Accept-Language": self.accept_language,
        "Connection": "keep-alive",
        "Referer": f"http://{original_host}/",
        "Origin": f"http://{original_host}",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache",
        "X-Forwarded-For": self.fake_ip,
        "X-Real-IP": self.fake_ip,
        "X-Requested-With": self.x_requested_with,
        "DNT": "1",
    }
    
    # Adiciona o X-Forwarded-Host para compatibilidade com CDNs
    if original_host:
        headers["X-Forwarded-Host"] = original_host

    if extra:
        headers.update(extra)
    return headers

# ---------------- Proxy Manager ----------------

class IPTVHLSProxyManager:
    def __init__(self):
        self.cache = RotatingCache()
        self.active_port: Optional[int] = None
        self.server = None
        self.server_thread: Optional[threading.Thread] = None
        self.lock = threading.Lock()

        self.user_agent = None
        self.fake_ip = None
        self.accept_language = None
        self.x_requested_with = None
        self.session = self._create_session()

        self.jitter_min_ms = 120
        self.jitter_max_ms = 420
        self.watchdog_thread = None
        self.last_activity = time.time()

        self.app = self._create_flask_app()

    def _randomize_headers(self):
        self.user_agent = random.choice(USER_AGENTS)
        self.fake_ip = f"{random.randint(1, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 255)}"
        self.accept_language = random.choice(ACCEPT_LANG_POOL)
        self.x_requested_with = random.choice(X_REQUESTED_WITH_POOL)

    def full_restart(self, reason: str):
        with self.lock:
            logging.warning("Reiniciando COMPLETAMENTE proxy e sessão HTTP (%s)", reason)
            try:
                self.stop()
            except Exception:
                logging.exception("Erro ao parar o servidor durante full_restart")
            try:
                self.cache.clear()
            except Exception:
                logging.exception("Erro ao limpar cache durante full_restart")
            
            self._randomize_headers()
            self.session = self._create_session()
            
            try:
                self.start()
            except Exception:
                logging.exception("Erro ao reiniciar o servidor durante full_restart")

    def force_reconnect(self, reason: str = "Unknown"):
        self.full_restart(reason)

    def _watchdog_loop(self):
        while True:
            if self.server is None:
                break
            try:
                if time.time() - self.last_activity > WATCHDOG_TIMEOUT:
                    logging.info("Watchdog: sem atividade por %s segundos, reiniciando.", WATCHDOG_TIMEOUT)
                    self.full_restart("Watchdog timeout sem tráfego")
                    break
            except Exception:
                logging.exception("Erro no watchdog loop")
            time.sleep(5)

    def _create_flask_app(self):
        app = Flask("IPTVHLSProxy")

        @app.route("/", methods=["GET"])
        def proxy():
            self.last_activity = time.time()
            url_q = request.args.get("url")
            orig_q = request.args.get("original_url")
            u_b64 = request.args.get("u")
            o_b64 = request.args.get("o")

            try:
                if u_b64:
                    decoded_url = _b64d(u_b64)
                elif url_q:
                    decoded_url = urllib.parse.unquote_plus(url_q)
                else:
                    return Response("Missing 'url' or 'u' parameter", 400)

                if o_b64:
                    decoded_original_url = _b64d(o_b64)
                elif orig_q:
                    decoded_original_url = urllib.parse.unquote_plus(orig_q)
                else:
                    decoded_original_url = decoded_url

                if decoded_url.endswith((".m3u8", ".m3u")):
                    return self.handle_manifest(decoded_url, decoded_original_url)
                else:
                    return self.handle_segment_stream(decoded_url, decoded_original_url)
            except Exception:
                logging.exception("Erro no endpoint proxy")
                return Response("Internal proxy error", status=500)

        return app

    def _create_session(self):
        session = requests.Session()
        retry_strategy = Retry(
            total=MAX_SEGMENT_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=[401, 403, 429, 500, 502, 503, 504, 520, 521, 522],
            allowed_methods=["HEAD", "GET", "OPTIONS"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def _make_request(self, url: str, method: str = "GET", original_url: Optional[str] = None, headers=None, **kwargs):
        kwargs['allow_redirects'] = False
        try:
            r = self.session.request(method, url, headers=get_headers(self, url, original_url, extra=headers), **kwargs)
            
            # Trata redirecionamentos manualmente
            if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get('Location')
                if location:
                    new_url = urllib.parse.urljoin(url, location)
                    r.close()
                    logging.info("Redirecionando de %s para %s", _b64e(url), _b64e(new_url))
                    return self._make_request(new_url, method, original_url, headers, **kwargs)
            return r
        except requests.exceptions.RequestException as e:
            logging.error("Request exception for %s: %s", _b64e(url), e)
            raise

    def handle_manifest(self, url: str, original_url: str) -> Response:
        try:
            logging.info("Buscando manifesto: %s", _b64e(url))
            r = self._make_request(url, method="GET", timeout=CONNECTION_TIMEOUT, original_url=original_url)
            r.raise_for_status()
            content = r.text
            final_url = r.url
            logging.info("Manifesto carregado com sucesso, status: %d", r.status_code)
        except Exception:
            logging.exception("Falha ao carregar manifesto %s", _b64e(url))
            self.full_restart("Falha manifesto principal")
            return Response("#EXTM3U\n#EXT-X-ERROR: Could not load manifest\n", status=502, mimetype="application/vnd.apple.mpegurl")

        try:
            base = f"http://{PROXY_HOST}:{self.active_port}/?u="
            orig_param = lambda s: f"&o={_b64e(s)}"
            encode = lambda s: _b64e(s)

            m3u8_obj = m3u8.loads(content, uri=final_url)

            if m3u8_obj.is_variant:
                for playlist in m3u8_obj.playlists:
                    playlist.uri = base + encode(playlist.absolute_uri) + orig_param(original_url)

            for segment in m3u8_obj.segments:
                segment.uri = base + encode(segment.absolute_uri) + orig_param(original_url)
                if segment.key and segment.key.uri:
                    segment.key.uri = base + encode(segment.key.absolute_uri) + orig_param(original_url)

            proxied_playlist = m3u8_obj.dumps().encode("utf-8")
            self.last_activity = time.time()
            return Response(proxied_playlist, mimetype="application/vnd.apple.mpegurl")
        except Exception:
            logging.exception("Erro ao reescrever manifesto %s", _b64e(url))
            return Response("#EXTM3U\n#EXT-X-ERROR: Playlist processing error\n", status=500, mimetype="application/vnd.apple.mpegurl")

    def handle_segment_stream(self, url: str, original_url: str) -> Response:
        def generate():
            try:
                logging.info("Buscando segmento: %s", _b64e(url))
                r = self._make_request(
                    url,
                    method="GET",
                    stream=True,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    original_url=original_url,
                )
                
                # Permite erros 404 para segmentos, que são comuns em streams ao vivo
                if r.status_code == 404:
                    logging.warning("Segmento não encontrado (404), pulando: %s", _b64e(url))
                    yield b"" # Retorna um chunk vazio para o Kodi, que tentará o próximo segmento
                    return

                r.raise_for_status()
                logging.info("Segmento carregado com sucesso, status: %d", r.status_code)
                
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.last_activity = time.time()
                        yield chunk
                r.close()
            except requests.exceptions.HTTPError as e:
                # Trata erros HTTP específicos sem reiniciar completamente
                logging.error("Erro HTTP ao buscar segmento %s: %s", _b64e(url), e)
                if e.response.status_code in [401, 403]:
                    logging.warning("Erro de autenticação/acesso. Tentando full_restart.")
                    self.full_restart("Erro 401/403 no segmento")
            except Exception:
                # Reinicia a sessão apenas para falhas críticas de conexão, não para erros 404
                logging.exception("Falha CRÍTICA ao buscar segmento %s", _b64e(url))
                try:
                    self.full_restart("Falha segmento crítico")
                except Exception:
                    logging.exception("Erro ao tentar full_restart após falha de segmento")
        
        return Response(stream_with_context(generate()), mimetype=safe_mime_type(url), status=200)

    def start(self) -> Optional[int]:
        try:
            self.stop()
        except Exception:
            logging.exception("Erro ao parar instancia existente antes de start")

        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = make_server(PROXY_HOST, port, self.app, threaded=True)
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                self.active_port = port
                self._randomize_headers()
                self.last_activity = time.time()
                try:
                    self.watchdog_thread = threading.Thread(target=self._watchdog_loop, daemon=True)
                    self.watchdog_thread.start()
                except Exception:
                    logging.exception("Não foi possível iniciar watchdog thread")
                logging.info("Proxy iniciado em http://%s:%s", PROXY_HOST, port)
                return port
            except OSError:
                continue
            except Exception:
                logging.exception("Erro ao iniciar proxy")
                continue
        logging.error("Falha ao iniciar proxy: nenhuma porta disponível.")
        return None

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
            except Exception:
                logging.exception("Erro ao dar shutdown no servidor")
        if self.server_thread and self.server_thread.is_alive():
            try:
                self.server_thread.join(timeout=1)
            except Exception:
                logging.exception("Erro aguardando server_thread join")
        self.server = None
        self.server_thread = None
        self.active_port = None

# ---------------- Kodi Addon Integration ----------------

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = IPTVHLSProxyManager()

    def play_stream(self, url: str, title: Optional[str] = None):
        try:
            self.proxy.stop()
            self.proxy.cache.clear()

            if not self.proxy.start():
                import xbmcgui
                import xbmcplugin
                xbmcgui.Dialog().ok("Erro Proxy IPTV", "Não foi possível iniciar o servidor proxy.")
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return

            b64u = _b64e(url)
            proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?u={b64u}&o={b64u}"

            import xbmcgui
            import xbmcplugin
            li = xbmcgui.ListItem(path=proxy_url, label=title or "GIF PEG TV PLUS")
            li.setProperty("IsPlayable", "true")
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("IsLive", "true")

            xbmcplugin.setResolvedUrl(self.handle, True, li)
            logging.info("Reprodução iniciada via proxy: %s", _b64e(proxy_url))
        except Exception:
            logging.exception("Erro em play_stream")
            try:
                import xbmcgui
                xbmcgui.Dialog().ok("Erro Proxy IPTV", "Erro ao tentar reproduzir stream via proxy. Verifique os logs para mais detalhes.")
            except Exception:
                pass

    def show_test_streams(self):
        try:
            import xbmcgui
            import xbmcplugin
            test_streams = [
                ("Big Buck Bunny", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
                ("Elephants Dream", "https://d3u2k51g8x1l3w.cloudfront.net/a/master_elephantsdream.m3u8"),
            ]
            for name, url in test_streams:
                li = xbmcgui.ListItem(label=name)
                li.setProperty("IsPlayable", "true")
                plugin_url = f"plugin://{sys.argv[0]}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
                xbmcplugin.addDirectoryItem(self.handle, plugin_url, li, isFolder=False)
            xbmcplugin.endOfDirectory(self.handle)
        except Exception:
            logging.exception("Erro em show_test_streams")

# ---------------- Entrypoint ----------------

def main():
    setup_logging()
    try:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        addon = HLSProxyAddon(handle)
        action = params.get("action")
        if action == "play":
            url = params.get("url")
            title = params.get("title", "GIF PEG TV PLUS")
            if url:
                addon.play_stream(url, title)
            else:
                addon.show_test_streams()
        else:
            addon.show_test_streams()
    except Exception:
        logging.exception("Erro fatal no main do addon")

if __name__ == "__main__":
    main()