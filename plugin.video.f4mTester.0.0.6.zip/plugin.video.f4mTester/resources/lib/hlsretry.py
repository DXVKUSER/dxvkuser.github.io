# -*- coding: utf-8 -*-
import os
import requests
import six
if six.PY3:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, urljoin, quote_plus
    import queue  # Python 3
else:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from urlparse import urlparse, parse_qs, urljoin
    from urllib import quote, unquote, unquote_plus
    import Queue as queue  # Python 2
import threading
import time
import re
import logging
import collections
import json
import socket

# Configuração de logging para depuração (compatível com Kodi)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def log(msg):
    logger.info(msg)

# --- Configurações do Servidor Proxy ---
HOST_NAME = '127.0.0.1'
PORT_NUMBER = 55894 

# Definindo URLs do proxy
url_proxy_base = 'http://' + HOST_NAME + ':' + str(PORT_NUMBER)
url_proxy = url_proxy_base + '/proxy_m3u8?url='  # Para playlists M3U8
url_segment_proxy_prefix = url_proxy_base + '/proxy_segment/'  # Para segmentos TS
url_key_proxy_prefix = url_proxy_base + '/proxy_key/'  # Para chaves de criptografia
url_stop = url_proxy_base + '/stop'
url_reset = url_proxy_base + '/reset'
url_check = url_proxy_base + '/check'  # Adicionado para verificar o status do servidor

# --- Variáveis Globais para o Estado do Proxy ---
URL_BASE = ''  # Base da URL do conteúdo original (e.g., http://example.com/live/)
LAST_URL = ''  # Última URL de playlist original que foi proxyficada
HEADERS_BASE = {}  # Headers para usar nas requisições ao servidor de origem
STOP_SERVER = False  # Flag para sinalizar o encerramento do servidor
CACHE_M3U8 = ''  # Conteúdo da última playlist M3U8 proxyficada

# Variáveis relacionadas ao cache e pré-busca
SEGMENT_CACHE = collections.OrderedDict()  # Dicionário para armazenar segmentos: {url: content}
KEY_CACHE = collections.OrderedDict()  # Dicionário para armazenar chaves de criptografia: {url: key_content}
MAX_CACHE_SIZE_MB = 200  # Limite máximo de cache em MB (ajustável)
CURRENT_CACHE_SIZE_BYTES = 0  # Tamanho atual do cache em bytes (segmentos + chaves)

SEGMENT_CACHE_LOCK = threading.Lock()  # Lock para acesso thread-safe ao cache de segmentos
KEY_CACHE_LOCK = threading.Lock()  # Lock para acesso thread-safe ao cache de chaves
PREFETCH_QUEUE = queue.Queue()  # Fila para URLs de segmentos a serem pré-buscados
PREFETCH_WORKERS = 5  # Aumentado para 5 workers para maior paralelismo (ajustável)
PREFETCH_STOP_EVENT = threading.Event()  # Evento para sinalizar o fim das threads de pré-busca
PREFETCH_DELAY_SECONDS = 0.05  # Pequeno atraso entre as buscas para não sobrecarregar o servidor de origem

REQUESTS_SESSION = requests.Session()  # Sessão persistente para requisições HTTP

# --- DNS Over HTTPS Resolver ---
class DNSOverHTTPSResolver:
    """Resolvedor DNS over HTTPS (DoH) usando serviços públicos."""
    
    DOH_PROVIDERS = [
        'https://cloudflare-dns.com/dns-query',  # Cloudflare
        'https://dns.google/dns-query',     # Google
        'https://dns10.quad9.net/dns-query',  # Quad9
    ]
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/dns-json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.cache = collections.defaultdict(str)  # In-memory cache: {hostname: ip}
        self.cache_lock = threading.Lock()  # Thread safety for cache access
        self.max_retries = 3  # Max retries per provider
        self.initial_delay = 0.5  # Initial delay for retries (seconds)

    def resolve(self, hostname, provider_index=0, retry_count=0):
        """Resolve um hostname para um endereço IP usando DoH."""
        # Check cache first
        with self.cache_lock:
            if hostname in self.cache:
                log(f"Cache hit for {hostname}: {self.cache[hostname]}")
                return self.cache[hostname]

        # If cache miss, proceed with DoH resolution
        try:
            provider_url = self.DOH_PROVIDERS[provider_index % len(self.DOH_PROVIDERS)]
            params = {
                'name': hostname,
                'type': 'A'  # IPv4 address
            }
            
            # Exponential backoff for retries
            delay = self.initial_delay * (2 ** retry_count)
            if retry_count > 0:
                log(f"Retrying DoH for {hostname} with delay {delay:.2f}s")
                time.sleep(delay)

            # Adjusted timeout for faster failure detection
            response = self.session.get(provider_url, params=params, timeout=3)
            response.raise_for_status()
            data = response.json()
            
            if data.get('Status') == 0 and 'Answer' in data:  # DNS response code 0 = NOERROR
                answers = [answer['data'] for answer in data['Answer'] 
                          if answer['type'] == 1]  # Type 1 = A record
                if answers:
                    ip = answers[0]
                    log(f"Resolved {hostname} to {ip} using DoH provider {provider_url}")
                    # Cache the result
                    with self.cache_lock:
                        self.cache[hostname] = ip
                    return ip
            
            # Retry with the same provider if max retries not reached
            if retry_count < self.max_retries - 1:
                return self.resolve(hostname, provider_index, retry_count + 1)

            # If max retries reached, try the next provider
            if provider_index < len(self.DOH_PROVIDERS) - 1:
                return self.resolve(hostname, provider_index + 1, 0)

        except requests.exceptions.RequestException as e:
            log(f"Error resolving {hostname} with DoH provider {provider_url}: {e}")
            # Retry logic
            if retry_count < self.max_retries - 1:
                return self.resolve(hostname, provider_index, retry_count + 1)
            # Try the next provider if available
            if provider_index < len(self.DOH_PROVIDERS) - 1:
                return self.resolve(hostname, provider_index + 1, 0)

        # Fallback to system DNS if all DoH providers fail
        log(f"All DoH providers failed for {hostname}. Falling back to system DNS.")
        try:
            ip = socket.gethostbyname(hostname)
            log(f"Resolved {hostname} to {ip} using system DNS")
            with self.cache_lock:
                self.cache[hostname] = ip
            return ip
        except socket.gaierror as e:
            log(f"System DNS resolution failed for {hostname}: {e}")
            return None

    def close(self):
        """Fecha a sessão de requests para evitar memory leaks."""
        self.session.close()
        log("DNSOverHTTPSResolver session closed.")

# Instância global do resolvedor DoH
DNS_RESOLVER = DNSOverHTTPSResolver()

# --- Thread de Pré-busca (Prefetch) ---
class PrefetchThread(threading.Thread):
    def __init__(self, queue, cache, lock, stop_event, headers):
        super(PrefetchThread, self).__init__()
        self.daemon = True  # Garante que a thread termine com o programa principal
        self.queue = queue
        self.cache = cache
        self.lock = lock
        self.stop_event = stop_event
        self.headers = headers.copy()  # Copia os headers para uso da thread
        log("Prefetch thread initialized.")

    def run(self):
        global CURRENT_CACHE_SIZE_BYTES
        while not self.stop_event.is_set():
            try:
                # Obter URL da fila com timeout para verificar stop_event
                segment_url_to_prefetch = self.queue.get(timeout=1)
            except queue.Empty:
                if self.stop_event.is_set():
                    break  # Sair se a fila estiver vazia e o evento de parada for definido
                time.sleep(0.1)  # Pequena pausa para evitar CPU alta em fila vazia
                continue

            # Verificar se o segmento já está no cache antes de tentar buscar
            with self.lock:
                if segment_url_to_prefetch in self.cache:
                    log(f"Segment already in cache, skipping prefetch: {segment_url_to_prefetch}")
                    self.queue.task_done()
                    continue

            log(f"Prefetching segment: {segment_url_to_prefetch}")
            try:
                # Tentar resolver via DoH primeiro
                parsed_url = urlparse(segment_url_to_prefetch)
                if not parsed_url.hostname:
                    log(f"Invalid URL (no hostname) for prefetch: {segment_url_to_prefetch}")
                    self.queue.task_done()
                    continue

                ip_address = DNS_RESOLVER.resolve(parsed_url.hostname)
                if ip_address:
                    # Substituir o hostname pelo IP e adicionar header Host
                    new_netloc = ip_address
                    if parsed_url.port:
                        new_netloc += f":{parsed_url.port}"
                    doh_url = parsed_url._replace(netloc=new_netloc).geturl()
                    
                    # Garantir que o header Host está correto
                    doh_headers = self.headers.copy()
                    doh_headers['Host'] = parsed_url.hostname
                    
                    log(f"Trying to prefetch via DoH resolved IP: {doh_url}")
                    r = REQUESTS_SESSION.get(doh_url, headers=doh_headers, stream=True, timeout=15)
                    r.raise_for_status()
                else:
                    log(f"DNS resolution failed for prefetch: {segment_url_to_prefetch}")
                    self.queue.task_done()
                    continue
                
                content = r.content  # Ler todo o conteúdo do segmento

                with self.lock:
                    # Gerenciamento de tamanho do cache
                    segment_size = len(content)
                    # Se adicionar este segmento exceder o limite, remover os mais antigos
                    while CURRENT_CACHE_SIZE_BYTES + segment_size > MAX_CACHE_SIZE_MB * 1024 * 1024:
                        if not self.cache:  # Se o cache estiver vazio, não há o que remover
                            log("Cache is empty, cannot free space for new segment.")
                            break
                        
                        # Remove o item mais antigo (FIFO)
                        oldest_url, oldest_content = self.cache.popitem(last=False) 
                        CURRENT_CACHE_SIZE_BYTES -= len(oldest_content)
                        log(f"Removed oldest segment from cache: {oldest_url} to free space. Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")

                    self.cache[segment_url_to_prefetch] = content
                    CURRENT_CACHE_SIZE_BYTES += segment_size
                
                log(f"Prefetched and cached: {segment_url_to_prefetch} ({len(content)} bytes). Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")
            except requests.exceptions.RequestException as e:
                log(f"Error prefetching {segment_url_to_prefetch}: {e}")
            finally:
                self.queue.task_done()  # Sinalizar que a tarefa foi concluída
                time.sleep(PREFETCH_DELAY_SECONDS)  # Pequeno atraso para evitar "martelar" o servidor de origem

# --- Handler das Requisições HTTP (ProxyHandler) ---
class ProxyHandler(BaseHTTPRequestHandler):

    def basename(self, p):
        i = p.rfind('/') + 1
        return p[i:]

    def fetch_m3u8(self, url, headers):
        """Busca o conteúdo da playlist M3U8 com suporte a DoH."""
        parsed_url = urlparse(url)
        if not parsed_url.hostname:
            log(f"Invalid URL (no hostname): {url}")
            return None, None
            
        # Tentar resolver via DoH primeiro
        ip_address = DNS_RESOLVER.resolve(parsed_url.hostname)
        if ip_address:
            # Substituir o hostname pelo IP e adicionar header Host
            new_netloc = ip_address
            if parsed_url.port:
                new_netloc += f":{parsed_url.port}"
            doh_url = parsed_url._replace(netloc=new_netloc).geturl()
            
            # Garantir que o header Host está correto
            doh_headers = headers.copy()
            doh_headers['Host'] = parsed_url.hostname
            
            log(f"Trying to fetch M3U8 via DoH resolved IP: {doh_url}")
            try:
                r = REQUESTS_SESSION.get(doh_url, headers=doh_headers, timeout=10)
                r.raise_for_status()
                log(f"Successfully fetched M3U8 via DoH from {url}. Status: {r.status_code}")
                return r.text, r.url
            except requests.exceptions.RequestException as e:
                log(f"Error fetching M3U8 via DoH from {url}: {e}")
                return None, None
        else:
            log(f"DNS resolution failed for M3U8 fetch: {url}")
            return None, None

    def fetch_chunk(self, url, headers):
        """Busca um segmento de vídeo, priorizando o cache com suporte a DoH."""
        global CURRENT_CACHE_SIZE_BYTES

        with SEGMENT_CACHE_LOCK:
            if url in SEGMENT_CACHE:
                log(f"Serving segment from cache: {url}")
                content = SEGMENT_CACHE.pop(url)
                SEGMENT_CACHE[url] = content
                
                class MockResponse:
                    def __init__(self, content):
                        self._content = content
                        self.headers = {'Content-Length': str(len(content)), 'Content-Type': 'video/mp2t'}
                        self.status_code = 200
                    def iter_content(self, chunk_size):
                        yield self._content 
                    def close(self):
                        pass 
                return MockResponse(content)

        parsed_url = urlparse(url)
        if not parsed_url.hostname:
            log(f"Invalid URL (no hostname): {url}")
            return None
        
        log(f"Fetching segment (not in cache): {url}")
        
        # Tentar resolver via DoH
        ip_address = DNS_RESOLVER.resolve(parsed_url.hostname)
        if ip_address:
            # Substituir o hostname pelo IP e adicionar header Host
            new_netloc = ip_address
            if parsed_url.port:
                new_netloc += f":{parsed_url.port}"
            doh_url = parsed_url._replace(netloc=new_netloc).geturl()
            
            # Garantir que o header Host está correto
            doh_headers = headers.copy()
            doh_headers['Host'] = parsed_url.hostname
            
            log(f"Trying to fetch segment via DoH resolved IP: {doh_url}")
            try:
                r = REQUESTS_SESSION.get(doh_url, headers=doh_headers, stream=True, timeout=15)
                r.raise_for_status()
                
                content = r.content
                with SEGMENT_CACHE_LOCK:
                    segment_size = len(content)

                    while CURRENT_CACHE_SIZE_BYTES + segment_size > MAX_CACHE_SIZE_MB * 1024 * 1024:
                        if not SEGMENT_CACHE:
                            log("Cache is empty, cannot free space for new segment when fetching live.")
                            break
                        oldest_url, oldest_content = SEGMENT_CACHE.popitem(last=False)
                        CURRENT_CACHE_SIZE_BYTES -= len(oldest_content)
                        log(f"Removed oldest segment from cache: {oldest_url} to free space during live fetch. Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")

                    SEGMENT_CACHE[url] = content
                    CURRENT_CACHE_SIZE_BYTES += segment_size

                log(f"Successfully fetched and cached segment via DoH: {url} ({len(content)} bytes). Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")
                
                class MockResponse:
                    def __init__(self, content):
                        self._content = content
                        self.headers = {'Content-Length': str(len(content)), 'Content-Type': 'video/mp2t'} 
                        self.status_code = 200
                    def iter_content(self, chunk_size):
                        yield self._content 
                    def close(self):
                        pass 
                return MockResponse(content)
            except requests.exceptions.RequestException as e:
                log(f"Error fetching segment via DoH from {url}: {e}")
                return None
        else:
            log(f"DNS resolution failed for segment fetch: {url}")
            return None

    def fetch_key(self, url, headers):
        """Busca uma chave de criptografia, priorizando o cache com suporte a DoH."""
        global CURRENT_CACHE_SIZE_BYTES

        with KEY_CACHE_LOCK:
            if url in KEY_CACHE:
                log(f"Serving key from cache: {url}")
                content = KEY_CACHE.pop(url)
                KEY_CACHE[url] = content
                
                class MockResponse:
                    def __init__(self, content):
                        self._content = content
                        self.headers = {'Content-Length': str(len(content)), 'Content-Type': 'application/octet-stream'}
                        self.status_code = 200
                    def iter_content(self, chunk_size):
                        yield self._content 
                    def close(self):
                        pass 
                return MockResponse(content)

        parsed_url = urlparse(url)
        if not parsed_url.hostname:
            log(f"Invalid URL (no hostname) for key: {url}")
            return None
        
        log(f"Fetching key (not in cache): {url}")
        
        # Tentar resolver via DoH
        ip_address = DNS_RESOLVER.resolve(parsed_url.hostname)
        if ip_address:
            # Substituir o hostname pelo IP e adicionar header Host
            new_netloc = ip_address
            if parsed_url.port:
                new_netloc += f":{parsed_url.port}"
            doh_url = parsed_url._replace(netloc=new_netloc).geturl()
            
            # Garantir que o header Host está correto
            doh_headers = headers.copy()
            doh_headers['Host'] = parsed_url.hostname
            
            log(f"Trying to fetch key via DoH resolved IP: {doh_url}")
            try:
                r = REQUESTS_SESSION.get(doh_url, headers=doh_headers, timeout=10)
                r.raise_for_status()
                
                content = r.content
                with KEY_CACHE_LOCK:
                    key_size = len(content)

                    while CURRENT_CACHE_SIZE_BYTES + key_size > MAX_CACHE_SIZE_MB * 1024 * 1024:
                        if not KEY_CACHE and not SEGMENT_CACHE:
                            log("Caches are empty, cannot free space for new key.")
                            break
                        # Priorizar remover chaves antigas, depois segmentos
                        if KEY_CACHE:
                            oldest_url, oldest_content = KEY_CACHE.popitem(last=False)
                            CURRENT_CACHE_SIZE_BYTES -= len(oldest_content)
                            log(f"Removed oldest key from cache: {oldest_url} to free space. Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")
                        elif SEGMENT_CACHE:
                            with SEGMENT_CACHE_LOCK:
                                oldest_url, oldest_content = SEGMENT_CACHE.popitem(last=False)
                                CURRENT_CACHE_SIZE_BYTES -= len(oldest_content)
                                log(f"Removed oldest segment from cache: {oldest_url} to free space for key. Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")

                    KEY_CACHE[url] = content
                    CURRENT_CACHE_SIZE_BYTES += key_size

                log(f"Successfully fetched and cached key via DoH: {url} ({len(content)} bytes). Current cache size: {CURRENT_CACHE_SIZE_BYTES / (1024*1024):.2f} MB")
                
                class MockResponse:
                    def __init__(self, content):
                        self._content = content
                        self.headers = {'Content-Length': str(len(content)), 'Content-Type': 'application/octet-stream'} 
                        self.status_code = 200
                    def iter_content(self, chunk_size):
                        yield self._content 
                    def close(self):
                        pass 
                return MockResponse(content)
            except requests.exceptions.RequestException as e:
                log(f"Error fetching key via DoH from {url}: {e}")
                return None
        else:
            log(f"DNS resolution failed for key fetch: {url}")
            return None

    def modify_m3u8_for_proxy(self, m3u8_content, base_url):
        """Modifica a playlist M3U8 para apontar para o proxy e enfileira segmentos para pré-busca."""
        lines = m3u8_content.splitlines()
        modified_lines = []
        segment_urls_for_prefetch = []

        # Variável para controlar a profundidade da pré-busca
        PREFETCH_DEPTH = 3  # Pré-busca os próximos 3 segmentos (ajustável)

        for line in lines:
            if line.startswith('#EXTINF') or \
               line.startswith('#EXT-X-TARGETDURATION') or \
               line.startswith('#EXT-X-MEDIA-SEQUENCE') or \
               line.startswith('#EXT-X-VERSION') or \
               line.startswith('#EXT-X-PLAYLIST-TYPE') or \
               line.startswith('#EXT-X-ENDLIST') or \
               line.startswith('#EXT-X-DISCONTINUITY') or \
               line.startswith('#EXT-X-BYTERANGE'):
                modified_lines.append(line)
            elif line.startswith('#EXT-X-MAP'):
                key_match = re.search(r'URI="([^"]+)"', line)
                if key_match:
                    map_uri = key_match.group(1)
                    if not urlparse(map_uri).scheme:  # Se a URI for relativa
                        absolute_map_uri = urljoin(base_url, map_uri)
                        line = line.replace(map_uri, absolute_map_uri)
                modified_lines.append(line)
            elif line.startswith('#EXT-X-KEY'):
                # Exemplo: #EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=0x1234567890abcdef1234567890abcdef
                key_match = re.search(r'URI="([^"]+)"', line)
                if key_match:
                    key_uri = key_match.group(1)
                    if not urlparse(key_uri).scheme:  # Se a URI for relativa
                        key_uri = urljoin(base_url, key_uri)
                    
                    # Criar URL proxied para a chave
                    proxied_key_url = url_key_proxy_prefix + quote_plus(key_uri)
                    header_params = []
                    for key, value in HEADERS_BASE.items():
                        if key.lower() not in ['connection', 'host', 'accept-encoding']:
                            header_params.append(f"{quote_plus(key)}={quote_plus(value)}")
                    if header_params:
                        proxied_key_url += '&' + '&'.join(header_params)
                    
                    # Substituir a URI original pela proxied
                    line = re.sub(r'URI="[^"]+"', f'URI="{proxied_key_url}"', line)
                modified_lines.append(line)
            elif not line.strip().startswith('#') and line.strip():  # É uma URL de segmento
                segment_url = line.strip()
                if not urlparse(segment_url).scheme:  # Se a URL do segmento for relativa
                    segment_url = urljoin(base_url, segment_url)

                proxied_segment_url = url_segment_proxy_prefix + quote_plus(segment_url)
                
                header_params = []
                for key, value in HEADERS_BASE.items():
                    if key.lower() not in ['connection', 'host', 'accept-encoding']:
                        header_params.append(f"{quote_plus(key)}={quote_plus(value)}")
                
                if header_params:
                    proxied_segment_url += '&' + '&'.join(header_params)

                modified_lines.append(proxied_segment_url)
                segment_urls_for_prefetch.append(segment_url)  # Adicionar para pré-busca

            else:  # Outras linhas (comentários desconhecidos, etc.)
                modified_lines.append(line)
        
        # Enfileirar os segmentos para pré-busca, limitado pela profundidade
        log(f"Queueing up to {PREFETCH_DEPTH} segments for prefetch out of {len(segment_urls_for_prefetch)} total.")
        # Limpar a fila de pré-busca para evitar segmentos antigos ou duplicados
        while not PREFETCH_QUEUE.empty():
            try:
                PREFETCH_QUEUE.get_nowait()
                PREFETCH_QUEUE.task_done()
            except queue.Empty:
                pass

        for i, url in enumerate(segment_urls_for_prefetch):
            if i < PREFETCH_DEPTH:  # Limita a pré-busca aos primeiros N segmentos
                PREFETCH_QUEUE.put(url)
            else:
                break  # Para de enfileirar após atingir a profundidade

        return "\n".join(modified_lines)

    # --- Métodos HTTP ---
    def do_HEAD(self):
        self.handle_request('HEAD')

    def do_GET(self):
        self.handle_request('GET')

    def handle_request(self, method):
        """Lida com as requisições HTTP para o proxy."""
        global URL_BASE, LAST_URL, HEADERS_BASE, CACHE_M3U8, STOP_SERVER, CURRENT_CACHE_SIZE_BYTES 
        
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)

        if path == '/proxy_m3u8':
            if 'url' in query_params and query_params['url']:
                
                url_to_fetch = unquote_plus(query_params['url'][0])
                
                extracted_headers = {}
                for key, values in query_params.items():
                    if key not in ['url'] and values:
                        extracted_headers[key] = unquote_plus(values[0])

                HEADERS_BASE = {}
                for h_key in ['User-Agent', 'Referer', 'Origin', 'Connection', 'Host', 'Accept', 'Accept-Encoding', 'Accept-Language']:
                    if h_key in extracted_headers:
                        HEADERS_BASE[h_key] = extracted_headers[h_key]
                        del extracted_headers[h_key] 
                
                if 'Connection' not in HEADERS_BASE:
                    HEADERS_BASE['Connection'] = 'keep-alive'
                
                HEADERS_BASE.update(extracted_headers)

                log(f"Received proxy request for URL: {url_to_fetch}")
                log(f"Headers to use: {HEADERS_BASE}")

                if url_to_fetch != LAST_URL:
                    log("URL changed, resetting cache and state.")
                    URL_BASE = ''
                    LAST_URL = ''
                    CACHE_M3U8 = ''
                    
                    with SEGMENT_CACHE_LOCK:
                        SEGMENT_CACHE.clear()
                    with KEY_CACHE_LOCK:
                        KEY_CACHE.clear()
                    CURRENT_CACHE_SIZE_BYTES = 0
                    
                    while not PREFETCH_QUEUE.empty():
                        try:
                            PREFETCH_QUEUE.get_nowait()
                            PREFETCH_QUEUE.task_done()
                        except queue.Empty:
                            pass
                    PREFETCH_STOP_EVENT.clear() 

                LAST_URL = url_to_fetch
                
                m3u8_content, final_url = self.fetch_m3u8(url_to_fetch, HEADERS_BASE)

                if m3u8_content:
                    if not URL_BASE or (final_url and not final_url.startswith(URL_BASE)):
                        URL_BASE = os.path.dirname(final_url) + '/' if '/' in os.path.dirname(final_url) else final_url
                        log(f"Updated URL_BASE to: {URL_BASE}")
                    
                    CACHE_M3U8 = m3u8_content
                    modified_m3u8 = self.modify_m3u8_for_proxy(m3u8_content, URL_BASE)
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/x-mpegURL')
                    self.end_headers()
                    self.wfile.write(modified_m3u8.encode('utf-8'))
                else:
                    log(f"Failed to fetch M3U8 for {url_to_fetch}")
                    self.send_response(404)
                    self.end_headers()
            else:
                log("Missing 'url' parameter in proxy request.")
                self.send_response(400)
                self.end_headers()

        elif path.startswith('/proxy_segment/'):
            encoded_segment_url_and_params = self.path[len('/proxy_segment/'):]
            
            parts = encoded_segment_url_and_params.split('&', 1)
            segment_url_decoded = unquote_plus(parts[0])
            
            segment_query_params = {}
            if len(parts) > 1:
                temp_query_string = parts[1]
                segment_query_params = parse_qs(temp_query_string)

            segment_headers = {}
            for key, values in segment_query_params.items():
                if values:
                    segment_headers[key] = unquote_plus(values[0])
            
            current_segment_headers = HEADERS_BASE.copy()
            current_segment_headers.update(segment_headers)

            log(f"Received proxy request for segment: {segment_url_decoded}")
            log(f"Headers for segment: {current_segment_headers}")

            segment_response = self.fetch_chunk(segment_url_decoded, current_segment_headers)
            if segment_response:
                self.send_response(200)
                for header, value in segment_response.headers.items():
                    if header.lower() not in ['transfer-encoding', 'content-encoding', 'connection', 'content-length']:
                        self.send_header(header, value)
                
                if hasattr(segment_response, '_content'):
                    self.send_header('Content-Length', str(len(segment_response._content)))
                
                self.end_headers()
                
                try:
                    if hasattr(segment_response, '_content'): 
                        self.wfile.write(segment_response._content)
                    else: 
                        for chunk in segment_response.iter_content(chunk_size=8192):
                            self.wfile.write(chunk)
                except Exception as e:
                    log(f"Error streaming segment content: {e}")
                finally:
                    segment_response.close()
            else:
                self.send_response(404)
                self.end_headers()

        elif path.startswith('/proxy_key/'):
            encoded_key_url_and_params = self.path[len('/proxy_key/'):]
            
            parts = encoded_key_url_and_params.split('&', 1)
            key_url_decoded = unquote_plus(parts[0])
            
            key_query_params = {}
            if len(parts) > 1:
                temp_query_string = parts[1]
                key_query_params = parse_qs(temp_query_string)

            key_headers = {}
            for key, values in key_query_params.items():
                if values:
                    key_headers[key] = unquote_plus(values[0])
            
            current_key_headers = HEADERS_BASE.copy()
            current_key_headers.update(key_headers)

            log(f"Received proxy request for key: {key_url_decoded}")
            log(f"Headers for key: {current_key_headers}")

            key_response = self.fetch_key(key_url_decoded, current_key_headers)
            if key_response:
                self.send_response(200)
                for header, value in key_response.headers.items():
                    if header.lower() not in ['transfer-encoding', 'content-encoding', 'connection', 'content-length']:
                        self.send_header(header, value)
                
                if hasattr(key_response, '_content'):
                    self.send_header('Content-Length', str(len(key_response._content)))
                
                self.end_headers()
                
                try:
                    if hasattr(key_response, '_content'): 
                        self.wfile.write(key_response._content)
                    else: 
                        for chunk in key_response.iter_content(chunk_size=8192):
                            self.wfile.write(chunk)
                except Exception as e:
                    log(f"Error streaming key content: {e}")
                finally:
                    key_response.close()
            else:
                self.send_response(404)
                self.end_headers()
        
        elif path == '/check':
            log("HEAD /check received. Server is responsive.")
            self.send_response(200)
            self.end_headers()

        elif path == '/stop':
            log("HEAD /stop received. Initiating server shutdown.")
            STOP_SERVER = True
            
            URL_BASE = ''
            LAST_URL = ''
            HEADERS_BASE = {}
            CACHE_M3U8 = ''
            
            PREFETCH_STOP_EVENT.set()
            while not PREFETCH_QUEUE.empty():
                try:
                    PREFETCH_QUEUE.get_nowait()
                    PREFETCH_QUEUE.task_done()
                except queue.Empty:
                    pass
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE.clear()
            with KEY_CACHE_LOCK:
                KEY_CACHE.clear()
            CURRENT_CACHE_SIZE_BYTES = 0
            log("All global proxy variables, segment cache, and key cache have been reset. Prefetch threads signaled to stop.")
            
            self.send_response(200)
            self.end_headers()

        elif path == '/reset':
            log("HEAD /reset received. Resetting global states.")
            URL_BASE = ''
            LAST_URL = ''
            HEADERS_BASE = {}
            CACHE_M3U8 = ''

            PREFETCH_STOP_EVENT.set() 
            while not PREFETCH_QUEUE.empty():
                try:
                    PREFETCH_QUEUE.get_nowait()
                    PREFETCH_QUEUE.task_done()
                except queue.Empty:
                    pass
            with SEGMENT_CACHE_LOCK:
                SEGMENT_CACHE.clear()
            with KEY_CACHE_LOCK:
                KEY_CACHE.clear()
            CURRENT_CACHE_SIZE_BYTES = 0
            
            PREFETCH_STOP_EVENT.clear() 
            
            log("All global proxy variables, segment cache, and key cache have been reset.")
            
            self.send_response(200)
            self.end_headers()
        else:
            log(f"{method} request for unknown path: {self.path}")
            self.send_response(404)
            self.end_headers()

# --- Classe do Servidor HTTP Threaded ---
class ThreadedHTTPServer(threading.Thread):
    def __init__(self, host, port):
        super(ThreadedHTTPServer, self).__init__()
        self.daemon = True 
        self.host = host
        self.port = port
        self.server = None
        self.running = False
        self.prefetch_threads = [] 
        log("Server thread initialized.")

    def run(self):
        try:
            PREFETCH_STOP_EVENT.clear() 
            self.prefetch_threads = []
            for i in range(PREFETCH_WORKERS):
                thread = PrefetchThread(PREFETCH_QUEUE, SEGMENT_CACHE, SEGMENT_CACHE_LOCK, PREFETCH_STOP_EVENT, HEADERS_BASE.copy())
                thread.start()
                self.prefetch_threads.append(thread)
            log(f"{PREFETCH_WORKERS} prefetch threads started.")

            self.server = HTTPServer((self.host, self.port), ProxyHandler)
            log(f"Server initialized and listening on {self.host}:{self.port}")
            self.running = True
            self.server.serve_forever()
        except Exception as e:
            log(f"Error starting HTTP server: {e}")
        finally:
            self.running = False
            if self.server:
                self.server.server_close() 
            PREFETCH_STOP_EVENT.set()
            for thread in self.prefetch_threads:
                thread.join(timeout=2) 
                if thread.is_alive():
                    log(f"Warning: Prefetch thread {thread.name} did not terminate gracefully.")
            log("HTTP server stopped and prefetch threads joined.")

# --- Classe de Controle do Servidor ---
class Server:
    def __init__(self):
        global STOP_SERVER
        STOP_SERVER = False 
        self.server_thread = ThreadedHTTPServer(HOST_NAME, PORT_NUMBER)
        self.server_thread_ok = True 
        log("Server controller initialized, thread created.")

    def in_use(self):
        """Verifica se o servidor proxy já está em execução e respondendo."""
        url = url_check 
        try:
            r = REQUESTS_SESSION.head(url, timeout=1)
            if r.status_code == 200:
                log("Server is already in use.")
                r.close()
                return True
            r.close()
        except requests.exceptions.RequestException as e:
            log(f"Server not responsive or not running: {e}")
        return False

    def start(self):
        """Inicia o servidor proxy ou reinicia seu estado se já estiver em uso."""
        if not self.in_use():
            if self.server_thread_ok:
                log("Starting new server thread.")
                self.server_thread.start()
                time.sleep(1.5)
                if not self.in_use():
                    log("Warning: Server thread started but not responding to /check immediately. Retrying start or checking.")
            else:
                log("Server thread not initialized successfully, cannot start.")
        else:
            log("Server already in use. Resetting global states for a new session.")
            url = url_reset 
            try:
                r = REQUESTS_SESSION.head(url, timeout=2)
                r.close()
                log("Sent reset command to existing server.")
            except requests.exceptions.RequestException as e:
                log(f"Failed to send reset command to existing server: {e}. Consider restarting Kodi or checking port.")

# --- Funções de Utilitário para o Kodi ---
def get_hls_url(url, headers=None):
    """
    Constrói a URL proxyficada para playlists M3U8, incluindo headers.
    """
    global url_proxy, HEADERS_BASE
    
    if headers:
        HEADERS_BASE.update(headers)
    
    proxied_url = url_proxy + quote_plus(url)
    
    for key, value in HEADERS_BASE.items():
        proxied_url += f"&{quote_plus(key)}={quote_plus(value)}"
    
    log(f"Constructed proxied HLS URL: {proxied_url}")
    return proxied_url

def stop_all_proxies():
    """Tenta parar o servidor proxy e limpar recursos."""
    global STOP_SERVER, CURRENT_CACHE_SIZE_BYTES
    STOP_SERVER = True
    log("Attempting to stop proxy server...")
    try:
        r = REQUESTS_SESSION.head(url_stop, timeout=5)
        r.close()
        log(f"Stop command sent to proxy server. Status: {r.status_code}")
    except requests.exceptions.RequestException as e:
        log(f"Failed to send stop command to proxy server: {e}")
    
    # Limpar a fila de pré-busca
    while not PREFETCH_QUEUE.empty():
        try:
            PREFETCH_QUEUE.get_nowait()
            PREFETCH_QUEUE.task_done()
        except queue.Empty:
            pass
    
    # Limpar caches
    with SEGMENT_CACHE_LOCK:
        SEGMENT_CACHE.clear()
    with KEY_CACHE_LOCK:
        KEY_CACHE.clear()
    CURRENT_CACHE_SIZE_BYTES = 0
    
    # Resetar o evento de parada
    PREFETCH_STOP_EVENT.clear() 
    
    # Fechar sessões de requests para evitar memory leaks
    REQUESTS_SESSION.close()
    DNS_RESOLVER.close()
    log("All resources cleaned up, proxy server stopped.")

# Instanciar o servidor principal (Server controller)
iniciavideo = Server()
