Silk icon set 1.3 by Mark James <mjames@gmail.com>

http://www.famfamfam.com/lab/icons/silk/

License: [CC-BY-2.5](https://creativecommons.org/licenses/by/2.5/)
or [CC-BY-3.0](https://creativecommons.org/licenses/by/3.0/)
