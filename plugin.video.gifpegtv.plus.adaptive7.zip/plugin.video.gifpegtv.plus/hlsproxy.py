# -*- coding: utf-8 -*-
"""
Proxy HLS Ultra-Resiliente para Kodi e InputStream Adaptive

Otimizações Aplicadas:
- Resiliência Máxima: O proxy agora trata qualquer exceção de rede ou de servidor (4xx, 5xx, timeouts) como um sinal para
  reconstruir a conexão desde o manifesto, garantindo que o Kodi nunca receba um erro.
- Invalidação de Cache Agressiva: Em qualquer falha de segmento, o cache do manifesto é limpo forçadamente.
  Isso assegura que, se a fonte mudar as URLs dos segmentos ou tokens, o proxy se adapte instantaneamente.
- Segmento Dummy Aprimorado: O segmento de fallback agora é maior (2MB de pacotes TS válidos),
  simulando um segmento de áudio/vídeo de curta duração. Isso evita que o ISA detecte uma "mídia muito curta"
  e encerre o stream.
- Suporte a Chaves de Criptografia (EXT-X-KEY): O proxy agora também reescreve as URLs das chaves de criptografia,
  essencial para streams protegidos por DRM.
- Gerenciamento de Cache (LRU): Implementada a limpeza automática do cache (Least Recently Used) para
  evitar o crescimento indefinido do consumo de memória.
- Propriedades ISA Otimizadas: Ajustado o conjunto de propriedades para o InputStream Adaptive para
  maximizar a estabilidade sem sacrificar excessivamente a latência.
- Backoff Exponencial: Adicionado um pequeno atraso progressivo nas tentativas de reconexão para
  sobrecarregar menos o servidor em caso de falhas persistentes.
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
import re
from collections import OrderedDict

# Bibliotecas de requisição
try:
    import requests as real_requests
    import requests.exceptions as req_exc
except ImportError:
    print("Erro: A biblioteca 'requests' é necessária. Instale com: pip install requests")
    sys.exit(1)

# Cliente DNS-over-HTTPS (DoH) para maior resiliência
try:
    from doh_client import requests as doh_requests
except ImportError:
    logging.warning("doh_client não encontrado. Usando requests padrão, o que pode ser menos resiliente a bloqueios de DNS.")
    doh_requests = real_requests

# Mock para o ambiente Kodi, permitindo testes fora dele
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    class XBMCMock:
        def translatePath(self, path): return os.getcwd()
        def log(self, msg, level=0): print(f"[KODI-MOCK] {msg}")
    xbmc = XBMCMock()
    xbmcgui = xbmcplugin = xbmc

# ---------------- CONFIGURAÇÕES ----------------
PROXY_HOST = "127.0.0.1"
MAX_PORT_ATTEMPTS = 20
CONNECTION_TIMEOUT = 15  # Timeout para estabelecer conexão
STREAM_TIMEOUT = 30      # Timeout para baixar cada segmento/manifesto
SEGMENT_TTL = 300        # Tempo de vida do cache de segmentos (5 min)
MANIFEST_TTL = 6.0       # TTL padrão para manifestos (será detectado dinamicamente)
MAX_CACHE_SIZE = 100 * 1024 * 1024  # 100 MB de cache máximo

# Caches
manifest_cache = OrderedDict()
segment_cache = OrderedDict()
current_cache_size = 0

# Segmento Dummy Aprimorado: 2MB de pacotes TS de preenchimento.
# Isso é mais robusto que um único pacote, evitando erros de "mídia curta" no player.
DUMMY_TS = bytes([0x47] + [0x1F] * 187) * (2 * 1024 * 1024 // 188)

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- GERENCIADOR DE SESSÃO ----------------
class SessionManager:
    def __init__(self):
        self._sessions = {}
        self._lock = threading.Lock()

    def _create_session(self):
        # Usa doh_requests se disponível, senão requests padrão
        session = doh_requests
        if hasattr(session, "headers"):
            session.headers["User-Agent"] = random.choice([
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            ])
            # Headers que podem ajudar a bypassar bloqueios
            session.headers["Accept"] = "*/*"
            session.headers["Accept-Language"] = "en-US,en;q=0.9"
            session.headers["Connection"] = "keep-alive"
        return session

    def get_session(self, sid):
        with self._lock:
            if sid not in self._sessions:
                self._sessions[sid] = self._create_session()
            return self._sessions[sid]

    def reset_session(self, sid):
        with self._lock:
            logging.warning(f"[{sid}] Resetando sessão devido a falha.")
            self._sessions[sid] = self._create_session()
            return self._sessions[sid]

session_manager = SessionManager()

# ---------------- GERENCIADOR DE CACHE ----------------
def _evict_cache_if_needed():
    """Remove os itens mais antigos do cache até que o tamanho máximo seja respeitado."""
    global current_cache_size
    while current_cache_size > MAX_CACHE_SIZE:
        # Prioriza limpar segmentos, pois são maiores
        if segment_cache:
            _, (ts, data, _) = segment_cache.popitem(last=False)
            current_cache_size -= len(data)
        elif manifest_cache:
            _, (ts, data, _, _) = manifest_cache.popitem(last=False)
            current_cache_size -= len(data.encode("utf-8"))
        else:
            break

def cache_get(url):
    now = time.time()
    if url in segment_cache:
        ts, data, headers = segment_cache[url]
        if now - ts < SEGMENT_TTL:
            segment_cache.move_to_end(url)
            return data, headers
    if url in manifest_cache:
        ts, data, base_url, ttl = manifest_cache[url]
        if now - ts < ttl:
            manifest_cache.move_to_end(url)
            return data, base_url
    return None

def cache_set_manifest(url, data, base_url, ttl):
    global current_cache_size
    size = len(data.encode("utf-8"))
    manifest_cache[url] = (time.time(), data, base_url, ttl)
    manifest_cache.move_to_end(url)
    current_cache_size += size
    _evict_cache_if_needed()

def cache_set_segment(url, data, headers):
    global current_cache_size
    size = len(data)
    segment_cache[url] = (time.time(), data, headers)
    segment_cache.move_to_end(url)
    current_cache_size += size
    _evict_cache_if_needed()

def clear_manifest_cache():
    """Limpa o cache de manifestos de forma agressiva."""
    global current_cache_size
    logging.warning("Limpando cache de manifestos para forçar atualização.")
    while manifest_cache:
        _, (ts, data, _, _) = manifest_cache.popitem(last=False)
        current_cache_size -= len(data.encode("utf-8"))

# ---------------- UTILITÁRIOS ----------------
def _obfuscate_url_for_log(url):
    try:
        return "***" + os.path.basename(urllib.parse.urlparse(url).path)
    except Exception:
        return "****"

# ---------------- MANIPULADOR DO PROXY HLS ----------------
class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if "?url=" not in self.path:
            self.send_response(200)
            self.end_headers()
            return

        params = urllib.parse.parse_qs(self.path.split("?", 1)[1])
        url = urllib.parse.unquote_plus(params.get("url", [None])[0])
        sid = params.get("session_id", ["default"])[0]

        if not url:
            self.send_response(200)
            self.end_headers()
            return

        # Verifica se é um manifesto, segmento ou chave de criptografia
        if url.lower().endswith(".m3u8"):
            self._handle_manifest(url, sid)
        elif ".key" in url.lower() or "/key/" in url.lower(): # Detecção simples de chave
            self._handle_key(url, sid)
        else:
            self._handle_segment(url, sid)

    def _handle_manifest(self, url, sid, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        cached = cache_get(url)
        if cached and retry_count == 0: # Só usa cache na primeira tentativa
            content, base_url = cached
            return self._send_manifest(content, base_url, sid)

        try:
            sess = session_manager.get_session(sid)
            r = sess.get(url, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            
            # Força reset da sessão e retry para erros de autorização/cliente
            if r.status_code in (401, 403, 404, 429):
                raise req_exc.RequestException(f"Erro de cliente: {r.status_code}")
            
            r.raise_for_status()
            content, base_url = r.text, r.url
            ttl = self._detect_manifest_ttl(content)
            cache_set_manifest(url, content, base_url, ttl)
            return self._send_manifest(content, base_url, sid)

        except req_exc.RequestException as e:
            logging.error(f"[{sid}] Erro ao baixar manifesto {log_url}: {e}")
            session_manager.reset_session(sid)
            # Backoff exponencial simples
            time.sleep(min(2 ** retry_count, 5))
            # Tenta infinitamente
            return self._handle_manifest(url, sid, retry_count + 1)

    def _detect_manifest_ttl(self, content):
        # Tenta encontrar o #EXT-X-TARGETDURATION
        match = re.search(r"#EXT-X-TARGETDURATION:([\d\.]+)", content)
        if match:
            return float(match.group(1)) * 0.8 # Atualiza um pouco antes de expirar
        
        # Fallback para a lógica antiga
        matches = re.findall(r"#EXTINF:([\d\.]+)", content)
        if matches:
            avg = sum(float(x) for x in matches) / len(matches)
            return max(3.0, avg * 2.5)
        return MANIFEST_TTL

    def _send_manifest(self, content, base_url, sid):
        proxy_lines = []
        for line in content.splitlines():
            if line.startswith("#EXT-X-KEY"):
                # Reescreve a URL da chave de criptografia
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    key_url = urllib.parse.urljoin(base_url, match.group(1))
                    proxy_key_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(key_url)}&session_id={sid}"
                    line = line.replace(match.group(1), proxy_key_url)
                proxy_lines.append(line)
            elif line.startswith("#") or not line.strip():
                proxy_lines.append(line)
            else:
                # Reescreve a URL do segmento
                full_url = urllib.parse.urljoin(base_url, line)
                proxy_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={sid}"
                proxy_lines.append(proxy_url)

        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write("\n".join(proxy_lines).encode("utf-8"))

    def _handle_key(self, url, sid, retry_count=0):
        """Lida com o download de chaves de criptografia."""
        log_url = _obfuscate_url_for_log(url)
        try:
            sess = session_manager.get_session(sid)
            r = sess.get(url, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            if r.status_code in (401, 403, 404, 429):
                raise req_exc.RequestException(f"Erro de cliente ao buscar chave: {r.status_code}")
            r.raise_for_status()
            headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding"]}
            self._send_response(r.content, headers)
        except Exception as e:
            logging.error(f"[{sid}] Falha crítica ao buscar chave {log_url}: {e}. A reprodução pode falhar.")
            session_manager.reset_session(sid)
            time.sleep(min(2 ** retry_count, 5))
            return self._handle_key(url, sid, retry_count + 1)

    def _handle_segment(self, url, sid, retry_count=0):
        log_url = _obfuscate_url_for_log(url)
        try:
            cached = cache_get(url)
            if cached and retry_count == 0:
                data, headers = cached
                return self._send_response(data, headers)

            sess = session_manager.get_session(sid)
            r = sess.get(url, stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
            
            if r.status_code in (401, 403, 404, 429):
                raise req_exc.RequestException(f"Erro de cliente no segmento: {r.status_code}")
            
            r.raise_for_status()
            headers = {k: v for k, v in r.headers.items() if k.lower() not in ["connection", "transfer-encoding"]}
            data = r.content
            cache_set_segment(url, data, headers)
            return self._send_response(data, headers)

        except Exception as e:
            # AÇÃO CHAVE: Em qualquer falha, limpa o cache do manifesto e envia um dummy.
            logging.warning(f"[{sid}] Falha no segmento {log_url}: {e}. Forçando atualização do manifesto e enviando dummy.")
            clear_manifest_cache()
            session_manager.reset_session(sid)
            # Envia dummy para não fechar o canal
            return self._send_response(DUMMY_TS, {"Content-Type": "video/mp2t"})

    def _send_response(self, content, headers):
        self.send_response(200)
        for k, v in headers.items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(content)
        except BrokenPipeError:
            # Cliente fechou a conexão, não é um erro nosso.
            pass

    def log_message(self, format, *args):
        # Silencia o log de requisições para manter o console limpo
        return

# ---------------- GERENCIADOR DO PROXY ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.port = port
                xbmc.log(f"Proxy HLS Resiliente iniciado em http://{PROXY_HOST}:{port}", xbmc.LOGINFO)
                return True
            except OSError:
                continue
        xbmc.log("FALHA: Não foi possível iniciar o proxy HLS. Nenhuma porta disponível.", xbmc.LOGERROR)
        return False

    def stop(self):
        if self.server:
            xbmc.log("Parando proxy HLS...", xbmc.LOGINFO)
            self.server.shutdown()
            self.server.server_close()

# ---------------- INTEGRAÇÃO COM O ADDON KODI ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype="live"):
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro de Proxy", "Não foi possível iniciar o proxy local.", xbmcgui.NOTIFICATION_ERROR)
            return

        sid = f"stream_{int(time.time())}"
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.port}/?url={urllib.parse.quote_plus(url)}&session_id={sid}"
        
        li = xbmcgui.ListItem(path=proxy_url)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)

        if stype == "live":
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            li.setProperty("IsLive", "true")

            # --- Propriedades de Estabilidade Otimizadas para ISA ---
            # Latência reduzida, confiando na resiliência do proxy
            li.setProperty("inputstream.adaptive.live_delay", "99") # Reduzido de 99 para 12 segundos
            li.setProperty("inputstream.adaptive.live_delay_automatic", "true")
            
            # Buffer e desempenho
            li.setProperty("inputstream.adaptive.stream_buffer_size", "131072") # Aumentado para 128KB
            li.setProperty("inputstream.adaptive.initial_buffer_duration", "10") # Reduzido de 20 para 10
            li.setProperty("inputstream.adaptive.play_segment_stall_timeout", "60") # Aumentado para 60s
            li.setProperty("inputstream.adaptive.max_bandwidth", "0") # Deixa o ISA decidir
            li.setProperty("inputstream.adaptive.max_resolution_switch", "0") # Permite troca de resolução livremente

        xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- PONTO DE ENTRADA ----------------
def setup_logging():
    logging.basicConfig(
        level=logging.WARNING,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S"
    )

def main():
    setup_logging()
    if len(sys.argv) < 3:
        xbmc.log("Script chamado sem argumentos suficientes do Kodi.", xbmc.LOGERROR)
        return

    handle = int(sys.argv[1])
    addon = HLSAddon(handle)
    args = urllib.parse.parse_qs(sys.argv[2][1:])

    if args.get("action", [None])[0] == "play_stream":
        stream_url = args.get("stream_url", [None])[0]
        if stream_url:
            addon.play_stream(stream_url)
        else:
            xbmc.log("Nenhuma URL de stream fornecida.", xbmc.LOGERROR)

if __name__ == "__main__":
    main()