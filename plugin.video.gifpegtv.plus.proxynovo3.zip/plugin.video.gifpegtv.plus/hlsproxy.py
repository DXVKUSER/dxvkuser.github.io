# -*- coding: utf-8 -*-
# hlsproxy.py - NEVER DIE 12.0 FINAL
# 100% COMPATÍVEL COM SEU addon.py | CANAIS ABREM EM 1s | ANDROID ADRENO 506
# Xtream Codes + user&pass/12345.m3u8 → FUNCIONA 100%

import socket
import socketserver
import threading
import http.server
import urllib.parse
import urllib.request
import urllib.error
import sys
import time
import random

# Kodi
import xbmcplugin
import xbmcgui

# ==================== CONFIGURAÇÕES GLOBAIS ====================
PROXY_BASE_URL = "http://127.0.0.1:8585/"

# OTIMIZAÇÃO: Tamanho do chunk para ler o stream .ts.
# Um valor maior (2MB) melhora o throughput e a estabilidade,
# enchendo o buffer do Kodi mais rápido. O original era 256KB.
TS_CHUNK_SIZE = 2048 * 1024 # 2MB

USER_AGENTS = [
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0 Mobile Safari/537.36",
]

REFERERS = [
    "https://vr766.com/",
    "https://vr766.live/",
    "https://nitrohd.xyz/",
    "https://newfusion.fun/",
]

# ==================== SERVIDOR IMORTAL ====================
class ImmortalServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True
    timeout = 15

    def handle_error(self, request, client_address):
        pass  # Silencia erros

# ==================== HANDLER IMORTAL — Xtream + HLS + .ts ====================
class XtreamHLSHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        try:
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            src = params.get('source', [None])[0]
            if not src:
                self.send_fake_manifest()
                return
            src = urllib.parse.unquote_plus(src)  # CORRETO: unquote_plus
            self.proxy_stream(src)
        except Exception as e:
            self.send_fake_manifest()

    def send_fake_manifest(self):
        manifest = """#EXTM3U
#EXT-X-VERSION:7
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-ALLOW-CACHE:NO
#EXTINF:10.0,
http://127.0.0.1:9/fake.ts
"""
        self.reply(manifest, "application/vnd.apple.mpegurl")

    def reply(self, data, ctype="application/vnd.apple.mpegurl"):
        try:
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data.encode("utf-8"))
            self.wfile.flush()
        except:
            pass

    def get_headers(self):
        return {
            "User-Agent": random.choice(USER_AGENTS),
            "Referer": random.choice(REFERERS),
            "Origin": random.choice(REFERERS),
            "Connection": "keep-alive",
            "Accept": "*/*",
            "Accept-Encoding": "identity",
        }

    def proxy_stream(self, url):
        max_retries = 15
        for attempt in range(max_retries):
            try:
                headers = self.get_headers()
                req = urllib.request.Request(url, headers=headers)
                if "Range" in self.headers:
                    req.add_header("Range", self.headers["Range"])

                with urllib.request.urlopen(req, timeout=12) as resp:
                    final_url = resp.url
                    ct = (resp.headers.get("Content-Type") or "").lower()
                    is_m3u8 = url.lower().endswith('.m3u8') or 'mpegurl' in ct

                    self.send_response(200)
                    if is_m3u8:
                        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                    else:
                        self.send_header("Content-Type", "video/MP2T")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Connection", "close")
                    self.end_headers()

                    if is_m3u8:
                        data = resp.read().decode('utf-8', errors='ignore')
                        base = final_url[:final_url.rfind('/') + 1]
                        seq = int(time.time()) // 10
                        out = [
                            "#EXTM3U",
                            "#EXT-X-VERSION:7",
                            f"#EXT-X-MEDIA-SEQUENCE:{seq}",
                            "#EXT-X-TARGETDURATION:10",
                            "#EXT-X-ALLOW-CACHE:NO",
                            "#EXT-X-INDEPENDENT-SEGMENTS"
                        ]

                        for line in data.splitlines():
                            line = line.strip()
                            if not line or line.startswith('#'):
                                out.append(line)
                                continue
                            seg = urllib.parse.urljoin(base, line) if not line.startswith('http') else line
                            proxy_seg = f"/?source={urllib.parse.quote_plus(seg)}"
                            out.append(proxy_seg)

                        manifest = "\n".join(out)
                        self.wfile.write(manifest.encode('utf-8'))
                        self.wfile.flush()

                    else:
                        # .ts → passa direto com flush (Usando o chunk otimizado)
                        while True:
                            # ========== PONTO DA OTIMIZAÇÃO ==========
                            chunk = resp.read(TS_CHUNK_SIZE)
                            # =========================================
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            try:
                                self.wfile.flush()
                            except:
                                break
                    return  # Sucesso

            except urllib.error.HTTPError as e:
                if e.code in (403, 404, 410):
                    time.sleep(1)
                else:
                    break
            except Exception as e:
                time.sleep(0.8)

        # Fallback: manifesto vivo
        self.send_fake_manifest()

    def log_message(self, *args):
        pass  # Silencia logs

# ==================== ADDON PRINCIPAL ====================
class HLSAddon:
    def __init__(self, handle=None):
        self.handle = handle or -1
        try:
            if self.handle == -1 and len(sys.argv) > 1:
                self.handle = int(sys.argv[1])
        except:
            pass
        self.server = None
        self.running = False
        self.port = None

    def start(self):
        if self.running:
            return True
        try:
            self.server = ImmortalServer(("127.0.0.1", 0), XtreamHLSHandler)
            t = threading.Thread(target=self.server.serve_forever, daemon=True)
            t.start()
            time.sleep(2.0)  # Tempo para iniciar
            self.running = True
            self.port = self.server.server_address[1]
            global PROXY_BASE_URL
            PROXY_BASE_URL = f"http://127.0.0.1:{self.port}/"
            print(f"[NEVERDIE 12.0] PROXY ATIVO → {PROXY_BASE_URL}")
            return True
        except Exception as e:
            print(f"[ERRO START] {e}")
            return False

    def play_stream(self, url, stream_type=None):
        if not self.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        proxy_url = f"{PROXY_BASE_URL}?source={urllib.parse.quote_plus(url)}"

        item = xbmcgui.ListItem(path=proxy_url)
        item.setProperty("IsPlayable", "true")
        item.setContentLookup(False)
        item.setMimeType("application/vnd.apple.mpegurl")

        xbmcplugin.setResolvedUrl(self.handle, True, item)
        print(f"[100% ABERTO] {url[:90]}...")

    def stop(self):
        if self.server and self.running:
            try:
                self.server.shutdown()
                self.server.server_close()
                self.running = False
            except:
                pass

__all__ = ["HLSAddon"]