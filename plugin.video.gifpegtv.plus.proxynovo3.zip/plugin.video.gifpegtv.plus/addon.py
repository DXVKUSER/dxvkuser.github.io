# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import time
import xbmcvfs
import html
import hashlib
from datetime import datetime

from resources.lib.api import XtreamAPI
from resources.lib.epg import load_epg, epg_lookup_current_next, normalize_epg_channel_id
from hlsproxy import HLSAddon  # Importação corrigida
from vodproxy import VODAddon  # Importação corrigida
from doh_client import requests

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADULT_KEYWORDS = ['adult', 'xxx', '+18', 'private']

REMOTE_MENU_URL = "https://paste.kodi.tv/raw/payomivoya"

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_TTL = 24 * 3600  # 24h

def get_setting(setting_id):
    return ADDON.getSetting(setting_id)

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_dir(name, query, icon='https://i.imgur.com/FBK5qFX.png', fanart='https://i.imgur.com/KMlkWXm.jpeg', is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=f"[B][COLORwhite]{name}[/COLOR][/B]")
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
    if plot:
        li.setInfo("video", {"title": name, "plot": plot})
    url = build_url(query)
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def get_remote_menu():
    try:
        xbmc.log(f"[ADDON] Baixando menu remoto: {REMOTE_MENU_URL}", level=xbmc.LOGINFO)
        response = requests.get(REMOTE_MENU_URL, timeout=15)
        response.raise_for_status()
        data = json.loads(response.text)
        if not isinstance(data, list) or not data:
            xbmc.log("[ADDON] Menu remoto vazio ou inválido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", "[B][COLORwhite]Menu remoto vazio ou inválido.[/COLOR][/B]")
            return []
        return data
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro ao baixar menu remoto: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLORwhite]Erro de Conexão[/COLOR][/B]", "[B][COLORwhite]Não foi possível baixar o menu remoto.[/COLOR][/B]")
        return []
    except (ValueError, json.JSONDecodeError):
        xbmc.log("[ADDON] Menu remoto não é JSON válido.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("[B][COLORwhite]Erro de Menu[/COLOR][/B]", "[B][COLORwhite]O arquivo JSON remoto está inválido.[/COLOR][/B]")
        return []

def servers_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Servidores[/COLOR][/B]")
    menu = get_remote_menu()
    for categoria in menu:
        cat_name = categoria.get("categoria", "[B][COLORwhite]Sem Nome[/COLOR][/B]")
        icon = categoria.get("icon", "https://i.imgur.com/SJITntP.png")
        fanart = categoria.get("fanart", "https://i.imgur.com/gaaKYUP.jpeg")
        add_dir(f"{cat_name}", {'action': 'category_menu', 'category_name': cat_name}, icon=icon, fanart=fanart, is_folder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def category_menu(category_name):
    menu = get_remote_menu()
    category = next((c for c in menu if c.get("categoria") == category_name), None)
    if not category:
        xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", f"[B][COLORwhite]Categoria '{category_name}' não encontrada.[/COLOR][/B]")
        return

    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"[B][COLORwhite]{category_name}[/COLOR][/B]")
    servidores = category.get("servidores", [])
    for i, server in enumerate(servidores):
        name = server.get("nome", "[B][COLORwhite]Servidor[/COLOR][/B]")
        imagem = server.get("icon", "https://i.imgur.com/SJITntP.png")
        add_dir(f"{name}", {'action': 'server_home', 'category_name': category_name, 'server_index': i}, icon=imagem, fanart=imagem, is_folder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def main_menu(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Menu Principal[/COLOR][/B]")
    add_dir("TV", {'action': 'list_live_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("Filmes", {'action': 'list_vod_categories', 'category_name': category_name, 'server_index': server_index})
    add_dir("Séries", {'action': 'list_series_categories', 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_epg_xml_path(server):
    # Use um hash do URL do servidor para criar um nome de arquivo único.
    server_hash = hashlib.md5(server.encode('utf-8')).hexdigest()
    return os.path.join(PROFILE_DIR, f'epg_{server_hash}.xml')

def download_epg(server, username, password):
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)
    epg_xml_path = get_epg_xml_path(server)
    url = f"{server.rstrip('/')}/xmltv.php?username={username}&password={password}"
    xbmc.log(f"[ADDON] Baixando EPG para o servidor: {server}", level=xbmc.LOGINFO)
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        content = response.content.decode('utf-8', errors='ignore')
        with open(epg_xml_path, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        xbmc.log(f"[ADDON] Falha ao baixar EPG: {e}", level=xbmc.LOGERROR)

def ensure_epg(server, username, password):
    epg_xml_path = get_epg_xml_path(server)
    if not os.path.exists(epg_xml_path) or (time.time() - os.path.getmtime(epg_xml_path)) > EPG_TTL:
        download_epg(server, username, password)
    return load_epg(epg_xml_path)

def list_live_categories(api, server, username, password, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Categorias Ao Vivo[/COLOR][/B]")
    
    download_epg(server, username, password)
    
    categories = api.get_live_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = get_setting('adult_filter') == 'true'
    filtered_categories = []
    for category in categories:
        cat_name = category['category_name']
        if adult_filter_enabled and any(keyword in cat_name.lower() for keyword in ADULT_KEYWORDS):
            continue
        filtered_categories.append(category)
    for category in filtered_categories:
        add_dir(f"{category['category_name']}", {'action': 'list_live_streams', 'category_id': category['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_live_streams(api, category_id, server, username, password, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Canais Ao Vivo[/COLOR][/B]")
    streams = api.get_live_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    adult_filter_enabled = get_setting('adult_filter') == 'true'
    show_epg_enabled = get_setting('show_epg') == 'true'

    epg = None
    epg_channels_by_name = None
    if show_epg_enabled:
        epg_xml_path = get_epg_xml_path(server)
        if not os.path.exists(epg_xml_path):
            download_epg(server, username, password)
        epg = load_epg(epg_xml_path)
        if epg and epg.get('channels'):
            epg_channels_by_name = {normalize_epg_channel_id(name): cid for cid, name in epg['channels'].items()}

    for stream in streams:
        title = stream.get('name', '[B][COLORwhite]Sem Título[/COLOR][/B]')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        epg_channel_id = stream.get('epg_channel_id')

        if adult_filter_enabled and any(keyword in title.lower() for keyword in ADULT_KEYWORDS):
            continue

        epg_title = ""
        epg_plot = ""
        
        if show_epg_enabled and epg:
            cid_to_lookup = None
            if epg_channel_id:
                cid_to_lookup = normalize_epg_channel_id(epg_channel_id)
            elif epg_channels_by_name:
                normalized_title = normalize_epg_channel_id(title)
                cid_to_lookup = epg_channels_by_name.get(normalized_title)
            
            if cid_to_lookup and cid_to_lookup in epg['progs']:
                current, nextp = epg_lookup_current_next(cid_to_lookup, epg)
                if current:
                    start_time = datetime.fromtimestamp(current.get('start')).strftime('%H:%M')
                    end_time = datetime.fromtimestamp(current.get('end')).strftime('%H:%M')
                    epg_title = html.unescape(current.get('title', '').strip())
                    epg_desc = html.unescape(current.get('desc', '').strip())
                    epg_plot = f"[B][COLORwhite][{start_time} - {end_time}] Agora: {epg_title}[/COLOR][/B]\n{epg_desc}"
                if nextp:
                    next_start_time = datetime.fromtimestamp(nextp.get('start')).strftime('%H:%M')
                    next_end_time = datetime.fromtimestamp(nextp.get('end')).strftime('%H:%M')
                    next_title = html.unescape(nextp.get('title', '').strip())
                    next_desc = html.unescape(nextp.get('desc', '').strip())
                    epg_plot += f"\n\n[B][COLORwhite][{next_start_time} - {next_end_time}] Próximo: {next_title}[/COLOR][/B]\n{next_desc}"
                if epg_title:
                    title = f"{title} | [COLORwhite]{epg_title}[/COLOR]"

        plot_text = f"[B][COLORwhite]Canal: {stream.get('name', 'N/A')}[/COLOR][/B]\n[B][COLORwhite]Tipo: Live[/COLOR][/B]"
        if epg_plot:
            plot_text += f"\n\n[B][COLORwhite]-- EPG --[/COLOR][/B]\n{epg_plot}"

        li = xbmcgui.ListItem(label=f"[B][COLORwhite]{title}[/COLOR][/B]")
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": title, "plot": plot_text, "genre": "[B][COLORwhite]Live[/COLOR][/B]"})
        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'live', 'category_name': category_name, 'server_index': server_index})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_categories(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Categorias Filmes (VOD)[/COLOR][/B]")
    categories = api.get_vod_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    adult_filter_enabled = get_setting('adult_filter') == 'true'
    filtered_categories = []
    for category in categories:
        cat_name = category['category_name']
        if adult_filter_enabled and any(keyword in cat_name.lower() for keyword in ADULT_KEYWORDS):
            continue
        filtered_categories.append(category)
    for category in filtered_categories:
        add_dir(f"{category['category_name']}", {'action': 'list_vod_streams', 'category_id': category['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_streams(api, category_id, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Filmes (VOD)[/COLOR][/B]")
    streams = api.get_vod_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = get_setting('adult_filter') == 'true'
    for stream in streams:
        title = stream.get('name', '[B][COLORwhite]Sem Título[/COLOR][/B]')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        
        plot = stream.get('plot')
        if not plot:
            info_dict = stream.get('info')
            if isinstance(info_dict, dict):
                plot = info_dict.get('plot')
        
        plot = plot or '[COLORwhite]Sem sinopse.[/COLOR]'
        
        if adult_filter_enabled and any(keyword in title.lower() for keyword in ADULT_KEYWORDS):
            continue
            
        li = xbmcgui.ListItem(label=f"[B][COLORwhite]{title}[/COLOR][/B]")
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        
        li.setInfo("video", {"title": title, "plot": f"[B][COLORwhite]Filme: {title}[/COLOR][/B]\n[B][COLORwhite]Tipo: VOD[/COLOR][/B]\n\n[B][COLORwhite]Sinopse: {plot}[/COLOR][/B]", "genre": "[B][COLORwhite]VOD[/COLOR][/B]"})
        
        url = build_url({'action': 'play_stream', 'stream_id': stream_id, 'stream_type': 'vod', 'category_name': category_name, 'server_index': server_index})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_series_categories(api, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Categorias Séries[/COLOR][/B]")
    categories = api.get_series_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = get_setting('adult_filter') == 'true'
    filtered_categories = []
    for category in categories:
        cat_name = category['category_name']
        if adult_filter_enabled and any(keyword in cat_name.lower() for keyword in ADULT_KEYWORDS):
            continue
        filtered_categories.append(category)
    for category in filtered_categories:
        add_dir(f"{category['category_name']}", {'action': 'list_series', 'category_id': category['category_id'], 'category_name': category_name, 'server_index': server_index})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_series(api, category_id, category_name, server_index):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Séries[/COLOR][/B]")
    series_list = api.get_series(category_id)
    if series_list is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    adult_filter_enabled = get_setting('adult_filter') == 'true'
    for series in series_list:
        title = series.get('name', '[B][COLORwhite]Sem Título[/COLOR][/B]')
        series_id = series.get('series_id')
        series_icon = series.get('cover', 'DefaultVideo.png')
        plot = series.get('plot', '[COLORwhite]Sem sinopse.[/COLOR]')
        if adult_filter_enabled and any(keyword in title.lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(f"{title}", {'action': 'list_episodes', 'series_id': series_id, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon}, series_icon, series_icon, plot=f"[B][COLORwhite]Série: {title}[/COLOR][/B]\n[B][COLORwhite]Tipo: Série[/COLOR][/B]\n\n[B][COLORwhite]Sinopse: {plot}[/COLOR][/B]")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_episodes(api, series_id, category_name, server_index, series_icon):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Episódios[/COLOR][/B]")
    series_info = api.get_series_info(series_id)
    if series_info is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes_by_season = series_info.get('episodes', {})
    for season_number, episodes in episodes_by_season.items():
        season_title = f"[COLOR white]Temporada {season_number}[/COLOR]"
        add_dir(season_title, {'action': 'list_episodes_for_season', 'series_id': series_id, 'season_number': season_number, 'category_name': category_name, 'server_index': server_index, 'series_icon': series_icon})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes_for_season(api, series_id, season_number, category_name, server_index, series_icon):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "[B][COLORwhite]Episódios[/COLOR][/B]")
    series_info = api.get_series_info(series_id)
    if series_info is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes = series_info.get('episodes', {}).get(season_number, [])
    adult_filter_enabled = get_setting('adult_filter') == 'true'
    for episode in episodes:
        episode_num = episode.get('episode_num')
        episode_title = episode.get('title', f"[B][COLORwhite]Episódio {episode_num}[/COLOR][/B]")
        episode_id = episode.get('id')
        plot = episode.get('info', {}).get('plot', '[COLORwhite]Sem sinopse.[/COLOR]')
        if adult_filter_enabled and any(keyword in episode_title.lower() for keyword in ADULT_KEYWORDS):
            continue
        li = xbmcgui.ListItem(label=f"[B][COLORwhite]{episode_title}[/COLOR][/B]")
        li.setArt({'thumb': series_icon, 'icon': series_icon, 'fanart': series_icon})
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {"title": episode_title, "genre": "[B][COLORwhite]Series[/COLOR][/B]", "plot": f"[B][COLORwhite]Episódio: {episode_title}[/COLOR][/B]\n[B][COLORwhite]Tipo: Série[/COLOR][/B]\n\n[B][COLORwhite]Sinopse: {plot}[/COLOR][/B]"})
        url = build_url({'action': 'play_stream', 'stream_id': episode_id, 'stream_type': 'series', 'category_name': category_name, 'server_index': server_index})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def resolve_and_play_stream(api, stream_id, stream_type):
    stream_url = None
    if stream_type == 'live':
        stream_url = api.get_live_stream_url(stream_id)
    elif stream_type == 'vod':
        stream_url = api.get_vod_stream_url(stream_id)
    elif stream_type == 'series':
        stream_url = api.get_series_stream_url(stream_id)
    else:
        xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", "[B][COLORwhite]Tipo de stream desconhecido.[/COLOR][/B]")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)
        return

    if stream_url:
        # --- MODIFICAÇÃO INICIADA ---
        if stream_type == 'live':
            proxy_addon = HLSAddon(ADDON_HANDLE)
            proxy_addon.play_stream(stream_url, stream_type)
        else: # vod e series
            proxy_addon = VODAddon(ADDON_HANDLE)
            proxy_addon.play_stream(stream_url, stream_type)
        # --- MODIFICAÇÃO FINALIZADA ---
    else:
        xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", f"[B][COLORwhite]Não foi possível obter a URL para o tipo '{stream_type}'.[/COLOR][/B]")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if action is None:
        servers_menu()
        return

    if action == 'category_menu':
        category_menu(params.get('category_name'))
        return

    category_name = params.get('category_name')
    server_index = params.get('server_index')
    series_icon = params.get('series_icon')

    if not category_name or server_index is None:
        # Ação 'play_stream' não precisa de seleção de servidor se já tiver os dados
        if 'play_stream' not in action:
             xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", "[B][COLORwhite]Servidor não selecionado.[/COLOR][/B]")
             return

    try:
        menu = get_remote_menu()
        category = next((c for c in menu if c.get("categoria") == category_name), None)
        if not category:
            xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", "[B][COLORwhite]Categoria do servidor não encontrada no menu remoto.[/COLOR][/B]")
            return

        server_info = category['servidores'][int(server_index)]
        server = server_info.get('dns')
        username = server_info.get('username')
        password = server_info.get('password')

        if not all([server, username, password]):
            xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", "[B][COLORwhite]Credenciais inválidas para o servidor.[/COLOR][/B]")
            return
    except (IndexError, ValueError):
        xbmcgui.Dialog().ok("[B][COLORwhite]Erro[/COLOR][/B]", "[B][COLORwhite]Índice de servidor inválido.[/COLOR][/B]")
        return

    api = XtreamAPI(server, username, password)

    if action == 'server_home':
        main_menu(api, category_name, server_index)
    elif action == 'list_live_categories':
        list_live_categories(api, server, username, password, category_name, server_index)
    elif action == 'list_live_streams':
        list_live_streams(api, params['category_id'], server, username, password, category_name, server_index)
    elif action == 'list_vod_categories':
        list_vod_categories(api, category_name, server_index)
    elif action == 'list_vod_streams':
        list_vod_streams(api, params['category_id'], category_name, server_index)
    elif action == 'list_series_categories':
        list_series_categories(api, category_name, server_index)
    elif action == 'list_series':
        list_series(api, params['category_id'], category_name, server_index)
    elif action == 'list_episodes':
        list_episodes(api, params['series_id'], category_name, server_index, series_icon)
    elif action == 'list_episodes_for_season':
        list_episodes_for_season(api, params['series_id'], params['season_number'], category_name, server_index, series_icon)
    elif action == 'play_stream':
        resolve_and_play_stream(api, params['stream_id'], params['stream_type'])

if __name__ == '__main__':
    router(sys.argv[2][1:])