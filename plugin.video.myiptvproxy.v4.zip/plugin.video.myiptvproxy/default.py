# -*- coding: utf-8 -*-

import sys
import threading
import time
import re
import socket
import traceback
import select
from queue import Empty, Full, Queue
from urllib.parse import parse_qsl, urlparse, urljoin, quote, unquote
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from typing import Optional, Dict, Tuple
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, HTTPServer
from io import BytesIO

# --- Resolvedor DoH (DNS-over-HTTPS) otimizado para Cloudflare ---
DOH_RESOLVER_URL = 'https://cloudflare-dns.com/dns-query'
DNS_CACHE: Dict[str, Tuple[str, float]] = {}
DNS_CACHE_TTL = 300  # 5 minutos

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

def get_setting_int(setting_id: str, default_value: int) -> int:
    try:
        return int(ADDON.getSetting(setting_id))
    except (ValueError, TypeError):
        return default_value

def get_setting_float(setting_id: str, default_value: float) -> float:
    try:
        return float(ADDON.getSetting(setting_id))
    except (ValueError, TypeError):
        return default_value

def get_setting_bool(setting_id: str, default_value: bool) -> bool:
    try:
        return ADDON.getSettingBool(setting_id)
    except Exception:
        return default_value

def resolve_hostname_doh(hostname: str) -> Optional[str]:
    """
    Resolve um hostname para IP via DNS-over-HTTPS com retentativas, agindo como um "túnel"
    estável para a resolução de nomes, evitando instabilidades e bloqueios de DNS.
    """
    now = time.time()
    cached = DNS_CACHE.get(hostname)
    if cached and now < cached[1]:
        return cached[0]

    headers = {'accept': 'application/dns-json'}
    params = {'name': hostname, 'type': 'A'}
    for attempt in range(3):
        try:
            resp = requests.get(DOH_RESOLVER_URL, headers=headers, params=params, timeout=2)
            resp.raise_for_status()
            data = resp.json()
            if data.get("Status") == 0 and "Answer" in data:
                for answer in data["Answer"]:
                    if answer.get("type") == 1:
                        ip = answer.get("data")
                        DNS_CACHE[hostname] = (ip, now + DNS_CACHE_TTL)
                        xbmc.log(f"[IPTV PROXY DOH] {hostname} => {ip}", xbmc.LOGINFO)
                        return ip
        except Exception as e:
            xbmc.log(f"[IPTV PROXY DOH] Erro ao resolver {hostname} via DoH (tentativa {attempt+1}): {e}", xbmc.LOGWARNING)
            time.sleep(0.2)
    return None

def get_url_with_resolved_ip(url: str) -> str:
    try:
        parsed = urlparse(url)
        if not parsed.hostname: return url
        
        ip = resolve_hostname_doh(parsed.hostname) if get_setting_bool('enable_doh', True) else None
        if not ip:
            try:
                ip = socket.gethostbyname(parsed.hostname)
            except socket.gaierror:
                return url

        if ip and parsed.hostname != ip:
            netloc = ip
            if parsed.port: netloc += f":{parsed.port}"
            if parsed.username:
                netloc = f"{parsed.username}:{parsed.password or ''}@{netloc}"
            return parsed._replace(netloc=netloc).geturl()
    except Exception:
        pass
    return url

# Cabeçalhos padrão para imitar o Exoplayer
DEFAULT_EXOPLAYER_HEADERS = {
    'User-Agent': 'ExoPlayer/2.18.1 (Linux; Android 10) ExoPlayerLib/2.18.1',
    'Accept': 'application/vnd.apple.mpegurl, application/x-mpegurl, application/octet-stream, */*',
    'Accept-Encoding': 'gzip, deflate, identity',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'video/mp2t, audio/aac, audio/mpeg, audio/mp4, video/mp4, application/x-mpegURL',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
}

REQUEST_RETRIES = max(get_setting_int('request_retries', 8), 4)
REQUEST_TIMEOUT = max(get_setting_float('request_timeout', 12.0), 8.0)
CONNECTION_POOL_SIZE = max(get_setting_int('connection_pool_size', 8), 6)
# Configuração do buffer/chunksize através do settings.xml
BUFFER_CHUNK_SIZE = max(get_setting_int('buffer_chunk_size_kb', 64) * 1024, 16 * 1024)

BLOCKED_RESPONSE_HEADERS = ['transfer-encoding', 'connection', 'content-encoding', 'keep-alive']

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

class LRUCache:
    def __init__(self, capacity_bytes: int):
        self.capacity, self.cache, self.current_size, self.lock = capacity_bytes, OrderedDict(), 0, threading.Lock()
    def get(self, key: str) -> Optional[bytes]:
        with self.lock:
            if key not in self.cache: return None
            self.cache.move_to_end(key)
            return self.cache[key]
    def put(self, key: str, value: bytes):
        with self.lock:
            value_size = sys.getsizeof(value)
            if value_size > self.capacity: return
            if key in self.cache: self.current_size -= sys.getsizeof(self.cache.pop(key))
            while self.current_size + value_size > self.capacity: self.current_size -= sys.getsizeof(self.cache.popitem(last=False)[1])
            self.cache[key], self.current_size = value, self.current_size + value_size
    def clear(self):
        with self.lock: self.cache.clear(); self.current_size = 0

class ConnectionPool:
    def __init__(self, size=CONNECTION_POOL_SIZE):
        self.pool = Queue(maxsize=size)
        self.size = size
        for _ in range(self.size): self._add_session()
    def _add_session(self):
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=self.size, pool_maxsize=self.size*2)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        try: self.pool.put_nowait(session)
        except Full: session.close()
    def get_session(self) -> requests.Session:
        try: return self.pool.get(timeout=2)
        except Empty:
            self._add_session()
            return self.pool.get()
    def return_session(self, session: requests.Session):
        try: self.pool.put_nowait(session)
        except Full: session.close()

class StreamProxy:
    _instance: Optional['StreamProxy'] = None
    _lock = threading.Lock()

    def __init__(self, stream_url: str):
        self.original_stream_url = stream_url
        self.stop_event = threading.Event()
        self.http_server: Optional[HTTPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.local_port: Optional[int] = None
        self.connection_pool = ConnectionPool()
        self.video_cache = LRUCache(capacity_bytes=20 * 1024 * 1024)

    def _fetch_url(self, url: str, session: requests.Session, headers: Optional[Dict] = None, stream=False):
        req_headers = DEFAULT_EXOPLAYER_HEADERS.copy()
        if 'Host' not in req_headers: req_headers['Host'] = urlparse(self.original_stream_url).hostname
        if headers: req_headers.update(headers)
        
        url_to_fetch, last_exception = get_url_with_resolved_ip(url), ""
        for attempt in range(REQUEST_RETRIES):
            if self.stop_event.is_set():
                return None, "Proxy parado"
            try:
                response = session.get(url_to_fetch, headers=req_headers, stream=stream, timeout=REQUEST_TIMEOUT, allow_redirects=True, verify=False)
                response.raise_for_status()
                return response, None
            except requests.exceptions.RequestException as e:
                last_exception = str(e)
                if hasattr(e, 'response') and e.response and 400 <= e.response.status_code < 500:
                    return None, f"Erro de Cliente: {e.response.status_code}"
                xbmc.log(f"[IPTV PROXY] Erro ao buscar {url} (tentativa {attempt+1}): {e}", xbmc.LOGWARNING)
                time.sleep(0.1 * (2 ** attempt))
        return None, f"Falha ao buscar {url} após {REQUEST_RETRIES} tentativas. Último erro: {last_exception}"

    def ts_live_stream_v4(self, ts_url: str, handler):
        """
        Downloader de TS com foco em streams ao vivo.
        Mantém o fluxo contínuo, reconectando sem tentar voltar no tempo.
        """
        session = self.connection_pool.get_session()
        headers_sent = False
        consecutive_failures = 0
        
        while not self.stop_event.is_set():
            req_headers = DEFAULT_EXOPLAYER_HEADERS.copy()
            req_headers['Host'] = urlparse(self.original_stream_url).hostname
            
            url_to_fetch = get_url_with_resolved_ip(ts_url)
            response = None
            try:
                response = session.get(url_to_fetch, headers=req_headers, stream=True, timeout=REQUEST_TIMEOUT, verify=False)
                response.raise_for_status()
                consecutive_failures = 0
                
                if not headers_sent:
                    handler.send_response(response.status_code)
                    for h_key, h_val in response.headers.items():
                        if h_key.lower() not in BLOCKED_RESPONSE_HEADERS:
                             handler.send_header(h_key, h_val)
                    if 'content-type' not in response.headers:
                        handler.send_header('Content-Type', 'video/mp2t')
                    handler.end_headers()
                    headers_sent = True

                for chunk in response.iter_content(chunk_size=BUFFER_CHUNK_SIZE):
                    if not chunk:
                        continue
                    handler.wfile.write(chunk)
                    
                response.close()
                xbmc.log(f"[IPTV PROXY] Stream de {ts_url} terminou, reconectando...", xbmc.LOGINFO)
                
            except requests.exceptions.HTTPError as e:
                xbmc.log(f"[IPTV PROXY] HTTP Erro para {ts_url}: {e}. Reconectando...", xbmc.LOGWARNING)
                consecutive_failures += 1
                time.sleep(min(1 * (2 ** min(consecutive_failures, 5)), 5))
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, requests.exceptions.ChunkedEncodingError) as e:
                xbmc.log(f"[IPTV PROXY] Erro de conexão para {ts_url}: {e}. Reconectando...", xbmc.LOGWARNING)
                consecutive_failures += 1
                time.sleep(min(1 * (2 ** min(consecutive_failures, 5)), 5))
            except (BrokenPipeError, ConnectionResetError):
                xbmc.log(f"[IPTV PROXY] Cliente Kodi desconectou de {ts_url}. Encerrando.", xbmc.LOGINFO)
                break
            except Exception as e:
                xbmc.log(f"[IPTV PROXY] Erro inesperado no stream {ts_url}: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
                consecutive_failures += 1
                time.sleep(min(1 * (2 ** min(consecutive_failures, 5)), 5))
            finally:
                if response: response.close()
        
        self.connection_pool.return_session(session)

    def start(self) -> Optional[str]:
        class ProxyHTTPHandler(BaseHTTPRequestHandler):
            _proxy_instance = self

            def do_GET(self):
                xbmc.log(f"[IPTV PROXY HTTP] Requisição GET: {self.path}", xbmc.LOGINFO)
                
                requested_path = self.path[1:] if self.path.startswith('/') else self.path

                if requested_path.startswith("stream?"):
                    query_params = dict(parse_qsl(urlparse(self.path).query))
                    remote_url = unquote(query_params.get('url', ''))

                    if not remote_url:
                        self.send_error(400, "URL não fornecida.")
                        return

                    if remote_url.endswith('.m3u8'):
                        session = ProxyHTTPHandler._proxy_instance.connection_pool.get_session()
                        try:
                            response, error = ProxyHTTPHandler._proxy_instance._fetch_url(remote_url, session)
                            if error or not response:
                                self.send_error(502, f"Falha ao buscar playlist: {error}")
                                return
                            
                            self.send_response(200)
                            for k, v in response.headers.items():
                                if k.lower() not in BLOCKED_RESPONSE_HEADERS:
                                    self.send_header(k, v)
                            if 'content-type' not in response.headers:
                                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                            self.end_headers()

                            proxy_base = f"http://127.0.0.1:{ProxyHTTPHandler._proxy_instance.local_port}/stream?url="
                            response_data = []
                            for line in response.text.splitlines():
                                line = line.strip()
                                if not line: continue
                                if line.startswith('#'):
                                    if 'URI="' in line:
                                        uri = re.search(r'URI="([^"]+)"', line).group(1)
                                        line = line.replace(uri, proxy_base + quote(urljoin(remote_url, uri)))
                                elif not line.startswith('http'):
                                    line = proxy_base + quote(urljoin(remote_url, line))
                                else:
                                    line = proxy_base + quote(line)
                                response_data.append(line)
                            self.wfile.write('\n'.join(response_data).encode('utf-8'))
                        finally:
                            ProxyHTTPHandler._proxy_instance.connection_pool.return_session(session)

                    elif re.search(r'\.ts(\?.*)?$', remote_url, re.IGNORECASE):
                        ProxyHTTPHandler._proxy_instance.ts_live_stream_v4(remote_url, self)
                    else:
                        session = ProxyHTTPHandler._proxy_instance.connection_pool.get_session()
                        try:
                            response, error = ProxyHTTPHandler._proxy_instance._fetch_url(remote_url, session, stream=True)
                            if error or not response:
                                self.send_error(502, f"Falha ao buscar recurso: {error}")
                                return
                            self.send_response(response.status_code)
                            for k, v in response.headers.items():
                                if k.lower() not in BLOCKED_RESPONSE_HEADERS:
                                    self.send_header(k, v)
                            self.end_headers()
                            for chunk in response.iter_content(BUFFER_CHUNK_SIZE):
                                if chunk:
                                    self.wfile.write(chunk)
                        finally:
                            ProxyHTTPHandler._proxy_instance.connection_pool.return_session(session)

                else:
                    self.send_error(404, "Recurso não encontrado.")

            def log_message(self, format, *args):
                pass

        with self._lock:
            if StreamProxy._instance:
                StreamProxy._instance.stop()
            
            for port in range(50000, 50021):
                try:
                    self.http_server = HTTPServer(('127.0.0.1', port), ProxyHTTPHandler)
                    self.local_port = port
                    self.server_thread = threading.Thread(target=self.http_server.serve_forever, daemon=True)
                    self.server_thread.start()
                    xbmc.log(f"[IPTV PROXY] Servidor HTTP de reconexão bruta iniciado em http://127.0.0.1:{self.local_port}", xbmc.LOGINFO)
                    StreamProxy._instance = self
                    return f"http://127.0.0.1:{self.local_port}/stream?url={quote(self.original_stream_url)}"
                except OSError as e:
                    xbmc.log(f"[IPTV PROXY] Porta {port} em uso ou não disponível: {e}. Tentando próxima...", xbmc.LOGWARNING)
                    continue
                except Exception as e:
                    xbmc.log(f"[IPTV PROXY] Erro ao iniciar servidor HTTP na porta {port}: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
                    continue
            return None

    def stop(self):
        with self._lock:
            if self.stop_event.is_set():
                return
            self.stop_event.set()
            if self.http_server:
                threading.Thread(target=self.http_server.shutdown, daemon=True).start()
                self.http_server.server_close()
                xbmc.log("[IPTV PROXY] Servidor HTTP parado.", xbmc.LOGINFO)
            
            self.video_cache.clear()
            StreamProxy._instance = None
            xbmc.log("[IPTV PROXY] Proxy totalmente parado.", xbmc.LOGINFO)

class KodiPlayer(xbmc.Player):
    def __init__(self, *, proxy_instance: StreamProxy):
        self._proxy_instance = proxy_instance
    def onPlayBackStopped(self):
        self._cleanup("Parado")
    def onPlayBackEnded(self):
        self._cleanup("Terminado")
    def onPlayBackError(self):
        self._cleanup("com Erro")
    def _cleanup(self, reason: str):
        xbmc.log(f"[IPTV PROXY PLAYER] Playback {reason}. Limpando proxy.", xbmc.LOGINFO)
        if self._proxy_instance:
            self._proxy_instance.stop()
            self._proxy_instance = None

def play_stream(url: str, title: str):
    proxy = None
    try:
        proxy = StreamProxy(url)
        local_url = proxy.start()
        if not local_url:
            raise RuntimeError("Falha ao iniciar servidor proxy local.")
        
        player_monitor = KodiPlayer(proxy_instance=proxy)
        list_item = xbmcgui.ListItem(path=local_url)
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setMediaType('video')
        list_item.setProperty('IsPlayable', 'true')
        if url.endswith('.m3u8'):
            list_item.setMimeType('application/vnd.apple.mpegurl')
        elif re.search(r'\.ts(\?.*)?$', url, re.IGNORECASE):
            list_item.setMimeType('video/mp2t')
        else:
            list_item.setMimeType('application/octet-stream')

        xbmcplugin.setResolvedUrl(handle=_HANDLE, succeeded=True, listitem=list_item)
        
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            if not (player_monitor and player_monitor._proxy_instance):
                break
            if monitor.waitForAbort(1):
                break
    except Exception as e:
        xbmc.log(f"[IPTV PROXY MAIN] Erro fatal: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle=_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        if proxy:
            proxy.stop()

def run_addon():
    action = _ARGS.get('action')
    url = _ARGS.get('url')
    title = _ARGS.get('title')
    
    if action == 'play' and url:
        play_stream(url, title)
    elif action == 'settings':
        ADDON.openSettings()
    else:
        test_title, test_url = "Canal de Teste (HLS)", "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8"
        # test_title, test_url = "Canal de Teste (TS)", "http://clips.vorwaerts-gmbh.de/VfE_html5.mp4"

        li = xbmcgui.ListItem(label=test_title)
        li.setProperty('IsPlayable', 'true')
        play_url = f"{sys.argv[0]}?action=play&url={quote(test_url)}&title={quote(test_title)}"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=play_url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    run_addon()