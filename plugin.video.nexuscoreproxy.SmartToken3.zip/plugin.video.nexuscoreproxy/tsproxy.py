#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tsproxy.py — NEXUS CORE MPEG-TS SUTURE ENGINE (v46-STDLIB)
# Engine baseada no ZeroSutura v5.4.0 (Alinhamento Cirúrgico 188 / Sutura Incremental)

import http.server
import socketserver
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue
import collections
import json
import ipaddress
import xbmc

# ─────────────────────────────────────────────
#  CONSTANTES MPEG-TS
# ─────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

def _build_null_burst(count: int = 24) -> bytes:
    burst = bytearray()
    for i in range(count):
        cc = i & 0x0F
        hdr = bytearray([0x47, 0x1F, 0xFF, 0x10 | cc])
        burst.extend(hdr)
        burst.extend(b'\xFF' * 184)
    return bytes(burst)

NULL_PUMP_BURST    = _build_null_burst(24)
NULL_PUMP_INTERVAL = 0.100
NULL_PUMP_MAX_SECS = 2.0

CHUNK_SIZE = TS_PACKET_SIZE * 348  # 65424 bytes

MAX_SYNC_ATTEMPTS_PER_CYCLE = 5000
STALL_TIMEOUT       = 5.0
MAX_OUTPUT_BUFFER   = 48

DROP_UNTIL_KEYFRAME_MAX_PACKETS = 200
SYNC_CONFIRM_PACKETS = 16

SUTURE_TAIL_SIZE      = 12 * 1024 * 1024
SUTURE_MAX_ACCUM      = 13 * 1024 * 1024
SUTURE_MIN_LIVE_EDGE_PACKETS = 20
SUTURE_OVERLAP_WINDOW = 200

# ─────────────────────────────────────────────
#  DNS-over-HTTPS RESOLVER
# ─────────────────────────────────────────────
_DOH_PROVIDERS = [
    "https://dns.nextdns.io/629e1b",
    "https://dns.cloudflare.com/dns-query",
    "https://1.1.1.1/dns-query",
    "https://1.0.0.1/dns-query",
]
_DOH_CACHE = collections.OrderedDict()
_DOH_CACHE_MAX = 20
_DOH_CACHE_LOCK = threading.Lock()
_DOH_TIMEOUT = 3.0
_DOH_SYS_FALLBACK_TTL = 30

def _doh_is_ip_address(value: str) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

def _doh_resolve_system_dns(hostname: str, timeout: float = 1.5):
    result = [None]
    def _do_resolve():
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
            for _family, _, _, _, sockaddr in infos:
                ip = sockaddr[0]
                if ip:
                    result[0] = ip
                    break
        except Exception:
            pass
    t = threading.Thread(target=_do_resolve, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]

def _doh_resolve_provider(hostname: str, provider: str, timeout: float = _DOH_TIMEOUT):
    try:
        query = urllib.parse.urlencode({"name": hostname, "type": "A"})
        req = urllib.request.Request(
            f"{provider}?{query}",
            headers={"Accept": "application/dns-json", "User-Agent": "Mozilla/5.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8", "ignore"))
        if data.get("Status", -1) != 0:
            return None
        for answer in data.get("Answer", []):
            if answer.get("type") == 1:
                ip = str(answer.get("data", "")).strip()
                ttl = int(answer.get("TTL", 60))
                try:
                    ipaddress.IPv4Address(ip)
                    return ip, ttl
                except ValueError:
                    continue
    except Exception:
        pass
    return None

def resolve_host_doh(hostname: str):
    if not hostname or _doh_is_ip_address(hostname):
        return hostname
    now = time.time()
    with _DOH_CACHE_LOCK:
        entry = _DOH_CACHE.get(hostname)
        if entry:
            ip, expiry = entry
            if now < expiry:
                return ip
            del _DOH_CACHE[hostname]

    for provider in _DOH_PROVIDERS:
        result = _doh_resolve_provider(hostname, provider)
        if result:
            ip, ttl = result
            with _DOH_CACHE_LOCK:
                if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                    _DOH_CACHE.popitem(last=False)
                _DOH_CACHE[hostname] = (ip, now + 86400)
            return ip

    sys_ip = _doh_resolve_system_dns(hostname, timeout=1.5)
    if sys_ip:
        with _DOH_CACHE_LOCK:
            if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                _DOH_CACHE.popitem(last=False)
            _DOH_CACHE[hostname] = (sys_ip, now + _DOH_SYS_FALLBACK_TTL)
        return sys_ip
    return None

def rewrite_url_with_doh(url: str):
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host or _doh_is_ip_address(host):
        return url, ""
    ip = resolve_host_doh(host)
    if not ip:
        return url, ""
    port = parsed.port
    new_netloc = f"{ip}:{port}" if port else ip
    return urllib.parse.urlunparse(parsed._replace(netloc=new_netloc)), host

def invalidate_doh_cache(hostname: str):
    if hostname:
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.pop(hostname, None)

# ─────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)

# ─────────────────────────────────────────────
#  TsBuffer
# ─────────────────────────────────────────────
class TsBuffer:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = False
        self._pids_pending_discontinuity = set()
        self._waiting_keyframe = False
        self._packets_dropped_waiting_kf = 0

    def reset_stream_state(self):
        self._buf.clear()
        self._aligned = False
        self._cc_map.clear()
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = True
        self._pids_pending_discontinuity = set()
        self._waiting_keyframe = True
        self._packets_dropped_waiting_kf = 0

    def clear_partial_buffer(self):
        self._buf.clear()
        self._aligned = False

    def _confirm_sync(self, data, idx: int, length: int) -> bool:
        checkpoints_needed = SYNC_CONFIRM_PACKETS
        confirmed = 0
        for k in range(checkpoints_needed):
            pos = idx + k * TS_PACKET_SIZE
            if pos >= length:
                break
            if data[pos] != TS_SYNC_BYTE:
                return False
            confirmed += 1
        min_needed = min(checkpoints_needed, max(2, (length - idx) // TS_PACKET_SIZE))
        if confirmed < min_needed:
            return False
        return True

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1
        idx = self._last_sync_idx if self._last_sync_idx < length else 0
        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                self._last_sync_idx = length
                return -1
            self._sync_attempts += 1
            if self._confirm_sync(data, idx, length):
                self._last_sync_idx = idx + TS_PACKET_SIZE
                return idx
            idx += 1
        self._last_sync_idx = idx
        return -1

    @staticmethod
    def _has_idr(packet, afc: int) -> bool:
        payload_start = 4
        if afc in (2, 3):
            if len(packet) < 5:
                return False
            adapt_len = packet[4]
            payload_start = 5 + adapt_len
        if payload_start >= len(packet) - 4:
            return False
        chunk = bytes(packet[payload_start:])
        for prefix in (b'\x00\x00\x01', b'\x00\x00\x00\x01'):
            i = 0
            while True:
                i = chunk.find(prefix, i)
                if i == -1:
                    break
                nal_pos = i + len(prefix)
                if nal_pos < len(chunk):
                    nal_byte = chunk[nal_pos]
                    nal_type_h264 = nal_byte & 0x1F
                    if nal_type_h264 in (5, 6, 7, 8):
                        return True
                    nal_type_hevc = (nal_byte >> 1) & 0x3F
                    if nal_type_hevc in (19, 20, 32, 33, 34):
                        return True
                i += 1
        return False

    def _set_discontinuity_bit(self, packet: bytearray) -> bool:
        afc = (packet[3] & 0x30) >> 4
        if afc in (2, 3) and len(packet) >= 6 and packet[4] > 0:
            packet[5] |= 0x80
            return True
        return False

    def _process_packets(self, data: bytearray):
        n = len(data) // TS_PACKET_SIZE
        out = bytearray()
        mv = memoryview(data)
        for i in range(n):
            offset = i * TS_PACKET_SIZE
            packet_view = mv[offset:offset + TS_PACKET_SIZE]
            if packet_view[0] != TS_SYNC_BYTE:
                self._error_count += 1
                self._aligned = False
                leftover = bytearray(mv[offset:])
                return out, leftover
            packet = bytearray(packet_view)
            pid = ((packet[1] & 0x1F) << 8) | packet[2]
            afc = (packet[3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            cc = packet[3] & 0x0F
            if pid == 0x1FFF:
                out.extend(packet)
                continue
            if pid not in self._cc_map and self._armed_discontinuity:
                self._pids_pending_discontinuity.add(pid)
            if has_payload:
                self._cc_map[pid] = cc
            if pid in self._pids_pending_discontinuity:
                if self._set_discontinuity_bit(packet):
                    self._pids_pending_discontinuity.discard(pid)
            if self._waiting_keyframe:
                self._packets_dropped_waiting_kf += 1
                if self._has_idr(memoryview(packet), afc):
                    self._waiting_keyframe = False
                elif self._packets_dropped_waiting_kf < DROP_UNTIL_KEYFRAME_MAX_PACKETS:
                    if pid > 0x0020:
                        continue
                else:
                    self._waiting_keyframe = False
            out.extend(packet)
        if self._armed_discontinuity and n > 0:
            self._armed_discontinuity = False
        return out, bytearray()

    def feed(self, raw: bytes) -> bytes:
        if not raw:
            return b''
        self._buf.extend(raw)
        result = bytearray()
        while True:
            if not self._aligned:
                self._sync_attempts = 0
                self._last_sync_idx = 0
                idx = self._find_sync(self._buf)
                if idx == -1:
                    if len(self._buf) > TS_PACKET_SIZE * 100:
                        keep_tail = TS_PACKET_SIZE * 2
                        del self._buf[:-keep_tail]
                    return bytes(result)
                if idx > 0:
                    del self._buf[:idx]
                self._aligned = True
            buf_len = len(self._buf)
            usable = buf_len - (buf_len % TS_PACKET_SIZE)
            if usable == 0:
                return bytes(result)
            payload = self._buf[:usable]
            del self._buf[:usable]
            processed, leftover = self._process_packets(payload)
            if processed:
                result.extend(processed)
            if leftover:
                self._buf[0:0] = leftover
                continue
            return bytes(result)

# ─────────────────────────────────────────────
#  SutureManager
# ─────────────────────────────────────────────
class SutureManager:
    def __init__(self, max_history: int = 500):
        self._hashes = collections.deque(maxlen=max_history)
        self._recent_set = collections.deque(maxlen=SUTURE_OVERLAP_WINDOW)
        self._recent_membership = set()
        self._lock = threading.Lock()

    @staticmethod
    def _get_packet_hash(pkt) -> int:
        if len(pkt) < 188:
            return None
        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if pid == 0x1FFF:
            return None
        afc = (pkt[3] & 0x30) >> 4
        if afc in (1, 3):
            payload_start = 4
            if afc == 3:
                if len(pkt) < 5:
                    return None
                adapt_len = pkt[4]
                payload_start = 5 + adapt_len
            if payload_start + 16 <= 188:
                return hash(bytes(pkt[payload_start:payload_start + 16]))
        return None

    def add_played(self, data: bytes):
        if not data:
            return
        mv = memoryview(data)
        n = len(data) // 188
        with self._lock:
            for i in range(n):
                offset = i * 188
                h = self._get_packet_hash(mv[offset:offset + 188])
                if h is None:
                    continue
                self._hashes.append(h)
                if len(self._recent_set) == self._recent_set.maxlen:
                    evicted = self._recent_set[0]
                self._recent_set.append(h)
                self._recent_membership.add(h)
            if len(self._recent_set) == self._recent_set.maxlen:
                self._recent_membership = set(self._recent_set)

    def find_any_overlap_incremental(self, packet_hashes) -> bool:
        with self._lock:
            if not self._recent_membership:
                return False
            for h in packet_hashes:
                if h is not None and h in self._recent_membership:
                    return True
            return False

    def find_suture_incremental(self, packet_hashes, start_index: int) -> int:
        with self._lock:
            if len(self._hashes) < 3:
                return -1
            target = (self._hashes[-3], self._hashes[-2], self._hashes[-1])
        n = len(packet_hashes)
        i = start_index
        while i <= n - 3:
            if (packet_hashes[i] == target[0] and
                    packet_hashes[i + 1] == target[1] and
                    packet_hashes[i + 2] == target[2]):
                return i + 3
            i += 1
        return -1

    def clear(self):
        with self._lock:
            self._hashes.clear()
            self._recent_set.clear()
            self._recent_membership.clear()

class SutureSearchState:
    __slots__ = ("accum", "hashes", "scanned_packets", "leftover")
    def __init__(self):
        self.accum = bytearray()
        self.hashes = []
        self.scanned_packets = 0
        self.leftover = bytearray()

    def feed(self, raw: bytes, suture_mgr: SutureManager):
        if self.leftover:
            raw = bytes(self.leftover) + raw
            self.leftover = bytearray()
        usable_len = len(raw) - (len(raw) % 188)
        if usable_len < len(raw):
            self.leftover = bytearray(raw[usable_len:])
            raw = raw[:usable_len]
        if not raw:
            return
        self.accum.extend(raw)
        n = len(raw) // 188
        mv = memoryview(raw)
        for i in range(n):
            offset = i * 188
            h = SutureManager._get_packet_hash(mv[offset:offset + 188])
            self.hashes.append(h)

    def total_packets(self) -> int:
        return len(self.hashes)

    def bytes_len(self) -> int:
        return len(self.accum)

    def clear(self):
        self.accum = bytearray()
        self.hashes = []
        self.scanned_packets = 0
        self.leftover = bytearray()

# ─────────────────────────────────────────────
#  OutputBuffer
# ─────────────────────────────────────────────
class OutputBuffer:
    def __init__(self, max_packets: int = MAX_OUTPUT_BUFFER):
        self._queue = queue.Queue(maxsize=max_packets)
        self._lock = threading.Lock()
        self._align_residual = bytearray()

    def put(self, data: bytes) -> bool:
        if not data:
            return True
        with self._lock:
            self._align_residual.extend(data)
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                return True
            chunk = bytes(self._align_residual[:usable])
            del self._align_residual[:usable]
            try:
                self._queue.put_nowait(chunk)
                return True
            except queue.Full:
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._queue.put_nowait(chunk)
                except queue.Full:
                    pass
                return True

    def clear(self):
        with self._lock:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    break
            self._align_residual.clear()

    def flush_to_writer(self, writer_func) -> bool:
        while True:
            try:
                data = self._queue.get_nowait()
                if data:
                    remainder = len(data) % TS_PACKET_SIZE
                    if remainder:
                        data = data[:-remainder]
                    if data and not writer_func(data):
                        return False
            except queue.Empty:
                return True

    def drain_residual(self, writer_func) -> bool:
        with self._lock:
            if not self._align_residual:
                return True
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                self._align_residual.clear()
                return True
            chunk = bytes(self._align_residual[:usable])
            self._align_residual.clear()
        if chunk:
            return writer_func(chunk)
        return True

# ─────────────────────────────────────────────
#  REDIRECT HANDLER
# ─────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

class SessionManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._session = None
                cls._instance._last_clean = 0
            return cls._instance

    def get_session(self):
        now = time.time()
        if self._session is None or now - self._last_clean > 30:
            if self._session:
                try:
                    self._session.close()
                except Exception:
                    pass
            self._session = urllib.request.build_opener(
                urllib.request.HTTPHandler(),
                urllib.request.HTTPSHandler(),
                NoRedirectHandler
            )
            self._last_clean = now
        return self._session

    def invalidate(self):
        with self._lock:
            if self._session:
                try:
                    self._session.close()
                except Exception:
                    pass
            self._session = None
            self._last_clean = 0

# ─────────────────────────────────────────────
#  SERVIDOR HTTP PROXY
# ─────────────────────────────────────────────
class TSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        xbmc.log(f"[NexusCore-TSProxy] {format % args}", xbmc.LOGDEBUG)

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True
        remainder = len(data) % TS_PACKET_SIZE
        if remainder:
            data = data[:-remainder]
        if not data:
            return True
        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError, ConnectionAbortedError):
            return False

    def _null_pump(self, duration: float) -> bool:
        actual_duration = min(duration, NULL_PUMP_MAX_SECS)
        cycles = max(1, int(actual_duration / NULL_PUMP_INTERVAL))
        for _ in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            time.sleep(NULL_PUMP_INTERVAL)
        return True

    def _calculate_backoff(self, reconnect_num: int) -> float:
        if reconnect_num <= 2:
            return 0.3 + reconnect_num * 0.25
        elif reconnect_num <= 6:
            return 0.8 + (reconnect_num - 2) * 0.4
        return min(4.0, 2.4 + (reconnect_num - 6) * 0.2)

    def _resolve_url(self, url: str, ua: str) -> str:
        curr = url
        for _ in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                fetch_url, doh_host = rewrite_url_with_doh(curr)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Connection': 'close',
                }
                if not doh_host:
                    fetch_url = curr
                req = urllib.request.Request(fetch_url, headers=headers)
                try:
                    with SessionManager().get_session().open(req, timeout=8) as resp:
                        if resp.code in (301, 302, 303, 307, 308):
                            loc = resp.headers.get('Location')
                            if loc:
                                curr = urllib.parse.urljoin(curr, loc)
                                continue
                        return curr
                except Exception:
                    if doh_host:
                        invalidate_doh_cache(doh_host)
                    raise
            except Exception:
                break
        return curr

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(400)
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        resolved_url = original_url
        ua = _pick_ua()
        reconnect_num = 0
        ts_buf = TsBuffer()
        output_buf = OutputBuffer()
        last_useful_payload = time.time()
        consecutive_empty_reads = 0

        suture_mgr = SutureManager()
        has_played_data = False
        force_hard_reset = False

        while True:
            output_buf.clear()
            last_useful_payload = time.time()
            consecutive_empty_reads = 0

            suture_searching = has_played_data and not force_hard_reset
            if force_hard_reset:
                force_hard_reset = False
                suture_searching = False

            search_state = SutureSearchState() if suture_searching else None

            if not suture_searching:
                ts_buf.reset_stream_state()

            try:
                parsed = urllib.parse.urlparse(resolved_url)
                fetch_url, doh_host = rewrite_url_with_doh(resolved_url)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Referer': original_url,
                    'Connection': 'close',
                }
                if not doh_host:
                    fetch_url = resolved_url
                req = urllib.request.Request(fetch_url, headers=headers)

                with SessionManager().get_session().open(req, timeout=12) as response:
                    if reconnect_num == 0:
                        xbmc.log(f"[NexusCore-TSProxy] Conectado -> {ua[:40]}...", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"[NexusCore-TSProxy] Reconectado #{reconnect_num}", xbmc.LOGINFO)
                        reconnect_num = max(0, reconnect_num - 2)

                    while True:
                        try:
                            raw = response.read(CHUNK_SIZE)
                        except Exception:
                            break

                        if not raw:
                            consecutive_empty_reads += 1
                            if consecutive_empty_reads >= 2:
                                break
                            time.sleep(0.05)
                            continue

                        consecutive_empty_reads = 0

                        if suture_searching:
                            search_state.feed(raw, suture_mgr)
                            last_useful_payload = time.time()

                            has_overlap = suture_mgr.find_any_overlap_incremental(
                                search_state.hashes[search_state.scanned_packets:]
                            ) or suture_mgr.find_any_overlap_incremental(search_state.hashes)

                            total_pkts = search_state.total_packets()

                            if not has_overlap and total_pkts > SUTURE_MIN_LIVE_EDGE_PACKETS:
                                all_raw = bytes(search_state.accum)
                                search_state.clear()
                                suture_searching = False
                                last_useful_payload = time.time()

                                ts_buf.reset_stream_state()
                                payload = ts_buf.feed(all_raw)
                                if payload:
                                    output_buf.put(payload)
                                    if not output_buf.flush_to_writer(self._safe_write):
                                        return
                                    suture_mgr.add_played(payload)
                                    has_played_data = True

                            elif has_overlap:
                                end_idx = suture_mgr.find_suture_incremental(
                                    search_state.hashes, search_state.scanned_packets
                                )

                                if end_idx != -1:
                                    skip = end_idx * TS_PACKET_SIZE
                                    xbmc.log(f"[NexusCore-TSProxy] Sutura encontrada! Pulando {skip} bytes.", xbmc.LOGINFO)
                                    remaining = bytes(search_state.accum[skip:])
                                    search_state.clear()
                                    suture_searching = False
                                    last_useful_payload = time.time()

                                    if remaining and remaining[0] != TS_SYNC_BYTE:
                                        sync_idx = remaining.find(TS_SYNC_BYTE)
                                        if sync_idx != -1 and sync_idx < TS_PACKET_SIZE:
                                            remaining = remaining[sync_idx:]

                                    ts_buf.clear_partial_buffer()
                                    payload = ts_buf.feed(remaining)
                                    if payload:
                                        output_buf.put(payload)
                                        if not output_buf.flush_to_writer(self._safe_write):
                                            return
                                        suture_mgr.add_played(payload)
                                        has_played_data = True
                                else:
                                    search_state.scanned_packets = max(0, total_pkts - 2)

                                    if search_state.bytes_len() > SUTURE_MAX_ACCUM:
                                        xbmc.log(f"[NexusCore-TSProxy] Sutura falhou. Descartando e esperando IDR.", xbmc.LOGWARNING)
                                        search_state.clear()
                                        suture_searching = False
                                        ts_buf.reset_stream_state()
                                        last_useful_payload = time.time()

                        else:
                            payload = ts_buf.feed(raw)
                            if payload:
                                last_useful_payload = time.time()
                                output_buf.put(payload)
                                if not output_buf.flush_to_writer(self._safe_write):
                                    return
                                suture_mgr.add_played(payload)
                                has_played_data = True
                            elif time.time() - last_useful_payload > STALL_TIMEOUT:
                                xbmc.log("[NexusCore-TSProxy] Stall detectado - reconectando", xbmc.LOGWARNING)
                                break

            except urllib.error.HTTPError as e:
                if e.code in (401, 403):
                    SessionManager().invalidate()
                    xbmc.log(f"[NexusCore-TSProxy] Auth error {e.code} - atualizando token", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[NexusCore-TSProxy] HTTP {e.code} #{reconnect_num}", xbmc.LOGWARNING)
            except Exception as e:
                err_name = type(e).__name__
                err_msg = str(e)[:80]
                xbmc.log(f"[NexusCore-TSProxy] {err_name} #{reconnect_num}: {err_msg}", xbmc.LOGWARNING)
                _doh_host_failed = locals().get('doh_host')
                if _doh_host_failed:
                    invalidate_doh_cache(_doh_host_failed)

            if suture_searching and search_state is not None and search_state.bytes_len() > 0:
                xbmc.log(f"[NexusCore-TSProxy] Conexao caiu durante busca. Descartando buffer. Forcando hard reset.", xbmc.LOGWARNING)
                search_state.clear()
                force_hard_reset = True

            if not output_buf.flush_to_writer(self._safe_write):
                return
            if not output_buf.drain_residual(self._safe_write):
                return

            reconnect_num += 1
            ua = _pick_ua()
            backoff = self._calculate_backoff(reconnect_num)

            if not self._null_pump(backoff):
                return

            try:
                new_url = self._resolve_url(original_url, ua)
                if new_url != resolved_url:
                    resolved_url = new_url
                    xbmc.log(f"[NexusCore-TSProxy] Token atualizado #{reconnect_num}", xbmc.LOGINFO)
            except Exception:
                pass

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

_server_instance = None
_server_thread = None
_lock = threading.Lock()

def _ensure_server_running():
    global _server_instance, _server_thread
    with _lock:
        if _server_instance is None:
            port = 0 
            _server_instance = ThreadingHTTPServer(('127.0.0.1', port), TSProxyHandler)
            _server_thread = threading.Thread(target=_server_instance.serve_forever, daemon=True)
            _server_thread.start()
            actual_port = _server_instance.server_address[1]
            xbmc.log(f"[NexusCore-TSProxy] Servidor iniciado na porta {actual_port}", xbmc.LOGINFO)
            return actual_port
        return _server_instance.server_address[1]