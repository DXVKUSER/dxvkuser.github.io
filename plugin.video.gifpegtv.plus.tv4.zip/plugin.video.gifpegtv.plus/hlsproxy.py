import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
from socketserver import ThreadingMixIn

# Importa a biblioteca requests original e seus componentes necessários
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- Importação Crítica: Substitui o requests padrão pelo requests do script.module.netunblock ---
try:
    from doh_client import requests as doh_requests
except ImportError:
    doh_requests = requests
    logging.warning("Módulo 'doh_client' não encontrado. Usando requests padrão, sem DNS Over HTTPS.")

# Dependências específicas do Kodi (assumidas)
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    class MockKodi:
        def translatePath(self, path): return "/tmp/"
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    
# ---------------- CONFIG ----------------
# *** OTIMIZAÇÃO: TENTATIVAS RÁPIDAS (AGRESSIVAS) PARA SEGMENTOS ***
MAX_SEGMENT_RETRIES = 15           # Múltiplas tentativas rápidas para segmentos de vídeo
RETRY_BACKOFF_FACTOR = 0.1
# *** OTIMIZAÇÃO: TIMEOUTS AJUSTADOS PARA DETECÇÃO RÁPIDA DE FALHAS ***
CONNECTION_TIMEOUT = 10.0          # Timeout para conexões (manifestos, primeiras tentativas)
STREAM_TIMEOUT = 20.0              # Timeout base para o streaming de segmentos
DEFAULT_CHUNK_SIZE = 1024 * 64     # Chunk size base (64KB)
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"
MANIFEST_RETRY_DELAY = 0.1         # Pequeno delay entre retries de manifesto
MAX_CONSECUTIVE_SEGMENT_ERRORS = 5 # Limite para erros (ex: 404) antes do reset total

# Template do User-Agent para Rotação
USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.{version} Safari/537.36"

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# --- Dummy TS Content (Segmento AAC silencioso de 1s) ---
# *** CORREÇÃO: String HEADER_HEX corrigida, removendo possível erro de concatenação/caractere invisível. ***
TS_PACKET_SIZE = 188
HEADER_HEX = "474000100000b00d00000001e00e0000e02000000001e0310000e0414741001001d68000000021c100000000147412110"
try:
    HEADER_BYTES = bytes.fromhex(HEADER_HEX)
except ValueError as e:
    logging.critical(f"Erro na string HEADER_HEX, usando fallback: {e}")
    HEADER_BYTES = b'\x47' * 52 
FILLER_LENGTH = TS_PACKET_SIZE - len(HEADER_BYTES)
SILENT_AAC_TS_PACKET = HEADER_BYTES + (b'\xff' * FILLER_LENGTH)
SILENT_AAC_TS_CONTENT = SILENT_AAC_TS_PACKET * 5

# ---------------- UTILS ----------------
def setup_logging():
    """Configura o sistema de logging do Python para um arquivo específico do Kodi."""
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    
    # Configuração inicial do Session e Retry
    retry_strategy = Retry(
        total=MAX_SEGMENT_RETRIES,
        status_forcelist=[429, 500, 502, 503, 504, 403, 404]
    )
    
    session = doh_requests.session 

    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    
    error_counter = {}
    manifest_duration = 1.0
    
    # Variáveis de estado dinâmico (por sessão)
    network_quality = {}
    dynamic_chunk_size = {}
    dynamic_stream_timeout = {}
    last_segment_times = {}
    last_segment_sizes = {} 
    
    session_ua_versions = {}
    session_manifest_refresh = {} 
    
    MAX_TIMES_TO_AVERAGE = 10
    
    DUMMY_SEGMENT_CONTENT_TEMPLATE = SILENT_AAC_TS_CONTENT 
    DEFAULT_DUMMY_SIZE_BYTES = 50 * 1024 
    

    def log_message(self, format, *args):
        logging.info(f"{self.client_address[0]} - - \"{format % args}\"")

    def _get_session_user_agent(self, session_id):
        version = HLSProxyRequestHandler.session_ua_versions.get(session_id, random.randint(1000, 5000))
        return USER_AGENT_TEMPLATE.format(version=version)

    def _rotate_session_user_agent(self, session_id):
        current_version = HLSProxyRequestHandler.session_ua_versions.get(session_id, random.randint(1000, 5000))
        new_version = current_version + 1
        HLSProxyRequestHandler.session_ua_versions[session_id] = new_version
        logging.warning(f"Rotacionando User-Agent para versão {new_version} (Sessão: {session_id})")

    # *** OTIMIZAÇÃO: REINICIALIZAÇÃO DA SESSÃO HTTP PARA MÁXIMA RESILIÊNCIA ***
    def _reset_session_and_retry(self, session_id):
        """
        Reinicia a sessão HTTP (recria o objeto session) para recuperação de conexão, 
        força a rotação do User-Agent e o refresh do manifesto.
        """
        logging.critical(f"Reiniciando sessão HTTP (recriação) e forçando manifest refresh! (Sessão: {session_id})")
        
        # 1. Rotaciona o User-Agent
        self._rotate_session_user_agent(session_id)
        
        # 2. Cria uma nova sessão requests/doh_requests
        try:
            # Reverte para o requests.Session() do requests original, que usará o getaddrinfo sobrescrito.
            new_session = requests.Session()
        except AttributeError:
             new_session = requests.session()

        new_adapter = HTTPAdapter(max_retries=HLSProxyRequestHandler.retry_strategy)
        new_session.mount('http://', new_adapter)
        new_session.mount('https://', new_adapter)
        
        # Se doh_requests foi importado, garante que a sessão global do proxy seja a nova sessão DoH.
        # No entanto, como o doh_client.py faz a substituição do socket global,
        # qualquer requests.Session() subsequente usará DoH.
        HLSProxyRequestHandler.session = new_session
        HLSProxyRequestHandler.adapter = new_adapter
        
        # 3. Força o refresh do manifesto
        HLSProxyRequestHandler.session_manifest_refresh[session_id] = time.time()
        # 4. Reseta o contador de erros consecutivos
        self.error_counter[session_id] = 0
        
    def _get_dynamic_silent_segment(self, session_id):
        segment_sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])
        
        if segment_sizes:
            avg_size = sum(segment_sizes) / len(segment_sizes)
            target_size = max(int(avg_size * 0.8), self.DEFAULT_DUMMY_SIZE_BYTES)
        else:
            target_size = self.DEFAULT_DUMMY_SIZE_BYTES
        
        content = self.DUMMY_SEGMENT_CONTENT_TEMPLATE
        if len(content) < target_size:
            repeat_factor = (target_size // len(content)) + 1
            content = SILENT_AAC_TS_PACKET * repeat_factor
        
        final_content = content[:target_size]
        
        logging.info(f"Gerando Segmento Silencioso: Tamanho Alvo {target_size // 1024}KB (Sessão: {session_id})")
        return final_content, len(final_content)

    def _send_silent_segment(self, session_id):
        """
        Envia um segmento nulo (TS aprimorado) com status 200 OK
        para manter a reprodução ativa, simulando um segmento válido.
        """
        
        silent_content, content_length = self._get_dynamic_silent_segment(session_id)
        
        logging.warning(f"Enviando segmento silencioso (200 OK) de {content_length // 1024}KB para manter o player vivo. (Sessão: {session_id})")
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(content_length))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            self.wfile.write(silent_content)
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou conexão durante envio do segmento silencioso.")
        except Exception as e:
            logging.error(f"Erro ao enviar segmento silencioso: {e}")
            

    def _get_forward_headers(self, session_id):
        """Encaminha headers importantes e usa o User-Agent da sessão."""
        ua = self._get_session_user_agent(session_id)
        
        headers = {
            'User-Agent': ua, 
            'Connection': 'keep-alive',
        }
        if 'Authorization' in self.headers:
            headers['Authorization'] = self.headers['Authorization']
        if 'Cookie' in self.headers:
            headers['Cookie'] = self.headers['Cookie']
        return headers

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400)
                return

            headers = self._get_forward_headers(session_id)

            parsed_url = urllib.parse.urlparse(url)
            # Verifica se o path termina com .m3u8 ou .m3u, ou se a query contém manifest
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')) or 'manifest' in parsed_url.query.lower():
                self._handle_manifest(url, headers, head_only, session_id)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except Exception as e:
            logging.error(f"Erro inesperado GET: {e}")
            try:
                # *** CORREÇÃO: Evita enviar erro 500 em caso de falha genérica ***
                self.send_error(404, message="Stream/Manifest Not Found or Expired")
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante erro inesperado.")
                return


    def _handle_manifest(self, url, headers, head_only, session_id):
        should_reset_session = HLSProxyRequestHandler.session_manifest_refresh.pop(session_id, None) is not None
        
        if should_reset_session:
             logging.info(f"Executando requisição de manifesto com nova sessão/UA forçada: {session_id}")

        try:
            for attempt in range(3):
                try:
                    manifest_headers = self._get_forward_headers(session_id)
                    manifest_headers.update(headers)
                    
                    r = doh_requests.get(url, headers=manifest_headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                    
                    # *** CORREÇÃO: Trata 404/403 (token expirado) de forma mais resiliente ***
                    if r.status_code in (404, 403):
                        logging.warning(f"Manifesto 404/403 (Token Expirado?). Tentando reiniciar a sessão/UA. (Sessão: {session_id})")
                        self._rotate_session_user_agent(session_id)
                        if attempt < 2:
                             time.sleep(MANIFEST_RETRY_DELAY * (2**attempt))
                             continue
                        # Se falhou 3 vezes, não levanta exceção de status 404/403
                        raise requests.exceptions.HTTPError(f"{r.status_code} Client Error: Manifest Not Found or Forbidden")

                    r.raise_for_status() # Levanta exceção para outros erros (5xx, etc.)
                    break
                except requests.exceptions.RequestException as e:
                    logging.warning(f"Erro ao baixar manifesto: {e} (Tentativa {attempt+1}/{3}, Sessão: {session_id})")
                    
                    self._rotate_session_user_agent(session_id) 
                    
                    if attempt < 2:
                        time.sleep(MANIFEST_RETRY_DELAY * (2**attempt))
                        continue
                    raise Exception("Falha ao obter o manifesto após várias tentativas.")

            manifest_content = r.text
            base_url = r.url

            total_duration = 0.0
            segment_count = 0
            for line in manifest_content.splitlines():
                if line.startswith('#EXTINF:'):
                    try:
                        duration = float(line.split('#EXTINF:')[1].split(',')[0])
                        total_duration += duration
                        segment_count += 1
                    except (IndexError, ValueError):
                        pass

            if segment_count > 0:
                HLSProxyRequestHandler.manifest_duration = max(total_duration / segment_count, 1.0)
                logging.info(f"Duração média do segmento detectada: {self.manifest_duration:.2f}s.")

            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()

            if head_only:
                return

            new_manifest_lines = []
            for line in manifest_content.splitlines():
                stripped = line.strip()

                if stripped.upper() == '#EXT-X-ENDLIST':
                    continue

                if not stripped or stripped.startswith('#'):
                    new_manifest_lines.append(line)
                else:
                    full_segment_url = urllib.parse.urljoin(base_url, stripped)
                    proxy_segment_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_segment_url)}&session_id={session_id}"
                    new_manifest_lines.append(proxy_segment_url)

            try:
                self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning("Cliente fechou conexão durante envio do manifesto.")
                return

        except requests.exceptions.HTTPError as e:
            # Captura a exceção levantada quando 404/403 persiste ou outro erro HTTP ocorre.
            logging.error(f"Erro HTTP final ao manipular manifesto ({session_id}): {e}")
            try:
                # *** CORREÇÃO: Envia 404 para o cliente em caso de falha de manifesto ***
                # Isso sinaliza ao Kodi que o stream expirou, forçando um re-request (dependendo do player)
                # ou fechando a stream de forma limpa, evitando o 500 do proxy.
                self.send_error(404, message="Manifest Not Found/Expired after retries")
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return
        
        except Exception as e:
            logging.error(f"Erro fatal ao manipular manifesto ({session_id}): {e}")
            try:
                self.send_error(500, message="Internal Proxy Error while fetching manifest")
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                return
            
    
    def _handle_segment(self, url, session_id, headers, head_only):
        """Serve o segmento de mídia, com lógica de resiliência e recuperação de falhas."""
        retries = 0
        consecutive_errors = self.error_counter.get(session_id, 0)
        
        self._initialize_session_quality(session_id)
        
        current_chunk_size = HLSProxyRequestHandler.dynamic_chunk_size.get(session_id, DEFAULT_CHUNK_SIZE)
        current_timeout = HLSProxyRequestHandler.dynamic_stream_timeout.get(session_id, STREAM_TIMEOUT) 
        
        bytes_downloaded = 0 

        while retries < MAX_SEGMENT_RETRIES:
            start_time = time.time()
            try:
                with HLSProxyRequestHandler.session.get(url, headers=headers, stream=True,
                                                        timeout=current_timeout, verify=False) as r:
                    
                    if r.status_code == 404 or r.status_code in HLSProxyRequestHandler.retry_strategy.status_forcelist:
                        r.raise_for_status() 

                    self.error_counter[session_id] = 0
                    
                    self.send_response(r.status_code)
                    for header, value in r.headers.items():
                        if header.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.send_header(header, value)
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()

                    if head_only:
                        content_length = int(r.headers.get('Content-Length', '0'))
                        self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=content_length)
                        return

                    for chunk in r.iter_content(chunk_size=current_chunk_size):
                        if not chunk:
                            continue
                        bytes_downloaded += len(chunk)
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                            logging.warning(f"Cliente fechou conexão. (Sessão: {session_id})")
                            self._update_network_quality(session_id, start_time, time.time(), success=False, size_bytes=bytes_downloaded)
                            return
                        except Exception as e:
                            logging.error(f"Erro ao escrever chunk para o cliente: {e} (Sessão: {session_id})")
                            self._reset_session_and_retry(session_id)
                            return 

                    self._update_network_quality(session_id, start_time, time.time(), success=True, size_bytes=bytes_downloaded)
                    return
            
            except requests.exceptions.HTTPError as e:
                retries += 1
                consecutive_errors += 1
                self.error_counter[session_id] = consecutive_errors
                logging.warning(f"Erro HTTP {e.response.status_code} segmento: {url}, retry {retries}/{MAX_SEGMENT_RETRIES}, cons. {consecutive_errors} (Sessão: {session_id})")

                if e.response.status_code == 404 and consecutive_errors >= MAX_CONSECUTIVE_SEGMENT_ERRORS:
                    logging.critical(f"Limite de 404s consec. atingido. Acionando RECUPERAÇÃO AGRESSIVA! (Sessão: {session_id})")
                    self._reset_session_and_retry(session_id)
                    self._send_silent_segment(session_id)
                    return
                
                if retries < MAX_SEGMENT_RETRIES:
                    time.sleep(MANIFEST_RETRY_DELAY)

            except requests.exceptions.RequestException as e:
                retries += 1
                is_timeout = isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectTimeout))
                
                logging.warning(f"Erro de Conexão/Rede segmento {url}: {e}, retry {retries}/{MAX_SEGMENT_RETRIES} (Sessão: {session_id})")
                
                self._update_network_quality(session_id, start_time, time.time(), success=False, is_timeout=is_timeout, size_bytes=0)
                
                time.sleep(min(RETRY_BACKOFF_FACTOR * (2 ** retries), 2.0))
                
                if is_timeout or retries >= MAX_SEGMENT_RETRIES:
                    logging.critical(f"Timeout/Max Retries. Acionando RECUPERAÇÃO AGRESSIVA! (Sessão: {session_id})")
                    self._reset_session_and_retry(session_id)
                    self._send_silent_segment(session_id)
                    return 

            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                logging.warning(f"Cliente desconectado antes do fim. (Sessão: {session_id})")
                return
            except Exception as e:
                logging.error(f"Erro geral segmento {url}: {e} (Sessão: {session_id})")
                self._reset_session_and_retry(session_id)
                self._send_silent_segment(session_id)
                return

        logging.critical(f"Segmento falhou de forma irrecuperável após todos os retries. Enviando segmento silencioso. (Sessão: {session_id})")
        self._reset_session_and_retry(session_id)
        self._send_silent_segment(session_id) 

    def _initialize_session_quality(self, session_id):
        """Inicializa os parâmetros dinâmicos para uma nova sessão."""
        if session_id not in HLSProxyRequestHandler.network_quality:
            HLSProxyRequestHandler.network_quality[session_id] = "good"
            HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
            HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            HLSProxyRequestHandler.last_segment_times[session_id] = []
            HLSProxyRequestHandler.last_segment_sizes[session_id] = [] 
            HLSProxyRequestHandler.session_ua_versions[session_id] = random.randint(1000, 5000)

    def _update_network_quality(self, session_id, start_time, end_time, success, is_timeout=False, size_bytes=0):
        """Ajusta o timeout, o chunk size e registra o tamanho do segmento com base na performance."""
        self._initialize_session_quality(session_id)
        duration = end_time - start_time
        session_times = HLSProxyRequestHandler.last_segment_times.get(session_id, [])
        session_sizes = HLSProxyRequestHandler.last_segment_sizes.get(session_id, [])
        
        if success:
            session_times.append(duration)
            if size_bytes > 0:
                session_sizes.append(size_bytes)
        else:
            penalty_time = HLSProxyRequestHandler.manifest_duration * 2.0 
            session_times.append(penalty_time)
            logging.warning(f"Falha de segmento registrada. Duração/Penalidade: {penalty_time:.2f}s (Sessão: {session_id})")

        while len(session_times) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE:
            session_times.pop(0)
        while len(session_sizes) > HLSProxyRequestHandler.MAX_TIMES_TO_AVERAGE:
            session_sizes.pop(0)
        
        HLSProxyRequestHandler.last_segment_times[session_id] = session_times
        HLSProxyRequestHandler.last_segment_sizes[session_id] = session_sizes

        if not session_times:
            return 

        avg_time = sum(session_times) / len(session_times)
        current_quality = HLSProxyRequestHandler.network_quality.get(session_id, "good")
        new_quality = current_quality
        
        segment_len = HLSProxyRequestHandler.manifest_duration

        if avg_time < (segment_len * 0.5):
            new_quality = "good"
        elif avg_time < (segment_len * 1.5):
            new_quality = "medium"
        else:
            new_quality = "bad"

        if new_quality != current_quality:
            logging.info(f"Qualidade da rede mudou de '{current_quality}' para '{new_quality}' (Média tempo: {avg_time:.2f}s) (Sessão: {session_id})")
            HLSProxyRequestHandler.network_quality[session_id] = new_quality

            if new_quality == "good":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = 1024 * 128
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT * 1.5
            
            elif new_quality == "medium":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = DEFAULT_CHUNK_SIZE
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = STREAM_TIMEOUT
            
            elif new_quality == "bad":
                HLSProxyRequestHandler.dynamic_chunk_size[session_id] = 1024 * 16
                HLSProxyRequestHandler.dynamic_stream_timeout[session_id] = min(STREAM_TIMEOUT * 0.5, segment_len * 1.5) 


    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()


# ---------------- MANAGER ----------------
class ThreadingHTTPServer(ThreadingMixIn, http.server.HTTPServer):
    """Servidor HTTP multithreaded para lidar com múltiplas conexões HLS."""
    pass

class HLSProxyManager:
    """Gerencia a inicialização e o estado do servidor proxy."""
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy resiliente iniciado na porta {self.active_port}")
                return True
            except OSError:
                continue
        logging.error("Não foi possível iniciar o proxy em nenhuma porta.")
        return False


class HLSAddon:
    """Classe principal do Addon Kodi que inicializa e resolve o stream."""
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            if xbmcplugin:
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        session_id = f"stream_{int(time.time())}_{random.randint(1000, 9999)}"
        logging.info(f"Iniciando stream com session_id: {session_id}")
        
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&session_id={session_id}"
        
        if xbmcgui and xbmcplugin:
            li = xbmcgui.ListItem(path=proxy_url, label=title or "Proxy HLS")
            li.setProperty("IsPlayable", "true")
            if stype == "live":
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setProperty("IsLive", "true")
            
            xbmcplugin.setResolvedUrl(self.handle, True, li)


def main():
    setup_logging()
    try:
        if len(sys.argv) < 2:
            logging.error("O script precisa ser chamado pelo Kodi com argumentos.")
            return

        h = int(sys.argv[1])
        addon = HLSAddon(h)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('url', [None])[0]
            stream_type = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(stream_url, stream_type, title)
        elif xbmcplugin:
            xbmcplugin.endOfDirectory(h)
    except Exception as e:
        logging.error(f"Erro main: {e}")


if __name__ == '__main__':
    main()