import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
from collections import OrderedDict, deque
from requests.exceptions import Timeout, ConnectionError, HTTPError

# --- Configurações Iniciais do Addon ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HANDLE = int(sys.argv[1])

proxy_host_setting = ADDON.getSetting('proxy_host') or '127.0.0.1'
PROXY_HOST = proxy_host_setting.strip() if proxy_host_setting else '127.0.0.1'

DEFAULT_PROXY_PORT = random.randint(20000, 65000)
MAX_PORT_ATTEMPTS = 10

def get_int_setting(key, default):
    try:
        value = int(ADDON.getSetting(key) or default)
        if value < 1:
            value = default
        return value
    except Exception:
        return default

max_cache_mb = get_int_setting('max_cache_mb', 64)
MAX_CACHE_SIZE_BYTES = max_cache_mb * 1024 * 1024

max_segment_size_mb = get_int_setting('max_segment_size_mb', 8)
MAX_SEGMENT_SIZE_BYTES = max_segment_size_mb * 1024 * 1024

CACHE_TYPE = 'ram'

def get_bool_setting(key, default):
    try:
        return ADDON.getSetting(key) == 'true'
    except Exception:
        return default

SIMULATE_ERRORS = get_bool_setting('simulate_errors', False)

IS_DEV_ENV = os.environ.get('KODI_ENV') == 'development'
if SIMULATE_ERRORS and not IS_DEV_ENV:
    SIMULATE_ERRORS = False

ENABLE_IPV6 = get_bool_setting('enable_ipv6', True)

def get_float_setting(key, default):
    try:
        return float(ADDON.getSetting(key) or default)
    except Exception:
        return default

CONNECTION_TIMEOUT = get_float_setting('connection_timeout', 10)
STREAM_TIMEOUT = get_float_setting('stream_timeout', 15)

LOG_MAX_BYTES = get_int_setting('log_max_bytes', 1048576)
LOG_BACKUP_COUNT = get_int_setting('log_backup_count', 3)

CHUNK_SIZE = 65536
LOG_FILE = xbmcvfs.translatePath(ADDON.getSetting('log_file_path') or 'special://temp/hlsproxy.log')
USER_BLOCKLIST = set(filter(None, (ADDON.getSetting('host_blocklist') or '').split(',')))

try:
    loglevel_raw = ADDON.getSetting("loglevel")
    loglevel = loglevel_raw.upper().strip() if loglevel_raw else "WARNING"
    LOG_LEVEL = int(getattr(logging, loglevel, logging.WARNING))
except Exception:
    LOG_LEVEL = logging.WARNING

log_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
)
logging.basicConfig(
    handlers=[log_handler],
    level=LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s'
)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.5 (WebOS; U; SmartTV; LG NetCast.TV-2013) AppleWebKit/537.41 (KHTML, like Gecko) WebAppManager"
]
ACCEPT_LANGUAGES = ["pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "en-US,en;q=0.9,pt;q=0.8", "es-ES,es;q=0.9,en;q=0.8"]
PLAYER_HEADERS = [{"User-Agent": USER_AGENTS[i], "Accept": "*/*", "Accept-Language": lang, "Origin": "", "Referer": ""} for i, lang in zip(range(len(USER_AGENTS)), ACCEPT_LANGUAGES * 2)]

def clean_headers(headers):
    sensitive = ['X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP', 
                'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP']
    return {k: v for k, v in headers.items() if k not in sensitive}

def random_player_headers(url):
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.hostname}"
    headers = random.choice(PLAYER_HEADERS).copy()
    headers['Origin'] = origin
    headers['Referer'] = origin
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def jitter(base, percent=0.1):
    return base + base * random.uniform(-percent, percent)

HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': random.choice(USER_AGENTS),
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive'
})
HTTP_SESSION.trust_env = False

def random_ipv4():
    return '.'.join(str(random.randint(1, 254)) for _ in range(4))

def random_ipv6():
    return ':'.join('%x' % random.randint(0, 0xFFFF) for _ in range(8))

def random_ip():
    if ENABLE_IPV6 and random.choice([True, False]):
        return random_ipv6()
    return random_ipv4()

class DoHResolver:
    def __init__(self, resolver_urls=None, cache_ttl=300, retries=2, retry_delay=0.7):
        self.resolver_urls = resolver_urls or [
            'https://cloudflare-dns.com/dns-query',
            'https://dns.nextdns.io',
        ]
        self.cache_ttl = cache_ttl
        self.retries = retries
        self.retry_delay = retry_delay
        self._cache = {}
        self.q_types = ('AAAA', 'A') if ENABLE_IPV6 else ('A',)
        logging.debug(f"DoHResolver initialized with resolvers: {self.resolver_urls}, IPv6 enabled: {ENABLE_IPV6}")

    def resolve(self, hostname, depth=0, max_depth=5):
        if depth > max_depth:
            logging.error(f"Max CNAME resolution depth reached for {hostname}. Aborting DNS resolution.")
            return None
        if self._is_valid_ip(hostname):
            logging.debug(f"Hostname {hostname} is already an IP address.")
            return hostname

        cached_entry = self._cache.get(hostname)
        if cached_entry and time.time() < cached_entry[1]:
            logging.debug(f"Hostname {hostname} found in DoH cache: {cached_entry[0]}")
            return cached_entry[0]
        
        logging.debug(f"Attempting to resolve hostname {hostname} via DoH (depth: {depth})")
        for resolver_url in self.resolver_urls:
            for q_type in self.q_types:
                for attempt in range(self.retries):
                    try:
                        params = {'name': hostname, 'type': q_type}
                        headers = {'accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                        response = HTTP_SESSION.get(resolver_url, params=params, headers=headers, timeout=5)
                        response.raise_for_status()
                        data = response.json()
                        ip_address = self._parse_doh_response(data, hostname, q_type, depth)
                        if ip_address:
                            ttl = data.get("Answer", [{}])[0].get("TTL", self.cache_ttl)
                            self._cache[hostname] = (ip_address, time.time() + ttl)
                            logging.debug(f"Successfully resolved {hostname} to {ip_address} (TTL: {ttl}s) using {resolver_url} for type {q_type}.")
                            return ip_address
                    except Exception as e:
                        logging.warning(f"DoH resolution attempt {attempt + 1}/{self.retries} for {hostname} (type {q_type}) via {resolver_url} failed: {e}")
                        if attempt < self.retries - 1:
                            time.sleep(jitter(self.retry_delay))
                        else:
                            continue
        logging.warning(f"Failed to resolve hostname {hostname} after all attempts.")
        return None

    def _parse_doh_response(self, data, hostname, q_type, depth):
        type_map = {'A': 1, 'AAAA': 28}
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map[q_type] and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data")
        for answer in data.get("Answer", []):
            if answer.get("type") == 5:
                cname = answer.get("data", "").rstrip('.')
                if cname:
                    logging.debug(f"Found CNAME for {hostname}: {cname}. Resolving CNAME.")
                    return self.resolve(cname, depth + 1)
        return None

    @staticmethod
    def _is_valid_ip(address):
        try:
            socket.inet_pton(socket.AF_INET6, address)
            return True
        except socket.error:
            try:
                socket.inet_aton(address)
                return True
            except socket.error:
                return False

class BaseCache:
    def __init__(self, max_bytes):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        logging.info(f"BaseCache initialized with max_bytes: {max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url): raise NotImplementedError
    def add(self, url, data): raise NotImplementedError
    def clear(self): raise NotImplementedError
    def get_stats(self): raise NotImplementedError

class RecentSegmentsCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES, max_segments=50):
        super().__init__(max_bytes)
        self.segments = OrderedDict()
        self.recent_queue = deque(maxlen=max_segments)
        self.total_bytes = 0
        self.max_segments = max_segments
        logging.info(f"RecentSegmentsCache initialized with {max_segments} recent segments and {max_bytes / (1024 * 1024):.2f} MB max size.")

    def get(self, url):
        with self.lock:
            data = self.segments.get(url)
            if data:
                self.segments.move_to_end(url)
                if url not in self.recent_queue:
                    self.recent_queue.append(url)
            return data

    def get_recent_segments(self, count=5):
        with self.lock:
            recent = list(self.recent_queue)[-count:]
            return [(url, self.segments[url]) for url in recent if url in self.segments]

    def add(self, url, data: bytes):
        with self.lock:
            if url in self.segments:
                self.total_bytes -= len(self.segments.pop(url))
            self.segments[url] = data
            self.recent_queue.append(url)
            self.total_bytes += len(data)
            self._shrink_to_limit()

    def _shrink_to_limit(self):
        while self.total_bytes > self.max_bytes and self.segments:
            old_url, old_data = self.segments.popitem(last=False)
            self.total_bytes -= len(old_data)
            if old_url in self.recent_queue:
                try:
                    self.recent_queue.remove(old_url)
                except ValueError:
                    pass
            logging.debug(f"Shrinking RecentSegmentsCache: removed {old_url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.recent_queue.clear()
            self.total_bytes = 0
            logging.info("RecentSegmentsCache cleared.")

    def get_stats(self):
        with self.lock:
            return {"entries": len(self.segments), "size_MB": round(self.total_bytes / 1048576, 2), "recent_queue": len(self.recent_queue)}

class StreamCache:
    def __init__(self, chunk_cache: BaseCache):
        self.manifest_cache = {}
        self.chunk_cache = chunk_cache
        logging.info("StreamCache initialized.")
        
    def get_manifest(self, url):
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            logging.debug(f"Manifest found in RAM cache: {url}")
            return entry['content']
        logging.debug(f"Manifest not found or expired in RAM cache: {url}")
        return None
        
    def add_manifest(self, url, content, ttl=1):
        self.manifest_cache[url] = {'content': content, 'expires': time.time() + ttl}
        logging.debug(f"Manifest added to RAM cache: {url} with TTL {ttl}s.")
        
    def get_segment(self, url): return self.chunk_cache.get(url)
    def add_segment(self, url, data): self.chunk_cache.add(url, data)
    def get_recent_segments(self, count=5):
        if hasattr(self.chunk_cache, 'get_recent_segments'):
            return self.chunk_cache.get_recent_segments(count)
        return []
    def clear(self):
        self.manifest_cache.clear()
        self.chunk_cache.clear()
        logging.info("Stream cache (manifests and chunks) cleared.")

class UpstreamFetcher:
    def __init__(self, session, doh_resolver):
        self.session = session
        self.doh_resolver = doh_resolver
        logging.info("UpstreamFetcher initialized with IP protection")

    def fetch(self, url, stream=False, original_headers=None):
        try:
            headers = random_player_headers(url)
            if original_headers:
                original_headers = clean_headers(original_headers)
                if 'Authorization' in original_headers: 
                    headers['Authorization'] = original_headers['Authorization']
                if 'Cookie' in original_headers: 
                    headers['Cookie'] = original_headers['Cookie']
            fake_ip = random_ip()
            headers['X-Forwarded-For'] = fake_ip
            headers['Client-IP'] = fake_ip
            headers['X-Real-IP'] = fake_ip
            parsed_url = urllib.parse.urlparse(url)
            resolved_ip = None
            if parsed_url.hostname:
                resolved_ip = self.doh_resolver.resolve(parsed_url.hostname)
            req_url = url
            if resolved_ip and resolved_ip != parsed_url.hostname:
                req_url = url.replace(parsed_url.hostname, resolved_ip, 1)
                headers['Host'] = parsed_url.hostname

            max_retries = 8
            base_delay = 0.1

            for attempt in range(max_retries):
                try:
                    resp = self.session.get(req_url, stream=stream, 
                                          timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                                          headers=headers, allow_redirects=True)
                    if resp.status_code >= 500:
                        resp.raise_for_status()
                    return resp
                except (Timeout, ConnectionError, HTTPError) as e:
                    logging.warning(f"Attempt {attempt + 1}/{max_retries} failed for {url}: {e}")
                    if attempt == max_retries - 1:
                        logging.error(f"All {max_retries} attempts failed for {url}. Giving up.")
                        raise e
                    delay = (base_delay * (2 ** attempt)) + random.uniform(0.1, 0.5)
                    logging.info(f"Waiting for {delay:.2f} seconds before next retry.")
                    time.sleep(delay)
                except Exception as ex:
                    logging.error(f"An unexpected non-recoverable error occurred while fetching {url}: {ex}", exc_info=True)
                    return None
        except Exception as ex:
            logging.error(f"Failed to fetch {url} after all retries or due to a critical error: {ex}", exc_info=True)
            return None

class ManifestRewriter:
    def __init__(self, content, manifest_url, proxy_base_url):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        logging.debug(f"ManifestRewriter initialized for {manifest_url}. Proxy base: {proxy_base_url}")

    def rewrite(self):
        for playlist in getattr(self.m3u8_obj, 'playlists', []):
            if playlist.uri:
                original_uri = playlist.absolute_uri
                playlist.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote playlist URI from {original_uri} to {playlist.uri}")
        for media in getattr(self.m3u8_obj, 'media', []):
            if hasattr(media, 'uri') and media.uri:
                original_uri = media.absolute_uri
                media.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote media URI from {original_uri} to {media.uri}")
        for segment in getattr(self.m3u8_obj, 'segments', []):
            if segment.uri:
                original_uri = segment.absolute_uri
                segment.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote segment URI from {original_uri} to {segment.uri}")
            if segment.key and segment.key.uri:
                original_uri = segment.key.absolute_uri
                segment.key.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote key URI from {original_uri} to {segment.key.uri}")
        rewritten_manifest = self.m3u8_obj.dumps()
        logging.debug(f"Manifest rewritten successfully. First 200 chars: {rewritten_manifest[:200]}")
        return rewritten_manifest

    @property
    def is_live(self):
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self):
        target_duration = getattr(self.m3u8_obj, 'target_duration', 0)
        if self.is_live and target_duration:
            ttl = max(1, int(target_duration * 0.75))
            logging.debug(f"Live stream detected. Target duration: {target_duration}s, calculated TTL: {ttl}s.")
            return ttl
        logging.debug("VOD stream detected or no target duration. Default TTL: 600s.")
        return 600

def notify(msg, time_ms=3000): 
    xbmc.executebuiltin(f'Notification({ADDON_NAME},{msg},{time_ms})')

def validate_url(url: str) -> bool:
    u = urllib.parse.urlparse(url)
    if not u.scheme in ('http', 'https'):
        logging.warning(f"Invalid URL scheme for {url}. Must be http or https.")
        return False
    if not u.netloc:
        logging.warning(f"URL has no network location (netloc): {url}.")
        return False
    if u.hostname in USER_BLOCKLIST:
        logging.warning(f"Hostname {u.hostname} is in the user blocklist for URL: {url}.")
        return False
    return True

def safe_mime_type(url, fallback='application/octet-stream'):
    ext = url.lower().split('?')[0]
    if ext.endswith('.m3u8'): return 'application/vnd.apple.mpegurl'
    if ext.endswith('.ts'): return 'video/mp2t'
    logging.debug(f"Could not determine specific MIME type for {url}. Using fallback: {fallback}")
    return fallback

def is_port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('127.0.0.1', port))
            return True
        except socket.error:
            return False

class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, stream_cache, fetcher, *args, **kwargs):
        self.cache = stream_cache
        self.fetcher = fetcher
        self.log_level_map = {
            'info': logging.info,
            'warning': logging.warning,
            'error': logging.error,
            'debug': logging.debug
        }
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        pass

    def _log_request(self, message, level='info'):
        log_func = self.log_level_map.get(level, logging.info)
        client_address = self.address_string()
        log_func(f"[{client_address}] {self.command} {self.path} - {message}")

    def do_GET(self):
        self._log_request("Received request", level='debug')
        original_url = "unknown"
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            query_params = urllib.parse.parse_qs(parsed_path.query)
            original_url = query_params.get('url', [''])[0]

            if not original_url:
                self.send_error(400, "Missing 'url' parameter in proxy request")
                self._log_request("Missing 'url' parameter.", level='warning')
                return

            if SIMULATE_ERRORS and random.random() < 0.008:
                self._send_response(200, b"", "application/octet-stream")
                self._log_request(f"Simulated 503 error (sent as 200 with empty body) for {original_url}", level='warning')
                return

            self.headers = clean_headers(self.headers)

            if ".m3u8" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected while serving {original_url}", level='info')
        except Exception as ex:
            logging.error("General proxy error for %s: %s", original_url, str(ex), exc_info=True)
            if not self.wfile.closed:
                try: self.send_error(500, "Internal Server Error")
                except Exception: pass

    def _handle_manifest(self, url, max_proxy_retries=3):
        self._log_request(f"Handling manifest: {url}", level='info')
        for proxy_attempt in range(max_proxy_retries):
            cached = self.cache.get_manifest(url)
            if cached:
                if "too many users" in cached.lower() or "limite" in cached.lower():
                    self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
                    return
                self._log_request(f"Serving manifest from cache: {url} (Proxy attempt {proxy_attempt + 1})", level='debug')
                return self._send_response(200, cached, 'application/vnd.apple.mpegurl')

            self._log_request(f"Fetching manifest {url} from upstream (Proxy attempt {proxy_attempt + 1})", level='debug')
            response = self.fetcher.fetch(url, original_headers=self.headers)
            if response and response.ok:
                if ("too many users" in response.text.lower() or
                    "limite" in response.text.lower()):
                    self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
                    response.close()
                    return
                try:
                    rewriter = ManifestRewriter(response.text, response.url, f"http://{self.server.server_address[0]}:{self.server.server_address[1]}/?url=")
                    rewritten_content = rewriter.rewrite()
                    ttl = rewriter.get_ttl()
                    self.cache.add_manifest(url, rewritten_content, ttl=ttl)
                    self._log_request(f"Manifest {url} fetched, rewritten, cached (TTL: {ttl}s) and served (Proxy attempt {proxy_attempt + 1}).", level='info')
                    response.close()
                    return self._send_response(200, rewritten_content, 'application/vnd.apple.mpegurl')
                except Exception as e:
                    logging.error(f"Error processing manifest {url} (Proxy attempt {proxy_attempt + 1}): {e}", exc_info=True)
                    if response: response.close()
            else:
                status_code = response.status_code if response else 502
                logging.warning(f"Upstream manifest fetch failed with status {status_code}: sending 200 with empty manifest to player.")
                self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
                if response: response.close()
                return

    def _handle_segment(self, url, max_proxy_retries=3):
        self._log_request(f"Handling segment: {url}", level='info')
        mime_type = safe_mime_type(url)
        # Pega só 1 segmento recente do cache como alternativo
        recent = self.cache.get_recent_segments(1)
        segment_urls_to_try = [url] + [u for u, _ in recent if u != url]
        tried_urls = set()
        for idx, seg_url in enumerate(segment_urls_to_try):
            if seg_url in tried_urls:
                continue
            tried_urls.add(seg_url)
            if idx == 0:
                # Segmento atual: tenta baixar e cachear normalmente
                for proxy_attempt in range(max_proxy_retries):
                    cached = self.cache.get_segment(seg_url)
                    if cached:
                        self._log_request(f"Serving segment from cache: {seg_url} (Proxy attempt {proxy_attempt + 1})", level='debug')
                        return self._send_response(200, cached, mime_type)
                    self._log_request(f"Fetching segment {seg_url} from upstream (Proxy attempt {proxy_attempt + 1})", level='debug')
                    response = None
                    try:
                        response = self.fetcher.fetch(seg_url, stream=True, original_headers=self.headers)
                    except Exception as e:
                        logging.warning(f"Error during initial fetch of segment {seg_url} (Proxy attempt {proxy_attempt + 1}): {e}")
                        if response: response.close()
                        response = None
                    if not response or not response.ok:
                        status_code = response.status_code if response else 404
                        logging.warning(f"Upstream segment fetch failed with status {status_code} for {seg_url}.")
                        if response: response.close()
                        if proxy_attempt < max_proxy_retries - 1:
                            delay = random.uniform(0.2, 0.5)
                            logging.info(f"Retrying segment fetch for {seg_url} in {delay:.2f} seconds...")
                            time.sleep(delay)
                            continue
                        else:
                            self._log_request(f"All {max_proxy_retries} attempts failed for segment {seg_url}. Trying next alternate.", level='warning')
                            break
                    _cached_data = bytearray()
                    try:
                        self.send_response(200)
                        for h, v in response.headers.items():
                            if h.lower() not in ('transfer-encoding', 'connection', 'content-encoding', 'content-length'):
                                self.send_header(h, v)
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0')
                        self.end_headers()
                        bytes_sent = 0
                        for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                            if not chunk:
                                continue
                            self.wfile.write(chunk)
                            bytes_sent += len(chunk)
                            if bytes_sent <= MAX_SEGMENT_SIZE_BYTES:
                                _cached_data.extend(chunk)
                        self._log_request(f"Segment {seg_url} streamed to client. Total bytes sent: {bytes_sent} (Proxy attempt {proxy_attempt + 1}).", level='debug')
                        if len(_cached_data) > 0 and len(_cached_data) <= MAX_SEGMENT_SIZE_BYTES:
                            self.cache.add_segment(seg_url, bytes(_cached_data))
                            self._log_request(f"Segment {seg_url} (size: {len(_cached_data)} bytes) added to cache (Proxy attempt {proxy_attempt + 1}).", level='debug')
                        elif len(_cached_data) > MAX_SEGMENT_SIZE_BYTES:
                            self._log_request(f"Segment {seg_url} (size: {len(_cached_data)} bytes) exceeded MAX_SEGMENT_SIZE_BYTES ({MAX_SEGMENT_SIZE_BYTES} bytes) and was NOT cached (Proxy attempt {proxy_attempt + 1}).", level='info')
                        response.close()
                        return
                    except (BrokenPipeError, ConnectionResetError) as e:
                        logging.info(f"Client disconnected while serving segment {seg_url}: {e} (Proxy attempt {proxy_attempt + 1}). Aborting segment handling.")
                        if response: response.close()
                        return
                    except Exception as e:
                        logging.warning(f"Error during segment streaming/writing {seg_url} (Proxy attempt {proxy_attempt + 1}): {e}", exc_info=True)
                        if response: response.close()
                        if proxy_attempt < max_proxy_retries - 1:
                            delay = random.uniform(0.5, 2.0)
                            logging.info(f"Retrying segment fetch for {seg_url} due to streaming error in {delay:.2f} seconds...")
                            time.sleep(delay)
                            continue
                        else:
                            self._log_request(f"All {max_proxy_retries} proxy attempts failed for segment {seg_url} after streaming errors. Trying next alternate.", level='warning')
                            break
            else:
                # Segmentos antigos: só entregue se já está no cache, não tente baixar!
                cached = self.cache.get_segment(seg_url)
                if cached:
                    self._log_request(f"Serving fallback segment from cache: {seg_url}", level='debug')
                    return self._send_response(200, cached, mime_type)
                else:
                    self._log_request(f"Alternate segment {seg_url} not in cache. Skipping.", level='debug')
                    continue
        # Nenhum segmento disponível, envie vazio
        self._log_request(f"All alternate segments failed. Sending empty segment to avoid freeze.", level='error')
        self._send_response(200, b"", mime_type)

    def _send_response(self, code, content, content_type):
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        try:
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(encoded)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(encoded)
            self._log_request(f"Response sent (code: 200, type: {content_type}, size: {len(encoded)} bytes).", level='debug')
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected while sending response for {content_type}.", level='info')
        except Exception as ex:
            logging.error("Error sending response: %s", str(ex), exc_info=True)

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self.doh_resolver = DoHResolver()
        self.chunk_cache = RecentSegmentsCache(MAX_CACHE_SIZE_BYTES, max_segments=50)
        logging.info("Usando cache de segmentos recentes na memória.")
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(HTTP_SESSION, self.doh_resolver)
        logging.info("HLSProxyManager initialized.")

    def start(self):
        self.stop()
        handler_with_deps = functools.partial(AdvancedHLSProxyHandler, self.stream_cache, self.fetcher)
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            if not is_port_free(port):
                logging.warning(f"Port {port} is in use, trying another. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.")
                continue
            try:
                self.server = socketserver.TCPServer((PROXY_HOST, port), handler_with_deps)
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy started successfully on port {self.active_port} on host {PROXY_HOST} (accessible by other devices if not localhost).")
                return self.active_port
            except Exception as ex:
                logging.warning(f"Failed to start proxy on port {port}: {ex}. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.", exc_info=True)
                time.sleep(0.5)
        logging.error(f"Failed to start HLS Proxy after {MAX_PORT_ATTEMPTS} attempts. No free port found or general error.")
        notify("Erro fatal: Não foi possível iniciar o proxy HLS. Nenhuma porta livre encontrada ou erro interno.", 7000)
        return None

    def stop(self):
        if self.server:
            logging.info(f"Stopping HLS Proxy on port {self.active_port}")
            try:
                self.server.shutdown()
                self.server.server_close()
                logging.debug("Proxy server shut down and closed.")
            except Exception as e:
                logging.error(f"Error during proxy server shutdown: {e}", exc_info=True)
            self.server = None
        if self.server_thread and self.server_thread.is_alive():
            logging.debug("Waiting for proxy server thread to join...")
            self.server_thread.join(timeout=1)
            if self.server_thread.is_alive():
                logging.warning("Proxy server thread did not terminate gracefully.")
            else:
                logging.debug("Proxy server thread joined successfully.")
        self.stream_cache.clear()
        self.active_port = None
        logging.info("HLS Proxy completely stopped and resources released.")
        
    def get_proxy_url(self, original_url):
        if not self.active_port: return None
        url_encoded = urllib.parse.quote_plus(original_url)
        return f"http://{PROXY_HOST}:{self.active_port}/?url={url_encoded}"

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        logging.info("CustomPlayer initialized with stop event.")

    def onPlayBackStarted(self):
        logging.info("Kodi playback started.")
        self.stop_event.clear() 
    
    def onPlayBackEnded(self):
        logging.info("Kodi playback ended.")
        self.stop_event.set() 

    def onPlayBackError(self):
        logging.error("Kodi playback error occurred.")
        self.stop_event.set() 

    def onPlayBackStopped(self):
        logging.info("Kodi playback stopped by user.")
        self.stop_event.set() 

class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)
        logging.info("HLSProxyAddon instance created.")

    def convert_to_m3u8(self, url):
        original_url = url
        logging.debug(f"Attempting to convert URL to M3U8 format: {url}")
        try:
            if '|' in url:
                url = url.split('|')[0]
                logging.debug(f"Removed '|' and everything after: {url}")
            elif '%7C' in url:
                url = url.split('%7C')[0]
                logging.debug(f"Removed '%7C' and everything after: {url}")

            if not '.m3u8' in url.lower() and not '/hl' in url.lower() and url.count("/") > 4 and not '.mp4' in url.lower() and not '.avi' in url.lower():
                parsed_url = urllib.parse.urlparse(url)
                host_part1 = f'{parsed_url.scheme}://{parsed_url.netloc}'
                host_part2 = url.split(host_part1)[1]
                
                if '/live' not in host_part2:
                    url = host_part1 + '/live' + host_part2
                    logging.debug(f"Added '/live' to URL: {url}")

                file = os.path.basename(urllib.parse.urlparse(url).path)
                if '.ts' in file.lower():
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                    logging.debug(f"Replaced .ts with .m3u8: {url}")
                else:
                    url = url + '.m3u8'
                    logging.debug(f"Appended .m3u8 to URL: {url}")
        except Exception as e:
            logging.warning(f"Heuristic conversion failed for {original_url}: {e}. Returning original URL.", exc_info=True)
            return original_url 
        logging.debug(f"Final URL after convert_to_m3u8: {url}")
        return url

    def play_stream(self, url, channel_name=None):
        logging.info(f"Attempting to play stream: {url}")
        processed_url = self.convert_to_m3u8(url)
        logging.info(f"URL after convert_to_m3u8: {processed_url}")
        if not validate_url(processed_url):
            notify("URL inválida, bloqueada ou não suportada.", 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        port = self.proxy_manager.start()
        if not port:
            notify("Erro fatal ao iniciar proxy local. Verifique os logs.", 5000)
            logging.error("Failed to start proxy, cannot resolve URL for Kodi.")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if channel_name:
            display_label = f"{channel_name} [COLOR lightblue](HLS/TS Tester)[/COLOR]"
        else:
            display_label = "[COLOR lightblue]HLS/TS Tester[/COLOR]"
        
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_label)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType(safe_mime_type(processed_url))
        
        # --- Modificações para usar inputstream.ffmpegdirect ---
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        # A propriedade 'inputstream.ffmpegdirect.is_helper_addon' é para Kodi v20+
        # Ela indica ao inputstream que ele está sendo usado como um helper para outro addon.
        # Não há uma propriedade direta para "timeshift mode" via ListItem.
        # Timeshift geralmente é uma funcionalidade do player Kodi.
        list_item.setProperty('inputstream.ffmpegdirect.is_helper_addon', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'curl') 
        # FMMpegDirect pode ter outras propriedades que podem influenciar a forma como ele lida com a reprodução
        # mas "timeshift" é uma característica do player Kodi que usa o inputstream para o buffer.
        # Se houver alguma configuração específica para timeshift, ela estaria nas configurações do inputstream addon.
        # Exemplo (NÃO GARANTIDO QUE FUNCIONE PARA TIMESHAFT DIRETO):
        # list_item.setProperty('inputstream.ffmpegdirect.mode', 'timeshift') 
        # list_item.setProperty('inputstream.ffmpegdirect.timeshift_path', 'special://temp/timeshift/') 
        # É improvável que as propriedades acima existam ou funcionem para timeshift.
        # O timeshift é geralmente habilitado nas configurações do Inputstream FFmpegDirect ou globalmente no Kodi.
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        logging.info(f"Kodi resolved URL to proxy: {proxy_url} with inputstream.ffmpegdirect properties.")
        monitor_thread = threading.Thread(target=self.monitor_playback, daemon=True)
        monitor_thread.start()
        logging.debug("Playback monitor thread started.")

    def monitor_playback(self):
        logging.info("Starting playback monitoring...")
        try:
            was_stopped = self.playback_stop_event.wait(timeout=86400)
            if was_stopped:
                logging.info("Playback stop event received. Releasing proxy resources.")
            else:
                logging.warning("Playback monitoring timed out. Releasing proxy resources as a safeguard.")
        except Exception as e:
            logging.error(f"Error during playback monitoring: {e}", exc_info=True)
        finally:
            logging.info("Ensuring proxy resources are released.")
            self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Live Exemplo (Caminho da Web)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Big Buck Bunny (VOD - 1080p)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Apple Test HLS (Advanced)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"),
            ("Google Shaka Test (DRM-Free)", "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8")
        ]
        logging.info("Displaying test streams.")
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=f"{name} [COLOR lightblue](Reprodução via Proxy HLS/TS Tester)[/COLOR]")
            li.setProperty('IsPlayable', 'true')
            li.setMimeType(safe_mime_type(url))
            # Set inputstream properties for test streams as well
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_helper_addon', 'true')
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            logging.debug(f"Added directory item: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url_to_play = params.get('url')
    channel_title = params.get('title')
    addon = HLSProxyAddon()
    if action == 'play' and url_to_play:
        addon.play_stream(url_to_play, channel_title)
    else:
        addon.show_test_streams()