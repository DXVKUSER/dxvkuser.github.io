import http.server
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue
import struct
import io
import http.cookiejar
import select
import requests

# ─────────────────────────────────────────────────────────────────────────────
#  CLOUDFLARE DoH RESOLVER (DNS over HTTPS)
# ─────────────────────────────────────────────────────────────────────────────
DOH_CACHE = {}
DOH_TTL = 86400  # TTL alto: 24 horas (em segundos)
_original_getaddrinfo = socket.getaddrinfo

def _is_ipv4(host):
    parts = host.split('.')
    return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)

def cf_doh_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    # Ignora IPs diretos e localhost para não causar loops ou erros desnecessários
    if _is_ipv4(host) or host == 'localhost':
        return _original_getaddrinfo(host, port, family, type, proto, flags)

    now = time.time()
    if host in DOH_CACHE and DOH_CACHE[host]['expires'] > now:
        ip = DOH_CACHE[host]['ip']
    else:
        try:
            resp = requests.get(
                'https://1.1.1.1/dns-query',
                params={'name': host, 'type': 'A'},
                headers={'accept': 'application/dns-json'},
                timeout=5
            )
            resp.raise_for_status()
            data = resp.json()
            
            ip = None
            if 'Answer' in data:
                for answer in data['Answer']:
                    if answer.get('type') == 1:  # Tipo 1 = A record (IPv4)
                        ip = answer.get('data')
                        break
            
            if ip:
                DOH_CACHE[host] = {'ip': ip, 'expires': now + DOH_TTL}
            else:
                # Fallback para o DNS do sistema se a Cloudflare não retornar um IP
                return _original_getaddrinfo(host, port, family, type, proto, flags)
                
        except Exception as e:
            # Fallback seguro em caso de falha de conexão com a Cloudflare
            return _original_getaddrinfo(host, port, family, type, proto, flags)

    # Retorna a estrutura exata que os sockets do Python esperam
    return [(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, '', (ip, port))]

# Aplica o patch globalmente no nível do socket
socket.getaddrinfo = cf_doh_getaddrinfo


# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES MPEG-TS (Otimizadas para Sincronia Perfeita e Início Rápido)
# ─────────────────────────────────────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

# Pacote nulo com Discontinuity Indicator ativado (bit 7 do byte 5 = 0x80)
# Isso previne o "Grinch Verde" ao forçar o reset do decoder do Kodi/VLC
_NULL_HDR      = bytes([0x47, 0x1F, 0xFF, 0x10, 0x01, 0x80])
TS_NULL_PACKET = _NULL_HDR + b'\xFF' * 182

CHUNK_SIZE = TS_PACKET_SIZE * 7  
NULL_PUMP_BURST = TS_NULL_PACKET * 7

STALL_TIMEOUT = 2.5

HOST = "127.0.0.1"
PORT = 8083

MAX_OUTPUT_BUFFER = 1024  

PCR_PID = 0x100
PAT_PID = 0x000
PMT_PID = 0x100

# ─────────────────────────────────────────────────────────────────────────────
#  PERFIS DE CLIENTE HTTP (Rotacionados em cada erro)
# ─────────────────────────────────────────────────────────────────────────────
_CLIENT_PROFILES = {
    "android_tv": {
        "User-Agent": "Mozilla/5.0 (Linux; Android 12; Android TV) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache",
        "Sec-Fetch-Dest": "video", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site"
    },
    "android_mobile": {
        "User-Agent": "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache",
        "Sec-Fetch-Dest": "video", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site"
    },
    "chrome_windows": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "en-US,en;q=0.9,pt-BR;q=0.8",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache",
        "Sec-Fetch-Dest": "video", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site"
    },
    "chrome_linux": {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache",
        "Sec-Fetch-Dest": "video", "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site"
    },
    "kodi": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache"
    },
    "vlc": {
        "User-Agent": "VLC/3.0.18 LibVLC/3.0.18",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache"
    },
    "exoplayer": {
        "User-Agent": "ExoPlayer/2.18.7 (Linux; Android 12)",
        "Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive", "Cache-Control": "no-cache", "Pragma": "no-cache"
    }
}

_USER_AGENTS = [p["User-Agent"] for p in _CLIENT_PROFILES.values()]
def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)

# ─────────────────────────────────────────────────────────────────────────────
#  TsParser — Sutura Avançada Forward com Filtro de Keyframe Anti-Grinch
# ─────────────────────────────────────────────────────────────────────────────

# Constantes do Protocolo MPEG-TS
TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47
PAT_PID = 0x0000
PMT_PID = 0x0100 
TS_NULL_PACKET = bytearray([0x47, 0x1F, 0xFF, 0x10] + [0xFF] * 184)

# Máximo valor do PCR Base (33 bits) para cálculo matemático de wrap-around
PCR_BASE_MAX = 0x1FFFFFFFF 

class TsParser:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}
        self._pcr_locked = False
        self._last_pcr_value = None
        self._pat_received = False
        self._pmt_received = False
        self._stream_initialized = False
        
        # Gerenciamento de Janela Deslizante e Sutura Estrita
        self._global_pcr_base = None
        self._is_suturing = False
        self._video_pid = None
        self._waiting_for_keyframe = False

    def reset_stream_state(self):
        """
        Reset cirúrgico acionado nas reconexões.
        Retém a base de tempo para checagem matemática, mas bloqueia o fluxo
        até encontrar dados novos e um ponto de entrada de vídeo seguro (I-Frame).
        """
        self._buf.clear()
        self._aligned = False
        self._cc_map.clear()
        self._pcr_locked = False
        self._last_pcr_value = None
        self._pat_received = False
        self._pmt_received = False
        self._stream_initialized = False
        
        # Ativa o isolamento de segurança se já houver fluxo prévio
        if self._global_pcr_base is not None:
            self._is_suturing = True
            self._waiting_for_keyframe = True

    def _strict_sync(self) -> int:
        """Busca alinhamento perfeito de sincronia examinando janelas subsequentes."""
        limit = len(self._buf) - (TS_PACKET_SIZE * 2)
        idx = 0
        
        while idx <= limit:
            idx = self._buf.find(TS_SYNC_BYTE, idx, limit + 1)
            if idx == -1:
                break
                
            # Validação tripla de integridade de frames TS
            if (self._buf[idx + TS_PACKET_SIZE] == TS_SYNC_BYTE and 
                self._buf[idx + (TS_PACKET_SIZE * 2)] == TS_SYNC_BYTE):
                return idx
            idx += 1
            
        return -1

    def _extract_pcr(self, packet: memoryview, off: int) -> int:
        """Extração e decodificação cirúrgica de PCR via manipulação de bits."""
        try:
            if packet[off] != TS_SYNC_BYTE:
                return None
            
            afc = (packet[off + 3] & 0x30) >> 4
            if afc not in (2, 3):
                return None
                
            adapt_len = packet[off + 4]
            if adapt_len >= 7 and (packet[off + 5] & 0x10) != 0:
                pcr_bytes = packet[off + 6:off + 12]
                pcr_base = (pcr_bytes[0] << 25) | (pcr_bytes[1] << 17) | (pcr_bytes[2] << 9) | (pcr_bytes[3] << 1) | (pcr_bytes[4] >> 7)
                pcr_ext = ((pcr_bytes[4] & 0x01) << 8) | pcr_bytes[5]
                return (pcr_base * 300) + pcr_ext
        except IndexError:
            pass
        return None

    def _mark_discontinuity(self, packet_chunk: bytearray, offset: int, has_adaptation: bool):
        """Sinaliza quebra de continuidade modificando a flag in-place de maneira segura."""
        if has_adaptation:
            adapt_len = packet_chunk[offset + 4]
            if adapt_len > 0 and offset + 5 < len(packet_chunk):
                packet_chunk[offset + 5] |= 0x80

    def feed(self, raw: bytes) -> bytes:
        if raw:
            self._buf.extend(raw)

        if not self._aligned:
            idx = self._strict_sync()
            if idx == -1:
                if len(self._buf) > TS_PACKET_SIZE * 50:
                    self._buf.clear()
                return b''
            if idx > 0:
                del self._buf[:idx]
            self._aligned = True

        buf_len = len(self._buf)
        usable = buf_len - (buf_len % TS_PACKET_SIZE)
        if usable == 0:
            return b''

        if self._buf[0] != TS_SYNC_BYTE:
            self._aligned = False
            return b''

        chunk = self._buf[:usable]
        del self._buf[:usable]

        mv = memoryview(chunk)
        n = usable // TS_PACKET_SIZE

        # ─────────────────────────────────────────────────────────────────────────────
        # JANELLA DESLIZANTE PROGRESSIVA (FORWARD) - FILTRO DE TEMPO REPETIDO
        # ─────────────────────────────────────────────────────────────────────────────
        if self._is_suturing and self._global_pcr_base is not None:
            splice_idx = -1
            
            for i in range(n):
                off = i * TS_PACKET_SIZE
                pcr_value = self._extract_pcr(mv, off)
                
                if pcr_value is not None:
                    pcr_base = pcr_value // 300
                    pcr_diff = pcr_base - self._global_pcr_base
                    
                    # Normalização matemática de Wrap-Around de 33 bits
                    if pcr_diff < -PCR_BASE_MAX // 2:
                        pcr_diff += PCR_BASE_MAX
                    elif pcr_diff > PCR_BASE_MAX // 2:
                        pcr_diff -= PCR_BASE_MAX

                    # Se pcr_diff > 0, localizamos a fronteira real do fluxo novo (futuro)
                    if pcr_diff > 0:
                        splice_idx = i
                        self._is_suturing = False
                        break
            
            if self._is_suturing:
                # O bloco inteiro pertence ao passado/duplicado, descarta integralmente
                return b''
            else:
                # Trunca os pacotes redundantes anteriores ao ponto da sutura estável
                if splice_idx > 0:
                    chunk = chunk[splice_idx * TS_PACKET_SIZE:]
                    mv = memoryview(chunk)
                    n -= splice_idx

        # ─────────────────────────────────────────────────────────────────────────────
        # FILTRO DE SEGURANÇA H.264 - SUTURA DE VIDEO (ANTI-GRINCH)
        # ─────────────────────────────────────────────────────────────────────────────
        if self._waiting_for_keyframe:
            keyframe_idx = -1
            for i in range(n):
                off = i * TS_PACKET_SIZE
                pid = ((mv[off + 1] & 0x1F) << 8) | mv[off + 2]
                pusi = (mv[off + 1] & 0x40) != 0
                
                # Se o PID de vídeo ainda não está mapeado, tenta inferir pelo primeiro fluxo ativo
                # Ou aguarda o PUSI no PID de vídeo conhecido para achar o I-Frame
                if pusi and (self._video_pid is None or pid == self._video_pid):
                    # Verifica se contém payload para evitar falsos positivos
                    afc = (mv[off + 3] & 0x30) >> 4
                    if afc in (1, 3):
                        self._video_pid = pid
                        keyframe_idx = i
                        self._waiting_for_keyframe = False
                        break
            
            if self._waiting_for_keyframe:
                # Sem I-Frame válido para ancorar os frames. Descarta para evitar tela verde.
                return b''
            else:
                if keyframe_idx > 0:
                    chunk = chunk[keyframe_idx * TS_PACKET_SIZE:]
                    mv = memoryview(chunk)
                    n -= keyframe_idx

        # ─────────────────────────────────────────────────────────────────────────────
        # PROCESSAMENTO DE FLUXO, ALINHAMENTO DE CC E EMISSÃO DE DADOS
        # ─────────────────────────────────────────────────────────────────────────────
        for i in range(n):
            off = i * TS_PACKET_SIZE
            
            if mv[off] != TS_SYNC_BYTE:
                chunk[off:off+TS_PACKET_SIZE] = TS_NULL_PACKET
                continue

            pid = ((mv[off + 1] & 0x1F) << 8) | mv[off + 2]
            if pid == 0x1FFF: 
                continue

            cc = mv[off + 3] & 0x0F
            afc = (mv[off + 3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            has_adaptation = afc in (2, 3)
            pusi = (mv[off + 1] & 0x40) != 0

            if pid == PAT_PID and pusi:
                self._pat_received = True
            elif pid == PMT_PID and pusi:
                self._pmt_received = True

            if self._pat_received and self._pmt_received and not self._stream_initialized:
                self._stream_initialized = True

            # Captura a posição do relógio mestre continuamente
            pcr_value = self._extract_pcr(mv, off)
            if pcr_value is not None:
                self._global_pcr_base = pcr_value // 300

            # Inicialização de Timeline pós-sutura
            if not self._pcr_locked:
                if pcr_value is not None:
                    self._pcr_locked = True
                    self._last_pcr_value = pcr_value
                    self._mark_discontinuity(chunk, off, has_adaptation)
                else:
                    chunk[off:off+TS_PACKET_SIZE] = TS_NULL_PACKET
                    continue

            # Controle Estrito de Continuidade por PID
            if pid in self._cc_map and has_payload:
                expected_cc = (self._cc_map[pid] + 1) & 0x0F
                
                if cc == expected_cc:
                    self._cc_map[pid] = cc
                elif cc == self._cc_map[pid]:
                    # Pacote duplicado detectado na rede -> Transforma em nulo para não quebrar a decodificação
                    chunk[off:off+TS_PACKET_SIZE] = TS_NULL_PACKET
                    continue
                else:
                    # Descontinuidade real constatada (Salto/Gap na transmissão)
                    self._mark_discontinuity(chunk, off, has_adaptation)
                    self._cc_map[pid] = cc
            elif has_payload:
                self._cc_map[pid] = cc

        return bytes(chunk)

# ─────────────────────────────────────────────────────────────────────────────
#  StreamWriter — Injeção de Null Packets Segura (Com Discontinuidade)
# ─────────────────────────────────────────────────────────────────────────────
class StreamWriter(threading.Thread):
    def __init__(self, wfile):
        super().__init__(daemon=True)
        self.wfile = wfile
        self.queue = queue.Queue(maxsize=MAX_OUTPUT_BUFFER)
        self.running = True
        
        # Uso do monotonic para precisão de deltas de tempo
        self.last_data_time = time.monotonic()
        self._last_null_time = 0
        self._null_sequence_count = 0

    def run(self):
        while self.running:
            try:
                # O timeout de 0.05 define a reatividade da injeção de pacotes vazios
                data = self.queue.get(timeout=0.05)
                
                # Sentinela para encerrar a thread instantaneamente
                if data is None:
                    break
                
                if self._is_valid_stream_data(data):
                    self.wfile.write(data)
                    self.wfile.flush()
                    self.last_data_time = time.monotonic()
                    self._null_sequence_count = 0
                else:
                    self._send_null_packets()
                    
            except queue.Empty:
                if not self.running:
                    break
                time_since_last = time.monotonic() - self.last_data_time
                if time_since_last > 0.1:
                    self._send_null_packets()
            except (BrokenPipeError, ConnectionResetError, OSError):
                self.running = False
                break

    def _is_valid_stream_data(self, data: bytes) -> bool:
        """
        Validação otimizada em O(1). 
        Confia no alinhamento do chunk em vez de iterar sobre os bytes.
        """
        if not data or len(data) < TS_PACKET_SIZE:
            return False
            
        # O alinhamento perfeito de 188 bytes é crucial para decoders TS
        if len(data) % TS_PACKET_SIZE != 0:
            return False
            
        # Checa o Sync Byte (0x47) no início do chunk
        return data[0] == TS_SYNC_BYTE

    def _send_null_packets(self):
        current_time = time.monotonic()
        
        # Rate-limiting: não envia mais rápido que 50ms
        if current_time - self._last_null_time < 0.05:
            return
            
        self._null_sequence_count += 1
        
        # Reduz a frequência após 20 rajadas consecutivas para poupar I/O
        if self._null_sequence_count > 20 and self._null_sequence_count % 5 != 0:
            return
            
        try:
            self.wfile.write(NULL_PUMP_BURST)
            self.wfile.flush()
            self._last_null_time = current_time
        except (BrokenPipeError, ConnectionResetError, OSError):
            self.running = False

    def purge(self):
        """
        Limpa a fila ignorando locks extras, pois queue.Queue já é thread-safe.
        """
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
            except queue.Empty:
                break
                
        self._null_sequence_count = 0
        self._last_null_time = 0

    def stop(self):
        """
        Sinaliza a parada e insere um sentinela para desbloquear a fila na mesma hora.
        """
        self.running = False
        try:
            self.queue.put_nowait(None)
        except queue.Full:
            pass

# ─────────────────────────────────────────────────────────────────────────────
#  HANDLERS AUXILIARES
# ─────────────────────────────────────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers): 
        return fp
    
    # Mapeamento direto e limpo dos demais códigos de redirecionamento
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

class SessionManager:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._opener = None
                    cls._instance._last_clean = 0
                    # Lock dedicado para a renovação do opener em ambiente multi-thread
                    cls._instance._opener_lock = threading.Lock()
        return cls._instance
    
    def get_opener(self):
        now = time.time()
        
        # 1ª Checagem rápida (sem Lock) para máxima performance
        if self._opener is None or (now - self._last_clean > 60):
            with self._opener_lock:
                # 2ª Checagem (com Lock) para evitar que múltiplas threads recriem o opener juntas
                now = time.time()
                if self._opener is None or (now - self._last_clean > 60):
                    self._opener = urllib.request.build_opener(
                        urllib.request.HTTPHandler(),
                        urllib.request.HTTPSHandler(),
                        NoRedirectHandler() # Instanciação explícita
                    )
                    self._last_clean = now
                    
        return self._opener

# ─────────────────────────────────────────────────────────────────────────────
#  SERVIDOR
# ─────────────────────────────────────────────────────────────────────────────
def _ensure_server_running():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.5)
    try:
        sock.connect((HOST, PORT))
        return PORT
    except Exception:
        pass
    finally:
        sock.close()

    srv = http.server.ThreadingHTTPServer((HOST, PORT), ZeroSuturaProxy)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    time.sleep(0.5)
    return PORT

# ─────────────────────────────────────────────────────────────────────────────
#  PROXY HANDLER
# ─────────────────────────────────────────────────────────────────────────────
class ZeroSuturaProxy(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args): 
        return

    def _resolve_url(self, url: str, profile: dict, cookie_jar: http.cookiejar.CookieJar) -> str:
        curr = url
        for _ in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                req_headers = profile.copy()
                req_headers['Host'] = parsed.netloc
                req_headers['Referer'] = f"{parsed.scheme}://{parsed.netloc}/"
                req_headers['Origin'] = f"{parsed.scheme}://{parsed.netloc}"
                
                req = urllib.request.Request(curr, headers=req_headers)
                cookie_jar.add_cookie_header(req)
                
                opener = SessionManager().get_opener()
                with opener.open(req, timeout=5) as resp:
                    if resp.code in (301, 302, 303, 307, 308):
                        loc = resp.headers.get('Location', '')
                        if loc:
                            curr = urllib.parse.urljoin(curr, loc)
                        cookie_jar.extract_cookies(resp, req)
                        continue
                    cookie_jar.extract_cookies(resp, req)
                    return curr
            except Exception:
                break
        return curr

    def _calculate_backoff(self, reconnect_num: int, error_type: str = 'network') -> float:
        if error_type in ('reset', 'eof'):
            base = 0.05
        elif error_type in ('network', 'cdn_change'):
            base = 0.15
        elif error_type == 'timeout':
            base = 0.3
        else:
            base = 0.5
        if reconnect_num <= 2:
            return base * reconnect_num
        return min(5.0, base * (reconnect_num ** 1.3))

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'keep-alive')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
        except Exception:
            return

        if not original_url:
            return

        writer = StreamWriter(self.wfile)
        writer.start()

        profile_keys = list(_CLIENT_PROFILES.keys())
        current_profile_idx = random.randint(0, len(profile_keys) - 1)
        profile_key = profile_keys[current_profile_idx]
        profile = _CLIENT_PROFILES[profile_key].copy()
        ua = profile["User-Agent"]
        
        resolved_url = original_url
        reconnect_num = 0
        ts_parser = TsParser()
        session_mgr = SessionManager()
        
        cookie_jar = http.cookiejar.CookieJar()
        
        session_metrics = {
            'bytes_received': 0,
            'read_rate': 0.0,
            'reconnects': 0,
            'last_host': None,
            'last_ip': None
        }
        
        adaptive_timeout = 10.0
        chunk_sizes = [8192, 16384, 32768, 65536]
        chunk_idx = 1
        read_chunk_size = chunk_sizes[chunk_idx]
        chunk_times = []
        
        last_useful_payload = time.time()
        error_type = 'network'
        first_connection = True
        
        connection_start_time = 0
        current_host = None
        current_ip = None

        try:
            while writer.running:
                ts_parser.reset_stream_state()
                writer.purge()
                last_useful_payload = time.time()
                
                try:
                    resolved_url = self._resolve_url(resolved_url, profile, cookie_jar)
                    
                    parsed = urllib.parse.urlparse(resolved_url)
                    current_host = parsed.netloc
                    
                    req_headers = profile.copy()
                    req_headers['Host'] = current_host
                    req_headers['Referer'] = f"{parsed.scheme}://{current_host}/"
                    req_headers['Origin'] = f"{parsed.scheme}://{current_host}"
                    
                    req = urllib.request.Request(resolved_url, headers=req_headers)
                    cookie_jar.add_cookie_header(req)

                    opener = session_mgr.get_opener()
                    connection_start_time = time.time()
                    
                    with opener.open(req, timeout=adaptive_timeout) as response:
                        try:
                            current_ip = response.fp.raw._sock.getpeername()[0]
                        except:
                            pass
                            
                        if session_metrics['last_host'] is not None and (current_host != session_metrics['last_host'] or current_ip != session_metrics['last_ip']):
                            error_type = 'cdn_change'
                            
                        session_metrics['last_host'] = current_host
                        session_metrics['last_ip'] = current_ip
                        
                        cookie_jar.extract_cookies(response, req)
                        
                        if reconnect_num == 0:
                            print(f"[ZeroSutura] Conectado → {ua[:30]}... Perfil: {profile_key}")
                        else:
                            reconnect_num = max(0, reconnect_num - 2)

                        while writer.running:
                            chunk_start = time.time()
                            
                            fd = response.fp
                            if hasattr(fd, 'fileno'):
                                ready, _, _ = select.select([fd], [], [], adaptive_timeout)
                                if not ready:
                                    raise socket.timeout("Adaptive read timeout")
                                    
                            raw = response.read(read_chunk_size)

                            if not raw:
                                error_type = 'eof'
                                break

                            read_time = time.time() - chunk_start
                            chunk_times.append(read_time)
                            if len(chunk_times) > 20:
                                chunk_times.pop(0)
                                
                            session_metrics['bytes_received'] += len(raw)
                            elapsed = time.time() - connection_start_time
                            if elapsed > 0:
                                session_metrics['read_rate'] = (session_metrics['bytes_received'] * 8) / (elapsed * 1000)
                                
                            avg_chunk_time = sum(chunk_times) / len(chunk_times) if chunk_times else 1.0
                            adaptive_timeout = max(5.0, min(30.0, avg_chunk_time * 10))
                            
                            if len(chunk_times) >= 10:
                                if avg_chunk_time < 0.01 and chunk_idx < len(chunk_sizes) - 1:
                                    chunk_idx += 1
                                    read_chunk_size = chunk_sizes[chunk_idx]
                                elif avg_chunk_time > 0.5 and chunk_idx > 0:
                                    chunk_idx -= 1
                                    read_chunk_size = chunk_sizes[chunk_idx]

                            payload = ts_parser.feed(raw)
                            
                            if payload and ts_parser._pcr_locked:
                                if ts_parser._stream_initialized:
                                    last_useful_payload = time.time()
                                    try:
                                        writer.queue.put(payload, block=True, timeout=5.0)
                                    except queue.Full:
                                        pass
                            elif payload and not ts_parser._pcr_locked:
                                pass
                            else:
                                if time.time() - last_useful_payload > STALL_TIMEOUT:
                                    error_type = 'stall'
                                    break

                except urllib.error.HTTPError as e:
                    error_type = 'http'
                except urllib.error.URLError as e:
                    reason = str(e.reason).lower()
                    error_type = 'timeout' if 'timeout' in reason else 'reset' if 'reset' in reason else 'network'
                except socket.timeout:
                    error_type = 'timeout'
                except ConnectionResetError:
                    error_type = 'reset'
                except EOFError:
                    error_type = 'eof'
                except (BrokenPipeError, OSError):
                    break
                except Exception:
                    error_type = 'network'

                if not writer.running:
                    break

                reconnect_num += 1
                session_metrics['reconnects'] = reconnect_num
                
                # Rotação de Perfis HTTP em cada falha
                current_profile_idx = (current_profile_idx + 1) % len(profile_keys)
                profile_key = profile_keys[current_profile_idx]
                profile = _CLIENT_PROFILES[profile_key].copy()
                ua = profile["User-Agent"]
                
                backoff = self._calculate_backoff(reconnect_num, error_type)
                
                # Log Interno. O Kodi nunca recebe erros HTTP, apenas Null Packets ininterruptos.
                print(f"[!] Falha ({error_type}) Reconexão #{reconnect_num}. Perfil trocado para {profile_key}. Tentando em {backoff:.2f}s [Rate: {session_metrics['read_rate']:.0f} kbps]")
                time.sleep(backoff)

                try:
                    new_url = self._resolve_url(original_url, profile, cookie_jar)
                    if new_url != resolved_url:
                        resolved_url = new_url
                        print(f"[+] Token/URL atualizado #{reconnect_num}")
                except Exception:
                    pass

        finally:
            writer.stop()
            writer.join(timeout=1.0)

# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = _ensure_server_running()
    print(f"[ZeroSutura v5 Pro] Proxy rodando em http://{HOST}:{port}/stream?url=<URL>")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("[ZeroSutura] Encerrado.")