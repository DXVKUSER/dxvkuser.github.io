#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Proxy HLS ULTRA RESILIENTE para Kodi – v3.1 (TARGETDURATION Dinâmico) - CORRIGIDO
# -----------------------------------------------------------------------------------
# • ZERO TRAVAMENTO
# • 404 = Pula instantaneamente (200 vazio)
# • Recarga do manifesto a cada 1s por 60s
# • Cache agressivo + qualidade fixa em falha
# • Player 100% fluido
# • CORREÇÃO: Evita RESET DE SESSÃO PÓS-SUCESSO para evitar EOF prematuro no Kodi
# • CORREÇÃO: Lógica de reconexão mais robusta para qualquer erro de segmento
# -----------------------------------------------------------------------------------

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
from socketserver import ThreadingMixIn
import re

# --- REQUESTS ---
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- DNS OVER HTTPS (OPCIONAL) ---
try:
    import doh_client
    doh_requests = requests
    logging.info("DoH ativado via doh_client.")
except ImportError:
    doh_requests = requests
    logging.warning("doh_client não encontrado. Usando DNS padrão.")

# --- KODI ---
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    class MockKodi:
        def translatePath(self, path): return "/tmp/"
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None

# ---------------- CONFIGURAÇÕES ----------------
# VALORES REDUZIDOS PARA DESISTIR MAIS RÁPIDO E FORÇAR RECONEXÃO:
MAX_SEGMENT_RETRIES = 1 
RETRY_BACKOFF_FACTOR = 0.01
CONNECTION_TIMEOUT = 5.0
# Timeout de segurança/fallback
STREAM_TIMEOUT_FALLBACK = 30.0 
# Fator multiplicador para o TARGETDURATION
TARGET_DURATION_TIMEOUT_FACTOR = 3.0 

# AUMENTADO PARA MAIS ESTABILIDADE NA REPRODUÇÃO
DEFAULT_CHUNK_SIZE = 64 * 1024
# ALTERAÇÃO SOLICITADA: Usar 0.0.0.0 para escutar em todas as interfaces (IP do dispositivo)
PROXY_HOST = '0.0.0.0' 
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"
MANIFEST_RETRY_DELAY = 0.05
FAIL_RELOAD_TTL = 60  # 60s de recarga rápida
FAILED_SEGMENT_TTL = 90
CACHE_TTL = 1  # Cache de 1s para manifesto em falha

USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.{version} Safari/537.36"

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- ESTADO GLOBAL ----------------
FAILED_SEGMENT_CACHE = {}
STREAM_FAIL_STATE = {}
MANIFEST_CACHE = {}
STATE_LOCK = threading.Lock()

# ---------------- UTILS ----------------

# --- GERADOR DE IP FAKE ---
def _generate_fake_ip():
    """Gera um endereço IPv4 fake aleatório (exclui faixas privadas e reservadas)."""
    while True:
        # Gera 4 octetos aleatórios
        octets = [random.randint(1, 254) for _ in range(4)]
        ip_str = ".".join(map(str, octets))
        
        # Simples exclusão de faixas mais comuns de IP privado/reservado (A, B, C)
        if (octets[0] == 10 or 
            (octets[0] == 172 and 16 <= octets[1] <= 31) or 
            (octets[0] == 192 and octets[1] == 168) or 
            octets[0] == 127 or octets[0] == 0 or octets[0] >= 240):
            continue
        return ip_str
# --------------------------------

def setup_logging():
    try:
        log_dir = xbmc.translatePath('special://logpath')
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        log_path = os.path.join(log_dir, LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
        logging.info("Proxy v3.1 rodando em 0.0.0.0 (IP do Dispositivo)")
    except Exception:
        logging.basicConfig(level=logging.INFO)

def cleanup_cache():
    while True:
        try:
            now = time.time()
            # Aumentando o CACHE_TTL para manifestos na limpeza para 60s, a lógica do manifesto
            # fará o refresh rápido se estiver em fail state.
            MANIFEST_CACHE_TTL = 60 # Mantém o manifesto em cache por mais tempo, reduzindo requisições desnecessárias.
            
            # Limpa cache de manifesto
            expired_manifests = [k for k, v in MANIFEST_CACHE.items() if now - v.get('timestamp', 0) > MANIFEST_CACHE_TTL]
            for k in expired_manifests:
                del MANIFEST_CACHE[k]

            # Limpa cache de segmento falho (TTL de 90s)
            expired_segments = [k for k, v in FAILED_SEGMENT_CACHE.items() if now - v.get('timestamp', 0) > FAILED_SEGMENT_TTL]
            for k in expired_segments:
                del FAILED_SEGMENT_CACHE[k]

            # Limpa fail state
            expired_fail_state = [k for k, t in STREAM_FAIL_STATE.items() if now - t > FAIL_RELOAD_TTL]
            for k in expired_fail_state:
                del STREAM_FAIL_STATE[k]
        except Exception as e:
            logging.error(f"Cleanup error: {e}")
        time.sleep(60)

# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):

    def create_session(self):
        session = requests.Session()
        # Aumentando total de retries para a sessão para ser mais resiliente
        retry = Retry(
            total=MAX_SEGMENT_RETRIES + 2, # Adiciona mais duas tentativas
            status_forcelist=[500, 502, 503, 504],
            backoff_factor=RETRY_BACKOFF_FACTOR,
            raise_on_status=False
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    # A sessão deve ser uma variável de instância para cada Thread/Handler para
    # que o retry/reconexão não afete outras reproduções ativas, mas a 
    # implementação original usou uma variável de classe e a recria em _reset_session_and_retry.
    # Vamos manter a estrutura de classe para evitar refatoração massiva,
    # mas o problema do Kodi fechar está na redefinição PÓS-SUCESSO.
    session = None 

    error_counter = {}
    network_quality = {}
    dynamic_chunk_size = {}
    last_segment_times = {}
    last_segment_sizes = {}
    session_ua_versions = {}
    session_fake_ips = {} 
    session_manifest_refresh = {}
    
    session_stream_timeout = {} 

    MAX_TIMES_TO_AVERAGE = 5

    def __init__(self, *args, **kwargs):
        # GARANTE QUE A SESSÃO É CRIADA PARA A CLASSE OU INSTÂNCIA (se não for thread safe)
        # Manter a lógica original de sessão única, mas criar uma nova na falha agressiva
        if HLSProxyRequestHandler.session is None:
            HLSProxyRequestHandler.session = self.create_session()
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        pass  # Silencia logs do http.server

    def _get_session_user_agent(self, session_id):
        # Versão do UA é fixa para a sessão, a menos que haja um reset agressivo
        version = self.session_ua_versions.get(session_id, random.randint(1000, 5000))
        self.session_ua_versions[session_id] = version # Garante que a versão está setada
        return USER_AGENT_TEMPLATE.format(version=version)

    def _get_session_fake_ip(self, session_id):
        # IP Fake é fixo para a sessão, a menos que haja um reset agressivo
        ip = self.session_fake_ips.get(session_id, _generate_fake_ip())
        self.session_fake_ips[session_id] = ip # Garante que o IP está setado
        return ip

    def _rotate_session_user_agent(self, session_id):
        # Gira o User-Agent, usado no reset agressivo
        current = self.session_ua_versions.get(session_id, random.randint(1000, 5000))
        new = current + 1
        self.session_ua_versions[session_id] = new
        logging.info(f"User-Agent girado para {new} (Sessão: {session_id})")

    def _rotate_session_fake_ip(self, session_id):
        # Gira o IP Fake, usado no reset agressivo
        new_ip = _generate_fake_ip()
        self.session_fake_ips[session_id] = new_ip
        logging.info(f"IP Fake girado para {new_ip} (Sessão: {session_id})")
        return new_ip

    def _get_segment_timeout(self, session_id):
        # Retorna o timeout dinâmico ou o fallback de segurança
        return self.session_stream_timeout.get(session_id, STREAM_TIMEOUT_FALLBACK)

    def _reset_session_and_retry(self, session_id):
        """
        Executa um reset agressivo na falha.
        Isso inclui girar o UA/IP, recriar a sessão requests e forçar o refresh do manifesto.
        """
        logging.info(f"RESET AGRESSIVO POR FALHA (Sessão: {session_id})")
        
        # 1. Gira credenciais
        self._rotate_session_user_agent(session_id)
        self._rotate_session_fake_ip(session_id) 
        
        # 2. Recria a sessão HTTP para quebrar qualquer conexão pendente/problema de DNS.
        HLSProxyRequestHandler.session = self.create_session()
        
        # 3. Força refresh do manifesto na próxima requisição
        self.session_manifest_refresh[session_id] = time.time()
        self.error_counter[session_id] = 0
        
        # 4. Atualiza estado global
        with STATE_LOCK:
            # Remove o manifesto do cache para forçar a busca.
            MANIFEST_CACHE.pop(session_id, None) 
            # Define o estado de falha para ativar a recarga rápida de 1s
            STREAM_FAIL_STATE[session_id] = time.time()
            # Força o chunk size mais baixo em falha
            self.dynamic_chunk_size[session_id] = 16 * 1024 

    # --- CORREÇÃO PRINCIPAL: REMOVER O RESET PÓS-SUCESSO ---
    def _reset_session_on_success(self, session_id): 
        # logging.info(f"RESET DE SESSÃO PÓS-SUCESSO (Manifesto 200 OK) (Sessão: {session_id})")
        # self._rotate_session_user_agent(session_id)
        # self._rotate_session_fake_ip(session_id)
        # HLSProxyRequestHandler.session = self.create_session()
        # self.session_manifest_refresh[session_id] = time.time()
        
        # O código original acima fazia o Kodi fechar, pois o Kodi vê um novo stream (nova sessão)
        # a cada manifesto e pode interpretá-lo como o fim do stream anterior.
        # A única coisa que faremos no sucesso é limpar o estado de falha.
        with STATE_LOCK:
            # Crucial: remove fail state on successful manifest to stop quick reload
            STREAM_FAIL_STATE.pop(session_id, None) 
        logging.debug(f"Limpeza de Fail State no Manifesto 200 OK (Sessão: {session_id})")


    def _get_forward_headers(self, session_id):
        return {
            'User-Agent': self._get_session_user_agent(session_id),
            'Connection': 'close',
            'Accept': '*/*',
            'X-Forwarded-For': self._get_session_fake_ip(session_id), 
        }

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            # Garante que as credenciais de sessão (UA/IP) são inicializadas
            session_id = params.get('session_id', [f"anon_{random.randint(1000,9999)}"])[0]
            self._get_session_user_agent(session_id) # Inicializa UA
            self._get_session_fake_ip(session_id)    # Inicializa IP Fake

            if not url:
                self.send_error(400)
                return

            headers = self._get_forward_headers(session_id)
            parsed = urllib.parse.urlparse(url)

            is_manifest = (
                parsed.path.lower().endswith(('.m3u8', '.m3u')) or
                'manifest' in parsed.query.lower()
            )

            if is_manifest:
                self._handle_manifest(url, headers, head_only, session_id)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except Exception as e:
            logging.error(f"Erro crítico: {e}")
            try:
                self.send_error(500)
            except:
                pass

    def _handle_manifest(self, url, headers, head_only, session_id):
        force_refresh = self.session_manifest_refresh.pop(session_id, None) is not None
        now = time.time()
        cache = MANIFEST_CACHE.get(session_id)
        
        # Decide se usa cache
        use_cache = False
        if cache:
            # Cache de 1s para o manifesto (CACHE_TTL = 1)
            is_stale = (now - cache['timestamp']) >= CACHE_TTL 
            is_in_fail_state = session_id in STREAM_FAIL_STATE
            
            # Se não estiver em fail state, o cache é válido até expirar (1s).
            # Se estiver em fail state, é crucial não usar o cache e forçar o refresh.
            use_cache = not force_refresh and cache and not is_stale and not is_in_fail_state
            
        if use_cache:
            self._send_manifest(cache['content'], head_only)
            logging.debug(f"Manifesto servido do Cache (Sessão: {session_id})")
            return

        try:
            # Tenta obter o manifesto
            r = self.session.get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
            
            # 404/403 no manifesto é crítico
            if r.status_code == 404 or r.status_code == 403:
                logging.error(f"Manifesto retornou {r.status_code}. Forçando redefinição agressiva (Sessão: {session_id})")
                self._reset_session_and_retry(session_id)
                # Tenta buscar novamente UMA VEZ com a nova sessão e credenciais
                r = self.session.get(url, headers=self._get_forward_headers(session_id), timeout=CONNECTION_TIMEOUT, verify=False, allow_redirects=True)
                if r.status_code == 404 or r.status_code == 403:
                    self.send_error(r.status_code) # Se a 2ª tentativa falhar, retorna o erro
                    return
            
            r.raise_for_status() # Lança exceção para 4xx (exceto 404/403 já tratados) e 5xx
            
            # Se o manifesto for bem-sucedido, limpa o estado de falha (CORREÇÃO)
            if r.status_code == 200:
                self._reset_session_on_success(session_id)

        except requests.exceptions.RequestException as e:
            logging.error(f"Falha ao buscar manifesto (Sessão: {session_id}). Status: {getattr(e.response, 'status_code', 'N/A')}. Erro: {e}")
            self._reset_session_and_retry(session_id)
            self.send_error(502)
            return

        content = r.text
        base_url = r.url

        # DETECÇÃO DE TARGETDURATION E AJUSTE DE TIMEOUT
        target_duration = None
        match = re.search(r'#EXT-X-TARGETDURATION:(\d+(\.\d+)?)', content)
        if match:
            try:
                target_duration = float(match.group(1))
                # Define o timeout como 3x o Target Duration
                new_timeout = target_duration * TARGET_DURATION_TIMEOUT_FACTOR
                # Garante um mínimo para o caso de target_duration ser muito baixo
                self.session_stream_timeout[session_id] = max(new_timeout, STREAM_TIMEOUT_FALLBACK / 2) # Mínimo de 15s
                logging.info(f"Manifesto: TargetDuration={target_duration}s. Timeout dinâmico ajustado para {self.session_stream_timeout[session_id]:.2f}s (Sessão: {session_id})")
            except ValueError:
                target_duration = None

        if not target_duration:
            # Se não encontrar, usa o fallback de segurança (30s)
            self.session_stream_timeout[session_id] = STREAM_TIMEOUT_FALLBACK
            logging.warning(f"Manifesto: TargetDuration não encontrado. Usando Timeout de Fallback: {STREAM_TIMEOUT_FALLBACK}s (Sessão: {session_id})")


        # RECARGA RÁPIDA (1s) SEMPRE EM FALHA
        if session_id in STREAM_FAIL_STATE:
            content = re.sub(r'#EXT-X-TARGETDURATION:\d+', '#EXT-X-TARGETDURATION:1', content)
            logging.info(f"RECARGA RÁPIDA (1s) ATIVADA (Sessão: {session_id})")

        # Remove segmentos falhos e faz o proxying
        failed = FAILED_SEGMENT_CACHE.get(session_id, {}).get('urls', set())
        lines = []
        i = 0
        raw = content.splitlines()
        while i < len(raw):
            line = raw[i].strip()
            if not line or line.startswith('#'):
                lines.append(raw[i])
            else:
                full_url = urllib.parse.urljoin(base_url, line)
                if full_url in failed:
                    # Se falhou, remove a tag EXTINF anterior também.
                    if i > 0 and raw[i-1].startswith('#EXTINF'):
                        del lines[-1] # Remove a linha EXTINF adicionada na iteração anterior
                    i += 1
                    continue
                
                # A variável PROXY_HOST é 0.0.0.0. Para consumo no Kodi local, usamos 127.0.0.1.
                proxy_host_for_url = '127.0.0.1' 
                
                proxy_url = f"http://{proxy_host_for_url}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={session_id}"
                lines.append(proxy_url)
            i += 1

        final = '\n'.join(lines)
        
        # Atualiza o cache do manifesto
        MANIFEST_CACHE[session_id] = {'content': final, 'timestamp': now}
        
        self._send_manifest(final, head_only)

    def _send_manifest(self, content, head_only):
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Cache-Control', 'no-cache, no-store')
        self.end_headers()
        if not head_only:
            try:
                self.wfile.write(content.encode('utf-8'))
                self.wfile.flush()
            except Exception as e:
                logging.error(f"Falha ao enviar manifesto para o cliente: {e}")

    def _handle_segment(self, url, session_id, headers, head_only):
        # Pula imediatamente se já falhou
        if url in FAILED_SEGMENT_CACHE.get(session_id, {}).get('urls', set()):
            self._send_empty()
            return
        
        # USA O TIMEOUT DINÂMICO
        current_timeout = self._get_segment_timeout(session_id)

        try:
            with self.session.get(url, headers=headers, stream=True, timeout=current_timeout, verify=False) as r: 
                
                # Trata 404 e 204 (No Content) como falha imediata para pular
                if r.status_code == 404 or r.status_code == 204:
                    logging.info(f"Segmento {r.status_code} detectado: {url}")
                    self._mark_failed(session_id, url)
                    self._reset_session_and_retry(session_id)
                    self._send_empty()
                    return

                # Qualquer outro erro 4xx ou 5xx
                if r.status_code >= 400:
                    logging.warning(f"Segmento falhou com status {r.status_code}: {url}")
                    r.raise_for_status() # Lança HTTPError para cair no bloco except
                    
                # Sucesso: Zera contador de erros
                self.error_counter[session_id] = 0
                
                # Envia cabeçalhos de sucesso
                self.send_response(r.status_code)
                for k, v in r.headers.items():
                    if k.lower() not in ['transfer-encoding', 'connection', 'content-encoding', 'keep-alive']:
                        self.send_header(k, v)
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()

                if head_only:
                    return

                # Streaming do conteúdo
                for data in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE): # Usando DEFAULT_CHUNK_SIZE (64k)
                    if not data: continue
                    try:
                        self.wfile.write(data)
                        self.wfile.flush()
                    except:
                        # Se falhar ao escrever para o cliente (Kodi fechou), para.
                        logging.warning(f"Falha ao enviar dados para o cliente (Sessão: {session_id})")
                        return
                return

        # --- Lógica de Reconexão para QUALQUER ERRO (Timeout, HTTPError, ConnectionError, etc.) ---
        except requests.exceptions.RequestException as e:
            # Caso especial para 404/204 que não foram capturados acima
            if '404' in str(e) or '204' in str(e):
                 logging.info(f"Segmento 404/204 (RequestException) detectado: {url}")
            else:
                logging.error(f"Erro no Segmento (Sessão: {session_id}, URL: {url}). Tipo: {type(e).__name__}, Erro: {e}")
            
            # Marca como falha, reseta sessão e envia vazio
            self._mark_failed(session_id, url)
            self._reset_session_and_retry(session_id)
            self._send_empty()
            return

        except Exception as e:
            # Captura exceções genéricas (ex: problemas no socket do servidor)
            logging.error(f"Erro inesperado no segmento (Sessão: {session_id}, URL: {url}). Erro: {e}")
            self._mark_failed(session_id, url)
            self._reset_session_and_retry(session_id)
            self._send_empty()


    def _send_empty(self):
        """Envia uma resposta HTTP 200 OK vazia para pular o segmento."""
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Content-Length', '0')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        # Não escreve nada no wfile.

    def _mark_failed(self, session_id, url):
        """Marca o segmento como falho e atualiza o estado de falha do stream."""
        now = time.time()
        with STATE_LOCK:
            cache = FAILED_SEGMENT_CACHE
            if session_id not in cache:
                cache[session_id] = {'timestamp': now, 'urls': {url}}
            else:
                cache[session_id]['urls'].add(url)
                cache[session_id]['timestamp'] = now
            # Ativa o estado de falha para o stream (para recarga rápida do manifesto)
            STREAM_FAIL_STATE[session_id] = now
            # Invalida o manifesto no cache para forçar o proxy a remover o segmento falho
            MANIFEST_CACHE.pop(session_id, None)
        logging.info(f"SEGMENTO FALHO → PULANDO + RECARGA RÁPIDA (Sessão: {session_id}, Segmento: {url[-30:]}...)")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.end_headers()

# ---------------- SERVIDOR ----------------
class ThreadingHTTPServer(ThreadingMixIn, http.server.HTTPServer):
    pass

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(30000, 60000)
            try:
                # O servidor escuta em 0.0.0.0 (PROXY_HOST)
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy v3.1 rodando em {PROXY_HOST} na porta {port}")
                return True
            except Exception as e:
                logging.warning(f"Porta {port} ocupada. Tentando outra. Erro: {e}")
                continue
        logging.error("Falha ao iniciar o servidor proxy após várias tentativas.")
        return False

# ---------------- ADDON KODI ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            if xbmcplugin:
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        session_id = f"stream_{int(time.time())}_{random.randint(1000, 9999)}"
        # Usa 127.0.0.1 para URL de consumo, pois é o endereço mais seguro para comunicação interna,
        # mesmo que o servidor esteja escutando em 0.0.0.0.
        proxy_host_for_url = '127.0.0.1' 
        proxy_url = f"http://{proxy_host_for_url}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}&session_id={session_id}"

        if xbmcgui and xbmcplugin:
            li = xbmcgui.ListItem(path=proxy_url, label=title or "Stream")
            li.setProperty("IsPlayable", "true")
            if stype == "live":
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setProperty("IsLive", "true")
            xbmcplugin.setResolvedUrl(self.handle, True, li)
        # Inicia a thread de limpeza na primeira reprodução
        threading.Thread(target=cleanup_cache, daemon=True).start()

def main():
    setup_logging()
    # A thread de limpeza será iniciada na primeira reprodução dentro de HLSAddon.play_stream()
    # threading.Thread(target=cleanup_cache, daemon=True).start() # Removido daqui
    try:
        if len(sys.argv) < 2:
            return
        handle = int(sys.argv[1])
        addon = HLSAddon(handle)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            url = args.get('url', [None])[0]
            stype = args.get('stream_type', [None])[0]
            title = args.get('title', [None])[0]
            addon.play_stream(url, stype, title)
        elif xbmcplugin:
            xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        logging.error(f"Erro main: {e}")

if __name__ == '__main__':
    main()