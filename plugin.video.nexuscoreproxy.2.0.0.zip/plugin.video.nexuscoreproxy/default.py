# -*- coding: utf-8 -*-

import sys
import threading
import time
import gc
import socket
import traceback
import re
import queue
from queue import Empty, Full, Queue
from urllib.parse import parse_qsl, urlparse, urljoin, quote
from collections import OrderedDict

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib3
from requests.exceptions import ConnectionError, ChunkedEncodingError
from requests.adapters import HTTPAdapter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    from flask import (
        Flask, request, Response, stream_with_context, make_response,
        redirect
    )
except ImportError:
    xbmcgui.Dialog().ok("Erro", "Módulo 'script.module.flask' não encontrado.")
    sys.exit(1)

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

addon_path = ADDON.getAddonInfo('path')
app = Flask(__name__, root_path=addon_path)
app.debug = False
SERVER_THREAD = None
SERVER_PORT = None
SERVER_LOCK = threading.Lock()

def get_setting_int(id, def_val): return int(ADDON.getSetting(id)) if ADDON.getSetting(id) else def_val
def get_setting_bool(id, def_val): return ADDON.getSettingBool(id) if ADDON.getSetting(id) != '' else def_val

# ========================================================================
# NEXUS CORE V16.10 - ANTI FREEZE EDITION
# ========================================================================

# Configurações Carregadas
FETCH_TIMEOUT = get_setting_int("fetch_timeout", 3) # Lendo do XML ajustado
if FETCH_TIMEOUT == 0: FETCH_TIMEOUT = 3

# Usamos timeout interno menor que o do setting para garantir reconexão antes do buffer do Kodi zerar
INTERNAL_READ_TIMEOUT = 2.0 
INTERNAL_CONNECT_TIMEOUT = 3.0

SEARCH_WINDOW = get_setting_int("search_window_kb", 8192) * 1024 
TAIL_PRIMARY = get_setting_int("tail_primary_kb", 32) * 1024
TAIL_SECONDARY = get_setting_int("tail_secondary_kb", 8) * 1024
FORCE_RESYNC_SIZE = get_setting_int("force_resync_kb", 64) * 1024
CHUNK_SIZE = get_setting_int("chunk_size_kb", 64) * 1024
QUEUE_SIZE = get_setting_int("queue_size", 1000)
KEEPALIVE_ENABLED = get_setting_bool("enable_keepalive", True)
KEEPALIVE_COUNT = get_setting_int("keepalive_multiplier", 10)

DEFAULT_HEADERS = {
    'User-Agent': 'VLC/3.0.18 LibVLC/3.0.18',
    'Accept': '*/*',
    'Connection': 'keep-alive',
}

TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184

class ConnectionPool:
    def __init__(self):
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=50, pool_maxsize=100, max_retries=0)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)
    def get(self): return self.session

connection_pool = ConnectionPool()

# ========================================================================
# NEXUS CORE V16.10 - MOTOR SAFE STITCHING (COM FALLBACK)
# ========================================================================

class NexusCoreEngine:
    def __init__(self, target_url):
        self.target_url = target_url
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self.stop_event = threading.Event()
        self.last_data_time = [time.time()]
        self.reconnect_count = [0]
        self.stream_tail = b""
        self.drain_cycles = 0
        
        # Buffer de Sutura (Leftover)
        self.leftover_bytes = bytearray()
        self.sync_locked = False

    def generator(self):
        t = threading.Thread(target=self._producer_loop, daemon=True)
        t.start()
        
        try:
            while not self.stop_event.is_set():
                try:
                    # Timeout da fila menor que o timeout de leitura para detectar stalls rapidamente
                    chunk = self.data_queue.get(timeout=1.5)
                    yield chunk
                except queue.Empty:
                    # Enviar NULL packets para manter o decoder vivo
                    yield TS_NULL_PACKET * KEEPALIVE_COUNT
        except GeneratorExit:
            pass
        finally:
            self.stop_event.set()

    def _update_tail(self, data):
        if data:
            self.stream_tail = (self.stream_tail + data)[-TAIL_PRIMARY:]

    def _stitch_and_send(self, data_source, is_final=False):
        if not data_source:
            return bytearray()

        # 1. Sync Lock (Garantir início em 0x47)
        if not self.sync_locked:
            idx = data_source.find(b'\x47')
            if idx != -1:
                data_source = data_source[idx:]
                self.sync_locked = True
            else:
                return data_source

        # 2. Alinhamento "Cabeçalho Duplo" (Smart Fallback)
        sync_pos = data_source.find(b'\x47')
        valid_pos = -1
        search_limit = min(len(data_source), 188 * 5)
        
        if sync_pos != -1:
            found_perfect = False
            for i in range(sync_pos, search_limit, 188):
                if i + 188 < len(data_source):
                    if data_source[i + 188] == 0x47:
                        valid_pos = i
                        found_perfect = True
                        break
            
            if not found_perfect:
                valid_pos = sync_pos
        else:
            return data_source

        aligned_data = data_source[valid_pos:]
        
        # 3. Stitching (Pacotes Inteiros)
        packet_count = len(aligned_data) // 188
        if packet_count == 0:
            return data_source
            
        data_to_send = aligned_data[:packet_count * 188]
        remainder = aligned_data[packet_count * 188:]

        if data_to_send:
            self.data_queue.put(bytes(data_to_send))
            self.last_data_time[0] = time.time()
            self._update_tail(bytes(data_to_send))

        return remainder

    def _producer_loop(self):
        xbmc.log(f"[NEXUS CORE V16.10] Motor Iniciado (Anti-Freeze Protocol): {self.target_url}", xbmc.LOGINFO)
        
        while not self.stop_event.is_set():
            # Cria uma nova sessão (Clean Cache/Token)
            fresh_session = requests.Session()
            adapter = HTTPAdapter(pool_connections=1, pool_maxsize=1, max_retries=0)
            fresh_session.mount('http://', adapter)
            fresh_session.mount('https://', adapter)

            try:
                self.leftover_bytes = bytearray()
                self.sync_locked = False
                
                # Timeout Agressivo: Se o servidor travar, cortamos a conexão em 1.5s
                with fresh_session.get(
                    self.target_url, 
                    headers=DEFAULT_HEADERS, 
                    stream=True, 
                    timeout=(INTERNAL_CONNECT_TIMEOUT, INTERNAL_READ_TIMEOUT),
                    verify=False, 
                    allow_redirects=True
                ) as r:
                    
                    if r.status_code not in [200, 206]:
                        raise Exception(f"Status Code: {r.status_code}")
                    
                    iterator = r.iter_content(chunk_size=CHUNK_SIZE)
                    xbmc.log(f"[NEXUS CORE V16.10] Conectado (Tentativa {self.reconnect_count[0] + 1}).")

                    need_resync = self.reconnect_count[0] > 0 and len(self.stream_tail) >= TAIL_SECONDARY
                    is_resyncing = need_resync
                    resync_buffer = bytearray()
                    self.drain_cycles = 0
                    
                    # Limite de segurança para evitar loop infinito no Anti-Grinch
                    MAX_DRAIN_CYCLES = 3 

                    self.reconnect_count[0] += 1
                    
                    for chunk in iterator:
                        if self.stop_event.is_set():
                            break
                        
                        if not chunk:
                            continue
                        
                        self.leftover_bytes.extend(chunk)
                        
                        # Lógica Anti-Grinch Otimizada (Com Trava de Segurança)
                        if is_resyncing:
                            resync_buffer.extend(chunk)
                            
                            if len(resync_buffer) > SEARCH_WINDOW:
                                resync_buffer = resync_buffer[-SEARCH_WINDOW:]

                            idx = -1
                            match_type = ""
                            matched_tail = b''

                            if len(self.stream_tail) >= TAIL_PRIMARY and len(resync_buffer) >= TAIL_PRIMARY:
                                matched_tail = self.stream_tail[-TAIL_PRIMARY:]
                                idx = resync_buffer.find(matched_tail)
                                if idx != -1: match_type = "Primário"

                            if idx == -1 and len(self.stream_tail) >= TAIL_SECONDARY and len(resync_buffer) >= TAIL_SECONDARY:
                                matched_tail = self.stream_tail[-TAIL_SECONDARY:]
                                idx = resync_buffer.find(matched_tail)
                                if idx != -1: match_type = "Secundário"

                            if idx != -1:
                                skip_offset = idx + len(matched_tail)
                                pending_data = resync_buffer[skip_offset:]

                                self.leftover_bytes = pending_data 
                                is_resyncing = False
                                self.drain_cycles = 0
                                xbmc.log(f"[NEXUS CORE V16.10] MATCH! {match_type}. Sincronizado.", xbmc.LOGINFO)

                            elif len(resync_buffer) >= SEARCH_WINDOW:
                                self.drain_cycles += 1
                                xbmc.log(f"[NEXUS CORE V16.10] Buffer cheio. FAST FORWARD (Ciclo {self.drain_cycles}/{MAX_DRAIN_CYCLES}).", xbmc.LOGWARNING)
                                
                                # FIX CRÍTICO: Se atingir o limite de ciclos, desiste do resync perfeito e envia o que tiver
                                # Isso impede o "Stream Stalled" quando a fonte não bate a cauda.
                                if self.drain_cycles >= MAX_DRAIN_CYCLES:
                                    xbmc.log(f"[NEXUS CORE V16.10] Anti-Grinch excedeu tentativas. Retomando stream básico para evitar freeze.", xbmc.LOGWARNING)
                                    is_resyncing = False
                                    self.sync_locked = False
                                    self.leftover_bytes = bytearray(resync_buffer) # Usa o buffer atual
                                else:
                                    resync_buffer = resync_buffer[-(SEARCH_WINDOW // 4):]
                                    self.leftover_bytes = resync_buffer

                        if not is_resyncing:
                            self.leftover_bytes = self._stitch_and_send(self.leftover_bytes)

            except Exception as e:
                # Erro silencioso com retentativa instantânea
                xbmc.log(f"[NEXUS CORE V16.10] Erro de Rede: {str(e)}. Reconectando...", xbmc.LOGWARNING)
                # REMOVIDO time.sleep(0.5) - Retentativa imediata para evitar buffer underrun
            finally:
                fresh_session.close()

# --- Rotas Flask ---

@app.route('/stream')
def stream_handler():
    remote_url = request.args.get('url')
    if not remote_url:
        return make_response("URL não fornecida.", 400)

    if remote_url.endswith('.m3u8') or '.m3u8' in remote_url:
        try:
            session = connection_pool.get()
            r = session.get(remote_url, headers=DEFAULT_HEADERS, timeout=10, verify=False, allow_redirects=True)
            proxy_base = f"http://127.0.0.1:{SERVER_PORT}/stream?url="
            response_data = []
            base_url_for_join = r.url 

            for line in r.text.splitlines():
                line = line.strip()
                if not line: continue
                if line.startswith('#'):
                    if 'URI="' in line:
                        uri_match = re.search(r'URI="([^"]+)"', line)
                        if uri_match:
                            uri = uri_match.group(1)
                            full_uri = urljoin(base_url_for_join, uri)
                            line = line.replace(uri, proxy_base + quote(full_uri))
                elif not line.startswith('http'):
                    full_line = urljoin(base_url_for_join, line)
                    line = proxy_base + quote(full_line)
                else:
                    line = proxy_base + quote(line)
                response_data.append(line)
            
            content = '\n'.join(response_data).encode('utf-8')
            resp = make_response(content)
            resp.headers['Content-Type'] = 'application/vnd.apple.mpegurl'
            return resp
        except Exception as e:
            xbmc.log(f"[PROXY M3U8] Erro: {e}", xbmc.LOGERROR)
            return make_response("Erro M3U8", 500)

    elif re.search(r'\.ts(\?.*)?$', remote_url, re.IGNORECASE):
        engine = NexusCoreEngine(remote_url)
        resp = Response(stream_with_context(engine.generator()), mimetype='video/mp2t')
        
        resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        resp.headers['Pragma'] = 'no-cache'
        resp.headers['Expires'] = '0'
        
        return resp

    return make_response("Formato não suportado", 400)

def run_server():
    global SERVER_THREAD, SERVER_PORT
    with SERVER_LOCK:
        if SERVER_THREAD and SERVER_THREAD.is_alive():
            return
        for port in range(50000, 50021):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('127.0.0.1', port))
                SERVER_PORT = port
                break
            except OSError: continue
        
        if not SERVER_PORT:
            xbmc.log("[PROXY] Sem porta livre.", xbmc.LOGERROR)
            return

        def serve_forever():
            try:
                from werkzeug.serving import run_simple
                run_simple('127.0.0.1', SERVER_PORT, app, use_reloader=False, use_debugger=False, threaded=True)
            except Exception as e:
                xbmc.log(f"[PROXY] Erro: {e}", xbmc.LOGERROR)

        SERVER_THREAD = threading.Thread(target=serve_forever, daemon=True)
        SERVER_THREAD.start()
        xbmc.log(f"[PROXY] Rodando em http://127.0.0.1:{SERVER_PORT}", xbmc.LOGINFO)

def run_addon():
    run_server()
    if not SERVER_PORT:
        xbmcgui.Dialog().ok("Erro", "Falha ao iniciar proxy.")
        return

    action = _ARGS.get('action')
    url = _ARGS.get('url')
    title = _ARGS.get('title')

    if action == 'play' and url:
        local_url = f"http://127.0.0.1:{SERVER_PORT}/stream?url={quote(url)}"
        li = xbmcgui.ListItem(path=local_url)
        li.setInfo('video', {'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False) 
        xbmcplugin.setResolvedUrl(handle=_HANDLE, succeeded=True, listitem=li)
    
    elif action == 'settings':
        ADDON.openSettings()
    else:
        test_title, test_url = "Teste NEXUS V16.10", "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8"
        p_url = f"{sys.argv[0]}?action=play&url={quote(test_url)}&title={quote(test_title)}"
        li = xbmcgui.ListItem(label=test_title)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=p_url, listitem=li, isFolder=False)
        
        li_set = xbmcgui.ListItem(label="Configurações")
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=f"{sys.argv[0]}?action=settings", listitem=li_set, isFolder=False)
        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    try:
        run_addon()
    except Exception as e:
        xbmc.log(f"Erro: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro", str(e))