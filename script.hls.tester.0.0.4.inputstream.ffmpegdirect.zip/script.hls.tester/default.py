import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
import re
import json
from collections import OrderedDict, deque

# --- CONFIGURAÇÕES DE OTIMIZAÇÃO AVANÇADA PARA HARDWARE FRACO/ANTIGO ---
# Reduzir o número de retentativas para evitar sobrecarga excessiva na CPU/rede.
# Foco em falhar mais rápido e tentar uma reconexão completa.
MAX_STICKY_SEGMENT_RETRIES = 0  # Reduzido para 0: não re-tentar o mesmo segmento. Se falhar, tentar o próximo ou reconectar.
MAX_CONSECUTIVE_SEGMENT_FAILURES = 1 # Manter 1 para forçar nova sessão HTTP na primeira falha de segmento, buscando limpeza rápida.

# Reduzir o número de retries para fetcher para evitar sobrecarregar o sistema com tentativas.
# Um número menor significa que a conexão será abandonada mais cedo se houver problemas.
# Alterado de 5 para 1 para forçar o reinício da sessão HTTP na primeira falha de fetch (incluindo manifestos).
FETCHER_MAX_RETRIES = 1
# O fator de backoff ajustado para que 5 tentativas ainda tenham um tempo de espera razoável, mas mais curto no total.
RETRY_BACKOFF_FACTOR = 0.1 # Ajustado para um backoff mais agressivo no início, mas com menos tentativas totais.

# Reduzir os tamanhos máximos dos chunks para downloads.
# Chunks menores podem ser processados com menor pico de uso de memória.
ROTATING_CHUNK_SIZES = [64 * 1024, 128 * 1024, 256 * 1024] # Reduzido o chunk size máximo e a variedade.

# Manter o tempo limite de stream para detecção de manifestos, pois é essencial para a lógica HLS.
MAX_STREAM_LIFETIME_SECONDS = 1  # Mantido para alinhamento com TARGETDURATION do HLS.

# Aumentar um pouco os timeouts para dar mais chance de sucesso em redes lentas
# antes de acionar retries ou reconexões, que são mais custosas para hardware fraco.
# --- OTIMIZAÇÃO: Redução dos timeouts para resposta mais rápida ---
CONNECTION_TIMEOUT = 2.0 # Reduzido para tentar uma conexão mais rápida
STREAM_TIMEOUT = 3.0     # Reduzido para desistir mais rápido de streams lentos
# --- FIM DA OTIMIZAÇÃO ---

# --- OUTRAS CONFIGURAÇÕES ---
SILENT_TS_SEGMENT = bytes([
    0x47, 0x1F, 0xFF, 0x10, 0x00, 0x00, 0xB0, 0x0D, 0x00, 0x01, 0xC1, 0x00,
    0x00, 0x00, 0x01, 0xF0
] + [0xFF] * 179)

LIMIT_COOLDOWN_SECONDS = 7

ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
HANDLE = int(sys.argv[1])

def get_local_ip():
    """
    Obtém o endereço IP local da máquina na rede.
    Retorna '127.0.0.1' em caso de falha.
    """
    try:
        # Cria um socket para descobrir o IP local
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Conecta-se a um endereço IP público (não envia dados)
        s.connect(('10.255.255.255', 1))
        local_ip = s.getsockname()[0]
    except Exception as e:
        # Se falhar, usa o IP de loopback como padrão
        local_ip = '127.00.0.1'
        logging.error(f"Não foi possível obter o IP local, usando {local_ip}. Erro: {e}")
    finally:
        try:
            # Fecha o socket
            s.close()
        except:
            pass
    return local_ip

# Define o host do proxy usando o IP local da máquina
PROXY_HOST = get_local_ip()
MAX_PORT_ATTEMPTS = 10

# Reduzir o tamanho máximo do cache para economizar memória.
max_cache_mb = 148 # Reduzido de 256MB para 128MB.
MAX_CACHE_SIZE_BYTES = max_cache_mb * 1024 * 1024

# Reduzir o tamanho máximo do segmento para evitar alocações de memória muito grandes.
max_segment_size_mb = 10 # Reduzido de 16MB para 8MB.
MAX_SEGMENT_SIZE_BYTES = max_segment_size_mb * 1024 * 1024

SPOOF_X_FORWARDED_FOR = True
ENABLE_IPV6 = False

LOG_MAX_BYTES = 1048576 * 2 # Reduzido o tamanho máximo do arquivo de log para economizar disco e I/O.
LOG_BACKUP_COUNT = 1 # Reduzido o número de arquivos de backup.
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
# --- OTIMIZAÇÃO: Nível de log alterado para WARNING para reduzir I/O ---
LOG_LEVEL = logging.WARNING # Reduzir logs para apenas avisos e erros
# --- FIM DA OTIMIZAÇÃO ---

log_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
)
logging.basicConfig(
    handlers=[log_handler],
    level=LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s'
)

USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, HadKML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "VLC/3.0.20 (Linux; Android 14) (Build/UP1A.231005.007)",
    "okhttp/4.9.0",
]
ACCEPT_LANGUAGES = ["pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "en-US,en;q=0.9,pt;q=0.8"]
PLAYER_HEADERS = [{"User-Agent": ua, "Accept": "*/*", "Accept-Language": random.choice(ACCEPT_LANGUAGES), "Origin": "", "Referer": ""} for ua in USER_AGENTS]
random.shuffle(PLAYER_HEADERS)

_SENSITIVE_HEADERS = ['X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP', 'Content-Length', 'Connection']
_SENSITIVE_HEADERS_LOWER = {s.lower() for s in _SENSITIVE_HEADERS}

def clean_headers(headers):
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def random_player_headers(url):
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.hostname}"
    headers = random.choice(PLAYER_HEADERS).copy()
    headers['Origin'] = origin
    headers['Referer'] = origin
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def jitter(base, percent=0.2):
    return base + base * random.uniform(-percent, percent)

HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({'User-Agent': random.choice(USER_AGENTS), 'Accept': '*/*', 'Connection': 'keep-alive'})
HTTP_SESSION.trust_env = False

def is_ipv6_address(addr):
    try: return isinstance(ipaddress.ip_address(addr), ipaddress.IPv6Address)
    except Exception: return False

def join_host_port(host, port):
    return f'[{host}]:{port}' if is_ipv6_address(host) else f'{host}:{port}'

# --- INÍCIO DA IMPLEMENTAÇÃO DO GERADOR DE IP BRASILEIRO ---
def generate_random_ipv4():
    """
    Gera um endereço de IP aleatório a partir de ranges alocados para o Brasil.
    Isso substitui o gerador de IP genérico.
    """
    # Converte um IP string para um inteiro
    def ip_to_int(ip_str):
        parts = ip_str.split('.')
        return (int(parts[0]) << 24) + (int(parts[1]) << 16) + (int(parts[2]) << 8) + int(parts[3])

    # Converte um inteiro de volta para um IP string
    def int_to_ip(ip_int):
        return ".".join([str((ip_int >> (i * 8)) & 0xFF) for i in range(4)[::-1]])

    # Ranges de IPs públicos alocados para o Brasil (exemplos)
    ranges = [
        ('177.0.0.0', '177.255.255.255'),
        ('179.0.0.0', '179.255.255.255'),
        ('186.192.0.0', '186.255.255.255'),
        ('187.0.0.0', '187.127.255.255'),
        ('189.0.0.0', '189.127.255.255'),
        ('200.96.0.0', '200.255.255.255'),
        ('201.0.0.0', '201.127.255.255'),
    ]

    # Converte os ranges de string para ranges de inteiros
    int_ranges = [(ip_to_int(start), ip_to_int(end)) for start, end in ranges]

    # Escolhe um range aleatório
    chosen_range = random.choice(int_ranges)
    
    # Gera um IP numérico aleatório dentro do range escolhido
    random_ip_int = random.randint(chosen_range[0], chosen_range[1])

    # Converte o IP numérico de volta para string e o retorna
    return int_to_ip(random_ip_int)
# --- FIM DA IMPLEMENTAÇÃO ---


class DoHResolver:
    def __init__(self, resolver_urls=None, cache_ttl=300):
        # Aqui é onde você define os resolvedores. Cloudflare já está presente.
        self.resolver_urls = resolver_urls or ['https://dns.nextdns.io', 'https://cloudflare-dns.com/dns-query']
        self.cache_ttl = cache_ttl
        self._cache = {}
        self.q_types = ['A']
        if ENABLE_IPV6: self.q_types.insert(0, 'AAAA')

    def resolve(self, hostname, depth=0, max_depth=2): # Reduzida a profundidade máxima de recursão para economizar CPU.
        if depth > max_depth: return None
        if self._is_valid_ip(hostname): return hostname
        cached_entry = self._cache.get(hostname)
        if cached_entry and time.time() < cached_entry[1]: return cached_entry[0]
        for resolver_url in self.resolver_urls:
            for q_type in self.q_types:
                # FETCHER_MAX_RETRIES é usado aqui para controlar as tentativas de resolução DNS
                for attempt in range(FETCHER_MAX_RETRIES):
                    try:
                        params = {'name': hostname, 'type': q_type}
                        headers = {'accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                        # !!! SECURITY WARNING: verify=False disables SSL certificate verification.
                        # This should ONLY be used in a controlled environment where you understand
                        # and accept the security risks (e.g., development, testing).
                        # In production, ALWAYS verify SSL certificates.
                        # CONNECTION_TIMEOUT e STREAM_TIMEOUT são usados aqui.
                        response = HTTP_SESSION.get(resolver_url, params=params, headers=headers, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
                        response.raise_for_status()
                        data, ttl = self._parse_doh_response(response.json(), hostname, q_type, depth)
                        if data:
                            self._cache[hostname] = (data, time.time() + ttl)
                            return data
                    except Exception as e:
                        logging.warning(f"[DoHResolver] Tentativa {attempt + 1}/{FETCHER_MAX_RETRIES} falhou para {hostname} ({q_type}) via {resolver_url}: {e}")
                        if attempt < FETCHER_MAX_RETRIES - 1:
                            delay = jitter(RETRY_BACKOFF_FACTOR * (2 ** attempt))
                            time.sleep(delay)
        return None

    def _parse_doh_response(self, data, hostname, q_type, depth):
        type_map = {'A': 1, 'AAAA': 28, 'CNAME': 5}
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map.get(q_type) and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data"), answer.get("TTL", self.cache_ttl)
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map['CNAME'] and answer.get("name", "").lower() == hostname.lower():
                cname = answer.get("data", "").rstrip('.')
                if cname: return self.resolve(cname, depth + 1), answer.get("TTL", self.cache_ttl)
        return None, None

    def clear_cache_for_host(self, hostname_to_clear):
        with threading.Lock():
            if hostname_to_clear in self._cache:
                del self._cache[hostname_to_clear]
                logging.info(f"[RECONEXÃO BRUTA] Cache de DNS limpo para o host: {hostname_to_clear}")

    @staticmethod
    def _is_valid_ip(address):
        try: ipaddress.ip_address(address); return True
        except ValueError: return False

class RotatingChunkCache:
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.chunks = OrderedDict()
        self.total_bytes = 0

    def get(self, url):
        with self.lock:
            data = self.chunks.get(url)
            if data:
                # Move the accessed item to the end to mark it as recently used (LRU)
                self.chunks.move_to_end(url)
            return data

    def add(self, url, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url)) # Remove existing to re-add at end
            
            chunk_size = len(data)
            if chunk_size > self.max_bytes: #
                logging.warning(f"Segmento de {chunk_size / (1024*1024):.2f}MB excede o tamanho máximo do cache de {self.max_bytes / (1024*1024):.2f}MB. Não será adicionado.") #
                return

            self.chunks[url] = data
            self.total_bytes += chunk_size
            
            # Evict least recently used items if cache is over limit
            while self.total_bytes > self.max_bytes and self.chunks:
                # popitem(last=False) removes the first (oldest/LRU) item
                _, old_data = self.chunks.popitem(last=False)
                self.total_bytes -= len(old_data)
                logging.debug(f"Evicting old chunk. Current cache size: {self.total_bytes / (1024*1024):.2f}MB")

    def clear(self):
        with self.lock: self.chunks.clear(); self.total_bytes = 0; logging.info("[RECONEXÃO BRUTA] Cache de segmentos de vídeo limpo.")

class StreamCache:
    def __init__(self, chunk_cache: RotatingChunkCache):
        self.manifest_cache = {}  # {url: {'content': str, 'expires': float, 'last_refresh_time': float}}
        self.chunk_cache = chunk_cache
    def get_manifest(self, url):
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires'] and time.time() - entry['last_refresh_time'] < MAX_STREAM_LIFETIME_SECONDS:
            return entry['content']
        return None
    def add_manifest(self, url, content, ttl=1):
        self.manifest_cache[url] = {
            'content': content,
            'expires': time.time() + ttl,
            'last_refresh_time': time.time()
        }
    def invalidate_manifest(self, url):
        if url in self.manifest_cache:
            del self.manifest_cache[url]
            logging.info(f"[RECONEXÃO BRUTA] Manifesto {url} invalidado do cache.")
    def get_segment(self, url): return self.chunk_cache.get(url)
    def add_segment(self, url, data): self.chunk_cache.add(url, data)
    def clear(self): self.manifest_cache.clear(); self.chunk_cache.clear()
    def is_manifest_expired(self, url):
        entry = self.manifest_cache.get(url)
        return entry and time.time() - entry.get('last_refresh_time', 0) >= MAX_STREAM_LIFETIME_SECONDS

class UpstreamFetcher:
    def __init__(self, session, doh_resolver): self.session = session; self.doh_resolver = doh_resolver
    def fetch(self, url, stream=False, original_headers=None, range_header=None):
        headers = random_player_headers(url)
        if original_headers:
            cleaned_original_headers = clean_headers(original_headers)
            for key in ['Authorization', 'Cookie', 'User-Agent', 'Range', 'Referer', 'Origin']:
                if key in cleaned_original_headers: headers[key] = cleaned_original_headers[key]
        if range_header: headers['Range'] = range_header
        if SPOOF_X_FORWARDED_FOR: headers['X-Forwarded-For'] = generate_random_ipv4()
        parsed_url = urllib.parse.urlparse(url)
        resolved_ip = self.doh_resolver.resolve(parsed_url.hostname) if parsed_url.hostname and not self.doh_resolver._is_valid_ip(parsed_url.hostname) else None
        req_url = url
        if resolved_ip and resolved_ip != parsed_url.hostname:
            port = parsed_url.port
            host_port = join_host_port(resolved_ip, port) if port else resolved_ip
            req_url = f"{parsed_url.scheme}://{host_port}{parsed_url.path or ''}{f'?{parsed_url.query}' if parsed_url.query else ''}"
            headers['Host'] = parsed_url.hostname
        for attempt in range(FETCHER_MAX_RETRIES): # FETCHER_MAX_RETRIES é usado aqui
            try:
                # !!! SECURITY WARNING: verify=False disables SSL certificate verification.
                # This should ONLY be used in a controlled environment where you understand
                # and accept the security risks (e.g., development, testing).
                # In production, ALWAYS verify SSL certificates.
                # CONNECTION_TIMEOUT e STREAM_TIMEOUT são usados aqui.
                resp = self.session.get(req_url, stream=stream, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), headers=headers, allow_redirects=True, verify=False)
                resp.raise_for_status()
                return resp
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError, requests.exceptions.HTTPError) as e: # Qualificado as exceções
                logging.warning(f"[Fetcher] Tentativa {attempt + 1}/{FETCHER_MAX_RETRIES} falhou para {url}: {e}")
                if attempt == FETCHER_MAX_RETRIES - 1: raise e
                delay = jitter(RETRY_BACKOFF_FACTOR * (2 ** attempt)) # RETRY_BACKOFF_FACTOR é usado aqui
                logging.info(f"Aguardando {delay:.2f}s antes de tentar novamente...")
                time.sleep(delay)
        return None

def is_manifest_limit_error(content):
    if not content: return True
    txt = content.lower().strip()
    if not txt: return True
    keywords = ["user", "too many users", "limite", "#limit", "maximum user", "conexoes simultaneas", "many connections", "max session", "total_users", "#error"]
    if any(k in txt for k in keywords): return True
    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    if lines == ["#extm3u"] or len(lines) <= 1: return True
    return False

class ManifestRewriter:
    def __init__(self, content, manifest_url, proxy_base_url):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url); self.proxy_base_url = proxy_base_url
    def rewrite(self):
        items_to_rewrite = getattr(self.m3u8_obj, 'playlists', []) + getattr(self.m3u8_obj, 'media', []) + getattr(self.m3u8_obj, 'segments', [])
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri: item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri: item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()
    @property
    def is_live(self): return not getattr(self.m3u8_obj, 'is_endlist', True)
    def get_ttl(self):
        target_duration = getattr(self.m3u8_obj, 'target_duration', 0)
        # Set TTL to 10 seconds for live streams to align with 17-second TARGETDURATION for 7 segments
        return max(1, int(target_duration * 0.6)) if self.is_live and target_duration else 10 #
    
    def get_segment_uris(self):
        """Returns a list of absolute URIs for all segments in the manifest."""
        return [seg.absolute_uri for seg in self.m3u8_obj.segments if seg.absolute_uri]

def notify(msg, time_ms=3000): xbmc.executebuiltin(f'Notification({ADDON_NAME},{msg},{time_ms})')

def safe_mime_type(url, fallback='application/octet-stream'):
    ext = url.lower().split('?')[0]
    if ext.endswith('.m3u8') or ext.endswith('.m3u'): return 'application/vnd.apple.mpegurl'
    if ext.endswith('.ts'): return 'video/mp2t'
    if ext.endswith('.aac'): return 'audio/aac'
    if ext.endswith('.mp4'): return 'video/mp4'
    return fallback

# Global queue for pre-loading segments
PRELOAD_QUEUE = deque()
PRELOAD_QUEUE_LOCK = threading.Lock()
PRELOAD_STOP_EVENT = threading.Event()
# --- OTIMIZAÇÃO: Aumentado o número de segmentos para pré-carregamento ---
NUM_SEGMENTS_TO_PRELOAD = 1 # Configurar quantos segmentos pré-carregar
# --- FIM DA OTIMIZAÇÃO ---

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, stream_cache, fetcher, proxy_manager, *args, **kwargs):
        self.cache = stream_cache; self.fetcher = fetcher; self.proxy_manager = proxy_manager
        self.global_consecutive_segment_failures = 0
        self.current_problem_segment_url = None; self.current_problem_segment_retries = 0
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args): pass
    def _log_request(self, message, level='info'): getattr(logging, level)(f"[{self.address_string()}] {self.command} {self.path} - {message}")

    def do_GET(self):
        original_url = "unknown"
        try:
            query_params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            original_url = query_params.get('url', [''])[0]
            if not original_url: return self.send_error(400, "Missing 'url' parameter")
            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower(): self._handle_manifest(original_url)
            else: self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError): self._log_request(f"Client disconnected for {original_url}", level='info')
        except Exception as ex:
            logging.error("General proxy error for %s: %s", original_url, str(ex), exc_info=True)
            try: self.send_error(500, "Internal Server Error")
            except Exception: pass

    def _handle_manifest(self, url):
        self._log_request(f"Handling manifest: {url}", level='info')
        last_limit_hit = self.proxy_manager.get_limit_hit_time(url)
        if last_limit_hit and (time.time() - last_limit_hit < LIMIT_COOLDOWN_SECONDS):
            remaining = int(LIMIT_COOLDOWN_SECONDS - (time.time() - last_limit_hit))
            self._log_request(f"Manifest limit hit recently. Waiting for {remaining}s before retrying for {url}.", level='warning')
            return self._send_response(200, b"#EXTM3U\n", 'application/vnd.apple.mpegurl')

        # Check if manifest is expired due to MAX_STREAM_LIFETIME_SECONDS limit
        if self.cache.is_manifest_expired(url):
            self._log_request(f"Manifest expired (>{MAX_STREAM_LIFETIME_SECONDS}s). Forcing reconnection for {url}", level='info')
            self.proxy_manager.force_reconnection(url)

        cached = self.cache.get_manifest(url)
        if cached and not is_manifest_limit_error(cached):
            return self._send_response(200, cached.encode('utf-8'), 'application/vnd.apple.mpegurl')

        response = None
        try:
            response = self.fetcher.fetch(url, original_headers=self.headers)
            content = response.text
            
            # --- START: Change for "restart session for any failure status" ---
            if is_manifest_limit_error(content):
                self._log_request(f"Manifest indica erro de limite de usuários ou conteúdo inesperado para {url}. Forçando reconexão.", level="warning")
                self.proxy_manager.record_limit_hit(url)
                self.proxy_manager.force_reconnection(url) # Force reconnection immediately
                return self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl") # Send empty manifest and let player re-request
            
            rewriter = ManifestRewriter(content, response.url, f"http://{join_host_port(self.server.server_address[0], self.server.server_address[1])}/?url=")
            rewritten_content = rewriter.rewrite(); ttl = rewriter.get_ttl()
            self.cache.add_manifest(url, rewritten_content, ttl=ttl)
            self.proxy_manager.clear_limit_hit(url)
            self._send_response(200, rewritten_content.encode('utf-8'), 'application/vnd.apple.mpegurl')

            # Trigger pre-loading after successfully processing the manifest
            self._trigger_segment_preloading(rewriter.get_segment_uris()) #

        except Exception as e:
            logging.error(f"Error fetching or processing manifest {url}: {e}", exc_info=False)
            self.proxy_manager.force_reconnection(url) # Force reconnection on any exception (Timeout, ConnectionError, HTTPError, etc.)
            self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl") # Send empty manifest on error
        finally:
            if response: response.close()
            # --- END: Change for "restart session for any failure status" ---

    def _handle_segment(self, url):
        mime_type = safe_mime_type(url)
        # Check if manifest is expired for the segment's parent manifest
        manifest_url = self._find_manifest_url_from_segment(url)
        if manifest_url and self.cache.is_manifest_expired(manifest_url):
            self._log_request(f"Manifest for segment {url} expired (>{MAX_STREAM_LIFETIME_SECONDS}s). Forcing reconnection.", level='info')
            self.proxy_manager.force_reconnection(manifest_url)
        cached_segment = self.cache.get_segment(url)
        if cached_segment:
            self.global_consecutive_segment_failures = 0; self.current_problem_segment_url = None
            return self._send_response(200, cached_segment, mime_type)

        if self.current_problem_segment_url != url:
            self.current_problem_segment_url = url; self.current_problem_segment_retries = 0

        # MAX_STICKY_SEGMENT_RETRIES + 1 tentativas (0 + 1 = 1 tentativa no total)
        for attempt in range(MAX_STICKY_SEGMENT_RETRIES + 1):
            self.current_problem_segment_retries += 1
            self._log_request(f"[RECONEXÃO] Tentativa Pegajosa {attempt + 1}/{MAX_STICKY_SEGMENT_RETRIES + 1} para segmento {url}", level='info')
            response = None
            try:
                response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
                current_chunk_size = random.choice(ROTATING_CHUNK_SIZES)
                self._log_request(f"Baixando com chunksize rotativo: {current_chunk_size // 1024}KB", level='debug')
                segment_data = bytearray()
                for chunk in response.iter_content(chunk_size=current_chunk_size):
                    if chunk: segment_data.extend(chunk)
                    if len(segment_data) > MAX_SEGMENT_SIZE_BYTES:
                        raise IOError(f"Segmento excedeu o tamanho máximo de {MAX_SEGMENT_SIZE_BYTES // (1024*1024)}MB.")
                final_data = bytes(segment_data)
                self.cache.add_segment(url, final_data)
                self.global_consecutive_segment_failures = 0
                self._send_response(200, final_data, mime_type)
                return
            except Exception as e:
                logging.warning(f"[RECONEXÃO] Falha na tentativa {self.current_problem_segment_retries} para {url}: {e}")
                if response: response.close()
                if attempt < MAX_STICKY_SEGMENT_RETRIES:
                    delay = jitter(RETRY_BACKOFF_FACTOR * (2 ** attempt))
                    time.sleep(delay)

        self._log_request(f"Segmento {url} falhou após {MAX_STICKY_SEGMENT_RETRIES + 1} tentativas. Acionando falha global.", level='error')
        self.global_consecutive_segment_failures += 1
        self._send_response(200, SILENT_TS_SEGMENT, mime_type)
        
        if self.global_consecutive_segment_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES:
            logging.error(f"[RECONEXÃO BRUTA TOTAL] Limite de falhas ({MAX_CONSECUTIVE_SEGMENT_FAILURES}) atingido. Forçando nova sessão HTTP para o link.")
            
            hostname = urllib.parse.urlparse(url).hostname
            if hostname: self.proxy_manager.clear_doh_cache(hostname)

            if manifest_url: self.proxy_manager.invalidate_manifest_cache(manifest_url)
            
            self.proxy_manager.clear_chunk_cache()
            
            self.proxy_manager.reset_http_session()
            
            self.global_consecutive_segment_failures = 0
        
        self.current_problem_segment_url = None

    def _find_manifest_url_from_segment(self, segment_url):
        # This function tries to deduce a parent manifest URL from a segment URL.
        # This is an approximation and might not always be accurate for all HLS structures.
        # A more robust solution might involve tracking which manifest pointed to which segment.
        try:
            # For simplicity, assume segments are typically in the same directory as the manifest
            # or a subdirectory. We try to find the base URL that might contain the manifest.
            parts = urllib.parse.urlparse(segment_url)
            path_segments = parts.path.split('/')
            
            # Heuristic: go up one or two levels to find a common manifest location
            # This is a simplification. A real HLS player would know the manifest URL.
            # For this proxy, we're guessing based on segment URL.
            
            # Option 1: The segment is directly in the manifest directory
            candidate_url_1 = f"{parts.scheme}://{parts.netloc}/{'/'.join(path_segments[:-1])}/"
            if candidate_url_1.endswith('//'): candidate_url_1 = candidate_url_1[:-1] # Remove double slash
            
            # Option 2: The segment is in a subdirectory of the manifest directory
            if len(path_segments) > 2:
                candidate_url_2 = f"{parts.scheme}://{parts.netloc}/{'/'.join(path_segments[:-2])}/"
                if candidate_url_2.endswith('//'): candidate_url_2 = candidate_url_2[:-1]
                
                # Check manifest cache for these candidates.
                # This is still a guess. Without explicit manifest-segment mapping, it's hard.
                # For now, let's just return the directory of the segment.
                # In many cases, the segment's manifest is its base URI.
                return f"{parts.scheme}://{parts.netloc}/{'/'.join(path_segments[:-1])}/"
            
            return f"{parts.scheme}://{parts.netloc}/{'/'.join(path_segments[:-1])}/"

        except Exception as e:
            logging.warning(f"Could not deduce manifest URL from segment {segment_url}: {e}")
            return None

    def _send_response(self, code, content, content_type):
        try:
            self.send_response(code); self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0')
            self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers(); self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError): self._log_request(f"Client disconnected.", level='info')
        except Exception as ex: logging.error("Error sending response: %s", str(ex), exc_info=True)

    def _trigger_segment_preloading(self, segment_uris): #
        """Adds segment URIs to the global pre-load queue.""" #
        with PRELOAD_QUEUE_LOCK: #
            # Clear existing preload queue to prioritize segments from the new manifest
            PRELOAD_QUEUE.clear() #
            for i, uri in enumerate(segment_uris): #
                if i < NUM_SEGMENTS_TO_PRELOAD: # Only add the first N segments for pre-loading
                    if not self.cache.get_segment(uri): # Only queue if not already in cache
                        PRELOAD_QUEUE.append(uri) #
                        logging.info(f"Adicionado segmento para pré-carregamento: {uri}") #
                else: #
                    break #

def _preload_worker(fetcher: UpstreamFetcher, cache: StreamCache): #
    """Worker thread to fetch segments from the PRELOAD_QUEUE.""" #
    while not PRELOAD_STOP_EVENT.is_set(): #
        segment_url = None #
        with PRELOAD_QUEUE_LOCK: #
            if PRELOAD_QUEUE: #
                segment_url = PRELOAD_QUEUE.popleft() # Get the next segment to pre-load

        if segment_url: #
            if cache.get_segment(segment_url): #
                logging.debug(f"Segmento {segment_url} já em cache. Pulando pré-carregamento.") #
                continue #

            logging.info(f"Pré-carregando segmento: {segment_url}") #
            try: #
                response = fetcher.fetch(segment_url, stream=True) #
                segment_data = bytearray() #
                for chunk in response.iter_content(chunk_size=random.choice(ROTATING_CHUNK_SIZES)): #
                    if chunk: segment_data.extend(chunk) #
                    if len(segment_data) > MAX_SEGMENT_SIZE_BYTES: #
                        logging.warning(f"Segmento pré-carregado excedeu o tamanho máximo de {MAX_SEGMENT_SIZE_BYTES // (1024*1024)}MB. Abortando.") #
                        break # Stop reading this segment
                else: # Only if loop completed without break
                    cache.add_segment(segment_url, bytes(segment_data)) #
                    logging.info(f"Segmento pré-carregado com sucesso: {segment_url}") #
            except Exception as e: #
                logging.warning(f"Falha ao pré-carregar segmento {segment_url}: {e}") #
            finally: #
                if 'response' in locals() and response: #
                    response.close() #
        else: #
            time.sleep(0.5) # Wait if queue is empty

class HLSProxyManager:
    def __init__(self):
        self.server = None; self.server_thread = None; self.active_port = None
        # DoHResolver usa 'https://cloudflare-dns.com/dns-query' por padrão se resolver_urls for None
        self.doh_resolver = DoHResolver() 
        self.chunk_cache = RotatingChunkCache(MAX_CACHE_SIZE_BYTES)
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(HTTP_SESSION, self.doh_resolver)
        self.recent_limit_failures = {}
        self.preload_worker_thread = None #
    
    def reset_http_session(self):
        """Fecha a sessão HTTP atual e cria uma nova para garantir novas conexões."""
        global HTTP_SESSION
        try:
            HTTP_SESSION.close()
        except Exception as e:
            logging.warning(f"Erro ao fechar sessão HTTP existente: {e}")
            
        HTTP_SESSION = requests.Session()
        HTTP_SESSION.headers.update({'User-Agent': random.choice(USER_AGENTS), 'Accept': '*/*', 'Connection': 'keep-alive'})
        HTTP_SESSION.trust_env = False
        
        self.fetcher.session = HTTP_SESSION
        logging.info("[RECONEXÃO BRUTA] Sessão HTTP recriada.")

    def record_limit_hit(self, url): self.recent_limit_failures[url] = time.time()
    def get_limit_hit_time(self, url): return self.recent_limit_failures.get(url)
    def clear_limit_hit(self, url):
        if url in self.recent_limit_failures: del self.recent_limit_failures[url]
    def invalidate_manifest_cache(self, manifest_url):
        self.stream_cache.invalidate_manifest(manifest_url)
    def clear_doh_cache(self, hostname):
        self.doh_resolver.clear_cache_for_host(hostname)
    def clear_chunk_cache(self):
        self.stream_cache.clear()
        
    def force_reconnection(self, url):
        """
        Executa uma reconexão forçada limpando caches e reiniciando a sessão HTTP.
        """
        parsed_url = urllib.parse.urlparse(url)
        hostname = parsed_url.hostname
        
        if hostname:
            self.clear_doh_cache(hostname)
            
        manifest_url = url if (".m3u8" in url.lower() or ".m3u" in url.lower()) else self._find_manifest_url_from_segment(url)
        if manifest_url:
            self.invalidate_manifest_cache(manifest_url)
            
        self.clear_chunk_cache()
        self.reset_http_session()
        
        logging.info(f"[FORCED RECONNECTION] Forced reconnection triggered for {url}.")
        
        # Clear pre-load queue on forced reconnection as segments might be invalid
        with PRELOAD_QUEUE_LOCK: #
            PRELOAD_QUEUE.clear() #
            logging.info("[FORCED RECONNECTION] Pre-load queue cleared.") #


    def _find_manifest_url_from_segment(self, segment_url):
        # This function tries to deduce a parent manifest URL from a segment URL.
        # This is an approximation and might not always be accurate for all HLS structures.
        try:
            parts = urllib.parse.urlparse(segment_url)
            path_segments = parts.path.split('/')
            return f"{parts.scheme}://{parts.netloc}/{'/'.join(path_segments[:-1])}/"
        except Exception:
            return None
    
    def start(self):
        self.stop()
        handler_with_deps = functools.partial(HLSProxyHandler, self.stream_cache, self.fetcher, self)
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), handler_with_deps)
                self.server.allow_reuse_address = True; self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy Avançado iniciado em {PROXY_HOST}:{self.active_port}.")

                # Start pre-load worker thread
                PRELOAD_STOP_EVENT.clear() #
                self.preload_worker_thread = threading.Thread(target=_preload_worker, args=(self.fetcher, self.stream_cache), daemon=True) #
                self.preload_worker_thread.start() #
                logging.info("Pre-load worker thread started.") #

                return self.active_port
            except Exception as ex: logging.warning(f"Falha ao iniciar proxy na porta {port}: {ex}. Tentativa {attempt + 1}.")
        logging.error("Falha ao iniciar HLS Proxy após todas as tentativas."); notify("Erro: Não foi possível iniciar o proxy HLS.", 5000)
        return None
    
    def stop(self):
        if self.server:
            logging.info(f"Parando HLS Proxy na porta {self.active_port}")
            self.server.shutdown(); self.server.server_close(); self.server = None
        if self.server_thread and self.server_thread.is_alive(): self.server_thread.join(timeout=2)
        
        # Signal and wait for pre-load worker to stop
        PRELOAD_STOP_EVENT.set() #
        if self.preload_worker_thread and self.preload_worker_thread.is_alive(): #
            self.preload_worker_thread.join(timeout=2) #
            logging.info("Pre-load worker thread stopped.") #

        self.stream_cache.clear(); self.active_port = None; logging.info("Proxy parado e recursos liberados.")
        self.reset_http_session()
        
    def get_proxy_url(self, original_url):
        if not self.active_port: return None
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/?url={urllib.parse.quote_plus(original_url)}"

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event): super().__init__(); self.stop_event = stop_event
    def onPlayBackEnded(self): self.stop_event.set(); logging.info("Playback ended.")
    def onPlayBackError(self): self.stop_event.set(); logging.error("Playback error.")
    def onPlayBackStopped(self): self.stop_event.set(); logging.info("Playback stopped.")

class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager(); self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)
    
    def convert_to_m3u8(self, url):
        if '|' in url:
            url = url.split('|')[0]
        elif '%7C' in url:
            url = url.split('%7C')[0]
        if not re.search(r'\.(m3u8|m3u)$', url, re.IGNORECASE) and not '/hl' in url and url.count('/') > 4 and not re.search(r'\.(mp4|avi)$', url, re.IGNORECASE):
            parsed_url = urllib.parse.urlparse(url)
            try:
                host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
                host_part2 = url.split(host_part1)[1]
                if '/live' not in host_part2:
                    if host_part2.startswith('/'):
                        url = host_part1 + '/live' + host_part2
                    else:
                        url = host_part1 + '/live/' + host_part2
                
                file = os.path.basename(url)
                if '.ts' in file:
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                elif not re.search(r'\.(m3u8|m3u)$', url, re.IGNORECASE):
                    url = url + '.m3u8'
            except Exception as e:
                logging.warning(f"Erro na conversão para m3u8: {e}")
                pass

        return url

    def play_stream(self, url, channel_name=None):
        logging.info(f"Tentando tocar stream com o player padrão: {url}")
        processed_url = self.convert_to_m3u8(url)
        port = self.proxy_manager.start()
        if not port: return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url: return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        
        display_label = f"{channel_name or 'Stream'} [COLOR cyan](HLS TESTER)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_label)
        list_item.setProperty('IsPlayable', 'true')
        
        # --- Configurações para inputstream.ffmpegdirect ---
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('mimetype', 'application/x-mpegURL') # MIME type for HLS manifests
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift') # Changed to timeshift
        list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setProperty('inputstream.ffmpegdirect.default_url', proxy_url) 
        list_item.setProperty('inputstream.ffmpegdirect.playback_as_live', 'true')
        
        # --- Fim das configurações para inputstream.ffmpegdirect ---
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        logging.info(f"Kodi resolvido para URL do proxy (HLS TESTER) com inputstream.ffmpegdirect: {proxy_url}")
        
        threading.Thread(target=self.monitor_playback, daemon=True).start()

    def monitor_playback(self):
        logging.info("Monitoramento de playback iniciado...")
        self.playback_stop_event.wait()
        logging.info("Evento de parada de playback recebido. Liberando recursos do proxy.")
        self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Live Exemplo (Caminho da Web)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Big Buck Bunny (VOD)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
        ]
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=f"{name} [COLOR cyan](Player Padrão)[/COLOR]")
            li.setProperty('IsPlayable', 'true'); li.setMimeType(safe_mime_type(url))
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action'); url_to_play = params.get('url'); channel_title = params.get('title')
    
    addon = HLSProxyAddon()
    if action == 'play' and url_to_play:
        addon.play_stream(url_to_play, channel_title)
    else:
        addon.show_test_streams()