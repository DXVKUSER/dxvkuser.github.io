import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
import re
import queue
from collections import OrderedDict
from typing import Optional, Dict, Any, List, Tuple, Type, Union

# ==============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO ---
# ==============================================================================

# --- Estratégia de Reconexão e Falha ---
# OBJETIVO: Mais resiliência e reconexão imediata na primeira falha de segmento.
MAX_STICKY_SEGMENT_RETRIES = 1
MAX_CONSECUTIVE_SEGMENT_FAILURES = 1   # Reconectar na primeira falha de segmento

# --- Configurações do Fetcher (Requisições HTTP) ---
FETCHER_MAX_RETRIES = 4   # Permite mais retentativas ao baixar segmentos
RETRY_BACKOFF_FACTOR = 0.15   # Menor para respostas rápidas e jitter menor
CONNECTION_TIMEOUT = 8.0      # Tempo limite levemente reduzido
STREAM_TIMEOUT = 8.0

# --- Otimização de Rede e Memória ---
DEFAULT_CHUNK_SIZE = 512 * 1024 # Chunks menores para melhor controle de memória
MAX_STREAM_LIFETIME_SECONDS = 6  # Aumentado para menos reconexões desnecessárias
MAX_CACHE_MB = 192               # Mais cache para menos redownloads em conexões ruins
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_MB = 12         # Aceita segmentos maiores, útil para streams com VBR alto
MAX_SEGMENT_SIZE_BYTES = MAX_SEGMENT_SIZE_MB * 1024 * 1024

# --- Configurações de Pré-busca (Pre-fetching) ---
PREFETCH_SEGMENTS_COUNT = 3      # Reativado para pré-buscar segmentos como VOD
PREFETCH_INTERVAL_SECONDS = 0.5  # Intervalo para verificar e pré-buscar

# --- Configurações do Proxy e Addon ---
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 10
LIMIT_COOLDOWN_SECONDS = 20      # Mais tempo para cooldown em bloqueios

# --- Configurações de Spoofing e Rede ---
SPOOF_X_FORWARDED_FOR = True
FIXED_X_FORWARDED_FOR_IP = "1.1.1.1"
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
]

# --- Configuração de Logging ---
LOG_MAX_BYTES = 1048576 * 2  # 2MB
LOG_BACKUP_COUNT = 2
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
LOG_LEVEL = logging.INFO

# --- Constantes ---
_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}

# ==============================================================================
# --- INICIALIZAÇÃO DO LOGGING ---
# ==============================================================================

def setup_logging():
    """Configura o logger para registrar em um arquivo rotativo."""
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

setup_logging()

# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================

def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def join_host_port(host: str, port: int) -> str:
    return f'[{host}]:{port}' if ':' in host and is_valid_ip(host) else f'{host}:{port}'

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str, range_header: Optional[str] = None) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    user_agent = random.choice(USER_AGENTS)
    headers = {
        "User-Agent": user_agent,
        "Accept": "application/vnd.apple.mpegurl,video/mp2t,audio/aac,video/mp4",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin,
    }
    if range_header:
        headers["Range"] = range_header
    if SPOOF_X_FORWARDED_FOR:
        headers["X-Forwarded-For"] = FIXED_X_FORWARDED_FOR_IP
    return headers

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith('.m3u8') or path.endswith('.m3u'):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
                "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid"]
    return any(keyword in txt for keyword in keywords)

# ==============================================================================
# --- RESOLUTOR DE DNS (CUSTOMIZADO PARA CLOUDFLARE DOH) ---
# ==============================================================================

class DoHDNSResolver:
    def __init__(self, cache_ttl: int = 600, doh_url: str = 'https://dns.nextdns.io/629e1b'):
        self._cache: Dict[str, Tuple[str, float]] = {}
        self._lock = threading.Lock()
        self.cache_ttl = cache_ttl
        self.doh_url = doh_url
        self.session = requests.Session()

    def _query_doh(self, hostname: str) -> Optional[str]:
        headers = {"Accept": "application/dns-json"}
        params = {"name": hostname, "type": "A"}
        try:
            response = self.session.get(self.doh_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            if data and 'Answer' in data:
                for answer in data['Answer']:
                    if answer['type'] == 1:
                        logging.debug(f"[DoHDNSResolver] DoH resolveu {hostname} para {answer['data']}")
                        return answer['data']
            logging.warning(f"[DoHDNSResolver] Nenhuma resposta IP válida de DoH para {hostname}.")
            return None
        except Exception as e:
            logging.warning(f"[DoHDNSResolver] Erro ao consultar DoH para {hostname}: {e}")
            return None

    def resolve(self, hostname: str) -> Optional[str]:
        if is_valid_ip(hostname):
            return hostname
        with self._lock:
            cached_entry = self._cache.get(hostname)
            if cached_entry and time.time() < cached_entry[1]:
                return cached_entry[0]
        ip = self._query_doh(hostname)
        if ip:
            self._add_to_cache(hostname, ip, self.cache_ttl)
            return ip
        else:
            return None

    def _add_to_cache(self, hostname: str, ip: str, ttl: int):
        with self._lock:
            self._cache[hostname] = (ip, time.time() + ttl)

    def clear_cache_for_host(self, hostname: str):
        with self._lock:
            if hostname in self._cache:
                del self._cache[hostname]

    def clear_cache(self):
        with self._lock:
            self._cache.clear()

# ==============================================================================
# --- CACHE DE DADOS ---
# ==============================================================================

class RotatingChunkCache:
    def __init__(self_obj, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self_obj.max_bytes = max_bytes
        self_obj.lock = threading.Lock()
        self_obj.chunks: OrderedDict[str, bytes] = OrderedDict()
        self_obj.total_bytes = 0

    def get(self_obj, url: str) -> Optional[bytes]:
        with self_obj.lock:
            data = self_obj.chunks.get(url)
            if data:
                self_obj.chunks.move_to_end(url)
            return data

    def add(self_obj, url: str, data: bytes):
        with self_obj.lock:
            if url in self_obj.chunks:
                self_obj.total_bytes -= len(self_obj.chunks.pop(url))
            chunk_size = len(data)
            if chunk_size > self_obj.max_bytes:
                logging.debug(f"[RotatingChunkCache] Segmento {url} muito grande para o cache, ignorando.")
                return
            self_obj.chunks[url] = data
            self_obj.total_bytes += chunk_size
            while self_obj.total_bytes > self_obj.max_bytes:
                _, old_data = self_obj.chunks.popitem(last=False)
                self_obj.total_bytes -= len(old_data)
                logging.debug(f"[RotatingChunkCache] Esvaziando cache. Tamanho atual: {self_obj.total_bytes / (1024*1024):.2f} MB")


    def clear(self_obj):
        with self_obj.lock:
            self_obj.chunks.clear()
            self_obj.total_bytes = 0
            logging.debug("[RotatingChunkCache] Cache de chunks limpo.")

    def has(self_obj, url: str) -> bool:
        with self_obj.lock:
            return url in self_obj.chunks

class StreamCache:
    def __init__(self_obj, chunk_cache: RotatingChunkCache):
        self_obj.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self_obj.chunk_cache = chunk_cache
        self_obj.lock = threading.Lock()

    def get_manifest(self_obj, url: str) -> Optional[str]:
        with self_obj.lock:
            entry = self_obj.manifest_cache.get(url)
            if entry and time.time() < entry['expires']:
                logging.debug(f"[StreamCache] Manifesto de {url} encontrado no cache e válido.")
                return entry['content']
            logging.debug(f"[StreamCache] Manifesto de {url} não encontrado ou expirado.")
            return None

    def add_manifest(self_obj, url: str, content: str, ttl: int):
        with self_obj.lock:
            self_obj.manifest_cache[url] = {
                'content': content,
                'expires': time.time() + ttl,
                'last_refresh_time': time.time()
            }
            logging.debug(f"[StreamCache] Manifesto de {url} adicionado ao cache com TTL de {ttl}s.")


    def invalidate_manifest(self_obj, url: str):
        with self_obj.lock:
            if url in self_obj.manifest_cache:
                del self_obj.manifest_cache[url]
                logging.debug(f"[StreamCache] Manifesto de {url} invalidado.")

    def is_manifest_expired(self_obj, url: str) -> bool:
        with self_obj.lock:
            entry = self_obj.manifest_cache.get(url)
            # Para streams "VOD-like" (incluindo IPTV que pode mudar), sempre verificar refresh
            is_expired = not entry or (time.time() - entry.get('last_refresh_time', 0) >= MAX_STREAM_LIFETIME_SECONDS)
            if is_expired:
                logging.debug(f"[StreamCache] Manifesto de {url} considerado expirado para refresh.")
            return is_expired

    def get_segment(self_obj, url: str) -> Optional[bytes]:
        data = self_obj.chunk_cache.get(url)
        if data:
            logging.debug(f"[StreamCache] Segmento {url} encontrado no cache.")
        else:
            logging.debug(f"[StreamCache] Segmento {url} não encontrado no cache.")
        return data

    def add_segment(self_obj, url: str, data: bytes):
        self_obj.chunk_cache.add(url, data)
        logging.debug(f"[StreamCache] Segmento {url} adicionado ao cache.")

    def has_segment(self_obj, url: str) -> bool:
        return self_obj.chunk_cache.has(url)

    def clear(self_obj):
        with self_obj.lock:
            self_obj.manifest_cache.clear()
            logging.debug("[StreamCache] Cache de manifestos limpo.")
        self_obj.chunk_cache.clear()

# ==============================================================================
# --- FETCHER E REWRITER ---
# ==============================================================================

class UpstreamFetcher:
    def __init__(self, session: requests.Session, dns_resolver: 'DoHDNSResolver'):
        self.session = session
        self.dns_resolver = dns_resolver

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        headers = get_player_headers(url)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie']})
        if SPOOF_X_FORWARDED_FOR:
            headers['X-Forwarded-For'] = FIXED_X_FORWARDED_FOR_IP
        parsed_url = urllib.parse.urlparse(url)
        hostname = parsed_url.hostname
        resolved_ip = self.dns_resolver.resolve(hostname) if hostname else None
        req_url = url
        if resolved_ip and resolved_ip != hostname:
            req_url_parts = list(parsed_url)
            req_url_parts[1] = join_host_port(resolved_ip, parsed_url.port) if parsed_url.port else resolved_ip
            req_url = urllib.parse.urlunparse(req_url_parts)
            headers['Host'] = hostname

        logging.debug(f"[UpstreamFetcher] Tentando buscar URL: {req_url} (Original: {url}) com headers: {headers}")

        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    req_url, stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                logging.debug(f"[UpstreamFetcher] Busca bem-sucedida para {url} (Tentativa {attempt + 1})")
                return resp
            except requests.RequestException as e:
                logging.warning(f"[UpstreamFetcher] Erro ao buscar {url} (Tentativa {attempt + 1}/{FETCHER_MAX_RETRIES + 1}): {e}")
                if attempt < FETCHER_MAX_RETRIES:
                    sleep_time = RETRY_BACKOFF_FACTOR * (2 ** attempt) + random.uniform(0, 0.12)
                    logging.debug(f"[UpstreamFetcher] Reintentando em {sleep_time:.2f} segundos...")
                    time.sleep(sleep_time)
                else:
                    raise

class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        self.original_manifest_url = manifest_url
        # Determinar se é um stream ao vivo. Se não houver EXT-X-ENDLIST, é considerado live.
        self._is_live = not getattr(self.m3u8_obj, 'is_endlist', False)
        logging.debug(f"[ManifestRewriter] Manifesto carregado. É live: {self._is_live}")

    def rewrite(self) -> str:
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                original_uri = item.uri
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
                logging.debug(f"[ManifestRewriter] Reescrevendo URI: {original_uri} -> {item.uri}")
            if hasattr(item, 'key') and item.key and item.key.uri:
                if not item.key.uri.startswith("data:"):
                    original_key_uri = item.key.uri
                    item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
                    logging.debug(f"[ManifestRewriter] Reescrevendo Key URI: {original_key_uri} -> {item.key.uri}")
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return self._is_live

    def get_ttl(self) -> int:
        if self.is_live:
            # Para streams ao vivo, o TTL deve ser curto para forçar atualizações frequentes
            # Um pouco mais do que a duração do segmento alvo, mas não muito.
            target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
            ttl = int(target_duration * 1.5) # Ex: se target_duration for 10s, TTL será 15s
            return max(ttl, 5) # Mínimo de 5 segundos
        return 3600 # Para VOD, 1 hora é razoável.

    def get_segments(self) -> List[str]:
        """Retorna uma lista de URIs absolutas de segmentos."""
        segments = []
        for segment in self.m3u8_obj.segments:
            segments.append(segment.absolute_uri)
        return segments

# ==============================================================================
# --- PROXY HTTP ---
# ==============================================================================

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, request: bytes, client_address: Tuple[str, int], server: socketserver.BaseServer,
                 stream_cache: 'StreamCache', fetcher: 'UpstreamFetcher', proxy_manager: 'HLSProxyManager'):
        self.stream_cache = stream_cache
        self.fetcher = fetcher
        self.proxy_manager = proxy_manager
        super().__init__(request, client_address, server)

    def log_message(self, format: str, *args: Any):
        # logging.debug(f"[HLSProxyHandler] {format % args}") # Habilitar para debug verbose
        pass

    def _send_response(self, status_code: int, content: bytes, content_type: str, additional_headers: Optional[Dict] = None):
        try:
            self.send_response(status_code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            if content:
                etag = f'"{hashlib.md5(content).hexdigest()}"'
                self.send_header('ETag', etag)
            self.send_header('Last-Modified', time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime()))
            self.send_header('Accept-Ranges', 'bytes')
            if content_type in ['video/mp2t', 'application/vnd.apple.mpegurl']:
                self.send_header('Content-Protection', 'cenc') # Pode ser útil para alguns players
            if additional_headers:
                for key, value in additional_headers.items():
                    self.send_header(key, value)
            self.end_headers()
            if content:
                self.wfile.write(content)
            self.wfile.flush()
            logging.debug(f"[{self.client_address[0]}:{self.client_address[1]}] Resposta enviada: {status_code} {content_type}")
        except BrokenPipeError:
            logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] BrokenPipeError ao enviar resposta.")
        except ConnectionResetError:
            logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] ConnectionResetError ao enviar resposta.")
        except Exception as e:
            logging.error(f"[{self.client_address[0]}:{self.client_address[1]}] Erro ao enviar resposta: {e}", exc_info=True)


    def do_GET(self):
        try:
            query_params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            original_url = query_params.get('url', [''])[0]
            if not original_url:
                logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] Requisição com parâmetro 'url' ausente: {self.path}")
                return self.send_error(400, "Parâmetro 'url' ausente")
            
            logging.info(f"[{self.client_address[0]}:{self.client_address[1]}] Recebida requisição para: {original_url}")

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] Conexão fechada pelo cliente durante GET.")
            pass # Cliente fechou a conexão, não há o que fazer
        except Exception as e:
            logging.error(f"[{self.client_address[0]}:{self.client_address[1]}] Erro inesperado no do_GET para {self.path}: {e}", exc_info=True)
            if not self.wfile.closed:
                self.send_error(500, "Erro interno do servidor")

    def _handle_manifest(self, url: str):
        if self.proxy_manager.is_in_cooldown(url):
            logging.warning(f"[HLSProxyHandler] Manifesto {url} em cooldown. Retornando manifesto vazio.")
            # Retorna um manifesto vazio para indicar temporariamente que não há stream
            return self._send_response(200, b"#EXTM3U\n", 'application/vnd.apple.mpegurl')

        # Forçar reconexão bruta se o manifesto estiver expirado
        if self.stream_cache.is_manifest_expired(url):
            logging.info(f"[HLSProxyHandler] Manifesto {url} expirado ou precisa de refresh. Forçando reconexão.")
            self.proxy_manager.force_reconnection(url)

        cached_content = self.stream_cache.get_manifest(url)
        if cached_content:
            logging.info(f"[HLSProxyHandler] Servindo manifesto {url} do cache.")
            return self._send_response(200, cached_content.encode('utf-8'), 'application/vnd.apple.mpegurl')

        try:
            logging.info(f"[HLSProxyHandler] Buscando manifesto original: {url}")
            response = self.fetcher.fetch(url, original_headers=self.headers)
            content = response.text
            logging.debug(f"[HLSProxyHandler] Conteúdo do manifesto original (primeiros 200 chars): {content[:200]}")

            if is_manifest_limit_error(content):
                logging.warning(f"[HLSProxyHandler] Manifesto {url} indica erro de limite. Entrando em cooldown.")
                self.proxy_manager.record_limit_hit(url)
                self.proxy_manager.force_reconnection(url) # Reconnection to try new IP/session next time
                return self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

            proxy_base = f"http://{join_host_port(self.server.server_address[0], self.server.server_address[1])}/?url="
            rewriter = ManifestRewriter(content, response.url, proxy_base)
            rewritten_content = rewriter.rewrite()
            ttl = rewriter.get_ttl()
            
            logging.debug(f"[HLSProxyHandler] Conteúdo do manifesto reescrito (primeiros 200 chars): {rewritten_content[:200]}") # NEW LOG
            
            self.stream_cache.add_manifest(url, rewritten_content, ttl)
            self.proxy_manager.clear_limit_hit(url)
            
            # Se for um manifesto de playlist (contém segmentos), enfileirar para pré-busca
            if not rewriter.m3u8_obj.playlists: # CORREÇÃO APLICADA AQUI: verifica se é uma playlist de mídia (segmentos)
                segments_to_prefetch = rewriter.get_segments()
                logging.info(f"[HLSProxyHandler] Enfileirando {len(segments_to_prefetch)} segmentos para pré-busca do manifesto {url}.")
                self.proxy_manager.queue_segments_for_prefetch(segments_to_prefetch)

            logging.info(f"[HLSProxyHandler] Manifesto {url} reescrito e servido.")
            self._send_response(200, rewritten_content.encode('utf-8'), 'application/vnd.apple.mpegurl')

        except Exception as e:
            logging.error(f"[HLSProxyHandler] Erro ao processar manifesto {url}: {e}", exc_info=True)
            self.proxy_manager.force_reconnection(url) # Brute force reconnection on manifest fetch failure
            self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl") # Retorna manifesto vazio

    def _handle_segment(self, url: str):
        mime_type = safe_mime_type(url)
        
        # Tentativa de servir do cache primeiro para simular VOD
        cached_data = self.stream_cache.get_segment(url)
        if cached_data:
            logging.info(f"[HLSProxyHandler] Servindo segmento {url} do cache.")
            additional_headers = {'Content-Range': self.headers.get('Range', 'bytes=0-')} if self.headers.get('Range') else None
            return self._send_response(200, cached_data, mime_type, additional_headers)

        try:
            logging.info(f"[HLSProxyHandler] Buscando segmento original: {url}")
            response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
            segment_data = bytearray()
            total_read = 0
            for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                segment_data.extend(chunk)
                total_read += len(chunk)
                if total_read > MAX_SEGMENT_SIZE_BYTES:
                    logging.error(f"[HLSProxyHandler] Segmento {url} excedeu o tamanho máximo permitido ({MAX_SEGMENT_SIZE_MB}MB).")
                    raise IOError(f"Segmento excedeu o tamanho máximo permitido.")
            final_data = bytes(segment_data)
            
            self.stream_cache.add_segment(url, final_data)
            self.proxy_manager.reset_failure_count()
            
            additional_headers = {'Content-Range': response.headers.get('Content-Range', self.headers.get('Range', 'bytes=0-'))} if self.headers.get('Range') else None
            self._send_response(200, final_data, mime_type, additional_headers)
            logging.info(f"[HLSProxyHandler] Segmento {url} baixado e servido (tamanho: {len(final_data)} bytes).")

        except Exception as e:
            logging.error(f"[HLSProxyHandler] Erro ao buscar/servir segmento {url}: {e}", exc_info=True)
            self.proxy_manager.increment_failure_count()
            if self.proxy_manager.should_force_reconnect():
                logging.info(f"[HLSProxyHandler] Falhas consecutivas de segmento atingiram o limite. Forçando reconexão bruta.")
                # Forçar reconexão ao manifesto base para obter um novo conjunto de IPs/sessões
                # É crucial aqui limpar caches de DNS/HTTP para tentar "furar" o bloqueio.
                self.proxy_manager.force_reconnection(self.proxy_manager.get_base_url(url))  
                self.proxy_manager.reset_failure_count() # Resetar contador após a reconexão bruta
            self.send_error(503, "Segmento indisponível ou falha na rede.")

class HLSProxyManager:
    def __init__(self):
        self.server: Optional[socketserver.ThreadingTCPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None
        self._http_session: requests.Session = self._create_http_session()
        self.dns_resolver = DoHDNSResolver()
        self.chunk_cache = RotatingChunkCache()
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(self._http_session, self.dns_resolver)
        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0
        self._limit_hits: Dict[str, float] = {}
        
        # Prefetching
        self._segment_prefetch_queue = queue.Queue(maxsize=100)
        self._prefetch_stop_event = threading.Event()
        self._prefetch_thread: Optional[threading.Thread] = None

    def _create_http_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({
            'User-Agent': USER_AGENTS[0],
            'Accept': 'application/vnd.apple.mpegurl,video/mp2t,audio/aac,video/mp4',
            'Connection': 'keep-alive'
        })
        session.trust_env = False
        return session

    def reset_http_session(self):
        logging.info("[HLSProxyManager] Resetando sessão HTTP, DNS e limpando fila de pré-busca.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher.session = self._http_session
        self.dns_resolver.clear_cache()
        with self._segment_prefetch_queue.mutex:
            self._segment_prefetch_queue.queue.clear()
        self.chunk_cache.clear() # Limpa o cache de chunks também

    def force_reconnection(self, url: str):
        logging.info(f"[HLSProxyManager] Forçando reconexão para URL base/host: {url}")
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.hostname:
            self.dns_resolver.clear_cache_for_host(parsed_url.hostname)
        self.stream_cache.clear() # Limpa o cache de manifestos e chunks
        self.reset_http_session() # Reseta a sessão HTTP e DNS

    def increment_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures += 1
            logging.warning(f"[HLSProxyManager] Incrementando contador de falhas consecutivas: {self._consecutive_failures}")

    def reset_failure_count(self):
        with self._failure_lock:
            if self._consecutive_failures > 0:
                logging.info(f"[HLSProxyManager] Resetando contador de falhas consecutivas.")
            self._consecutive_failures = 0

    def should_force_reconnect(self) -> bool:
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES

    def record_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        self._limit_hits[base_url] = time.time()
        logging.warning(f"[HLSProxyManager] Limite atingido para {base_url}. Entrando em cooldown.")

    def is_in_cooldown(self, url: str) -> bool:
        base_url = self._get_base_url(url)
        hit_time = self._limit_hits.get(base_url)
        is_cooldown = hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS
        if is_cooldown:
            remaining = int(LIMIT_COOLDOWN_SECONDS - (time.time() - hit_time))
            logging.info(f"[HLSProxyManager] {base_url} ainda em cooldown por {remaining}s.")
        return is_cooldown

    def clear_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        if base_url in self._limit_hits:
            del self._limit_hits[base_url]
            logging.info(f"[HLSProxyManager] Cooldown para {base_url} limpo.")

    @staticmethod
    def _get_base_url(url: str) -> str:
        parts = urllib.parse.urlparse(url)
        return f"{parts.scheme}://{parts.netloc}"

    def get_base_url(self, url: str) -> str:
        return self._get_base_url(url)

    def queue_segments_for_prefetch(self, segment_urls: List[str]):
        if PREFETCH_SEGMENTS_COUNT <= 0:
            return # Prefetching desativado
            
        for url in segment_urls:
            if not self.stream_cache.has_segment(url): # Só adiciona se não estiver no cache
                try:
                    self._segment_prefetch_queue.put_nowait(url)
                    logging.debug(f"[HLSProxyManager] Segmento {url} adicionado à fila de pré-busca.")
                except queue.Full:
                    logging.warning(f"[HLSProxyManager] Fila de pré-busca cheia. Ignorando {url}.")
                    break # Se a fila está cheia, para de adicionar.

    def _prefetch_worker(self):
        logging.info("[HLSProxyManager] Thread de pré-busca iniciada.")
        while not self._prefetch_stop_event.is_set():
            try:
                segment_url = self._segment_prefetch_queue.get(timeout=PREFETCH_INTERVAL_SECONDS)
                if not self.stream_cache.has_segment(segment_url): # Dupla checagem para evitar downloads redundantes
                    logging.info(f"[HLSProxyManager] Pré-buscando segmento: {segment_url}")
                    try:
                        response = self.fetcher.fetch(segment_url, stream=True)
                        segment_data = bytearray()
                        for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            segment_data.extend(chunk)
                            if len(segment_data) > MAX_SEGMENT_SIZE_BYTES:
                                logging.warning(f"[HLSProxyManager] Segmento pré-buscado {segment_url} excedeu o tamanho máximo.")
                                break # Não armazenar segmentos muito grandes
                        else: # Only runs if the loop completed without a break
                            self.stream_cache.add_segment(segment_url, bytes(segment_data))
                            logging.info(f"[HLSProxyManager] Pré-busca de {segment_url} concluída.")
                    except requests.RequestException as e:
                        logging.warning(f"[HLSProxyManager] Falha na pré-busca de {segment_url}: {e}")
                self._segment_prefetch_queue.task_done()
            except queue.Empty:
                pass # Nenhuma tarefa na fila, espera um pouco
            except Exception as e:
                logging.error(f"[HLSProxyManager] Erro inesperado na thread de pré-busca: {e}", exc_info=True)
        logging.info("[HLSProxyManager] Thread de pré-busca finalizada.")


    def start(self) -> Optional[int]:
        self.stop() # Garante que o proxy anterior esteja parado
        def handler_factory(*args, **kwargs):
            return HLSProxyHandler(*args, **kwargs,
                                   stream_cache=self.stream_cache,
                                   fetcher=self.fetcher,
                                   proxy_manager=self)
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                server = socketserver.ThreadingTCPServer((PROXY_HOST, port), handler_factory)
                server.allow_reuse_address = True
                self.server = server
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"[HLSProxyManager] Proxy iniciado em {PROXY_HOST}:{port}")
                
                # Iniciar thread de pré-busca se PREFETCH_SEGMENTS_COUNT > 0
                if PREFETCH_SEGMENTS_COUNT > 0:
                    self._prefetch_stop_event.clear()
                    self._prefetch_thread = threading.Thread(target=self._prefetch_worker, daemon=True)
                    self._prefetch_thread.start()
                    logging.info("[HLSProxyManager] Thread de pré-busca iniciada.")

                return port
            except Exception as e:
                logging.error(f"[HLSProxyManager] Erro ao iniciar proxy na porta {port}: {e}")
                continue
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy",5000)')
        return None

    def stop(self):
        logging.info("[HLSProxyManager] Parando o proxy...")
        if self._prefetch_thread and self._prefetch_thread.is_alive():
            self._prefetch_stop_event.set() # Sinaliza para a thread parar
            self._prefetch_thread.join(timeout=5) # Espera a thread terminar
            if self._prefetch_thread.is_alive():
                logging.warning("[HLSProxyManager] Thread de pré-busca não encerrou a tempo.")

        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
            logging.info("[HLSProxyManager] Servidor HTTP do proxy parado.")
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
            if self.server_thread.is_alive():
                logging.warning("[HLSProxyManager] Thread do servidor HTTP não encerrou a tempo.")
        
        self.stream_cache.clear()
        self.reset_http_session()
        self.active_port = None
        logging.info("[HLSProxyManager] Proxy parado e caches limpos.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/?url={encoded_url}"

# ==============================================================================
# --- LÓGICA DO ADDON KODI ---
# ==============================================================================

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        logging.info("[CustomPlayer] Player customizado inicializado.")

    def onPlayBackEnded(self):
        logging.info("[CustomPlayer] Playback ended.")
        self.stop_event.set()

    def onPlayBackError(self):
        logging.error("[CustomPlayer] Playback error!")
        self.stop_event.set()

    def onPlayBackStopped(self):
        logging.info("[CustomPlayer] Playback stopped.")
        self.stop_event.set()

class HLSProxyAddon:
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)
        logging.info(f"[HLSProxyAddon] Addon inicializado com handle: {handle}")

    def _convert_to_m3u8(self, url: str) -> str:
        """
        Tenta normalizar a URL para um formato HLS .m3u8 ou .m3u,
        removendo parâmetros adicionais do player Kodi.
        Adiciona heurísticas para URLs comuns de IPTV que podem não terminar em .m3u8.
        """
        original_url = url
        try:
            # Explicitly strip everything after the first encoded or unencoded pipe.
            # This order ensures that encoded pipes from original URLs are handled first.
            if '%7C' in url:
                url = url.split('%7C', 1)[0]
            if '|' in url:
                url = url.split('|', 1)[0]
            
            # Se já parece ser um manifesto, retorna
            if re.search(r'\.(m3u8|m3u)$', url, re.IGNORECASE):
                logging.debug(f"[_convert_to_m3u8] URL já é manifesto HLS: {url}")
                return url
            
            parts = urllib.parse.urlparse(url)
            path_segments = [s for s in parts.path.split('/') if s]

            # Heurística para adicionar '/live' se ausente e não for VOD aparente
            if 'live' not in path_segments and not re.search(r'\.(mp4|avi|ts)$', parts.path, re.IGNORECASE):
                # Tenta inserir 'live' antes do último segmento se o último não for um arquivo de vídeo óbvio
                if len(path_segments) > 0:
                    last_segment = path_segments[-1]
                    # Evita adicionar 'live' se o último segmento for um ID numérico ou hash
                    if not re.fullmatch(r'\d+|[a-fA-F0-9]{32,}', last_segment): # Verifica se é só números ou um hash longo
                        new_path_segments = path_segments[:-1] + ['live'] + [path_segments[-1]]
                        new_path = '/' + '/'.join(new_path_segments)
                        url = parts._replace(path=new_path).geturl()
                        logging.debug(f"[_convert_to_m3u8] Adicionado '/live' à URL: {url}")
                else: # Se não há segmentos de path, adiciona 'live' diretamente
                    url = parts._replace(path=parts.path.rstrip('/') + '/live').geturl()
                    logging.debug(f"[_convert_to_m3u8] Adicionado '/live' à URL vazia: {url}")


            # Tentar adicionar .m3u8 se não tiver extensão e não for um segmento .ts
            if not re.search(r'\.(ts|mp4|aac)$', url, re.IGNORECASE) and not url.endswith('.m3u8'):
                url += '.m3u8'
                logging.debug(f"[_convert_to_m3u8] Adicionado '.m3u8' à URL: {url}")
            
            logging.debug(f"[_convert_to_m3u8] URL convertida de {original_url} para {url}")
            return url
        except Exception as e:
            logging.error(f"[HLSProxyAddon] Erro ao converter URL {original_url}: {e}", exc_info=True)
            return original_url # Retorna a original em caso de erro

    def play_stream(self, url: str, channel_name: Optional[str] = None):
        logging.info(f"[HLSProxyAddon] Tentando reproduzir stream: {url} (Nome: {channel_name})")
        processed_url = self._convert_to_m3u8(url)
        logging.info(f"[HLSProxyAddon] URL processada para reprodução: {processed_url}")

        if not self.proxy_manager.start():
            logging.error("[HLSProxyAddon] Falha ao iniciar o proxy. Não é possível reproduzir.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url:
            logging.error("[HLSProxyAddon] Falha ao obter URL do proxy. Não é possível reproduzir.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        logging.info(f"[HLSProxyAddon] URL do proxy para reprodução: {proxy_url}")
        display_name = f"{channel_name or 'Stream'} [COLOR cyan](HLS Tester)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_name)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        
        # Define a URL resolvida para o Kodi
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        logging.info("[HLSProxyAddon] URL resolvida para o Kodi. Iniciando monitoramento de playback.")
        
        # Inicia thread para monitorar o fim da reprodução
        threading.Thread(target=self.monitor_playback, daemon=True).start()

    def monitor_playback(self):
        logging.info("[HLSProxyAddon] Monitor de playback iniciado. Aguardando evento de parada.")
        self.playback_stop_event.wait() # Bloqueia até que o evento seja setado pelo player
        logging.info("[HLSProxyAddon] Evento de parada de playback recebido. Parando o proxy.")
        self.proxy_manager.stop()
        logging.info("[HLSProxyAddon] Proxy parado após término do playback.")

    def show_test_streams(self):
        logging.info("[HLSProxyAddon] Exibindo streams de teste.")
        test_streams = [
            ("Big Buck Bunny (VOD - Teste de download completo)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Exemplo Live (Pode estar offline, teste de atualização manifesto)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Exemplo Live (TS, converter para M3U8)", "http://sample.vodobox.com/skate_park_pic.ts"), # Exemplo para testar a conversão TS para M3U8
            ("Exemplo Live (sem ext, heurística)", "http://live.hkstv.hk/live/hks/playlist"), # Exemplo para testar adição de .m3u8
        ]
        for name, url in test_streams:
            list_item = xbmcgui.ListItem(label=name)
            list_item.setProperty('IsPlayable', 'true')
            list_item.setMimeType(safe_mime_type(url)) # Tenta determinar o MIME type
            plugin_url_params = urllib.parse.urlencode({'action': 'play', 'url': url, 'title': name})
            plugin_url = f"plugin://{ADDON_ID}/?{plugin_url_params}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, list_item, isFolder=False)
            logging.debug(f"[HLSProxyAddon] Adicionado item de diretório: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(self.handle)
        logging.info("[HLSProxyAddon] Fim da listagem de streams de teste.")

def main():
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get('action')
        
        # Inicializa o logger para garantir que ele esteja pronto antes de qualquer log.
        setup_logging() 
        logging.info(f"Main iniciado. sys.argv: {sys.argv}")
        
        addon = HLSProxyAddon(handle)
        if action == 'play':
            url_to_play = params.get('url')
            title = params.get('title')
            if url_to_play:
                addon.play_stream(url_to_play, title)
            else:
                logging.error("[main] Ação 'play' chamada sem URL.")
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.critical(f"Erro fatal na função main: {e}", exc_info=True)
        # Em caso de erro crítico, tenta notificar o usuário via Kodi
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro crítico: Veja o log",5000)')

if __name__ == '__main__':
    main()