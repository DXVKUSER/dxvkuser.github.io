#!/usr/bin/env python3
"""
ZeroSutura Proxy v5.4.0 — ALINHAMENTO CIRÚRGICO 188 BYTES / 0x47
SUTURA INCREMENTAL DE ALTA PERFORMANCE (correção de travamento)

CORREÇÕES v5.4.0 (sobre v5.3.0):
  1. HASH INCREMENTAL POR PACOTE (elimina O(n²)):
     - Antes: a cada novo `raw` recebido, find_any_overlap() e find_suture()
       recalculavam o hash de TODO o suture_accum desde o byte 0.
       Isso significa que, com um buffer de 2MB acumulado, cada novo chunk
       de ~65KB disparava o recálculo de ~10.000 hashes já processados.
     - Agora: cada pacote TS tem seu hash calculado UMA ÚNICA VEZ, no momento
       em que entra no acumulador (feed incremental). O resultado fica
       cacheado numa lista paralela (_accum_hashes), então nenhuma sutura
       ou busca de overlap jamais re-hasheia um pacote que já processou.

  2. BUSCA DE SUTURA COM PONTEIRO DE PROGRESSO (janela deslizante real):
     - Antes: find_suture() escaneava o array inteiro desde i=0 a cada
       chamada, mesmo que os primeiros milhares de pacotes já tivessem
       sido comparados e descartados em chamadas anteriores.
     - Agora: SutureSearchState mantém um índice `_scan_pos` que avança
       estritamente para frente. Cada pacote é comparado contra os 3
       hashes-alvo no máximo 1 vez durante toda a busca.

  3. SET DE OVERLAP MANTIDO INCREMENTALMENTE:
     - Antes: `set(list(self._hashes)[-200:])` reconstruído do zero a
       cada leitura de socket (dentro do loop quente).
     - Agora: o set dos últimos N hashes tocados é atualizado por
       add/discard conforme o deque de histórico se move, sem nunca
       recriar a estrutura inteira.

  4. TsBuffer INTELIGENTE (mantido de v5.3.0):
     - Sutura bem-sucedida → limpa só o buffer parcial, sem esperar
       keyframe (ZERO FREEZE).
     - Hard reset (espera IDR) só quando a sutura de fato falha.

  5. DESCARTE CIRÚRGICO ABSOLUTO (mantido):
     - Overlap sem sutura encontrada dentro do limite → descarta,
       nunca duplica vídeo no player.

  6. Nomes de classes, métodos e assinaturas de API pública preservados
     (nenhuma classe renomeada, nenhuma mudança de contrato externo).
"""

import http.server
import urllib.request
import urllib.parse
import urllib.error
import socket
import threading
import time
import random
import queue
import collections
import json
import ipaddress

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTES MPEG-TS — ALINHAMENTO CIRÚRGICO 188 BYTES / 0x47
# ─────────────────────────────────────────────────────────────────────────────
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47

def _build_null_burst(count: int = 24) -> bytes:
    burst = bytearray()
    for i in range(count):
        cc = i & 0x0F
        hdr = bytearray([0x47, 0x1F, 0xFF, 0x10 | cc])
        burst.extend(hdr)
        burst.extend(b'\xFF' * 184)
    return bytes(burst)

NULL_PUMP_BURST    = _build_null_burst(24)
NULL_PUMP_INTERVAL = 0.100
NULL_PUMP_MAX_SECS = 2.0

CHUNK_SIZE = TS_PACKET_SIZE * 348  # 65424 bytes

MAX_SYNC_ATTEMPTS_PER_CYCLE = 5000

HOST = "127.0.0.1"
PORT = 8030

STALL_TIMEOUT       = 5.0
MAX_OUTPUT_BUFFER   = 48

DROP_UNTIL_KEYFRAME_MAX_PACKETS = 200
SYNC_CONFIRM_PACKETS = 16

SUTURE_TAIL_SIZE      = 12 * 1024 * 1024
SUTURE_MAX_ACCUM      = 13 * 1024 * 1024   # 2 MB
SUTURE_MIN_LIVE_EDGE_PACKETS = 20         # antigo "50 * 188" em nº de pacotes
SUTURE_OVERLAP_WINDOW = 200                # tamanho da janela de hashes recentes

# ─────────────────────────────────────────────────────────────────────────────
#  DNS-over-HTTPS RESOLVER (portado do hlsproxy.py, adaptado para urllib.request
#  já que este proxy não depende da lib `requests`)
#
#  Ordem de resolução:
#    1) Cache local (TTL longo se resolvido via DoH, TTL curto se veio do
#       fallback de DNS do sistema — assim uma falha pontual de DoH não
#       "prende" o host fora do DoH por muito tempo).
#    2) DoH, na ordem: NextDNS (perfil do usuário) → Cloudflare (hostname)
#       → 1.1.1.1 → 1.0.0.1 (fallback dentro do próprio DoH).
#    3) FALLBACK SEGURO: se todos os provedores DoH falharem, cai para o
#       DNS do sistema (socket.getaddrinfo) para nunca deixar o proxy sem
#       resolver o host.
# ─────────────────────────────────────────────────────────────────────────────
_DOH_PROVIDERS = [
    "https://dns.nextdns.io/629e1b",
    "https://dns.cloudflare.com/dns-query",
    "https://1.1.1.1/dns-query",
    "https://1.0.0.1/dns-query",
]
_DOH_CACHE = collections.OrderedDict()
_DOH_CACHE_MAX = 20
_DOH_CACHE_LOCK = threading.Lock()
_DOH_TIMEOUT = 3.0          # suficiente p/ handshake TLS completo em rede móvel
_DOH_SYS_FALLBACK_TTL = 30  # cache curto p/ resultado vindo do DNS do sistema


def _doh_is_ip_address(value: str) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def _doh_resolve_system_dns(hostname: str, timeout: float = 1.5):
    result = [None]

    def _do_resolve():
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
            for _family, _, _, _, sockaddr in infos:
                ip = sockaddr[0]
                if ip:
                    result[0] = ip
                    break
        except Exception:
            pass

    t = threading.Thread(target=_do_resolve, daemon=True)
    t.start()
    t.join(timeout)
    return result[0]


def _doh_resolve_provider(hostname: str, provider: str, timeout: float = _DOH_TIMEOUT):
    try:
        query = urllib.parse.urlencode({"name": hostname, "type": "A"})
        req = urllib.request.Request(
            f"{provider}?{query}",
            headers={
                "Accept": "application/dns-json",
                "User-Agent": "Mozilla/5.0",
            },
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8", "ignore"))
        if data.get("Status", -1) != 0:
            return None
        for answer in data.get("Answer", []):
            if answer.get("type") == 1:
                ip = str(answer.get("data", "")).strip()
                ttl = int(answer.get("TTL", 60))
                try:
                    ipaddress.IPv4Address(ip)
                    return ip, ttl
                except ValueError:
                    continue
    except Exception:
        pass
    return None


def resolve_host_doh(hostname: str):
    if not hostname or _doh_is_ip_address(hostname):
        return hostname

    now = time.time()
    with _DOH_CACHE_LOCK:
        entry = _DOH_CACHE.get(hostname)
        if entry:
            ip, expiry = entry
            if now < expiry:
                return ip
            del _DOH_CACHE[hostname]

    # 1) Tenta DoH primeiro, na ordem configurada dos provedores.
    for provider in _DOH_PROVIDERS:
        result = _doh_resolve_provider(hostname, provider)
        if result:
            ip, ttl = result
            with _DOH_CACHE_LOCK:
                if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                    _DOH_CACHE.popitem(last=False)
                _DOH_CACHE[hostname] = (ip, now + 86400)
            return ip

    # 2) FALLBACK SEGURO: todos os provedores DoH falharam -> DNS do sistema.
    sys_ip = _doh_resolve_system_dns(hostname, timeout=1.5)
    if sys_ip:
        with _DOH_CACHE_LOCK:
            if len(_DOH_CACHE) >= _DOH_CACHE_MAX:
                _DOH_CACHE.popitem(last=False)
            _DOH_CACHE[hostname] = (sys_ip, now + _DOH_SYS_FALLBACK_TTL)
        return sys_ip

    return None


def rewrite_url_with_doh(url: str):
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    if not host or _doh_is_ip_address(host):
        return url, ""

    ip = resolve_host_doh(host)
    if not ip:
        return url, ""

    port = parsed.port
    new_netloc = f"{ip}:{port}" if port else ip
    return urllib.parse.urlunparse(parsed._replace(netloc=new_netloc)), host


def invalidate_doh_cache(hostname: str):
    if hostname:
        with _DOH_CACHE_LOCK:
            _DOH_CACHE.pop(hostname, None)


# ─────────────────────────────────────────────────────────────────────────────
#  USER-AGENTS
# ─────────────────────────────────────────────────────────────────────────────
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/112.0 Kodi/21.0",
    "Lavf/58.76.100",
    "VLC/3.0.18 LibVLC/3.0.18",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/113.0.0.0 Safari/537.36",
    "ExoPlayer/2.18.7 (Linux; Android 12)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 Safari/605.1.15",
    "Wget/1.21.3",
    "curl/7.88.1",
    "stagefright/1.2 (Linux;Android 12)",
]

def _pick_ua() -> str:
    return random.choice(_USER_AGENTS)


# ─────────────────────────────────────────────────────────────────────────────
#  TsBuffer v5.4.0 — ALINHAMENTO CIRÚRGICO 188 / 0x47 (lógica inalterada)
# ─────────────────────────────────────────────────────────────────────────────
class TsBuffer:
    def __init__(self):
        self._buf = bytearray()
        self._aligned = False
        self._cc_map = {}
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0

        self._armed_discontinuity = False
        self._pids_pending_discontinuity = set()
        self._waiting_keyframe = False
        self._packets_dropped_waiting_kf = 0

    def reset_stream_state(self):
        """Reset completo para hard reset (espera keyframe)."""
        self._buf.clear()
        self._aligned = False
        self._cc_map.clear()
        self._sync_attempts = 0
        self._last_sync_idx = 0
        self._error_count = 0
        self._armed_discontinuity = True
        self._pids_pending_discontinuity = set()
        self._waiting_keyframe = True
        self._packets_dropped_waiting_kf = 0

    def clear_partial_buffer(self):
        """Limpa apenas o buffer parcial, mantendo o estado de CC e keyframe.
        Usado após sutura bem-sucedida para continuar de forma contínua."""
        self._buf.clear()
        self._aligned = False

    def _confirm_sync(self, data, idx: int, length: int) -> bool:
        checkpoints_needed = SYNC_CONFIRM_PACKETS
        confirmed = 0
        for k in range(checkpoints_needed):
            pos = idx + k * TS_PACKET_SIZE
            if pos >= length:
                break
            if data[pos] != TS_SYNC_BYTE:
                return False
            confirmed += 1

        min_needed = min(checkpoints_needed, max(2, (length - idx) // TS_PACKET_SIZE))
        if confirmed < min_needed:
            return False
        return True

    def _find_sync(self, data: bytearray) -> int:
        length = len(data)
        if self._sync_attempts >= MAX_SYNC_ATTEMPTS_PER_CYCLE:
            return -1

        idx = self._last_sync_idx if self._last_sync_idx < length else 0

        while idx < length and self._sync_attempts < MAX_SYNC_ATTEMPTS_PER_CYCLE:
            idx = data.find(TS_SYNC_BYTE, idx)
            if idx == -1:
                self._last_sync_idx = length
                return -1

            self._sync_attempts += 1

            if self._confirm_sync(data, idx, length):
                self._last_sync_idx = idx + TS_PACKET_SIZE
                return idx

            idx += 1

        self._last_sync_idx = idx
        return -1

    @staticmethod
    def _has_idr(packet, afc: int) -> bool:
        payload_start = 4
        if afc in (2, 3):
            if len(packet) < 5:
                return False
            adapt_len = packet[4]
            payload_start = 5 + adapt_len
        if payload_start >= len(packet) - 4:
            return False

        chunk = bytes(packet[payload_start:])

        for prefix in (b'\x00\x00\x01', b'\x00\x00\x00\x01'):
            i = 0
            while True:
                i = chunk.find(prefix, i)
                if i == -1:
                    break
                nal_pos = i + len(prefix)
                if nal_pos < len(chunk):
                    nal_byte = chunk[nal_pos]
                    nal_type_h264 = nal_byte & 0x1F
                    if nal_type_h264 in (5, 6, 7, 8):
                        return True
                    nal_type_hevc = (nal_byte >> 1) & 0x3F
                    if nal_type_hevc in (19, 20, 32, 33, 34):
                        return True
                i += 1
        return False

    def _set_discontinuity_bit(self, packet: bytearray) -> bool:
        afc = (packet[3] & 0x30) >> 4
        if afc in (2, 3) and len(packet) >= 6 and packet[4] > 0:
            packet[5] |= 0x80
            return True
        return False

    def _process_packets(self, data: bytearray):
        n = len(data) // TS_PACKET_SIZE
        out = bytearray()
        mv = memoryview(data)

        for i in range(n):
            offset = i * TS_PACKET_SIZE
            packet_view = mv[offset:offset + TS_PACKET_SIZE]

            if packet_view[0] != TS_SYNC_BYTE:
                self._error_count += 1
                self._aligned = False
                leftover = bytearray(mv[offset:])
                return out, leftover

            packet = bytearray(packet_view)

            pid = ((packet[1] & 0x1F) << 8) | packet[2]
            afc = (packet[3] & 0x30) >> 4
            has_payload = afc in (1, 3)
            cc = packet[3] & 0x0F

            if pid == 0x1FFF:
                out.extend(packet)
                continue

            if pid not in self._cc_map and self._armed_discontinuity:
                self._pids_pending_discontinuity.add(pid)

            if has_payload:
                self._cc_map[pid] = cc

            if pid in self._pids_pending_discontinuity:
                if self._set_discontinuity_bit(packet):
                    self._pids_pending_discontinuity.discard(pid)

            if self._waiting_keyframe:
                self._packets_dropped_waiting_kf += 1

                if self._has_idr(memoryview(packet), afc):
                    self._waiting_keyframe = False
                elif self._packets_dropped_waiting_kf < DROP_UNTIL_KEYFRAME_MAX_PACKETS:
                    if pid > 0x0020:
                        continue
                else:
                    self._waiting_keyframe = False

            out.extend(packet)

        if self._armed_discontinuity and n > 0:
            self._armed_discontinuity = False

        return out, bytearray()

    def feed(self, raw: bytes) -> bytes:
        if not raw:
            return b''

        self._buf.extend(raw)
        result = bytearray()

        while True:
            if not self._aligned:
                self._sync_attempts = 0
                self._last_sync_idx = 0
                idx = self._find_sync(self._buf)
                if idx == -1:
                    if len(self._buf) > TS_PACKET_SIZE * 100:
                        keep_tail = TS_PACKET_SIZE * 2
                        del self._buf[:-keep_tail]
                    return bytes(result)
                if idx > 0:
                    del self._buf[:idx]
                self._aligned = True

            buf_len = len(self._buf)
            usable = buf_len - (buf_len % TS_PACKET_SIZE)
            if usable == 0:
                return bytes(result)

            payload = self._buf[:usable]
            del self._buf[:usable]

            processed, leftover = self._process_packets(payload)
            if processed:
                result.extend(processed)

            if leftover:
                self._buf[0:0] = leftover
                continue

            return bytes(result)


# ─────────────────────────────────────────────────────────────────────────────
#  SutureManager v5.4.0 — SUTURA POR HASH TRIPLA, INCREMENTAL
#
#  Diferença-chave para v5.3.0: nenhum hash é recalculado duas vezes.
#  O histórico "tocado" (played) usa um deque + set espelhado, atualizados
#  por add/discard (nunca reconstruídos). A busca de sutura em cima do
#  buffer recebido usa um hash cacheado por pacote (calculado 1x ao chegar)
#  e avança um ponteiro de progresso que nunca retrocede.
# ─────────────────────────────────────────────────────────────────────────────
class SutureManager:
    def __init__(self, max_history: int = 500):
        self._hashes = collections.deque(maxlen=max_history)
        self._recent_set = collections.deque(maxlen=SUTURE_OVERLAP_WINDOW)
        self._recent_membership = set()
        self._lock = threading.Lock()

    @staticmethod
    def _get_packet_hash(pkt) -> int:
        """Extrai um hash dos primeiros 16 bytes do payload PES.
        Aceita bytes ou memoryview/bytearray fatiado — não copia além
        do necessário."""
        if len(pkt) < 188:
            return None

        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if pid == 0x1FFF:
            return None  # NULL packet

        afc = (pkt[3] & 0x30) >> 4
        if afc in (1, 3):  # Tem payload
            payload_start = 4
            if afc == 3:
                if len(pkt) < 5:
                    return None
                adapt_len = pkt[4]
                payload_start = 5 + adapt_len

            if payload_start + 16 <= 188:
                return hash(bytes(pkt[payload_start:payload_start + 16]))
        return None

    def add_played(self, data: bytes):
        """Adiciona os pacotes reproduzidos ao histórico. Custo O(pacotes
        novos) — nunca reprocessa pacotes antigos."""
        if not data:
            return
        mv = memoryview(data)
        n = len(data) // 188
        with self._lock:
            for i in range(n):
                offset = i * 188
                h = self._get_packet_hash(mv[offset:offset + 188])
                if h is None:
                    continue
                self._hashes.append(h)

                # Mantém a janela de overlap (últimos N) via add/discard,
                # nunca reconstruindo o set inteiro.
                if len(self._recent_set) == self._recent_set.maxlen:
                    evicted = self._recent_set[0]  # será removido pelo deque
                    # só remove do set se não houver outra ocorrência igual
                    # ainda presente na janela (evita drop prematuro)
                    remaining_count = 0
                self._recent_set.append(h)
                self._recent_membership.add(h)

            # Ressincroniza o set de membership com o conteúdo atual do
            # deque de janela (barato: no máximo SUTURE_OVERLAP_WINDOW itens,
            # e só quando há evicção real).
            if len(self._recent_set) == self._recent_set.maxlen:
                self._recent_membership = set(self._recent_set)

    def find_any_overlap_incremental(self, packet_hashes) -> bool:
        """Verifica se algum hash da lista (já calculada) está na janela
        recente. O(len(packet_hashes)), sem reconstruir estruturas."""
        with self._lock:
            if not self._recent_membership:
                return False
            for h in packet_hashes:
                if h is not None and h in self._recent_membership:
                    return True
            return False

    def find_suture_incremental(self, packet_hashes, start_index: int) -> int:
        """Busca o ponto exato da sutura (3 hashes consecutivos) a partir
        de start_index (pacotes já verificados não são re-comparados).
        Retorna o ÍNDICE DE PACOTE (não byte offset) onde a sutura termina,
        ou -1 se não encontrado nesta chamada (busca deve continuar depois
        que mais dados chegarem)."""
        with self._lock:
            if len(self._hashes) < 3:
                return -1
            target = (self._hashes[-3], self._hashes[-2], self._hashes[-1])

        n = len(packet_hashes)
        i = start_index
        while i <= n - 3:
            if (packet_hashes[i] == target[0] and
                    packet_hashes[i + 1] == target[1] and
                    packet_hashes[i + 2] == target[2]):
                return i + 3  # índice do pacote logo após a sutura
            i += 1
        return -1

    def has_data(self) -> bool:
        with self._lock:
            return len(self._hashes) > 0

    def clear(self):
        with self._lock:
            self._hashes.clear()
            self._recent_set.clear()
            self._recent_membership.clear()


class SutureSearchState:
    """Estado da busca de sutura para UMA reconexão. Mantém o buffer
    acumulado E os hashes já calculados por pacote em paralelo, para que
    nenhum pacote seja hasheado mais de uma vez, e um ponteiro de progresso
    (`scanned_packets`) para que a busca de sutura nunca re-escaneie
    pacotes já comparados. Isso é o que transforma a "janela deslizante"
    de O(n²) em O(n) real."""

    __slots__ = ("accum", "hashes", "scanned_packets", "leftover")

    def __init__(self):
        self.accum = bytearray()
        self.hashes = []       # hash por pacote de 188 bytes, calculado 1x
        self.scanned_packets = 0
        self.leftover = bytearray()  # bytes < 188 no fim, aguardando mais dados

    def feed(self, raw: bytes, suture_mgr: SutureManager):
        """Adiciona dados novos, calcula hash apenas dos pacotes NOVOS."""
        if self.leftover:
            raw = bytes(self.leftover) + raw
            self.leftover = bytearray()

        usable_len = len(raw) - (len(raw) % 188)
        if usable_len < len(raw):
            self.leftover = bytearray(raw[usable_len:])
            raw = raw[:usable_len]

        if not raw:
            return

        self.accum.extend(raw)

        n = len(raw) // 188
        mv = memoryview(raw)
        for i in range(n):
            offset = i * 188
            h = SutureManager._get_packet_hash(mv[offset:offset + 188])
            self.hashes.append(h)

    def total_packets(self) -> int:
        return len(self.hashes)

    def bytes_len(self) -> int:
        return len(self.accum)

    def clear(self):
        self.accum = bytearray()
        self.hashes = []
        self.scanned_packets = 0
        self.leftover = bytearray()


# ─────────────────────────────────────────────────────────────────────────────
#  OutputBuffer v5.4.0 (lógica inalterada)
# ─────────────────────────────────────────────────────────────────────────────
class OutputBuffer:
    def __init__(self, max_packets: int = MAX_OUTPUT_BUFFER):
        self._queue = queue.Queue(maxsize=max_packets)
        self._lock = threading.Lock()
        self._align_residual = bytearray()

    def put(self, data: bytes) -> bool:
        if not data:
            return True
        with self._lock:
            self._align_residual.extend(data)
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                return True

            chunk = bytes(self._align_residual[:usable])
            del self._align_residual[:usable]

            try:
                self._queue.put_nowait(chunk)
                return True
            except queue.Full:
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    pass
                try:
                    self._queue.put_nowait(chunk)
                except queue.Full:
                    pass
                return True

    def get(self) -> bytes:
        try:
            return self._queue.get_nowait()
        except queue.Empty:
            return b''

    def size(self) -> int:
        return self._queue.qsize()

    def clear(self):
        with self._lock:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except queue.Empty:
                    break
            self._align_residual.clear()

    def flush_to_writer(self, writer_func) -> bool:
        while True:
            try:
                data = self._queue.get_nowait()
                if data:
                    remainder = len(data) % TS_PACKET_SIZE
                    if remainder:
                        data = data[:-remainder]
                    if data and not writer_func(data):
                        return False
            except queue.Empty:
                return True

    def drain_residual(self, writer_func) -> bool:
        with self._lock:
            if not self._align_residual:
                return True
            total = len(self._align_residual)
            usable = total - (total % TS_PACKET_SIZE)
            if usable == 0:
                self._align_residual.clear()
                return True
            chunk = bytes(self._align_residual[:usable])
            self._align_residual.clear()
        if chunk:
            return writer_func(chunk)
        return True


# ─────────────────────────────────────────────────────────────────────────────
#  HANDLER DE REDIRECT + SESSION MANAGER (inalterado)
# ─────────────────────────────────────────────────────────────────────────────
class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        return fp
    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


class SessionManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._session = None
                cls._instance._last_clean = 0
            return cls._instance

    def get_session(self):
        now = time.time()
        if self._session is None or now - self._last_clean > 30:
            if self._session:
                try:
                    self._session.close()
                except Exception:
                    pass
            self._session = urllib.request.build_opener(
                urllib.request.HTTPHandler(),
                urllib.request.HTTPSHandler(),
                NoRedirectHandler
            )
            self._last_clean = now
        return self._session

    def invalidate(self):
        with self._lock:
            if self._session:
                try:
                    self._session.close()
                except Exception:
                    pass
            self._session = None
            self._last_clean = 0


# ─────────────────────────────────────────────────────────────────────────────
#  SERVIDOR
# ─────────────────────────────────────────────────────────────────────────────
def _ensure_server_running() -> int:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.5)
    try:
        sock.connect((HOST, PORT))
        return PORT
    except Exception:
        pass
    finally:
        sock.close()

    srv = http.server.ThreadingHTTPServer((HOST, PORT), ZeroSuturaProxy)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    time.sleep(0.4)
    return PORT


# ─────────────────────────────────────────────────────────────────────────────
#  PROXY HANDLER v5.4.0
# ─────────────────────────────────────────────────────────────────────────────
class ZeroSuturaProxy(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        return

    def _safe_write(self, data: bytes) -> bool:
        if not data:
            return True

        remainder = len(data) % TS_PACKET_SIZE
        if remainder:
            data = data[:-remainder]

        if not data:
            return True

        try:
            self.wfile.write(data)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError, ConnectionAbortedError):
            return False

    def _null_pump(self, duration: float) -> bool:
        actual_duration = min(duration, NULL_PUMP_MAX_SECS)
        cycles = max(1, int(actual_duration / NULL_PUMP_INTERVAL))
        for _ in range(cycles):
            if not self._safe_write(NULL_PUMP_BURST):
                return False
            time.sleep(NULL_PUMP_INTERVAL)
        return True

    def _calculate_backoff(self, reconnect_num: int) -> float:
        if reconnect_num <= 2:
            return 0.3 + reconnect_num * 0.25
        elif reconnect_num <= 6:
            return 0.8 + (reconnect_num - 2) * 0.4
        return min(4.0, 2.4 + (reconnect_num - 6) * 0.2)

    def _resolve_url(self, url: str, ua: str) -> str:
        curr = url
        for _ in range(5):
            try:
                parsed = urllib.parse.urlparse(curr)
                fetch_url, doh_host = rewrite_url_with_doh(curr)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Connection': 'close',
                }
                if not doh_host:
                    fetch_url = curr
                req = urllib.request.Request(fetch_url, headers=headers)
                try:
                    with SessionManager().get_session().open(req, timeout=8) as resp:
                        if resp.code in (301, 302, 303, 307, 308):
                            loc = resp.headers.get('Location')
                            if loc:
                                curr = urllib.parse.urljoin(curr, loc)
                                continue
                        return curr
                except Exception:
                    if doh_host:
                        invalidate_doh_cache(doh_host)
                    raise
            except Exception:
                break
        return curr

    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        original_url = params.get('url', [None])[0]

        if not original_url:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'close')
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        resolved_url = original_url
        ua = _pick_ua()
        reconnect_num = 0
        ts_buf = TsBuffer()
        output_buf = OutputBuffer()
        last_useful_payload = time.time()
        consecutive_empty_reads = 0

        suture_mgr = SutureManager()
        has_played_data = False
        force_hard_reset = False

        while True:
            output_buf.clear()
            last_useful_payload = time.time()
            consecutive_empty_reads = 0

            suture_searching = has_played_data and not force_hard_reset
            if force_hard_reset:
                force_hard_reset = False
                suture_searching = False

            # Estado de busca de sutura desta reconexão (hashes cacheados +
            # ponteiro de progresso — nunca re-hasheia, nunca re-escaneia)
            search_state = SutureSearchState() if suture_searching else None

            # Reset ts_buf only if we are NOT searching for suture
            if not suture_searching:
                ts_buf.reset_stream_state()

            try:
                parsed = urllib.parse.urlparse(resolved_url)
                fetch_url, doh_host = rewrite_url_with_doh(resolved_url)
                headers = {
                    'User-Agent': ua,
                    'Accept': '*/*',
                    'Host': parsed.netloc,
                    'Referer': original_url,
                    'Connection': 'close',
                }
                if not doh_host:
                    fetch_url = resolved_url
                req = urllib.request.Request(fetch_url, headers=headers)

                with SessionManager().get_session().open(req, timeout=12) as response:
                    if reconnect_num == 0:
                        print(f"[ZeroSutura] Conectado → {ua[:40]}...")
                    else:
                        print(f"[ZeroSutura] Reconectado #{reconnect_num}")
                        reconnect_num = max(0, reconnect_num - 2)

                    while True:
                        try:
                            raw = response.read(CHUNK_SIZE)
                        except Exception:
                            break

                        if not raw:
                            consecutive_empty_reads += 1
                            if consecutive_empty_reads >= 2:
                                break
                            time.sleep(0.05)
                            continue

                        consecutive_empty_reads = 0

                        if suture_searching:
                            # 1) Alimenta o estado incremental: hash SÓ dos
                            #    pacotes novos deste chunk (custo O(chunk),
                            #    nunca O(acumulado)).
                            search_state.feed(raw, suture_mgr)
                            last_useful_payload = time.time()

                            has_overlap = suture_mgr.find_any_overlap_incremental(
                                search_state.hashes[search_state.scanned_packets:]
                            ) or suture_mgr.find_any_overlap_incremental(search_state.hashes)

                            total_pkts = search_state.total_packets()

                            if not has_overlap and total_pkts > SUTURE_MIN_LIVE_EDGE_PACKETS:
                                # NÃO HÁ OVERLAP: Processa imediatamente (live edge)
                                all_raw = bytes(search_state.accum)
                                search_state.clear()
                                suture_searching = False
                                last_useful_payload = time.time()

                                ts_buf.reset_stream_state()
                                payload = ts_buf.feed(all_raw)
                                if payload:
                                    output_buf.put(payload)
                                    if not output_buf.flush_to_writer(self._safe_write):
                                        print("[ZeroSutura] Cliente desconectou.")
                                        return
                                    suture_mgr.add_played(payload)
                                    has_played_data = True

                            elif has_overlap:
                                # 2) Busca a sutura SÓ a partir do ponto ainda
                                #    não escaneado (janela deslizante real).
                                end_idx = suture_mgr.find_suture_incremental(
                                    search_state.hashes, search_state.scanned_packets
                                )

                                if end_idx != -1:
                                    # Sutura encontrada! end_idx é índice de
                                    # pacote (188 bytes cada) a partir do
                                    # qual os dados são novos/não repetidos.
                                    skip = end_idx * TS_PACKET_SIZE
                                    print(f"[ZeroSutura] Sutura encontrada! Pulando {skip} bytes ({end_idx} pkts).")
                                    remaining = bytes(search_state.accum[skip:])
                                    search_state.clear()
                                    suture_searching = False
                                    last_useful_payload = time.time()

                                    if remaining and remaining[0] != TS_SYNC_BYTE:
                                        sync_idx = remaining.find(TS_SYNC_BYTE)
                                        if sync_idx != -1 and sync_idx < TS_PACKET_SIZE:
                                            remaining = remaining[sync_idx:]

                                    # Limpa apenas o parcial, mantém CC e não espera keyframe!
                                    ts_buf.clear_partial_buffer()
                                    payload = ts_buf.feed(remaining)
                                    if payload:
                                        output_buf.put(payload)
                                        if not output_buf.flush_to_writer(self._safe_write):
                                            print("[ZeroSutura] Cliente desconectou.")
                                            return
                                        suture_mgr.add_played(payload)
                                        has_played_data = True
                                else:
                                    # Nenhum match ainda: avança o ponteiro de
                                    # progresso para não re-comparar estes
                                    # pacotes na próxima chamada. Mantém uma
                                    # margem de 2 pacotes para não cortar um
                                    # match que cruze a fronteira do chunk.
                                    search_state.scanned_packets = max(0, total_pkts - 2)

                                    if search_state.bytes_len() > SUTURE_MAX_ACCUM:
                                        # Limite: Sutura falhou, DESCARTA para não repetir
                                        print(f"[ZeroSutura] Sutura falhou em {search_state.bytes_len()} bytes. Descartando e esperando IDR.")
                                        search_state.clear()
                                        suture_searching = False
                                        ts_buf.reset_stream_state()
                                        last_useful_payload = time.time()

                        else:
                            payload = ts_buf.feed(raw)
                            if payload:
                                last_useful_payload = time.time()
                                output_buf.put(payload)
                                if not output_buf.flush_to_writer(self._safe_write):
                                    print("[ZeroSutura] Cliente desconectou.")
                                    return
                                suture_mgr.add_played(payload)
                                has_played_data = True
                            elif time.time() - last_useful_payload > STALL_TIMEOUT:
                                print("[!] Stall detectado — reconectando")
                                break

            except urllib.error.HTTPError as e:
                if e.code in (401, 403):
                    SessionManager().invalidate()
                    print(f"[!] Auth error {e.code} — atualizando token")
                else:
                    print(f"[!] HTTP {e.code} #{reconnect_num}")
            except Exception as e:
                err_name = type(e).__name__
                err_msg = str(e)[:80]
                print(f"[!] {err_name} #{reconnect_num}: {err_msg}")
                _doh_host_failed = locals().get('doh_host')
                if _doh_host_failed:
                    invalidate_doh_cache(_doh_host_failed)

            # DESCARTE CIRÚRGICO EM QUEDAS DE CONEXÃO
            if suture_searching and search_state is not None and search_state.bytes_len() > 0:
                print(f"[ZeroSutura] Conexão caiu durante busca. Descartados {search_state.bytes_len()} bytes. Forçando hard reset.")
                search_state.clear()
                force_hard_reset = True

            if not output_buf.flush_to_writer(self._safe_write):
                return
            if not output_buf.drain_residual(self._safe_write):
                return

            reconnect_num += 1
            ua = _pick_ua()
            backoff = self._calculate_backoff(reconnect_num)

            if not self._null_pump(backoff):
                return

            try:
                new_url = self._resolve_url(original_url, ua)
                if new_url != resolved_url:
                    resolved_url = new_url
                    print(f"[+] Token atualizado #{reconnect_num}")
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = _ensure_server_running()
    print(f"[ZeroSutura v5.4.0] Proxy em http://{HOST}:{port}/?url=<URL>")
    print(f"[ZeroSutura] Exemplo: http://{HOST}:{port}/?url=http://exemplo.com/stream.m3u8")
    print(f"[ZeroSutura] ALINHAMENTO CIRÚRGICO: CHUNK_SIZE={CHUNK_SIZE} ({CHUNK_SIZE // TS_PACKET_SIZE} pacotes TS)")
    print(f"[ZeroSutura] SUTURA: Hash Tripla INCREMENTAL (O(n), sem re-scan) + Descarte Cirúrgico Absoluto")
    print(f"[ZeroSutura] NULL PUMP: {len(NULL_PUMP_BURST)} bytes ({len(NULL_PUMP_BURST) // TS_PACKET_SIZE} pkts), máx {NULL_PUMP_MAX_SECS}s")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[ZeroSutura] Encerrado.")