#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import threading
import logging
import urllib.parse
import warnings
import requests
import socket
import re
import random
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

PROXY_HOST = "127.0.0.1"
TIMEOUT_CONNECT = 20
TIMEOUT_READ = 45
MAX_REDIRECTS = 5

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="[HLS-PROXY] %(message)s")

try:
    import xbmcgui
    import xbmcplugin
    KODI = True
except ImportError:
    KODI = False

# -------------------- SESSION --------------------

session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=25, pool_maxsize=25)
session.mount("http://", adapter)
session.mount("https://", adapter)

# -------------------- USER AGENTS --------------------

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) Safari/604.1",
    "Mozilla/5.0 (Android 10; Mobile) Chrome/118.0.0.0 Mobile Safari/537.36",
]

# -------------------- HEADERS --------------------

def build_headers(url, rotate=False, base_headers=None):
    p = urllib.parse.urlparse(url)
    headers = base_headers.copy() if base_headers else {}
    headers.update({
        "User-Agent": random.choice(USER_AGENTS) if rotate else USER_AGENTS[0],
        "Accept": "*/*",
        "Connection": "close",
        "Host": p.netloc,
        "Origin": f"{p.scheme}://{p.netloc}",
        "Referer": f"{p.scheme}://{p.netloc}/",
    })
    return headers

# -------------------- HANDLER --------------------

class HLSProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *args):
        return

    def parse_target_url(self):
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        return query.get("url", [None])[0]

    def fetch_with_redirects(self, url, rotate=False, stream=False, base_headers=None):
        current_url = url

        for _ in range(MAX_REDIRECTS):
            headers = build_headers(current_url, rotate, base_headers)

            try:
                r = session.get(
                    current_url,
                    headers=headers,
                    timeout=(TIMEOUT_CONNECT, TIMEOUT_READ),
                    verify=False,
                    allow_redirects=False,
                    stream=stream,
                )
            except Exception:
                return None

            if r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get("Location")
                if not location:
                    return None
                current_url = urllib.parse.urljoin(current_url, location)
                continue

            r.url = current_url
            return r

        return None

    def do_GET(self):
        target_url = self.parse_target_url()
        if not target_url:
            self.send_error(400)
            return

        target_url = urllib.parse.unquote_plus(target_url)

        if ".m3u8" in target_url.lower():
            self.serve_manifest(target_url)
        else:
            self.serve_binary(target_url)

    # ---------------- MANIFEST ----------------

    def serve_manifest(self, original_url):
        r = None

        with self.server.lock:
            cached = self.server.resolved_cache.get(original_url)

        if cached:
            r = self.fetch_with_redirects(cached)
            if not self._valid_manifest(r):
                with self.server.lock:
                    self.server.resolved_cache.pop(original_url, None)
                r = None

        if r is None:
            r = self.fetch_with_redirects(original_url, rotate=True)
            if not self._valid_manifest(r):
                self.send_error(502)
                return

            with self.server.lock:
                self.server.resolved_cache[original_url] = r.url

        base_url = r.url.rsplit("/", 1)[0] + "/"

        output = []
        for line in r.text.splitlines():
            line = line.strip()
            if not line:
                continue

            if line.startswith("#"):
                if "#EXT-X-KEY" in line:
                    line = self.rewrite_key(line, base_url)
                output.append(line)
            else:
                abs_url = urllib.parse.urljoin(base_url, line)
                output.append(self.make_proxy_url(abs_url))

        content = "\n".join(output).encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _valid_manifest(self, r):
        return r and r.status_code == 200 and "#EXTM3U" in r.text

    # ---------------- SEGMENTS / KEYS ----------------

    def serve_binary(self, url):
        r = self.fetch_with_redirects(url, rotate=True, stream=True)

        if not r or r.status_code != 200:
            self.send_error(502)
            return

        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.end_headers()

        try:
            for chunk in r.iter_content(65536):
                if chunk:
                    self.wfile.write(chunk)
        except Exception:
            pass
        finally:
            r.close()

    def rewrite_key(self, line, base_url):
        match = re.search(r'URI=["\'](.*?)["\']', line)
        if not match:
            return line

        original = match.group(1)
        abs_key = urllib.parse.urljoin(base_url, original)
        return line.replace(original, self.make_proxy_url(abs_key))

    def make_proxy_url(self, url):
        return f"http://{PROXY_HOST}:{self.server.server_port}/?url={urllib.parse.quote_plus(url)}"

# -------------------- SERVER --------------------

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, *args):
        super().__init__(*args)
        self.resolved_cache = {}
        self.lock = threading.Lock()

# -------------------- KODI ADDON --------------------

class HLSAddon:
    def __init__(self, handle=None):
        self.handle = int(handle) if handle and str(handle).isdigit() else 0
        self.port = self.find_free_port()
        self.server = ThreadedHTTPServer((PROXY_HOST, self.port), HLSProxyHandler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def find_free_port(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("", 0))
        port = s.getsockname()[1]
        s.close()
        return port

    # ✅ CORREÇÃO APLICADA AQUI
    def play_stream(self, stream_url, stream_type=None):
        proxy_url = f"http://{PROXY_HOST}:{self.port}/?url={urllib.parse.quote_plus(stream_url)}"

        if KODI:
            item = xbmcgui.ListItem(path=proxy_url)
            item.setProperty("IsPlayable", "true")
            item.setInfo("video", {"Title": "HLS Stream"})
            xbmcplugin.setResolvedUrl(self.handle, True, item)