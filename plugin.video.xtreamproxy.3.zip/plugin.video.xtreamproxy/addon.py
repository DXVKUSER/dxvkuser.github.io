# -*- coding: utf-8 -*-

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import json
import logging

from resources.lib.api import XtreamAPI
from proxy import HLSProxyAddon

# --- Globais ---
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADULT_KEYWORDS = ['adult', 'xxx', '+18', 'private']

# --- Variável Fixa ---
REMOTE_CREDENTIALS_URL = "https://paste.kodi.tv/raw/xiqudipadu"

# --- Funções de Utilitário ---

def get_remote_credentials():
    try:
        xbmc.log(f"[ADDON] Tentando baixar credenciais de: {REMOTE_CREDENTIALS_URL}", level=xbmc.LOGINFO)
        response = requests.get(REMOTE_CREDENTIALS_URL, timeout=15)
        response.raise_for_status()
        data = json.loads(response.text)
        return data.get('server'), data.get('username'), data.get('password')
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ADDON] Erro de conexão ou requisição ao baixar credenciais: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Conexão", "Não foi possível baixar as credenciais do servidor remoto.")
        return None, None, None
    except (ValueError, json.JSONDecodeError):
        xbmc.log("[ADDON] Erro: O arquivo de credenciais remoto não é um JSON válido.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Credenciais", "O arquivo de credenciais está inválido.")
        return None, None, None

# --- Funções de Navegação e Reprodução ---

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_dir(name, query, icon='DefaultFolder.png', fanart='DefaultFolder.png', is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
    url = build_url(query)
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def main_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Menu Principal")
    add_dir("Canais Ao Vivo", {'action': 'list_live_categories'})
    add_dir("Filmes (VOD)", {'action': 'list_vod_categories'})
    add_dir("Séries", {'action': 'list_series_categories'})
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_live_categories(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias Ao Vivo")
    categories = api.get_live_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    
    adult_filter_enabled = ADDON.getSettingBool('adult_filter')
    
    add_dir("Todos os Canais", {'action': 'list_live_streams', 'category_id': '0'})
    for category in categories:
        if adult_filter_enabled and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(category['category_name'], {'action': 'list_live_streams', 'category_id': category['category_id']})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_live_streams(api, category_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Canais Ao Vivo")
    streams = api.get_live_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    for stream in streams:
        title = stream.get('name', 'Sem Título')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        
        url = build_url({'action': 'play_with_proxy', 'stream_id': stream_id, 'stream_type': 'live'})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_categories(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias Filmes (VOD)")
    categories = api.get_vod_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    
    adult_filter_enabled = ADDON.getSettingBool('adult_filter')
    
    add_dir("Todos os Filmes", {'action': 'list_vod_streams', 'category_id': '0'})
    for category in categories:
        if adult_filter_enabled and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(category['category_name'], {'action': 'list_vod_streams', 'category_id': category['category_id']})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_vod_streams(api, category_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Filmes (VOD)")
    streams = api.get_vod_streams(category_id)
    if streams is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    for stream in streams:
        title = stream.get('name', 'Sem Título')
        stream_id = stream.get('stream_id')
        stream_icon = stream.get('stream_icon', 'DefaultVideo.png')
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': stream_icon, 'icon': stream_icon, 'fanart': stream_icon})
        li.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_with_proxy', 'stream_id': stream_id, 'stream_type': 'vod'})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_series_categories(api):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Categorias Séries")
    categories = api.get_series_categories()
    if categories is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    adult_filter_enabled = ADDON.getSettingBool('adult_filter')

    add_dir("Todas as Séries", {'action': 'list_series', 'category_id': '0'})
    for category in categories:
        if adult_filter_enabled and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
            continue
        add_dir(category['category_name'], {'action': 'list_series', 'category_id': category['category_id']})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_series(api, category_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Séries")
    series_list = api.get_series(category_id)
    if series_list is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    for series in series_list:
        title = series.get('name', 'Sem Título')
        series_id = series.get('series_id')
        series_icon = series.get('cover', 'DefaultVideo.png')
        add_dir(title, {'action': 'list_episodes', 'series_id': series_id}, series_icon, series_icon)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_episodes(api, series_id):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Episódios")
    series_info = api.get_series_info(series_id)
    if series_info is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes_by_season = series_info.get('episodes', {})
    for season_number, episodes in episodes_by_season.items():
        season_title = f"Temporada {season_number}"
        add_dir(season_title, {'action': 'list_episodes_for_season', 'series_id': series_id, 'season_number': season_number})
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def list_episodes_for_season(api, series_id, season_number):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Episódios")
    series_info = api.get_series_info(series_id)
    if series_info is None:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    episodes = series_info.get('episodes', {}).get(season_number, [])
    for episode in episodes:
        episode_num = episode.get('episode_num')
        episode_title = episode.get('title', f"Episódio {episode_num}")
        episode_id = episode.get('id')
        episode_icon = episode.get('info', {}).get('cover', 'DefaultVideo.png')
        li = xbmcgui.ListItem(label=episode_title)
        li.setArt({'thumb': episode_icon, 'icon': episode_icon})
        li.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_with_proxy', 'stream_id': episode_id, 'stream_type': 'series'})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

def play_with_proxy(api, stream_id, stream_type):
    stream_url = None
    if stream_type == 'live':
        stream_url = api.get_live_stream_url(stream_id)
    elif stream_type == 'vod':
        stream_url = api.get_vod_stream_url(stream_id)
    elif stream_type == 'series':
        stream_url = api.get_series_stream_url(stream_id)
        
    if stream_url:
        xbmc.log(f"[ADDON] URL do stream original para proxy: {stream_url}", level=xbmc.LOGINFO)
        
        proxy_addon = HLSProxyAddon(ADDON_HANDLE)
        proxy_addon.play_stream(stream_url)
    else:
        xbmcgui.Dialog().ok("Erro", "Não foi possível obter a URL do stream.")
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False)

def play_direct_stream(url):
    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True, listitem=li)

# --- Roteador Principal ---

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    server, username, password = get_remote_credentials()

    if not all([server, username, password]):
        return

    api = XtreamAPI(server, username, password)

    if action is None:
        main_menu()
    elif action == 'list_live_categories':
        list_live_categories(api)
    elif action == 'list_live_streams':
        list_live_streams(api, params['category_id'])
    elif action == 'list_vod_categories':
        list_vod_categories(api)
    elif action == 'list_vod_streams':
        list_vod_streams(api, params['category_id'])
    elif action == 'list_series_categories':
        list_series_categories(api)
    elif action == 'list_series':
        list_series(api, params['category_id'])
    elif action == 'list_episodes':
        list_episodes(api, params['series_id'])
    elif action == 'list_episodes_for_season':
        list_episodes_for_season(api, params['series_id'], params['season_number'])
    elif action == 'play_with_proxy':
        play_with_proxy(api, params['stream_id'], params['stream_type'])
    elif action == 'play_direct':
        play_direct_stream(params['url'])

if __name__ == '__main__':
    router(sys.argv[2][1:])