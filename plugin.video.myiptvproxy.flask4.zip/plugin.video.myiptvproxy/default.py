# -*- coding: utf-8 -*-

import sys
import threading
import time
import re
import socket
import traceback
from queue import Empty, Full, Queue
from urllib.parse import parse_qsl, urlparse, urljoin, quote, unquote
from collections import OrderedDict

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Otimizado: importar tudo do Flask do script.module.flask
try:
    from flask import (
        Flask, request, Response, stream_with_context, make_response,
        redirect, jsonify, g, session, current_app, url_for
    )
except ImportError:
    xbmcgui.Dialog().ok("Erro de Dependência", "O módulo 'script.module.flask' não foi encontrado. Por favor, instale-o.")
    sys.exit(1)

# --- Configuração do Addon e Globais ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

# --- Configuração do Proxy e Conexão ---
DEFAULT_EXOPLAYER_HEADERS = {
    'User-Agent': 'ExoPlayer/2.18.1 (Linux; Android 10) ExoPlayerLib/2.18.1',
    'Accept': 'application/vnd.apple.mpegurl, application/x-mpegurl, application/octet-stream, */*',
    'Accept-Encoding': 'gzip, deflate, identity',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'video/mp2t, audio/aac, audio/mpeg, audio/mp4, video/mp4, application/x-mpegURL',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
}
BLOCKED_RESPONSE_HEADERS = ['transfer-encoding', 'connection', 'content-encoding', 'keep-alive', 'content-length']

# --- Inicialização da Aplicação Flask e Globais do Servidor ---
addon_path = ADDON.getAddonInfo('path')
app = Flask(__name__, root_path=addon_path)
app.debug = False
SERVER_THREAD = None
SERVER_PORT = None
SERVER_LOCK = threading.Lock()

# --- Funções de Configuração ---
def get_setting_int(setting_id: str, default_value: int) -> int:
    try: return int(ADDON.getSetting(setting_id))
    except (ValueError, TypeError): return default_value

def get_setting_float(setting_id: str, default_value: float) -> float:
    try: return float(ADDON.getSetting(setting_id))
    except (ValueError, TypeError): return default_value

def get_setting_bool(setting_id: str, default_value: bool) -> bool:
    try: return ADDON.getSettingBool(setting_id)
    except Exception: return default_value

REQUEST_RETRIES = max(get_setting_int('request_retries', 8), 4)
REQUEST_TIMEOUT = max(get_setting_float('request_timeout', 12.0), 8.0)
CONNECTION_POOL_SIZE = max(get_setting_int('connection_pool_size', 8), 6)

# --- Resolvedor DoH (DNS-over-HTTPS) ---
DOH_RESOLVER_URL = 'https://cloudflare-dns.com/dns-query'
DNS_CACHE = {}
DNS_CACHE_TTL = 300

def resolve_hostname_doh(hostname: str) -> str or None:
    now = time.time()
    cached = DNS_CACHE.get(hostname)
    if cached and now < cached[1]:
        return cached[0]

    headers = {'accept': 'application/dns-json'}
    params = {'name': hostname, 'type': 'A'}
    for attempt in range(3):
        try:
            resp = requests.get(DOH_RESOLVER_URL, headers=headers, params=params, timeout=2)
            resp.raise_for_status()
            data = resp.json()
            if data.get("Status") == 0 and "Answer" in data:
                for answer in data["Answer"]:
                    if answer.get("type") == 1:
                        ip = answer.get("data")
                        DNS_CACHE[hostname] = (ip, now + DNS_CACHE_TTL)
                        xbmc.log(f"[IPTV PROXY DOH] {hostname} => {ip}", xbmc.LOGINFO)
                        return ip
        except Exception as e:
            xbmc.log(f"[IPTV PROXY DOH] Erro ao resolver {hostname} via DoH (tentativa {attempt+1}): {e}", xbmc.LOGWARNING)
            time.sleep(0.2)
    return None

def get_url_with_resolved_ip(url: str) -> str:
    try:
        parsed = urlparse(url)
        if not parsed.hostname: return url
        
        ip = resolve_hostname_doh(parsed.hostname) if get_setting_bool('enable_doh', True) else None
        if not ip:
            try: ip = socket.gethostbyname(parsed.hostname)
            except socket.gaierror: return url

        if ip and parsed.hostname != ip:
            netloc = ip
            if parsed.port: netloc += f":{parsed.port}"
            if parsed.username: netloc = f"{parsed.username}:{parsed.password or ''}@{netloc}"
            return parsed._replace(netloc=netloc).geturl()
    except Exception:
        pass
    return url

# --- Classes de Gerenciamento de Conexão e Cache ---
class LRUCache:
    def __init__(self, capacity_bytes: int):
        self.capacity, self.cache, self.current_size, self.lock = capacity_bytes, OrderedDict(), 0, threading.Lock()
    def get(self, key: str) -> bytes or None:
        with self.lock:
            if key not in self.cache: return None
            self.cache.move_to_end(key)
            return self.cache[key]
    def put(self, key: str, value: bytes):
        with self.lock:
            value_size = sys.getsizeof(value)
            if value_size > self.capacity: return
            if key in self.cache: self.current_size -= sys.getsizeof(self.cache.pop(key))
            while self.current_size + value_size > self.capacity: self.current_size -= sys.getsizeof(self.cache.popitem(last=False)[1])
            self.cache[key], self.current_size = value, self.current_size + value_size
    def clear(self):
        with self.lock: self.cache.clear(); self.current_size = 0

class ConnectionPool:
    def __init__(self, size=CONNECTION_POOL_SIZE):
        self.pool = Queue(maxsize=size)
        self.size = size
        for _ in range(self.size): self._add_session()
    def _add_session(self):
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=self.size, pool_maxsize=self.size*2)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        try: self.pool.put_nowait(session)
        except Full: session.close()
    def get_session(self) -> requests.Session:
        try: return self.pool.get(timeout=2)
        except Empty: 
            self._add_session() 
            return self.pool.get()
    def return_session(self, session: requests.Session):
        try: self.pool.put_nowait(session)
        except Full: session.close()

connection_pool = ConnectionPool()
video_cache = LRUCache(capacity_bytes=20 * 1024 * 1024)

# --- Lógica Principal do Proxy ---
def _fetch_url(url: str, session: requests.Session, headers: dict = None, stream=False):
    req_headers = DEFAULT_EXOPLAYER_HEADERS.copy()
    original_host = urlparse(url).hostname
    if 'Host' not in req_headers and original_host:
        req_headers['Host'] = original_host
    if headers: req_headers.update(headers)
    
    url_to_fetch, last_exception = get_url_with_resolved_ip(url), ""
    for attempt in range(REQUEST_RETRIES):
        try:
            response = session.get(url_to_fetch, headers=req_headers, stream=stream, timeout=REQUEST_TIMEOUT, allow_redirects=True, verify=False)
            response.raise_for_status()
            return response, None
        except requests.exceptions.RequestException as e:
            last_exception = str(e)
            if hasattr(e, 'response') and e.response and 400 <= e.response.status_code < 500:
                return None, f"Erro de Cliente: {e.response.status_code}"
            xbmc.log(f"[IPTV PROXY] Erro ao buscar {url} (tentativa {attempt+1}): {e}", xbmc.LOGWARNING)
            time.sleep(0.1 * (2 ** attempt))
    return None, f"Falha ao buscar {url} após {REQUEST_RETRIES} tentativas. Último erro: {last_exception}"

def _ts_brute_stream_generator(ts_url: str, start_byte: int = 0, original_stream_url: str = None):
    """
    Gera o stream de um segmento .ts, reconectando indefinidamente para nunca fechar o canal.
    """
    session = connection_pool.get_session()
    consecutive_failures = 0
    original_host = urlparse(original_stream_url).hostname if original_stream_url else urlparse(ts_url).hostname

    try:
        while True:
            req_headers = DEFAULT_EXOPLAYER_HEADERS.copy()
            if original_host:
                req_headers['Host'] = original_host
            req_headers['Range'] = f'bytes={start_byte}-'

            url_to_fetch = get_url_with_resolved_ip(ts_url)
            response = None
            try:
                response = session.get(url_to_fetch, headers=req_headers, stream=True, timeout=REQUEST_TIMEOUT, verify=False)
                response.raise_for_status()
                consecutive_failures = 0

                stream_had_data = False
                for chunk in response.iter_content(chunk_size=1024 * 64):
                    if chunk:
                        stream_had_data = True
                        yield chunk
                        start_byte += len(chunk)

                response.close()

                # Se não recebeu dados, espere antes de tentar de novo
                if not stream_had_data:
                    consecutive_failures += 1
                    xbmc.log(f"[IPTV PROXY] Sem dados do stream {ts_url}. Reconectando... (Falha {consecutive_failures})", xbmc.LOGINFO)
                    time.sleep(min(0.5 * (2 ** min(consecutive_failures, 5)), 5))
                else:
                    time.sleep(0.05)
                continue

            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, requests.exceptions.ChunkedEncodingError) as e:
                consecutive_failures += 1
                xbmc.log(f"[IPTV PROXY] Erro de conexão para {ts_url}: {e}. Reconectando...", xbmc.LOGWARNING)
                time.sleep(min(0.5 * (2 ** min(consecutive_failures, 5)), 5))
            except Exception as e:
                consecutive_failures += 1
                xbmc.log(f"[IPTV PROXY] Erro inesperado no stream {ts_url}: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
                time.sleep(1)
            finally:
                if response: response.close()
    finally:
        xbmc.log(f"[IPTV PROXY] Saindo do gerador de stream para {ts_url}.", xbmc.LOGINFO)
        connection_pool.return_session(session)

# --- Rotas da Aplicação Flask ---
@app.route('/stream')
def stream_handler():
    remote_url = request.args.get('url')
    original_url = request.args.get('original_url', remote_url)
    if not remote_url:
        return make_response("URL não fornecida.", 400)

    # Caso playlist m3u8
    if remote_url.endswith('.m3u8'):
        session = connection_pool.get_session()
        try:
            response, error = _fetch_url(remote_url, session)
            if error or not response:
                return make_response(f"Falha ao buscar playlist: {error}", 502)

            proxy_base = f"http://127.0.0.1:{SERVER_PORT}/stream?original_url={quote(remote_url)}&url="
            response_data = []
            for line in response.text.splitlines():
                line = line.strip()
                if not line: continue
                if line.startswith('#'):
                    if 'URI="' in line:
                        uri_match = re.search(r'URI="([^"]+)"', line)
                        if uri_match:
                            uri = uri_match.group(1)
                            full_uri = urljoin(remote_url, uri)
                            line = line.replace(uri, proxy_base + quote(full_uri))
                elif not line.startswith('http'):
                    full_line = urljoin(remote_url, line)
                    line = proxy_base + quote(full_line)
                else:
                    line = proxy_base + quote(line)
                response_data.append(line)
            
            content = '\n'.join(response_data).encode('utf-8')
            resp = make_response(content)
            
            for h_key, h_val in response.headers.items():
                if h_key.lower() not in BLOCKED_RESPONSE_HEADERS:
                    resp.headers[h_key] = h_val
            resp.headers['Content-Type'] = response.headers.get('Content-Type', 'application/vnd.apple.mpegurl')
            return resp
        finally:
            connection_pool.return_session(session)

    # Caso segmento TS
    elif re.search(r'\.ts(\?.*)?$', remote_url, re.IGNORECASE):
        # Captura o Range enviado pelo player (ex: bytes=12345-)
        range_header = request.headers.get('Range')
        start_byte = 0
        if range_header:
            match = re.match(r'bytes=(\d+)-', range_header)
            if match:
                start_byte = int(match.group(1))
        generator = _ts_brute_stream_generator(remote_url, start_byte, original_url)
        resp = Response(stream_with_context(generator), mimetype='video/mp2t')
        # Copia cabeçalhos importantes para manter compatibilidade
        if range_header:
            resp.headers['Content-Range'] = f"bytes {start_byte}-/*"
            resp.status_code = 206  # Partial Content
        return resp

    # Demais tipos de arquivo
    else:
        session = connection_pool.get_session()
        try:
            response, error = _fetch_url(remote_url, session, stream=True)
            if error or not response:
                return make_response(f"Falha ao buscar recurso: {error}", 502)
            def generate():
                for chunk in response.iter_content(1024*1024):
                    if chunk: yield chunk
            
            resp = Response(stream_with_context(generate()), status=response.status_code)
            for k, v in response.headers.items():
                if k.lower() not in BLOCKED_RESPONSE_HEADERS:
                    resp.headers[k] = v
            return resp
        finally:
            connection_pool.return_session(session)

# --- Funções de Controle do Addon e do Servidor ---
def run_server():
    global SERVER_THREAD, SERVER_PORT
    with SERVER_LOCK:
        if SERVER_THREAD and SERVER_THREAD.is_alive():
            return
        for port in range(50000, 50021):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('127.0.0.1', port))
                SERVER_PORT = port
                break
            except OSError:
                continue
        else:
            xbmc.log("[IPTV PROXY] Não foi possível encontrar uma porta livre.", xbmc.LOGERROR)
            return

        def serve_forever():
            try:
                from werkzeug.serving import run_simple
                run_simple('127.0.0.1', SERVER_PORT, app, use_reloader=False, use_debugger=False)
            except Exception as e:
                xbmc.log(f"[IPTV PROXY] Erro no servidor Flask: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)

        SERVER_THREAD = threading.Thread(target=serve_forever, daemon=True)
        SERVER_THREAD.start()
        xbmc.log(f"[IPTV PROXY] Servidor Flask iniciado em http://127.0.0.1:{SERVER_PORT}", xbmc.LOGINFO)

def run_addon():
    run_server()
    if not SERVER_PORT:
        xbmcgui.Dialog().ok("Erro de Proxy", "Não foi possível iniciar o servidor proxy local.")
        return

    action = _ARGS.get('action')
    url = _ARGS.get('url')
    title = _ARGS.get('title', "Stream")

    if action == 'play' and url:
        local_url = f"http://127.0.0.1:{SERVER_PORT}/stream?url={quote(url)}"
        list_item = xbmcgui.ListItem(path=local_url)
        list_item.setInfo('video', {'title': title, 'mediatype': 'video'})
        list_item.setProperty('IsPlayable', 'true')

        if '.m3u8' in url:
            list_item.setMimeType('application/vnd.apple.mpegurl')
        elif re.search(r'\.ts(\?.*)?$', url, re.IGNORECASE):
            list_item.setMimeType('video/mp2t')
        else:
            list_item.setMimeType('application/octet-stream')

        xbmcplugin.setResolvedUrl(handle=_HANDLE, succeeded=True, listitem=list_item)
    
    elif action == 'settings':
        ADDON.openSettings()
        
    else:
        test_title, test_url = "Canal de Teste (HLS)", "https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8"
        plugin_play_url = f"{sys.argv[0]}?action=play&url={quote(test_url)}&title={quote(test_title)}"
        li = xbmcgui.ListItem(label=test_title)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': test_title, 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=plugin_play_url, listitem=li, isFolder=False)
        
        settings_li = xbmcgui.ListItem(label="Configurações do Addon")
        settings_url = f"{sys.argv[0]}?action=settings"
        xbmcplugin.addDirectoryItem(handle=_HANDLE, url=settings_url, listitem=settings_li, isFolder=False)

        xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    try:
        run_addon()
    except Exception as e:
        xbmc.log(f"[IPTV PROXY ADDON] Erro não capturado: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro Inesperado", f"Ocorreu um erro: {e}")