import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
from collections import OrderedDict, deque
from requests.exceptions import Timeout, ConnectionError, HTTPError

# --- Configurações Iniciais do Addon ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HANDLE = int(sys.argv[1])

proxy_host_setting = ADDON.getSetting('proxy_host') or '127.0.0.1'
PROXY_HOST = proxy_host_setting.strip() if proxy_host_setting else '127.0.0.1'

DEFAULT_PROXY_PORT = random.randint(20000, 65000)
MAX_PORT_ATTEMPTS = 10

def get_int_setting(key, default):
    try:
        value = int(ADDON.getSetting(key) or default)
        if value < 1:
            value = default
        return value
    except Exception:
        return default

max_cache_mb = get_int_setting('max_cache_mb', 64)
MAX_CACHE_SIZE_BYTES = max_cache_mb * 1024 * 1024

max_segment_size_mb = get_int_setting('max_segment_size_mb', 8)
MAX_SEGMENT_SIZE_BYTES = max_segment_size_mb * 1024 * 1024

CACHE_TYPE = 'ram'

def get_bool_setting(key, default):
    try:
        return ADDON.getSetting(key) == 'true'
    except Exception:
        return default

SIMULATE_ERRORS = get_bool_setting('simulate_errors', False)

IS_DEV_ENV = os.environ.get('KODI_ENV') == 'development'
if SIMULATE_ERRORS and not IS_DEV_ENV:
    SIMULATE_ERRORS = False

ENABLE_IPV6 = get_bool_setting('enable_ipv6', True)

def get_float_setting(key, default):
    try:
        return float(ADDON.getSetting(key) or default)
    except Exception:
        return default

# Conexão mais agressiva, mas com stream timeout suficiente para dados chegarem
CONNECTION_TIMEOUT = get_float_setting('connection_timeout', 2.0) # Reduzido para resposta mais rápida
STREAM_TIMEOUT = get_float_setting('stream_timeout', 8.0) # Aumentado para permitir buffers maiores

LOG_MAX_BYTES = get_int_setting('log_max_bytes', 1048576)
LOG_BACKUP_COUNT = get_int_setting('log_backup_count', 3)

CHUNK_SIZE = 65536 # Tamanho do chunk para leitura e escrita
PREFETCH_SEGMENTS = get_int_setting('prefetch_segments', 3) # Quantos segmentos pré-buscar
MAX_PREFETCH_QUEUE_SIZE = get_int_setting('max_prefetch_queue', 5) # Tamanho máximo da fila de pré-fetch

LOG_FILE = xbmcvfs.translatePath(ADDON.getSetting('log_file_path') or 'special://temp/hlsproxy.log')
USER_BLOCKLIST = set(filter(None, (ADDON.getSetting('host_blocklist') or '').split(',')))

try:
    loglevel_raw = ADDON.getSetting("loglevel")
    loglevel = loglevel_raw.upper().strip() if loglevel_raw else "WARNING"
    LOG_LEVEL = int(getattr(logging, loglevel, logging.WARNING))
except Exception:
    LOG_LEVEL = logging.WARNING

log_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
)
logging.basicConfig(
    handlers=[log_handler],
    level=LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s'
)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.5 (WebOS; U; SmartTV; LG NetCast.TV-2013) AppleWebKit/537.41 (KHTML, like Gecko) WebAppManager"
]
ACCEPT_LANGUAGES = ["pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "en-US,en;q=0.9,pt;q=0.8", "es-ES,es;q=0.9,en;q=0.8"]
PLAYER_HEADERS = [{"User-Agent": USER_AGENTS[i], "Accept": "*/*", "Accept-Language": lang, "Origin": "", "Referer": ""} for i, lang in zip(range(len(USER_AGENTS)), ACCEPT_LANGUAGES * 2)]

def clean_headers(headers):
    sensitive = ['X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP', 
                'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP']
    return {k: v for k, v in headers.items() if k.lower() not in [s.lower() for s in sensitive]} # Comparação case-insensitive

def random_player_headers(url):
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.hostname}"
    headers = random.choice(PLAYER_HEADERS).copy()
    headers['Origin'] = origin
    headers['Referer'] = origin
    # Não embaralhar as chaves, mantendo ordem previsível para alguns servidores
    # keys = list(headers.keys())
    # random.shuffle(keys)
    # return {k: headers[k] for k in keys}
    return headers

def jitter(base, percent=0.1):
    return base + base * random.uniform(-percent, percent)

HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': random.choice(USER_AGENTS),
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive'
})
HTTP_SESSION.trust_env = False

# New functions for IP address handling
def is_ipv6_address(addr):
    try:
        return isinstance(ipaddress.ip_address(addr), ipaddress.IPv6Address)
    except Exception:
        return False

def join_host_port(host, port):
    if is_ipv6_address(host):
        return f'[{host}]:{port}'
    return f'{host}:{port}'

class DoHResolver:
    def __init__(self, resolver_urls=None, cache_ttl=300, retries=2, retry_delay=0.7):
        self.resolver_urls = resolver_urls or [
            'https://cloudflare-dns.com/dns-query',
            'https://dns.nextdns.io',
        ]
        self.cache_ttl = cache_ttl
        self.retries = retries
        self.retry_delay = retry_delay
        self._cache = {}
        self.q_types = ('AAAA', 'A') if ENABLE_IPV6 else ('A',)
        logging.debug(f"DoHResolver initialized with resolvers: {self.resolver_urls}, IPv6 enabled: {ENABLE_IPV6}")

    def resolve(self, hostname, depth=0, max_depth=5):
        if depth > max_depth:
            logging.error(f"Max CNAME resolution depth reached for {hostname}. Aborting DNS resolution.")
            return None
        if self._is_valid_ip(hostname):
            logging.debug(f"Hostname {hostname} is already an IP address.")
            return hostname

        cached_entry = self._cache.get(hostname)
        if cached_entry and time.time() < cached_entry[1]:
            logging.debug(f"Hostname {hostname} found in DoH cache: {cached_entry[0]}")
            return cached_entry[0]
        
        logging.debug(f"Attempting to resolve hostname {hostname} via DoH (depth: {depth})")
        # Rotacionar os resolvers para distribuir a carga e evitar um único ponto de falha
        random.shuffle(self.resolver_urls) 
        for resolver_url in self.resolver_urls:
            for q_type in self.q_types:
                for attempt in range(self.retries):
                    try:
                        params = {'name': hostname, 'type': q_type}
                        headers = {'accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                        response = HTTP_SESSION.get(resolver_url, params=params, headers=headers, timeout=3) # Timeout reduzido para DoH
                        response.raise_for_status()
                        data = response.json()
                        ip_address = self._parse_doh_response(data, hostname, q_type, depth)
                        if ip_address:
                            # Usar TTL do DNS ou um mínimo seguro
                            ttl = data.get("Answer", [{}])[0].get("TTL", self.cache_ttl)
                            # Se o TTL for muito baixo, usar um mínimo para evitar consultas excessivas
                            if ttl < 60: ttl = 60 
                            self._cache[hostname] = (ip_address, time.time() + ttl)
                            logging.debug(f"Successfully resolved {hostname} to {ip_address} (TTL: {ttl}s) using {resolver_url} for type {q_type}.")
                            return ip_address
                    except Exception as e:
                        logging.warning(f"DoH resolution attempt {attempt + 1}/{self.retries} for {hostname} (type {q_type}) via {resolver_url} failed: {e}")
                        if attempt < self.retries - 1:
                            time.sleep(jitter(self.retry_delay * (attempt + 1) / self.retries)) # Jitter com backoff
                        else:
                            continue # Tentar próximo q_type ou resolver_url
        logging.warning(f"Failed to resolve hostname {hostname} after all attempts.")
        return None

    def _parse_doh_response(self, data, hostname, q_type, depth):
        type_map = {'A': 1, 'AAAA': 28}
        # Priorizar a resposta exata
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map[q_type] and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data")
        # Em seguida, procurar CNAMEs
        for answer in data.get("Answer", []):
            if answer.get("type") == 5: # CNAME
                cname = answer.get("data", "").rstrip('.')
                if cname and cname.lower() != hostname.lower(): # Evitar loops de CNAME auto-referenciais
                    logging.debug(f"Found CNAME for {hostname}: {cname}. Resolving CNAME.")
                    return self.resolve(cname, depth + 1)
        return None

    @staticmethod
    def _is_valid_ip(address):
        try:
            # Tenta IPv6 primeiro, depois IPv4 para ser mais eficiente
            ipaddress.ip_address(address)
            return True
        except ValueError:
            return False

class BaseCache:
    def __init__(self, max_bytes):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        logging.info(f"BaseCache initialized with max_bytes: {max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url): raise NotImplementedError
    def add(self, url, data): raise NotImplementedError
    def clear(self): raise NotImplementedError
    def get_stats(self): raise NotImplementedError

class RecentSegmentsCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES, max_segments=100): # Aumentado max_segments
        super().__init__(max_bytes)
        self.segments = OrderedDict()
        self.recent_queue = deque(maxlen=max_segments) # Mantém a ordem de acesso
        self.total_bytes = 0
        self.max_segments = max_segments
        logging.info(f"RecentSegmentsCache initialized with {max_segments} recent segments and {max_bytes / (1024 * 1024):.2f} MB max size.")

    def get(self, url):
        with self.lock:
            data = self.segments.get(url)
            if data:
                self.segments.move_to_end(url) # Move para o final para manter como "recentemente usado"
                if url in self.recent_queue: # O(N) para remover, mas deque é pequeno
                     self.recent_queue.remove(url)
                self.recent_queue.append(url) # Adiciona no final
            return data

    def get_recent_segments(self, count=10): # Aumentado count
        with self.lock:
            recent = list(self.recent_queue)[-count:]
            return [(url, self.segments[url]) for url in recent if url in self.segments]

    def add(self, url, data: bytes):
        with self.lock:
            if url in self.segments:
                # Se já existe, remove o antigo para atualizar o tamanho total antes de adicionar o novo
                self.total_bytes -= len(self.segments.pop(url))
                if url in self.recent_queue:
                    try: self.recent_queue.remove(url)
                    except ValueError: pass # Pode ter sido removido por shrink_to_limit

            self.segments[url] = data
            self.recent_queue.append(url)
            self.total_bytes += len(data)
            self._shrink_to_limit()
            # logging.debug(f"Segment added: {url}. Current cache size: {self.total_bytes / (1024 * 1024):.2f} MB")

    def _shrink_to_limit(self):
        while (self.total_bytes > self.max_bytes or len(self.segments) > self.max_segments) and self.segments:
            # Prioriza remover por tamanho, depois por número de segmentos
            if self.total_bytes > self.max_bytes:
                # Remove o item mais antigo (FIFO)
                old_url, old_data = self.segments.popitem(last=False) 
                self.total_bytes -= len(old_data)
                # Tenta remover da fila de recentes se estiver lá
                if old_url in self.recent_queue: 
                    try: self.recent_queue.remove(old_url)
                    except ValueError: pass
                logging.debug(f"Shrinking RecentSegmentsCache by size: removed {old_url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")
            elif len(self.segments) > self.max_segments:
                # Se o limite de segmentos for atingido, remove o mais antigo
                old_url, old_data = self.segments.popitem(last=False)
                self.total_bytes -= len(old_data)
                if old_url in self.recent_queue:
                    try: self.recent_queue.remove(old_url)
                    except ValueError: pass
                logging.debug(f"Shrinking RecentSegmentsCache by count: removed {old_url}. Current count: {len(self.segments)}")

    def clear(self):
        with self.lock:
            self.segments.clear()
            self.recent_queue.clear()
            self.total_bytes = 0
            logging.info("RecentSegmentsCache cleared.")

    def get_stats(self):
        with self.lock:
            return {"entries": len(self.segments), "size_MB": round(self.total_bytes / 1048576, 2), "recent_queue": len(self.recent_queue)}

class StreamCache:
    def __init__(self, chunk_cache: BaseCache):
        self.manifest_cache = {}
        self.chunk_cache = chunk_cache
        logging.info("StreamCache initialized.")
        
    def get_manifest(self, url):
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            logging.debug(f"Manifest found in RAM cache: {url}")
            return entry['content']
        logging.debug(f"Manifest not found or expired in RAM cache: {url}")
        return None
        
    def add_manifest(self, url, content, ttl=1):
        self.manifest_cache[url] = {'content': content, 'expires': time.time() + ttl}
        logging.debug(f"Manifest added to RAM cache: {url} with TTL {ttl}s.")
        
    def get_segment(self, url): return self.chunk_cache.get(url)
    def add_segment(self, url, data): self.chunk_cache.add(url, data)
    def get_recent_segments(self, count=5):
        if hasattr(self.chunk_cache, 'get_recent_segments'):
            return self.chunk_cache.get_recent_segments(count)
        return []
    def clear(self):
        self.manifest_cache.clear()
        self.chunk_cache.clear()
        logging.info("Stream cache (manifests and chunks) cleared.")

class UpstreamFetcher:
    def __init__(self, session, doh_resolver):
        self.session = session
        self.doh_resolver = doh_resolver
        logging.info("UpstreamFetcher initialized with IP protection")

    def fetch(self, url, stream=False, original_headers=None):
        try:
            headers = random_player_headers(url)
            if original_headers:
                original_headers = clean_headers(original_headers)
                # Mesclar apenas cabeçalhos importantes da requisição original
                for k, v in original_headers.items():
                    if k.lower() in ('authorization', 'cookie', 'range'): # Adicionado 'range'
                        headers[k] = v

            parsed_url = urllib.parse.urlparse(url)
            resolved_ip = None
            if parsed_url.hostname:
                # Adicionado cache local para evitar múltiplas chamadas de DoH para o mesmo hostname em um curto período
                # (o cache DoHResolver já faz isso, mas aqui reforça para o fetcher)
                resolved_ip = self.doh_resolver.resolve(parsed_url.hostname)
            req_url = url
            if resolved_ip and resolved_ip != parsed_url.hostname:
                port = parsed_url.port if parsed_url.port else (443 if parsed_url.scheme == 'https' else 80)
                scheme = parsed_url.scheme
                path = parsed_url.path or ''
                query = f'?{parsed_url.query}' if parsed_url.query else ''
                host_port = join_host_port(resolved_ip, port)
                req_url = f"{scheme}://{host_port}{path}{query}"
                headers['Host'] = parsed_url.hostname # Essencial para servidores virtuais

            max_retries = 10 # Aumentado o número de retries para maior resiliência
            base_delay = 0.05 # Reduzido o atraso base
            
            # Adicionado uma pequena aleatoriedade no timeout para evitar thundering herd
            current_connection_timeout = jitter(CONNECTION_TIMEOUT, 0.1)
            current_stream_timeout = jitter(STREAM_TIMEOUT, 0.1)

            for attempt in range(max_retries):
                try:
                    resp = self.session.get(req_url, stream=stream, 
                                          timeout=(current_connection_timeout, current_stream_timeout),
                                          headers=headers, allow_redirects=True)
                    # Códigos 5xx devem ser retentados
                    if resp.status_code >= 500:
                        resp.raise_for_status() 
                    # Considerar 429 Too Many Requests como retentável
                    if resp.status_code == 429:
                        logging.warning(f"Upstream returned 429 Too Many Requests for {url}. Retrying.")
                        resp.close()
                        raise HTTPError("Too Many Requests")

                    return resp
                except (Timeout, ConnectionError, HTTPError) as e:
                    logging.warning(f"Attempt {attempt + 1}/{max_retries} failed for {url}: {e}")
                    if attempt == max_retries - 1:
                        logging.error(f"All {max_retries} attempts failed for {url}. Giving up.")
                        raise e
                    # Atraso exponencial com jitter
                    delay = (base_delay * (2 ** attempt)) + random.uniform(0.01, 0.2)
                    logging.info(f"Waiting for {delay:.2f} seconds before next retry.")
                    time.sleep(delay)
                except Exception as ex:
                    logging.error(f"An unexpected non-recoverable error occurred while fetching {url}: {ex}", exc_info=True)
                    # Não retentar em erros inesperados que não sejam de rede/HTTP
                    return None
        except Exception as ex:
            logging.error(f"Failed to fetch {url} after all retries or due to a critical error: {ex}", exc_info=True)
            return None

class SingleConnectionSegmentBuffer:
    """
    Buffer de segmentos vindos do server, para tentar manter uma conexão só.
    Otimizado com pré-fetching e gerenciamento de fila.
    """
    def __init__(self, fetcher, manifest_url):
        self.fetcher = fetcher
        self.manifest_url = manifest_url
        self.manifest_obj = None
        self.segments_data = {}  # {segment_url: data}
        self.manifest_last_fetch = 0
        self.manifest_ttl = 2
        self.running = False
        self.lock = threading.Lock()
        self.thread = None
        self.prefetch_queue = deque(maxlen=MAX_PREFETCH_QUEUE_SIZE) # Fila de URLs para pré-fetch
        self.fetched_events = {} # Para sinalizar que um segmento foi pré-buscado
        self.active_segment_urls = deque(maxlen=50) # Rastreia os últimos N segmentos ativos para prefetch
        logging.info("SingleConnectionSegmentBuffer initialized for %s", manifest_url)

    def _fetch_manifest(self):
        resp = self.fetcher.fetch(self.manifest_url)
        if resp and resp.ok:
            try:
                self.manifest_obj = m3u8.loads(resp.text, uri=self.manifest_url)
                self.manifest_last_fetch = time.time()
                # Usar target_duration para TTL, mas com um mínimo razoável
                self.manifest_ttl = max(1, int(getattr(self.manifest_obj, "target_duration", 2) * 0.8)) 
                logging.debug("Manifest fetched and updated for SingleConnection. New TTL: %s", self.manifest_ttl)
                return True
            except Exception as e:
                logging.error(f"Failed to parse manifest for SingleConnection: {e}")
                return False
        return False

    def _background_segment_fetch(self):
        self.running = True
        fetch_interval = 0.3 # Intervalo mais frequente para busca
        while self.running:
            try:
                # Atualizar manifesto se expirado ou se houver poucas URLs na fila
                if time.time() - self.manifest_last_fetch > self.manifest_ttl or len(self.prefetch_queue) < PREFETCH_SEGMENTS:
                    self._fetch_manifest()
                    # Limpar prefetch_queue ao atualizar manifesto para evitar busca de segmentos obsoletos
                    if self.manifest_obj:
                        with self.lock:
                            self.prefetch_queue.clear() 
                            # Preencher a fila de pré-fetch com os próximos segmentos do manifesto
                            current_segments = [s.absolute_uri for s in self.manifest_obj.segments]
                            for i in range(len(current_segments)):
                                if current_segments[i] not in self.segments_data and \
                                   current_segments[i] not in self.prefetch_queue:
                                    self.prefetch_queue.append(current_segments[i])
                                    if len(self.prefetch_queue) >= MAX_PREFETCH_QUEUE_SIZE:
                                        break
                                
                if self.manifest_obj:
                    # Tentar pré-buscar da fila de prefetch
                    segment_to_fetch = None
                    with self.lock:
                        if self.prefetch_queue:
                            # Priorizar segmentos que o player pode precisar em breve
                            # Se a fila de prefetch está muito cheia, esvaziar os mais antigos
                            if len(self.prefetch_queue) > MAX_PREFETCH_QUEUE_SIZE:
                                segment_to_fetch = self.prefetch_queue.popleft()
                            else:
                                # Pegar o próximo da fila, mas não remover ainda para re-tentar se falhar
                                segment_to_fetch = self.prefetch_queue[0] 
                    
                    if segment_to_fetch and segment_to_fetch not in self.segments_data:
                        logging.debug(f"[SingleConnection] Attempting to pre-fetch segment: {segment_to_fetch}")
                        resp = self.fetcher.fetch(segment_to_fetch)
                        if resp and resp.ok:
                            with self.lock:
                                self.segments_data[segment_to_fetch] = resp.content
                                # Remover da fila de prefetch se o download foi bem-sucedido
                                if segment_to_fetch in self.prefetch_queue:
                                    try: self.prefetch_queue.remove(segment_to_fetch)
                                    except ValueError: pass
                                self.fetched_events[segment_to_fetch] = True # Sinalizar que foi buscado
                                logging.debug(f"[SingleConnection] Pre-fetched {segment_to_fetch}. Buffer size: {len(self.segments_data)}")
                            resp.close()
                        else:
                            logging.warning(f"[SingleConnection] Failed to pre-fetch {segment_to_fetch}.")
                            # Se falhou, mover para o final da fila ou re-adicionar para tentar mais tarde
                            with self.lock:
                                if segment_to_fetch in self.prefetch_queue:
                                    try: self.prefetch_queue.remove(segment_to_fetch)
                                    except ValueError: pass
                                self.prefetch_queue.append(segment_to_fetch) # Re-adiciona para retry
                            if resp: resp.close()

                    # Limpeza do buffer de segmentos já servidos (FIFO)
                    with self.lock:
                        # Manter um número razoável de segmentos no buffer
                        max_segments_in_buffer = max(50, self.manifest_obj.target_duration * 2) if self.manifest_obj else 50
                        while len(self.segments_data) > max_segments_in_buffer:
                            # Heurística: remover o mais antigo que não está na fila de prefetch
                            oldest_url = next(iter(self.segments_data))
                            if oldest_url not in self.prefetch_queue:
                                self.segments_data.pop(oldest_url, None)
                                self.fetched_events.pop(oldest_url, None)
                            else: # Se o mais antigo está na fila de prefetch, pare a limpeza
                                break

            except Exception as e:
                logging.warning(f"[SingleConnection] Error in background fetch: {e}", exc_info=True)
            time.sleep(fetch_interval) # Pequeno atraso para não consumir CPU em excesso

    def start(self):
        with self.lock:
            if not self.thread or not self.thread.is_alive():
                self._fetch_manifest() # Busca inicial do manifesto
                self.thread = threading.Thread(target=self._background_segment_fetch, daemon=True)
                self.thread.name = "SingleConnFetcher"
                self.thread.start()
                logging.info("SingleConnectionSegmentBuffer background thread started.")

    def stop(self):
        self.running = False
        if self.thread and self.thread.is_alive():
            logging.info("Stopping SingleConnectionSegmentBuffer background thread.")
            self.thread.join(timeout=3) # Tempo maior para join
            if self.thread.is_alive():
                logging.warning("SingleConnectionSegmentBuffer thread did not terminate gracefully.")
        with self.lock:
            self.segments_data.clear()
            self.prefetch_queue.clear()
            self.fetched_events.clear()
            self.active_segment_urls.clear()
            self.manifest_obj = None
            logging.info("SingleConnectionSegmentBuffer resources cleared.")

    def get_segment(self, segment_url):
        with self.lock:
            data = self.segments_data.get(segment_url)
            if data:
                # Se o segmento é solicitado, indica que ele é "ativo"
                if segment_url in self.prefetch_queue:
                    try: self.prefetch_queue.remove(segment_url)
                    except ValueError: pass
                # Adicionar à lista de URLs ativas para ajudar a identificar os próximos
                if segment_url not in self.active_segment_urls:
                    self.active_segment_urls.append(segment_url)
                return data
            return None

    def add_segment_to_prefetch_queue(self, segment_url):
        with self.lock:
            if segment_url not in self.segments_data and segment_url not in self.prefetch_queue:
                self.prefetch_queue.append(segment_url)
                logging.debug(f"Added {segment_url} to prefetch queue.")


def is_manifest_limit_error(content):
    """
    Detecta se o manifesto retornou erro de limite de usuários.
    """
    if not content:
        return True # Manifesto vazio é um sinal de problema
    txt = content.lower()
    # Adicionadas mais strings para detecção
    if (
        "#mensagem:" in txt and "user" in txt
        or "too many users" in txt
        or "limite" in txt
        or "#limit" in txt
        or "maximum user" in txt
        or "conexoes simultaneas" in txt
        or "many connections" in txt
        or "max session" in txt
        or "#error" in txt
        or "concurrent connection limit" in txt
        or "access denied" in txt # Adicionado
        or "connection refused" in txt # Adicionado
    ):
        return True
    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    # Se o manifesto é muito curto e não contém informações úteis
    if len(lines) <= 2 and not any("extinf" in l for l in lines) and not any(".ts" in l for l in lines):
        logging.warning("Manifest content is suspiciously short or lacking actual stream data.")
        return True
    return False

class ManifestRewriter:
    def __init__(self, content, manifest_url, proxy_base_url):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        logging.debug(f"ManifestRewriter initialized for {manifest_url}. Proxy base: {proxy_base_url}")

    def rewrite(self):
        for playlist in getattr(self.m3u8_obj, 'playlists', []):
            if playlist.uri:
                original_uri = playlist.absolute_uri
                playlist.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                # logging.debug(f"Rewrote playlist URI from {original_uri} to {playlist.uri}")
        for media in getattr(self.m3u8_obj, 'media', []):
            if hasattr(media, 'uri') and media.uri:
                original_uri = media.absolute_uri
                media.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                # logging.debug(f"Rewrote media URI from {original_uri} to {media.uri}")
        for segment in getattr(self.m3u8_obj, 'segments', []):
            if segment.uri:
                original_uri = segment.absolute_uri
                segment.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                # logging.debug(f"Rewrote segment URI from {original_uri} to {segment.uri}")
            if segment.key and segment.key.uri:
                original_uri = segment.key.absolute_uri
                segment.key.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                # logging.debug(f"Rewrote key URI from {original_uri} to {segment.key.uri}")
        rewritten_manifest = self.m3u8_obj.dumps()
        # logging.debug(f"Manifest rewritten successfully. First 200 chars: {rewritten_manifest[:200]}")
        return rewritten_manifest

    @property
    def is_live(self):
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self):
        target_duration = getattr(self.m3u8_obj, 'target_duration', 0)
        if self.is_live and target_duration:
            # TTL mais agressivo para live, para buscar atualizações mais rápido
            ttl = max(1, int(target_duration * 0.5)) # Reduzido de 0.75 para 0.5
            logging.debug(f"Live stream detected. Target duration: {target_duration}s, calculated TTL: {ttl}s.")
            return ttl
        logging.debug("VOD stream detected or no target duration. Default TTL: 600s.")
        return 600

def notify(msg, time_ms=3000): 
    xbmc.executebuiltin(f'Notification({ADDON_NAME},{msg},{time_ms})')

def validate_url(url: str) -> bool:
    u = urllib.parse.urlparse(url)
    if not u.scheme in ('http', 'https'):
        logging.warning(f"Invalid URL scheme for {url}. Must be http or https.")
        return False
    if not u.netloc:
        logging.warning(f"URL has no network location (netloc): {url}.")
        return False
    # Normalizar o hostname para comparação (case-insensitive)
    normalized_hostname = u.hostname.lower() if u.hostname else ''
    if normalized_hostname in [h.lower() for h in USER_BLOCKLIST]:
        logging.warning(f"Hostname {u.hostname} is in the user blocklist for URL: {url}.")
        return False
    return True

def safe_mime_type(url, fallback='application/octet-stream'):
    ext = url.lower().split('?')[0]
    if ext.endswith('.m3u8'): return 'application/vnd.apple.mpegurl'
    if ext.endswith('.ts'): return 'video/mp2t'
    if ext.endswith(('.aac', '.mp4', '.m4a')): return 'audio/mp4' # Adicionado
    if ext.endswith(('.mp4')): return 'video/mp4' # Adicionado
    logging.debug(f"Could not determine specific MIME type for {url}. Using fallback: {fallback}")
    return fallback

def is_port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('127.0.0.1', port))
            return True
        except socket.error:
            return False

class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    single_connection_buffer = None
    single_connection_manifest_url = None

    def __init__(self, stream_cache, fetcher, *args, **kwargs):
        self.cache = stream_cache
        self.fetcher = fetcher
        self.log_level_map = {
            'info': logging.info,
            'warning': logging.warning,
            'error': logging.error,
            'debug': logging.debug
        }
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        pass # Desabilita log padrão do BaseHTTPRequestHandler

    def _log_request(self, message, level='info'):
        log_func = self.log_level_map.get(level, logging.info)
        client_address = self.address_string()
        log_func(f"[{client_address}] {self.command} {self.path} - {message}")

    def do_GET(self):
        # logging.debug("Received GET request for %s", self.path) # Log mais detalhado se necessário
        original_url = "unknown"
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            query_params = urllib.parse.parse_qs(parsed_path.query)
            original_url = query_params.get('url', [''])[0]

            if not original_url:
                self.send_error(400, "Missing 'url' parameter in proxy request")
                self._log_request("Missing 'url' parameter.", level='warning')
                return

            if SIMULATE_ERRORS and random.random() < 0.008:
                # Simular erro mas enviar 200 com corpo vazio para não travar o player
                self._send_response(200, b"", "application/octet-stream")
                self._log_request(f"Simulated 503 error (sent as 200 with empty body) for {original_url}", level='warning')
                return

            self.headers = clean_headers(self.headers)

            if ".m3u8" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected while serving {original_url}", level='info')
        except Exception as ex:
            logging.error("General proxy error for %s: %s", original_url, str(ex), exc_info=True)
            if not self.wfile.closed:
                try: self.send_error(500, "Internal Server Error")
                except Exception: pass # Previne erro se a conexão já estiver fechada

    def _handle_manifest(self, url, max_proxy_retries=3):
        self._log_request(f"Handling manifest: {url}", level='info')
        
        # Correção para evitar loops infinitos de revalidação
        # Se um manifesto falhou muitas vezes em sequência, parar de tentar
        if hasattr(self, '_manifest_fail_count') and self._manifest_fail_count.get(url, 0) >= max_proxy_retries * 2:
            logging.error(f"Manifest {url} failed too many times consecutively. Giving up on it.")
            self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
            return

        for proxy_attempt in range(max_proxy_retries):
            cached = self.cache.get_manifest(url)
            if cached and not is_manifest_limit_error(cached):
                if not cached.strip():
                    self._log_request("Manifesto em cache vazio! Retornando mínimo válido.", level='warning')
                    return self._send_response(200, "#EXTM3U\n", 'application/vnd.apple.mpegurl')
                self._log_request(f"Serving manifest from cache: {url} (Proxy attempt {proxy_attempt + 1})", level='debug')
                
                # Se o buffer de conexão única está ativo e para este manifesto, atualizar a lista de segmentos ativos
                if AdvancedHLSProxyHandler.single_connection_buffer and AdvancedHLSProxyHandler.single_connection_manifest_url == url:
                    try:
                        temp_m3u8 = m3u8.loads(cached, uri=url)
                        for seg in temp_m3u8.segments:
                            AdvancedHLSProxyHandler.single_connection_buffer.add_segment_to_prefetch_queue(seg.absolute_uri)
                    except Exception as e:
                        logging.warning(f"Failed to parse cached manifest for prefetch queue update: {e}")

                return self._send_response(200, cached, 'application/vnd.apple.mpegurl')

            self._log_request(f"Fetching manifest {url} from upstream (Proxy attempt {proxy_attempt + 1})", level='debug')
            response = self.fetcher.fetch(url, original_headers=self.headers)
            if response and response.ok:
                manifest_content = response.text
                if is_manifest_limit_error(manifest_content):
                    self._log_request(f"Manifesto retornou erro de limite de usuários! Ativando modo single-connection (experimental).", level="warning")
                    if AdvancedHLSProxyHandler.single_connection_buffer is None or AdvancedHLSProxyHandler.single_connection_manifest_url != url:
                        # Parar qualquer buffer anterior
                        if AdvancedHLSProxyHandler.single_connection_buffer:
                            AdvancedHLSProxyHandler.single_connection_buffer.stop()
                            AdvancedHLSProxyHandler.single_connection_buffer = None
                            AdvancedHLSProxyHandler.single_connection_manifest_url = None
                        
                        AdvancedHLSProxyHandler.single_connection_buffer = SingleConnectionSegmentBuffer(self.fetcher, url)
                        AdvancedHLSProxyHandler.single_connection_buffer.start()
                        AdvancedHLSProxyHandler.single_connection_manifest_url = url
                    self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl") # Envia manifesto mínimo
                    response.close()
                    # Resetar contador de falhas para este manifesto
                    if hasattr(self, '_manifest_fail_count'): self._manifest_fail_count[url] = 0
                    return
                try:
                    rewriter = ManifestRewriter(manifest_content, response.url, f"http://{self.server.server_address[0]}:{self.server.server_address[1]}/?url=")
                    rewritten_content = rewriter.rewrite()
                    if not rewritten_content.strip():
                        self._log_request("Manifesto reescrito ficou vazio! Retornando mínimo válido.", level="error")
                        response.close()
                        return self._send_response(200, "#EXTM3U\n", 'application/vnd.apple.mpegurl')
                    ttl = rewriter.get_ttl()
                    self.cache.add_manifest(url, rewritten_content, ttl=ttl)
                    self._log_request(f"Manifest {url} fetched, rewritten, cached (TTL: {ttl}s) and served (Proxy attempt {proxy_attempt + 1}).", level='info')
                    
                    # Se o buffer de conexão única está ativo e para este manifesto, atualizar a lista de segmentos ativos
                    if AdvancedHLSProxyHandler.single_connection_buffer and AdvancedHLSProxyHandler.single_connection_manifest_url == url:
                        for seg in rewriter.m3u8_obj.segments:
                            AdvancedHLSProxyHandler.single_connection_buffer.add_segment_to_prefetch_queue(seg.absolute_uri)

                    response.close()
                    # Resetar contador de falhas para este manifesto
                    if hasattr(self, '_manifest_fail_count'): self._manifest_fail_count[url] = 0
                    return
                except Exception as e:
                    logging.error(f"Error processing manifest {url} (Proxy attempt {proxy_attempt + 1}): {e}", exc_info=True)
                    if response: response.close()
            else:
                status_code = response.status_code if response else 502
                logging.warning(f"Upstream manifest fetch failed with status {status_code} for {url}: sending 200 with minimal manifest to player.")
                if not hasattr(self, '_manifest_fail_count'): self._manifest_fail_count = {}
                self._manifest_fail_count[url] = self._manifest_fail_count.get(url, 0) + 1
                self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
                if response: response.close()
                return

        # Se todas as tentativas falharam
        logging.error(f"All manifest fetch attempts for {url} failed. Sending minimal M3U8.")
        self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")


    def _handle_segment(self, url, max_proxy_retries=5): # Aumentado retries para segmentos
        self._log_request(f"Handling segment: {url}", level='info')
        mime_type = safe_mime_type(url)
        
        # CORREÇÃO: Segmento TS mínimo válido para fallback, evita erro de demuxer.
        SILENT_TS_SEGMENT = bytes([
            0x47, 0x1F, 0xFF, 0x10, 0x00, 0x00, 0xB0, 0x0D, 0x00, 0x01, 0xC1, 0x00, 0x00, 0x00, 0x01, 0xF0
        ] + [0xFF] * 179) # 188 bytes total

        # Tentar primeiro o buffer de conexão única
        if AdvancedHLSProxyHandler.single_connection_buffer:
            seg_data = AdvancedHLSProxyHandler.single_connection_buffer.get_segment(url)
            if seg_data:
                self._log_request(f"Serving segment from single-connection buffer: {url}", level='debug')
                return self._send_response(200, seg_data, mime_type)
            else:
                # Se não está no buffer, pode estar sendo pré-buscado. Esperar um pouco antes de tentar cache/upstream
                # Isso evita que a mesma requisição seja feita N vezes
                wait_time = 0.05 # Tempo pequeno de espera
                max_wait_attempts = 5 # Número de tentativas
                for _ in range(max_wait_attempts):
                    if url in AdvancedHLSProxyHandler.single_connection_buffer.segments_data:
                        seg_data = AdvancedHLSProxyHandler.single_connection_buffer.get_segment(url)
                        if seg_data:
                            self._log_request(f"Serving segment from single-connection buffer after wait: {url}", level='debug')
                            return self._send_response(200, seg_data, mime_type)
                    time.sleep(wait_time)
                
        # Tentar o cache normal (RAM)
        cached_segment = self.cache.get_segment(url)
        if cached_segment:
            self._log_request(f"Serving segment from cache: {url}", level='debug')
            return self._send_response(200, cached_segment, mime_type)

        # Se não está em nenhum cache, buscar upstream
        for attempt in range(max_proxy_retries):
            self._log_request(f"Fetching segment {url} from upstream (Attempt {attempt + 1}/{max_proxy_retries})", level='debug')
            response = None
            try:
                response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
                if response and response.ok:
                    _cached_data = bytearray()
                    
                    self.send_response(200)
                    # Cabeçalhos importantes para streaming e compatibilidade
                    for h, v in response.headers.items():
                        # Excluir Transfer-Encoding para que o servidor web Kodi calcule o Content-Length
                        if h.lower() not in ('transfer-encoding', 'connection', 'content-encoding', 'content-length', 'keep-alive'):
                            try:
                                self.send_header(h, v)
                            except UnicodeEncodeError:
                                logging.warning(f"Skipping header with invalid characters: {h}: {v}")
                    
                    self.send_header("Content-Type", mime_type) # Força o MIME type correto
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0') # Impede cache de proxy intermediário
                    self.end_headers()
                    
                    bytes_sent = 0
                    for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                        if not chunk: continue
                        self.wfile.write(chunk)
                        bytes_sent += len(chunk)
                        
                        # Cachear apenas se o segmento estiver dentro do limite de tamanho
                        if bytes_sent <= MAX_SEGMENT_SIZE_BYTES:
                            _cached_data.extend(chunk)
                        else:
                            # Se exceder o limite, parar de cachear, mas continuar enviando
                            _cached_data = bytearray() # Limpar o que já foi acumulado
                            logging.debug(f"Segment {url} exceeded MAX_SEGMENT_SIZE_BYTES, not caching.")
                            
                    self._log_request(f"Segment {url} streamed to client. Total bytes sent: {bytes_sent}.", level='debug')
                    
                    if len(_cached_data) > 0 and len(_cached_data) <= MAX_SEGMENT_SIZE_BYTES:
                        self.cache.add_segment(url, bytes(_cached_data))
                        self._log_request(f"Segment {url} (size: {len(_cached_data)} bytes) added to cache.", level='debug')

                    if response: response.close()
                    return # Sucesso, sai da função

                status_code = response.status_code if response else 502
                logging.warning(f"Upstream segment fetch for {url} failed with status {status_code} on attempt {attempt + 1}.")
                if response: response.close()

            except (BrokenPipeError, ConnectionResetError) as e:
                logging.info(f"Client disconnected while serving segment {url}: {e}. Aborting.")
                if response: response.close()
                return # Cliente desconectou, não há o que fazer

            except Exception as e:
                logging.warning(f"Error fetching/streaming segment {url} on attempt {attempt + 1}: {e}", exc_info=True)
                if response: response.close()

            # Em caso de falha, tentar revalidar o manifesto para pegar URLs mais recentes
            try:
                manifest_url = self._find_manifest_url_from_segment(url)
                if manifest_url:
                    self._log_request(f"Forçando revalidação do manifesto {manifest_url} devido à falha do segmento.", level='warning')
                    self.cache.manifest_cache.pop(manifest_url, None) # Invalida o cache
                    # Não chamar _handle_manifest diretamente aqui para evitar loops.
                    # A próxima requisição do player pelo manifesto o revalidará.
            except Exception as e:
                logging.warning(f"Erro ao tentar atualizar manifesto após falha do segmento: {e}")

            if attempt < max_proxy_retries - 1:
                delay = jitter(0.05 * (2 ** attempt), percent=0.5) # Atraso exponencial menor
                logging.info(f"Retrying segment fetch for {url} in {delay:.2f} seconds...")
                time.sleep(delay)

        # Se todas as tentativas falharam
        self._log_request(f"All fetch attempts for {url} failed. Enviando TS silencioso para player não travar.", level='error')
        self._send_response(200, SILENT_TS_SEGMENT, mime_type)

    def _find_manifest_url_from_segment(self, segment_url):
        # Heurística mais robusta para encontrar o manifesto pai
        try:
            parsed = urllib.parse.urlparse(segment_url)
            path_parts = parsed.path.split('/')
            
            # Tentar encontrar a última parte que se assemelha a um nome de arquivo de manifesto
            for i in range(len(path_parts) - 1, -1, -1):
                part = path_parts[i]
                if '.m3u8' in part.lower():
                    # Reconstruir a URL até o manifesto
                    manifest_path = '/'.join(path_parts[:i+1])
                    return urllib.parse.urlunparse(parsed._replace(path=manifest_path, query=''))
            
            # Se não encontrou um .m3u8 no caminho, assumir que é no mesmo diretório base
            if path_parts:
                base_path = '/'.join(path_parts[:-1]) # Pega o diretório
                manifest_path_candidates = [
                    f"{base_path}/playlist.m3u8",
                    f"{base_path}/index.m3u8",
                    f"{base_path}/master.m3u8",
                    f"{base_path}/stream.m3u8"
                ]
                for candidate in manifest_path_candidates:
                    temp_url = urllib.parse.urlunparse(parsed._replace(path=candidate, query=''))
                    # Poderia fazer uma HEAD request aqui para verificar se existe, mas é mais caro
                    # Por simplicidade, retorna o primeiro candidato razoável
                    return temp_url

        except Exception as e:
            logging.warning(f"Error determining manifest URL for segment {segment_url}: {e}", exc_info=True)
        return None # Retornar None se não for possível deduzir

    def _send_response(self, code, content, content_type):
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        try:
            self.send_response(code) # Usar o código de resposta real
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(encoded)))
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0') # Garante que nenhum cache intermediário guarde
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(encoded)
            # self._log_request(f"Response sent (code: {code}, type: {content_type}, size: {len(encoded)} bytes).", level='debug')
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected while sending response for {content_type}.", level='info')
        except Exception as ex:
            logging.error("Error sending response: %s", str(ex), exc_info=True)

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self.doh_resolver = DoHResolver()
        self.chunk_cache = RecentSegmentsCache(MAX_CACHE_SIZE_BYTES, max_segments=100) # Otimizado
        logging.info("Usando cache de segmentos recentes na memória.")
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(HTTP_SESSION, self.doh_resolver)
        logging.info("HLSProxyManager initialized.")

    def start(self):
        self.stop() # Garante que qualquer instância anterior seja parada
        handler_with_deps = functools.partial(AdvancedHLSProxyHandler, self.stream_cache, self.fetcher)
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            if not is_port_free(port):
                logging.warning(f"Port {port} is in use, trying another. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.")
                continue
            try:
                # Otimização: Reuso de endereço imediato (SO_REUSEADDR) para evitar Address already in use
                self.server = socketserver.TCPServer((PROXY_HOST, port), handler_with_deps)
                self.server.allow_reuse_address = True
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.name = "ProxyServer"
                self.server_thread.start()
                logging.info(f"HLS Proxy started successfully on port {self.active_port} on host {PROXY_HOST} (accessible by other devices if not localhost).")
                return self.active_port
            except Exception as ex:
                logging.warning(f"Failed to start proxy on port {port}: {ex}. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.", exc_info=True)
                time.sleep(0.5)
        logging.error(f"Failed to start HLS Proxy after {MAX_PORT_ATTEMPTS} attempts. No free port found or general error.")
        notify("Erro fatal: Não foi possível iniciar o proxy HLS. Nenhuma porta livre encontrada ou erro interno.", 7000)
        return None

    def stop(self):
        if self.server:
            logging.info(f"Stopping HLS Proxy on port {self.active_port}")
            try:
                self.server.shutdown() # Desliga o servidor de forma graciosa
                self.server.server_close() # Fecha o socket
                logging.debug("Proxy server shut down and closed.")
            except Exception as e:
                logging.error(f"Error during proxy server shutdown: {e}", exc_info=True)
            self.server = None
        if self.server_thread and self.server_thread.is_alive():
            logging.debug("Waiting for proxy server thread to join...")
            self.server_thread.join(timeout=2) # Aumentado timeout para join
            if self.server_thread.is_alive():
                logging.warning("Proxy server thread did not terminate gracefully.")
            else:
                logging.debug("Proxy server thread joined successfully.")
        self.stream_cache.clear()
        self.active_port = None
        logging.info("HLS Proxy completely stopped and and resources released.")
        
    def get_proxy_url(self, original_url):
        if not self.active_port: return None
        url_encoded = urllib.parse.quote_plus(original_url)
        return f"http://{PROXY_HOST}:{self.active_port}/?url={url_encoded}"

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        logging.info("CustomPlayer initialized with stop event.")

    def onPlayBackStarted(self):
        logging.info("Kodi playback started.")
        self.stop_event.clear() # Limpa o evento para indicar que o playback está ativo
    
    def onPlayBackEnded(self):
        logging.info("Kodi playback ended.")
        self.stop_event.set() # Define o evento para sinalizar o fim do playback

    def onPlayBackError(self):
        logging.error("Kodi playback error occurred.")
        self.stop_event.set() # Define o evento para sinalizar erro no playback

    def onPlayBackStopped(self):
        logging.info("Kodi playback stopped by user.")
        self.stop_event.set() # Define o evento para sinalizar que o usuário parou

class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)
        logging.info("HLSProxyAddon instance created.")

    # convert_to_m3u8(url) NÃO SERÁ MODIFICADA CONFORME REQUISITADO
    def convert_to_m3u8(self, url):
        original_url = url
        logging.debug(f"Attempting to convert URL to M3U8 format: {url}")
        try:
            if '|' in url:
                url = url.split('|')[0]
                logging.debug(f"Removed '|' and everything after: {url}")
            elif '%7C' in url:
                url = url.split('%7C')[0]
                logging.debug(f"Removed '%7C' and everything after: {url}")

            if not '.m3u8' in url.lower() and not '/hl' in url.lower() and url.count("/") > 4 and not '.mp4' in url.lower() and not '.avi' in url.lower():
                parsed_url = urllib.parse.urlparse(url)
                host_part1 = f'{parsed_url.scheme}://{parsed_url.netloc}'
                host_part2 = url.split(host_part1)[1]
                
                if '/live' not in host_part2:
                    url = host_part1 + '/live' + host_part2
                    logging.debug(f"Added '/live' to URL: {url}")

                file = os.path.basename(urllib.parse.urlparse(url).path)
                if '.ts' in file.lower():
                    file_new = file.replace('.ts', '.m3u8')
                    url = url.replace(file, file_new)
                    logging.debug(f"Replaced .ts with .m3u8: {url}")
                else:
                    url = url + '.m3u8'
                    logging.debug(f"Appended .m3u8 to URL: {url}")
        except Exception as e:
            logging.warning(f"Heuristic conversion failed for {original_url}: {e}. Returning original URL.", exc_info=True)
            return original_url 
        logging.debug(f"Final URL after convert_to_m3u8: {url}")
        return url


    def play_stream(self, url, channel_name=None):
        logging.info(f"Attempting to play stream: {url}")
        processed_url = self.convert_to_m3u8(url)
        logging.info(f"URL after convert_to_m3u8: {processed_url}")
        if not validate_url(processed_url):
            notify("URL inválida, bloqueada ou não suportada.", 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        
        # Garante que o evento de parada esteja limpo antes de iniciar um novo playback
        self.playback_stop_event.clear() 

        port = self.proxy_manager.start()
        if not port:
            notify("Erro fatal ao iniciar proxy local. Verifique os logs.", 5000)
            logging.error("Failed to start proxy, cannot resolve URL for Kodi.")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if channel_name:
            display_label = f"{channel_name} [COLOR lightblue](HLS/TS Tester)[/COLOR]"
        else:
            display_label = "[COLOR lightblue]HLS/TS Tester[/COLOR]"
        
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_label)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType(safe_mime_type(processed_url))
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        logging.info(f"Kodi resolved URL to proxy: {proxy_url}")
        
        # Iniciar o monitoramento em uma nova thread
        monitor_thread = threading.Thread(target=self.monitor_playback, daemon=True)
        monitor_thread.name = "PlaybackMonitor"
        monitor_thread.start()
        logging.debug("Playback monitor thread started.")

    def monitor_playback(self):
        logging.info("Starting playback monitoring...")
        try:
            # Espera pelo evento de parada. Timeout elevado para streams longos.
            # O player.onPlayBack* irá sinalizar o evento
            was_stopped = self.playback_stop_event.wait(timeout=3600 * 24) # Espera até 24 horas
            if was_stopped:
                logging.info("Playback stop event received. Releasing proxy resources.")
            else:
                logging.warning("Playback monitoring timed out (24 hours). Releasing proxy resources as a safeguard.")
        except Exception as e:
            logging.error(f"Error during playback monitoring: {e}", exc_info=True)
        finally:
            logging.info("Ensuring proxy resources are released.")
            # Garante que o buffer de conexão única seja parado e limpo
            if AdvancedHLSProxyHandler.single_connection_buffer:
                AdvancedHLSProxyHandler.single_connection_buffer.stop()
                AdvancedHLSProxyHandler.single_connection_buffer = None
                AdvancedHLSProxyHandler.single_connection_manifest_url = None
            # Para o HLSProxyManager (servidor e caches)
            self.proxy_manager.stop()

    def show_test_streams(self):
        test_streams = [
            ("Live Exemplo (Caminho da Web)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Big Buck Bunny (VOD - 1080p)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Apple Test HLS (Advanced)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"),
            ("Google Shaka Test (DRM-Free)", "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8")
        ]
        logging.info("Displaying test streams.")
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=f"{name} [COLOR lightblue](Reprodução via Proxy HLS/TS Tester)[/COLOR]")
            li.setProperty('IsPlayable', 'true')
            li.setMimeType(safe_mime_type(url))
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            logging.debug(f"Added directory item: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url_to_play = params.get('url')
    channel_title = params.get('title')
    addon = HLSProxyAddon()
    if action == 'play' and url_to_play:
        addon.play_stream(url_to_play, channel_title)
    else:
        addon.show_test_streams()