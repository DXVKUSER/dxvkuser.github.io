import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
import re
from collections import OrderedDict
from typing import Optional, Dict, Any, List, Tuple, Type, Union

# ==============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO ---
# ==============================================================================

# --- Estratégia de Reconexão e Falha ---
# A filosofia é "falhar rápido, reconectar de forma agressiva".
# Evita gastar tempo e CPU com retentativas em um segmento que provavelmente
# não será recuperado, preferindo forçar uma reinicialização completa da sessão.
MAX_STICKY_SEGMENT_RETRIES = 0  # 0 = Não re-tentar o mesmo segmento. Se falhar, aciona a lógica de falha global.
MAX_CONSECUTIVE_SEGMENT_FAILURES = 1  # 1 = Na primeira falha de segmento, força uma nova sessão HTTP.

# --- Configurações do Fetcher (Requisições HTTP) ---
FETCHER_MAX_RETRIES = 1  # Reduzido para 1 para abandonar conexões problemáticas mais cedo.
RETRY_BACKOFF_FACTOR = 0.5  # Fator de espera entre retentativas.
CONNECTION_TIMEOUT = 4.0  # Aumentado ligeiramente para dar mais margem em conexões lentas.
STREAM_TIMEOUT = 4.0  # Aumentado ligeiramente para dar mais margem em redes instáveis.

# --- Otimização de Rede e Memória ---
# Tamanhos de chunk rotativos para download de segmentos, para variar o padrão de requisição.
ROTATING_CHUNK_SIZES = [50 * 1024, 64 * 1024, 128 * 1024]
# Tempo de vida máximo de um manifesto em cache antes de forçar uma reconexão.
# Alinhado com a duração alvo (TARGETDURATION) comum em HLS.
MAX_STREAM_LIFETIME_SECONDS = 2
MAX_CACHE_MB = 128  # Reduzido para 128MB para economizar memória em dispositivos fracos.
MAX_CACHE_SIZE_BYTES = MAX_CACHE_MB * 1024 * 1024
MAX_SEGMENT_SIZE_MB = 8  # Reduzido para 8MB para evitar picos de uso de memória.
MAX_SEGMENT_SIZE_BYTES = MAX_SEGMENT_SIZE_MB * 1024 * 1024

# --- Configurações do Proxy e Addon ---
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 10
LIMIT_COOLDOWN_SECONDS = 7  # Tempo de espera após um erro de "limite de usuários".

# --- Configurações de Spoofing e Rede ---
SPOOF_X_FORWARDED_FOR = True  # Envia um IP aleatório no header X-Forwarded-For.
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, HadKML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "okhttp/4.9.0",
]

# --- Configuração de Logging ---
LOG_MAX_BYTES = 1048576 * 2  # 2MB
LOG_BACKUP_COUNT = 1
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
LOG_LEVEL = logging.INFO

# --- Constantes ---
# Segmento de vídeo MPEG-TS silencioso e válido para enviar ao player em caso de falha.
# Isso evita que o player pare imediatamente, dando tempo para a reconexão.
SILENT_TS_SEGMENT = bytes([
    0x47, 0x1F, 0xFF, 0x10, 0x00, 0x00, 0xB0, 0x0D, 0x00, 0x01, 0xC1, 0x00,
    0x00, 0x00, 0x01, 0xF0
] + [0xFF] * 179)
_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}


# ==============================================================================
# --- INICIALIZAÇÃO DO LOGGING ---
# ==============================================================================

def setup_logging():
    """Configura o logger para registrar em um arquivo rotativo."""
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

setup_logging()


# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================

def is_valid_ip(address: str) -> bool:
    """Verifica se uma string é um endereço IP válido (IPv4 ou IPv6)."""
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def join_host_port(host: str, port: int) -> str:
    """Junta host e porta, tratando corretamente endereços IPv6."""
    return f'[{host}]:{port}' if ':' in host and is_valid_ip(host) else f'{host}:{port}'

def generate_random_ipv4() -> str:
    """Gera um endereço IPv4 público aleatório."""
    while True:
        ip_str = f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            if not ip_obj.is_private and not ip_obj.is_loopback and not ip_obj.is_link_local:
                return ip_str
        except ValueError:
            continue

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    """Remove headers sensíveis que não devem ser repassados."""
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_random_player_headers(url: str) -> Dict[str, str]:
    """Cria um dicionário de headers de player aleatórios com Origin e Referer baseados na URL."""
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "*/*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin
    }
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def safe_mime_type(url: str) -> str:
    """Determina o MIME type com base na extensão do arquivo de forma segura."""
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith('.m3u8') or path.endswith('.m3u'):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    """Verifica se o conteúdo de um manifesto indica um erro de limite de conexões."""
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections", "max session", "#error"]
    return any(keyword in txt for keyword in keywords)


# ==============================================================================
# --- RESOLUTOR DE DNS (DoH) ---
# ==============================================================================

class DoHResolver:
    """Resolve nomes de host para IPs usando DNS-over-HTTPS para contornar problemas de DNS local."""
    def __init__(self, session: requests.Session, cache_ttl: int = 300):
        self.resolver_urls = ['https://dns.nextdns.io/dns-query', 'https://cloudflare-dns.com/dns-query']
        self._cache: Dict[str, Tuple[str, float]] = {}
        self._lock = threading.Lock()
        self.cache_ttl = cache_ttl
        self.session = session

    def resolve(self, hostname: str) -> Optional[str]:
        """Resolve um hostname para um endereço IP, usando cache."""
        if is_valid_ip(hostname):
            return hostname

        with self._lock:
            cached_entry = self._cache.get(hostname)
            if cached_entry and time.time() < cached_entry[1]:
                return cached_entry[0]

        try:
            # Tenta resolver com o DNS padrão do sistema primeiro
            addr_info = socket.getaddrinfo(hostname, None, socket.AF_INET)
            ip = addr_info[0][4][0]
            self._add_to_cache(hostname, ip, self.cache_ttl)
            return ip
        except socket.gaierror:
            logging.warning(f"[DoHResolver] Falha no DNS do sistema para {hostname}. Usando DoH.")
            return self._resolve_over_https(hostname)

    def _resolve_over_https(self, hostname: str, depth: int = 0) -> Optional[str]:
        """Lógica de resolução via HTTPS."""
        if depth > 2: # Previne recursão infinita
            return None
            
        for resolver_url in self.resolver_urls:
            try:
                params = {'name': hostname, 'type': 'A'}
                headers = {'accept': 'application/dns-json'}
                response = self.session.get(resolver_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT)
                response.raise_for_status()
                data = response.json()
                
                for answer in data.get("Answer", []):
                    if answer.get("type") == 1: # 'A' record
                        ip = answer.get("data")
                        ttl = answer.get("TTL", self.cache_ttl)
                        self._add_to_cache(hostname, ip, ttl)
                        return ip
                # Fallback para CNAME
                for answer in data.get("Answer", []):
                    if answer.get("type") == 5: # 'CNAME' record
                        cname = answer.get("data", "").rstrip('.')
                        return self._resolve_over_https(cname, depth + 1)

            except requests.RequestException as e:
                logging.warning(f"[DoHResolver] Falha ao consultar {resolver_url} para {hostname}: {e}")
        return None

    def _add_to_cache(self, hostname: str, ip: str, ttl: int):
        with self._lock:
            self._cache[hostname] = (ip, time.time() + ttl)

    def clear_cache_for_host(self, hostname: str):
        """Limpa o cache de DNS para um hostname específico."""
        with self._lock:
            if hostname in self._cache:
                del self._cache[hostname]
                logging.info(f"[RECONEXÃO] Cache de DNS limpo para o host: {hostname}")


# ==============================================================================
# --- CACHE DE DADOS ---
# ==============================================================================

class RotatingChunkCache:
    """Cache LRU (Least Recently Used) para armazenar segmentos de vídeo em memória."""
    def __init__(self, max_bytes: int = MAX_CACHE_SIZE_BYTES):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.chunks: OrderedDict[str, bytes] = OrderedDict()
        self.total_bytes = 0

    def get(self, url: str) -> Optional[bytes]:
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
            return data

    def add(self, url: str, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))
            
            chunk_size = len(data)
            if chunk_size > self.max_bytes:
                return

            self.chunks[url] = data
            self.total_bytes += chunk_size
            
            while self.total_bytes > self.max_bytes:
                _, old_data = self.chunks.popitem(last=False)
                self.total_bytes -= len(old_data)

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0
            logging.info("[RECONEXÃO] Cache de segmentos de vídeo limpo.")

class StreamCache:
    """Gerencia o cache de manifestos e segmentos de vídeo."""
    def __init__(self, chunk_cache: RotatingChunkCache):
        self.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self.chunk_cache = chunk_cache
        self.lock = threading.Lock()

    def get_manifest(self, url: str) -> Optional[str]:
        with self.lock:
            entry = self.manifest_cache.get(url)
            if entry and time.time() < entry['expires']:
                return entry['content']
        return None

    def add_manifest(self, url: str, content: str, ttl: int):
        with self.lock:
            self.manifest_cache[url] = {
                'content': content,
                'expires': time.time() + ttl,
                'last_refresh_time': time.time()
            }

    def invalidate_manifest(self, url: str):
        with self.lock:
            if url in self.manifest_cache:
                del self.manifest_cache[url]
                logging.info(f"[RECONEXÃO] Manifesto {url} invalidado do cache.")

    def is_manifest_expired(self, url: str) -> bool:
        with self.lock:
            entry = self.manifest_cache.get(url)
            return not entry or time.time() - entry.get('last_refresh_time', 0) >= MAX_STREAM_LIFETIME_SECONDS

    def get_segment(self, url: str) -> Optional[bytes]:
        return self.chunk_cache.get(url)

    def add_segment(self, url: str, data: bytes):
        self.chunk_cache.add(url, data)

    def clear(self):
        with self.lock:
            self.manifest_cache.clear()
        self.chunk_cache.clear()


# ==============================================================================
# --- FETCHER E REWRITER ---
# ==============================================================================

class UpstreamFetcher:
    """Responsável por buscar conteúdo (manifestos, segmentos) da fonte original."""
    def __init__(self, session: requests.Session, doh_resolver: DoHResolver):
        self.session = session
        self.doh_resolver = doh_resolver

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        headers = get_random_player_headers(url)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie']})
        
        if SPOOF_X_FORWARDED_FOR:
            headers['X-Forwarded-For'] = generate_random_ipv4()

        parsed_url = urllib.parse.urlparse(url)
        hostname = parsed_url.hostname
        resolved_ip = self.doh_resolver.resolve(hostname) if hostname else None

        req_url = url
        if resolved_ip and resolved_ip != hostname:
            host_port = join_host_port(resolved_ip, parsed_url.port or (443 if parsed_url.scheme == 'https' else 80))
            req_url = parsed_url._replace(netloc=host_port).geturl()
            headers['Host'] = hostname

        for attempt in range(FETCHER_MAX_RETRIES):
            try:
                # O verify=False desabilita a verificação do certificado SSL.
                # Necessário para muitos servidores de IPTV, mas é uma prática insegura.
                resp = self.session.get(
                    req_url, stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                return resp
            except requests.RequestException as e:
                logging.warning(f"[Fetcher] Tentativa {attempt + 1}/{FETCHER_MAX_RETRIES} falhou para {url}: {e}")
                if attempt < FETCHER_MAX_RETRIES - 1:
                    time.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))
                else:
                    raise

class ManifestRewriter:
    """Analisa um manifesto M3U8 e reescreve as URLs para apontarem para o proxy local."""
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url

    def rewrite(self) -> str:
        """Reescreve as URLs de playlists, mídias, segmentos e chaves."""
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri:
                # Não reescreve a URL da chave se ela já for um data URI
                if not item.key.uri.startswith("data:"):
                    item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        """Calcula um TTL (Time To Live) para o cache do manifesto."""
        target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
        if self.is_live:
            # TTL é 60% da duração alvo, garantindo atualização antes do próximo segmento.
            return max(1, int(target_duration * 0.6))
        return 3600 # Cache longo para VOD

# ==============================================================================
# --- PROXY HTTP ---
# ==============================================================================

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    """Manipulador de requisições HTTP para o proxy."""

    def __init__(self, request: bytes, client_address: Tuple[str, int], server: socketserver.BaseServer,
                 stream_cache: 'StreamCache', fetcher: 'UpstreamFetcher', proxy_manager: 'HLSProxyManager'):
        """
        Construtor customizado que recebe as dependências e as atribui
        antes de chamar o construtor da classe pai.
        """
        self.stream_cache = stream_cache
        self.fetcher = fetcher
        self.proxy_manager = proxy_manager
        # Chama o construtor pai apenas com os argumentos que ele espera.
        super().__init__(request, client_address, server)

    def log_message(self, format: str, *args: Any):
        # Desativa o logging padrão do BaseHTTPRequestHandler
        pass

    def do_GET(self):
        try:
            query_params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            original_url = query_params.get('url', [''])[0]
            if not original_url:
                return self.send_error(400, "Parâmetro 'url' ausente")

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            logging.info(f"[{self.address_string()}] Cliente desconectou.")
        except Exception as e:
            logging.error(f"[{self.address_string()}] Erro geral no proxy para {self.path}: {e}", exc_info=True)
            if not self.wfile.closed:
                self.send_error(500, "Erro interno do servidor")

    def _handle_manifest(self, url: str):
        """Processa requisições para manifestos M3U8."""
        logging.info(f"[{self.address_string()}] Manipulando manifesto: {url}")

        if self.proxy_manager.is_in_cooldown(url):
            cooldown = LIMIT_COOLDOWN_SECONDS
            logging.warning(f"Manifesto em cooldown por {cooldown}s. Enviando playlist vazia.")
            return self._send_response(200, b"#EXTM3U\n", 'application/vnd.apple.mpegurl')

        if self.stream_cache.is_manifest_expired(url):
            logging.info(f"Manifesto expirou (> {MAX_STREAM_LIFETIME_SECONDS}s). Forçando reconexão.")
            self.proxy_manager.force_reconnection(url)

        cached_content = self.stream_cache.get_manifest(url)
        if cached_content:
            return self._send_response(200, cached_content.encode('utf-8'), 'application/vnd.apple.mpegurl')
        
        try:
            response = self.fetcher.fetch(url, original_headers=self.headers)
            content = response.text

            if is_manifest_limit_error(content):
                logging.warning(f"Erro de limite detectado para {url}. Forçando reconexão.")
                self.proxy_manager.record_limit_hit(url)
                self.proxy_manager.force_reconnection(url)
                return self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

            proxy_base = f"http://{join_host_port(self.server.server_address[0], self.server.server_address[1])}/?url="
            rewriter = ManifestRewriter(content, response.url, proxy_base)
            rewritten_content = rewriter.rewrite()
            ttl = rewriter.get_ttl()
            
            self.stream_cache.add_manifest(url, rewritten_content, ttl)
            self.proxy_manager.clear_limit_hit(url)
            self._send_response(200, rewritten_content.encode('utf-8'), 'application/vnd.apple.mpegurl')

        except Exception as e:
            logging.error(f"Falha ao buscar ou processar manifesto {url}: {e}", exc_info=False)
            self.proxy_manager.force_reconnection(url)
            self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

    def _handle_segment(self, url: str):
        """Processa requisições para segmentos de vídeo (.ts, etc)."""
        mime_type = safe_mime_type(url)
        
        cached_segment = self.stream_cache.get_segment(url)
        if cached_segment:
            self.proxy_manager.reset_failure_count()
            return self._send_response(200, cached_segment, mime_type)

        try:
            response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
            
            segment_data = bytearray()
            current_chunk_size = random.choice(ROTATING_CHUNK_SIZES)

            for chunk in response.iter_content(chunk_size=current_chunk_size):
                segment_data.extend(chunk)
                if len(segment_data) > MAX_SEGMENT_SIZE_BYTES:
                    raise IOError(f"Segmento excedeu o tamanho máximo de {MAX_SEGMENT_SIZE_MB}MB.")
            
            final_data = bytes(segment_data)
            self.stream_cache.add_segment(url, final_data)
            self.proxy_manager.reset_failure_count()
            self._send_response(200, final_data, mime_type)
        
        except Exception as e:
            logging.warning(f"Falha ao baixar segmento {url}: {e}")
            self.proxy_manager.increment_failure_count()
            
            if self.proxy_manager.should_force_reconnect():
                logging.error(f"Limite de falhas consecutivas atingido. FORÇANDO RECONEXÃO TOTAL.")
                self.proxy_manager.force_reconnection(url)
                self.proxy_manager.reset_failure_count()
            
            self._send_response(200, SILENT_TS_SEGMENT, mime_type)

    def _send_response(self, code: int, content: bytes, content_type: str):
        """Envia a resposta HTTP para o cliente (Kodi)."""
        try:
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            logging.info(f"[{self.address_string()}] Cliente desconectou ao enviar resposta.")
        except Exception as e:
            logging.error(f"Erro ao enviar resposta: {e}", exc_info=True)


class HLSProxyManager:
    """Gerencia o ciclo de vida do servidor proxy, estado de reconexão e caches."""
    def __init__(self):
        self.server: Optional[socketserver.ThreadingTCPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None
        
        self._http_session: requests.Session = self._create_http_session()
        self.doh_resolver = DoHResolver(self._http_session)
        self.chunk_cache = RotatingChunkCache()
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(self._http_session, self.doh_resolver)

        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0
        self._limit_hits: Dict[str, float] = {}

    def _create_http_session(self) -> requests.Session:
        """Cria e configura uma nova sessão de requisições."""
        session = requests.Session()
        session.headers.update({
            'User-Agent': random.choice(USER_AGENTS),
            'Accept': '*/*',
            'Connection': 'keep-alive'
        })
        # Não usar variáveis de ambiente de proxy do sistema
        session.trust_env = False
        return session

    def reset_http_session(self):
        """Fecha a sessão HTTP atual e cria uma nova para limpar o estado da conexão."""
        logging.info("[RECONEXÃO] Recriando sessão HTTP.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher.session = self._http_session
        self.doh_resolver.session = self._http_session

    def force_reconnection(self, url: str):
        """Orquestra uma reconexão completa: limpa caches e reinicia a sessão HTTP."""
        logging.info(f"[RECONEXÃO] Forçando reconexão para URL base: {url}")
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.hostname:
            self.doh_resolver.clear_cache_for_host(parsed_url.hostname)
        
        self.stream_cache.clear()
        self.reset_http_session()
    
    # --- Gerenciamento de Falhas ---
    def increment_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures += 1

    def reset_failure_count(self):
        with self._failure_lock:
            self._consecutive_failures = 0

    def should_force_reconnect(self) -> bool:
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES
    
    # --- Gerenciamento de Limite de Conexões ---
    def record_limit_hit(self, url: str):
        self._limit_hits[self._get_base_url(url)] = time.time()

    def is_in_cooldown(self, url: str) -> bool:
        hit_time = self._limit_hits.get(self._get_base_url(url))
        return hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS

    def clear_limit_hit(self, url: str):
        base_url = self._get_base_url(url)
        if base_url in self._limit_hits:
            del self._limit_hits[base_url]

    @staticmethod
    def _get_base_url(url: str) -> str:
        """Extrai a base da URL (scheme://netloc) para agrupar erros."""
        parts = urllib.parse.urlparse(url)
        return f"{parts.scheme}://{parts.netloc}"

    def start(self) -> Optional[int]:
        """Inicia o servidor proxy em uma porta aleatória."""
        self.stop() # Garante que qualquer instância anterior seja parada
        
        def handler_factory(*args, **kwargs):
            return HLSProxyHandler(*args, **kwargs,
                                   stream_cache=self.stream_cache,
                                   fetcher=self.fetcher,
                                   proxy_manager=self)

        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                server = socketserver.ThreadingTCPServer((PROXY_HOST, port), handler_factory)
                server.allow_reuse_address = True
                self.server = server
                self.active_port = port

                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.server_thread.start()
                logging.info(f"HLS Proxy Avançado iniciado em {PROXY_HOST}:{port}.")
                return port
            except Exception as e:
                logging.warning(f"Falha ao iniciar proxy na porta {port}: {e}.")
        
        logging.error("Falha ao iniciar HLS Proxy após todas as tentativas.")
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy",5000)')
        return None

    def stop(self):
        """Para o servidor proxy e libera os recursos."""
        if self.server:
            logging.info(f"Parando HLS Proxy na porta {self.active_port}")
            self.server.shutdown()
            self.server.server_close()
            self.server = None
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2)
        
        self.stream_cache.clear()
        self.reset_http_session()
        self.active_port = None
        logging.info("Proxy parado e recursos liberados.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/?url={encoded_url}"


# ==============================================================================
# --- LÓGICA DO ADDON KODI ---
# ==============================================================================

class CustomPlayer(xbmc.Player):
    """Player customizado para monitorar o fim da reprodução e liberar recursos."""
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event

    def onPlayBackEnded(self):
        logging.info("Playback finalizado.")
        self.stop_event.set()

    def onPlayBackError(self):
        logging.error("Erro no Playback.")
        self.stop_event.set()

    def onPlayBackStopped(self):
        logging.info("Playback parado pelo usuário.")
        self.stop_event.set()

class HLSProxyAddon:
    """Classe principal do addon, gerencia a interface com o Kodi."""
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)

    def _convert_to_m3u8(self, url: str) -> str:
        """Tenta converter uma URL de stream (comum em IPTV) para um formato M3U8 padrão."""
        try:
            # Remove parâmetros de header após '|' ou '%7C'
            url = url.split('|')[0].split('%7C')[0]
            
            # Não modifica URLs que já parecem ser HLS ou outros formatos conhecidos
            if re.search(r'\.(m3u8|m3u|mp4|avi)$', url, re.IGNORECASE) or '/hl' in url:
                return url
            
            parts = urllib.parse.urlparse(url)
            path_segments = parts.path.split('/')
            
            # Heurística comum: streams live estão sob um caminho /live/
            if 'live' not in path_segments and len(path_segments) > 2:
                # Ex: /user/pass/123.ts -> /live/user/pass/123.m3u8
                new_path = '/live/' + '/'.join(s for s in path_segments if s)
                url = parts._replace(path=new_path).geturl()

            # Troca a extensão de .ts para .m3u8 no final do caminho
            if url.endswith('.ts'):
                url = url[:-3] + '.m3u8'
            elif not url.endswith('.m3u8'):
                url += '.m3u8'
                
        except Exception as e:
            logging.warning(f"Falha na conversão para m3u8 (usando URL original): {e}")

        return url

    def play_stream(self, url: str, channel_name: Optional[str] = None):
        """Inicia o proxy e envia a URL processada para o player do Kodi."""
        logging.info(f"Iniciando stream para: {url}")
        
        processed_url = self._convert_to_m3u8(url)
        logging.info(f"URL processada para HLS: {processed_url}")

        if not self.proxy_manager.start():
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
            
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        display_name = f"{channel_name or 'Stream'} [COLOR cyan](HLS Tester)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_name)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
        logging.info(f"Kodi resolvido para a URL do proxy: {proxy_url}")
        
        threading.Thread(target=self.monitor_playback, daemon=True).start()

    def monitor_playback(self):
        """Aguarda o fim da reprodução para parar o proxy e limpar recursos."""
        logging.info("Monitor de playback iniciado.")
        self.playback_stop_event.wait()
        logging.info("Evento de parada de playback recebido. Liberando proxy.")
        self.proxy_manager.stop()

    def show_test_streams(self):
        """Exibe uma lista de streams de teste para verificação."""
        test_streams = [
            ("Big Buck Bunny (VOD)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Exemplo Live (Pode estar offline)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
        ]
        for name, url in test_streams:
            list_item = xbmcgui.ListItem(label=name)
            list_item.setProperty('IsPlayable', 'true')
            list_item.setMimeType(safe_mime_type(url))
            
            plugin_url_params = urllib.parse.urlencode({'action': 'play', 'url': url, 'title': name})
            plugin_url = f"plugin://{ADDON_ID}/?{plugin_url_params}"
            
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, list_item, isFolder=False)
        
        xbmcplugin.endOfDirectory(self.handle)

def main():
    """Função principal que roteia as ações do addon."""
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get('action')
        
        addon = HLSProxyAddon(handle)

        if action == 'play':
            url_to_play = params.get('url')
            title = params.get('title')
            if url_to_play:
                addon.play_stream(url_to_play, title)
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.error(f"Erro na execução principal do addon: {e}", exc_info=True)

if __name__ == '__main__':
    main()