import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
from collections import OrderedDict, deque
from requests.exceptions import Timeout, ConnectionError, HTTPError

# --- Configurações Iniciais do Addon (Hardcoded) ---
# Definir o nome e ID do addon para uso em notificações e URLs de plugin
ADDON_ID = "plugin.video.meuhlsplayer" # ID CORRIGIDO
ADDON_NAME = "MEU HLS PLAYER" # Nome padrão, ajuste se o seu addon tiver outro
HANDLE = int(sys.argv[1])

# Este PROXY_HOST agora representa o host padrão, sem leitura de settings.xml
PROXY_HOST = '127.0.0.1'

DEFAULT_PROXY_PORT = random.randint(20000, 65000)
MAX_PORT_ATTEMPTS = 10

# Valores padrão para as configurações
max_cache_mb = 64
MAX_CACHE_SIZE_BYTES = max_cache_mb * 1024 * 1024

max_segment_size_mb = 8
MAX_SEGMENT_SIZE_BYTES = max_segment_size_mb * 1024 * 1024

LIMIT_COOLDOWN_SECONDS = 15 # Padrão 15 segundos
MAX_CONSECUTIVE_SEGMENT_FAILURES = 3 # Padrão 3 falhas

CACHE_TYPE = 'ram'

SIMULATE_ERRORS = False # ATENÇÃO: Nunca use True em produção
IS_DEV_ENV = os.environ.get('KODI_ENV') == 'development'
if SIMULATE_ERRORS and not IS_DEV_ENV:
    SIMULATE_ERRORS = False

ENABLE_IPV6 = False

# NOVA CONFIGURAÇÃO: Gerar IPs falsos no cabeçalho X-Forwarded-For
# ATENÇÃO: Isso NÃO oculta seu IP real. Pode causar problemas com alguns servidores.
SPOOF_X_FORWARDED_FOR = True # Altere para True para ativar. Use com cautela.

CONNECTION_TIMEOUT = 2.0
STREAM_TIMEOUT = 3.0

CHUNK_SIZE = 50 * 1024 # 50 KB padrão

LOG_MAX_BYTES = 1048576 # 1MB
LOG_BACKUP_COUNT = 3

LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
USER_BLOCKLIST = set() # Lista negra de hosts vazia por padrão

LOG_LEVEL = logging.WARNING # Nível de log padrão

log_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
)
logging.basicConfig(
    handlers=[log_handler],
    level=LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s'
)

USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 14; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.5 (WebOS; U; SmartTV; LG NetCast.TV-2013) AppleWebKit/537.41 (KHTML, like Gecko) WebAppManager",
    "VLC/3.0.20 (Linux; Android 14) (Build/UP1A.231005.007)" # Adicionado User-Agent similar ao VLC
]
ACCEPT_LANGUAGES = [
    "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "en-US,en;q=0.9,pt;q=0.8",
    "es-ES,es;q=0.9,en;q=0.8"
]
PLAYER_HEADERS = [{"User-Agent": USER_AGENTS[i], "Accept": "*/*", "Accept-Language": lang, "Origin": "", "Referer": ""} for i, lang in zip(range(len(USER_AGENTS)), ACCEPT_LANGUAGES * 2)]

# Otimização: Pre-calcular o set de cabeçalhos sensíveis em minúsculas uma vez.
_SENSITIVE_HEADERS = ['X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP']
_SENSITIVE_HEADERS_LOWER = {s.lower() for s in _SENSITIVE_HEADERS}

def clean_headers(headers):
    """Remove cabeçalhos HTTP sensíveis/privados que não devem ser enviados upstream."""
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def random_player_headers(url):
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.hostname}"
    headers = random.choice(PLAYER_HEADERS).copy()
    headers['Origin'] = origin
    headers['Referer'] = origin
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def jitter(base, percent=0.1):
    return base + base * random.uniform(-percent, percent)

HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': random.choice(USER_AGENTS),
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive'
})
HTTP_SESSION.trust_env = False

def is_ipv6_address(addr):
    try:
        return isinstance(ipaddress.ip_address(addr), ipaddress.IPv6Address)
    except Exception:
        return False

def join_host_port(host, port):
    if is_ipv6_address(host):
        return f'[{host}]:{port}'
    return f'{host}:{port}'

# Nova função para gerar um IPv4 aleatório
def generate_random_ipv4():
    """Gera um endereço IPv4 aleatório, evitando ranges reservados e privados."""
    while True:
        # Gera 4 octetos aleatórios
        o1 = random.randint(1, 254) # Evita 0 e 255 no primeiro octeto
        o2 = random.randint(0, 255)
        o3 = random.randint(0, 255)
        o4 = random.randint(1, 254) # Evita 0 e 255 no último octeto
        
        ip_str = f"{o1}.{o2}.{o3}.{o4}"
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            # Exclui ranges privados e reservados (ex: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, loopback, link-local)
            if not ip_obj.is_private and not ip_obj.is_reserved and not ip_obj.is_loopback and not ip_obj.is_link_local:
                return ip_str
        except Exception:
            pass # Continua tentando se for um IP inválido por algum motivo

class DoHResolver:
    def __init__(self, resolver_urls=None, cache_ttl=300, retries=2, retry_delay=0.7):
        self.resolver_urls = resolver_urls or [
            'https://one.one.one.one/dns-query',
            'https://dns.nextdns.io',
        ]
        self.cache_ttl = cache_ttl
        self.retries = retries
        self.retry_delay = retry_delay
        self._cache = {}
        self.q_types = []
        if ENABLE_IPV6:
            self.q_types.append('AAAA')
        self.q_types.append('A')
        logging.debug(f"DoHResolver initialized with resolvers: {self.resolver_urls}, Query Types: {self.q_types}")

    def resolve(self, hostname, depth=0, max_depth=5):
        if depth > max_depth:
            logging.error(f"Max CNAME resolution depth reached for {hostname}. Aborting DNS resolution.")
            return None
        if self._is_valid_ip(hostname):
            logging.debug(f"Hostname {hostname} is already an IP address.")
            return hostname

        cached_entry = self._cache.get(hostname)
        if cached_entry and time.time() < cached_entry[1]:
            logging.debug(f"Hostname {hostname} found in DoH cache: {cached_entry[0]}")
            return cached_entry[0]

        logging.debug(f"Attempting to resolve hostname {hostname} via DoH (depth: {depth})")
        for resolver_url in self.resolver_urls:
            for q_type in self.q_types:
                for attempt in range(self.retries):
                    try:
                        params = {'name': hostname, 'type': q_type}
                        headers = {'accept': 'application/dns-json', 'User-Agent': random.choice(USER_AGENTS)}
                        response = HTTP_SESSION.get(resolver_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT)
                        response.raise_for_status()
                        data = response.json()
                        ip_address = self._parse_doh_response(data, hostname, q_type, depth)
                        if ip_address:
                            ttl = data.get("Answer", [{}])[0].get("TTL", self.cache_ttl)
                            self._cache[hostname] = (ip_address, time.time() + ttl)
                            logging.debug(f"Successfully resolved {hostname} to {ip_address} (TTL: {ttl}s) using {resolver_url} for type {q_type}.")
                            return ip_address
                    except Exception as e:
                        logging.warning(f"DoH resolution attempt {attempt + 1}/{self.retries} for {hostname} (type {q_type}) via {resolver_url} failed: {e}")
                        if attempt < self.retries - 1:
                            time.sleep(jitter(self.retry_delay))
                        else:
                            continue
        logging.warning(f"Failed to resolve hostname {hostname} after all attempts.")
        return None

    def _parse_doh_response(self, data, hostname, q_type, depth):
        type_map = {'A': 1, 'AAAA': 28, 'CNAME': 5}
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map.get(q_type) and answer.get("name", "").lower() == hostname.lower():
                return answer.get("data")
        for answer in data.get("Answer", []):
            if answer.get("type") == type_map['CNAME']:
                cname = answer.get("data", "").rstrip('.')
                if cname:
                    logging.debug(f"Found CNAME for {hostname}: {cname}. Resolving CNAME.")
                    return self.resolve(cname, depth + 1)
        return None

    @staticmethod
    def _is_valid_ip(address):
        try:
            ipaddress.ip_address(address)
            return True
        except ValueError:
            return False

class BaseCache:
    def __init__(self, max_bytes):
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        logging.info(f"BaseCache initialized with max_bytes: {self.max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url): raise NotImplementedError
    def add(self, url, data): raise NotImplementedError
    def clear(self): raise NotImplementedError
    def get_stats(self): raise NotImplementedError

class RotatingChunkCache(BaseCache):
    def __init__(self, max_bytes=MAX_CACHE_SIZE_BYTES):
        super().__init__(max_bytes)
        self.chunks = OrderedDict()
        self.total_bytes = 0
        logging.info(f"RotatingChunkCache initialized with max_size: {self.max_bytes / (1024 * 1024):.2f} MB")

    def get(self, url):
        with self.lock:
            data = self.chunks.get(url)
            if data:
                self.chunks.move_to_end(url)
                logging.debug(f"Cache hit for chunk: {url}")
            return data

    def add(self, url, data: bytes):
        with self.lock:
            if url in self.chunks:
                self.total_bytes -= len(self.chunks.pop(url))

            chunk_size = len(data)
            if chunk_size > self.max_bytes:
                logging.warning(f"Chunk of size {chunk_size} bytes for {url} is larger than max cache size. Not caching.")
                return

            self.chunks[url] = data
            self.total_bytes += chunk_size
            self._shrink_to_limit()
            logging.debug(f"Chunk {url} (size: {chunk_size} bytes) added to cache. Current cache size: {self.total_bytes / (1024 * 1024):.2f} MB")

    def _shrink_to_limit(self):
        while self.total_bytes > self.max_bytes and self.chunks:
            old_url, old_data = self.chunks.popitem(last=False)
            self.total_bytes -= len(old_data)
            logging.debug(f"RotatingChunkCache shrinking: removed {old_url}. Current size: {self.total_bytes / (1024 * 1024):.2f} MB")

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.total_bytes = 0
            logging.info("RotatingChunkCache cleared.")

    def get_stats(self):
        with self.lock:
            return {"entries": len(self.chunks), "size_MB": round(self.total_bytes / 1048576, 2)}

class StreamCache:
    def __init__(self, chunk_cache: RotatingChunkCache):
        self.manifest_cache = {}
        self.chunk_cache = chunk_cache
        logging.info("StreamCache initialized.")

    def get_manifest(self, url):
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            logging.debug(f"Manifest found in RAM cache: {url}")
            return entry['content']
        logging.debug(f"Manifest not found or expired in RAM cache: {url}")
        return None

    def add_manifest(self, url, content, ttl=1):
        self.manifest_cache[url] = {'content': content, 'expires': time.time() + ttl}
        logging.debug(f"Manifest added to RAM cache: {url} with TTL {ttl}s.")

    def invalidate_manifest(self, url):
        """Remove um manifesto do cache, forçando uma nova requisição na próxima vez."""
        if url in self.manifest_cache:
            del self.manifest_cache[url]
            logging.info(f"Manifesto {url} invalidado e removido do cache.")

    def get_segment(self, url): return self.chunk_cache.get(url)
    def add_segment(self, url, data): self.chunk_cache.add(url, data)

    def get_recent_segments(self, count=0):
        logging.debug("get_recent_segments is not applicable for RotatingChunkCache.")
        return []

    def clear(self):
        self.manifest_cache.clear()
        self.chunk_cache.clear()
        logging.info("Stream cache (manifests and chunks) cleared.")

class UpstreamFetcher:
    def __init__(self, session, doh_resolver):
        self.session = session
        self.doh_resolver = doh_resolver
        logging.info("UpstreamFetcher initialized with IP protection")

    def fetch(self, url, stream=False, original_headers=None, retries=3):
        headers = random_player_headers(url)
        if original_headers:
            original_headers = clean_headers(original_headers)
            for key in ['Authorization', 'Cookie', 'User-Agent', 'Range']:
                if key in original_headers:
                    headers[key] = original_headers[key]

        # Injeta um IP falso no cabeçalho X-Forwarded-For se SPOOF_X_FORWARDED_FOR for True
        if SPOOF_X_FORWARDED_FOR:
            fake_ip = generate_random_ipv4()
            headers['X-Forwarded-For'] = fake_ip
            logging.debug(f"Adicionando X-Forwarded-For falso: {fake_ip} para {url}")

        parsed_url = urllib.parse.urlparse(url)
        resolved_ip = None
        if parsed_url.hostname and not self.doh_resolver._is_valid_ip(parsed_url.hostname):
            resolved_ip = self.doh_resolver.resolve(parsed_url.hostname)

        req_url = url
        if resolved_ip and resolved_ip != parsed_url.hostname:
            port = parsed_url.port
            scheme = parsed_url.scheme
            path = parsed_url.path or ''
            query = f'?{parsed_url.query}' if parsed_url.query else ''

            host_port = join_host_port(resolved_ip, port) if port else resolved_ip
            req_url = f"{scheme}://{host_port}{path}{query}"
            headers['Host'] = parsed_url.hostname
            logging.debug(f"Resolved {parsed_url.hostname} to {resolved_ip}. Requesting {req_url} with Host header.")

        for attempt in range(retries):
            try:
                resp = self.session.get(req_url, stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True)
                resp.raise_for_status()
                return resp
            except (Timeout, ConnectionError, HTTPError) as e:
                logging.warning(f"[Fetcher] Tentativa {attempt+1}/{retries} falhou para {url} (resolved to {resolved_ip}): {e}")
                if attempt == retries - 1:
                    logging.error(f"[Fetcher] Todas as {retries} tentativas falharam para {url}.")
                    raise e
                delay = jitter(0.25, percent=0.25)
                time.sleep(delay)
            except Exception as ex:
                logging.error(f"[Fetcher] Erro inesperado não recuperável em {url}: {ex}", exc_info=True)
                return None
        return None

def is_manifest_limit_error(content):
    if not content:
        return True
    txt = content.lower()
    if (
        "#mensagem:" in txt and "user" in txt
        or "too many users" in txt
        or "limite" in txt
        or "#limit" in txt
        or "maximum user" in txt
        or "conexoes simultaneas" in txt
        or "many connections" in txt
        or "max session" in txt
        or "total_users" in txt
        or "#error" in txt
    ):
        return True
    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    if lines == ["#extm3u"] or len(lines) <= 1:
        return True
    return False

class ManifestRewriter:
    def __init__(self, content, manifest_url, proxy_base_url):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        logging.debug(f"ManifestRewriter initialized for {manifest_url}. Proxy base: {proxy_base_url}")

    def rewrite(self):
        for playlist in getattr(self.m3u8_obj, 'playlists', []):
            if playlist.uri:
                original_uri = playlist.absolute_uri
                playlist.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote playlist URI from {original_uri} to {playlist.uri}")
        for media in getattr(self.m3u8_obj, 'media', []):
            if hasattr(media, 'uri') and media.uri:
                original_uri = media.absolute_uri
                media.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote media URI from {original_uri} to {media.uri}")
        for segment in getattr(self.m3u8_obj, 'segments', []):
            if segment.uri:
                original_uri = segment.absolute_uri
                segment.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote segment URI from {original_uri} to {segment.uri}")
            if segment.key and segment.key.uri:
                original_uri = segment.key.absolute_uri
                segment.key.uri = self.proxy_base_url + urllib.parse.quote_plus(original_uri)
                logging.debug(f"Rewrote key URI from {original_uri} to {segment.key.uri}")
        rewritten_manifest = self.m3u8_obj.dumps()
        logging.debug(f"Manifest rewritten successfully. First 200 chars: {rewritten_manifest[:200]}")
        return rewritten_manifest

    @property
    def is_live(self):
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self):
        target_duration = getattr(self.m3u8_obj, 'target_duration', 0)
        if self.is_live and target_duration:
            ttl = max(1, int(target_duration * 0.75))
            logging.debug(f"Live stream detected. Target duration: {target_duration}s, calculated TTL: {ttl}s.")
            return ttl
        logging.debug("VOD stream detected or no target duration. Default TTL: 600s.")
        return 600

def notify(msg, time_ms=3000):
    xbmc.executebuiltin(f'Notification({ADDON_NAME},{msg},{time_ms})')

def validate_url(url: str) -> bool:
    u = urllib.parse.urlparse(url)
    if not u.scheme in ('http', 'https'):
        logging.warning(f"Invalid URL scheme for {url}. Must be http or https.")
        return False
    if not u.netloc:
        logging.warning(f"URL has no network location (netloc): {url}.")
        return False
    if u.hostname in USER_BLOCKLIST:
        logging.warning(f"Hostname {u.hostname} is in the user blocklist for URL: {url}.")
        return False
    return True

def safe_mime_type(url, fallback='application/octet-stream'):
    ext = url.lower().split('?')[0]
    if ext.endswith('.m3u8'): return 'application/vnd.apple.mpegurl'
    if ext.endswith('.ts'): return 'video/mp2t'
    if ext.endswith('.aac'): return 'audio/aac'
    if ext.endswith('.mp4'): return 'video/mp4'
    logging.debug(f"Could not determine specific MIME type for {url}. Using fallback: {fallback}")
    return fallback

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, stream_cache, fetcher, proxy_manager, *args, **kwargs):
        self.cache = stream_cache
        self.fetcher = fetcher
        self.proxy_manager = proxy_manager
        self.log_level_map = {
            'info': logging.info,
            'warning': logging.warning,
            'error': logging.error,
            'debug': logging.debug
        }
        self.consecutive_segment_failures = 0 # Contador para falhas consecutivas de segmentos
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        pass

    def _log_request(self, message, level='info'):
        log_func = self.log_level_map.get(level, logging.info)
        client_address = self.address_string()
        log_func(f"[{client_address}] {self.command} {self.path} - {message}")

    def do_GET(self):
        self._log_request("Received request", level='debug')
        original_url = "unknown"
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            query_params = urllib.parse.parse_qs(parsed_path.query)
            original_url = query_params.get('url', [''])[0]

            if not original_url:
                self.send_error(400, "Missing 'url' parameter in proxy request")
                self._log_request("Missing 'url' parameter.", level='warning')
                return

            if SIMULATE_ERRORS and random.random() < 0.008:
                self._send_response(200, b"", "application/octet-stream")
                self._log_request(f"Simulated 503 error (sent as 200 with empty body) for {original_url}", level='warning')
                return

            self.headers = clean_headers(self.headers)

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            # Client disconnected gracefully (or ungracefully but expectedly)
            self._log_request(f"Client disconnected while serving {original_url}", level='info')
        except Exception as ex:
            # Catch all other unexpected errors.
            # Removed the `if not self.wfile.closed:` check here, as it's better handled within _send_response or _handle_segment.
            logging.error("General proxy error for %s: %s", original_url, str(ex), exc_info=True)
            # Only attempt to send error if the connection is likely still open.
            # This is a fallback and might also fail if connection is already closed.
            try:
                self.send_error(500, "Internal Server Error")
            except Exception:
                pass # Ignore errors if we can't send an error response

    def _handle_manifest(self, url, max_proxy_retries=1):
        self._log_request(f"Handling manifest: {url}", level='info')

        last_limit_hit = self.proxy_manager.get_limit_hit_time(url)
        if last_limit_hit and (time.time() - last_limit_hit < LIMIT_COOLDOWN_SECONDS):
            remaining_cooldown = int(LIMIT_COOLDOWN_SECONDS - (time.time() - last_limit_hit))
            self._log_request(f"Manifest {url} está em cooldown de limite de usuários. Tentando novamente em {remaining_cooldown} segundos.", level='warning')
            notify(f"Limite de usuários atingido para este canal. Tente novamente em {remaining_cooldown} segundos.", 5000)
            self._send_response(200, "#EXTM3U\n", 'application/vnd.apple.mpegurl')
            return

        for proxy_attempt in range(max_proxy_retries):
            cached = self.cache.get_manifest(url)
            if cached and not is_manifest_limit_error(cached):
                if not cached.strip():
                    self._log_request("Manifesto em cache vazio! Retornando mínimo válido.", level='warning')
                    return self._send_response(200, "#EXTM3U\n", 'application/vnd.apple.mpegurl')
                self._log_request(f"Serving manifest from cache: {url} (Proxy attempt {proxy_attempt + 1})", level='debug')
                return self._send_response(200, cached, 'application/vnd.apple.mpegurl')

            self._log_request(f"Fetching manifest {url} from upstream (Proxy attempt {proxy_attempt + 1})", level='debug')
            response = self.fetcher.fetch(url, original_headers=self.headers)
            if response and response.ok:
                is_limit_error = is_manifest_limit_error(response.text)
                if is_limit_error:
                    # Verifica se é uma mensagem explícita de limite ou apenas um manifesto vazio/mínimo
                    if not response.text.strip() or len([l.strip() for l in response.text.splitlines() if l.strip()]) <= 1:
                        self._log_request(f"Manifesto vazio/mínimo detectado para {url}. Tratando como erro de limite de usuários.", level="warning")
                        notify("O stream retornou um manifesto vazio ou incompleto. Isso pode indicar um limite de usuários ou um problema com o stream. Tentando novamente mais tarde.", 5000)
                    else:
                        self._log_request(f"Manifesto retornou erro de limite de usuários!", level="warning")
                        notify("Limite de usuários atingido para este canal.", 5000)

                    self.proxy_manager.record_limit_hit(url)
                    self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
                    response.close()
                    return
                try:
                    rewriter = ManifestRewriter(response.text, response.url, f"http://{self.server.server_address[0]}:{self.server.server_address[1]}/?url=")
                    rewritten_content = rewriter.rewrite()
                    if not rewritten_content.strip():
                        self._log_request("Manifesto reescrito ficou vazio! Retornando mínimo válido.", level="error")
                        response.close()
                        return self._send_response(200, "#EXTM3U\n", 'application/vnd.apple.mpegurl')
                    ttl = rewriter.get_ttl()
                    self.cache.add_manifest(url, rewritten_content, ttl=ttl)
                    self._log_request(f"Manifest {url} fetched, rewritten, cached (TTL: {ttl}s) and served (Proxy attempt {proxy_attempt + 1}).", level='info')
                    response.close()
                    self.proxy_manager.clear_limit_hit(url)
                    return self._send_response(200, rewritten_content, 'application/vnd.apple.mpegurl')
                except Exception as e:
                    logging.error(f"Error processing manifest {url} (Proxy attempt {proxy_attempt + 1}): {e}", exc_info=True)
                    if response: response.close()
            else:
                status_code = response.status_code if response else 502
                logging.warning(f"Upstream manifest fetch failed with status {status_code}: sending 200 with minimal manifest to player.")
                self._send_response(200, "#EXTM3U\n", "application/vnd.apple.mpegurl")
                if response: response.close()
                return

    def _handle_segment(self, url, max_proxy_retries=2):
        self._log_request(f"Handling segment: {url}", level='info')
        mime_type = safe_mime_type(url)
        SILENT_TS_SEGMENT = bytes([
            0x47, 0x1F, 0xFF, 0x10, 0x00, 0x00, 0xB0, 0x0D, 0x00, 0x01, 0xC1, 0x00, 0x00, 0x00, 0x01, 0xF0
        ] + [0xFF] * 179)

        cached_segment = self.cache.get_segment(url)
        if cached_segment:
            self.consecutive_segment_failures = 0 # Reset count on successful cache hit
            self._log_request(f"Serving segment from rotating cache: {url}", level='debug')
            return self._send_response(200, cached_segment, mime_type)

        for attempt in range(max_proxy_retries):
            self._log_request(f"Fetching segment {url} from upstream (Attempt {attempt + 1}/{max_proxy_retries})", level='debug')
            response = None
            try:
                response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
                if response and response.ok:
                    _cached_data = bytearray()
                    self.send_response(200)
                    for h, v in response.headers.items():
                        if h.lower() not in ('transfer-encoding', 'connection', 'content-encoding', 'content-length', 'keep-alive'):
                            self.send_header(h, v)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0')
                    
                    # Ensure headers are sent before starting to write content
                    try:
                        self.end_headers()
                    except (BrokenPipeError, ConnectionResetError):
                        logging.info(f"Client disconnected before headers could be sent for segment {url}. Aborting.")
                        if response: response.close()
                        return # Exit the function if client disconnected

                    bytes_sent = 0
                    for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                        if not chunk: continue
                        try:
                            self.wfile.write(chunk)
                        except (BrokenPipeError, ConnectionResetError):
                            logging.info(f"Client disconnected while streaming segment {url}. Aborting.")
                            if response: response.close()
                            return # Exit the function if client disconnected mid-stream
                        bytes_sent += len(chunk)
                        if bytes_sent <= MAX_SEGMENT_SIZE_BYTES:
                            _cached_data.extend(chunk)

                    self._log_request(f"Segment {url} streamed to client. Total bytes sent: {bytes_sent}.", level='debug')

                    if len(_cached_data) > 0 and len(_cached_data) <= MAX_SEGMENT_SIZE_BYTES:
                        self.cache.add_segment(url, bytes(_cached_data))
                        self._log_request(f"Segment {url} (size: {len(_cached_data)} bytes) added to rotating cache.", level='debug')

                    if response: response.close()
                    self.consecutive_segment_failures = 0 # Reset count on successful stream
                    return

                status_code = response.status_code if response else 502
                logging.warning(f"Upstream segment fetch for {url} failed with status {status_code} on attempt {attempt + 1}.")
                if response: response.close()

            except (BrokenPipeError, ConnectionResetError):
                logging.info(f"Client disconnected while serving segment {url}. Aborting.")
                if response: response.close()
                return
            except Exception as e:
                logging.warning(f"Error fetching/streaming segment {url} on attempt {attempt + 1}: {e}", exc_info=True)
                if response: response.close()

            if attempt < max_proxy_retries - 1:
                delay = jitter(0.1, percent=0.01)
                logging.info(f"Retrying segment fetch for {url} in {delay:.2f} seconds...")
                time.sleep(delay)
            else: # All attempts failed for this specific segment
                self.consecutive_segment_failures += 1
                self._log_request(f"Segment {url} failed after all retries. Consecutive failures: {self.consecutive_segment_failures}", level='warning')

                # ==== Nova lógica para falhas consecutivas de segmentos ====
                if self.consecutive_segment_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES:
                    self._log_request(f"ATINGIU O LIMITE DE FALHAS CONSECUTIVAS ({MAX_CONSECUTIVE_SEGMENT_FAILURES}) para o stream de {url}. Tentando reconectar...", level='error')

                    # Tenta encontrar o manifesto base para invalidar
                    manifest_url_for_invalidation = self._find_manifest_url_from_segment(url)
                    if manifest_url_for_invalidation:
                        self.proxy_manager.invalidate_manifest_cache(manifest_url_for_invalidation)
                        self._log_request(f"Manifesto {manifest_url_for_invalidation} invalidado devido a falhas consecutivas de segmentos.", level='warning')
                    else:
                        self._log_request(f"Não foi possível determinar o manifesto para invalidar a partir de {url}.", level='warning')

                    self.consecutive_segment_failures = 0 # Reseta o contador após a tentativa de reconexão
                # ==== Fim da nova lógica ====

        self._log_request(f"Todas as tentativas de busca para {url} falharam. Enviando TS silencioso para player não travar.", level='error')
        self._send_response(200, SILENT_TS_SEGMENT, mime_type)

    def _find_manifest_url_from_segment(self, segment_url):
        # Esta função tenta heurísticamente encontrar o URL do manifesto pai
        # para que possamos invalidá-lo e forçar uma nova requisição pelo Kodi.
        # Pode não ser 100% precisa para todos os casos de HLS complexos.
        try:
            parsed = urllib.parse.urlparse(segment_url)
            path = parsed.path

            # Se já é um manifesto, retorna
            if '.m3u8' in path.lower() or '.m3u' in path.lower():
                return segment_url

            # Tenta subir um nível na URL para encontrar um manifesto
            parts = path.split('/')
            for i in range(len(parts) - 1, 0, -1):
                potential_base_path = '/'.join(parts[:i])
                if potential_base_path:
                    # Tenta os nomes de manifesto mais comuns
                    for manifest_name in ['master.m3u8', 'index.m3u8', 'playlist.m3u8']:
                        manifest_url = urllib.parse.urlunparse(parsed._replace(path=f"{potential_base_path}/{manifest_name}", query=''))
                        logging.debug(f"Tentativa de manifesto a partir do segmento: {manifest_url}")
                        return manifest_url

            # Último recurso: tenta um manifesto na raiz
            root_manifest = urllib.parse.urlunparse(parsed._replace(path='/master.m3u8', query=''))
            logging.debug(f"Tentativa de manifesto na raiz: {root_manifest}")
            return root_manifest

        except Exception as e:
            logging.debug(f"Erro ao tentar encontrar URL do manifesto a partir do segmento {segment_url}: {e}")
        return None


    def _send_response(self, code, content, content_type):
        encoded = content.encode('utf-8') if isinstance(content, str) else content
        try:
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(encoded)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(encoded)
            self._log_request(f"Response sent (code: {code}, type: {content_type}, size: {len(encoded)} bytes).", level='debug')
        except (BrokenPipeError, ConnectionResetError):
            self._log_request(f"Client disconnected while sending response for {content_type}.", level='info')
        except Exception as ex:
            logging.error("Error sending response: %s", str(ex), exc_info=True)

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self.active_bind_host = None
        self.doh_resolver = DoHResolver()
        self.chunk_cache = RotatingChunkCache(MAX_CACHE_SIZE_BYTES)
        logging.info("Usando cache de segmentos rotativo na memória.")
        self.stream_cache = StreamCache(self.chunk_cache)
        self.fetcher = UpstreamFetcher(HTTP_SESSION, self.doh_resolver)
        self.recent_limit_failures = {}
        logging.info("HLSProxyManager initialized.")

    def record_limit_hit(self, url):
        self.recent_limit_failures[url] = time.time()
        logging.debug(f"Limite de usuário registrado para {url} em {self.recent_limit_failures[url]}")

    def get_limit_hit_time(self, url):
        return self.recent_limit_failures.get(url)

    def clear_limit_hit(self, url):
        if url in self.recent_limit_failures:
            del self.recent_limit_failures[url]
            logging.debug(f"Registro de limite de usuário limpo para {url}")

    def invalidate_manifest_cache(self, manifest_url):
        """Método para o HLSProxyHandler chamar para invalidar um manifesto."""
        self.stream_cache.invalidate_manifest(manifest_url)


    def start(self):
        self.stop()
        handler_with_deps = functools.partial(HLSProxyHandler, self.stream_cache, self.fetcher, self)

        target_bind_hosts = []
        if PROXY_HOST not in ['127.0.0.1', '0.0.0.0', '::', '::1']:
            target_bind_hosts.append(PROXY_HOST)
        else:
            if PROXY_HOST == '::':
                target_bind_hosts.append('::')
                if ENABLE_IPV6:
                    target_bind_hosts.append('0.0.0.0')
            elif PROXY_HOST == '0.0.0.0':
                target_bind_hosts.append('0.0.0.0')
                if ENABLE_IPV6:
                    target_bind_hosts.append('::')
            else:
                if ENABLE_IPV6:
                    target_bind_hosts.append('::1')
                target_bind_hosts.append('127.0.0.1')

        seen = set()
        unique_target_bind_hosts = []
        for host in target_bind_hosts:
            if host not in seen:
                unique_target_bind_hosts.append(host)
                seen.add(host)
        target_bind_hosts = unique_target_bind_hosts

        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)

            for bind_host in target_bind_hosts:
                try:
                    # Usando ThreadingTCPServer para lidar com múltiplas requisições concorrentemente
                    self.server = socketserver.ThreadingTCPServer((bind_host, port), handler_with_deps)
                    self.server.allow_reuse_address = True

                    if is_ipv6_address(bind_host) and hasattr(socket, 'IPPROTO_IPV6') and hasattr(socket, 'IPV6_V6ONLY'):
                        try:
                            self.server.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                            logging.debug(f"Set IPV6_V6ONLY to 0 for dual-stack on {bind_host}:{port}")
                        except OSError as e:
                            logging.warning(f"Could not set IPV6_V6ONLY to 0 on {bind_host}:{port}: {e}. May not support IPv4-mapped addresses.")

                    self.active_port = port
                    self.active_bind_host = bind_host
                    self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                    self.server_thread.start()
                    logging.info(f"HLS Proxy started successfully on {self.active_bind_host}:{self.active_port}.")
                    return self.active_port
                except Exception as ex:
                    logging.warning(f"Failed to start proxy on {bind_host}:{port}: {ex}. Trying next bind address or port. Attempt {attempt + 1}/{MAX_PORT_ATTEMPTS}.", exc_info=True)
        logging.error(f"Failed to start HLS Proxy after {MAX_PORT_ATTEMPTS} attempts. No free port/address combination found or general error.")
        notify("Erro fatal: Não foi possível iniciar o proxy HLS. Nenhuma porta livre encontrada ou erro interno.", 7000)
        return None

    def stop(self):
        if self.server:
            logging.info(f"Stopping HLS Proxy on port {self.active_port}")
            try:
                self.server.shutdown()
                self.server.server_close()
                logging.debug("Proxy server shut down and closed.")
            except Exception as e:
                logging.error(f"Error during proxy server shutdown: {e}", exc_info=True)
            self.server = None
        if self.server_thread and self.server_thread.is_alive():
            logging.debug("Waiting for proxy server thread to join...")
            self.server_thread.join(timeout=2)
            if self.server_thread.is_alive():
                logging.warning("Proxy server thread did not terminate gracefully.")
            else:
                logging.debug("Proxy server thread joined successfully.")
        self.stream_cache.clear()
        self.active_port = None
        self.active_bind_host = None
        logging.info("HLS Proxy completely stopped and resources released.")

    def get_proxy_url(self, original_url):
        if not self.active_port: return None
        display_host = self.active_bind_host
        if display_host == '0.0.0.0':
            display_host = '127.0.0.1'
        elif display_host == '::':
            display_host = '::1'

        url_encoded = urllib.parse.quote_plus(original_url)
        return f"http://{join_host_port(display_host, self.active_port)}/?url={url_encoded}"

class CustomPlayer(xbmc.Player):
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        logging.info("CustomPlayer initialized with stop event.")

    def onPlayBackStarted(self):
        logging.info("Kodi playback started.")
        self.stop_event.clear()

    def onPlayBackEnded(self):
        logging.info("Kodi playback ended.")
        self.stop_event.set()

    def onPlayBackError(self):
        logging.error("Kodi playback error occurred.")
        self.stop_event.set()

    def onPlayBackStopped(self):
        logging.info("Kodi playback stopped by user.")
        self.stop_event.set()

class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)
        logging.info("HLSProxyAddon instance created.")

    def convert_to_m3u8(self, url):
        original_url = url
        logging.debug(f"Attempting to convert URL to M3U8 format: {url}")
        try:
            if '|' in url:
                url = url.split('|')[0]
                logging.debug(f"Removed '|' and everything after: {url}")
            elif '%7C' in url:
                url = url.split('%7C')[0]
                logging.debug(f"Removed '%7C' and everything after: {url}")

            if not (('.m3u8' in url.lower() or '.m3u' in url.lower()) or
                    (url.lower().endswith(('.mp4', '.avi', '.ts', '.mkv', '.webm')))):
                parsed_url = urllib.parse.urlparse(url)
                path = parsed_url.path.lower()
                
                # Só tenta adicionar .m3u8 se não for um arquivo de vídeo direto e não tiver extensão
                if '.' not in os.path.basename(path) and url.count("/") > 3:
                    url = url + '.m3u8'
                    logging.debug(f"Appended .m3u8 to URL (heuristic): {url}")
                

        except Exception as e:
            logging.warning(f"Heuristic conversion failed for {original_url}: {e}. Returning original URL.", exc_info=True)
            return original_url
        logging.debug(f"Final URL after convert_to_m3u8: {url}")
        return url

    def play_stream(self, url, channel_name=None):
        logging.info(f"Attempting to play stream: {url}")
        processed_url = self.convert_to_m3u8(url)
        logging.info(f"URL after convert_to_m3u8: {processed_url}")
        if not validate_url(processed_url):
            notify("URL inválida, bloqueada ou não suportada.", 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        port = self.proxy_manager.start()
        if not port:
            notify("Erro fatal ao iniciar proxy local. Verifique os logs.", 5000)
            logging.error("Failed to start proxy, cannot resolve URL for Kodi.")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if channel_name:
            display_label = f"{channel_name} [COLOR lightblue](Meu HLS Player)[/COLOR]"
        else:
            display_label = "[COLOR lightblue]Meu HLS Player[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_label)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType(safe_mime_type(processed_url)) # Use safe_mime_type
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        logging.info(f"Kodi resolved URL to proxy: {proxy_url}")

        monitor_thread = threading.Thread(target=self.monitor_playback, daemon=True)
        monitor_thread.start()
        logging.debug("Playback monitor thread started.")

    def monitor_playback(self):
        logging.info("Starting playback monitoring...")
        try:
            # Wait for the playback to stop, with a very long timeout as a failsafe
            # A more robust solution might involve polling xbmc.Player().isPlaying()
            # or relying solely on the onPlayBack* events.
            was_stopped = self.playback_stop_event.wait(timeout=86400) # Wait up to 24 hours
            if was_stopped:
                logging.info("Playback stop event received. Releasing proxy resources.")
            else:
                logging.warning("Playback monitoring timed out (24h). Releasing proxy resources as a safeguard.")
        except Exception as e:
            logging.error(f"Error during playback monitoring: {e}", exc_info=True)
        finally:
            logging.info("Ensuring proxy resources are released.")
            self.proxy_manager.stop()
            logging.info("Proxy resources released.")

    def show_test_streams(self):
        test_streams = [
            ("Live Exemplo (Caminho da Web)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Big Buck Bunny (VOD - 1080p)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Apple Test HLS (Advanced)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"),
            ("Google Shaka Test (DRM-Free)", "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8"),
            ("Exemplo TS Direto (MIME Detect)", "http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_1080p_60fps_normal.mp4")
        ]
        logging.info("Displaying test streams.")
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=f"{name} [COLOR lightblue](Reprodução via Proxy Meu HLS Player)[/COLOR]")
            li.setProperty('IsPlayable', 'true')
            li.setMimeType(safe_mime_type(url)) # Use safe_mime_type
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False)
            logging.debug(f"Added directory item: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url_to_play = params.get('url')
    channel_title = params.get('title')

    # Correção: Adicione suporte para a ação 'play_hls_stream' e o parâmetro 'path'
    if action == 'play_hls_stream':
        url_to_play = params.get('path') # Mapeia 'path' para 'url_to_play'
        if not channel_title:
            channel_title = "Stream via Meu HLS Player" # Título padrão para esta ação, se não fornecido

    addon = HLSProxyAddon()
    # Modificado para aceitar 'play' ou 'play_hls_stream'
    if (action == 'play' or action == 'play_hls_stream') and url_to_play:
        addon.play_stream(url_to_play, channel_title)
    else:
        addon.show_test_streams()