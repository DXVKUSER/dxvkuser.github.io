# -*- coding: utf-8 -*-
"""
HLS Proxy v4.9.4 - Correção: Renomeado playstream para play_stream
Proxy adaptativo para streaming HLS no Kodi, com retries, ajuste de timeouts e tratamento robusto de erros.
"""

import sys
import threading
import random
import logging
import urllib.parse
import time
import os
import http.server
import socketserver
import socket
from http.client import RemoteDisconnected
from urllib3.exceptions import MaxRetryError, NewConnectionError
import json
import re # Módulo para expressões regulares

try:
    import requests
except ImportError:
    requests = None

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except Exception:
    xbmc = xbmcgui = xbmcplugin = None

# Configurações padrão e constantes
DEFAULTCONNECTIONTIMEOUT = 7.0
DEFAULTSTREAMTIMEOUT = 10.0
DEFAULTCHUNKSIZE = 50 * 1024
DEFAULTMAXRETRYATTEMPTS = 1 # Valor padrão inicial
MAXPORTATTEMPTS = 20
PROXYHOST = '0.0.0.0'
LOGLEVEL = logging.INFO

def setuplogging():
    global LOGLEVEL
    try:
        if xbmc:
            # Kodi cuida do próprio logging
            pass
        else:
            logging.basicConfig(level=LOGLEVEL,
                                format='%(asctime)s %(threadName)s %(levelname)s %(message)s')
    except Exception as e:
        print('Erro ao configurar logging: %s' % e)
        # Ambiente standalone, configura console
        logging.basicConfig(level=LOGLEVEL,
                            format='%(asctime)s %(threadName)s %(levelname)s %(message)s')

def obfuscate_url(url):
    """Substitui a URL principal e o token por um placeholder para ofuscação no log."""
    if not url:
        return "[EMPTY_URL]"
    
    # Decodifica temporariamente se for uma URL codificada (como as do Kodi)
    temp_url = urllib.parse.unquote_plus(url)
    
    # Expressão para capturar o protocolo e o host
    match = re.match(r'^(https?://[^/]+)', temp_url)
    
    if match:
        # Substitui o host e o caminho principal, mantendo a extensão ou query se houver
        # Não substitui a URL inteira por [OBFUSCATED_URL], mas só a parte do host/origem
        obfuscated_path = re.sub(r'https?://[^/]+', r'[OBFUSCATED_URL_HOST]', temp_url, 1)
        
        # Ofusca o token (parte mais sensível do segmento)
        obfuscated_path = re.sub(r'token=([^&]+)', r'token=[OBFUSCATED_TOKEN]', obfuscated_path)
        
        return obfuscated_path
    
    # Retorna a URL original se não for uma URL http(s) válida (ex: é apenas um nome de arquivo)
    return url

class HLSTuner:
    """Gerencia parâmetros adaptativos do stream (timeouts, chunk size, retries)"""
    def __init__(self,
                 initialconntimeout=DEFAULTCONNECTIONTIMEOUT,
                 initialstreamtimeout=DEFAULTSTREAMTIMEOUT,
                 initialchunksize=DEFAULTCHUNKSIZE,
                 initialmaxretries=DEFAULTMAXRETRYATTEMPTS):
        self.conntimeout = initialconntimeout
        self.streamtimeout = initialstreamtimeout
        self.chunksize = initialchunksize
        self.maxretryattempts = initialmaxretries 
        self.MAX_RETRY_LIMIT = 3 
        self.lastrtt = 0.0
        self.failurecount = 0

    def adjustconntimeout(self, rtt):
        newtimeout = max(2.0, min(10.0, rtt * 1.5))
        if abs(self.conntimeout - newtimeout) > 0.5:
            logging.debug(f"Ajustando Conn Timeout {self.conntimeout:.1f}s -> {newtimeout:.1f}s Avg RTT {rtt:.2f}s")
            self.conntimeout = newtimeout

    def adjuststreamtimeout(self, duration):
        newtimeout = max(10.0, min(30.0, duration * 1.5))
        if abs(self.streamtimeout - newtimeout) > 2.0:
            logging.debug(f"Ajustando Stream Timeout {self.streamtimeout:.1f}s -> {newtimeout:.1f}s Duracao {duration:.2f}s")
            self.streamtimeout = newtimeout

    def adjustchunksize(self, avgbps):
        newchunksize = self.chunksize
        if avgbps > 1024 * 1024:  # se > 1MB/s
            newchunksize = min(256 * 1024, self.chunksize * 2)
        elif avgbps > 256 * 1024 and self.chunksize < 256 * 1024:
            newchunksize = max(32 * 1024, self.chunksize * 2)
        if newchunksize != self.chunksize:
            logging.debug(f"Ajustando Chunk Size {self.chunksize} -> {newchunksize} Avg BPS {avgbps / 1024:.2f} KBs")
            self.chunksize = newchunksize

    def trackfailure(self, errortype):
        self.failurecount += 1
        logging.warning(f"Falha consecutiva {errortype} {self.failurecount}")
        
        # Lógica de ajuste adaptativo para retries: aumenta tentativas em caso de falha
        new_retries = min(self.MAX_RETRY_LIMIT, self.maxretryattempts + 1)
        if new_retries != self.maxretryattempts:
             logging.warning(f"Ajustando Max Retries {self.maxretryattempts} -> {new_retries} devido à falha.")
             self.maxretryattempts = new_retries

    def resetfailures(self):
        if self.failurecount > 0:
            logging.info("Conexao reestabelecida. Resetando contador de falhas.")
            self.failurecount = 0
            
        # Lógica de ajuste adaptativo para retries: diminui tentativas em caso de sucesso
        new_retries = max(DEFAULTMAXRETRYATTEMPTS, self.maxretryattempts - 1)
        if new_retries != self.maxretryattempts:
            logging.info(f"Ajustando Max Retries {self.maxretryattempts} -> {new_retries} devido ao sucesso.")
            self.maxretryattempts = new_retries


class HLSProxy:
    """Proxy global singleton para gerenciar tunner e sessão HTTP"""
    def __init__(self):
        self.server = None
        self.serverthread = None
        self.lock = threading.Lock()
        self.tuner = HLSTuner()
        self.session = requests.Session() if requests else None
        self.port = None
        self.manifestcache = {}

    def start(self, port=0):
        if self.server:
            return
        with self.lock:
            for attempt in range(MAXPORTATTEMPTS):
                try:
                    p = port if port else random.randint(8000, 9000)
                    self.server = ThreadedHTTPServer((PROXYHOST, p), HLSProxyRequestHandler)
                    self.port = p
                    break
                except OSError as e:
                    if 'Address already in use' in str(e) and not port:
                        logging.debug(f"Porta {p} em uso, tentando próxima...")
                        continue
                    raise e
            else:
                raise Exception("Não foi possível encontrar uma porta livre.")
            self.server.proxyinstance = self
            self.serverthread = threading.Thread(target=self.server.serve_forever)
            self.serverthread.daemon = True
            self.serverthread.start()
            logging.info(f"HLS Proxy rodando em http://{PROXYHOST}:{self.port}")

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
            self.serverthread = None
            logging.info("HLS Proxy parado.")
    
    # Adicionado para ser usado por HLSAddon.play_stream
    def getproxyurl(self, originalurl):
        if not self.port:
            raise Exception("Proxy não iniciado.")
        encodedurl = urllib.parse.quote_plus(originalurl)
        # Ofusca a URL original ANTES de codificar/enviar
        logging.debug(f"Gerando URL proxy para {obfuscate_url(originalurl)}") 
        return f"http://127.0.0.1:{self.port}/play/{encodedurl}.m3u8"


    def getsession(self):
        if not self.session:
            raise Exception("Módulo requests ausente.")
        return self.session

    def fetchurl(self, url, method='GET', headers=None, stream=False, segmentfetch=False):
        session = self.getsession()
        conntimeout = self.tuner.conntimeout
        streamtimeout = self.tuner.streamtimeout if segmentfetch else conntimeout
        ismanifestfetch = not segmentfetch
        max_retries = self.tuner.maxretryattempts
        
        obf_url = obfuscate_url(url)

        for attempt in range(1, max_retries + 1):
            shouldresetsession = False
            try:
                response = session.request(method, url, headers=headers, stream=stream,
                                           timeout=(conntimeout, streamtimeout))
                if response.status_code == 200:
                    self.tuner.resetfailures()
                    return response

                if ismanifestfetch:
                    logging.warning(f"Tentativa {attempt}/{max_retries} falhou Manifesto - Status {response.status_code}. URL: {obf_url}. Forcando reset de sessao.")
                    shouldresetsession = True
                else:
                    logging.warning(f"Tentativa {attempt}/{max_retries} falhou Status HTTP {response.status_code} para {obf_url}")

            except Exception as e:
                errstr = str(e)
                if segmentfetch:
                    # RemoteDisconnected é comum em segmentos
                    if isinstance(e, (ConnectionResetError, RemoteDisconnected)):
                        logging.warning(f"Tentativa {attempt}/{max_retries} falhou segmento (Conn/Remote Disconnect). URL: {obf_url}.")
                    else:
                        logging.warning(f"Tentativa {attempt}/{max_retries} falhou segmento {errstr.splitlines()[0]}. URL: {obf_url}")
                    self.tuner.trackfailure('segment')
                else:
                    logging.warning(f"Tentativa {attempt}/{max_retries} falhou Manifesto Exception {errstr.splitlines()[0]}. URL: {obf_url}")
                    self.tuner.trackfailure('connection')
                    shouldresetsession = True

                if isinstance(e, (ConnectionResetError, RemoteDisconnected, MaxRetryError, NewConnectionError)):
                    shouldresetsession = True

            if shouldresetsession:
                logging.info("Aplicando reset de sessao HTTP proativo.")
                # Recria a sessão para resetar o estado
                self.session = requests.Session()

            if attempt == max_retries:
                break
            time.sleep(0.5)
        logging.error(f"Falha final ao buscar URL {obf_url}")
        return None

    def fetchsegment(self, handler, url):
        starttime = time.time()
        response = self.fetchurl(url, stream=True, segmentfetch=True)
        if response is None:
            logging.error("Falha crítica ao buscar segmento. Retornando 0 bytes para PULAR SEGMENTO.")
            return 0, 0, None
        try:
            totalsize = 0
            for chunk in response.iter_content(self.tuner.chunksize):
                if chunk:
                    try:
                        handler.wfile.write(chunk)
                        totalsize += len(chunk)
                    except (ConnectionResetError, BrokenPipeError, OSError) as e:
                        logging.warning(f"Conexão fechada pelo cliente durante o envio do segmento: {e}")
                        response.close()
                        return totalsize, time.time() - starttime, True
            endtime = time.time()
            duration = endtime - starttime
            if duration > 0 and totalsize > 0:
                avgbps = totalsize * 8 / duration
                self.tuner.adjuststreamtimeout(duration)
                self.tuner.adjustchunksize(avgbps)
                self.tuner.adjustconntimeout(duration) # RTT do segmento
            return totalsize, duration, None
        except Exception as e:
            logging.error(f"Erro de conexão ou streaming ao enviar para o cliente Kodi: {e}")
            return 0, time.time() - starttime, True
        finally:
            # Garante que o objeto response seja fechado
            if response:
                response.close()


    def fetchandrewriteplaylist(self, handler, playlisturl):
        response = self.fetchurl(playlisturl)
        obf_playlisturl = obfuscate_url(playlisturl)
        
        if response is None:
            if playlisturl in self.manifestcache:
                rewritten = self.manifestcache[playlisturl]
                try:
                    handler.wfile.write(rewritten)
                except (ConnectionResetError, BrokenPipeError, OSError):
                    logging.warning("Conexão fechada pelo cliente ao enviar manifesto em cache")
                return
            else:
                placeholder = (
                    "#EXTM3U\n"
                    "#EXT-X-VERSION:3\n"
                    "#EXT-X-TARGETDURATION:10\n"
                    "#EXT-X-MEDIA-SEQUENCE:0\n"
                    "#EXT-X-ENDLIST\n"
                ).encode('utf-8')
                try:
                    handler.wfile.write(placeholder)
                except (ConnectionResetError, BrokenPipeError, OSError):
                    logging.warning("Conexão fechada pelo cliente ao enviar placeholder")
                logging.warning(f"Falha ao buscar playlist {obf_playlisturl} sem cache disponível. Enviando placeholder para evitar travamento.")
                return
        try:
            playlistcontent = response.text
            baseurl = response.url
            # Acessar o proxy instance através do server
            proxyhost = f"http://127.0.0.1:{handler.server.proxyinstance.port}"
            lines = playlistcontent.splitlines()
            newlines = []
            for line in lines:
                if line.startswith("#") or not line.strip():
                    newlines.append(line)
                    continue
                absurl = urllib.parse.urljoin(baseurl, line.strip())
                encodedurl = urllib.parse.quote_plus(absurl)
                if ".m3u8" in absurl.lower():
                    # Para playlists filhas
                    proxypath = f"{proxyhost}/playlist/{encodedurl}.m3u8"
                else:
                    # Para segmentos
                    proxypath = f"{proxyhost}/segment/{encodedurl}.ts"
                newlines.append(proxypath)
            rewrittenplaylist = "\n".join(newlines).encode('utf-8')
            try:
                handler.wfile.write(rewrittenplaylist)
            except (ConnectionResetError, BrokenPipeError, OSError):
                logging.warning("Conexão fechada pelo cliente ao enviar manifesto reescrito")
                return
            self.manifestcache[playlisturl] = rewrittenplaylist
            logging.debug(f"Manifesto cached para {obf_playlisturl}")
        except Exception as e:
            logging.error(f"Erro ao reescrever playlist: {e}")
        finally:
            # Garante que o objeto response seja fechado
            if response:
                response.close()

class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):

    def __init__(self, request, client_address, server):
        self.connectionclosed = False
        try:
            super().__init__(request, client_address, server)
        except (ConnectionResetError, BrokenPipeError, OSError) as e:
            logging.warning(f"Conexão fechada durante inicialização do handler: {e}")
            self.connectionclosed = True
        except Exception:
            self.connectionclosed = True
            raise

    def finish_response(self):
        # Tenta fechar o wfile sempre
        try:
            self.wfile.close()
        except (ConnectionResetError, BrokenPipeError, OSError):
            self.connectionclosed = True
            logging.error("Falha na transmissão para o cliente. Conexão com o cliente fechada para forçar re-tentativa.")
        except Exception as e:
            logging.debug(f"Erro ao tentar fechar wfile: {e}")

        # Tenta finalizar a resposta do handler base
        try:
            if not self.connectionclosed:
                super().finish_response()
        except (ConnectionResetError, BrokenPipeError, OSError) as e:
            logging.debug(f"Conexão fechada durante finalização da resposta base: {e}")
            self.connectionclosed = True
        except Exception as e:
            logging.debug(f"Erro durante finalização da resposta base: {e}")
            self.connectionclosed = True
            
    # Sobrescreve log_request para ofuscar o path
    def log_request(self, code='-', size='-'):
        # path já está em self.path (que é a URL do proxy com a URL original codificada)
        obfuscated_path = self.path
        try:
            # Tenta decodificar a URL original e ofusca
            if "/play/" in self.path or "/playlist/" in self.path or "/segment/" in self.path:
                parts = self.path.split("/", 2)
                if len(parts) == 3:
                    requesttype = parts[1]
                    encodedurl_ext = parts[2]
                    originalurl = urllib.parse.unquote_plus(encodedurl_ext.rsplit(".", 1)[0])
                    obf_url = obfuscate_url(originalurl)
                    # O path ofuscado no log para /play/ é simplificado
                    obfuscated_path = f"/{requesttype}/{obf_url.split('/')[0]}.m3u8" if requesttype != "segment" else f"/{requesttype}/{obf_url.split('/')[0]}.ts"

        except Exception:
            # Se a decodificação falhar, mantém o path original do proxy
            pass

        # Usa o formato de log padrão do BaseHTTPRequestHandler, mas com o path ofuscado
        logging.error(f"{self.client_address[0]} - - [{self.log_date_time_string()}] \"{self.command} {obfuscated_path} {self.request_version}\" {code} {size}")


    def do_GET(self):
        if self.connectionclosed:
            return
        
        proxy_instance = self.server.proxyinstance
        
        try:
            pathparts = self.path.strip("/").split("/", 1)
            if len(pathparts) != 2:
                self.send_error(404, "Formato de URL inválido.")
                self.connectionclosed = True
                return
            requesttype, encodedurl_ext = pathparts
            
            # Before processing, send 200 OK to fix Kodi hangs on open
            self.send_response(200)
            
            # Remove a extensão de arquivo codificada
            originalurl = urllib.parse.unquote_plus(encodedurl_ext.rsplit(".", 1)[0])

            if requesttype in ["play", "playlist"]:
                self.send_header("Content-type", "application/vnd.apple.mpegurl")
                self.end_headers()
                proxy_instance.fetchandrewriteplaylist(self, originalurl)
            elif requesttype == "segment":
                self.send_header("Content-type", "video/mp2t")
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                self.send_header("Pragma", "no-cache")
                self.end_headers()
                proxy_instance.fetchsegment(self, originalurl)
            else:
                self.send_error(404, f"Tipo de requisição desconhecido {requesttype}")
                self.connectionclosed = True
        except (ConnectionResetError, BrokenPipeError, OSError) as e:
            logging.warning(f"Conexão fechada durante processamento da requisição: {e}")
            self.connectionclosed = True
        except Exception as e:
            logging.error(f"Erro crítico no HLS Proxy Handler: {e}")


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    allow_reuse_address = True
    proxyinstance = None

class HLSAddon:
    def __init__(self, addonhandle=None):
        self.addonhandle = addonhandle
        self.proxy = HLSPROXY

    def start(self):
        if not self.proxy.server:
            try:
                self.proxy.start()
            except Exception as e:
                logging.error(f"Não foi possível iniciar o HLS Proxy: {e}")
    
    # CORREÇÃO: Renomeado de 'playstream' para 'play_stream' para resolver o AttributeError.
    def play_stream(self, streamurl, streamname):
        if requests is None:
            logging.error("O módulo requests é obrigatório. Instale-o.")
            return
        try:
            self.start()
            # Usa o novo método getproxyurl
            proxyurl = self.proxy.getproxyurl(streamurl) 
            logging.info(f"Enviando stream (Proxy URL) {proxyurl}")
            if xbmcgui and xbmcplugin and self.addonhandle is not None:
                li = xbmcgui.ListItem(label=streamname, path=proxyurl)
                try:
                    # CORREÇÃO APLICADA: Define explicitamente o rótulo e o título do vídeo para
                    # forçar o Kodi a exibir o nome correto do canal (streamname).
                    li.setLabel(streamname)
                    li.setInfo('video', {'title': streamname})
                    
                    li.setProperty("IsPlayable", "true")
                    li.setMimeType("application/vnd.apple.mpegurl")
                except Exception as e:
                    logging.warning(f"Erro ao configurar ListItem (pode ser problema de API): {e}")
                    pass
                xbmcplugin.setResolvedUrl(self.addonhandle, True, li)
            else:
                logging.warning(f"Kodi GUI não disponível ou handle ausente, use URL manualmente: {proxyurl} (A URL original é ofuscada em outros logs)")
            return proxyurl
        except Exception as e:
            logging.error(f"Erro no playstream: {e}")

def main():
    setuplogging()
    port = 8000
    try:
        HLSPROXY.start(port)
        print(f"HLS Proxy v4.9.4 rodando em http://{PROXYHOST}:{HLSPROXY.port} Ctrl+C para parar")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Parado.")
    except Exception as e:
        print(f"Erro ao executar o main: {e}")
    finally:
        HLSPROXY.stop()

# Instância global do Proxy
HLSPROXY = HLSProxy()

if __name__ == "__main__":
    main()