#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------------
# Proxy HLS Local TCP/HTTP Puro v9.2 (ESTÁVEL)
# -----------------------------------------------------------------------------------
# Objetivo: Baixa segmentos HLS via HTTP e os retransmite ao player nativo do Kodi.
# -----------------------------------------------------------------------------------
# CORREÇÕES (v9.2):
# 1. REMOVIDA: Rotação proativa de credenciais para evitar travamentos durante a reprodução.
#    A rotação agora é apenas reativa (ocorre em caso de falha).
# 2. OTIMIZADO: A chave do cache de segmentos (lru_cache) foi simplificada para não depender
#    das credenciais, tornando-o mais robusto a mudanças de sessão.
# 3. MANTIDAS: Melhorias de tratamento de erros específicos (403/429) e invalidação de cache.
# -----------------------------------------------------------------------------------
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import json
import socket
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse, urljoin, quote, unquote_plus, parse_qs
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import ConnectionError, Timeout, ReadTimeout, RequestException, ChunkedEncodingError
from functools import lru_cache

# ---------------- MOCK KODI PARA AMBIENTES STAND-ALONE ----------------
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    def kodi_log(msg, level=xbmc.LOGINFO):
        if xbmc:
            xbmc.log(f"[HLSProxy] {msg}", level=level)
except ImportError:
    class MockKodi:
        def log(self, msg, level=None):
            print(f"[MOCK] {msg}")
        LOGINFO = 1
        LOGDEBUG = 0
        LOGWARNING = 2
        LOGERROR = 3
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    def kodi_log(msg, level=xbmc.LOGINFO):
        print(f"[HLSProxy] {msg}")
# ---------------- FIM MOCK KODI ----------------


# ---------------- CONFIGURAÇÕES ----------------
MAX_SEGMENT_RETRIES = 3
CONNECTION_TIMEOUT = 2.5
READ_TIMEOUT = 5.0
SEGMENT_CACHE_SIZE = 50
PREFETCH_ENABLED = True
MAX_PREFETCH_THREADS = 2
CIRCUIT_BREAKER_FAILURE_THRESHOLD = 5
CIRCUIT_BREAKER_TIMEOUT = 30
SESSION_TIMEOUT_SECONDS = 60
MAX_ACTIVE_SESSIONS = 50

DEFAULT_CHUNK_SIZE = 32 * 1024
PROXY_HOST = '0.0.0.0'
HTTP_PORT = 8010
LOG_FILE = "hls_tcp_proxy.log"
MANIFEST_CACHE_TTL = 4

# CORREÇÃO: Removida a constante de rotação proativa
# CREDENTIAL_ROTATION_INTERVAL_SECONDS = 120

USER_AGENT_TEMPLATE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.{version} Safari/537.36"
NULL_TS_PACKET = b'\x47\x1f\xff\x10' + (b'\xff' * 184)

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- ESTADO GLOBAL ----------------
MANIFEST_CACHE = {}
SESSION_STORE = {}
STATE_LOCK = threading.Lock()
PREFETCH_EXECUTOR = ThreadPoolExecutor(max_workers=MAX_PREFETCH_THREADS, thread_name_prefix="Prefetch")
PROXY_SERVER_INSTANCE = None
PROXY_SERVER_PORT = 0

# ---------------- UTILS & SETUP ----------------
def _generate_fake_ip():
    while True:
        octets = [random.randint(1, 254) for _ in range(4)]
        if (octets[0] == 10 or (octets[0] == 192 and octets[1] == 168) or
            (octets[0] == 172 and 16 <= octets[1] <= 31) or octets[0] == 127 or
            octets[0] == 0 or octets[0] >= 240):
            continue
        return ".".join(map(str, octets))

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

HOST_NAME_FOR_URLS = get_local_ip()

def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    if logger.hasHandlers():
        logger.handlers.clear()
    try:
        file_handler = logging.FileHandler(LOG_FILE, mode='w', encoding='utf-8')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception: pass
    logging.getLogger('urllib3').setLevel(logging.ERROR)
    logging.getLogger('requests').setLevel(logging.ERROR)

# ---------------- GERENCIAMENTO DE SESSÃO ----------------
class SessionManager:
    """Gerencia a criação, estabilidade (Circuit Breaker) e limpeza de sessões."""
    def __init__(self):
        self._cleanup_thread = threading.Thread(target=self._cleanup_idle_sessions_loop, daemon=True)
        self._cleanup_thread.start()

    def _create_new_session_entry(self, session_id, original_url, origin_host):
        session = requests.Session()
        adapter = HTTPAdapter(
            pool_connections=10,
            pool_maxsize=20,
            max_retries=Retry(total=2, backoff_factor=0.5, status_forcelist=[500, 502, 503, 504])
        )
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        ua_version = random.randint(1000, 9999)
        SESSION_STORE[session_id] = {
            'session': session,
            'original_url': original_url,
            'origin_host': origin_host,
            'user_agent': USER_AGENT_TEMPLATE.format(version=ua_version),
            'fake_ip': _generate_fake_ip(),
            'last_rotation': time.time(),
            'consecutive_failures': 0,
            'circuit_breaker_open_time': 0,
            'last_activity_time': time.time(),
        }
        kodi_log(f"Sessão Iniciada: {session_id} para {original_url}", xbmc.LOGDEBUG)

    def get_session_data(self, session_id, original_url=None, origin_host=None):
        """Retorna dados da sessão, criando se necessário."""
        with STATE_LOCK:
            if len(SESSION_STORE) >= MAX_ACTIVE_SESSIONS and session_id not in SESSION_STORE:
                kodi_log(f"Limite de sessões atingido. Rejeitando: {session_id}", xbmc.LOGWARNING)
                raise Exception("Too many active sessions")

            if session_id not in SESSION_STORE:
                if not (original_url and origin_host):
                    raise Exception("Sessão não encontrada e sem dados iniciais.")
                self._create_new_session_entry(session_id, original_url, origin_host)

            # CORREÇÃO: Removida a lógica de rotação proativa daqui
            SESSION_STORE[session_id]['last_activity_time'] = time.time()
            return SESSION_STORE[session_id]

    def is_circuit_breaker_open(self, session_id):
        with STATE_LOCK:
            if session_id not in SESSION_STORE: return True
            s_data = SESSION_STORE[session_id]
            if s_data['circuit_breaker_open_time'] == 0:
                return False
            if time.time() - s_data['circuit_breaker_open_time'] > CIRCUIT_BREAKER_TIMEOUT:
                kodi_log(f"Circuit Breaker fechando para {session_id}", xbmc.LOGINFO)
                s_data['circuit_breaker_open_time'] = 0
                s_data['consecutive_failures'] = 0
                return False
            return True

    def trip_circuit_breaker(self, session_id):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                SESSION_STORE[session_id]['circuit_breaker_open_time'] = time.time()
                kodi_log(f"Circuit Breaker ABERTO para {session_id}", xbmc.LOGWARNING)

    def record_success(self, session_id):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                s_data = SESSION_STORE[session_id]
                s_data['consecutive_failures'] = 0
                if s_data['circuit_breaker_open_time'] > 0:
                    s_data['circuit_breaker_open_time'] = 0
                    kodi_log(f"Circuit Breaker resetado por sucesso em {session_id}", xbmc.LOGINFO)

    def record_failure(self, session_id):
        with STATE_LOCK:
            if session_id not in SESSION_STORE: return
            
            s_data = SESSION_STORE[session_id]
            s_data['consecutive_failures'] += 1
            
            if session_id in MANIFEST_CACHE:
                del MANIFEST_CACHE[session_id]
                kodi_log(f"Cache do manifesto para {session_id} invalidado devido a falha.", xbmc.LOGDEBUG)
            
            if s_data['consecutive_failures'] >= CIRCUIT_BREAKER_FAILURE_THRESHOLD:
                self.trip_circuit_breaker(session_id)

    def rotate_credentials(self, session_id, force=False):
        """Gera um novo User-Agent e Fake-IP para a sessão (Bypass DPI)."""
        with STATE_LOCK:
            if session_id not in SESSION_STORE: return False
                
            s_data = SESSION_STORE[session_id]
            now = time.time()
            
            if not force and now - s_data['last_rotation'] < 10: return False
            
            new_version = random.randint(1000, 9999)
            new_ip = _generate_fake_ip()
            
            s_data['user_agent'] = USER_AGENT_TEMPLATE.format(version=new_version)
            s_data['fake_ip'] = new_ip
            s_data['last_rotation'] = now
                
            if session_id in MANIFEST_CACHE:
                del MANIFEST_CACHE[session_id]
                
            kodi_log(f"🚨 Rotação Reativa: {session_id} -> Novo IP/UA", xbmc.LOGINFO)
            return True

    def _cleanup_idle_sessions_loop(self):
        while True:
            time.sleep(30)
            with STATE_LOCK:
                now = time.time()
                to_remove = []
                for sid, s_data in SESSION_STORE.items():
                    if now - s_data['last_activity_time'] > SESSION_TIMEOUT_SECONDS:
                        to_remove.append(sid)
                
                for sid in to_remove:
                    try:
                        SESSION_STORE[sid]['session'].close()
                    except: pass
                    del SESSION_STORE[sid]
                    if sid in MANIFEST_CACHE: del MANIFEST_CACHE[sid]
                    kodi_log(f"Sessão inativa removida: {sid}", xbmc.LOGDEBUG)

session_manager = SessionManager()

# ---------------- BYPASS DE DPI ----------------
def generate_random_headers(user_agent=None, referer=None):
    headers = {
        'User-Agent': user_agent if user_agent else USER_AGENT_TEMPLATE.format(version=random.randint(1000, 9999)),
        'Accept': random.choice(["*/*", "application/vnd.apple.mpegurl", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"]),
        'Accept-Language': random.choice(["pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "en-US,en;q=0.9"]),
        'Accept-Encoding': random.choice(["gzip, deflate, br", "gzip, deflate", "identity"]),
        'Connection': 'keep-alive',
        'Cache-Control': random.choice(["no-cache", "max-age=0"]),
    }
    if referer:
        headers['Referer'] = referer
    return {k: v for k, v in headers.items() if v is not None}

# ---------------- CACHE DE SEGMENTOS (CORRIGIDO) ----------------
# CORREÇÃO: A chave do cache agora é apenas (session_id, segment_url)
# para não ser invalidada pela rotação de credenciais.
@lru_cache(maxsize=SEGMENT_CACHE_SIZE)
def fetch_and_cache_segment(session_id, segment_url):
    """
    Busca um segmento, usando lru_cache para armazenamento.
    A função obtém os dados da sessão internamente.
    """
    try:
        s_data = session_manager.get_session_data(session_id)
        headers = generate_random_headers(s_data['user_agent'], f"http://{s_data['origin_host']}/")
        headers['X-Forwarded-For'] = s_data['fake_ip']
        
        # Usamos uma sessão temporária para a busca do cache.
        temp_session = requests.Session()
        adapter = HTTPAdapter(max_retries=Retry(total=1, backoff_factor=0.1))
        temp_session.mount('http://', adapter)
        temp_session.mount('https://', adapter)

        r = temp_session.get(segment_url, headers=headers, timeout=(CONNECTION_TIMEOUT, READ_TIMEOUT), verify=False)
        
        if r.status_code == 200:
            return r.content
        else:
            kodi_log(f"Erro ao buscar segmento para cache: {r.status_code}", xbmc.LOGWARNING)
            return None

    except Exception as e:
        kodi_log(f"Exceção ao buscar segmento para cache: {e}", xbmc.LOGDEBUG)
        return None
    finally:
        temp_session.close()

def prefetch_segment(session_id, segment_url):
    if not PREFETCH_ENABLED: return
    # A função lru_cache cuida de não buscar novamente se já estiver no cache.
    fetch_and_cache_segment(session_id, segment_url)
    kodi_log(f"Pré-busca agendada: {segment_url[-30:]}...", xbmc.LOGDEBUG)


# ---------------- HTTP SERVER IMPLEMENTATION ----------------
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class ProxyHTTPHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def get_safe_manifest(self):
        return """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:1
#EXT-X-MEDIA-SEQUENCE:1
#EXTINF:1.0,
http://{}:{}/dummy_wait_segment.ts
""".format(HOST_NAME_FOR_URLS, PROXY_SERVER_PORT).encode('utf-8')

    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        query = parse_qs(parsed_url.query)
        try:
            if path.startswith('/play/') and path.endswith('/index.m3u8'):
                self.proxy_manifest(path)
            elif path == '/stream':
                self.proxy_segment(query)
            elif path == '/dummy_wait_segment.ts':
                self.dummy_wait()
            elif path == '/':
                self.index()
            else:
                self.send_error(404)
        except BrokenPipeError:
            pass
        except Exception as e:
            kodi_log(f"Erro Request ({path}): {e}", xbmc.LOGERROR)
            if path.endswith('.ts'):
                self._send_null_packets(100)
            else:
                try: self.send_error(500)
                except: pass

    def index(self):
        html_content = f"""
        <html><head><title>HLS Proxy</title></head>
        <body style="background:#121212; color:white;">
            <h1>🛡️ HLS Proxy Ativo v9.2 (Estável)</h1>
            <p>Status: OK. Porta: {PROXY_SERVER_PORT}</p>
            <p>Sessões Ativas: {len(SESSION_STORE)}</p>
            <p>Cache de Segmentos (LRU): {fetch_and_cache_segment.cache_info().currsize}/{fetch_and_cache_segment.cache_info().maxsize}</p>
            <p>O proxy está pronto para reescrever e rotear streams HLS.</p>
        </body></html>
        """
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        try: self.wfile.write(html_content.encode('utf-8'))
        except BrokenPipeError: pass

    def proxy_manifest(self, path):
        try:
            session_id = path.split('/')[2]
        except IndexError:
            self._send_safe_manifest()
            return
            
        try:
            s_data = session_manager.get_session_data(session_id)
        except Exception:
            self._send_safe_manifest()
            return

        original_url = s_data['original_url']
        origin_host = s_data['origin_host']
        
        now = time.time()
        cache = MANIFEST_CACHE.get(session_id)
        
        if cache and (now - cache['timestamp'] < MANIFEST_CACHE_TTL):
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            try: self.wfile.write(cache['content'])
            except BrokenPipeError: pass
            return

        success = False
        content = ""
        base_url = ""
        
        for attempt in range(2):
            host_referer = f"http://{origin_host}/" if origin_host else None
            headers = generate_random_headers(s_data['user_agent'], host_referer)
            headers['X-Forwarded-For'] = s_data['fake_ip']
            
            try:
                r = s_data['session'].get(original_url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False)
                if r.status_code == 200:
                    content = r.text
                    base_url = r.url
                    success = True
                    break
                else:
                    r.close()
                    if r.status_code >= 400: session_manager.rotate_credentials(session_id)
            except Exception as e:
                kodi_log(f"Erro Manifesto (tentativa {attempt+1}): {e}", xbmc.LOGWARNING)
                session_manager.rotate_credentials(session_id)
                time.sleep(random.uniform(0.1, 0.5))

        if not success:
            kodi_log(f"Falha total ao obter manifesto: {original_url}", xbmc.LOGERROR)
            self._send_safe_manifest()
            return

        try:
            new_lines = []
            segment_urls_to_prefetch = []
            
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    new_lines.append(line)
                    continue
                
                full_url = urljoin(base_url, line)
                enc_url = quote(full_url, safe='')
                enc_host = quote(origin_host, safe='')
                
                proxy_url = f"http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}/stream?url={enc_url}&sid={session_id}"
                new_lines.append(proxy_url)
                
                segment_urls_to_prefetch.append(full_url)
                
            final_content = "\n".join(new_lines).encode('utf-8')
            MANIFEST_CACHE[session_id] = {'content': final_content, 'timestamp': now}
            
            if PREFETCH_ENABLED and segment_urls_to_prefetch:
                for seg_url in segment_urls_to_prefetch[:2]:
                    PREFETCH_EXECUTOR.submit(prefetch_segment, session_id, seg_url)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            try: self.wfile.write(final_content)
            except BrokenPipeError: pass
            
        except Exception as e:
            kodi_log(f"Erro ao reescrever/enviar manifesto: {e}", xbmc.LOGERROR)
            self._send_safe_manifest()

    def proxy_segment(self, query):
        url = query.get('url', [None])[0]
        sid = query.get('sid', [None])[0]
        
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.end_headers()
        except BrokenPipeError:
            return

        if not url or not sid:
            self._send_null_packets(10)
            return

        try:
            url = unquote_plus(url)
        except: return

        if session_manager.is_circuit_breaker_open(sid):
            self._send_null_packets(500)
            return

        # 1. Tenta o cache LRU primeiro
        cached_data = fetch_and_cache_segment(sid, url)

        if cached_data:
            try:
                self.wfile.write(cached_data)
                session_manager.record_success(sid)
                return
            except BrokenPipeError: return

        # 2. Requisita na Origem (Fallback)
        segment_downloaded = False
        
        for attempt in range(MAX_SEGMENT_RETRIES):
            try:
                s_data = session_manager.get_session_data(sid)
                host_referer = f"http://{s_data['origin_host']}/" if s_data['origin_host'] else None
                headers = generate_random_headers(s_data['user_agent'], host_referer)
                headers['X-Forwarded-For'] = s_data['fake_ip']
                
                with s_data['session'].get(url, headers=headers, stream=True,
                                         timeout=(CONNECTION_TIMEOUT, READ_TIMEOUT), verify=False) as r:
                
                    if r.status_code == 200:
                        data = b''
                        for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            if chunk:
                                try:
                                    self.wfile.write(chunk)
                                    data += chunk
                                except BrokenPipeError:
                                    return
                        segment_downloaded = True
                        session_manager.record_success(sid)
                        # Adiciona ao cache LRU após o download bem-sucedido
                        fetch_and_cache_segment.cache_set((sid, url), data)
                        break
                    elif r.status_code in [403, 429]:
                        kodi_log(f"Erro de limite detectado ({r.status_code}), rotacionando.", xbmc.LOGWARNING)
                        session_manager.record_failure(sid)
                        session_manager.rotate_credentials(sid, force=True)
                        continue
                    else:
                        kodi_log(f"Erro de servidor ({r.status_code}), tentando novamente.", xbmc.LOGWARNING)
                        session_manager.record_failure(sid)
                        continue
            
            except (ConnectionError, ChunkedEncodingError, Timeout) as e:
                kodi_log(f"Erro Rede/Stream: {e}", xbmc.LOGERROR)
                session_manager.record_failure(sid)
                continue
            except BrokenPipeError:
                return
        
        if not segment_downloaded:
            kodi_log(f"Falha total no segmento: {url}", xbmc.LOGERROR)
            session_manager.record_failure(sid)
            self._send_null_packets(100)

    def dummy_wait(self):
        self._send_null_packets(100)
    
    def _send_null_packets(self, count):
        try:
            self.wfile.write(NULL_TS_PACKET * count)
        except BrokenPipeError:
            pass
            
    def _send_safe_manifest(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.end_headers()
        try: self.wfile.write(self.get_safe_manifest())
        except BrokenPipeError: pass

# ---------------- INTEGRAÇÃO ADDON/KODI ----------------
class ProxyController:
    def __init__(self):
        self.lock = threading.Lock()

    def find_available_port(self):
        ports_to_try = [HTTP_PORT] + [random.randint(10000, 11000) for _ in range(10)]
        for port in set(ports_to_try):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind((PROXY_HOST, port))
                    return port
            except OSError:
                continue
        return 0

    def start(self):
        global PROXY_SERVER_INSTANCE, PROXY_SERVER_PORT
        with self.lock:
            if PROXY_SERVER_INSTANCE: return True

            PROXY_SERVER_PORT = self.find_available_port()
            if PROXY_SERVER_PORT == 0:
                kodi_log("FATAL: Nenhuma porta livre encontrada.", xbmc.LOGERROR)
                return False

            try:
                temp_server = ThreadedHTTPServer((PROXY_HOST, PROXY_SERVER_PORT), ProxyHTTPHandler)
                PROXY_SERVER_INSTANCE = temp_server
                
                thread = threading.Thread(target=PROXY_SERVER_INSTANCE.serve_forever, daemon=True)
                thread.start()
                
                kodi_log(f"Servidor Proxy Iniciado: http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}", xbmc.LOGINFO)
                return True
            except Exception as e:
                kodi_log(f"Erro ao iniciar servidor: {e}", xbmc.LOGERROR)
                PROXY_SERVER_INSTANCE = None
                PROXY_SERVER_PORT = 0
                return False

    def stop(self):
        global PROXY_SERVER_INSTANCE, PROXY_SERVER_PORT
        with self.lock:
            if PROXY_SERVER_INSTANCE:
                PROXY_SERVER_INSTANCE.shutdown()
                PROXY_SERVER_INSTANCE.server_close()
                PROXY_SERVER_INSTANCE = None
                PROXY_SERVER_PORT = 0
                kodi_log("Servidor Proxy Parado.", xbmc.LOGINFO)
            PREFETCH_EXECUTOR.shutdown(wait=False)

_proxy_controller = ProxyController()

class HLSAddon:
    """Classe de interface para o addon Kodi."""
    def __init__(self, handle=None):
        self.handle = handle

    def get_proxy_url(self, target_url):
        """Gera URL e inicia Proxy se necessário. Armazena a URL original na sessão."""
        global PROXY_SERVER_PORT
        
        if not _proxy_controller.start():
            return target_url
            
        session_id = str(abs(hash(target_url)))
        origin_host = urlparse(target_url).netloc
        
        try:
             session_manager.get_session_data(session_id, target_url, origin_host)
        except Exception as e:
            kodi_log(f"Erro ao criar sessão proxy: {e}", xbmc.LOGERROR)
            return target_url
             
        proxy_path = f"/play/{session_id}/index.m3u8"
        return f"http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}{proxy_path}"

    def play_stream(self, url, stream_type=None):
        """Função principal chamada pelo addon.py."""
        if not xbmcgui or not xbmcplugin:
            kodi_log("Chamada play_stream fora do ambiente Kodi. Ignorando.", xbmc.LOGWARNING)
            return
            
        try:
            kodi_log(f"Preparando reprodução segura para: {url} (Tipo: {stream_type})", xbmc.LOGINFO)
            proxy_url = self.get_proxy_url(url)
            
            listitem = xbmcgui.ListItem(path=proxy_url)
            listitem.setMimeType('application/vnd.apple.mpegurl')
            listitem.setContentLookup(False)
            listitem.setProperty('IsLive', 'true')
            
            kodi_log(f"Proxy URL para Player: {proxy_url}", xbmc.LOGINFO)
            
            if self.handle:
                xbmcplugin.setResolvedUrl(int(self.handle), True, listitem)
            else:
                xbmc.Player().play(proxy_url, listitem)
                
            kodi_log("Reprodução enviada para o Player.")
            
        except Exception as e:
            kodi_log(f"Erro ao iniciar reprodução: {e}", xbmc.LOGERROR)
            if self.handle:
                xbmcplugin.setResolvedUrl(int(self.handle), False, xbmcgui.ListItem())

# ---------------- INICIALIZAÇÃO ----------------
if __name__ == '__main__':
    setup_logging()
    _proxy_controller.start()
    try:
        print(f"------------------------------------------------")
        print(f" HLS PROXY TCP v9.2 (Estável)")
        print(f" HTTP: http://{HOST_NAME_FOR_URLS}:{PROXY_SERVER_PORT}")
        print(f"------------------------------------------------")
        while True: time.sleep(1)
    except KeyboardInterrupt:
        _proxy_controller.stop()
    except Exception as e:
        print(f"Erro fatal: {e}")
else:
    kodi_log("Módulo hlsproxy importado pelo addon.py. Próxima etapa: HLSAddon().play_stream()", xbmc.LOGINFO)