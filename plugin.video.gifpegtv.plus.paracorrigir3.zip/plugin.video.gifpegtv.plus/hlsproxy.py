# -*- coding: utf-8 -*-
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import http.server
import socketserver
from collections import OrderedDict
import re
from urllib.parse import urlparse, urlunparse

import requests
from requests.adapters import HTTPAdapter
from doh_client import requests as doh_requests

import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIG ----------------
MAX_RETRIES = 10  # Mantido para maior resiliência
SHORT_RETRY_DELAYS = [0.5, 1, 2, 4, 4, 4, 4, 4, 4, 4]  # Backoff exponencial mais rápido com platô em 4s
CONNECTION_TIMEOUT = 15  # Tolerância para conexões
STREAM_TIMEOUT = 60.0  # Tolerância para streams
DEFAULT_CHUNK_SIZE = 1024 * 50  # 512KB para throughput melhor
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_proxy.log"

# Cache em memória com limite LRU
manifest_cache = OrderedDict()
segment_cache = OrderedDict()
current_cache_size = 0
MAX_CACHE_SIZE = 100 * 1024 * 1024  # 100 MB limite total
MANIFEST_TTL = 2        # Refresh frequente de manifestos
SEGMENT_TTL = 60        # Segmentos até 60s
# ----------------------------------

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- SESSION MANAGER ----------------
class SessionManager:
    """Gerencia sessões HTTP por session_id para garantir isolamento e permitir reinicialização."""
    def __init__(self):
        self._sessions = {}
        self._manifest_urls = {}
        self._lock = threading.Lock()

    def _create_session(self):
        """Cria e configura uma nova sessão de requests."""
        session = doh_requests.session
        adapter = HTTPAdapter(pool_connections=50, pool_maxsize=50, max_retries=5)  # Aumentado para resiliência
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        session.user_agent = self._generate_user_agent()  # Gera novo User-Agent por sessão
        logging.info(f"Novo User-Agent gerado para sessão: {session.user_agent}")
        return session

    def _generate_user_agent(self):
        """Gera um User-Agent aleatório de uma lista variada."""
        agents = [
            f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(110, 125)}.0.0.0 Safari/537.36",
            f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(110, 125)}.0.0.0 Safari/537.36",
            f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{random.randint(100, 125)}.0) Gecko/20100101 Firefox/{random.randint(100, 125)}.0",
            f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:{random.randint(100, 125)}.0) Gecko/20100101 Firefox/{random.randint(100, 125)}.0",
            f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(110, 125)}.0.0.0 Edg/{random.randint(110, 125)}.0.0.0",
            f"Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
        ]
        return random.choice(agents)

    def get_session(self, session_id):
        """Obtém ou cria uma sessão para um determinado ID."""
        with self._lock:
            if session_id not in self._sessions:
                self._sessions[session_id] = self._create_session()
            return self._sessions[session_id]

    def reset_session(self, session_id):
        """Descarta a sessão antiga e cria uma nova para o ID, gerando novo User-Agent."""
        with self._lock:
            logging.info(f"Reiniciando a sessão HTTP para session_id: {session_id}")
            self._sessions[session_id] = self._create_session()
            return self._sessions[session_id]
            
    def register_manifest_url(self, session_id, url):
        """Associa uma URL de manifesto a um session_id."""
        with self._lock:
            self._manifest_urls[session_id] = url
            
    def get_manifest_url(self, session_id):
        """Obtém a URL do manifesto associada a um session_id."""
        with self._lock:
            return self._manifest_urls.get(session_id)

# Instância global do gerenciador de sessão
session_manager = SessionManager()

# ---------------- URL OBFUSCATOR ----------------
def _obfuscate_url_match(match):
    """Função auxiliar para o regex, ofusca uma URL encontrada."""
    url = match.group(0)
    try:
        parsed = urlparse(url)
        path_parts = parsed.path.strip('/').split('/')
        
        # Mantém o domínio, mas simplifica o caminho para ".../nome_do_arquivo"
        if len(path_parts) > 2:
            obfuscated_path = f"/{path_parts[0]}/.../{path_parts[-1]}"
        else:
            obfuscated_path = parsed.path
            
        # Remonta a URL sem query string (tokens) ou outros parâmetros
        return urlunparse((parsed.scheme, parsed.netloc, obfuscated_path, '', '', ''))
    except Exception:
        return "[URL_OBFUSCATED]"

def obfuscate_text(text):
    """Encontra e ofusca todas as URLs dentro de uma string de texto."""
    if not isinstance(text, str):
        text = str(text)
    # Padrão de regex para encontrar URLs http e https
    url_pattern = r'https?://[^\s\'"]+'
    return re.sub(url_pattern, _obfuscate_url_match, text)

# ---------------- UTILS ----------------
def setup_logging():
    try:
        log_path = os.path.join(xbmc.translatePath('special://logpath'), LOG_FILE)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] (%(threadName)s) %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] (%(threadName)s) %(message)s')

def get_forward_headers(client_headers, user_agent):
    headers = {
        'User-Agent': user_agent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7',
        'Connection': 'keep-alive',
        'Accept-Encoding': 'identity',  # Evita compressão para streams
    }
    if 'Authorization' in client_headers:
        headers['Authorization'] = client_headers['Authorization']
    if 'Cookie' in client_headers:
        headers['Cookie'] = client_headers['Cookie']
    if 'Range' in client_headers:
        headers['Range'] = client_headers['Range']
    
    return headers

def cache_get(cache, url, ttl):
    now = time.time()
    if url in cache:
        ts, data, size = cache[url]
        if now - ts < ttl:
            cache.move_to_end(url)
            return data
        else:
            cache_pop(cache, url)
    return None

def cache_set(cache, url, data):
    global current_cache_size
    size = len(data[0]) if isinstance(data[0], (bytes, bytearray)) else len(str(data[0]).encode())
    cache[url] = (time.time(), data, size)
    cache.move_to_end(url)
    current_cache_size += size
    while current_cache_size > MAX_CACHE_SIZE and cache:
        cache_pop(cache, next(iter(cache)))

def cache_pop(cache, url):
    global current_cache_size
    if url in cache:
        logging.info(obfuscate_text(f"Removendo do cache: {url}"))
        _, _, size = cache[url]
        current_cache_size -= size
        del cache[url]

# ---------------- HANDLER ----------------
class HLSProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    
    def log_message(self, format, *args):
        message = format % args
        # Decodifica a mensagem para que a URL codificada possa ser encontrada e ofuscada
        decoded_message = urllib.parse.unquote(message)
        obfuscated_message = obfuscate_text(decoded_message)
        logging.info(f"{self.client_address[0]} - \"{obfuscated_message}\"")

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        try:
            if '?url=' not in self.path:
                self.send_error(404, "Not Found")
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [self.client_address[0]])[0]

            if not url:
                self.send_error(400, "Bad Request: 'url' parameter missing")
                return

            session = session_manager.get_session(session_id)
            headers = get_forward_headers(self.headers, session.user_agent)
            parsed_url = urllib.parse.urlparse(url)

            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, session_id, head_only)
            else:
                self._handle_segment(url, session_id, headers, head_only)
        
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError):
            logging.warning(obfuscate_text(f"Client disconnected abruptly for path {self.path}"))

        except Exception as e:
            logging.error(f"Erro inesperado no do_GET: {e}", exc_info=True)
            if not self.wfile.closed:
                try:
                    self.send_error(500, "Internal Proxy Error")
                except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError): 
                    logging.warning("Client disconnected before 500 error could be sent.")
                except Exception as e2:
                    logging.error(f"Failed to send 500 error response: {e2}")

    def _handle_manifest(self, url, headers, session_id, head_only):
        manifest_content = None
        base_url = None
        cached = cache_get(manifest_cache, url, MANIFEST_TTL)
        session = session_manager.get_session(session_id)
        
        last_error = None
        # Início do bloco de retentativas para o manifesto
        for attempt in range(MAX_RETRIES):
            try:
                r = session.get(url, headers=headers, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                                verify=False, allow_redirects=True)
                r.raise_for_status()
                
                # Se for bem-sucedido, quebra o loop e processa
                manifest_content = r.text
                base_url = r.url
                cache_set(manifest_cache, url, (manifest_content, base_url))
                session_manager.register_manifest_url(session_id, base_url)
                break
                
            except requests.exceptions.RequestException as e:
                last_error = e
                wait = SHORT_RETRY_DELAYS[min(attempt, len(SHORT_RETRY_DELAYS)-1)]
                logging.warning(obfuscate_text(f"Erro no manifesto {url}: {e}. Retry {attempt+1}/{MAX_RETRIES} em {wait}s..."))
                time.sleep(wait)
            except Exception as e:
                last_error = e
                logging.error(f"Erro inesperado ao buscar manifesto: {e}", exc_info=True)
                break # Erros inesperados não devem ser repetidos
        else:
            # Este bloco é executado se o loop for concluído sem sucesso (todas as tentativas falharam)
            pass

        # Lógica de fallback para cache se todas as tentativas falharem
        if manifest_content is None:
            if cached:
                logging.warning(obfuscate_text(f"Manifesto falhou ({last_error}), servindo cache: {url}"))
                manifest_content, base_url = cached
            else:
                self.send_error(503, "Service Unavailable: Manifesto indisponível")
                return

        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.end_headers()

        if head_only: return

        new_manifest_lines = []
        for line in manifest_content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                new_manifest_lines.append(line)
            else:
                full_url = urllib.parse.urljoin(base_url, stripped)
                proxy_url = f"http://{PROXY_HOST}:{self.server.server_address[1]}/?url={urllib.parse.quote_plus(full_url)}&session_id={session_id}"
                new_manifest_lines.append(proxy_url)

        self.wfile.write('\n'.join(new_manifest_lines).encode('utf-8'))
        self.wfile.flush()

    def _handle_segment(self, url, session_id, headers, head_only):
        cached = cache_get(segment_cache, url, SEGMENT_TTL)
        r = None
        last_error = None
        session = session_manager.get_session(session_id)
        success = False

        # Loop principal de retries
        for attempt in range(MAX_RETRIES):
            try:
                r = session.get(url, headers=headers, stream=True,
                                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)

                if r.status_code == 404:
                    logging.warning(obfuscate_text(f"Segmento expirado (404) {url}, devolvendo 204."))
                    self.send_response(204)
                    self.end_headers()
                    return

                r.raise_for_status()
                
                headers_out = {h: v for h, v in r.headers.items()
                               if h.lower() not in ['transfer-encoding', 'connection', 'content-encoding']}
                self.send_response(r.status_code)
                for h, v in headers_out.items(): self.send_header(h, v)
                self.end_headers()

                if head_only: return

                buffer = bytearray()
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()  # Flush mais frequente para resiliência
                        except (BrokenPipeError, ConnectionResetError):
                            logging.warning(obfuscate_text(f"Broken pipe ao escrever chunk para {url}"))
                            return
                        buffer.extend(chunk)
                
                cache_set(segment_cache, url, (bytes(buffer), headers_out))
                success = True
                return

            except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError) as e:
                logging.warning(obfuscate_text(f"Client disconnected while handling segment {url}: {e}"))
                return

            except requests.exceptions.RequestException as e:
                last_error = e
                wait = SHORT_RETRY_DELAYS[min(attempt, len(SHORT_RETRY_DELAYS)-1)]
                logging.warning(obfuscate_text(f"Erro no segmento {url}: {e}. Retry {attempt+1}/{MAX_RETRIES} em {wait}s..."))
                time.sleep(wait)
            
            finally:
                if r: r.close()

        # --- LÓGICA DE RECUPERAÇÃO PROATIVA APÓS TODAS AS TENTATIVAS FALHAREM ---
        if not success:
            logging.error(obfuscate_text(f"Todas as {MAX_RETRIES} tentativas falharam para o segmento {url}. Iniciando recuperação proativa."))
            session_manager.reset_session(session_id)  # Reset com novo UA
            manifest_url = session_manager.get_manifest_url(session_id)
            if manifest_url:
                logging.info(obfuscate_text(f"Invalidando cache do manifesto ({manifest_url}) e forçando re-fetch proativo."))
                cache_pop(manifest_cache, manifest_url)
                # Forçar re-fetch do manifesto proativamente para atualizar base_url ou tokens
                try:
                    manifest_headers = get_forward_headers(self.headers, session.user_agent)  # Usa novo UA
                    manifest_r = session.get(manifest_url, headers=manifest_headers, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False, allow_redirects=True)
                    manifest_r.raise_for_status()
                    new_manifest_content = manifest_r.text
                    new_base_url = manifest_r.url
                    cache_set(manifest_cache, manifest_url, (new_manifest_content, new_base_url))
                    session_manager.register_manifest_url(session_id, new_base_url)
                    logging.info(obfuscate_text(f"Manifesto re-fetchado com sucesso para {manifest_url}. Tentando segmento novamente."))
                    
                    # Retry o segmento uma vez mais após re-fetch do manifesto
                    try:
                        r = session.get(url, headers=headers, stream=True, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), verify=False)
                        r.raise_for_status()
                        
                        headers_out = {h: v for h, v in r.headers.items()
                                       if h.lower() not in ['transfer-encoding', 'connection', 'content-encoding']}
                        self.send_response(r.status_code)
                        for h, v in headers_out.items(): self.send_header(h, v)
                        self.end_headers()

                        if head_only: return

                        buffer = bytearray()
                        for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                            if chunk:
                                try:
                                    self.wfile.write(chunk)
                                    self.wfile.flush()
                                except (BrokenPipeError, ConnectionResetError):
                                    logging.warning(obfuscate_text(f"Broken pipe ao escrever chunk em retry para {url}"))
                                    return
                                buffer.extend(chunk)
                        
                        cache_set(segment_cache, url, (bytes(buffer), headers_out))
                        success = True
                        return
                    except Exception as retry_e:
                        logging.warning(obfuscate_text(f"Retry do segmento após re-fetch falhou: {retry_e}"))
                except Exception as manifest_e:
                    logging.error(obfuscate_text(f"Falha no re-fetch proativo do manifesto: {manifest_e}"))
        # ----------------------------------------------------------------

        try:
            if not success:
                if cached:
                    logging.warning(obfuscate_text(f"Servindo segmento do cache como fallback final: {url}"))
                    content, seg_headers = cached
                    self.send_response(200)
                    for h, v in seg_headers.items(): self.send_header(h, v)
                    self.end_headers()
                    if not head_only:
                        self.wfile.write(content)
                        self.wfile.flush()
                else:
                    logging.error(obfuscate_text(f"Segmento falhou sem cache {url}: {last_error}"))
                    self.send_response(204)  # Devolve 204 para não travar o player
                    self.end_headers()
        except (ConnectionAbortedError, BrokenPipeError, ConnectionResetError) as e:
            logging.warning(obfuscate_text(f"Client disconnected before fallback response for {url}: {e}"))

    def do_OPTIONS(self):
        self.send_response(200, "OK")
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()


# ---------------- MANAGER ----------------
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        for _ in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = socketserver.ThreadingTCPServer((PROXY_HOST, port), HLSProxyRequestHandler, bind_and_activate=False)
                self.server.allow_reuse_address = True
                self.server.server_bind()
                self.server.server_activate()
                self.server.daemon_threads = True
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                self.active_port = port
                logging.info(f"Proxy HLS iniciado em http://{PROXY_HOST}:{self.active_port}")
                return True
            except OSError as e:
                logging.warning(f"Porta {port} em uso, tentando outra. Erro: {e}")
                continue
        logging.error("Não foi possível iniciar o proxy HLS.")
        return False

    def stop(self):
        if self.server:
            logging.info("Parando proxy HLS...")
            self.server.shutdown()
            self.server.server_close()
            if self.thread: self.thread.join()
            logging.info("Proxy HLS parado.")


# ---------------- ADDON ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        if not self.proxy.start():
            xbmcgui.Dialog().notification("Erro no Proxy HLS", "Não foi possível iniciar o servidor local.", xbmcgui.NOTIFICATION_ERROR)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={urllib.parse.quote_plus(url)}"
        li = xbmcgui.ListItem(path=proxy_url)
        if title:
            li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        if stype == "live":
            # MODIFICAÇÃO SOLICITADA: Adicionando 'application/octet-stream'
            li.setMimeType("application/vnd.apple.mpegurl|application/octet-stream")
        xbmcplugin.setResolvedUrl(self.handle, True, li)


def main():
    setup_logging()
    try:
        handle = int(sys.argv[1])
        addon = HLSAddon(handle)
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [None])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [None])[0]
            stream_type = args.get('stream_type', ['live'])[0]
            title = args.get('title', [None])[0]
            if stream_url:
                addon.play_stream(stream_url, stream_type, title)
            else:
                xbmcplugin.endOfDirectory(handle, succeeded=False)
        else:
            xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        logging.error(f"Erro fatal no main: {e}", exc_info=True)
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        if handle != -1:
            xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == '__main__':
    main()