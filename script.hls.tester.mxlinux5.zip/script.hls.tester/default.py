import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import sys
import os
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import socket
import random
import logging
import logging.handlers
import hashlib
import functools
import ipaddress
import re
import queue
from collections import OrderedDict
from typing import Optional, Dict, Any, List, Tuple, Type, Union

# ==============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO ---
# ==============================================================================

# --- Estratégia de Reconexão e Falha ---
# OBJETIVO: Mais resiliência e reconexão imediata na primeira falha de segmento.
# Reconectar na primeira falha de segmento para tentar recuperar o stream rapidamente.
MAX_CONSECUTIVE_SEGMENT_FAILURES = 1

# --- Configurações do Fetcher (Requisições HTTP) ---
# Permite uma retentativa adicional ao baixar segmentos para maior resiliência.
FETCHER_MAX_RETRIES = 1
# Menor para respostas rápidas e jitter menor, mas aumentado para dar mais tempo de recuperação.
RETRY_BACKOFF_FACTOR = 0.15
CONNECTION_TIMEOUT = 8.0      # Tempo limite para estabelecer conexão.
STREAM_TIMEOUT = 8.0          # Tempo limite para leitura de dados do stream.

# --- Configurações do Proxy e Addon ---
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 10
# Mais tempo para cooldown em bloqueios de limite de conexão.
LIMIT_COOLDOWN_SECONDS = 30

# --- Configurações de Spoofing e Rede ---
SPOOF_X_FORWARDED_FOR = True
FIXED_X_FORWARDED_FOR_IP = "192.168.56.100"
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
]

# --- Configuração de Logging ---
LOG_MAX_BYTES = 1048576 * 2  # 2MB
LOG_BACKUP_COUNT = 2
LOG_FILE = xbmcvfs.translatePath('special://temp/hlsproxy.log')
LOG_LEVEL = logging.INFO

# --- Constantes ---
_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}

# ==============================================================================
# --- INICIALIZAÇÃO DO LOGGING ---
# ==============================================================================

def setup_logging():
    """Configura o logger para registrar em um arquivo rotativo."""
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(threadName)s] %(message)s',
        force=True
    )

setup_logging()

# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================

def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def join_host_port(host: str, port: int) -> str:
    return f'[{host}]:{port}' if ':' in host and is_valid_ip(host) else f'{host}:{port}'

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_player_headers(url: str, range_header: Optional[str] = None) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    user_agent = random.choice(USER_AGENTS)
    headers = {
        "User-Agent": user_agent,
        "Accept": "application/vnd.apple.mpegurl,video/mp2t,audio/aac,video/mp4",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin,
    }
    if range_header:
        headers["Range"] = range_header
    if SPOOF_X_FORWARDED_FOR:
        headers["X-Forwarded-For"] = FIXED_X_FORWARDED_FOR_IP
    return headers

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith('.m3u8') or path.endswith('.m3u'):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content:
        return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u":
        return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
                "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid"]
    return any(keyword in txt for keyword in keywords)

# ==============================================================================
# --- RESOLUTOR DE DNS (CUSTOMIZADO PARA CLOUDFLARE DOH) ---
# ==============================================================================

class DoHDNSResolver:
    def __init__(self, cache_ttl: int = 600, doh_url: str = 'https://dns.nextdns.io/629e1b'):
        self._cache: Dict[str, Tuple[str, float]] = {}
        self._lock = threading.Lock()
        self.cache_ttl = cache_ttl
        self.doh_url = doh_url
        self.session = requests.Session()
        logging.info("[DoHDNSResolver] DNS Resolver inicializado.")

    def _query_doh(self, hostname: str) -> Optional[str]:
        headers = {"Accept": "application/dns-json"}
        params = {"name": hostname, "type": "A"}
        try:
            response = self.session.get(self.doh_url, params=params, headers=headers, timeout=CONNECTION_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            if data and 'Answer' in data:
                for answer in data['Answer']:
                    if answer['type'] == 1:
                        logging.debug(f"[DoHDNSResolver] DoH resolveu {hostname} para {answer['data']}")
                        return answer['data']
            logging.warning(f"[DoHDNSResolver] Nenhuma resposta IP válida de DoH para {hostname}.")
            return None
        except Exception as e:
            logging.warning(f"[DoHDNSResolver] Erro ao consultar DoH para {hostname}: {e}")
            return None

    def resolve(self, hostname: str) -> Optional[str]:
        if is_valid_ip(hostname):
            return hostname
        with self._lock:
            cached_entry = self._cache.get(hostname)
            if cached_entry and time.time() < cached_entry[1]:
                return cached_entry[0]
        ip = self._query_doh(hostname)
        if ip:
            self._add_to_cache(hostname, ip, self.cache_ttl)
            return ip
        else:
            return None

    def _add_to_cache(self, hostname: str, ip: str, ttl: int):
        with self._lock:
            self._cache[hostname] = (ip, time.time() + ttl)

    def clear_cache_for_host(self, hostname: str):
        with self._lock:
            if hostname in self._cache:
                del self._cache[hostname]
                logging.info(f"[DoHDNSResolver] Cache DNS para {hostname} limpo.")

    def clear_cache(self):
        with self._lock:
            self._cache.clear()
            logging.info("[DoHDNSResolver] Cache DNS limpo.")

# ==============================================================================
# --- CACHE DE DADOS ---
# ==============================================================================

class RotatingChunkCache:
    """
    Cache de chunks rotativo. Para este proxy, está desativado para garantir
    que os segmentos sejam sempre buscados do upstream, evitando o uso de dados
    potencialmente obsoletos ou corrompidos em caso de perda de segmentos.
    """
    def __init__(self_obj):
        self_obj.lock = threading.Lock()
        self_obj.chunks: OrderedDict[str, bytes] = OrderedDict()
        self_obj.total_bytes = 0
        logging.info("[RotatingChunkCache] Cache de chunks inicializado (desativado para o proxy).")

    def get(self_obj, url: str) -> Optional[bytes]:
        """Sempre retorna None, desativando o cache de chunks."""
        return None

    def add(self_obj, url: str, data: bytes):
        """Não faz nada, desativando o cache de chunks."""
        pass

    def clear(self_obj):
        """Não faz nada, não há cache de chunks para limpar."""
        pass

    def has(self_obj, url: str) -> bool:
        """Sempre retorna False."""
        return False

class StreamCache:
    """
    Gerencia o cache de manifestos. O cache de manifestos é crucial para
    a reescrita e lógica do player, enquanto o cache de segmentos é desativado
    para maior resiliência em perda de segmentos.
    """
    def __init__(self_obj, chunk_cache: RotatingChunkCache):
        self_obj.manifest_cache: Dict[str, Dict[str, Any]] = {}
        self_obj.chunk_cache = chunk_cache # Mantido para compatibilidade, mas chunks desativados
        self_obj.lock = threading.Lock()
        logging.info("[StreamCache] Cache de stream (manifestos) inicializado.")

    def get_manifest(self_obj, url: str) -> Optional[str]:
        with self_obj.lock:
            entry = self_obj.manifest_cache.get(url)
            # Verifica se o manifesto está no cache e ainda é válido
            if entry and time.time() < entry['expires']:
                logging.debug(f"[StreamCache] Manifesto de {url} encontrado no cache e válido.")
                return entry['content']
            logging.debug(f"[StreamCache] Manifesto de {url} não encontrado ou expirado.")
            return None

    def add_manifest(self_obj, url: str, content: str, ttl: int):
        with self_obj.lock:
            self_obj.manifest_cache[url] = {
                'content': content,
                'expires': time.time() + ttl,
                'last_refresh_time': time.time()
            }
            logging.debug(f"[StreamCache] Manifesto de {url} adicionado ao cache com TTL de {ttl}s.")

    def invalidate_manifest(self_obj, url: str):
        with self_obj.lock:
            if url in self_obj.manifest_cache:
                del self_obj.manifest_cache[url]
                logging.debug(f"[StreamCache] Manifesto de {url} invalidado.")

    def is_manifest_expired(self_obj, url: str) -> bool:
        with self_obj.lock:
            entry = self_obj.manifest_cache.get(url)
            # Um manifesto é considerado expirado se não existe ou se o tempo de refresh expirou
            is_expired = not entry or (time.time() - entry.get('last_refresh_time', 0) >= entry.get('ttl', 0))
            if is_expired:
                logging.debug(f"[StreamCache] Manifesto de {url} considerado expirado para refresh.")
            return is_expired

    def get_segment(self_obj, url: str) -> Optional[bytes]:
        """Sempre retorna None, desativando o cache de segmentos."""
        return None

    def add_segment(self_obj, url: str, data: bytes):
        """Não faz nada, desativando o cache de segmentos."""
        pass

    def has_segment(self_obj, url: str) -> bool:
        """Sempre retorna False."""
        return False

    def clear(self_obj):
        with self_obj.lock:
            self_obj.manifest_cache.clear()
            logging.debug("[StreamCache] Cache de manifestos limpo.")

# ==============================================================================
# --- FETCHER E REWRITER ---
# ==============================================================================

class UpstreamFetcher:
    """
    Responsável por buscar conteúdo (manifestos e segmentos) do servidor upstream.
    Implementa retentativas e resolução DNS personalizada.
    """
    def __init__(self, session: requests.Session, dns_resolver: 'DoHDNSResolver'):
        self.session = session
        self.dns_resolver = dns_resolver
        logging.info("[UpstreamFetcher] UpstreamFetcher inicializado.")

    def fetch(self, url: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests.Response:
        """
        Realiza a requisição HTTP, com retentativas e resolução DNS.
        :param url: URL a ser buscada.
        :param stream: Se True, o corpo da resposta não é baixado imediatamente.
        :param original_headers: Cabeçalhos originais da requisição do cliente Kodi.
        :return: Objeto requests.Response.
        :raises requests.RequestException: Se todas as retentativas falharem.
        """
        headers = get_player_headers(url)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            # Propaga headers importantes como Authorization e Cookie
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie', 'Range']})
        if SPOOF_X_FORWARDED_FOR:
            headers['X-Forwarded-For'] = FIXED_X_FORWARDED_FOR_IP

        parsed_url = urllib.parse.urlparse(url)
        hostname = parsed_url.hostname
        resolved_ip = self.dns_resolver.resolve(hostname) if hostname else None
        req_url = url
        if resolved_ip and resolved_ip != hostname:
            # Se o IP foi resolvido via DoH e é diferente do hostname, usa o IP na URL
            # e adiciona o cabeçalho 'Host' original. Isso é útil para balanceadores de carga
            # que dependem do cabeçalho Host.
            req_url_parts = list(parsed_url)
            req_url_parts[1] = join_host_port(resolved_ip, parsed_url.port) if parsed_url.port else resolved_ip
            req_url = urllib.parse.urlunparse(req_url_parts)
            headers['Host'] = hostname

        logging.info(f"[UpstreamFetcher] Tentando buscar URL: {req_url} (Original: {url}) com headers: {headers}")
        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    req_url, stream=stream,
                    timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status() # Levanta HTTPError para respostas 4xx/5xx
                logging.debug(f"[UpstreamFetcher] Busca bem-sucedida para {url} (Tentativa {attempt + 1})")
                return resp
            except requests.RequestException as e:
                logging.warning(f"[UpstreamFetcher] Erro ao buscar {url} (Tentativa {attempt + 1}/{FETCHER_MAX_RETRIES + 1}): {e}")
                if attempt < FETCHER_MAX_RETRIES:
                    sleep_time = RETRY_BACKOFF_FACTOR * (2 ** attempt) + random.uniform(0, 0.12)
                    logging.debug(f"[UpstreamFetcher] Reintentando em {sleep_time:.2f} segundos...")
                    time.sleep(sleep_time)
                else:
                    raise # Re-lança a exceção se todas as retentativas falharem

class ManifestRewriter:
    """
    Reescreve as URIs dentro de um manifesto HLS para apontar para o proxy local.
    """
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        self.original_manifest_url = manifest_url
        self._is_live = not getattr(self.m3u8_obj, 'is_endlist', False)
        logging.debug(f"[ManifestRewriter] Manifesto carregado. É live: {self._is_live}")

    def rewrite(self) -> str:
        """
        Itera sobre playlists, mídias e segmentos e reescreve suas URIs
        para apontar para a URL do proxy local.
        """
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                original_uri = item.uri
                # Codifica a URI absoluta original para ser o parâmetro 'url' do proxy
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
                logging.debug(f"[ManifestRewriter] Reescrevendo URI: {original_uri} -> {item.uri}")
            if hasattr(item, 'key') and item.key and item.key.uri:
                # Trata chaves de criptografia que não são data URIs
                if not item.key.uri.startswith("data:"):
                    original_key_uri = item.key.uri
                    item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
                    logging.debug(f"[ManifestRewriter] Reescrevendo Key URI: {original_key_uri} -> {item.key.uri}")
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        """Retorna True se o manifesto representa um stream ao vivo (não tem #EXT-X-ENDLIST)."""
        return self._is_live

    def get_ttl(self) -> int:
        """
        Calcula um TTL (Time To Live) para o manifesto no cache.
        Para streams ao vivo, baseia-se na target_duration para permitir atualizações frequentes.
        """
        if self.is_live:
            target_duration = getattr(self.m3u8_obj, 'target_duration', 10)
            ttl = int(target_duration * 1.5) # Adiciona uma folga
            return max(ttl, 5) # Mínimo de 5 segundos
        return 3600 # Para VOD, um TTL maior

    def get_segments(self) -> List[str]:
        """Retorna uma lista das URIs absolutas de todos os segmentos no manifesto."""
        segments = []
        for segment in self.m3u8_obj.segments:
            segments.append(segment.absolute_uri)
        return segments

# ==============================================================================
# --- PROXY HTTP ---
# ==============================================================================

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    """
    Manipulador de requisições HTTP para o proxy HLS.
    Intercepta requisições de manifestos e segmentos, os reescreve/busca
    e os entrega ao cliente Kodi.
    """
    def __init__(self, request: bytes, client_address: Tuple[str, int], server: socketserver.BaseServer,
                 stream_cache: 'StreamCache', fetcher: 'UpstreamFetcher', proxy_manager: 'HLSProxyManager'):
        self.stream_cache = stream_cache
        self.fetcher = fetcher
        self.proxy_manager = proxy_manager
        super().__init__(request, client_address, server)

    def log_message(self, format: str, *args: Any):
        """Suprime o logging padrão do BaseHTTPRequestHandler para usar o sistema de logging do addon."""
        pass

    def _send_response(self, status_code: int, content: bytes, content_type: str, additional_headers: Optional[Dict] = None):
        """
        Envia uma resposta HTTP ao cliente.
        Não envia Content-Length para segmentos para permitir o buffering nativo do Kodi.
        """
        try:
            self.send_response(status_code) # Alterado para usar o status_code fornecido
            self.send_header('Content-Type', content_type)
            # Remove Content-Length para segmentos para permitir o próprio buffering do Kodi
            if content_type not in ['video/mp2t', 'audio/aac', 'video/mp4', 'application/octet-stream']:
                self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            if content:
                etag = f'"{hashlib.md5(content).hexdigest()}"'
                self.send_header('ETag', etag)
            self.send_header('Last-Modified', time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime()))
            self.send_header('Accept-Ranges', 'bytes')
            if content_type in ['video/mp2t', 'application/vnd.apple.mpegurl']:
                self.send_header('Content-Protection', 'cenc') # Pode ser útil para alguns players/conteúdos
            if additional_headers:
                for key, value in additional_headers.items():
                    self.send_header(key, value)
            self.end_headers()
            if content:
                self.wfile.write(content)
            self.wfile.flush()
            logging.debug(f"[{self.client_address[0]}:{self.client_address[1]}] Resposta enviada: {status_code} {content_type}")
        except BrokenPipeError:
            logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] BrokenPipeError ao enviar resposta.")
        except ConnectionResetError:
            logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] ConnectionResetError ao enviar resposta.")
        except Exception as e:
            logging.error(f"[{self.client_address[0]}:{self.client_address[1]}] Erro ao enviar resposta: {e}", exc_info=True)

    def do_GET(self):
        """
        Trata as requisições GET.
        Identifica se é um manifesto ou um segmento e chama o handler apropriado.
        """
        try:
            query_params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            original_url = query_params.get('url', [''])[0]
            if not original_url:
                logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] Requisição com parâmetro 'url' ausente: {self.path}")
                return self._send_response(400, "Parâmetro 'url' ausente".encode('utf-8'), "text/plain") # 400 Bad Request
            
            logging.info(f"[{self.client_address[0]}:{self.client_address[1]}] Recebida requisição para: {original_url}")

            if ".m3u8" in original_url.lower() or ".m3u" in original_url.lower():
                self._handle_manifest(original_url)
            else:
                self._handle_segment(original_url)
        except (BrokenPipeError, ConnectionResetError):
            logging.warning(f"[{self.client_address[0]}:{self.client_address[1]}] Conexão fechada pelo cliente durante GET.")
            pass # Cliente fechou a conexão, não há o que fazer
        except Exception as e:
            logging.error(f"[{self.client_address[0]}:{self.client_address[1]}] Erro inesperado no do_GET para {self.path}: {e}", exc_info=True)
            if not self.wfile.closed:
                # Em caso de erro, retorna um manifesto HLS vazio para o player não travar.
                self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

    def _handle_manifest(self, url: str):
        """
        Gerencia a busca, reescrita e cache de manifestos HLS.
        Inclui lógica de cooldown e reconexão forçada.
        """
        # Garante que apenas uma thread processe um manifesto por vez para evitar condições de corrida
        with self.proxy_manager.get_manifest_lock(url):
            if self.proxy_manager.is_in_cooldown(url):
                logging.warning(f"[HLSProxyHandler] Manifesto {url} em cooldown. Retornando manifesto vazio.")
                # Retorna um manifesto HLS vazio para o player tentar novamente mais tarde
                return self._send_response(200, b"#EXTM3U\n", 'application/vnd.apple.mpegurl')

            cached_content = self.stream_cache.get_manifest(url)
            if cached_content:
                logging.info(f"[HLSProxyHandler] Servindo manifesto {url} do cache.")
                return self._send_response(200, cached_content.encode('utf-8'), 'application/vnd.apple.mpegurl')

            # Se o manifesto não está no cache ou está expirado, tenta buscá-lo.
            # A lógica de is_manifest_expired para refresh não é estritamente necessária aqui
            # porque get_manifest já cuida da expiração. Esta linha pode ser removida.
            # if self.stream_cache.is_manifest_expired(url):
            #     logging.info(f"[HLSProxyHandler] Manifesto {url} expirado ou precisa de refresh. Forçando reconexão.")
            #     self.proxy_manager.force_reconnection(url)

            try:
                logging.info(f"[HLSProxyHandler] Buscando manifesto original: {url}")
                response = self.fetcher.fetch(url, original_headers=self.headers)
                content = response.text
                logging.debug(f"[HLSProxyHandler] Conteúdo do manifesto original (primeiros 200 chars): {content[:200]}")

                if is_manifest_limit_error(content):
                    logging.warning(f"[HLSProxyHandler] Manifesto {url} indica erro de limite. Entrando em cooldown.")
                    self.proxy_manager.record_limit_hit(url)
                    self.proxy_manager.force_reconnection(url) # Força reconexão para limpar DNS/sessão
                    return self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

                proxy_base = f"http://{join_host_port(self.server.server_address[0], self.server.server_address[1])}/?url="
                rewriter = ManifestRewriter(content, response.url, proxy_base)
                rewritten_content = rewriter.rewrite()
                ttl = rewriter.get_ttl()
                
                logging.debug(f"[HLSProxyHandler] Conteúdo do manifesto reescrito (primeiros 200 chars): {rewritten_content[:200]}")
                
                self.stream_cache.add_manifest(url, rewritten_content, ttl)
                self.proxy_manager.clear_limit_hit(url) # Se buscou com sucesso, remove do cooldown
                
                logging.info(f"[HLSProxyHandler] Manifesto {url} reescrito e servido.")
                self._send_response(200, rewritten_content.encode('utf-8'), 'application/vnd.apple.mpegurl')

            except Exception as e:
                logging.error(f"[HLSProxyHandler] Erro ao processar manifesto {url}: {e}", exc_info=True)
                self.proxy_manager.force_reconnection(url) # Força reconexão em qualquer erro de manifesto
                self._send_response(200, b"#EXTM3U\n", "application/vnd.apple.mpegurl")

    def _handle_segment(self, url: str):
        """
        Gerencia a busca e retransmissão de segmentos de vídeo/áudio.
        Implementa contagem de falhas consecutivas e reconexão forçada em caso de limite.
        """
        mime_type = safe_mime_type(url)
        
        try:
            logging.info(f"[HLSProxyHandler] Buscando segmento original: {url}")
            # original_headers inclui o cabeçalho 'Range' do Kodi, que é importante para SEEK.
            response = self.fetcher.fetch(url, stream=True, original_headers=self.headers)
            
            # Diretamente faz streaming do conteúdo para o cliente.
            # Isso é mais eficiente em termos de memória e latência do que baixar tudo de uma vez.
            self.send_response(200)
            self.send_header('Content-Type', mime_type)
            # NÃO envie Content-Length para segmentos, permita que o Kodi lide com o streaming e buffering
            self.send_header('Cache-Control', 'no-cache, no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Accept-Ranges', 'bytes') # Importante para permitir seek no player
            if mime_type in ['video/mp2t', 'audio/aac', 'video/mp4']:
                self.send_header('Content-Protection', 'cenc')
            
            # Propaga Content-Range se existir na resposta upstream ou na requisição original
            # Isso é crucial para o SEEK e para o Kodi entender a parte do arquivo que está recebendo.
            content_range = response.headers.get('Content-Range', self.headers.get('Range'))
            if content_range:
                self.send_header('Content-Range', content_range)
            
            # Copia outros cabeçalhos relevantes da resposta upstream, exceto os sensíveis ou já tratados
            for key, value in clean_headers(response.headers).items():
                if key.lower() not in ['content-type', 'content-length', 'transfer-encoding', 'connection', 'cache-control', 'access-control-allow-origin', 'etag', 'last-modified', 'accept-ranges', 'content-protection', 'content-range']:
                    self.send_header(key, value)
            
            self.end_headers()
            
            # Stream chunks diretamente para o wfile do cliente
            for chunk in response.iter_content(chunk_size=8192):
                if not chunk: # Se o chunk estiver vazio, pode indicar fim do stream ou problema
                    break
                self.wfile.write(chunk)
            self.wfile.flush()

            self.proxy_manager.reset_failure_count() # Segmento baixado com sucesso, reseta contador
            
            logging.info(f"[HLSProxyHandler] Segmento {url} baixado e servido (streaming).")

        except Exception as e:
            logging.error(f"[HLSProxyHandler] Erro ao buscar/servir segmento {url}: {e}", exc_info=True)
            self.proxy_manager.increment_failure_count()
            if self.proxy_manager.should_force_reconnect():
                logging.info(f"[HLSProxyHandler] Falhas consecutivas de segmento atingiram o limite ({MAX_CONSECUTIVE_SEGMENT_FAILURES}). Forçando reconexão bruta.")
                # Usa a URL base do segmento para forçar a reconexão.
                self.proxy_manager.force_reconnection(self.proxy_manager.get_base_url(url))  
                self.proxy_manager.reset_failure_count() # Reseta o contador após a tentativa de reconexão
            # Em caso de falha, envia uma resposta mínima para evitar que o Kodi trave.
            # Um segmento vazio ou resposta 200 com 0 bytes pode sinalizar um problema para o player
            # mas permite que ele tente o próximo segmento ou playlist.
            self._send_response(200, b"", "application/octet-stream")


class HLSProxyManager:
    """
    Gerencia o ciclo de vida do servidor proxy HLS, sessões HTTP, caches
    e a lógica de falhas/reconexões.
    """
    def __init__(self):
        self.server: Optional[socketserver.ThreadingTCPServer] = None
        self.server_thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None
        self._http_session: requests.Session = self._create_http_session()
        self.dns_resolver = DoHDNSResolver()
        self.chunk_cache = RotatingChunkCache() # Está efetivamente desativado
        self.stream_cache = StreamCache(self.chunk_cache) # Usado para manifestos
        self.fetcher = UpstreamFetcher(self._http_session, self.dns_resolver)
        self._failure_lock = threading.Lock()
        self._consecutive_failures = 0 # Contador de falhas consecutivas de segmento
        self._limit_hits: Dict[str, float] = {} # Registro de quando um limite de conexão foi atingido
        self._manifest_locks: Dict[str, threading.Lock] = {} # Locks para manifestos específicos
        logging.info("[HLSProxyManager] HLSProxyManager inicializado.")

    def _create_http_session(self) -> requests.Session:
        """Cria e configura uma nova sessão requests.Session."""
        session = requests.Session()
        session.headers.update({
            'User-Agent': USER_AGENTS[0], # Usa o primeiro user-agent como padrão da sessão
            'Accept': 'application/vnd.apple.mpegurl,video/mp2t,audio/aac,video/mp4',
            'Connection': 'keep-alive' # Mantém a conexão viva para reutilização
        })
        session.trust_env = False # Impede o uso de variáveis de ambiente para proxies
        logging.info("[HLSProxyManager] Nova sessão HTTP criada.")
        return session

    def reset_http_session(self):
        """Fecha a sessão HTTP atual e cria uma nova, útil para limpar estados de conexão."""
        logging.info("[HLSProxyManager] Resetando sessão HTTP e DNS.")
        self._http_session.close()
        self._http_session = self._create_http_session()
        self.fetcher.session = self._http_session # Atualiza a sessão no fetcher
        self.dns_resolver.clear_cache() # Limpa o cache DNS para novas resoluções

    def force_reconnection(self, url: str):
        """
        Força uma "reconexão" limpando o cache DNS para o host, invalidando caches
        de manifesto e resetando a sessão HTTP.
        """
        logging.info(f"[HLSProxyManager] Forçando reconexão para URL base/host: {url}")
        parsed_url = urllib.parse.urlparse(url)
        if parsed_url.hostname:
            self.dns_resolver.clear_cache_for_host(parsed_url.hostname)
        self.stream_cache.clear() # Limpa cache de manifestos
        self.reset_http_session() # Reseta a sessão HTTP

    def increment_failure_count(self):
        """Incrementa o contador de falhas consecutivas de segmentos."""
        with self._failure_lock:
            self._consecutive_failures += 1
            logging.warning(f"[HLSProxyManager] Incrementando contador de falhas consecutivas: {self._consecutive_failures}")

    def reset_failure_count(self):
        """Reseta o contador de falhas consecutivas de segmentos."""
        with self._failure_lock:
            if self._consecutive_failures > 0:
                logging.info(f"[HLSProxyManager] Resetando contador de falhas consecutivas.")
            self._consecutive_failures = 0

    def should_force_reconnect(self) -> bool:
        """Verifica se o número de falhas consecutivas atingiu o limite para forçar reconexão."""
        with self._failure_lock:
            return self._consecutive_failures >= MAX_CONSECUTIVE_SEGMENT_FAILURES

    def record_limit_hit(self, url: str):
        """Registra o momento em que um limite de conexão foi atingido para uma URL base."""
        base_url = self._get_base_url(url)
        self._limit_hits[base_url] = time.time()
        logging.warning(f"[HLSProxyManager] Limite atingido para {base_url}. Entrando em cooldown.")

    def is_in_cooldown(self, url: str) -> bool:
        """Verifica se uma URL base está em período de cooldown após um limite ser atingido."""
        base_url = self._get_base_url(url)
        hit_time = self._limit_hits.get(base_url)
        is_cooldown = hit_time and (time.time() - hit_time) < LIMIT_COOLDOWN_SECONDS
        if is_cooldown:
            remaining = int(LIMIT_COOLDOWN_SECONDS - (time.time() - hit_time))
            logging.info(f"[HLSProxyManager] {base_url} ainda em cooldown por {remaining}s.")
        return is_cooldown

    def clear_limit_hit(self, url: str):
        """Limpa o registro de limite atingido para uma URL base."""
        base_url = self._get_base_url(url)
        if base_url in self._limit_hits:
            del self._limit_hits[base_url]
            logging.info(f"[HLSProxyManager] Cooldown para {base_url} limpo.")

    @staticmethod
    def _get_base_url(url: str) -> str:
        """Extrai a URL base (esquema://host:porta) de uma URL completa."""
        parts = urllib.parse.urlparse(url)
        return f"{parts.scheme}://{parts.netloc}"

    def get_base_url(self, url: str) -> str:
        """Retorna a URL base de uma URL."""
        return self._get_base_url(url)

    def get_manifest_lock(self, url: str) -> threading.Lock:
        """Retorna um lock específico para um manifesto, garantindo acesso exclusivo."""
        with self._failure_lock: # Usa o lock de falhas para proteger o dicionário de locks de manifesto
            if url not in self._manifest_locks:
                self._manifest_locks[url] = threading.Lock()
            return self._manifest_locks[url]

    def start(self) -> Optional[int]:
        """
        Inicia o servidor proxy HTTP em uma porta aleatória disponível.
        Tenta várias portas antes de falhar.
        """
        self.stop() # Garante que qualquer instância anterior seja parada
        def handler_factory(*args, **kwargs):
            return HLSProxyHandler(*args, **kwargs,
                                   stream_cache=self.stream_cache,
                                   fetcher=self.fetcher,
                                   proxy_manager=self)
        for attempt in range(MAX_PORT_ATTEMPTS):
            port = random.randint(20000, 65000)
            try:
                # ThreadingTCPServer permite que cada requisição seja tratada em uma nova thread
                server = socketserver.ThreadingTCPServer((PROXY_HOST, port), handler_factory)
                server.allow_reuse_address = True # Permite reuso da porta após o fechamento
                self.server = server
                self.active_port = port
                self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True, name="HLSProxyServer")
                self.server_thread.start()
                logging.info(f"[HLSProxyManager] Proxy iniciado em {PROXY_HOST}:{port}")
                return port
            except Exception as e:
                logging.error(f"[HLSProxyManager] Erro ao iniciar proxy na porta {port}: {e}")
                continue
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro: Não foi possível iniciar o proxy",5000)')
        return None

    def stop(self):
        """Para o servidor proxy HTTP e limpa os recursos."""
        logging.info("[HLSProxyManager] Parando o proxy...")
        if self.server:
            self.server.shutdown() # Desliga o servidor
            self.server.server_close() # Fecha o socket do servidor
            self.server = None
            logging.info("[HLSProxyManager] Servidor HTTP do proxy parado.")
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=2) # Espera a thread do servidor terminar
            if self.server_thread.is_alive():
                logging.warning("[HLSProxyManager] Thread do servidor HTTP não encerrou a tempo.")
        
        self.stream_cache.clear() # Limpa o cache de manifestos
        with self._failure_lock: # Protege o acesso ao dicionário de locks
            self._manifest_locks.clear()
            logging.debug("[HLSProxyManager] Locks de manifesto limpos.")
        self.reset_http_session() # Reseta a sessão HTTP e limpa o cache DNS
        self.active_port = None
        logging.info("[HLSProxyManager] Proxy parado e caches limpos.")

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        """Gera a URL do proxy para uma URL de stream original."""
        if not self.active_port:
            return None
        encoded_url = urllib.parse.quote_plus(original_url)
        return f"http://{join_host_port(PROXY_HOST, self.active_port)}/?url={encoded_url}"

# ==============================================================================
# --- LÓGICA DO ADDON KODI ---
# ==============================================================================

class CustomPlayer(xbmc.Player):
    """
    Player customizado para o Kodi, que intercepta eventos de playback
    para sinalizar o fim da reprodução ao proxy.
    """
    def __init__(self, stop_event: threading.Event):
        super().__init__()
        self.stop_event = stop_event
        logging.info("[CustomPlayer] Player customizado inicializado.")

    def onPlayBackEnded(self):
        """Chamado quando a reprodução termina normalmente."""
        logging.info("[CustomPlayer] Playback ended.")
        self.stop_event.set()

    def onPlayBackError(self):
        """Chamado quando ocorre um erro durante a reprodução."""
        logging.error("[CustomPlayer] Playback error!")
        self.stop_event.set()

    def onPlayBackStopped(self):
        """Chamado quando a reprodução é parada pelo usuário ou sistema."""
        logging.info("[CustomPlayer] Playback stopped.")
        self.stop_event.set()

class HLSProxyAddon:
    """
    Classe principal do addon Kodi, responsável pela interface com o usuário,
    início/parada do proxy e gerenciamento do playback.
    """
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy_manager = HLSProxyManager()
        self.playback_stop_event = threading.Event()
        self.player = CustomPlayer(self.playback_stop_event)
        logging.info(f"[HLSProxyAddon] Addon inicializado com handle: {handle}")

    def _convert_to_m3u8(self, url: str) -> str:
        """
        Tenta converter uma URL de stream para um formato HLS M3U8 se
        não for explicitamente um manifesto HLS.
        Isso ajuda na compatibilidade com diferentes formatos de URL de IPTV.
        """
        original_url = url
        try:
            # Remove parâmetros adicionais que o Kodi possa enviar após o pipe (| ou %7C)
            if '%7C' in url:
                url = url.split('%7C', 1)[0]
            if '|' in url:
                url = url.split('|', 1)[0]
            
            # Se já é um manifesto .m3u8 ou .m3u, retorna como está.
            if re.search(r'\.(m3u8|m3u)$', url, re.IGNORECASE):
                logging.debug(f"[_convert_to_m3u8] URL já é manifesto HLS: {url}")
                return url
            
            parts = urllib.parse.urlparse(url)
            path_segments = [s for s in parts.path.split('/') if s]

            # Heurística para adicionar '/live' se não for um arquivo de vídeo direto
            # e 'live' não estiver no caminho.
            if 'live' not in path_segments and not re.search(r'\.(mp4|avi|ts)$', parts.path, re.IGNORECASE):
                if len(path_segments) > 0:
                    last_segment = path_segments[-1]
                    # Evita adicionar '/live' se o último segmento parece ser um ID ou hash
                    if not re.fullmatch(r'\d+|[a-fA-F0-9]{32,}', last_segment):
                        new_path_segments = path_segments[:-1] + ['live'] + [path_segments[-1]]
                        new_path = '/' + '/'.join(new_path_segments)
                        url = parts._replace(path=new_path).geturl()
                        logging.debug(f"[_convert_to_m3u8] Adicionado '/live' à URL: {url}")
                else:
                    url = parts._replace(path=parts.path.rstrip('/') + '/live').geturl()
                    logging.debug(f"[_convert_to_m3u8] Adicionado '/live' à URL vazia: {url}")

            # Se ainda não termina em .m3u8 e não é um segmento de vídeo conhecido, adiciona .m3u8
            if not re.search(r'\.(ts|mp4|aac)$', url, re.IGNORECASE) and not url.endswith('.m3u8'):
                url += '.m3u8'
                logging.debug(f"[_convert_to_m3u8] Adicionado '.m3u8' à URL: {url}")
            
            logging.debug(f"[_convert_to_m3u8] URL convertida de {original_url} para {url}")
            return url
        except Exception as e:
            logging.error(f"[HLSProxyAddon] Erro ao converter URL {original_url}: {e}", exc_info=True)
            return original_url

    def play_stream(self, url: str, channel_name: Optional[str] = None):
        """
        Prepara e inicia a reprodução de um stream HLS através do proxy.
        """
        logging.info(f"[HLSProxyAddon] Tentando reproduzir stream: {url} (Nome: {channel_name})")
        processed_url = self._convert_to_m3u8(url) # Converte a URL para um formato HLS compatível
        logging.info(f"[HLSProxyAddon] URL processada para reprodução: {processed_url}")

        if not self.proxy_manager.start():
            logging.error("[HLSProxyAddon] Falha ao iniciar o proxy. Não é possível reproduzir.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        proxy_url = self.proxy_manager.get_proxy_url(processed_url)
        if not proxy_url:
            logging.error("[HLSProxyAddon] Falha ao obter URL do proxy. Não é possível reproduzir.")
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        
        logging.info(f"[HLSProxyAddon] URL do proxy para reprodução: {proxy_url}")
        display_name = f"{channel_name or 'Stream'} [COLOR cyan](HLS Tester)[/COLOR]"
        list_item = xbmcgui.ListItem(path=proxy_url, label=display_name)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setMimeType('application/vnd.apple.mpegurl') # Define o tipo MIME para HLS
        
        xbmcplugin.setResolvedUrl(self.handle, True, list_item) # Informa ao Kodi a URL para reproduzir
        logging.info("[HLSProxyAddon] URL resolvida para o Kodi. Iniciando monitoramento de playback.")
        
        # Inicia uma thread para monitorar o playback e parar o proxy quando ele terminar.
        threading.Thread(target=self.monitor_playback, daemon=True, name="PlaybackMonitor").start()

    def monitor_playback(self):
        """
        Monitora o evento de parada do player e desliga o proxy quando ele ocorre.
        """
        logging.info("[HLSProxyAddon] Monitor de playback iniciado. Aguardando evento de parada.")
        self.playback_stop_event.wait() # Bloqueia até que o evento de parada seja disparado
        logging.info("[HLSProxyAddon] Evento de parada de playback recebido. Parando o proxy.")
        self.proxy_manager.stop() # Para o proxy
        logging.info("[HLSProxyAddon] Proxy parado após término do playback.")

    def show_test_streams(self):
        """
        Adiciona itens de diretório ao Kodi para streams de teste.
        """
        logging.info("[HLSProxyAddon] Exibindo streams de teste.")
        test_streams = [
            ("Big Buck Bunny (VOD - Teste de download completo)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            ("Exemplo Live (Pode estar offline, teste de atualização manifesto)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"),
            ("Exemplo Live (TS, converter para M3U8)", "http://sample.vodobox.com/skate_park_pic.ts"),
            ("Exemplo Live (sem ext, heurística)", "http://live.hkstv.hk/live/hks/playlist"),
        ]
        for name, url in test_streams:
            list_item = xbmcgui.ListItem(label=name)
            list_item.setProperty('IsPlayable', 'true')
            list_item.setMimeType(safe_mime_type(url)) # Define o tipo MIME baseado na URL
            # Cria a URL do plugin que será chamada quando o item for selecionado
            plugin_url_params = urllib.parse.urlencode({'action': 'play', 'url': url, 'title': name})
            plugin_url = f"plugin://{ADDON_ID}/?{plugin_url_params}"
            xbmcplugin.addDirectoryItem(self.handle, plugin_url, list_item, isFolder=False)
            logging.debug(f"[HLSProxyAddon] Adicionado item de diretório: {name} -> {plugin_url}")
        xbmcplugin.endOfDirectory(self.handle) # Sinaliza o fim do diretório
        logging.info("[HLSProxyAddon] Fim da listagem de streams de teste.")

def main():
    """Função principal do script do addon Kodi."""
    try:
        handle = int(sys.argv[1])
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get('action')
        
        setup_logging() # Garante que o logging esteja configurado
        logging.info(f"Main iniciado. sys.argv: {sys.argv}")
        
        addon = HLSProxyAddon(handle)
        if action == 'play':
            url_to_play = params.get('url')
            title = params.get('title')
            if url_to_play:
                addon.play_stream(url_to_play, title)
            else:
                logging.error("[main] Ação 'play' chamada sem URL.")
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            addon.show_test_streams()
    except Exception as e:
        logging.critical(f"Erro fatal na função main: {e}", exc_info=True)
        xbmc.executebuiltin(f'Notification({ADDON_NAME},"Erro crítico: Veja o log",5000)')

if __name__ == '__main__':
    main()