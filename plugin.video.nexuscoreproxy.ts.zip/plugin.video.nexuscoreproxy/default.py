# -*- coding: utf-8 -*-
# NEXUS X-CODES HYBRID V20.67 (Grinch Fix - TS Sync Correto)
#
# Root-cause do Grinch em V20.66 (corrigido aqui):
#
#   BUG 1 — aligned_idx ERRADO (causa principal do Grinch):
#     TAIL_SIZE = 32768 bytes. 32768 % 188 = 56 → a tail nunca começa
#     num limite de packet TS. O aligned_idx = (idx // 188) * 188
#     cortava 112 bytes A MENOS que o necessário. O remainder começava
#     antes do fim real da tail, reinjetava bytes já reproduzidos, e
#     _process() alinhava num 0x47 falso dentro de dados PES → Grinch.
#     FIX: remover o aligned_idx. skip = idx + len(primary) é suficiente.
#     _process() já busca o 0x47 no remainder — deixar ele fazer o trabalho.
#
#   BUG 2 — _process() não validava o sync byte:
#     batch.find(b'\x47') achava falsos 0x47 dentro de payloads PES.
#     FIX: find_sync_offset() valida com dupla checagem:
#     buf[i] == 0x47 E buf[i + 188] == 0x47 (quando possível).
#     Isso garante que o alinhamento inicial é num sync byte real.
#
#   BUG 3 — DynamicTailSaver race condition:
#     Thread separada podia ler stream_tail = b'' durante o reset e
#     sobrescrever tail_cache._live antes de promote_to_backup() terminar.
#     FIX: TailSaver só salva se len(stream_tail) >= TS_PACKET_SIZE * 4
#     e verifica _real_bytes_sent > 0 antes de qualquer escrita no cache.
#
#   SUTURA INTOCADA: rfind(), janela deslizante, primary/secondary,
#   SingleTailCache, DynamicTailSaver — estrutura 100% preservada.

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, parse_qs
from requests.adapters import HTTPAdapter
from http.server import HTTPServer, BaseHTTPRequestHandler

import xbmc
import xbmcgui
import xbmcplugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS   = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

VERSION = 'V20.67'

TS_PACKET_SIZE = 188
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
NULL_BLOCK     = TS_NULL_PACKET * 7

CHUNK_SIZE_MIN  = 32  * 1024
CHUNK_SIZE_MAX  = 512 * 1024
CHUNK_SIZE_DEF  = 128 * 1024
TS_CHUNK_SIZE   = 8   * 1024

# CORREÇÃO: Timeouts reduzidos para evitar "stream stalled" do Kodi.
# Se o servidor parar de enviar, detectamos em 10s (antes do buffer do Kodi zerar).
FETCH_TIMEOUT   = 10
CONNECT_TIMEOUT = 4
QUEUE_SIZE      = 512

PREBUFFER_BYTES   = 188 * 1024
PREBUFFER_TIMEOUT = 6.0

KEEPALIVE_INTERVAL = 0.04
WATCHDOG_INTERVAL  = 3.0
# CORREÇÃO: Starvation reduzido. Se parar de chegar dados por 4s, reconecta.
# Antes 12s era tarde demais para o buffer do Kodi.
STARVATION_TIMEOUT = 4.0

TOKEN_EXPIRED_CODES   = {401, 403, 404, 410}
MANIFEST_FAIL_TIMEOUT = 8
BACKOFF_SEQUENCE = [0.5, 1.0, 2.0, 5.0, 10.0, 15.0]

SESSION_RESET_FAIL_LIMIT   = 3
# CORREÇÃO: Backoff de reset removido (0.0). Reconexão deve ser imediata.
SESSION_RESET_BACKOFF      = 0.0

# ---- Sutura - JANELA DESLIZANTE 3MB + ALINHAMENTO TS -----------------------
TAIL_SIZE           = 32 * 1024
TAIL_SECONDARY      = 8  * 1024
SLIDING_WINDOW_SIZE = 12 * 1024 * 1024
SUTURE_MAX_TIME     = 9.0

TAIL_SAVE_INTERVAL  = 0.25
TAIL_SAVE_MIN_DELTA = 1024

_ALL_UA = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15;7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 7.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.0 Chrome/122.0.0.0 TV Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20',
    'Lavf/60.3.100',
    'Kodi/20.5 (Windows NT 10.0; Win64; x64) App_Bitness/64 Version/20.5',
]

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in (10, 127, 169, 172, 192, 198, 203, 224): continue
        o2, o3 = random.randint(0, 255), random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31: continue
        if o1 == 192 and o2 == 168: continue
        return '%d.%d.%d.%d' % (o1, o2, o3, o4)

def get_stealth_headers(target_url):
    fake_ip = random_ip()
    parsed  = urlparse(target_url)
    base    = '%s://%s/' % (parsed.scheme, parsed.netloc)
    ua      = random.choice(_ALL_UA)
    cv      = random.choice(['121', '122', '123', '124'])
    if   'Android'  in ua: plat, mob = '"Android"', '?1'
    elif 'iPhone'   in ua or 'iPad' in ua: plat, mob = '"iOS"', '?1'
    elif 'SMART-TV' in ua: plat, mob = '"SmartTV"', '?0'
    elif 'Windows'  in ua: plat, mob = '"Windows"', '?0'
    elif 'Macintosh' in ua: plat, mob = '"macOS"',   '?0'
    elif 'Linux'    in ua: plat, mob = '"Linux"',   '?0'
    else:                   plat, mob = '"Unknown"', '?0'
    return {
        'User-Agent': ua, 'Accept': '*/*',
        'Accept-Language': random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9,en;q=0.8']),
        'Connection': 'keep-alive', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache',
        'Referer': base, 'Origin': base.rstrip('/'), 'DNT': str(random.randint(0, 1)),
        'X-Forwarded-For': fake_ip, 'X-Real-IP': fake_ip, 'Client-IP': fake_ip,
        'Sec-CH-UA': '"Not;A-Brand";v="99","Google Chrome";v="%s","Chromium";v="%s"' % (cv, cv),
        'Sec-CH-UA-Mobile': mob, 'Sec-CH-UA-Platform': plat,
        'Sec-Fetch-Site': 'cross-site', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Dest': 'empty',
        'Upgrade-Insecure-Requests': '1',
    }

class ReconnectionSystem(object):
    def __init__(self):
        self.history = []
        self.last_success_idx = None
    @staticmethod
    def _make_session():
        s = requests.Session()
        a = HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=0)
        s.mount('http://', a); s.mount('https://', a)
        return s
    @staticmethod
    def _do_get(session, url, extra=None, t_add=(0, 0)):
        h = get_stealth_headers(url)
        h.pop('Accept-Encoding', None)
        if extra: h.update(extra)
        return session.get(url, headers=h, stream=True, timeout=(CONNECT_TIMEOUT + t_add[0], FETCH_TIMEOUT + t_add[1]), verify=False, allow_redirects=True)
    def _s0_fast(self, s, url): return self._do_get(s, url, {'X-Request-Id': str(uuid.uuid4())})
    def _s1_backoff(self, s, url): time.sleep(random.uniform(0.5, 1.5)); return self._do_get(s, url, t_add=(5, 10))
    def _s2_new_session(self, s, url): return self._do_get(self._make_session(), url, {'Accept-Encoding': 'identity'})
    def _s3_alt_proto(self, s, url):
        alt = url.replace('https://', 'http://', 1) if url.startswith('https://') else url.replace('http://', 'https://', 1)
        return self._do_get(s, alt, {'Accept-Encoding': 'identity'})
    def _s4_new_ip(self, s, url): time.sleep(random.uniform(0.5, 2.0)); return self._do_get(s, url, {'X-Device-ID': str(uuid.uuid4())})
    def _s5_cache_bust(self, s, url):
        sep = '&' if '?' in url else '?'
        return self._do_get(s, '%s%s_t=%d' % (url, sep, int(time.time())), {'Cache-Control': 'no-cache, no-store', 'Pragma': 'no-cache'})
    _STRATEGIES = [_s0_fast, _s1_backoff, _s2_new_session, _s3_alt_proto, _s4_new_ip, _s5_cache_bust]
    def next_idx(self):
        if self.last_success_idx is not None: return self.last_success_idx
        if not self.history: return 0
        used = set(self.history[-3:])
        avail = [i for i in range(len(self._STRATEGIES)) if i not in used]
        if avail: return random.choice(avail)
        counts = {x: self.history.count(x) for x in set(self.history)}
        return min(counts, key=counts.get)
    def execute(self, idx, session, url):
        return self._STRATEGIES[idx % len(self._STRATEGIES)](self, session, url)

class AdaptiveChunkSizer(object):
    def __init__(self):
        self._size = CHUNK_SIZE_DEF; self._bytes = 0; self._t_last = time.time(); self._lock = threading.Lock()
    def update(self, n):
        with self._lock:
            self._bytes += n; now = time.time(); dt = now - self._t_last
            if dt >= 2.0:
                rate = self._bytes / dt
                if rate > 4*1024*1024: self._size = CHUNK_SIZE_MAX
                elif rate > 1*1024*1024: self._size = 256*1024
                elif rate > 256*1024: self._size = 128*1024
                else: self._size = CHUNK_SIZE_MIN
                self._bytes = 0; self._t_last = now
    @property
    def size(self):
        with self._lock: return self._size

class SingleTailCache(object):
    def __init__(self):
        self._live = b''; self._backup = b''; self._lock = threading.Lock()
    def update_live(self, tail):
        if not tail or len(tail) < TS_PACKET_SIZE: return False
        with self._lock:
            self._live = tail[-TAIL_SIZE:] if len(tail) > TAIL_SIZE else tail
            return True
    def promote_to_backup(self):
        with self._lock:
            if self._live and len(self._live) >= TS_PACKET_SIZE:
                self._backup = self._live; self._live = b''; return True
        return False
    def get_for_suture(self):
        with self._lock: return self._live
    def get_for_recovery(self):
        with self._lock:
            if not self._live and self._backup: return self._backup
            return b''
    def suture_done(self):
        with self._lock: self._live = b''; self._backup = b''
    def clear_live(self):
        with self._lock: self._live = b''
    def clear_all(self):
        with self._lock: self._live = b''; self._backup = b''
    @property
    def has_live(self):
        with self._lock: return bool(self._live and len(self._live) >= TS_PACKET_SIZE)
    @property
    def has_backup(self):
        with self._lock: return bool(self._backup and len(self._backup) >= TS_PACKET_SIZE)

class DynamicTailSaver(threading.Thread):
    def __init__(self, engine):
        super(DynamicTailSaver, self).__init__(daemon=True, name='TailSaver')
        self.engine = engine; self._stop = threading.Event(); self._last_hash = None
    def run(self):
        while not self._stop.wait(timeout=TAIL_SAVE_INTERVAL):
            tail = self.engine.stream_tail
            # Guarda apenas se há bytes reais suficientes E o engine entregou dados.
            # Sem essa checagem, o saver podia ler stream_tail=b'' durante o reset
            # e sobrescrever tail_cache._live antes de promote_to_backup() terminar.
            if not tail or len(tail) < TS_PACKET_SIZE * 4: continue
            if self.engine._real_bytes_sent == 0: continue
            h = hash(tail[-512:]) if len(tail) >= 512 else hash(tail)
            if h != self._last_hash:
                if self.engine.tail_cache.update_live(tail): self._last_hash = h
    def force_save(self):
        tail = self.engine.stream_tail
        if tail and len(tail) >= TS_PACKET_SIZE and self.engine._real_bytes_sent > 0:
            self.engine.tail_cache.update_live(tail)
            self._last_hash = hash(tail[-512:]) if len(tail) >= 512 else hash(tail)
    def mark_synced(self):
        tail = self.engine.stream_tail
        if tail: self._last_hash = hash(tail[-512:]) if len(tail) >= 512 else hash(tail)
    def reset(self): self._last_hash = None
    def stop(self): self._stop.set()

class XCodesEngine(object):
    def __init__(self):
        self.entry_url = None; self.current_url = None; self.base_url = None; self.active_param = None
        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self._stop_event = threading.Event(); self.prebuf_ready = threading.Event(); self._engine_lock = threading.Lock()
        self._gen = 0; self._gen_lock = threading.Lock()
        self.session = None; self._active_response = None; self._active_response_lock = threading.Lock()
        self.reconn = ReconnectionSystem(); self.chunk_sizer = AdaptiveChunkSizer()
        self.stream_tail = b''; self.residual_buffer = b''; self.has_initial_lock = False
        self.tail_cache = SingleTailCache(); self.tail_saver = DynamicTailSaver(self)
        self.emergency = queue.Queue(maxsize=200); self._refill_emergency()
        self._producer_thread = None; self._watchdog_thread = None
        self._prebuf_bytes = 0; self.last_data_time = 0.0; self.starvation_counter = 0
        self.consecutive_failures = 0; self.token_expired_count = 0; self.reconnection_count = 0
        self._real_bytes_sent = 0; self._watchdog_restart_flag = threading.Event()
        self._next_fake_ip = random_ip(); self._next_ua = random.choice(_ALL_UA)

    def _refill_emergency(self):
        for _ in range(200):
            try: self.emergency.put_nowait(NULL_BLOCK)
            except queue.Full: break
            
    def _push_keepalive(self, n=8):
        for _ in range(n):
            try: self.data_queue.put_nowait(NULL_BLOCK)
            except queue.Full: pass

    def _next_gen(self):
        with self._gen_lock: self._gen += 1; return self._gen
    def _get_gen(self):
        with self._gen_lock: return self._gen
    def _set_active_response(self, r):
        with self._active_response_lock: self._active_response = r
    def _clear_queue(self):
        while True:
            try: self.data_queue.get_nowait()
            except queue.Empty: break
            
    def _new_session_with_rotation(self):
        if self.session:
            try: self.session.close()
            except Exception: pass
        self.session = requests.Session()
        a = HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=0)
        self.session.mount('http://', a); self.session.mount('https://', a)
        self.reconnection_count += 1; self._next_fake_ip = random_ip(); self._next_ua = random.choice(_ALL_UA)
        if self.reconnection_count % 5 == 0: gc.collect()

    def _prepare_for_reset(self, reason=''):
        tail = self.stream_tail
        if tail and len(tail) >= TS_PACKET_SIZE and self._real_bytes_sent > 0:
            self.tail_cache.update_live(tail)
            self.tail_cache.promote_to_backup()
            self.tail_saver.mark_synced()

    def _session_reset(self, reason=''):
        xbmc.log('[RESET] %s' % reason, xbmc.LOGWARNING)
        with self._active_response_lock:
            if self._active_response:
                try: self._active_response.close()
                except Exception: pass
                self._active_response = None
        self._clear_queue(); self._push_keepalive(10)
        self._prepare_for_reset(reason)
        self.consecutive_failures = 0; self.token_expired_count = 0; self.starvation_counter = 0
        self._prebuf_bytes = 0; self.prebuf_ready.clear(); self.last_data_time = time.time()
        self.stream_tail = b''; self.residual_buffer = b''; self.has_initial_lock = False; self._real_bytes_sent = 0
        self._new_session_with_rotation(); self.tail_saver.reset()
        self._stop_event.wait(timeout=SESSION_RESET_BACKOFF)

    def _start_producer(self):
        self._stop_event.clear(); self._watchdog_restart_flag.clear()
        t = threading.Thread(target=self._producer_loop, name='XCodes-Producer', daemon=True)
        self._producer_thread = t; t.start()
    def _start_watchdog(self):
        t = threading.Thread(target=self._watchdog_loop, name='XCodes-Watchdog', daemon=True)
        self._watchdog_thread = t; t.start()
    def _start_tail_saver(self):
        if not self.tail_saver.is_alive():
            self.tail_saver = DynamicTailSaver(self); self.tail_saver.start()
    def _stop_tail_saver(self):
        if self.tail_saver.is_alive(): self.tail_saver.stop()

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls: raise ValueError('URL vazia')
        entry = urls[0]
        with self._engine_lock:
            same = (self.active_param == url_param)
            if same and self._producer_thread and self._producer_thread.is_alive(): return
            
            self._stop_event.set(); self._stop_tail_saver(); time.sleep(0.1)
            self._clear_queue()
            if same and self._real_bytes_sent > 0 and self.stream_tail:
                self._prepare_for_reset('reinicio_same')
            self.tail_cache.clear_all(); self.stream_tail = b''; self.residual_buffer = b''; self.has_initial_lock = False
            self._new_session_with_rotation(); self._next_gen()
            self._prebuf_bytes = 0; self.prebuf_ready.clear(); self.last_data_time = time.time()
            self.starvation_counter = 0; self.consecutive_failures = 0; self.token_expired_count = 0; self._real_bytes_sent = 0
            if not same:
                self.active_param = url_param; self.reconn.history = []; self.reconn.last_success_idx = None
            self.entry_url = entry; self.current_url = entry; self.base_url = entry.split('?')[0]
            self._refill_emergency(); self._start_tail_saver(); self._start_producer(); self._start_watchdog()

    def _watchdog_loop(self):
        while not self._stop_event.wait(timeout=WATCHDOG_INTERVAL):
            if self.last_data_time == 0.0: continue
            if time.time() - self.last_data_time >= STARVATION_TIMEOUT:
                self.starvation_counter += 1; self._watchdog_restart_flag.set()
                self._push_keepalive(10); self.last_data_time = time.time()

    # ---- A SANTÍSSIMA TRINDADE DA SUTURA -----------------------------------
    def _try_suture(self, buf):
        # 1. JANELA DESLIZANTE: Mantém apenas os últimos 3MB para busca rápida
        if len(buf) > SLIDING_WINDOW_SIZE:
            buf = buf[-SLIDING_WINDOW_SIZE:]
            
        # 2. TAIL LIVE (Acabou de salvar dinamicamente)
        tail = self.tail_cache.get_for_suture()
        if tail:
            r = self._find_match(buf, tail, 'LIVE')
            if r[0]: return r
            
        # 3. TAIL BACKUP (Segurança contra crash)
        tail = self.tail_cache.get_for_recovery()
        if tail:
            r = self._find_match(buf, tail, 'BACKUP')
            if r[0]: return r
            
        return False, b''

    def _find_match(self, buf, tail, label):
        if not tail: return False, b''

        primary = tail[-TAIL_SIZE:] if len(tail) >= TAIL_SIZE else tail
        if primary and primary in buf:
            # rfind() pula cenas estáticas direto pro Live Edge (fim do loop)
            idx  = buf.rfind(primary)
            skip = idx + len(primary)
            # CORREÇÃO V20.67 — BUG DO GRINCH:
            # O aligned_idx = (idx // 188) * 188 da V20.66 era INCORRETO.
            # TAIL_SIZE = 32768, 32768 % 188 = 56 → primary nunca começa
            # num limite de packet. O aligned_idx cortava 112 bytes a menos,
            # reinjetando bytes já reproduzidos. O 0x47 falso nesses bytes
            # causava desalinhamento permanente → Grinch verde.
            # SOLUÇÃO: skip = idx + len(primary) já é o ponto exato após a
            # tail. _process() valida o 0x47 real com dupla checagem.
            xbmc.log('[SUTURA] Perfeita [%s] pulou %dKB' % (label, skip // 1024), xbmc.LOGINFO)
            return True, buf[skip:]

        secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
        if secondary and len(buf) > TAIL_SECONDARY + 188 * 50 and secondary in buf:
            idx  = buf.rfind(secondary)
            skip = idx + len(secondary)
            # Mesma correção: sem aligned_idx. _process() alinha depois.
            xbmc.log('[SUTURA] Rapida [%s] pulou %dKB' % (label, skip // 1024), xbmc.LOGINFO)
            return True, buf[skip:]

        return False, b''

    @staticmethod
    def _find_sync_offset(data):
        """
        Localiza o primeiro sync byte 0x47 REAL no buffer.
        Dupla checagem: valida que data[i+188] também é 0x47 (quando possível).
        Isso evita alinhar num 0x47 falso dentro de dados PES/payload,
        que é a causa do Grinch verde após sutura.
        """
        i = 0
        length = len(data)
        while i < length:
            if data[i] == 0x47:
                # Valida com o próximo packet se houver espaço suficiente
                if i + TS_PACKET_SIZE < length:
                    if data[i + TS_PACKET_SIZE] == 0x47:
                        return i  # Sync byte real confirmado
                    # 0x47 falso (dados PES) — avança 1 byte e continua
                    i += 1
                    continue
                else:
                    # Não há bytes suficientes para dupla checagem: aceita
                    return i
            i += 1
        return -1

    def _process(self, raw, my_gen):
        if my_gen != self._get_gen() or not raw: return
        batch = self.residual_buffer + raw
        if not self.has_initial_lock:
            # Usa dupla checagem para nunca alinhar num 0x47 falso de dados PES
            idx = self._find_sync_offset(batch)
            if idx == -1:
                self.residual_buffer = batch[-(TS_PACKET_SIZE * 2):] if len(batch) > TS_PACKET_SIZE * 2 else batch
                return
            batch = batch[idx:]; self.has_initial_lock = True
        n = len(batch) // TS_PACKET_SIZE
        if n == 0: self.residual_buffer = batch; return
        used = n * TS_PACKET_SIZE; payload = batch[:used]; self.residual_buffer = batch[used:]
        self.stream_tail += payload
        if len(self.stream_tail) > TAIL_SIZE + TAIL_SECONDARY: self.stream_tail = self.stream_tail[-TAIL_SIZE:]
        self.last_data_time = time.time(); self.starvation_counter = 0; self.chunk_sizer.update(len(payload))
        if not self.prebuf_ready.is_set():
            self._prebuf_bytes += len(payload)
            if self._prebuf_bytes >= PREBUFFER_BYTES: self.prebuf_ready.set()
        try: self.data_queue.put_nowait(payload)
        except queue.Full:
            try: self.data_queue.get_nowait(); self.data_queue.put_nowait(payload)
            except Exception: pass

    def _producer_loop(self):
        my_gen = self._get_gen(); failure_count = 0; strategy_idx = 0
        while not self._stop_event.is_set():
            if self._watchdog_restart_flag.is_set():
                self._watchdog_restart_flag.clear(); self.consecutive_failures += 1; self.last_data_time = time.time()
            r = None
            try:
                needs_reconn = (self.consecutive_failures >= 1 or self.token_expired_count >= 1)
                if needs_reconn:
                    target_url = self.base_url; strategy_idx = self.reconn.next_idx()
                    xbmc.log('[PRODUCER] Reconexao S%d' % strategy_idx, xbmc.LOGINFO)
                    self.reconn.history.append(strategy_idx)
                    self._prepare_for_reset('reconexao')
                    self._new_session_with_rotation()
                    self.stream_tail = b''; self.residual_buffer = b''; self.has_initial_lock = False
                    self._real_bytes_sent = 0; self.tail_saver.reset()
                    try: r = self.reconn.execute(strategy_idx, self.session, target_url)
                    except Exception as e:
                        self._session_reset('Falha: %s' % type(e).__name__); failure_count += 1; continue
                else:
                    target_url = self.current_url; h = get_stealth_headers(target_url)
                    if self._next_fake_ip:
                        h['X-Forwarded-For'] = self._next_fake_ip; h['X-Real-IP'] = self._next_fake_ip; h['Client-IP'] = self._next_fake_ip
                    if self._next_ua: h['User-Agent'] = self._next_ua
                    h.pop('Accept-Encoding', None)
                    try: r = self.session.get(target_url, headers=h, stream=True, timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT), verify=False, allow_redirects=True)
                    except Exception as e:
                        self._session_reset('Falha init: %s' % type(e).__name__); failure_count += 1; continue

                if r is None:
                    self.consecutive_failures += 1; self._push_keepalive(5); self._stop_event.wait(1.0); continue
                status = r.status_code
                if status in TOKEN_EXPIRED_CODES:
                    self.token_expired_count += 1; self._prepare_for_reset('token'); r.close()
                    if self.token_expired_count >= 2:
                        self._session_reset('Token %d' % status); failure_count += 1
                    else:
                        wait = min(8.0, self.token_expired_count * 1.5)
                        self._push_keepalive(5); self._stop_event.wait(wait); self.consecutive_failures = 0
                    continue
                if status == 409: r.close(); self._push_keepalive(5); self._stop_event.wait(1.5); continue
                if status not in (200, 206):
                    self.consecutive_failures += 1; failure_count += 1
                    backoff = BACKOFF_SEQUENCE[min(failure_count - 1, len(BACKOFF_SEQUENCE) - 1)]
                    r.close()
                    if failure_count >= SESSION_RESET_FAIL_LIMIT:
                        self._session_reset('HTTP %d x%d' % (status, failure_count)); failure_count = 0
                    else:
                        self._push_keepalive(5); self._stop_event.wait(backoff)
                    continue

                self._watchdog_restart_flag.clear(); self.last_data_time = time.time()
                self.consecutive_failures = 0; self.token_expired_count = 0; failure_count = 0
                self.reconn.last_success_idx = strategy_idx; self.current_url = r.url
                self._next_fake_ip = random_ip(); self._next_ua = random.choice(_ALL_UA); self._real_bytes_sent = 0
                self._set_active_response(r)

                is_ts = any(x in r.url.lower() for x in ('.ts', '/ts', '.m2ts', '/chunk', '/segment'))
                chunk_sz = TS_CHUNK_SIZE if is_ts else self.chunk_sizer.size
                real_bytes = 0; conn_start = time.time()
                resync_buf = b''
                need_suture = self.tail_cache.has_live or self.tail_cache.has_backup
                suture_start = time.time()

                try:
                    for chunk in r.iter_content(chunk_size=chunk_sz):
                        if self._stop_event.is_set(): break
                        if not chunk:
                            if real_bytes == 0 and time.time() - conn_start > MANIFEST_FAIL_TIMEOUT: break
                            continue
                        real_bytes += len(chunk)
                        if not is_ts: chunk_sz = self.chunk_sizer.size

                        if need_suture:
                            resync_buf += chunk
                            self.last_data_time = time.time(); self._push_keepalive(1)
                            if len(resync_buf) > SLIDING_WINDOW_SIZE: resync_buf = resync_buf[-SLIDING_WINDOW_SIZE:]
                            
                            ok, remainder = self._try_suture(resync_buf)
                            time_spent = time.time() - suture_start

                            if ok:
                                resync_buf = b''; need_suture = False; self.has_initial_lock = False
                                self.residual_buffer = b''; self.tail_cache.suture_done(); self.tail_saver.reset()
                                self._process(remainder, my_gen)
                                
                            # TIMEOUT SEGURO: Só ativa depois de ler os 3MB inteiros.
                            # Evita loop e não trava o Android.
                            elif time_spent > SUTURE_MAX_TIME and len(resync_buf) >= SLIDING_WINDOW_SIZE:
                                xbmc.log('[SUTURA] Timeout seguro - Servidor iniciou fluxo limpo', xbmc.LOGWARNING)
                                need_suture = False; self.has_initial_lock = False; self.residual_buffer = b''
                                self.tail_cache.clear_live(); self.tail_saver.reset()
                                # Descarta o lixo. O fluxo novo entrará no _process e achará o 0x47 naturalmente.
                                resync_buf = b''
                        else:
                            self._process(chunk, my_gen)
                            self._real_bytes_sent += len(chunk)
                        if self._watchdog_restart_flag.is_set(): break

                except Exception as e:
                    self._prepare_for_reset('falha_stream')
                    self._set_active_response(None)
                    try: r.close()
                    except Exception: pass
                    self._session_reset('Stream: %s' % type(e).__name__); failure_count += 1; continue

                self._set_active_response(None); r.close()
                if real_bytes == 0 and not self._stop_event.is_set():
                    self.consecutive_failures += 1; failure_count += 1; self._push_keepalive(5)
                    if failure_count >= SESSION_RESET_FAIL_LIMIT:
                        self._session_reset('Zero bytes x%d' % failure_count); failure_count = 0

            except Exception as exc:
                self._set_active_response(None)
                if r:
                    try: r.close()
                    except Exception: pass
                self._prepare_for_reset('excecao')
                if self._stop_event.is_set(): break
                xbmc.log('[PRODUCER] Excecao: %s' % exc, xbmc.LOGERROR)
                self.consecutive_failures += 1; failure_count += 1
                if failure_count >= SESSION_RESET_FAIL_LIMIT:
                    self._session_reset('Exc x%d' % failure_count); failure_count = 0
                else:
                    backoff = BACKOFF_SEQUENCE[min(failure_count - 1, len(BACKOFF_SEQUENCE) - 1)]
                    self._push_keepalive(5); self._stop_event.wait(backoff)
        self._prepare_for_reset('fim')

    def generator(self):
        my_gen = self._get_gen()
        for _ in range(100): yield NULL_BLOCK
        if self.prebuf_ready.wait(timeout=PREBUFFER_TIMEOUT): pass
        else: xbmc.log('[PRE-BUFFER] Timeout', xbmc.LOGWARNING)
        next_kp = time.time() + KEEPALIVE_INTERVAL
        try:
            while True:
                if my_gen != self._get_gen(): break
                now = time.time()
                try:
                    chunk = self.data_queue.get(timeout=KEEPALIVE_INTERVAL)
                    yield chunk; next_kp = time.time() + KEEPALIVE_INTERVAL
                except queue.Empty:
                    if now >= next_kp:
                        try: yield self.emergency.get_nowait(); self._refill_emergency()
                        except queue.Empty: yield NULL_BLOCK
                        next_kp = time.time() + KEEPALIVE_INTERVAL
        except GeneratorExit: pass
        except Exception as e: xbmc.log('[ENGINE] Erro: %s' % e, xbmc.LOGERROR)
        finally:
            if my_gen == self._get_gen(): self._stop_event.set()

engine = XCodesEngine()

class TSProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        p = urlparse(self.path)
        if p.path != '/stream':
            self.send_response(404); self.end_headers(); return
        self.send_response(200)
        self.send_header('Cache-Control', 'no-cache'); self.send_header('Connection', 'keep-alive')
        self.send_header('Content-Type', 'video/mp2t'); self.end_headers()
        url_param = parse_qs(p.query).get('url', [None])[0]
        if not url_param: self._keep_alive_dummy(); return
        try:
            engine.start_stream(url_param)
            for chunk in engine.generator(): self.wfile.write(chunk); self.wfile.flush()
        except (ConnectionResetError, BrokenPipeError): pass
        except Exception: self._keep_alive_dummy()
    def _keep_alive_dummy(self):
        try:
            while True: self.wfile.write(NULL_BLOCK); self.wfile.flush(); time.sleep(0.05)
        except Exception: pass
    def log_message(self, fmt, *args): pass

# CORREÇÃO: Silencia erros de conexão fechada abruptamente (ConnectionResetError)
# que ocorrem quando o Kodi fecha o player e o socketserver lança exceção no log.
class SilentHTTPServer(HTTPServer):
    def handle_error(self, request, client_address):
        exc_type, exc_val, exc_tb = sys.exc_info()
        # Ignora erros comuns de rede quando o cliente (Kodi) desconecta
        if exc_type in (ConnectionResetError, BrokenPipeError, ConnectionAbortedError, OSError):
            return
        # Para outros erros, usa o comportamento padrão (logar)
        return super(SilentHTTPServer, self).handle_error(request, client_address)

class TSProxyServer(threading.Thread):
    def __init__(self, port):
        super(TSProxyServer, self).__init__(daemon=True)
        self.port = port
        # Usa o SilentHTTPServer ao invés do HTTPServer padrão
        self.server = SilentHTTPServer(('127.0.0.1', port), TSProxyHandler)
    def run(self):
        try: self.server.serve_forever()
        except Exception: pass
    def stop(self): self.server.shutdown(); self.server.server_close()

def get_free_port(start=50088):
    for port in range(start, start + 100):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try: s.bind(('127.0.0.1', port)); return port
        except OSError: pass
        finally:
            try: s.close()
            except Exception: pass
    return random.randint(50088, 50188)

proxy_server = None
def start_server():
    global proxy_server
    port = get_free_port(); proxy_server = TSProxyServer(port); proxy_server.start(); time.sleep(0.5); return port

SERVER_PORT = start_server()

def run_addon():
    action = _ARGS.get('action'); url = _ARGS.get('url')
    if action == 'play' and url:
        local = 'http://127.0.0.1:%d/stream?url=%s' % (SERVER_PORT, quote(url))
        li = xbmcgui.ListItem(path=local)
        li.setProperty('IsPlayable', 'true'); li.setMimeType('video/mp2t'); li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    else:
        li = xbmcgui.ListItem('[COLOR cyan]NEXUS X-CODES HYBRID %s[/COLOR]' % VERSION)
        li.setInfo('video', {'title': 'Nexus X-Codes Hybrid Proxy'})
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False); xbmcplugin.endOfDirectory(_HANDLE)

if __name__ == '__main__':
    run_addon()