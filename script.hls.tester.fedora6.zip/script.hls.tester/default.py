# -*- coding: utf-8 -*-

# ==============================================================================
# MÓDULOS PADRÃO E DE TERCEIROS
# ==============================================================================
import sys
import threading
import time
import random
import urllib.parse
from typing import Optional, Dict, Any
import requests
import m3u8
from werkzeug.serving import make_server
from requests.exceptions import RequestException, ConnectionError, HTTPError, Timeout

try:
    from flask import Flask, request, Response, stream_with_context
except ImportError:
    import xbmcgui
    xbmcgui.Dialog().ok("Erro de Dependência", "O addon 'script.module.flask' não foi encontrado. Por favor, instale-o para que o HLS Tester funcione.")
    sys.exit(1)

# ==============================================================================
# MÓDULOS KODI
# ==============================================================================
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# ==============================================================================
# --- CONFIGURAÇÕES E CONSTANTES ---
# ==============================================================================
CONNECTION_TIMEOUT = 5.0  # Reduced for faster retries
STREAM_TIMEOUT = 5.0  # Reduced for faster retries
DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1 MB
LIVE_MANIFEST_REFRESH_TTL = 3  # Reduced TTL for more frequent manifest refresh
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 10
MAX_RETRIES = 5  # Number of retry attempts
RETRY_BACKOFF_FACTOR = 0.5  # Exponential backoff factor
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
]

_SENSITIVE_HEADERS = {'Content-Length', 'Connection', 'Transfer-Encoding', 'Host'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}

# Dicionário para gerenciar sessões 'requests' por stream.
_stream_sessions: Dict[str, requests.Session] = {}
_session_lock = threading.Lock()
_proxy_port: Optional[int] = None
_server_thread: Optional[Any] = None
_playback_stopped_event = threading.Event()

# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================
def get_player_origin(url: str) -> str:
    parts = urllib.parse.urlparse(url)
    return f"{parts.scheme}://{parts.netloc}"

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith(('.m3u8', '.m3u')): return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'): return 'video/mp2t'
    if path.endswith('.aac'): return 'audio/aac'
    if path.endswith('.mp4'): return 'video/mp4'
    return 'application/octet-stream'

def get_random_headers(url: str, referer: Optional[str] = None) -> Dict[str, str]:
    """Generate randomized headers to mimic different clients."""
    origin = get_player_origin(url)
    return {
        'User-Agent': random.choice(USER_AGENTS),
        'Accept': '*/*',
        'Referer': referer if referer else origin,
        'Origin': origin,
        'Accept-Encoding': random.choice(['gzip, deflate', 'gzip', 'deflate']),
        'Accept-Language': random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9', 'es-ES,es;q=0.9']),
        'Connection': 'keep-alive',
    }

# ==============================================================================
# --- CLASSES DE REDE ---
# ==============================================================================
class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str, master_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url
        self.master_url_encoded = urllib.parse.quote_plus(master_url)

    def rewrite(self) -> str:
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                proxied_uri = f"{self.proxy_base_url}{urllib.parse.quote_plus(item.absolute_uri)}"
                item.uri = f"{proxied_uri}?master_url={self.master_url_encoded}"
            if hasattr(item, 'key') and item.key and item.key.uri and not item.key.uri.startswith("data:"):
                proxied_key_uri = f"{self.proxy_base_url}{urllib.parse.quote_plus(item.key.absolute_uri)}"
                item.key.uri = f"{proxied_key_uri}?master_url={self.master_url_encoded}"

        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        return LIVE_MANIFEST_REFRESH_TTL if self.is_live else 3600

# ==============================================================================
# --- APLICAÇÃO FLASK E ROTAS DO PROXY ---
# ==============================================================================
app = Flask(__name__)

def fetch_content(session: requests.Session, url: str, stream: bool = False, headers: Optional[Dict[str, str]] = None) -> requests.Response:
    """Fetch content with aggressive reconnection and header rotation."""
    attempt = 0
    while attempt < MAX_RETRIES:
        try:
            # Rotate headers for each attempt
            req_headers = headers if headers else get_random_headers(url)
            xbmc.log(f"[{ADDON_NAME}] Tentativa {attempt + 1}/{MAX_RETRIES} para {url} com User-Agent: {req_headers['User-Agent']}", xbmc.LOGDEBUG)
            resp = session.get(
                url,
                stream=stream,
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                allow_redirects=True,
                verify=False,
                headers=req_headers
            )
            resp.raise_for_status()
            return resp
        except (ConnectionError, HTTPError, Timeout) as e:
            attempt += 1
            if attempt >= MAX_RETRIES:
                xbmc.log(f"[{ADDON_NAME}] Falha após {MAX_RETRIES} tentativas para {url}: {e}", xbmc.LOGERROR)
                raise RequestException(f"Falha após {MAX_RETRIES} tentativas: {e}")
            sleep_time = RETRY_BACKOFF_FACTOR * (2 ** (attempt - 1))
            xbmc.log(f"[{ADDON_NAME}] Erro na tentativa {attempt} para {url}: {e}. Reattemptando em {sleep_time}s", xbmc.LOGWARNING)
            time.sleep(sleep_time)
        except RequestException as e:
            xbmc.log(f"[{ADDON_NAME}] Erro crítico na busca de conteúdo para {url}: {e}", xbmc.LOGERROR)
            raise

@app.route('/proxy/<path:encoded_url>', methods=['GET'])
def proxy_handler(encoded_url):
    decoded_url = urllib.parse.unquote_plus(encoded_url)
    master_url_encoded = request.args.get('master_url')
    
    if not master_url_encoded:
        return Response("Erro: 'master_url' não encontrado no request.", status=400)
    
    master_url = urllib.parse.unquote_plus(master_url_encoded)

    with _session_lock:
        session = _stream_sessions.get(master_url)

    if not session:
        xbmc.log(f"[{ADDON_NAME}] Sessão expirada ou não encontrada para {master_url}. URL solicitada: {decoded_url}", xbmc.LOGWARNING)
        return Response("Erro: Sessão de streaming expirada ou não encontrada.", status=404)
        
    is_manifest = decoded_url.lower().endswith(('.m3u8', '.m3u'))

    try:
        if is_manifest:
            resp = fetch_content(session, decoded_url, stream=False)
            content = resp.text
            proxy_base_url = f"{request.url_root}proxy/"
            rewriter = ManifestRewriter(content, decoded_url, proxy_base_url, master_url)
            rewritten_manifest = rewriter.rewrite()
            
            response = Response(rewritten_manifest, mimetype=safe_mime_type(decoded_url))
            response.headers['Cache-Control'] = f'max-age={rewriter.get_ttl()}'
            return response
        else:
            referer = request.headers.get('Referer', None)
            headers = get_random_headers(decoded_url, referer)
            
            resp = fetch_content(session, decoded_url, stream=True, headers=headers)
            
            def generate():
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        yield chunk
                    if _playback_stopped_event.is_set():
                        xbmc.log(f"[{ADDON_NAME}] Reprodução interrompida, encerrando streaming para {decoded_url}.", xbmc.LOGINFO)
                        break
            
            response = Response(stream_with_context(generate()), mimetype=resp.headers.get('Content-Type', safe_mime_type(decoded_url)))
            for header, value in resp.headers.items():
                if header.lower() not in _SENSITIVE_HEADERS_LOWER:
                    response.headers[header] = value

            return response

    except RequestException as e:
        xbmc.log(f"[{ADDON_NAME}] Erro ao processar a solicitação para {decoded_url}: {e}", xbmc.LOGERROR)
        return Response(f"Erro ao processar a solicitação para {decoded_url}: {e}", status=502)

# ==============================================================================
# --- SERVIDOR FLASK EM SEGUNDO PLANO ---
# ==============================================================================
class ServerThread(threading.Thread):
    def __init__(self, app: Flask, host: str, port: int):
        super().__init__()
        self.server = make_server(host, port, app, threaded=True)
        self.daemon = True

    def run(self):
        self.server.serve_forever()

    def shutdown(self):
        self.server.shutdown()

# ==============================================================================
# --- LÓGICA DO ADDON KODI ---
# ==============================================================================
class MyPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.url = None

    def onPlayBackStopped(self):
        xbmc.log(f"[{ADDON_NAME}] Reprodução interrompida.", xbmc.LOGINFO)
        _playback_stopped_event.set()
        if self.url:
            clear_all_sessions()
            self.url = None
        shutdown_proxy_server()

    def onPlayBackEnded(self):
        xbmc.log(f"[{ADDON_NAME}] Reprodução finalizada.", xbmc.LOGINFO)
        _playback_stopped_event.set()
        if self.url:
            clear_all_sessions()
            self.url = None
        shutdown_proxy_server()

_kodi_player = MyPlayer()

def clear_all_sessions():
    """Encerra e limpa todas as sessões de streaming ativas."""
    with _session_lock:
        if not _stream_sessions:
            return
        
        xbmc.log(f"[{ADDON_NAME}] Limpando {_stream_sessions.keys()} sessões antigas.", xbmc.LOGINFO)
        for session in _stream_sessions.values():
            session.close()
        _stream_sessions.clear()

def shutdown_proxy_server():
    global _server_thread, _proxy_port
    if _server_thread and _server_thread.is_alive():
        xbmc.log(f"[{ADDON_NAME}] Desligando o servidor proxy na porta {_proxy_port}.", xbmc.LOGINFO)
        _server_thread.shutdown()
        _server_thread.join(timeout=2)
        _server_thread = None
        _proxy_port = None
        xbmc.log(f"[{ADDON_NAME}] Servidor proxy desligado.", xbmc.LOGINFO)

def run_proxy_server():
    global _server_thread, _proxy_port

    if _server_thread and _server_thread.is_alive():
        xbmc.log(f"[{ADDON_NAME}] Servidor proxy já está rodando na porta {_proxy_port}. Reutilizando.", xbmc.LOGINFO)
        return True

    shutdown_proxy_server()

    for port_offset in range(MAX_PORT_ATTEMPTS):
        port = 58000 + port_offset
        try:
            xbmc.log(f"[{ADDON_NAME}] Tentando iniciar o servidor proxy na porta {port}...", xbmc.LOGINFO)
            server = ServerThread(app, PROXY_HOST, port)
            server.start()
            
            is_ready = False
            for _ in range(5):
                try:
                    time.sleep(1)
                    test_url = f"http://{PROXY_HOST}:{port}/"
                    requests.get(test_url, timeout=1, verify=False)
                    is_ready = True
                    break
                except (requests.exceptions.ConnectionError, requests.exceptions.ReadTimeout):
                    xbmc.log(f"[{ADDON_NAME}] Servidor na porta {port} ainda não responde. Tentando novamente...", xbmc.LOGWARNING)
                    continue
                except Exception as e:
                    xbmc.log(f"[{ADDON_NAME}] Erro inesperado ao verificar o servidor na porta {port}: {e}", xbmc.LOGERROR)
                    break
            
            if is_ready:
                _server_thread = server
                _proxy_port = port
                xbmc.log(f"[{ADDON_NAME}] Servidor proxy iniciado com sucesso em http://{PROXY_HOST}:{port}", xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f"[{ADDON_NAME}] Servidor na porta {port} falhou em responder após várias tentativas. Desligando e tentando a próxima porta.", xbmc.LOGWARNING)
                server.shutdown()
                server.join()
                continue

        except Exception as e:
            xbmc.log(f"[{ADDON_NAME}] Falha fatal ao usar a porta {port}: {e}", xbmc.LOGERROR)
            continue
    
    _proxy_port = None
    xbmcgui.Dialog().ok("Erro", "Não foi possível iniciar o servidor proxy local.")
    return False

def play_stream(handle, url, title):
    _playback_stopped_event.clear()
    shutdown_proxy_server()
    clear_all_sessions()

    if not run_proxy_server():
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(label='Erro de reprodução'))
        return

    port = _proxy_port
    
    session = requests.Session()
    session.headers.update(get_random_headers(url))
    
    with _session_lock:
        _stream_sessions[url] = session
    xbmc.log(f"[{ADDON_NAME}] Nova sessão criada para: {url}", xbmc.LOGINFO)

    encoded_url = urllib.parse.quote_plus(url)
    proxy_url = f"http://{PROXY_HOST}:{port}/proxy/{encoded_url}?master_url={encoded_url}"
    
    list_item = xbmcgui.ListItem(path=proxy_url, label=title)
    list_item.setInfo(type='Video', infoLabels={'title': title})
    list_item.setProperty('IsPlayable', 'true')
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    
    _kodi_player.url = proxy_url

    xbmcplugin.setResolvedUrl(handle, True, list_item)

def main_menu(handle):
    xbmcplugin.setPluginCategory(handle, 'HLS Streams de Teste')
    streams = [
        ("Live Stream Teste (CBS News)", "https://cbsn-us.cbsnstream.cbsnews.com/out/v1/55a8648e8f134e82a470f83d51c92926/master.m3u8"),
        ("VOD Teste (Apple)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8")
    ]
    for name, url in streams:
        li = xbmcgui.ListItem(label=name)
        li.setProperty('IsPlayable', 'true')
        plugin_url = f"{sys.argv[0]}?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
        xbmcplugin.addDirectoryItem(handle, plugin_url, li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

# ==============================================================================
# --- PONTO DE ENTRADA PRINCIPAL ---
# ==============================================================================
if __name__ == "__main__":
    try:
        handle = int(sys.argv[1])
        params_str = sys.argv[2][1:] if len(sys.argv) > 2 else ''
        params = dict(urllib.parse.parse_qsl(params_str))
        action = params.get('action')

        if not action:
            main_menu(handle)
        elif action == 'play':
            url_to_play = params.get('url')
            title = params.get('title', 'Stream')
            if url_to_play:
                play_stream(handle, url_to_play, title)
            else:
                xbmcgui.Dialog().ok("Erro", "URL de reprodução não fornecida.")
        
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Erro crítico no addon: {e}", xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro Inesperado", f"Ocorreu um erro: {e}")