# -*- coding: utf-8 -*-
# NEXUS X-CODES HYBRID V20.20
# Correções: Smart Token Renewal (Token Decay), Never-EOF Generator,
#            Starvation Loop Fix, Manifest Fail Recovery, LRU Tail Cache

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import collections
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, parse_qs
from requests.adapters import HTTPAdapter
from http.server import HTTPServer, BaseHTTPRequestHandler

import xbmc
import xbmcgui
import xbmcplugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS   = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

# ---- Tamanhos de buffer / chunk ---------------------------------------------
CHUNK_SIZE      = 128 * 1024
TS_CHUNK_SIZE   = 8   * 1024
FETCH_TIMEOUT   = 25
CONNECT_TIMEOUT = 8
QUEUE_SIZE      = 512

# ---- Sutura / Anti-Loop -----------------------------------------------------
TAIL_PRIMARY   = 32 * 1024
TAIL_SECONDARY = 8  * 1024
SEARCH_WINDOW  = 11  * 1024 * 1024

# ---- LRU Tail Cache ---------------------------------------------------------
LRU_TAIL_CAPACITY = 8

# ---- Anti-EOF / Keepalive ---------------------------------------------------
# O gerador NUNCA retorna EOF ao player. Sempre envia pacotes nulos se
# nao houver dados reais, impedindo o Kodi de encerrar a reproducao.
KEEPALIVE_PACKETS  = 7
KEEPALIVE_INTERVAL = 0.04   # ~25 Hz

# ---- Deteccao de falha de manifesto TS --------------------------------------
MANIFEST_FAIL_TIMEOUT  = 8
STARVATION_TIMEOUT     = 12
STARVATION_RESET_LIMIT = 2

# ---- Token Decay / Smart Token Renewal --------------------------------------
# Erros que indicam expiracao de token CDN: descarta URL resolvida e
# volta a entry_url para gerar nova sessao limpa.
TOKEN_EXPIRED_CODES = {401, 403, 404, 410}

# ---- Pacote TS Nulo ---------------------------------------------------------
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
TS_PACKET_SIZE = 188
NULL_BLOCK     = TS_NULL_PACKET * KEEPALIVE_PACKETS

# ---- User Agents ------------------------------------------------------------
_UA_BASE = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/121.0.0.0 TV Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20',
    'AppleCoreMedia/1.0.0.21G217 (iPhone; U; CPU OS 16_6 like Mac OS X)',
    'Lavf/59.27.100',
]
_UA_ROTATION = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone14,3; U; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/19A346 Safari/602.1',
    'Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 7.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.0 Chrome/122.0.0.0 TV Safari/537.36',
    'Kodi/20.5 (Windows NT 10.0; Win64; x64) App_Bitness/64 Version/20.5',
    'Lavf/60.3.100',
    'FFmpeg/6.0',
    'streamlink/6.0.0',
    'python-requests/2.31.0',
    'curl/8.4.0',
]
ALL_UA = _UA_BASE + _UA_ROTATION


# ---- Utilitarios ------------------------------------------------------------

def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in (10, 127, 169, 172, 192, 198, 203, 224):
            continue
        o2 = random.randint(0, 255)
        o3 = random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31:
            continue
        if o1 == 192 and o2 == 168:
            continue
        return '%d.%d.%d.%d' % (o1, o2, o3, o4)


def get_stealth_headers(target_url):
    """Gera headers ofuscados com UA e IP sempre novos a cada chamada."""
    fake_ip = random_ip()
    parsed  = urlparse(target_url)
    base    = '%s://%s/' % (parsed.scheme, parsed.netloc)
    ua      = random.choice(ALL_UA)

    if   'Android'   in ua: plat, mob = '"Android"', '?1'
    elif 'iPhone'    in ua or 'iPad' in ua: plat, mob = '"iOS"', '?1'
    elif 'SMART-TV'  in ua: plat, mob = '"SmartTV"', '?0'
    elif 'Windows'   in ua: plat, mob = '"Windows"', '?0'
    elif 'Macintosh' in ua: plat, mob = '"macOS"',   '?0'
    elif 'Linux'     in ua: plat, mob = '"Linux"',   '?0'
    else:                    plat, mob = '"Unknown"', '?0'

    cv = random.choice(['121', '122', '123', '124'])
    h = {
        'User-Agent':                ua,
        'Accept':                    '*/*',
        'Accept-Language':           random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9,en;q=0.8',
                                                    'es-ES,es;q=0.9', 'fr-FR,fr;q=0.9']),
        'Connection':                'keep-alive',
        'Cache-Control':             'no-cache',
        'Pragma':                    'no-cache',
        'Referer':                   base,
        'Origin':                    base.rstrip('/'),
        'DNT':                       str(random.randint(0, 1)),
        'X-Forwarded-For':           fake_ip,
        'X-Real-IP':                 fake_ip,
        'Client-IP':                 fake_ip,
        'Sec-CH-UA':                 '"Not;A=Brand";v="99","Google Chrome";v="%s","Chromium";v="%s"' % (cv, cv),
        'Sec-CH-UA-Mobile':          mob,
        'Sec-CH-UA-Platform':        plat,
        'Sec-Fetch-Site':            random.choice(['same-origin', 'cross-site', 'none']),
        'Sec-Fetch-Mode':            'cors',
        'Sec-Fetch-Dest':            'empty',
        'Upgrade-Insecure-Requests': '1',
        'TE':                        'trailers',
    }
    if random.random() < 0.4:
        h['X-Requested-With'] = 'XMLHttpRequest'
    return h


# ---- LRU Tail Cache ---------------------------------------------------------

class LRUTailCache(object):
    def __init__(self, capacity=LRU_TAIL_CAPACITY):
        self.capacity = capacity
        self._cache   = collections.OrderedDict()
        self._lock    = threading.Lock()

    def push(self, tail):
        if not tail:
            return
        with self._lock:
            self._cache[str(uuid.uuid4())] = tail
            if len(self._cache) > self.capacity:
                self._cache.popitem(last=False)
        xbmc.log('[LRU] snapshot=%d/%d tail=%dB' % (
            len(self._cache), self.capacity, len(tail)), xbmc.LOGINFO)

    def get_all(self):
        with self._lock:
            return list(reversed(list(self._cache.values())))

    def clear(self):
        with self._lock:
            self._cache.clear()


# ---- Sistema de Reconexao ---------------------------------------------------

class ReconnectionSystem(object):
    """
    6 estrategias de reconexao. Todas usam a entry_url para garantir
    Smart Token Renewal (nunca reutiliza URL CDN expirada).
    """

    def __init__(self):
        self.history          = []
        self.last_success_idx = None

    @staticmethod
    def _make_session():
        s = requests.Session()
        a = HTTPAdapter(pool_connections=50, pool_maxsize=100, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        return s

    @staticmethod
    def _do_get(session, url, extra=None, t_add=(0, 0)):
        h = get_stealth_headers(url)
        h.pop('Accept-Encoding', None)
        if extra:
            h.update(extra)
        xbmc.log('[RECON] UA=%s IP=%s' % (h['User-Agent'][:55], h['X-Forwarded-For']),
                 xbmc.LOGINFO)
        return session.get(
            url, headers=h, stream=True,
            timeout=(CONNECT_TIMEOUT + t_add[0], FETCH_TIMEOUT + t_add[1]),
            verify=False, allow_redirects=True)

    def _s0_fast(self, session, url):
        xbmc.log('[S0] Fast retry', xbmc.LOGINFO)
        return self._do_get(session, url, {'X-Request-Id': str(uuid.uuid4())})

    def _s1_backoff(self, session, url):
        xbmc.log('[S1] Progressive backoff', xbmc.LOGINFO)
        time.sleep(random.uniform(0.5, 1.5))
        return self._do_get(session, url, t_add=(5, 10))

    def _s2_new_session(self, session, url):
        xbmc.log('[S2] New session', xbmc.LOGINFO)
        ns = self._make_session()
        return self._do_get(ns, url, {'Accept-Encoding': 'identity'})

    def _s3_alt_proto(self, session, url):
        xbmc.log('[S3] Alt protocol', xbmc.LOGINFO)
        alt = (url.replace('https://', 'http://', 1)
               if url.startswith('https://')
               else url.replace('http://', 'https://', 1))
        return self._do_get(session, alt, {'Accept-Encoding': 'identity'})

    def _s4_new_ip(self, session, url):
        xbmc.log('[S4] New IP simulation', xbmc.LOGINFO)
        time.sleep(random.uniform(0.5, 2.0))
        return self._do_get(session, url, {
            'X-Device-ID':  str(uuid.uuid4()),
            'X-Session-ID': str(uuid.uuid4()),
        })

    def _s5_cache_bust(self, session, url):
        xbmc.log('[S5] Cache bust', xbmc.LOGINFO)
        sep  = '&' if '?' in url else '?'
        bust = '%s%s_t=%d&_r=%d' % (url, sep, int(time.time()), random.randint(1000, 9999))
        return self._do_get(session, bust, {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma':        'no-cache',
            'Expires':       '0',
        })

    _STRATEGIES = [_s0_fast, _s1_backoff, _s2_new_session,
                   _s3_alt_proto, _s4_new_ip, _s5_cache_bust]

    def next_idx(self):
        if self.last_success_idx is not None:
            return self.last_success_idx
        if not self.history:
            return 0
        used      = set(self.history[-3:])
        available = [i for i in range(len(self._STRATEGIES)) if i not in used]
        if available:
            return random.choice(available)
        counts = {}
        for s in self.history:
            counts[s] = counts.get(s, 0) + 1
        return min(counts, key=counts.get)

    def execute(self, idx, session, url):
        fn = self._STRATEGIES[idx % len(self._STRATEGIES)]
        return fn(self, session, url)


# ---- Engine Principal -------------------------------------------------------

class XCodesEngine(object):

    def __init__(self):
        # entry_url: URL original que nunca expira (portal de entrada).
        # Nunca reutilizamos a URL CDN resolvida — Token Decay prevention.
        self.entry_url    = None
        self.active_param = None

        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)
        self.stop_event = threading.Event()
        self._lock      = threading.Lock()

        # Estado de sutura
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False

        # Contadores
        self.consecutive_failures = 0
        self.reconnection_count   = 0
        self.last_data_time       = 0.0
        self.starvation_counter   = 0
        self.token_expired_count  = 0

        self.session = None

        self.lru    = LRUTailCache()
        self.reconn = ReconnectionSystem()

        self.emergency = queue.Queue(maxsize=200)
        self._refill_emergency()

        self.producer_thread = None

    # -- Buffers / Keepalive --------------------------------------------------

    def _refill_emergency(self):
        for _ in range(200):
            try:
                self.emergency.put_nowait(NULL_BLOCK)
            except queue.Full:
                break

    def _push_keepalive(self, n=8):
        for _ in range(n):
            try:
                self.data_queue.put_nowait(NULL_BLOCK)
            except queue.Full:
                break

    # -- Sessao HTTP ----------------------------------------------------------

    def _new_session(self):
        if self.session:
            try:
                self.session.close()
            except Exception:
                pass
        s = requests.Session()
        a = HTTPAdapter(pool_connections=50, pool_maxsize=100, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        self.session = s
        self.reconnection_count += 1
        if self.reconnection_count % 5 == 0:
            gc.collect()

    # -- Reset ----------------------------------------------------------------

    def _soft_reset(self):
        """Reset leve: salva tail no LRU, limpa estado de stream, nova sessao."""
        if self.stream_tail:
            self.lru.push(self.stream_tail)
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False
        with self.data_queue.mutex:
            self.data_queue.queue.clear()
        self._new_session()
        xbmc.log('[X-CODES] Soft reset — LRU=%d snapshots' % len(self.lru.get_all()),
                 xbmc.LOGINFO)

    def _hard_reset(self):
        """Reset total: limpa tudo incluindo LRU (troca de canal)."""
        self.lru.clear()
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False
        with self.data_queue.mutex:
            self.data_queue.queue.clear()
        self._new_session()

    # -- Processamento de chunk -----------------------------------------------

    def _process(self, raw):
        if not raw:
            return
        batch = self.residual_buffer + raw

        if not self.has_initial_lock:
            idx = batch.find(b'\x47')
            if idx == -1:
                self.residual_buffer = batch[-(TS_PACKET_SIZE * 2):]
                return
            batch = batch[idx:]
            self.has_initial_lock = True

        n = len(batch) // TS_PACKET_SIZE
        if n == 0:
            self.residual_buffer = batch
            return

        used                 = n * TS_PACKET_SIZE
        payload              = batch[:used]
        self.residual_buffer = batch[used:]

        self.stream_tail += payload
        if len(self.stream_tail) > TAIL_PRIMARY + TAIL_SECONDARY:
            self.stream_tail = self.stream_tail[-TAIL_PRIMARY:]

        self.last_data_time     = time.time()
        self.starvation_counter = 0

        try:
            self.data_queue.put_nowait(payload)
        except queue.Full:
            while not self.data_queue.empty():
                try:
                    self.data_queue.get_nowait()
                except Exception:
                    break
            try:
                self.data_queue.put_nowait(payload)
            except Exception:
                pass

    # -- Sutura LRU -----------------------------------------------------------

    def _try_suture(self, buf):
        """
        Tenta encontrar ponto de sutura em buf.
        Testa tail atual primeiro, depois cada snapshot LRU.
        Retorna (True, dados_apos_sutura) ou (False, b'').
        """
        candidates = []
        if self.stream_tail:
            candidates.append(('atual', self.stream_tail))
        for i, t in enumerate(self.lru.get_all()):
            candidates.append(('LRU#%d' % (i + 1), t))

        for label, tail in candidates:
            primary = tail[-TAIL_PRIMARY:] if len(tail) >= TAIL_PRIMARY else tail
            if primary and primary in buf:
                idx  = buf.rfind(primary)
                skip = idx + len(primary)
                xbmc.log('[SUTURA] Perfeita via %s pulando %dB' % (label, skip), xbmc.LOGINFO)
                return True, buf[skip:]

            secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
            if secondary and len(buf) > TAIL_SECONDARY + 188 * 50 and secondary in buf:
                idx  = buf.rfind(secondary)
                skip = idx + len(secondary)
                xbmc.log('[SUTURA] Rapida via %s pulando %dB' % (label, skip), xbmc.LOGINFO)
                return True, buf[skip:]

        return False, b''

    # -- Start ----------------------------------------------------------------

    def start_stream(self, url_param):
        urls = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls:
            raise ValueError('Nenhuma URL fornecida')
        entry = urls[0]

        with self._lock:
            if self.active_param == url_param:
                xbmc.log('[X-CODES] Reutilizando sessao', xbmc.LOGINFO)
                need_restart = self.stop_event.is_set() or (
                    self.producer_thread is not None and
                    not self.producer_thread.is_alive())
                if need_restart:
                    self._do_restart(entry, keep_lru=True)
            else:
                self._stop_producer()
                self._hard_reset()
                self.active_param            = url_param
                self.entry_url               = entry
                self.consecutive_failures    = 0
                self.reconnection_count      = 0
                self.last_data_time          = time.time()
                self.starvation_counter      = 0
                self.token_expired_count     = 0
                self.reconn.history          = []
                self.reconn.last_success_idx = None
                self._refill_emergency()
                self._start_producer()
                xbmc.log('[X-CODES] Iniciando Motor: %s' % entry[:80], xbmc.LOGINFO)

    def _stop_producer(self):
        self.stop_event.set()
        if self.producer_thread and self.producer_thread.is_alive():
            self.producer_thread.join(timeout=4)

    def _start_producer(self):
        self.stop_event.clear()
        self.producer_thread = threading.Thread(
            target=self._producer_loop, daemon=True)
        self.producer_thread.start()

    def _do_restart(self, entry, keep_lru=True):
        self.stop_event.clear()
        if keep_lru:
            self._soft_reset()
        else:
            self._hard_reset()
        self.entry_url               = entry
        self.consecutive_failures    = 0
        self.starvation_counter      = 0
        self.token_expired_count     = 0
        self.last_data_time          = time.time()
        self._start_producer()

    # -- Producer Loop --------------------------------------------------------

    def _producer_loop(self):
        """
        Loop principal do produtor de bytes.

        Politica Never-Crash:
        - 401/403/404/410: Token Decay detectado. Descarta URL resolvida,
          volta a entry_url com nova sessao e novo UA/IP. Nunca fica em
          loop infinito de 403.
        - Falha HTTP ou excecao: reconexao com estrategia rotativa.
        - Starvation: soft_reset + reconexao via entry_url.
        - Manifesto vazio (200 sem bytes): reconexao imediata.
        - O gerador NUNCA recebe EOF — keepalive continuo via NULL_BLOCK.
        """
        strategy_idx = 0

        while not self.stop_event.is_set():
            r = None
            try:
                # ---- Starvation check ---------------------------------------
                if self.last_data_time > 0:
                    elapsed = time.time() - self.last_data_time
                    if elapsed > STARVATION_TIMEOUT:
                        self.starvation_counter += 1
                        xbmc.log('[STARVATION] %.1fs sem dados (counter=%d)' % (
                            elapsed, self.starvation_counter), xbmc.LOGWARNING)

                        # Backoff progressivo a cada STARVATION_RESET_LIMIT ciclos
                        if self.starvation_counter % STARVATION_RESET_LIMIT == 0:
                            backoff = min(15, (self.starvation_counter //
                                               STARVATION_RESET_LIMIT) * 3)
                            xbmc.log('[STARVATION] Backoff %ds antes de reconectar' % backoff,
                                     xbmc.LOGWARNING)
                            self._push_keepalive(int(backoff / KEEPALIVE_INTERVAL))
                            time.sleep(backoff)

                        # Soft reset e forca reconexao
                        self._soft_reset()
                        self.consecutive_failures = max(self.consecutive_failures, 1)
                        self.last_data_time       = time.time()
                        xbmc.log('[STARVATION] Soft reset — reconectando', xbmc.LOGINFO)

                # ---- URL alvo: sempre entry_url (nunca URL CDN expirada) -----
                target_url = self.entry_url

                # ---- Seleciona estrategia de reconexao ----------------------
                needs_reconn = (self.consecutive_failures >= 1 or
                                self.token_expired_count >= 1)

                if needs_reconn:
                    strategy_idx = self.reconn.next_idx()
                    xbmc.log('[RECONEXAO] S%d falhas=%d token_exp=%d' % (
                        strategy_idx, self.consecutive_failures,
                        self.token_expired_count), xbmc.LOGINFO)
                    self.reconn.history.append(strategy_idx)
                    # Salva tail antes de resetar estado de sutura
                    if self.stream_tail:
                        self.lru.push(self.stream_tail)
                    self.stream_tail      = b''
                    self.residual_buffer  = b''
                    self.has_initial_lock = False
                    self._new_session()
                    r = self.reconn.execute(strategy_idx, self.session, target_url)
                else:
                    # Primeira conexao
                    h = get_stealth_headers(target_url)
                    h.pop('Accept-Encoding', None)
                    xbmc.log('[X-CODES] Primeira conexao: UA=%s' % h['User-Agent'][:55],
                             xbmc.LOGINFO)
                    r = self.session.get(
                        target_url, headers=h, stream=True,
                        timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT),
                        verify=False, allow_redirects=True)

                # ---- Tratamento de status HTTP ------------------------------
                if r is None:
                    xbmc.log('[X-CODES] Resposta nula', xbmc.LOGWARNING)
                    self.consecutive_failures += 1
                    self._push_keepalive(10)
                    time.sleep(1)
                    continue

                status = r.status_code

                # Token Decay / Smart Token Renewal
                if status in TOKEN_EXPIRED_CODES:
                    self.token_expired_count += 1
                    xbmc.log('[TOKEN DECAY] HTTP %d — renovando token #%d' % (
                        status, self.token_expired_count), xbmc.LOGWARNING)
                    r.close()
                    wait = min(8.0, self.token_expired_count * 1.5)
                    self._push_keepalive(int(wait / KEEPALIVE_INTERVAL) + 5)
                    time.sleep(wait)
                    # Nao acumula consecutive_failures para token decay
                    self.consecutive_failures = 0
                    continue

                if status == 409:
                    xbmc.log('[X-CODES] HTTP 409 — keepalive + espera', xbmc.LOGWARNING)
                    r.close()
                    self._push_keepalive(20)
                    time.sleep(1.5 + random.uniform(0, 1))
                    continue

                if status not in (200, 206):
                    self.consecutive_failures += 1
                    backoff = min(10, 2 ** min(self.consecutive_failures - 1, 3))
                    xbmc.log('[X-CODES] HTTP %d — backoff %ds' % (status, backoff),
                             xbmc.LOGERROR)
                    r.close()
                    self._push_keepalive(10)
                    time.sleep(backoff + random.uniform(0, 1))
                    continue

                # ---- Conexao bem-sucedida ------------------------------------
                self.consecutive_failures = 0
                self.token_expired_count  = 0
                self.reconn.last_success_idx = strategy_idx
                xbmc.log('[X-CODES] Conectado: %s' % r.url[:80], xbmc.LOGINFO)

                is_ts = any(x in r.url.lower()
                            for x in ('.ts', '/ts', '.m2ts', '/chunk', '/segment'))
                chunk_sz = TS_CHUNK_SIZE if is_ts else CHUNK_SIZE

                resync_buf  = b''
                need_suture = bool(self.stream_tail) or bool(self.lru.get_all())
                real_bytes  = 0
                conn_start  = time.time()

                for chunk in r.iter_content(chunk_size=chunk_sz):
                    if self.stop_event.is_set():
                        break

                    if not chunk:
                        # Manifesto vazio: sem bytes reais apos timeout
                        if real_bytes == 0 and time.time() - conn_start > MANIFEST_FAIL_TIMEOUT:
                            xbmc.log('[MANIFEST FAIL] Sem bytes reais — reconectando',
                                     xbmc.LOGERROR)
                            break
                        continue

                    real_bytes += 1

                    if need_suture:
                        resync_buf += chunk
                        if len(resync_buf) > SEARCH_WINDOW:
                            resync_buf = resync_buf[-(SEARCH_WINDOW // 2):]

                        ok, remainder = self._try_suture(resync_buf)
                        if ok:
                            resync_buf          = b''
                            need_suture         = False
                            self.has_initial_lock = False
                            self.residual_buffer  = b''
                            self._process(remainder)
                        elif len(resync_buf) >= SEARCH_WINDOW:
                            # Janela esgotada sem match — inicia fluxo novo
                            xbmc.log('[SUTURA] Janela maxima sem match — fluxo novo',
                                     xbmc.LOGWARNING)
                            need_suture         = False
                            self.has_initial_lock = False
                            self.residual_buffer  = b''
                            self._process(resync_buf)
                            resync_buf = b''
                    else:
                        self._process(chunk)

                # Fim do iter_content
                if real_bytes == 0 and not self.stop_event.is_set():
                    xbmc.log('[MANIFEST FAIL] Stream encerrou sem dados', xbmc.LOGWARNING)
                    self.consecutive_failures += 1
                    self._push_keepalive(8)

                r.close()

            except Exception as exc:
                xbmc.log('[X-CODES] Excecao: %s' % exc, xbmc.LOGERROR)
                if r:
                    try:
                        r.close()
                    except Exception:
                        pass

                err = str(exc).lower()
                if 'ssl' in err or 'cipher' in err:
                    for fb in range(len(ReconnectionSystem._STRATEGIES)):
                        try:
                            xbmc.log('[SSL FALLBACK] S%d' % fb, xbmc.LOGWARNING)
                            res = self.reconn.execute(fb, self.session, self.entry_url)
                            if res and res.status_code in (200, 206):
                                xbmc.log('[SSL FALLBACK] S%d OK' % fb, xbmc.LOGINFO)
                                for ch in res.iter_content(chunk_size=TS_CHUNK_SIZE):
                                    if self.stop_event.is_set():
                                        break
                                    if ch:
                                        self._process(ch)
                                res.close()
                                break
                        except Exception:
                            continue

                self.consecutive_failures += 1
                backoff = min(12, 2 ** min(self.consecutive_failures - 1, 3))
                xbmc.log('[X-CODES] Backoff %ds' % backoff, xbmc.LOGERROR)
                self._push_keepalive(int(backoff / KEEPALIVE_INTERVAL))
                time.sleep(backoff + random.uniform(0, 1))

    # -- Gerador nativo -------------------------------------------------------

    def generator(self):
        """
        Gerador que NUNCA retorna EOF ao player (Never-EOF Policy).

        Enquanto o stop_event nao for sinalizado pelo fechamento do player,
        o gerador continua indefinidamente. Quando nao ha dados reais na fila,
        envia pacotes TS nulos para manter o demuxer do Kodi ativo.

        Isso impede o 'eof reading from demuxer' que fechava a reproducao.
        GeneratorExit e capturado limpamente para evitar RuntimeError.
        """
        xbmc.log('[X-CODES] Gerador Iniciado', xbmc.LOGINFO)

        # Bloco inicial para o demuxer nao receber EOF enquanto conecta
        for _ in range(100):
            yield NULL_BLOCK

        next_kp = time.time() + KEEPALIVE_INTERVAL

        try:
            while True:
                # Encerra APENAS se stop_event sinalizado E fila vazia
                if self.stop_event.is_set() and self.data_queue.empty():
                    break

                now = time.time()
                try:
                    chunk = self.data_queue.get(timeout=KEEPALIVE_INTERVAL)
                    yield chunk
                    next_kp = time.time() + KEEPALIVE_INTERVAL
                except queue.Empty:
                    if now >= next_kp:
                        try:
                            yield self.emergency.get_nowait()
                            self._refill_emergency()
                        except queue.Empty:
                            yield NULL_BLOCK
                        next_kp = time.time() + KEEPALIVE_INTERVAL

        except GeneratorExit:
            xbmc.log('[X-CODES] GeneratorExit — gerador encerrado limpo', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[X-CODES] Erro no gerador: %s' % e, xbmc.LOGERROR)
        finally:
            self.stop_event.set()
            xbmc.log('[X-CODES] Sessao finalizada', xbmc.LOGINFO)


# ---- Instância Global do Motor ----------------------------------------------
engine = XCodesEngine()


# ---- HTTP Server / Class Wrapper --------------------------------------------

class TSProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        
        if parsed_path.path == '/stream':
            query = parse_qs(parsed_path.query)
            url_param = query.get('url', [None])[0]

            if not url_param:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b'URL nao fornecida')
                return

            engine.start_stream(url_param)

            # Enviando cabeçalhos de resposta HTTP
            self.send_response(200)
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'keep-alive')
            self.send_header('Content-Type', 'video/mp2t')
            self.end_headers()

            try:
                for chunk in engine.generator():
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except (ConnectionResetError, BrokenPipeError) as e:
                xbmc.log('[X-CODES] Cliente desconectou: %s' % e, xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log('[X-CODES] Erro handler: %s' % e, xbmc.LOGERROR)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # Evita flood no console do servidor http
        pass


class TSProxyServer(threading.Thread):
    """
    Classe Wrapper para inicializar o Proxy Server de forma importável.
    """
    def __init__(self, port):
        super(TSProxyServer, self).__init__(daemon=True)
        self.port = port
        self.server = HTTPServer(('127.0.0.1', self.port), TSProxyHandler)

    def run(self):
        xbmc.log('[X-CODES] Servidor HTTP iniciado na porta %d' % self.port, xbmc.LOGINFO)
        try:
            self.server.serve_forever()
        except Exception as e:
            xbmc.log('[X-CODES] Erro no servidor: %s' % e, xbmc.LOGERROR)

    def stop(self):
        self.server.shutdown()
        self.server.server_close()


# ---- Server Start Logic -----------------------------------------------------

def get_free_port(start=50088):
    for port in range(start, start + 100):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            return port
        except OSError:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    return random.randint(50088, 50188)

# Variável para referenciar o servidor ativo caso seja necessário
proxy_server = None

def start_server():
    global proxy_server
    port = get_free_port()
    proxy_server = TSProxyServer(port)
    proxy_server.start()
    time.sleep(0.7)
    return port

SERVER_PORT = start_server()


# ---- Addon Entry Point ------------------------------------------------------

def run_addon():
    action = _ARGS.get('action')
    url    = _ARGS.get('url')

    if action == 'play' and url:
        local = 'http://127.0.0.1:%d/stream?url=%s' % (SERVER_PORT, quote(url))
        li = xbmcgui.ListItem(path=local)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    else:
        li = xbmcgui.ListItem('[COLOR cyan]NEXUS X-CODES HYBRID V20.20[/COLOR]')
        li.setInfo('video', {'title': 'Nexus X-Codes Hybrid Proxy'})
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(_HANDLE)


if __name__ == '__main__':
    run_addon()