# -*- coding: utf-8 -*-
# NEXUS X-CODES HYBRID V20.58 (Anti-LRU-Loop + Live-Edge Suture + Grinch Fix)
#
# Root-cause V20.57 -> V20.58:
#   A LRU acumulava snapshots de tails de TODAS as tentativas de conexao (inclusive
#   as que receberam HTTP 406 e foram descartadas). Ao reconectar, _try_suture()
#   vasculhava LRU#1..#8 e encontrava match em tails ANTIGAS ja enviadas ao Kodi,
#   fazendo skip para bytes ATRAS do live-edge -> loop de video + Grinch verde.
#
#   Evidencia nos logs:
#     [LRU] snapshot=2/8 tail=32768B   <- acumulando tails de conexoes com 406
#     [SUTURA] Perfeita via LRU#2 pulando 2996532B  <- bytes ja reproduzidos!
#     [SUTURA] Perfeita via LRU#3 pulando 523768B   <- idem
#     ActiveAE - large audio sync error: -8759ms     <- desynced por rewind
#
# Correcoes V20.58:
#   1. LRU_TAIL_CAPACITY = 1  (guarda somente a tail da ultima sessao ativa)
#   2. stream_tail so vai para LRU se _real_bytes_sent > 0 (stream entregou dados)
#   3. Apos sutura bem-sucedida: lru.clear() imediato (evita reuso de tail velha)
#   4. Apos sutura timeout (fluxo forcado): lru.clear() tambem
#   5. tail na LRU e substituida a cada nova conexao bem-sucedida (nao acumula)
#   6. Session reset preserva LRU somente se havia bytes reais entregues

import sys
import threading
import time
import gc
import queue
import random
import socket
import uuid
import collections
import urllib3
import requests
from urllib.parse import parse_qsl, quote, urlparse, parse_qs
from requests.adapters import HTTPAdapter
from http.server import HTTPServer, BaseHTTPRequestHandler

import xbmc
import xbmcgui
import xbmcplugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_ARGS   = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

VERSION = 'V20.58'

# ---- Constantes -------------------------------------------------------------
TS_PACKET_SIZE = 188
TS_SYNC_BYTE   = 0x47
TS_NULL_PACKET = b'\x47\x1F\xFF\x10' + b'\xFF' * 184
NULL_BLOCK     = TS_NULL_PACKET * 7

CHUNK_SIZE_MIN  = 32  * 1024
CHUNK_SIZE_MAX  = 512 * 1024
CHUNK_SIZE_DEF  = 128 * 1024
TS_CHUNK_SIZE   = 8   * 1024

FETCH_TIMEOUT   = 25
CONNECT_TIMEOUT = 8
QUEUE_SIZE      = 512

PREBUFFER_BYTES   = 188 * 1024
PREBUFFER_TIMEOUT = 6.0

KEEPALIVE_INTERVAL = 0.04

WATCHDOG_INTERVAL  = 3.0
STARVATION_TIMEOUT = 12.0
STARVATION_RESET_LIMIT = 2

TOKEN_EXPIRED_CODES   = {401, 403, 404, 410}
MANIFEST_FAIL_TIMEOUT = 8

BACKOFF_SEQUENCE = [0.5, 1.0, 2.0, 5.0, 10.0, 15.0]

# ---- Session Reset ----------------------------------------------------------
# Numero maximo de falhas de conexao antes de acionar reset total de sessao
SESSION_RESET_FAIL_LIMIT   = 3
# Codigos HTTP que indicam token expirado/invalido -> aciona reset de sessao
SESSION_RESET_HTTP_CODES   = {401, 403, 404, 410}
# Tempo maximo de espera apos reset antes de tentar reconexao
SESSION_RESET_BACKOFF      = 2.0

# ---- Sutura / Anti-Loop / LRU -----------------------------------------------
TAIL_PRIMARY      = 32 * 1024
TAIL_SECONDARY    = 8  * 1024
SEARCH_WINDOW     = 7 * 1024 * 1024
SUTURE_MAX_TIME   = 4.0
# LRU com capacidade 1: guarda SOMENTE a tail da ultima sessao que entregou dados reais.
# Capacidade > 1 causava loop de video: sutura encontrava match em tails antigas ja
# reproduzidas e fazia skip para bytes atras do live-edge -> Grinch + audio desync.
LRU_TAIL_CAPACITY = 1

# ---- User Agents ------------------------------------------------------------
_ALL_UA = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 7.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.0 Chrome/122.0.0.0 TV Safari/537.36',
    'ExoPlayer/2.18.1 (Linux; Android 12) ExoPlayerLib/2.18.1',
    'VLC/3.0.20 LibVLC/3.0.20',
    'Lavf/60.3.100',
    'Kodi/20.5 (Windows NT 10.0; Win64; x64) App_Bitness/64 Version/20.5',
]


def random_ip():
    while True:
        o1 = random.randint(1, 223)
        if o1 in (10, 127, 169, 172, 192, 198, 203, 224):
            continue
        o2 = random.randint(0, 255)
        o3 = random.randint(0, 255)
        o4 = random.randint(1, 254)
        if o1 == 172 and 16 <= o2 <= 31:
            continue
        if o1 == 192 and o2 == 168:
            continue
        return '%d.%d.%d.%d' % (o1, o2, o3, o4)


def get_stealth_headers(target_url):
    fake_ip = random_ip()
    parsed  = urlparse(target_url)
    base    = '%s://%s/' % (parsed.scheme, parsed.netloc)
    ua      = random.choice(_ALL_UA)
    cv      = random.choice(['121', '122', '123', '124'])

    if   'Android'   in ua: plat, mob = '"Android"', '?1'
    elif 'iPhone'    in ua or 'iPad' in ua: plat, mob = '"iOS"', '?1'
    elif 'SMART-TV'  in ua: plat, mob = '"SmartTV"', '?0'
    elif 'Windows'   in ua: plat, mob = '"Windows"', '?0'
    elif 'Macintosh' in ua: plat, mob = '"macOS"',   '?0'
    elif 'Linux'     in ua: plat, mob = '"Linux"',   '?0'
    else:                    plat, mob = '"Unknown"', '?0'

    h = {
        'User-Agent':                ua,
        'Accept':                    '*/*',
        'Accept-Language':           random.choice(['en-US,en;q=0.9',
                                                    'pt-BR,pt;q=0.9,en;q=0.8']),
        'Connection':                'keep-alive',
        'Cache-Control':             'no-cache',
        'Pragma':                    'no-cache',
        'Referer':                   base,
        'Origin':                    base.rstrip('/'),
        'DNT':                       str(random.randint(0, 1)),
        'X-Forwarded-For':           fake_ip,
        'X-Real-IP':                 fake_ip,
        'Client-IP':                 fake_ip,
        'Sec-CH-UA':                 '"Not;A=Brand";v="99","Google Chrome";v="%s","Chromium";v="%s"' % (cv, cv),
        'Sec-CH-UA-Mobile':          mob,
        'Sec-CH-UA-Platform':        plat,
        'Sec-Fetch-Site':            'cross-site',
        'Sec-Fetch-Mode':            'cors',
        'Sec-Fetch-Dest':            'empty',
        'Upgrade-Insecure-Requests': '1',
    }
    return h


# ---- Reconexao --------------------------------------------------------------

class ReconnectionSystem(object):
    def __init__(self):
        self.history          = []
        self.last_success_idx = None

    @staticmethod
    def _make_session():
        s = requests.Session()
        a = HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        return s

    @staticmethod
    def _do_get(session, url, extra=None, t_add=(0, 0)):
        h = get_stealth_headers(url)
        h.pop('Accept-Encoding', None)
        if extra:
            h.update(extra)
        
        xbmc.log('[ROTATE] IP Gerado: %s | UA: %s...' % (
            h.get('X-Forwarded-For', 'N/A'), 
            h.get('User-Agent', '')[:35]), xbmc.LOGINFO)

        return session.get(
            url, headers=h, stream=True,
            timeout=(CONNECT_TIMEOUT + t_add[0], FETCH_TIMEOUT + t_add[1]),
            verify=False, allow_redirects=True)

    def _s0_fast(self, s, url):
        xbmc.log('[S0] fast', xbmc.LOGINFO)
        return self._do_get(s, url, {'X-Request-Id': str(uuid.uuid4())})

    def _s1_backoff(self, s, url):
        xbmc.log('[S1] backoff', xbmc.LOGINFO)
        time.sleep(random.uniform(0.5, 1.5))
        return self._do_get(s, url, t_add=(5, 10))

    def _s2_new_session(self, s, url):
        xbmc.log('[S2] new session', xbmc.LOGINFO)
        return self._do_get(self._make_session(), url,
                            {'Accept-Encoding': 'identity'})

    def _s3_alt_proto(self, s, url):
        xbmc.log('[S3] alt proto', xbmc.LOGINFO)
        alt = (url.replace('https://', 'http://', 1)
               if url.startswith('https://')
               else url.replace('http://', 'https://', 1))
        return self._do_get(s, alt, {'Accept-Encoding': 'identity'})

    def _s4_new_ip(self, s, url):
        xbmc.log('[S4] new ip', xbmc.LOGINFO)
        time.sleep(random.uniform(0.5, 2.0))
        return self._do_get(s, url, {'X-Device-ID': str(uuid.uuid4())})

    def _s5_cache_bust(self, s, url):
        xbmc.log('[S5] cache bust', xbmc.LOGINFO)
        sep  = '&' if '?' in url else '?'
        bust = '%s%s_t=%d' % (url, sep, int(time.time()))
        return self._do_get(s, bust, {
            'Cache-Control': 'no-cache, no-store',
            'Pragma': 'no-cache',
        })

    _STRATEGIES = [_s0_fast, _s1_backoff, _s2_new_session,
                   _s3_alt_proto, _s4_new_ip, _s5_cache_bust]

    def next_idx(self):
        if self.last_success_idx is not None:
            return self.last_success_idx
        if not self.history:
            return 0
        used      = set(self.history[-3:])
        available = [i for i in range(len(self._STRATEGIES)) if i not in used]
        if available:
            return random.choice(available)
        counts = {}
        for x in self.history:
            counts[x] = counts.get(x, 0) + 1
        return min(counts, key=counts.get)

    def execute(self, idx, session, url):
        return self._STRATEGIES[idx % len(self._STRATEGIES)](self, session, url)


# ---- Chunk Size Adaptativo --------------------------------------------------

class AdaptiveChunkSizer(object):
    def __init__(self):
        self._size   = CHUNK_SIZE_DEF
        self._bytes  = 0
        self._t_last = time.time()
        self._lock   = threading.Lock()

    def update(self, n):
        with self._lock:
            self._bytes += n
            now = time.time()
            dt  = now - self._t_last
            if dt >= 2.0:
                rate = self._bytes / dt
                if   rate > 4 * 1024 * 1024: self._size = CHUNK_SIZE_MAX
                elif rate > 1 * 1024 * 1024: self._size = 256 * 1024
                elif rate > 256 * 1024:       self._size = 128 * 1024
                else:                         self._size = CHUNK_SIZE_MIN
                xbmc.log('[ADAPTIVE] %.1fKB/s chunk=%dKB' % (
                    rate / 1024, self._size // 1024), xbmc.LOGINFO)
                self._bytes  = 0
                self._t_last = now

    @property
    def size(self):
        with self._lock:
            return self._size


# ---- LRU Tail Cache ---------------------------------------------------------

class LRUTailCache(object):
    def __init__(self, capacity=LRU_TAIL_CAPACITY):
        self.capacity = capacity
        self._cache   = collections.OrderedDict()
        self._lock    = threading.Lock()

    def push(self, tail):
        if not tail:
            return
        with self._lock:
            self._cache[str(uuid.uuid4())] = tail
            if len(self._cache) > self.capacity:
                self._cache.popitem(last=False)
        xbmc.log('[LRU] snapshot=%d/%d tail=%dB' % (
            len(self._cache), self.capacity, len(tail)), xbmc.LOGINFO)

    def get_all(self):
        with self._lock:
            return list(reversed(list(self._cache.values())))

    def clear(self):
        with self._lock:
            self._cache.clear()


# ---- Engine Principal -------------------------------------------------------

class XCodesEngine(object):

    def __init__(self):
        self.entry_url    = None
        self.current_url  = None
        self.base_url     = None
        self.active_param = None

        self.data_queue = queue.Queue(maxsize=QUEUE_SIZE)

        self._stop_event = threading.Event()
        self.prebuf_ready  = threading.Event()
        self._engine_lock  = threading.Lock()

        self._gen      = 0
        self._gen_lock = threading.Lock()

        self.session = None
        self._active_response      = None
        self._active_response_lock = threading.Lock()

        self.reconn      = ReconnectionSystem()
        self.chunk_sizer = AdaptiveChunkSizer()

        # Estado de sutura
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False
        self.lru              = LRUTailCache()

        self.emergency = queue.Queue(maxsize=200)
        self._refill_emergency()

        self._producer_thread = None
        self._watchdog_thread = None

        self._prebuf_bytes        = 0
        self.last_data_time       = 0.0
        self.starvation_counter   = 0
        self.consecutive_failures = 0
        self.token_expired_count  = 0
        self.reconnection_count   = 0

        # Bytes reais entregues ao Kodi na sessao atual.
        # CRITICO: stream_tail so vai para LRU se este contador > 0,
        # evitando que tails de conexoes falhas (406 etc.) contaminem a LRU.
        self._real_bytes_sent = 0

        self._watchdog_restart_flag = threading.Event()

        # Rotacao de IP/UA: pre-gerados para proxima conexao
        self._next_fake_ip = random_ip()
        self._next_ua      = random.choice(_ALL_UA)

    def _refill_emergency(self):
        for _ in range(200):
            try:
                self.emergency.put_nowait(NULL_BLOCK)
            except queue.Full:
                break

    def _push_keepalive(self, n=8):
        for _ in range(n):
            try:
                self.data_queue.put_nowait(NULL_BLOCK)
            except queue.Full:
                break

    def _next_gen(self):
        with self._gen_lock:
            self._gen += 1
            return self._gen

    def _get_gen(self):
        with self._gen_lock:
            return self._gen

    def _set_active_response(self, r):
        with self._active_response_lock:
            self._active_response = r

    def _clear_queue(self):
        n = 0
        while True:
            try:
                self.data_queue.get_nowait()
                n += 1
            except queue.Empty:
                break
        if n:
            xbmc.log('[ENGINE] Queue drenada: %d chunks' % n, xbmc.LOGDEBUG)

    def _new_session(self):
        self._new_session_with_rotation()

    def _kill_producer(self, timeout=5.0):
        self._stop_event.set()
        with self._active_response_lock:
            if self._active_response is not None:
                try:
                    self._active_response.close()
                except Exception:
                    pass
                self._active_response = None

        if self._producer_thread and self._producer_thread.is_alive():
            self._producer_thread.join(timeout=timeout)
            if self._producer_thread.is_alive():
                xbmc.log('[ENGINE] AVISO: producer nao encerrou em %ds' % timeout,
                         xbmc.LOGERROR)
            else:
                xbmc.log('[ENGINE] Producer encerrado OK', xbmc.LOGINFO)

    def _kill_watchdog(self, timeout=3.0):
        if self._watchdog_thread and self._watchdog_thread.is_alive():
            self._watchdog_thread.join(timeout=timeout)

    def _new_session_with_rotation(self):
        """Cria nova sessao HTTP com IP fake e UA rotacionados (garantido)."""
        if self.session:
            try:
                self.session.close()
            except Exception:
                pass
        s = requests.Session()
        a = HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=0)
        s.mount('http://', a)
        s.mount('https://', a)
        self.session = s
        self.reconnection_count += 1
        # Gera novo IP e UA para proxima conexao (logado aqui para rastreio)
        fake_ip = random_ip()
        ua      = random.choice(_ALL_UA)
        xbmc.log('[ROTATE] Sessao renovada #%d | IP=%s | UA=%s...' % (
            self.reconnection_count, fake_ip, ua[:40]), xbmc.LOGINFO)
        # Salva para uso imediato na proxima requisicao (via get_stealth_headers)
        self._next_fake_ip = fake_ip
        self._next_ua      = ua
        if self.reconnection_count % 5 == 0:
            gc.collect()

    def _session_reset(self, reason=''):
        """
        Reset TOTAL de sessao em caso de falha de conexao.
        Preserva LRU Tail Cache SOMENTE se havia bytes reais entregues ao Kodi
        (_real_bytes_sent > 0). Isso evita que tails de conexoes falhas (HTTP 406,
        timeout etc.) contaminem a LRU e causem loop/Grinch na sutura.
        """
        lru_count = len(self.lru.get_all())
        xbmc.log('[SESSION-RESET] Motivo: %s | bytes_entregues=%d | LRU=%d' % (
            reason, self._real_bytes_sent, lru_count), xbmc.LOGWARNING)

        # --- Fecha resposta ativa ---
        with self._active_response_lock:
            if self._active_response is not None:
                try:
                    self._active_response.close()
                except Exception:
                    pass
                self._active_response = None

        # --- Drena queue e injeta null packets para manter Kodi vivo ---
        self._clear_queue()
        self._push_keepalive(20)

        # --- Reseta contadores ---
        self.consecutive_failures = 0
        self.token_expired_count  = 0
        self.starvation_counter   = 0
        self._prebuf_bytes        = 0
        self.prebuf_ready.clear()
        self.last_data_time = time.time()

        # --- Atualiza LRU SOMENTE se stream entregou dados reais ao Kodi ---
        # Se nao entregou (ex: conexao recusada com 406 antes de qualquer chunk),
        # nao sobrescreve a LRU existente que pode ter tail valida de antes.
        if self._real_bytes_sent > 0 and self.stream_tail:
            self.lru.clear()   # Remove tail antiga para nao causar loop
            self.lru.push(self.stream_tail)
            xbmc.log('[SESSION-RESET] Tail valida (%dB, %d bytes entregues) -> LRU' % (
                len(self.stream_tail), self._real_bytes_sent), xbmc.LOGINFO)
        elif self._real_bytes_sent == 0:
            xbmc.log('[SESSION-RESET] Sem bytes entregues — LRU preservada sem alteracao (%d entradas)' % lru_count,
                     xbmc.LOGINFO)

        # --- Reseta estado de stream ---
        self.stream_tail      = b''
        self.residual_buffer  = b''
        self.has_initial_lock = False
        self._real_bytes_sent = 0

        # --- Nova sessao HTTP com IP/UA rotacionados ---
        self._new_session_with_rotation()

        # --- Backoff antes de reconectar ---
        self._stop_event.wait(timeout=SESSION_RESET_BACKOFF)
        xbmc.log('[SESSION-RESET] Pronto para reconexao', xbmc.LOGINFO)

    def _start_producer(self):
        self._stop_event.clear()
        self._watchdog_restart_flag.clear()
        t = threading.Thread(target=self._producer_loop,
                             name='XCodes-Producer', daemon=True)
        self._producer_thread = t
        t.start()

    def _start_watchdog(self):
        t = threading.Thread(target=self._watchdog_loop,
                             name='XCodes-Watchdog', daemon=True)
        self._watchdog_thread = t
        t.start()

    def start_stream(self, url_param):
        urls  = [u.strip() for u in url_param.split('|') if u.strip()]
        if not urls:
            raise ValueError('URL vazia')
        entry = urls[0]

        with self._engine_lock:
            same = (self.active_param == url_param)

            if same:
                producer_dead = (self._producer_thread is None or
                                 not self._producer_thread.is_alive())
                if not producer_dead:
                    xbmc.log('[ENGINE] Reutilizando sessao ativa', xbmc.LOGINFO)
                    return
                xbmc.log('[ENGINE] Mesmo canal, producer morto — reiniciando',
                         xbmc.LOGINFO)
            else:
                xbmc.log('[ENGINE %s] Novo canal: %s' % (VERSION, entry[:80]),
                         xbmc.LOGINFO)

            self._kill_producer()
            self._kill_watchdog()
            self._clear_queue()
            
            self.lru.clear()
            self.stream_tail      = b''
            self.residual_buffer  = b''
            self.has_initial_lock = False

            self._new_session()
            self._next_gen()
            self._prebuf_bytes        = 0
            self.prebuf_ready.clear()
            self.last_data_time       = time.time()
            self.starvation_counter   = 0
            self.consecutive_failures = 0
            self.token_expired_count  = 0
            self._real_bytes_sent     = 0

            if not same:
                self.active_param            = url_param
                self.reconn.history          = []
                self.reconn.last_success_idx = None

            self.entry_url   = entry
            self.current_url = entry
            self.base_url    = entry.split('?')[0]
            
            self._refill_emergency()
            self._start_producer()
            self._start_watchdog()

    def _watchdog_loop(self):
        xbmc.log('[WATCHDOG] Iniciado', xbmc.LOGINFO)
        stop = self._stop_event

        while not stop.wait(timeout=WATCHDOG_INTERVAL):
            if self.last_data_time == 0.0:
                continue

            elapsed = time.time() - self.last_data_time
            if elapsed < STARVATION_TIMEOUT:
                continue

            self.starvation_counter += 1
            xbmc.log('[WATCHDOG] Starvation %.1fs (n=%d)' % (
                elapsed, self.starvation_counter), xbmc.LOGWARNING)

            self._watchdog_restart_flag.set()
            self._push_keepalive(20)
            self.last_data_time = time.time()

        xbmc.log('[WATCHDOG] Encerrado', xbmc.LOGINFO)

    # ---- Lógica de Processamento --------------------------------------------

    def _try_suture(self, buf):
        candidates = []
        if self.stream_tail:
            candidates.append(('atual', self.stream_tail))
        for i, t in enumerate(self.lru.get_all()):
            candidates.append(('LRU#%d' % (i + 1), t))

        for label, tail in candidates:
            primary = tail[-TAIL_PRIMARY:] if len(tail) >= TAIL_PRIMARY else tail
            if primary and primary in buf:
                idx  = buf.rfind(primary)
                skip = idx + len(primary)
                xbmc.log('[SUTURA] Perfeita via %s pulando %dB' % (label, skip), xbmc.LOGINFO)
                return True, buf[skip:]

            secondary = tail[-TAIL_SECONDARY:] if len(tail) >= TAIL_SECONDARY else b''
            if secondary and len(buf) > TAIL_SECONDARY + 188 * 50 and secondary in buf:
                idx  = buf.rfind(secondary)
                skip = idx + len(secondary)
                xbmc.log('[SUTURA] Rapida via %s pulando %dB' % (label, skip), xbmc.LOGINFO)
                return True, buf[skip:]

        return False, b''

    def _process(self, raw, my_gen):
        if my_gen != self._get_gen():
            return
        if not raw:
            return

        batch = self.residual_buffer + raw

        if not self.has_initial_lock:
            idx = batch.find(b'\x47')
            if idx == -1:
                if len(batch) > TS_PACKET_SIZE * 2:
                    self.residual_buffer = batch[-(TS_PACKET_SIZE * 2):]
                else:
                    self.residual_buffer = batch
                return
            batch = batch[idx:]
            self.has_initial_lock = True

        n = len(batch) // TS_PACKET_SIZE
        if n == 0:
            self.residual_buffer = batch
            return

        used    = n * TS_PACKET_SIZE
        payload = batch[:used]
        self.residual_buffer = batch[used:]

        self.stream_tail += payload
        if len(self.stream_tail) > TAIL_PRIMARY + TAIL_SECONDARY:
            self.stream_tail = self.stream_tail[-TAIL_PRIMARY:]

        self.last_data_time       = time.time()
        self.starvation_counter   = 0
        self.chunk_sizer.update(len(payload))

        if not self.prebuf_ready.is_set():
            self._prebuf_bytes += len(payload)
            if self._prebuf_bytes >= PREBUFFER_BYTES:
                self.prebuf_ready.set()
                xbmc.log('[PRE-BUFFER] Pronto: %dKB' % (
                    self._prebuf_bytes // 1024), xbmc.LOGINFO)

        try:
            self.data_queue.put_nowait(payload)
        except queue.Full:
            try:
                self.data_queue.get_nowait()
            except Exception:
                pass
            try:
                self.data_queue.put_nowait(NULL_BLOCK)
            except Exception:
                pass
            try:
                self.data_queue.put_nowait(payload)
            except Exception:
                pass

    def _producer_loop(self):
        my_gen        = self._get_gen()
        failure_count = 0
        strategy_idx  = 0

        xbmc.log('[PRODUCER] Iniciado gen=%d' % my_gen, xbmc.LOGINFO)

        while not self._stop_event.is_set():

            if self._watchdog_restart_flag.is_set():
                self._watchdog_restart_flag.clear()
                xbmc.log('[PRODUCER] Watchdog restart solicitado', xbmc.LOGWARNING)
                self.consecutive_failures += 1
                self.last_data_time = time.time()

            r = None
            try:
                needs_reconn = (self.consecutive_failures >= 1 or
                                self.token_expired_count  >= 1)

                if needs_reconn:
                    target_url   = self.base_url
                    strategy_idx = self.reconn.next_idx()
                    xbmc.log('[PRODUCER] Reconexao S%d falhas=%d tok=%d -> URL Original: %s' % (
                        strategy_idx, self.consecutive_failures,
                        self.token_expired_count, target_url[:80]), xbmc.LOGINFO)

                    self.reconn.history.append(strategy_idx)
                    self._new_session_with_rotation()

                    # So preserva tail na LRU se esta sessao entregou bytes reais ao Kodi.
                    # Conexoes que falharam antes de enviar qualquer dado (406 etc.) nao
                    # devem contaminar a LRU com dados desatualizados.
                    if self._real_bytes_sent > 0 and self.stream_tail:
                        self.lru.clear()          # substitui, nao acumula
                        self.lru.push(self.stream_tail)
                        xbmc.log('[RECONN] Tail valida -> LRU (%dB, entregues=%d)' % (
                            len(self.stream_tail), self._real_bytes_sent), xbmc.LOGINFO)
                    elif self._real_bytes_sent == 0:
                        xbmc.log('[RECONN] Sem bytes entregues — LRU nao alterada', xbmc.LOGINFO)

                    self.stream_tail      = b''
                    self.residual_buffer  = b''
                    self.has_initial_lock = False
                    self._real_bytes_sent = 0

                    try:
                        r = self.reconn.execute(strategy_idx, self.session, target_url)
                    except (requests.exceptions.ConnectionError,
                            requests.exceptions.Timeout,
                            requests.exceptions.ChunkedEncodingError,
                            OSError) as conn_err:
                        xbmc.log('[PRODUCER] Falha de conexao na URL entrada: %s' % conn_err,
                                 xbmc.LOGERROR)
                        self._session_reset(reason='Falha URL entrada: %s' % type(conn_err).__name__)
                        failure_count += 1
                        continue

                else:
                    target_url = self.current_url
                    h = get_stealth_headers(target_url)
                    # Injeta IP/UA pre-rotacionados se disponiveis
                    if hasattr(self, '_next_fake_ip') and self._next_fake_ip:
                        h['X-Forwarded-For'] = self._next_fake_ip
                        h['X-Real-IP']       = self._next_fake_ip
                        h['Client-IP']       = self._next_fake_ip
                    if hasattr(self, '_next_ua') and self._next_ua:
                        h['User-Agent'] = self._next_ua
                    h.pop('Accept-Encoding', None)
                    xbmc.log('[PRODUCER] Primeira conexao IP=%s UA=%s URL=%s' %
                             (h.get('X-Forwarded-For', 'N/A'),
                              h.get('User-Agent', '')[:35],
                              target_url[:80]), xbmc.LOGINFO)
                    try:
                        r = self.session.get(
                            target_url, headers=h, stream=True,
                            timeout=(CONNECT_TIMEOUT, FETCH_TIMEOUT),
                            verify=False, allow_redirects=True)
                    except (requests.exceptions.ConnectionError,
                            requests.exceptions.Timeout,
                            requests.exceptions.ChunkedEncodingError,
                            OSError) as conn_err:
                        xbmc.log('[PRODUCER] Falha de conexao inicial: %s' % conn_err,
                                 xbmc.LOGERROR)
                        self._session_reset(reason='Falha conexao inicial: %s' % type(conn_err).__name__)
                        failure_count += 1
                        continue

                if r is None:
                    xbmc.log('[PRODUCER] Resposta nula', xbmc.LOGWARNING)
                    self.consecutive_failures += 1
                    self._push_keepalive(10)
                    self._stop_event.wait(timeout=1.0)
                    continue

                status = r.status_code

                if status in TOKEN_EXPIRED_CODES:
                    self.token_expired_count += 1
                    xbmc.log('[PRODUCER] Token expirado HTTP %d #%d' % (
                        status, self.token_expired_count), xbmc.LOGWARNING)
                    r.close()
                    # Reset de sessao quando token expirado (preserva LRU para sutura)
                    if self.token_expired_count >= 2:
                        self._session_reset(reason='Token expirado HTTP %d x%d' % (
                            status, self.token_expired_count))
                        failure_count += 1
                    else:
                        wait = min(8.0, self.token_expired_count * 1.5)
                        self._push_keepalive(int(wait / KEEPALIVE_INTERVAL) + 5)
                        self._stop_event.wait(timeout=wait)
                        self.consecutive_failures = 0
                    continue

                if status == 409:
                    r.close()
                    self._push_keepalive(20)
                    self._stop_event.wait(timeout=1.5)
                    continue

                if status not in (200, 206):
                    self.consecutive_failures += 1
                    failure_count             += 1
                    backoff = BACKOFF_SEQUENCE[min(failure_count - 1,
                                                   len(BACKOFF_SEQUENCE) - 1)]
                    xbmc.log('[PRODUCER] HTTP %d backoff %.1fs' % (
                        status, backoff), xbmc.LOGERROR)
                    r.close()
                    # Reset de sessao apos multiplas falhas HTTP
                    if failure_count >= SESSION_RESET_FAIL_LIMIT:
                        self._session_reset(reason='HTTP %d x%d' % (status, failure_count))
                        failure_count = 0
                    else:
                        self._push_keepalive(10)
                        self._stop_event.wait(timeout=backoff)
                    continue

                self._watchdog_restart_flag.clear()
                self.last_data_time          = time.time()
                self.consecutive_failures    = 0
                self.token_expired_count     = 0
                failure_count                = 0
                self.reconn.last_success_idx = strategy_idx
                self.current_url             = r.url
                # Pre-rotaciona IP/UA para proxima reconexao
                self._next_fake_ip = random_ip()
                self._next_ua      = random.choice(_ALL_UA)
                # Reseta contador de bytes desta conexao
                self._real_bytes_sent = 0

                if needs_reconn:
                    xbmc.log('[PRODUCER] Reconectado gen=%d (Novo Token): %s' % (
                        my_gen, r.url[:80]), xbmc.LOGINFO)
                else:
                    xbmc.log('[PRODUCER] Conectado gen=%d: %s' % (
                        my_gen, r.url[:80]), xbmc.LOGINFO)

                self._set_active_response(r)

                is_ts    = any(x in r.url.lower()
                               for x in ('.ts', '/ts', '.m2ts',
                                         '/chunk', '/segment'))
                chunk_sz = TS_CHUNK_SIZE if is_ts else self.chunk_sizer.size
                real_bytes  = 0
                conn_start  = time.time()

                resync_buf  = b''
                need_suture = bool(self.stream_tail) or bool(self.lru.get_all())
                suture_start = time.time()

                try:
                    for chunk in r.iter_content(chunk_size=chunk_sz):
                        if self._stop_event.is_set():
                            break

                        if not chunk:
                            if (real_bytes == 0 and
                                    time.time() - conn_start > MANIFEST_FAIL_TIMEOUT):
                                xbmc.log('[PRODUCER] Manifest fail — reconectando',
                                         xbmc.LOGERROR)
                                break
                            continue

                        real_bytes += len(chunk)
                        if not is_ts:
                            chunk_sz = self.chunk_sizer.size

                        if need_suture:
                            resync_buf += chunk

                            # Manter Watchdog e Player do Kodi vivos durante a busca da emenda
                            self.last_data_time = time.time()
                            self._push_keepalive(2)

                            if len(resync_buf) > SEARCH_WINDOW:
                                resync_buf = resync_buf[-(SEARCH_WINDOW // 2):]

                            ok, remainder = self._try_suture(resync_buf)
                            time_spent = time.time() - suture_start

                            if ok:
                                resync_buf            = b''
                                need_suture           = False
                                self.has_initial_lock = False
                                self.residual_buffer  = b''
                                # CRITICO: limpa LRU apos sutura bem-sucedida.
                                # A tail usada na emenda ja foi consumida — manter
                                # na LRU causaria reuso em reconexoes futuras
                                # e enviaria bytes atras do live-edge (loop/Grinch).
                                self.lru.clear()
                                xbmc.log('[SUTURA] LRU limpa pos-emenda (anti-loop)', xbmc.LOGINFO)
                                self._process(remainder, my_gen)
                            elif time_spent > SUTURE_MAX_TIME or len(resync_buf) >= SEARCH_WINDOW:
                                xbmc.log('[SUTURA] Timeout/Janela maxima (%.1fs) — forcando fluxo novo' % time_spent, xbmc.LOGWARNING)
                                need_suture           = False
                                self.has_initial_lock = False
                                self.residual_buffer  = b''
                                # Limpa LRU tambem no timeout: dados acumulados
                                # no resync_buf estao muito distantes do live-edge
                                self.lru.clear()
                                self._process(resync_buf, my_gen)
                                resync_buf = b''
                        else:
                            self._process(chunk, my_gen)
                            # Contabiliza bytes reais entregues ao Kodi
                            self._real_bytes_sent += len(chunk)

                        if self._watchdog_restart_flag.is_set():
                            xbmc.log('[PRODUCER] Watchdog pediu restart no stream',
                                     xbmc.LOGWARNING)
                            break

                except (requests.exceptions.ConnectionError,
                        requests.exceptions.ChunkedEncodingError,
                        requests.exceptions.Timeout,
                        OSError) as stream_err:
                    xbmc.log('[PRODUCER] Falha durante streaming: %s' % stream_err,
                             xbmc.LOGERROR)
                    self._set_active_response(None)
                    try:
                        r.close()
                    except Exception:
                        pass
                    # Reset de sessao preservando LRU para sutura
                    self._session_reset(reason='Falha stream: %s' % type(stream_err).__name__)
                    failure_count += 1
                    continue

                self._set_active_response(None)
                r.close()

                if real_bytes == 0 and not self._stop_event.is_set():
                    self.consecutive_failures += 1
                    failure_count             += 1
                    self._push_keepalive(8)
                    if failure_count >= SESSION_RESET_FAIL_LIMIT:
                        self._session_reset(reason='Zero bytes recebidos x%d' % failure_count)
                        failure_count = 0

            except Exception as exc:
                self._set_active_response(None)
                if r:
                    try:
                        r.close()
                    except Exception:
                        pass

                if self._stop_event.is_set():
                    break

                xbmc.log('[PRODUCER] Excecao: %s' % exc, xbmc.LOGERROR)
                self.consecutive_failures += 1
                failure_count             += 1

                if failure_count >= SESSION_RESET_FAIL_LIMIT:
                    self._session_reset(reason='Excecao geral x%d: %s' % (
                        failure_count, type(exc).__name__))
                    failure_count = 0
                else:
                    backoff = BACKOFF_SEQUENCE[min(failure_count - 1,
                                                   len(BACKOFF_SEQUENCE) - 1)]
                    self._push_keepalive(int(backoff / KEEPALIVE_INTERVAL))
                    self._stop_event.wait(timeout=backoff)

        xbmc.log('[PRODUCER] Encerrado gen=%d' % my_gen, xbmc.LOGINFO)

    def generator(self):
        xbmc.log('[ENGINE %s] Gerador iniciado' % VERSION, xbmc.LOGINFO)
        
        my_gen = self._get_gen()

        for _ in range(100):
            yield NULL_BLOCK

        xbmc.log('[PRE-BUFFER] Aguardando %dKB...' % (PREBUFFER_BYTES // 1024),
                 xbmc.LOGINFO)
        if self.prebuf_ready.wait(timeout=PREBUFFER_TIMEOUT):
            xbmc.log('[PRE-BUFFER] OK', xbmc.LOGINFO)
        else:
            xbmc.log('[PRE-BUFFER] Timeout — iniciando mesmo assim',
                     xbmc.LOGWARNING)

        next_kp = time.time() + KEEPALIVE_INTERVAL

        try:
            while True:
                if my_gen != self._get_gen():
                    xbmc.log('[ENGINE] Novo stream solicitado. Encerrando gerador antigo.', xbmc.LOGINFO)
                    break

                now = time.time()
                try:
                    chunk = self.data_queue.get(timeout=KEEPALIVE_INTERVAL)
                    yield chunk
                    next_kp = time.time() + KEEPALIVE_INTERVAL
                except queue.Empty:
                    if now >= next_kp:
                        try:
                            yield self.emergency.get_nowait()
                            self._refill_emergency()
                        except queue.Empty:
                            yield NULL_BLOCK
                        next_kp = time.time() + KEEPALIVE_INTERVAL

        except GeneratorExit:
            xbmc.log('[ENGINE] GeneratorExit (Cliente desconectou)', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[ENGINE] Erro gerador: %s' % e, xbmc.LOGERROR)
        finally:
            if my_gen == self._get_gen():
                self._stop_event.set()
            xbmc.log('[ENGINE] Sessao finalizada (gen=%d)' % my_gen, xbmc.LOGINFO)


# ---- Instancia Global -------------------------------------------------------
engine = XCodesEngine()


# ---- HTTP Handler -----------------------------------------------------------

class TSProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        p = urlparse(self.path)
        if p.path != '/stream':
            self.send_response(404)
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('Connection',    'keep-alive')
        self.send_header('Content-Type',  'video/mp2t')
        self.end_headers()

        url_param = parse_qs(p.query).get('url', [None])[0]
        if not url_param:
            self._keep_alive_dummy()
            return

        try:
            engine.start_stream(url_param)
            for chunk in engine.generator():
                self.wfile.write(chunk)
                self.wfile.flush()
        except (ConnectionResetError, BrokenPipeError) as e:
            xbmc.log('[HTTP] Cliente desconectou: %s' % e, xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[HTTP] Erro (mascarado do player): %s' % e, xbmc.LOGERROR)
            self._keep_alive_dummy()

    def _keep_alive_dummy(self):
        try:
            while True:
                self.wfile.write(NULL_BLOCK)
                self.wfile.flush()
                time.sleep(0.05)
        except Exception:
            pass

    def log_message(self, fmt, *args):
        pass


class TSProxyServer(threading.Thread):
    def __init__(self, port):
        super(TSProxyServer, self).__init__(daemon=True)
        self.port   = port
        self.server = HTTPServer(('127.0.0.1', port), TSProxyHandler)

    def run(self):
        xbmc.log('[X-CODES] Servidor na porta %d' % self.port, xbmc.LOGINFO)
        try:
            self.server.serve_forever()
        except Exception as e:
            xbmc.log('[X-CODES] Erro servidor: %s' % e, xbmc.LOGERROR)

    def stop(self):
        self.server.shutdown()
        self.server.server_close()


def get_free_port(start=50088):
    for port in range(start, start + 100):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            return port
        except OSError:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    return random.randint(50088, 50188)


proxy_server = None

def start_server():
    global proxy_server
    port         = get_free_port()
    proxy_server = TSProxyServer(port)
    proxy_server.start()
    time.sleep(0.5)
    return port

SERVER_PORT = start_server()


# ---- Entry Point ------------------------------------------------------------

def run_addon():
    action = _ARGS.get('action')
    url    = _ARGS.get('url')

    if action == 'play' and url:
        local = 'http://127.0.0.1:%d/stream?url=%s' % (SERVER_PORT, quote(url))
        li = xbmcgui.ListItem(path=local)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=li)
    else:
        li = xbmcgui.ListItem(
            '[COLOR cyan]NEXUS X-CODES HYBRID %s[/COLOR]' % VERSION)
        li.setInfo('video', {'title': 'Nexus X-Codes Hybrid Proxy'})
        xbmcplugin.addDirectoryItem(_HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(_HANDLE)


if __name__ == '__main__':
    run_addon()