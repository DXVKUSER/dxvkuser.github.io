# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
from doh_client import requests
import random
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests import exceptions  # CORREÇÃO: Importa o módulo de exceções corretamente

# --- NOVAS CONFIGURAÇÕES DE REPETIÇÃO ---
API_RETRIES = 5
RETRY_BACKOFF_FACTOR = 0.5
STATUS_FORCELIST = [429, 500, 502, 503, 504, 403]
# ----------------------------------------

class XtreamAPI:
    def __init__(self, server, username, password):
        self.base_url = f"{server}"
        self.username = username
        self.password = password
        
        # Gera uma versão do Chrome aleatória e rotativa
        chrome_version = random.randint(90, 110)
        self.user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_version}.0.0.0 Safari/537.36"
        
        # Configura a estratégia de repetição para a API
        retry_strategy = Retry(
            total=API_RETRIES,
            backoff_factor=RETRY_BACKOFF_FACTOR,
            status_forcelist=STATUS_FORCELIST
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session = requests.session
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)

        # Adiciona o User Agent rotativo
        self.session.headers.update({'User-Agent': self.user_agent})
        xbmc.log(f"[XtreamProxy] Usando User-Agent rotativo: {self.session.headers['User-Agent']}", level=xbmc.LOGINFO)

    def _make_request(self, params):
        params['username'] = self.username
        params['password'] = self.password
        try:
            response = self.session.get(f"{self.base_url}/player_api.php", params=params, timeout=15)
            response.raise_for_status()
            if response.text.strip() == "[]":
                return []
            data = response.json()
            if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
                xbmcgui.Dialog().ok("Erro de Autenticação", "Usuário ou senha inválidos.")
                return None
            return data
        # CORREÇÃO: Usa 'exceptions.RequestException' para capturar o erro corretamente
        except exceptions.RequestException as e:
            xbmc.log(f"[XtreamProxy] Erro de API (com retries): {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Conexão", f"Não foi possível conectar ao servidor: {e}")
            return None
        except ValueError:
            xbmc.log(f"[XtreamProxy] Erro de API: Resposta não é JSON válido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Servidor", "O servidor retornou uma resposta inválida.")
            return None

    def get_live_categories(self):
        return self._make_request({'action': 'get_live_categories'})

    def get_live_streams(self, category_id=None):
        params = {'action': 'get_live_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_vod_categories(self):
        return self._make_request({'action': 'get_vod_categories'})

    def get_vod_streams(self, category_id=None):
        params = {'action': 'get_vod_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_categories(self):
        return self._make_request({'action': 'get_series_categories'})

    def get_series(self, category_id=None):
        params = {'action': 'get_series'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_info(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_live_stream_url(self, stream_id):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.m3u8"

    def get_vod_stream_url(self, stream_id):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.mp4"

    def get_series_stream_url(self, stream_id):
        return f"{self.base_url}/series/{self.username}/{self.password}/{stream_id}.mp4"