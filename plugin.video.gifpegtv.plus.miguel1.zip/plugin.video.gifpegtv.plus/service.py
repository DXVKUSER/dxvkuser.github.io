# -*- coding: utf-8 -*-
import threading
import logging
from socketserver import ThreadingTCPServer
import xbmc

# Importa as classes necessárias do seu script principal
from hlsproxy import HLSProxyRequestHandler, CONFIG, setup_logging

class HLSProxyManager:
    """Gerenciador de ciclo de vida do proxy para o serviço."""
    def __init__(self):
        self.server: ThreadingTCPServer | None = None
        self.thread: threading.Thread | None = None

    def start(self) -> bool:
        """Inicia o proxy na porta e host fixos da configuração."""
        host = CONFIG.proxy_host # '0.0.0.0'
        port = CONFIG.proxy_port # 8001
        
        try:
            logging.info(f"Tentando iniciar o proxy em {host}:{port}")
            self.server = ThreadingTCPServer(
                # Usa o host '0.0.0.0' para escutar todas as interfaces
                (host, port),
                HLSProxyRequestHandler,
                bind_and_activate=False
            )
            self.server.allow_reuse_address = True
            self.server.server_bind()
            self.server.server_activate()
            self.server.daemon_threads = True
            
            self.thread = threading.Thread(
                target=self.server.serve_forever,
                daemon=True
            )
            self.thread.start()
            # Informa a porta em que está ouvindo
            logging.info(f"Proxy iniciado com sucesso em http://{host}:{port}") 
            return True
            
        except OSError as e:
            logging.error(f"Não foi possível iniciar o proxy na porta {port}: {e}")
            return False

    def stop(self) -> None:
        """Para o proxy com limpeza de recursos."""
        if self.server:
            logging.info("Parando servidor proxy...")
            self.server.shutdown()
            self.server.server_close()
            if self.thread:
                self.thread.join()
            logging.info("Servidor proxy parado.")

if __name__ == '__main__':
    setup_logging()
    monitor = xbmc.Monitor()
    proxy = HLSProxyManager()
    
    # Se a porta 8001 estiver em uso, o start() falhará e o serviço não iniciará
    if proxy.start():
        # Mantém o serviço rodando até o Kodi ser fechado
        while not monitor.abortRequested():
            if monitor.waitForAbort(10): # Espera por 10 segundos
                break
        proxy.stop()
    else:
        logging.error("O serviço do proxy não pôde ser iniciado. A porta 8001 pode estar em uso.")