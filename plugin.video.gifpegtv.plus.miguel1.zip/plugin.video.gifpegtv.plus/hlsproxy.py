# -*- coding: utf-8 -*-
import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingTCPServer
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass
from contextlib import contextmanager
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import HTTPError, RequestException
# from doh_client import requests as doh_requests # REMOVIDO: Limpeza de import não utilizado
import xbmc
import xbmcgui
import xbmcplugin

# ---------------- CONFIGURAÇÃO AVANÇADA PARA MÁXIMA FLUIDEZ (ANTI-STALL) ----------------
@dataclass(frozen=True)
class ProxyConfig:
    # Máximo de tentativas de segmento em caso de falha de rede ou timeout
    max_retries: int = 3
    # Fator de backoff exponencial em segundos. (1.0 * 2^attempt)
    retry_backoff_factor: float = 1.0 
    # REDUZIDO: Timeout para conexão inicial (manifesto ou segmento) - Detecta falha mais rápido.
    connection_timeout: int = 5        
    
    # AJUSTE CRÍTICO (HIPER-AGRESSIVO): Timeout máximo para leitura de dados do stream.
    # 12s força retry muito rápido em downloads lentos que causariam stall.
    stream_timeout: float = 12.0       
    
    # AJUSTE CRÍTICO (MÁXIMA VAZÃO): Tamanho do chunk para acelerar a transferência interna.
    chunk_size: int = 1024 * 1024 # Aumentado para 1024KB
    
    proxy_host: str = '0.0.0.0'
    proxy_port: int = 8001
    max_port_attempts: int = 20
    log_file: str = "hls_proxy.log"
    # Máximo de erros 404 consecutivos antes de quebrar - Usamos 503 para recuperação
    max_segment_errors: int = 1        
    manifest_retries: int = 8          # Retries para o manifesto
    
    # Tupla de (connect_timeout, read_timeout) ajustada para a nova agressividade (5s, 12s)
    request_timeout_tuple: Tuple[int, float] = (5, 12.0) 

CONFIG = ProxyConfig()
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- UTILITÁRIOS ----------------
def setup_logging() -> None:
    """Configura o sistema de logging com pathlib e formatação moderna."""
    try:
        log_path = Path(xbmc.translatePath('special://logpath')) / CONFIG.log_file
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(thread)d %(message)s',
            handlers=[logging.FileHandler(log_path, mode='w', encoding='utf-8')]
        )
    except Exception:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

def get_forward_headers(client_headers: Dict[str, str]) -> Dict[str, str]:
    """Gera headers com User-Agent rotativo e headers essenciais."""
    chrome_version = random.randint(100, 125) # Faixa de versão atualizada
    user_agent = (
        f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        f"(KHTML, like Gecko) Chrome/{chrome_version}.0.0.0 Safari/537.36"
    )
    
    headers = {
        'User-Agent': user_agent,
    }
    
    # Copia headers essenciais do cliente. 'Range' é vital para HLS e buffering.
    for header in ('Authorization', 'Cookie', 'Range'): 
        if header in client_headers:
            headers[header] = client_headers[header]
    
    return headers

# ---------------- HANDLER OTIMIZADO ----------------
class HLSProxyRequestHandler(BaseHTTPRequestHandler):
    """Handler otimizado com tratamento robusto de erros."""
    def __init__(self, *args, **kwargs):
        # Usando requests padrão para maior estabilidade de rede e connection pooling
        self.session = requests.Session() 
        self.adapter = HTTPAdapter(max_retries=0) 
        self.session.mount('http://', self.adapter)
        self.session.mount('https://', self.adapter)
        self.error_counter: Dict[str, int] = {}
        super().__init__(*args, **kwargs)

    def log_message(self, format: str, *args) -> None:
        """Sobrescrita para logging eficiente."""
        # Logs de INFO são essenciais para rastrear requisições no Kodi
        logging.info(f"{self.client_address[0]} - \"{format % args}\"")

    def do_HEAD(self) -> None:
        """Suporte a requisições HEAD."""
        self.do_GET(head_only=True)

    def do_GET(self, head_only: bool = False) -> None:
        """Processa requisições GET com tratamento robusto de erros."""
        try:
            if '?url=' not in self.path:
                self.send_error(404, "Not Found")
                return

            query = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(query.get('url', [''])[0])
            # Usa o IP do cliente como session_id padrão para rastreamento de erros
            session_id = query.get('session_id', [self.client_address[0]])[0] 

            if not url:
                self.send_error(400, "Bad Request")
                return

            headers = get_forward_headers(self.headers)
            parsed_url = urllib.parse.urlparse(url)
            
            if parsed_url.path.lower().endswith(('.m3u8', '.m3u')):
                self._handle_manifest(url, headers, session_id, head_only)
            else:
                self._handle_segment(url, session_id, headers, head_only)

        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente Kodi fechou a conexão abruptamente (possivelmente devido a stall)")
        except Exception as e:
            logging.error(f"Erro inesperado no handler GET: {e}", exc_info=True)
            try:
                # CORREÇÃO: Usar 502 Bad Gateway se a origem for o problema
                self.send_error(502, "Bad Gateway / Internal Proxy Error") 
            except Exception:
                pass 

    def _handle_manifest(self, url: str, headers: Dict[str, str], 
                        session_id: str, head_only: bool) -> None:
        """Processa manifestos com retry inteligente e reescrita de URLs."""
        response = None
        try:
            # Manifestos usam um único timeout (connection_timeout)
            response = self._retry_request(
                url, headers, CONFIG.manifest_retries, CONFIG.connection_timeout, stream=False
            )
            
            if not response:
                logging.error(f"Falha PROATIVA ao obter manifesto após {CONFIG.manifest_retries} tentativas: {url}")
                self.send_error(503, "Service Unavailable: Retries exhausted for manifest")
                return

            self._send_manifest_response(response, session_id, head_only)
            
        except HTTPError as e:
            logging.error(f"Erro HTTP ao processar manifesto {url}: {e}")
            status_code = e.response.status_code if e.response else 502
            self.send_error(status_code, str(e) or "Bad Gateway")
        except Exception as e:
            logging.error(f"Erro ao processar manifesto {url}: {e}", exc_info=True)
            self.send_error(502, "Bad Gateway: Error processing manifest")
        finally:
            if response:
                response.close()

    def _handle_segment(self, url: str, session_id: str, 
                       headers: Dict[str, str], head_only: bool) -> None:
        """Processa segmentos com controle de erros e streaming eficiente."""
        response = None
        try:
            # Segmentos usam a tupla (connect_timeout, read_timeout) - Agressivo (5s, 12s)
            response = self._retry_request(
                url, headers, CONFIG.max_retries, CONFIG.request_timeout_tuple, stream=True
            )
            
            if not response:
                logging.error(f"Falha de RESILIÊNCIA ao obter segmento após {CONFIG.max_retries} tentativas: {url}")
                # CORREÇÃO: Usar 504 Gateway Timeout, pois falha de retry significa que o recurso não está disponível
                self.send_error(504, "Gateway Timeout: Retries exhausted for segment") 
                return

            if response.status_code == 404:
                self._handle_404_error(session_id) # Se 404, usa a lógica de recuperação 503
                return

            # Limpa o contador de erros após um segmento bem-sucedido (código 2xx)
            if response.ok:
                 self.error_counter[session_id] = 0
            
            self._send_segment_response(response, head_only)
            
        except HTTPError as e:
            logging.error(f"Erro HTTP ao processar segmento {url}: {e}")
            status_code = e.response.status_code if e.response else 502
            self.send_error(status_code, str(e) or "Bad Gateway")
        except requests.exceptions.Timeout:
            # Captura Timeout de forma explícita, que é o alvo principal da correção.
            logging.warning(f"TIMEOUT AGRESSIVO ({CONFIG.stream_timeout}s) alcançado para o segmento {url}. Forçando retry.")
            # CORREÇÃO: Usar 504 ao invés de 500
            self.send_error(504, "Gateway Timeout (Proxy Forçou Retry Rápido)") 
        except Exception as e:
            logging.error(f"Erro ao processar segmento {url}: {e}", exc_info=True)
            self.send_error(502, "Bad Gateway") # Usar 502 para erros de origem/conexão
        finally:
            if response:
                response.close()

    def _retry_request(self, url: str, headers: Dict[str, str], 
                      max_retries: int, timeout: Any, 
                      stream: bool = False) -> Optional[requests.Response]:
        """Realiza requisições com retry exponencial e tratamento de 429 e 5xx."""
        for attempt in range(max_retries):
            try:
                # O timeout agora usa o valor mais agressivo de 12.0s para leitura.
                response = self.session.get(
                    url, headers=headers, timeout=timeout, 
                    stream=stream, verify=False, allow_redirects=True
                )
                
                # Para erros 4xx que não devem ser retentados (404, 403, etc.), retorna a resposta imediatamente
                if 400 <= response.status_code < 500 and response.status_code != 429:
                    # CORREÇÃO: Para o Kodi, se não for 404, o proxy deve passar o erro adiante.
                    return response
                    
                response.raise_for_status()
                return response
                
            except HTTPError as e:
                status_code = e.response.status_code if e.response else 0
                
                # Tratamento de 429 (Too Many Requests)
                if status_code == 429:
                    wait_time = self._calculate_retry_time(e.response, attempt)
                    logging.warning(f"429 - Tentando novamente em {wait_time:.2f}s... (Tentativa {attempt+1}/{max_retries})")
                    time.sleep(wait_time)
                    continue
                
                # Tratamento de erros de servidor 5xx
                if 500 <= status_code < 600:
                    # Backoff exponencial para 5xx (melhora a resiliência)
                    wait_time = CONFIG.retry_backoff_factor * (2 ** attempt) + random.uniform(0.1, 0.5)
                    logging.warning(f"Erro 5xx na requisição: {status_code}. Tentando novamente em {wait_time:.2f}s...")
                    time.sleep(wait_time)
                    continue
                
                # Para outros erros HTTP, levanta a exceção e encerra o retry
                raise
            except requests.exceptions.Timeout:
                # O timeout é agressivo e intencional.
                logging.warning(f"Timeout alcançado no segmento. Tentativa {attempt+1}/{max_retries}")
                if attempt + 1 >= max_retries:
                    raise # Levanta a exceção para o chamador finalizar o segmento
                
                # Permite um pequeno sleep apenas para espaçar as tentativas
                wait_time = CONFIG.retry_backoff_factor * (2 ** attempt) + random.uniform(0.1, 0.5)
                time.sleep(wait_time)
                continue
                
            except RequestException as e:
                # Erro de conexão ou falha de rede/conexão
                wait_time = CONFIG.retry_backoff_factor * (2 ** attempt) + random.uniform(0.1, 0.5)
                logging.warning(f"Erro de rede: {e}. Tentando novamente em {wait_time:.2f}s... (Tentativa {attempt+1}/{max_retries})")
                time.sleep(wait_time)
                continue
                
        return None

    def _calculate_retry_time(self, response: requests.Response, attempt: int) -> float:
        """Calcula tempo de retry baseado em Retry-Header ou backoff exponencial."""
        retry_after = response.headers.get('Retry-After')
        if retry_after:
            try:
                return float(retry_after)
            except ValueError:
                pass
        return CONFIG.retry_backoff_factor * (2 ** attempt) + random.uniform(0.1, 0.5)

    def _handle_404_error(self, session_id: str) -> None:
        """PROATIVO: Controla erros 404 consecutivos e força o retry pelo player (503)."""
        consecutive_errors = self.error_counter.get(session_id, 0) + 1
        self.error_counter[session_id] = consecutive_errors
        logging.warning(f"404 - Segmento não encontrado. Erros consecutivos: {consecutive_errors} para {session_id}")
        
        if consecutive_errors >= CONFIG.max_segment_errors:
            # Se exceder o limite, retorna 404 final para quebrar a reprodução
            self.send_error(404, "Not Found (Segmento indisponível após várias tentativas)")
        else:
            # Retorna 503 (Temporarily Unavailable) para forçar o player HLS a buscar um novo manifesto ou segmento.
            self.send_error(503, "Segment Temporarily Unavailable (Tentativa de recuperação do stream)")

    def _send_manifest_response(self, response: requests.Response, 
                               session_id: str, head_only: bool) -> None:
        """Envia resposta do manifesto com URLs reescritas."""
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        # Headers PROATIVOS: Garantem que o Kodi não cacheie o manifesto e sempre o busque.
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.end_headers()
        
        if head_only:
            return
            
        try:
            # Decodificação de conteúdo mais robusta
            manifest_content = response.content.decode(response.encoding or 'utf-8', errors='ignore')
            base_url = response.url
            new_manifest = []
            
            for line in manifest_content.splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith('#'):
                    new_manifest.append(line)
                else:
                    full_url = urllib.parse.urljoin(base_url, stripped)
                    # Cache-Buster (t=) para garantir que o Kodi não use cache interno (Fluidez)
                    cache_buster = f"&t={int(time.time() * 1000)}" 
                    
                    proxy_url = (
                        f"http://127.0.0.1:{CONFIG.proxy_port}/" 
                        f"?url={urllib.parse.quote_plus(full_url)}&session_id={session_id}{cache_buster}"
                    )
                    new_manifest.append(proxy_url)
            
            self.wfile.write('\n'.join(new_manifest).encode('utf-8'))
        except Exception as e:
            logging.error(f"Erro ao enviar manifesto: {e}", exc_info=True)
        finally:
            response.close()

    def _send_segment_response(self, response: requests.Response, head_only: bool) -> None:
        """Envia resposta do segmento com streaming eficiente (Fluidez)."""
        self.send_response(response.status_code)
        
        # Copia headers relevantes
        for header, value in response.headers.items():
            lower_header = header.lower()
            # Garante que Content-Length seja passado (ajuda no buffering do Kodi)
            # Evita Transfer-Encoding/Connection/Content-Encoding que podem causar problemas no Kodi/http.server
            if lower_header not in ['transfer-encoding', 'connection', 'content-encoding']:
                self.send_header(header, value)

        # Se houver Content-Length, passamos para o cliente para auxiliar no buffering
        if 'Content-Length' in response.headers:
            self.send_header('Content-Length', response.headers['Content-Length'])
        
        self.end_headers()
        
        if head_only:
            return
            
        try:
            # Streaming eficiente em chunks grandes para máxima fluidez
            for chunk in response.iter_content(chunk_size=CONFIG.chunk_size):
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            logging.warning("Cliente fechou a conexão durante o streaming (Kodi) - Possível descarte após stall.")
        except Exception as e:
            logging.error(f"Erro grave durante o streaming: {e}", exc_info=True)
        finally:
            response.close()

    def do_OPTIONS(self) -> None:
        """Responde requisições OPTIONS com headers CORS."""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Range, User-Agent, Cookie')
        self.end_headers()

# ---------------- GERENCIADOR DE PROXY ----------------
class HLSProxyManager:
    """Gerenciador de ciclo de vida do proxy com inicialização otimizada."""
    def __init__(self):
        self.server: Optional[ThreadingTCPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.active_port: Optional[int] = None

    def start(self) -> bool:
        """Inicia o proxy na porta fixa 8001 (ou tenta encontrar uma aleatória se a fixa falhar)."""
        
        host = CONFIG.proxy_host 
        port = CONFIG.proxy_port 
        
        try:
            self._bind_and_start(host, port)
            self.active_port = port
            logging.info(f"Proxy iniciado em http://127.0.0.1:{self.active_port}")
            return True
        except OSError as e:
            logging.warning(f"Porta fixa {port} em uso: {e}. Tentando portas aleatórias...")

        # Lógica de fallback para porta aleatória
        for _ in range(CONFIG.max_port_attempts):
            port = random.randint(30000, 60000)
            try:
                self._bind_and_start(host, port)
                self.active_port = port
                logging.info(f"Proxy iniciado (aleatório) em http://127.0.0.1:{self.active_port}")
                return True
            except OSError as e:
                logging.warning(f"Porta {port} em uso: {e}")
                continue
                
        logging.error("Não foi possível iniciar o proxy - todas as portas em uso")
        return False
        
    def _bind_and_start(self, host: str, port: int) -> None:
        """Cria e inicia o servidor ThreadingTCPServer."""
        self.server = ThreadingTCPServer(
            (host, port), 
            HLSProxyRequestHandler,
            bind_and_activate=False
        )
        self.server.allow_reuse_address = True
        self.server.server_bind()
        self.server.server_activate()
        self.server.daemon_threads = True
        
        self.thread = threading.Thread(
            target=self.server.serve_forever, 
            daemon=True
        )
        self.thread.start()

    def stop(self) -> None:
        """Para o proxy com limpeza de recursos."""
        if self.server:
            logging.info("Parando servidor proxy...")
            self.server.shutdown()
            self.server.server_close()
            # O join é importante para esperar que a thread termine
            if self.thread and self.thread.is_alive(): 
                self.thread.join(timeout=1) 
            self.server = None
            self.thread = None
            self.active_port = None
            logging.info("Servidor proxy parado")

# ---------------- ADDON ----------------
class HLSAddon:
    """Interface do addon com Kodi usando métodos otimizados."""
    def __init__(self, handle: int):
        self.handle = handle
        self.proxy = HLSProxyManager()
        global __proxy_manager
        __proxy_manager = self.proxy 

    def play_stream(self, url: str, stype: str, title: Optional[str] = None) -> None:
        """Inicia o proxy e reproduz a stream no Kodi."""
        if not self.proxy.start():
            xbmcgui.Dialog().notification(
                "Erro no Proxy", 
                "Não foi possível iniciar o servidor local",
                xbmcgui.NOTIFICATION_ERROR
            )
            # Falhou ao iniciar o proxy, retorna False e encerra
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        # Sempre usar 127.0.0.1 para a URL de reprodução do Kodi
        proxy_url = (
            f"http://127.0.0.1:{self.proxy.active_port}/"
            f"?url={urllib.parse.quote_plus(url)}"
        )
        
        li = xbmcgui.ListItem(path=proxy_url)
        if title:
            li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        
        # O MIME type é fundamental para o Kodi saber como tratar a stream
        li.setMimeType("application/vnd.apple.mpegurl") # Mantido o tipo HLS genérico
        
        # O Kodi irá usar esta URL para iniciar o player
        xbmcplugin.setResolvedUrl(self.handle, True, li)

# Variável global para gerenciar o proxy. Usada para garantir que o proxy pare ao fechar.
__proxy_manager: Optional[HLSProxyManager] = None
__has_resolved: bool = False # Flag para controlar se setResolvedUrl foi chamado

# ---------------- PONTO DE ENTRADA E LIMPEZA ----------------
def main() -> None:
    """Ponto de entrada principal com tratamento robusto de erros."""
    setup_logging()
    
    global __has_resolved
    
    # ---------------- LÓGICA DE ENTRADA DO KODI ----------------
    try:
        handle = int(sys.argv[1])
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        action = args.get('action', [''])[0]

        if action == 'play_stream':
            stream_url = args.get('stream_url', [''])[0]
            stream_type = args.get('stream_type', ['live'])[0]
            title = args.get('title', [''])[0]

            if stream_url:
                addon = HLSAddon(handle)
                addon.play_stream(stream_url, stream_type, title)
                __has_resolved = True # Marcamos que setResolvedUrl foi chamado
            else:
                logging.error("Ação 'play_stream' sem 'stream_url'")
                xbmcplugin.endOfDirectory(handle, succeeded=False)
                __has_resolved = True
        else:
            xbmcplugin.endOfDirectory(handle)
            __has_resolved = True
            
    except Exception as e:
        logging.error(f"Erro fatal: {e}", exc_info=True)
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        if handle != -1 and not __has_resolved:
            xbmcplugin.endOfDirectory(handle, succeeded=False)

    # ---------------- LÓGICA DE LIMPEZA DO KODI ----------------
    # A chamada para stop() deve ocorrer aqui, no final da execução do script Python
    # que chamou setResolvedUrl, garantindo que o servidor permaneça ativo durante a reprodução.
    global __proxy_manager
    if __proxy_manager:
        logging.info("Encerrando execução do script Kodi. Tentando parar o proxy agora...")
        __proxy_manager.stop()


if __name__ == '__main__':
    main()