# -*- coding: utf-8 -*-

# ==============================================================================
# MÓDULOS PADRÃO E DE TERCEIROS
# ==============================================================================
import sys
import os
import threading
import time
import random
import logging
import logging.handlers
import queue
import urllib.parse
from collections import OrderedDict
from typing import Optional, Dict, Any, List, Tuple

# ==============================================================================
# MÓDULOS KODI
# ==============================================================================
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import xbmcaddon

# ==============================================================================
# MÓDULOS DO PROXY (INCLUINDO FLASK)
# ==============================================================================
import requests as requests_
import m3u8
import ipaddress
from werkzeug.serving import make_server
from requests.exceptions import RequestException

try:
    from flask import Flask, request, Response, make_response, stream_with_context
except ImportError:
    xbmcgui.Dialog().ok("Erro de Dependência", "O addon 'script.module.flask' não foi encontrado. Por favor, instale-o para que o HLS Tester funcione.")
    sys.exit(1)

# ==============================================================================
# --- CONFIGURAÇÕES DE OTIMIZAÇÃO E COMPORTAMENTO ---
# ==============================================================================
MAX_CONSECUTIVE_SEGMENT_FAILURES = 1
FETCHER_MAX_RETRIES = 2
RETRY_BACKOFF_FACTOR = 0.2
CONNECTION_TIMEOUT = 10.0
STREAM_TIMEOUT = 10.0
DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1 MB
LIVE_MANIFEST_REFRESH_TTL = 5 # TTL em segundos para manifestos ao vivo.
ADDON_ID = "script.hls.tester"
ADDON_NAME = "HLS TESTER"
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 10
USER_AGENTS = [
    "ExoPlayer/2.18.7 (Linux; Android 13) (Build/TP1A.220624.014)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.128 Mobile Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1"
]
LOG_MAX_BYTES = 1048576 * 2  # 2 MB
LOG_BACKUP_COUNT = 1
ADDON_DATA_PATH = xbmcvfs.translatePath(xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('profile'))
LOG_FILE = os.path.join(ADDON_DATA_PATH, 'hlsproxy_flask.log')
LOG_LEVEL = logging.INFO

_SENSITIVE_HEADERS = {'X-Forwarded-For', 'Forwarded', 'Via', 'X-Real-IP',
                      'Client-IP', 'X-Client-IP', 'X-Cluster-Client-IP',
                      'Content-Length', 'Connection', 'Transfer-Encoding'}
_SENSITIVE_HEADERS_LOWER = {h.lower() for h in _SENSITIVE_HEADERS}

# Dicionário para gerenciar o User-Agent por stream. A chave será a URL base do manifesto.
# Valor será uma tupla: (timestamp_da_ultima_troca, user_agent_atual)
_user_agent_cache: Dict[str, Tuple[float, str]] = {}
_cache_lock = threading.Lock()

# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS ---
# ==============================================================================
def setup_logging():
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        xbmcvfs.mkdir(ADDON_DATA_PATH)
    log_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT, encoding='utf-8'
    )
    logging.basicConfig(
        handlers=[log_handler],
        level=LOG_LEVEL,
        format='%(asctime)s [%(levelname)s] [Thread-%(thread)d] %(message)s',
        force=True
    )

def is_valid_ip(address: str) -> bool:
    try:
        ipaddress.ip_address(address)
        return True
    except ValueError:
        return False

def clean_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _SENSITIVE_HEADERS_LOWER}

def get_rotating_user_agent(base_url: str) -> str:
    """
    Retorna um User-Agent para a URL base. Se o TTL expirou, um novo é selecionado.
    """
    with _cache_lock:
        now = time.time()
        last_change, user_agent = _user_agent_cache.get(base_url, (0, random.choice(USER_AGENTS)))
        
        if (now - last_change) > LIVE_MANIFEST_REFRESH_TTL:
            new_user_agent = random.choice([ua for ua in USER_AGENTS if ua != user_agent] or USER_AGENTS)
            _user_agent_cache[base_url] = (now, new_user_agent)
            logging.info(f"User-Agent rotacionado para {base_url}: {new_user_agent}")
            return new_user_agent
        else:
            return user_agent

def get_player_headers(url: str, user_agent: str) -> Dict[str, str]:
    parts = urllib.parse.urlparse(url)
    origin = f"{parts.scheme}://{parts.netloc}"
    return {
        "User-Agent": user_agent,
        "Accept": "*/*",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": origin,
        "X-Forwarded-For": "1.1.1.1"
    }

def safe_mime_type(url: str) -> str:
    path = urllib.parse.urlparse(url).path.lower()
    if path.endswith(('.m3u8', '.m3u')):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.aac'):
        return 'audio/aac'
    if path.endswith('.mp4'):
        return 'video/mp4'
    return 'application/octet-stream'

def is_manifest_limit_error(content: Optional[str]) -> bool:
    if not content: return True
    txt = content.lower().strip()
    if not txt or txt == "#extm3u": return True
    keywords = ["limite", "limit", "too many", "maximum user", "conexoes", "connections",
                "max session", "#error", "offline", "geoblocked", "stream not found",
                "access denied", "blocked", "forbidden", "unavailable", "invalid"]
    return any(keyword in txt for keyword in keywords)


# ==============================================================================
# --- CLASSES DE REDE ---
# ==============================================================================

class UpstreamFetcher:
    def __init__(self, session: requests_.Session):
        self.session = session

    def fetch(self, url: str, user_agent: str, stream: bool = False, original_headers: Optional[Dict] = None) -> requests_.Response:
        headers = get_player_headers(url, user_agent)
        if original_headers:
            cleaned_original = clean_headers(original_headers)
            headers.update({k: v for k, v in cleaned_original.items() if k in ['Authorization', 'Cookie']})

        for attempt in range(FETCHER_MAX_RETRIES + 1):
            try:
                resp = self.session.get(
                    url, stream=stream, timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT),
                    headers=headers, allow_redirects=True, verify=False
                )
                resp.raise_for_status()
                return resp
            except requests_.RequestException as e:
                logging.warning(f"[Fetcher] Tentativa {attempt + 1} falhou para {url}: {e}")
                if attempt < FETCHER_MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))
                else:
                    raise

class ManifestRewriter:
    def __init__(self, content: str, manifest_url: str, proxy_base_url: str):
        self.m3u8_obj = m3u8.loads(content, uri=manifest_url)
        self.proxy_base_url = proxy_base_url

    def rewrite(self) -> str:
        items_to_rewrite = (
            getattr(self.m3u8_obj, 'playlists', []) +
            getattr(self.m3u8_obj, 'media', []) +
            getattr(self.m3u8_obj, 'segments', [])
        )
        for item in items_to_rewrite:
            if hasattr(item, 'uri') and item.uri:
                item.uri = self.proxy_base_url + urllib.parse.quote_plus(item.absolute_uri)
            if hasattr(item, 'key') and item.key and item.key.uri and not item.key.uri.startswith("data:"):
                item.key.uri = self.proxy_base_url + urllib.parse.quote_plus(item.key.absolute_uri)
        return self.m3u8_obj.dumps()

    @property
    def is_live(self) -> bool:
        return not getattr(self.m3u8_obj, 'is_endlist', True)

    def get_ttl(self) -> int:
        if self.is_live:
            return LIVE_MANIFEST_REFRESH_TTL
        else:
            return 3600

# ==============================================================================
# --- APLICAÇÃO FLASK E ROTAS DO PROXY ---
# ==============================================================================
app = Flask(__name__)
http_session = requests_.Session()
fetcher = UpstreamFetcher(http_session)

# Cache para armazenar o user-agent por URL principal do stream
# A chave é o encoded_url do manifesto principal
_stream_user_agents: Dict[str, str] = {}
_stream_lock = threading.Lock()

@app.route('/proxy/<path:encoded_url>', methods=['GET'])
def proxy_handler(encoded_url):
    decoded_url = urllib.parse.unquote_plus(encoded_url)
    logging.info(f"Requisição para: {decoded_url}")

    # Use a URL completa para determinar o User-Agent
    # Para o proxy, é mais simples usar a URL decodificada para o cache
    # pois a URL principal do manifesto pode ser diferente das URLs de segmentos.
    # Vamos usar a URL decodificada do *primeiro manifesto* como a chave de sessão.
    
    # Para garantir que segmentos e manifestos secundários usem o mesmo UA do manifesto principal
    # que os originou, passaremos o UA no contexto da requisição. Isso é mais complexo.
    # Uma abordagem mais simples é usar a url completa para o cache.
    # O cache rotacionará o UA para CADA url, o que pode não ser ideal, mas resolve o problema
    # de bloqueio de forma mais geral.

    user_agent = get_rotating_user_agent(decoded_url)

    if decoded_url.lower().endswith(('.m3u8', '.m3u')):
        return handle_manifest(decoded_url, user_agent)
    else:
        return handle_segment(decoded_url, user_agent)

def handle_manifest(url: str, user_agent: str):
    proxy_base_url = f"{request.url_root}proxy/"

    try:
        logging.info(f"[Manifesto] Buscando da fonte: {url} com User-Agent: {user_agent}")
        resp = fetcher.fetch(url, user_agent, original_headers=request.headers)
        content = resp.text

        if is_manifest_limit_error(content):
            logging.warning("[Manifesto] Conteúdo indica erro de limite. Retornando manifesto de erro temporário.")
            return Response(
                "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1,RESOLUTION=1x1\nindex.m3u8",
                mimetype='application/vnd.apple.mpegurl',
                status=503
            )

        rewriter = ManifestRewriter(content, url, proxy_base_url)
        rewritten_manifest = rewriter.rewrite()
        
        response = Response(rewritten_manifest, mimetype='application/vnd.apple.mpegurl')
        response.headers['Cache-Control'] = f'max-age={rewriter.get_ttl()}'
        
        return response

    except requests_.RequestException as e:
        logging.error(f"[Manifesto] Erro ao buscar {url}: {e}")
        return Response(
            "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-TARGETDURATION:10\n#EXT-X-MEDIA-SEQUENCE:0\n",
            status=503,
            mimetype='application/vnd.apple.mpegurl'
        )

def handle_segment(url: str, user_agent: str):
    try:
        logging.debug(f"[Segmento] Buscando da fonte: {url} com User-Agent: {user_agent}")
        resp = fetcher.fetch(url, user_agent, stream=True, original_headers=request.headers)

        chunk_size = DEFAULT_CHUNK_SIZE

        def generate():
            for chunk in resp.iter_content(chunk_size=chunk_size):
                yield chunk

        response = Response(stream_with_context(generate()), mimetype=safe_mime_type(url))
        response.headers['Content-Length'] = resp.headers.get('Content-Length')
        return response
    
    except requests_.RequestException as e:
        logging.error(f"[Segmento] Erro ao buscar {url}: {e}")
        return Response(
            f"Erro ao buscar segmento: {e}",
            status=500
        )

# ==============================================================================
# --- SERVIDOR FLASK EM SEGUNDO PLANO ---
# ==============================================================================
class ServerThread(threading.Thread):
    def __init__(self, app: Flask, host: str, port: int):
        super().__init__()
        self.app = app
        self.host = host
        self.port = port
        self.server: Optional[Any] = None
        self.daemon = True

    def run(self):
        logging.info(f"Iniciando o servidor Flask em http://{self.host}:{self.port}")
        self.server = make_server(self.host, self.port, self.app, threaded=True)
        self.server.serve_forever()

    def shutdown(self):
        if self.server:
            logging.info("Encerrando o servidor Flask...")
            self.server.shutdown()
            logging.info("Servidor Flask encerrado.")

# ==============================================================================
# --- LÓGICA DO ADDON KODI E PONTO DE ENTRADA PRINCIPAL ---
# ==============================================================================
_server_thread: Optional[ServerThread] = None
_proxy_port: Optional[int] = None

def get_proxy_port() -> Optional[int]:
    return _proxy_port

def run_proxy_server():
    global _server_thread, _proxy_port
    if _server_thread and _server_thread.is_alive():
        logging.info("Servidor do proxy já está rodando.")
        return

    for port_offset in range(MAX_PORT_ATTEMPTS):
        try:
            port = 55000 + port_offset
            server_thread = ServerThread(app, PROXY_HOST, port)
            server_thread.start()
            
            time.sleep(1)

            if server_thread.is_alive():
                _server_thread = server_thread
                _proxy_port = port
                logging.info(f"Servidor Flask iniciado com sucesso na porta {port}.")
                return
            else:
                logging.warning(f"Tentativa de iniciar o servidor na porta {port} falhou. Tentando próxima porta...")
        except Exception as e:
            logging.warning(f"Erro ao iniciar o servidor na porta {port}: {e}. Tentando próxima porta...")

    logging.error("Não foi possível iniciar o servidor Flask em nenhuma das portas disponíveis.")

def stop_proxy_server():
    global _server_thread
    if _server_thread:
        _server_thread.shutdown()
        _server_thread = None
        logging.info("Servidor do proxy parado.")

def show_test_streams(handle):
    xbmcplugin.setPluginCategory(handle, 'HLS Streams de Teste')
    streams = [
        ("Live Stream Teste (HLS)", "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8"),
        ("Conteúdo VOD Teste (HLS)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8")
    ]
    
    for name, url in streams:
        list_item = xbmcgui.ListItem(label=name)
        list_item.setProperty('IsPlayable', 'true')
        plugin_url = f"{sys.argv[0]}?action=play&url={urllib.parse.quote_plus(url)}&title={urllib.parse.quote_plus(name)}"
        xbmcplugin.addDirectoryItem(handle, plugin_url, list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(handle)

def play_stream(handle, url, title):
    run_proxy_server()
    
    if get_proxy_port():
        proxy_url = f"http://{PROXY_HOST}:{get_proxy_port()}/proxy/{urllib.parse.quote_plus(url)}"
        
        logging.info(f"Preparando para reproduzir stream através do proxy: {proxy_url}")
        
        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setInfo(type='Video', infoLabels={'title': title})
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(handle, True, list_item)
    else:
        xbmcgui.Dialog().ok("Erro", "Não foi possível iniciar o proxy para reproduzir o stream.")


def main():
    setup_logging()
    
    try:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        addon_base = sys.argv[0]
        params_str = sys.argv[2][1:] if len(sys.argv) > 2 else ''
        params = dict(urllib.parse.parse_qsl(params_str))
        
        action = params.get('action')

        if not action:
            show_test_streams(handle)
        elif action == 'play':
            url_to_play = params.get('url')
            title = params.get('title')
            if url_to_play:
                play_stream(handle, url_to_play, title)
            else:
                xbmcgui.Dialog().ok("Erro", "URL de reprodução não fornecida.")
        else:
            xbmcgui.Dialog().ok("Erro", "Ação desconhecida.")

    except Exception as e:
        logging.error(f"Erro na execução do addon: {e}", exc_info=True)


if __name__ == "__main__":
    main()
