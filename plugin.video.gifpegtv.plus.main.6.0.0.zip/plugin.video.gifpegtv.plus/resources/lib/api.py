# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
import xbmcaddon # CORREÇÃO: Necessário para obter o path do perfil
import json
import os
import xbmcvfs
import time
import hashlib
import requests # ALTERAÇÃO: Usando requests padrão do Python

# Constantes de Cache
CACHE_TTL = 3600  # 1 hora em segundos para o cache da API
# Tentativa de obter o caminho do perfil do addon
try:
    ADDON_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
except Exception as e:
    # Fallback, caso a execução esteja fora do ambiente Kodi para evitar quebra total
    ADDON_PROFILE = xbmcvfs.translatePath(os.path.join(os.getcwd(), 'profile_cache'))
    xbmc.log(f"[XtreamProxy] Fallback para ADDON_PROFILE: {e}", level=xbmc.LOGERROR)

def get_cache_path(key):
    """Gera um caminho de arquivo de cache único baseado em uma chave."""
    if not xbmcvfs.exists(ADDON_PROFILE):
        xbmcvfs.mkdirs(ADDON_PROFILE)
    # Usa um hash para o nome do arquivo para evitar problemas de caminho
    filename = hashlib.sha1(key.encode('utf-8')).hexdigest()
    return os.path.join(ADDON_PROFILE, f"cache_{filename}.json")

def read_cache(key):
    """Lê o cache se não estiver expirado."""
    cache_file = get_cache_path(key)
    if not os.path.exists(cache_file):
        return None
    
    # Verifica TTL
    file_age = time.time() - os.path.getmtime(cache_file)
    if file_age > CACHE_TTL:
        xbmc.log(f"[XtreamProxy] Cache expirado para {key}. Idade: {file_age:.0f}s", level=xbmc.LOGINFO)
        return None

    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        xbmc.log(f"[XtreamProxy] Cache HIT para {key}", level=xbmc.LOGINFO)
        return data
    except Exception as e:
        xbmc.log(f"[XtreamProxy] Erro ao ler cache: {e}", level=xbmc.LOGERROR)
        return None

def write_cache(key, data):
    """Escreve dados no cache."""
    cache_file = get_cache_path(key)
    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        xbmc.log(f"[XtreamProxy] Erro ao escrever cache: {e}", level=xbmc.LOGERROR)

class XtreamAPI:
    def __init__(self, server, username, password):
        self.base_url = f"{server}"
        self.username = username
        self.password = password
        # Chave base para o cache da API (para diferenciar servidores/usuários)
        self.cache_base_key = f"{server}-{username}"
        # CORREÇÃO: Inicializa corretamente a sessão padrão (requests.Session())
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': 'Mozilla/5.0'})

    def _make_request(self, params):
        action = params.get('action', 'unknown')
        cache_key = f"{self.cache_base_key}-{action}-{params.get('category_id', 'all')}-{params.get('series_id', 'all')}"
        
        # 1. Tenta ler do cache
        cached_data = read_cache(cache_key)
        if cached_data is not None:
            return cached_data
            
        params['username'] = self.username
        params['password'] = self.password
        try:
            # Aumentar o timeout para listagens iniciais em caso de servidor lento
            response = self.session.get(f"{self.base_url}/player_api.php", params=params, timeout=100) 
            response.raise_for_status()
            
            if response.text.strip() == "[]":
                result_data = []
            else:
                data = response.json()
                if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
                    xbmcgui.Dialog().ok("Erro de Autenticação", "Usuário ou senha inválidos.")
                    return None
                result_data = data

            # 2. Escreve no cache após sucesso
            write_cache(cache_key, result_data)
            return result_data
            
        except requests.exceptions.RequestException as e:
            xbmc.log(f"[XtreamProxy] Erro de API: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Conexão", f"Não foi possível conectar ao servidor: {e}")
            return None
        except ValueError:
            xbmc.log(f"[XtreamProxy] Erro de API: Resposta não é JSON válido.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Servidor", "O servidor retornou uma resposta inválida.")
            return None

    def get_live_categories(self):
        return self._make_request({'action': 'get_live_categories'})

    def get_live_streams(self, category_id=None):
        params = {'action': 'get_live_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_vod_categories(self):
        return self._make_request({'action': 'get_vod_categories'})

    def get_vod_streams(self, category_id=None):
        params = {'action': 'get_vod_streams'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_categories(self):
        return self._make_request({'action': 'get_series_categories'})

    def get_series(self, category_id=None):
        params = {'action': 'get_series'}
        if category_id:
            params['category_id'] = category_id
        return self._make_request(params)

    def get_series_info(self, series_id):
        return self._make_request({'action': 'get_series_info', 'series_id': series_id})

    def get_live_stream_url(self, stream_id):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.m3u8"

    def get_vod_stream_url(self, stream_id):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.mp4"

    def get_series_stream_url(self, stream_id):
        return f"{self.base_url}/series/{self.username}/{self.password}/{stream_id}.mp4"