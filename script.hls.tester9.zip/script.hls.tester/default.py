import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import urllib.parse
import http.server
import socketserver
import threading
import time
import requests
import m3u8
import os
import re
import socket
import json
from functools import lru_cache
from collections import defaultdict
from typing import Optional, Dict, Tuple, List

# --- Configurações Globais ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE = int(sys.argv[1])

# Configurações de proxy dinâmico
DEFAULT_PROXY_PORT = 65323  # Porta inicial. 0 = sistema escolhe porta livre
PROXY_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 5  # Número máximo de tentativas para encontrar porta livre

# Configurações de desempenho
CHUNK_SIZE = 8192 * 4  # Aumentado para melhor throughput (32KB)
CONNECTION_TIMEOUT = 15  # segundos para estabelecer conexão
STREAM_TIMEOUT = 30  # segundos para ler dados do stream
MAX_CACHE_SIZE = 100  # Itens no cache LRU

# Sessão HTTP otimizada
HTTP_SESSION = requests.Session()
HTTP_SESSION.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate', # Aceita compressão para economia de banda
    'Connection': 'keep-alive' # Mantém a conexão HTTP viva para melhor desempenho
})
# A verificação de SSL é True por padrão no requests, o que é seguro.

# Configurações avançadas de adaptação (HLS)
ADAPTIVE_STREAMING = True  # Habilita ajuste dinâmico de qualidade para HLS
MIN_BITRATE = 500000  # 500 kbps (para o monitor de banda interno)
MAX_BITRATE = 8000000  # 8 Mbps (para o monitor de banda interno)
BANDWIDTH_MONITOR_WINDOW = 10  # Número de segmentos para calcular média de banda

# --- Sistema de Log Melhorado ---
class KodiLogger:
    @staticmethod
    def log(msg: str, level: int = xbmc.LOGINFO):
        """Log formatado com nome do addon e níveis personalizados"""
        level_map = {
            'DEBUG': xbmc.LOGDEBUG,
            'INFO': xbmc.LOGINFO,
            'WARNING': xbmc.LOGWARNING,
            'ERROR': xbmc.LOGERROR,
            'FATAL': xbmc.LOGFATAL
        }
        if isinstance(level, str):
            level = level_map.get(level.upper(), xbmc.LOGINFO)
        xbmc.log(f"[{ADDON_NAME}] {msg}", level)

    @staticmethod
    def debug(msg: str):
        KodiLogger.log(msg, xbmc.LOGDEBUG)

    @staticmethod
    def info(msg: str):
        KodiLogger.log(msg, xbmc.LOGINFO)

    @staticmethod
    def warning(msg: str):
        KodiLogger.log(msg, xbmc.LOGWARNING)

    @staticmethod
    def error(msg: str):
        KodiLogger.log(msg, xbmc.LOGERROR)

# Mapeia as funções de log para facilitar o uso
log = KodiLogger.log
debug = KodiLogger.debug
info = KodiLogger.info
warning = KodiLogger.warning
error = KodiLogger.error

# --- DNS over HTTPS (DoH) Resolver ---
class DoHResolver:
    # Google Public DNS-over-HTTPS. Pode ser substituído por outros provedores como Cloudflare (https://cloudflare-dns.com/dns-query)
    DOH_URL = "https://dns.nextdns.io/37d9d4" 

    @staticmethod
    @lru_cache(maxsize=128) # Cache para resultados de DNS para evitar requisições repetidas
    def resolve(hostname: str) -> Optional[str]:
        """Resolve um hostname para um endereço IP usando DNS-over-HTTPS."""
        if not hostname:
            return None
        
        # Se o hostname já é um endereço IP válido, retorna-o diretamente.
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", hostname):
            debug(f"DoH: Hostname '{hostname}' já é um IP. Não resolvendo via DoH.")
            return hostname

        try:
            # Construindo a URL da requisição DoH para obter registros A (IPv4)
            query_url = f"{DoHResolver.DOH_URL}?name={hostname}&type=A"
            headers = {"Accept": "application/dns-json"}

            # Usando a mesma sessão HTTP global para a requisição DoH
            # Timeout para evitar bloqueios longos em caso de problemas de rede.
            response = HTTP_SESSION.get(query_url, headers=headers, timeout=5)
            response.raise_for_status() # Levanta um erro para respostas HTTP de erro
            
            data = response.json() # Decodifica a resposta JSON
            if data and "Answer" in data:
                for answer in data["Answer"]:
                    if answer.get("type") == 1: # Tipo 1 indica um registro A (IPv4)
                        info(f"DoH: Hostname '{hostname}' resolvido para IP '{answer['data']}' via DoH.")
                        return answer["data"] # Retorna o primeiro IP encontrado
            warning(f"DoH: Nenhuma resposta A encontrada para {hostname}.")
            return None
        except requests.exceptions.RequestException as e:
            error(f"DoH: Erro ao resolver {hostname} via DoH: {e}")
            return None
        except json.JSONDecodeError as e:
            error(f"DoH: Erro ao decodificar resposta JSON para {hostname}: {e}")
            return None
        except Exception as e:
            error(f"DoH: Erro inesperado ao resolver {hostname}: {e}")
            return None

# --- Monitor de Banda Larga Inteligente ---
class BandwidthMonitor:
    def __init__(self, window_size: int = BANDWIDTH_MONITOR_WINDOW):
        self.window_size = window_size
        self.samples = [] # Armazena o tamanho em bytes dos segmentos transferidos
        self.timestamps = [] # Armazena o tempo em que cada segmento foi processado
        
    def add_sample(self, bytes_transferred: int):
        """Adiciona uma nova amostra de transferência de bytes e seu timestamp."""
        now = time.time()
        self.samples.append(bytes_transferred)
        self.timestamps.append(now)
        
        # Mantém apenas as amostras mais recentes, conforme a janela de tempo definida
        if len(self.samples) > self.window_size:
            self.samples.pop(0)
            self.timestamps.pop(0)
    
    def get_bandwidth(self) -> float:
        """Calcula a largura de banda média em bits por segundo (bps) com base nas amostras."""
        if len(self.samples) < 2: # São necessárias pelo menos duas amostras para calcular um intervalo de tempo
            return 0.0 # Retorna 0 se não houver dados suficientes
            
        total_bytes = sum(self.samples)
        time_span = self.timestamps[-1] - self.timestamps[0] # Calcula o período total das amostras
        
        if time_span <= 0: # Evita divisão por zero ou resultados inválidos
            return 0.0
            
        return (total_bytes * 8) / time_span  # Converte bytes para bits e divide pelo tempo

# --- Cache Inteligente para Manifestos e Segmentos ---
class StreamCache:
    def __init__(self, max_size: int = MAX_CACHE_SIZE):
        self.max_size = max_size
        self.manifest_cache = {} # Cache para manifestos HLS (M3U8)
        self.segment_cache = {}  # Cache para segmentos de mídia (TS, MP4, etc.)
        self.access_times = {}   # Armazena o último tempo de acesso para cada item (para política LRU)
        self.current_size = 0    # Tamanho total aproximado do cache de segmentos em bytes
        
    def get_manifest(self, url: str) -> Optional[str]:
        """Obtém um manifesto do cache se ele existir e ainda não estiver expirado."""
        entry = self.manifest_cache.get(url)
        if entry and time.time() < entry['expires']:
            self.access_times[url] = time.time() # Atualiza o tempo de acesso (LRU)
            return entry['content']
        return None
        
    def add_manifest(self, url: str, content: str, ttl: int = 10):
        """Adiciona um manifesto ao cache com um Tempo de Vida (TTL) em segundos."""
        if len(self.manifest_cache) >= self.max_size:
            self._evict_oldest() # Remove o item mais antigo se o cache estiver cheio
            
        self.manifest_cache[url] = {
            'content': content,
            'expires': time.time() + ttl
        }
        self.access_times[url] = time.time()
        
    def get_segment(self, url: str) -> Optional[bytes]:
        """Obtém um segmento de mídia do cache."""
        if url in self.segment_cache:
            self.access_times[url] = time.time()
            return self.segment_cache[url]
        return None
        
    def add_segment(self, url: str, data: bytes):
        """Adiciona um segmento de mídia ao cache."""
        if len(self.segment_cache) >= self.max_size:
            self._evict_oldest()
            
        self.segment_cache[url] = data
        self.access_times[url] = time.time()
        self.current_size += len(data)
        
    def _evict_oldest(self):
        """
        Remove o item menos recentemente usado (Least Recently Used - LRU)
        do cache para liberar espaço quando o limite de tamanho é atingido.
        """
        if not self.access_times:
            return
            
        oldest_url = min(self.access_times, key=self.access_times.get)
        if oldest_url in self.manifest_cache:
            del self.manifest_cache[oldest_url]
        if oldest_url in self.segment_cache:
            self.current_size -= len(self.segment_cache[oldest_url])
            del self.segment_cache[oldest_url]
        del self.access_times[oldest_url]

# --- Manipulador de Proxy Avançado ---
class AdvancedHLSProxyHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # A instância do cache e do monitor de banda é criada por handler,
        # o que significa que cada requisição HTTP interna ao proxy terá seu próprio estado.
        # Para um cache e monitor global, eles precisariam ser passados ou serem atributos de classe.
        # Para este caso de uso (um único stream por vez), ter instâncias por handler é aceitável,
        # mas pode não ser ideal para múltiplos streams simultâneos.
        self.cache = StreamCache() 
        self.bw_monitor = BandwidthMonitor()
        self.adaptive_streaming = ADAPTIVE_STREAMING
        super().__init__(*args, **kwargs)
    
    def log_message(self, format, *args):
        """Suprime logs padrão do HTTP server para evitar poluir o log do Kodi."""
        pass
    
    def do_GET(self):
        """
        Processa requisições GET.
        Identifica se a requisição é para um manifesto HLS ou um segmento de mídia (incluindo TS).
        """
        start_time = time.time()
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            # A URL original é codificada no caminho do proxy, então precisamos decodificá-la.
            original_url = urllib.parse.unquote_plus(parsed_path.path.lstrip('/'))
            
            debug(f"Requisição recebida pelo proxy para URL original: {original_url}")
            
            # Decide se é um manifesto HLS ou um stream/segmento de mídia (incluindo TS)
            if ".m3u8" in original_url.lower() or "manifest" in original_url.lower(): # Adicionada "manifest" para maior robustez
                self._handle_manifest(original_url)
            else:
                # Para qualquer outra URL, trata como um segmento ou stream direto (TS, MP4, etc.)
                self._handle_media_stream(original_url)
                
        except Exception as e:
            error(f"Erro geral ao processar requisição no proxy para '{self.path}': {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
        finally:
            debug(f"Tempo de processamento da requisição para '{self.path}': {(time.time() - start_time):.2f}s")
    
    def _handle_manifest(self, url: str):
        """
        Busca e processa manifestos M3U8 (HLS).
        Reescreve URLs internas e pode ajustar a qualidade dinamicamente.
        """
        cached = self.cache.get_manifest(url)
        if cached:
            debug(f"Retornando manifesto do cache: {url}")
            self._send_response(200, cached, 'application/vnd.apple.mpegurl')
            return
            
        try:
            response = self._fetch_url(url, stream=False) # stream=False para manifestos (texto)
            if not response:
                self.send_error(502, "Bad Gateway")
                return
                
            parsed_m3u8 = m3u8.loads(response.text, uri=url) # Parseia o manifesto M3U8
            
            # Ajuste dinâmico de qualidade baseado na banda disponível (apenas para HLS)
            if self.adaptive_streaming and parsed_m3u8.playlists:
                bandwidth = self.bw_monitor.get_bandwidth()
                if bandwidth > 0:
                    self._adjust_quality(parsed_m3u8, bandwidth)
            
            # Reescreve URLs de playlists e segmentos para apontar para este proxy
            actual_port = self.server.server_address[1]
            base_proxy_url = f"http://{PROXY_HOST}:{actual_port}/"
            
            # Itera sobre todas as playlists e segmentos para reescrever as URLs
            for playlist in parsed_m3u8.playlists:
                # Codifica a URL original do segmento para ser passada como parte da URL do proxy
                playlist.uri = base_proxy_url + urllib.parse.quote_plus(playlist.absolute_uri)
                
            for segment in parsed_m3u8.segments:
                segment.uri = base_proxy_url + urllib.parse.quote_plus(segment.absolute_uri)
                # Se o segmento tiver chaves (DRM), garantir que seus URIs também sejam reescritos
                if segment.key and segment.key.uri:
                    segment.key.uri = base_proxy_url + urllib.parse.quote_plus(segment.key.absolute_uri)
                
            rewritten = parsed_m3u8.dumps() # Gera o manifesto M3U8 reescrito
            self.cache.add_manifest(url, rewritten) # Adiciona o manifesto reescrito ao cache
            
            self._send_response(200, rewritten, 'application/vnd.apple.mpegurl')
            
        except Exception as e:
            error(f"Erro ao processar manifesto {url}: {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
    
    def _handle_media_stream(self, url: str):
        """
        Processa segmentos de mídia ou streams diretos (ex: MPEG-TS, MP4).
        Atua como um pass-through, transmitindo os dados diretamente do servidor de origem para o cliente.
        """
        cached = self.cache.get_segment(url)
        if cached:
            debug(f"Retornando segmento/stream do cache: {url}")
            # Tenta inferir o tipo MIME a partir da URL para a resposta do cache
            content_type = self._get_mime_type_from_url(url)
            self._send_response(200, cached, content_type)
            return
            
        try:
            response = self._fetch_url(url, stream=True) # stream=True para lidar com arquivos grandes
            if not response:
                self.send_error(502, "Bad Gateway")
                return
                
            content_length = int(response.headers.get('Content-Length', 0))
            # Tenta obter o tipo MIME da resposta original, senão infere pela URL.
            content_type = response.headers.get('Content-Type', self._get_mime_type_from_url(url))
            
            data = bytearray() # Buffer para armazenar dados se for para cachear
            
            self.send_response(200)
            self.send_header('Content-Type', content_type) # Envia o tipo MIME correto
            self._copy_headers(response) # Copia outros cabeçalhos relevantes da resposta original
            self.end_headers()
            
            # Transmite os dados em chunks
            bytes_sent = 0
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    break
                data.extend(chunk) # Adiciona ao buffer para possível cache
                self.wfile.write(chunk) # Escreve o chunk diretamente para o cliente
                bytes_sent += len(chunk)
                
            # Atualiza o monitor de banda e, opcionalmente, cacheia o segmento.
            if content_length > 0 or data:
                actual_size = len(data) if data else content_length
                self.bw_monitor.add_sample(actual_size)
                
                # Cacheia segmentos apenas se forem de tamanho razoável para evitar esgotar a memória
                # e se o conteúdo foi totalmente lido e não era um stream infinito.
                if data and bytes_sent == actual_size and actual_size <= 5 * 1024 * 1024:  # Cache até 5MB
                    self.cache.add_segment(url, bytes(data))
                    
        except requests.exceptions.ChunkedEncodingError as e:
            warning(f"Erro de Chunked Encoding para {url}: {e}. O stream pode ter sido interrompido pelo cliente ou servidor.")
            # Não envia erro 500, pois pode ser uma interrupção esperada do cliente.
        except requests.exceptions.RequestException as e:
            error(f"Erro de rede/HTTP ao processar segmento/stream direto {url}: {e}")
            self.send_error(500, f"Network Error: {str(e)}")
        except Exception as e:
            error(f"Erro inesperado ao processar segmento/stream direto {url}: {e}")
            self.send_error(500, f"Internal Proxy Error: {str(e)}")
    
    def _get_mime_type_from_url(self, url: str) -> str:
        """Tenta inferir o tipo MIME de uma URL baseada na extensão do arquivo."""
        path = urllib.parse.urlparse(url).path
        if path.lower().endswith(('.ts', '.mpeg', '.mpg')):
            return 'video/mp2t' # MPEG Transport Stream
        elif path.lower().endswith(('.mp4', '.m4v')):
            return 'video/mp4'
        elif path.lower().endswith(('.m3u8')):
            return 'application/vnd.apple.mpegurl'
        elif path.lower().endswith(('.aac', '.mp3', '.m4a')):
            return 'audio/mpeg' # Ou audio/aac, audio/mp4
        else:
            return 'application/octet-stream' # Tipo genérico se não reconhecido
            
    def _adjust_quality(self, m3u8_obj: m3u8.M3U8, bandwidth: float):
        """
        Seleciona a melhor qualidade de stream HLS baseada na banda disponível.
        Reordena as playlists no manifesto para que o player Kodi dê preferência
        à qualidade mais adequada.
        """
        available_bandwidth = min(max(bandwidth, MIN_BITRATE), MAX_BITRATE)
        info(f"Banda disponível para ajuste de qualidade: {available_bandwidth/1e6:.2f} Mbps")
        
        # Filtra playlists que não têm informações de banda ou são muito lentas para o que queremos.
        eligible_playlists = [p for p in m3u8_obj.playlists if p.stream_info.bandwidth and p.stream_info.bandwidth >= MIN_BITRATE]
        
        if not eligible_playlists:
            warning("Nenhuma playlist HLS elegível encontrada para ajuste de qualidade.")
            return

        best_playlist = None
        closest_diff = float('inf')
        
        # Prioriza playlists que estão dentro da banda disponível ou ligeiramente acima (tolerância de 20%)
        for playlist in eligible_playlists:
            playlist_bandwidth = playlist.stream_info.bandwidth
            
            # Calcula a diferença para a banda disponível
            diff = abs(playlist_bandwidth - available_bandwidth)
            
            # Critério de seleção:
            # 1. Se a playlist estiver abaixo ou no limite de 1.2x da banda disponível.
            # 2. Se for a primeira playlist considerada ou se a diferença for menor que a melhor encontrada até agora.
            if playlist_bandwidth <= available_bandwidth * 1.2: 
                if best_playlist is None or diff < closest_diff:
                    closest_diff = diff
                    best_playlist = playlist
                
        if best_playlist:
            # Reordena as playlists no objeto M3U8 para colocar a melhor opção primeiro.
            # O Kodi e o inputstream.ffmpegdirect tendem a escolher a primeira opção adequada.
            m3u8_obj.playlists.sort(
                key=lambda p: (
                    0 if p == best_playlist else 1, # Coloca a melhor playlist na frente (prioridade)
                    abs(p.stream_info.bandwidth - best_playlist.stream_info.bandwidth) if p.stream_info.bandwidth else float('inf') # Critério secundário de ordenação
                )
            )
            info(f"Qualidade HLS ajustada no manifesto para: {best_playlist.stream_info.bandwidth/1e6:.2f} Mbps (Original: {best_playlist.uri})")
        else:
            # Se nenhuma playlist foi selecionada pelos critérios, mantém a ordem original ou a mais alta disponível.
            # O ideal é o ffmpegdirect ainda conseguir escolher, mas este log ajuda a depurar.
            warning(f"Não foi possível encontrar uma playlist HLS adequada para a banda: {available_bandwidth/1e6:.2f} Mbps. Mantendo ordem original.")

    def _fetch_url(self, url: str, stream: bool = False) -> Optional[requests.Response]:
        """
        Busca uma URL externa com tratamento de erros robusto.
        Tenta resolver o IP via DoH para conexões HTTP, para ignorar o DNS padrão do sistema.
        Para HTTPS, delega a resolução ao requests para garantir a validação SSL/TLS.
        """
        parsed_url = urllib.parse.urlparse(url)
        hostname = parsed_url.hostname
        scheme = parsed_url.scheme

        headers = HTTP_SESSION.headers.copy()
        # Adiciona o cabeçalho 'Referer' para a requisição externa.
        if parsed_url.scheme and parsed_url.netloc:
            headers['Referer'] = f"{parsed_url.scheme}://{parsed_url.netloc}"

        target_url = url
        connection_type_log = "DNS Padrão" # Default logging
        
        if scheme == 'http': # Aplica DoH apenas para HTTP para evitar problemas de SSL/SNI
            resolved_ip = DoHResolver.resolve(hostname)
            if resolved_ip:
                # Reconstrói a URL para usar o IP diretamente no lugar do hostname.
                # Ex: http://1.2.3.4:80/path/to/stream.ts
                target_url = urllib.parse.urlunparse(
                    parsed_url._replace(netloc=f"{resolved_ip}:{parsed_url.port}" if parsed_url.port else resolved_ip)
                )
                # É CRUCIAL enviar o Host header original, pois o servidor remoto precisa saber qual domínio ele está atendendo.
                headers['Host'] = hostname 
                connection_type_log = f"HTTP via IP (DoH) -> {resolved_ip}"
            else:
                connection_type_log = "HTTP via Hostname (DNS Padrão)"
                warning(f"DoH: Não foi possível resolver '{hostname}' via DoH para HTTP, usando DNS padrão do sistema.")
        elif scheme == 'https':
            connection_type_log = "HTTPS via Hostname (SSL/TLS)"
            debug(f"HTTPS: Conexão para '{url}'. Deixando a resolução de DNS para a biblioteca 'requests' para garantir a validação SSL/TLS.")
        else:
            warning(f"Esquema desconhecido '{scheme}' para URL: {url}")
            
        info(f"Fazendo requisição para '{url}' ({connection_type_log})")

        try:
            response = HTTP_SESSION.get(
                target_url,
                stream=stream, # `stream=True` para lidar com streams grandes (chunks), `False` para conteúdo pequeno (ex: manifestos)
                timeout=(CONNECTION_TIMEOUT, STREAM_TIMEOUT), # Define timeouts de conexão e leitura
                headers=headers, # Usa os cabeçalhos atualizados, que podem incluir o 'Host' para DoH em HTTP
                verify=True # Garante a verificação de certificados SSL para HTTPS. ESSENCIAL PARA SEGURANÇA.
            )
            response.raise_for_status() # Levanta uma exceção HTTPError para respostas de status de erro (4xx ou 5xx)
            return response
        except requests.exceptions.RequestException as e:
            error(f"Erro ao buscar URL externa '{url}' (target: '{target_url}'): {e}")
            return None
    
    def _send_response(self, code: int, content: bytes, content_type: str):
        """Envia uma resposta HTTP para o cliente (Kodi) com os cabeçalhos apropriados."""
        # Garante que o conteúdo seja bytes para ser escrito no socket
        encoded_content = content.encode('utf-8') if isinstance(content, str) else content

        self.send_response(code) # Envia o código de status HTTP (ex: 200 OK)
        self.send_header('Content-Type', content_type) # Define o tipo de conteúdo (MIME type)
        self.send_header('Content-Length', str(len(encoded_content))) # Define o tamanho do conteúdo
        self.send_header('Cache-Control', 'max-age=10, private') # Sugere ao cliente cachear por 10 segundos, e que é para uso privado
        self.end_headers() # Finaliza os cabeçalhos
        self.wfile.write(encoded_content) # Escreve o conteúdo no socket de resposta
    
    def _copy_headers(self, response: requests.Response):
        """
        Copia cabeçalhos da resposta original do servidor remoto para a resposta do proxy,
        filtrando aqueles que podem causar problemas ou são manipulados pelo proxy.
        """
        for header, value in response.headers.items():
            header_lower = header.lower()
            # Filtra cabeçalhos que são gerenciados pelo proxy ou podem causar conflitos.
            # 'transfer-encoding' (gerenciado pelo servidor HTTP), 'connection' (keep-alive),
            # 'content-encoding' (se o proxy não descomprimir), 'content-length' e 'content-type'
            # são tratados separadamente ou podem ser reintroduzidos pelo servidor HTTP local.
            if header_lower not in {'transfer-encoding', 'connection', 'content-encoding', 'content-length', 'content-type', 'server', 'date'}:
                self.send_header(header, value)

# --- Gerenciador de Proxy Avançado ---
class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.ready_event = threading.Event()
        self.active_port = None
        
    def start(self) -> Optional[int]:
        """
        Inicia o servidor proxy em uma porta disponível.
        Tenta a porta padrão primeiro, depois portas dinâmicas se houver conflito.
        """
        global DEFAULT_PROXY_PORT # Necessário para modificar a variável global
        
        self.stop()  # Garante que qualquer servidor proxy anterior seja parado antes de iniciar um novo.
        
        for attempt in range(MAX_PORT_ATTEMPTS):
            # Na primeira tentativa, usa a porta DEFAULT_PROXY_PORT. Nas próximas, usa 0 para que o sistema escolha uma porta livre.
            port_to_try = DEFAULT_PROXY_PORT if attempt == 0 else 0 
            server_address = (PROXY_HOST, port_to_try)
            
            try:
                # Cria o servidor, mas não inicia imediatamente (bind_and_activate=False).
                self.server = socketserver.TCPServer(
                    server_address,
                    AdvancedHLSProxyHandler,
                    bind_and_activate=False
                )
                self.server.allow_reuse_address = True # Permite reuso rápido da porta após o shutdown
                self.server.server_bind() # Liga o socket à porta e endereço
                self.server.server_activate() # Ativa o servidor para começar a escutar conexões
                
                self.active_port = self.server.server_address[1] # Obtém a porta real alocada (se foi 0)
                info(f"Servidor proxy iniciado em http://{PROXY_HOST}:{self.active_port}")
                
                # Inicia uma thread separada para rodar o loop principal de atendimento do servidor
                self.server_thread = threading.Thread(
                    target=self.server.serve_forever,
                    daemon=True # Torna a thread um daemon para que ela termine automaticamente quando o programa principal morrer
                )
                self.server_thread.start()
                
                self.ready_event.set() # Sinaliza que o proxy está pronto e a porta está ativa
                return self.active_port # Retorna a porta em que o proxy está escutando
                
            except OSError as e:
                # Trata o erro específico de "Address already in use" (porta ocupada)
                if "Address already in use" in str(e):
                    warning(f"Porta {port_to_try} em uso, tentando outra porta...")
                    # Se a porta padrão (diferente de 0) estiver em uso, define DEFAULT_PROXY_PORT para 0
                    # para que a próxima tentativa use uma porta dinâmica.
                    if port_to_try == DEFAULT_PROXY_PORT and DEFAULT_PROXY_PORT != 0:
                        DEFAULT_PROXY_PORT = 0 
                    continue # Continua para a próxima tentativa no loop
                error(f"Erro fatal ao iniciar servidor proxy: {e}")
                break # Sai do loop em caso de outros erros de sistema operacional
            except Exception as e:
                error(f"Erro inesperado ao iniciar proxy: {e}")
                break # Sai do loop para outros tipos de exceção
                
        self.ready_event.set()  # Garante que o evento seja liberado mesmo em caso de falha de inicialização
        return None # Retorna None se o proxy não pôde ser iniciado com sucesso
    
    def stop(self):
        """Para o servidor proxy e limpa seus recursos."""
        if self.server:
            info("Parando servidor proxy...")
            try:
                self.server.shutdown() # Sinaliza para o servidor parar de aceitar novas requisições
                self.server.server_close() # Fecha o socket do servidor
                info("Servidor proxy parado.")
            except Exception as e:
                error(f"Erro ao parar o servidor proxy: {e}")
            finally:
                self.server = None # Limpa a referência ao objeto do servidor
            
        # Espera a thread do servidor terminar para liberar recursos e evitar vazamentos de threads
        if self.server_thread and self.server_thread.is_alive():
            info("Aguardando thread do proxy finalizar...")
            self.server_thread.join(timeout=5) # Espera no máximo 5 segundos pela thread
            if self.server_thread.is_alive():
                warning("Thread do proxy não finalizou a tempo. Pode haver recursos residuais.")
                
        self.active_port = None # Reseta a porta ativa
        self.ready_event.clear() # Limpa o evento para a próxima inicialização

    def get_proxy_url(self, original_url: str) -> Optional[str]:
        """Gera a URL do proxy que o Kodi usará para acessar o stream original."""
        if not self.active_port:
            return None
        # Codifica a URL original para que ela possa ser usada como parte do caminho da URL do proxy
        return f"http://{PROXY_HOST}:{self.active_port}/{urllib.parse.quote_plus(original_url)}"
    
    def wait_until_ready(self, timeout: float = 15) -> bool:
        """Aguarda até que o proxy esteja pronto para aceitar conexões, com um tempo limite."""
        return self.ready_event.wait(timeout)

# --- Interface do Addon ---
class HLSProxyAddon:
    def __init__(self):
        self.proxy_manager = HLSProxyManager()
        self.player = xbmc.Player() # Instância do player Kodi para monitoramento
        self.playback_monitor_thread = None 
    
    def play_stream(self, url: str):
        """Prepara e inicia a reprodução de um stream, detectando se é HLS ou MPEG-TS/Outro."""
        info(f"Iniciando reprodução para: {url}")
        
        # --- Detecção de Tipo de Stream (HLS vs. Direto) ---
        is_hls = False
        parsed_original_url = urllib.parse.urlparse(url)
        path_lower = parsed_original_url.path.lower()
        
        if ".m3u8" in path_lower or ".m3u" in path_lower or "manifest" in path_lower:
            is_hls = True
            info(f"Detectado HLS via extensão/padrão de URL para: {url}")
        else:
            # Para URLs sem extensão clara, ou para maior robustez, tenta verificar o Content-Type via HEAD request.
            try:
                # Faz um HEAD request para obter apenas os cabeçalhos, é mais rápido que um GET completo.
                # Certifica-se de que a verificação SSL está ativa para HTTPS.
                head_response = HTTP_SESSION.head(url, timeout=5, allow_redirects=True, verify=True)
                head_response.raise_for_status() # Levanta erro para status 4xx/5xx
                content_type = head_response.headers.get('Content-Type', '').lower()
                
                # Verifica se o Content-Type sugere HLS
                if 'application/vnd.apple.mpegurl' in content_type or 'audio/mpegurl' in content_type:
                    is_hls = True
                    info(f"Detectado HLS via Content-Type ('{content_type}') para: {url}")
                else:
                    info(f"Content-Type '{content_type}' não indica HLS. Assumindo stream direto para: {url}")
            except requests.exceptions.RequestException as e:
                warning(f"Não foi possível obter Content-Type para {url}: {e}. Assumindo stream direto.")
                is_hls = False # Em caso de erro na requisição HEAD, assume que é um stream direto para tentar reproduzir.

        # --- Lógica de Início do Proxy ---
        port = self.proxy_manager.start()
        if not port:
            xbmcgui.Dialog().notification(ADDON_NAME, "Falha ao iniciar proxy", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
            
        if not self.proxy_manager.wait_until_ready():
            xbmcgui.Dialog().notification(ADDON_NAME, "Proxy não iniciou a tempo", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            self.proxy_manager.stop()
            return
            
        # Gera a URL do proxy que será passada ao Kodi
        proxy_url = self.proxy_manager.get_proxy_url(url)
        if not proxy_url:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            self.proxy_manager.stop()
            return
            
        # --- Configuração do ListItem para Kodi e inputstream.ffmpegdirect ---
        list_item = xbmcgui.ListItem(path=proxy_url)
        list_item.setContentLookup(False) # Desabilita a busca de informações de conteúdo do Kodi

        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        
        # Configuração específica para HLS ou Streams Diretos
        if is_hls:
            list_item.setMimeType('application/x-mpegURL') # MIME Type padrão para HLS
            list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
            list_item.setProperty('inputstream.ffmpegdirect.hls_segment_duration_limit', '60')
            list_item.setProperty('inputstream.ffmpegdirect.hls_min_buffer_duration', '3')
            list_item.setProperty('inputstream.ffmpegdirect.hls_max_bitrate', str(MAX_BITRATE))
            list_item.setProperty('inputstream.ffmpegdirect.hls_allow_partial_segments', 'true')
            list_item.setProperty('inputstream.ffmpegdirect.live_threshold', '10')
            list_item.setProperty('inputstream.ffmpegdirect.manifest_update_parameter', 'full') # Força atualização completa do manifesto
            info("Configurando inputstream.ffmpegdirect para HLS.")
        else:
            # Para MPEG-TS e outros streams diretos (MP4, MKV, AVI etc.)
            # Tenta inferir o MIME type com base na extensão para ser mais preciso
            if path_lower.endswith(('.ts', '.mpeg', '.mpg')):
                list_item.setMimeType('video/mp2t')
            elif path_lower.endswith(('.mp4', '.m4v')):
                 list_item.setMimeType('video/mp4')
            elif path_lower.endswith(('.mkv')):
                 list_item.setMimeType('video/x-matroska')
            elif path_lower.endswith(('.avi')):
                 list_item.setMimeType('video/x-msvideo')
            else:
                list_item.setMimeType('video/unknown') # Tipo MIME genérico se não reconhecido
            
            # Não definir 'manifest_type' ou propriedades 'hls_*' para streams diretos,
            # pois o ffmpegdirect fará a detecção automática do container.
            info("Configurando inputstream.ffmpegdirect para stream direto (TS/MP4/etc.).")
            
        # --- Propriedades comuns do inputstream.ffmpegdirect para ambos os tipos de stream (rede, erros) ---
        # O cabeçalho Referer é crucial para muitos servidores. Ele deve ser o domínio do link original.
        list_item.setProperty('inputstream.ffmpegdirect.stream_headers', f"Referer={parsed_original_url.scheme}://{parsed_original_url.netloc}")
        list_item.setProperty('inputstream.ffmpegdirect.http_connect_timeout', str(CONNECTION_TIMEOUT))
        list_item.setProperty('inputstream.ffmpegdirect.http_read_timeout', str(STREAM_TIMEOUT))
        list_item.setProperty('inputstream.ffmpegdirect.reconnect_on_error', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.fast_seek', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.seek_method', 'byte')
        
        # Garante que o ffmpegdirect verifique certificados SSL para links HTTPS
        # É CRUCIAL que isso esteja como 'false' APENAS para links HTTP que você deseja forçar
        # a resolução via IP (DoH) e que não têm validação de SSL (o que é raro e inseguro).
        # Para links HTTPS, isso DEVE ser 'false' para que a validação de SSL funcione.
        # Se você está usando HTTPS, a verificação de SSL deve ser habilitada no inputstream.ffmpegdirect.
        # A propriedade 'allow_insecure_ssl' controla se o ffmpegdirect aceita certificados inválidos.
        # Definir para 'false' é o comportamento padrão e seguro.
        list_item.setProperty('inputstream.ffmpegdirect.allow_insecure_ssl', 'false') 

        xbmcplugin.setResolvedUrl(HANDLE, True, list_item) # Informa ao Kodi para reproduzir este ListItem.
        
        # Inicia o monitor de reprodução, que garante que o proxy seja parado corretamente
        # após a reprodução ou se ela não iniciar.
        self._start_playback_monitor()
        
        # A thread principal do addon aguarda a conclusão da reprodução ou falha,
        # gerenciada pelo monitor de reprodução. Isso impede que o script Kodi termine
        # e pare o proxy prematuramente.
        if self.playback_monitor_thread:
            self.playback_monitor_thread.join() # Aguarda a thread do monitor finalizar
            info("Monitor de reprodução finalizado, script principal encerrando.")
        else:
            warning("Monitor de reprodução não foi iniciado corretamente, o proxy pode não ser parado automaticamente.")


    def _start_playback_monitor(self):
        """
        Inicia uma thread separada para monitorar o status do player Kodi.
        Quando a reprodução termina ou falha, ela desliga o servidor proxy.
        """
        # Evita iniciar múltiplos monitores se já houver um ativo.
        if self.playback_monitor_thread and self.playback_monitor_thread.is_alive():
            return 

        def monitor_func():
            info("Iniciando monitor de reprodução de fundo...")
            
            # Aguarda um tempo limite para a reprodução realmente começar no Kodi.
            start_time = time.time()
            is_playing_after_wait = False
            # Dando um tempo ligeiramente maior para o Kodi começar a reproduzir.
            while time.time() - start_time < 60: # Tempo limite de 60 segundos
                if self.player.isPlaying():
                    is_playing_after_wait = True
                    break
                time.sleep(1) # Verifica o status do player a cada 1 segundo
            
            if not is_playing_after_wait:
                warning("Reprodução não iniciada dentro do tempo limite ou falha do player detectada. Parando proxy.")
                self.proxy_manager.stop() # Desliga o proxy se o player não iniciar a tempo
                return
            
            info("Reprodução iniciada. Monitorando player ativo...")
            # Mantém a thread ativa enquanto o Kodi estiver reproduzindo ativamente
            while self.player.isPlaying():
                time.sleep(2) # Verifica a cada 2 segundos para reduzir carga de CPU
                
            info("Reprodução terminada ou parada. Parando proxy...")
            self.proxy_manager.stop() # Desliga o proxy quando a reprodução termina ou é interrompida
            
        self.playback_monitor_thread = threading.Thread(target=monitor_func, daemon=True)
        self.playback_monitor_thread.start()
    
    def show_test_streams(self):
        """
        Cria e adiciona itens de lista para streams de teste (HLS e TS/MP4)
        no diretório do addon no Kodi para demonstração.
        """
        # Adicione URLs de teste aqui. Preferencialmente HTTPS para testar a segurança.
        test_streams = [
            # ATENÇÃO: Estes links HTTP de live stream podem expirar ou ter restrições geográficas.
            # Use-os apenas para testes de funcionalidade do DoH e comportamento HTTP.
            ("Live Stream Exemplo 1 (HLS - HTTP - pode expirar)", "http://cdnrez.xyz:80/live/844876939/805772826/1108522.m3u8"), 
            ("Live Stream Exemplo 2 (HLS - HTTP - pode expirar)", "http://tvhdbalck.pro:80/live/6464779/0577073/329.m3u8"), 
            
            # Links HTTPS, ideais para testar a criptografia de fluxo (TLS/SSL).
            ("VOD Apple Sample (HLS - estável HTTPS)", "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8"),
            ("Big Buck Bunny (HLS Demo - estável HTTPS)", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
            
            # Exemplo de stream direto HTTP (NÃO criptografado, apenas DoH na consulta DNS)
            ("Exemplo MPEG-TS Direto (Placeholder - HTTP)", "http://iptv.example.com/live/channel.ts"), # SUBSTITUA POR UM LINK TS REAL E VÁLIDO!
            ("Exemplo MP4 Direto (Big Buck Bunny - estável HTTPS)", "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4")
        ]
        
        for name, url in test_streams:
            li = xbmcgui.ListItem(label=name)
            li.setProperty('IsPlayable', 'true') # Marca o item como reproduzível
            li.setInfo('video', {'title': name}) # Define informações de vídeo
            
            # Ajusta o MIME type para os exemplos de teste na listagem inicial
            if ".m3u8" in url.lower() or ".m3u" in url.lower():
                li.setMimeType('application/vnd.apple.mpegurl')
            elif url.lower().endswith('.ts'):
                li.setMimeType('video/mpegts')
            elif url.lower().endswith('.mp4'):
                li.setMimeType('video/mp4')
            else:
                li.setMimeType('video/mp2t') # Default genérico para outros streams
            
            # Cria a URL do plugin que será chamada quando o item for selecionado
            plugin_url = f"plugin://{ADDON_ID}/?action=play&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, False) # Adiciona o item ao diretório do Kodi
            
        xbmcplugin.endOfDirectory(HANDLE) # Finaliza a listagem do diretório

# --- Ponto de Entrada Principal do Addon ---
if __name__ == '__main__':
    # Cria uma única instância do addon para gerenciar o proxy e a reprodução.
    addon_instance = HLSProxyAddon()
    
    # Analisa os parâmetros da URL de chamada do addon (sys.argv[2])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url = params.get('url')

    if action == 'play' and url:
        info(f"Ação 'play' recebida para URL: {url}")
        # Inicia a reprodução. A função 'play_stream' gerencia todo o ciclo de vida do proxy.
        addon_instance.play_stream(url)
    else:
        info("Exibindo lista de streams de teste ao iniciar o addon.")
        # Exibe a lista de streams quando o addon é aberto diretamente (sem ação específica).
        addon_instance.show_test_streams()
    
    # O script principal do addon termina aqui. O proxy é gerenciado de forma assíncrona
    # pela thread de monitoramento iniciada em 'play_stream', que garante que ele só seja
    # parado após a reprodução.