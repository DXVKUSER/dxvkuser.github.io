#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# -----------------------------------------------------------------------------------
# Proxy HLS Local TCP/HTTP Puro v8.3 (ULTRA-RESILIENTE) - KODI VERSION
# -----------------------------------------------------------------------------------
# Adaptado para Kodi: Sem painel XCodes, Sem Banco de Dados Local.
# Apenas a lógica de resiliência, Circuit Breaker e Prefetch.
#
# NOVIDADES v8.3:
# 1. Bypass de DPI aprimorado: Randomização de headers HTTP (Accept, Language, etc.)
#    para cada requisição, tornando o tráfego indetectável.
# 2. Política "Sempre 200 OK": Em caso de falha crítica na busca de um segmento,
#    o proxy responde com 200 OK e pacotes nulos, evitando que o player pare o stream.
# -----------------------------------------------------------------------------------

import sys
import threading
import random
import logging
import urllib.parse
import time
import warnings
import os
import socket
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import re

# --- REQUESTS ---
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- KODI IMPORTS ---
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
except ImportError:
    # Mocks para testes fora do Kodi
    class MockKodi:
        def translatePath(self, path): return "."
        def log(self, msg, level): print(msg)
        def getAddonInfo(self, info): return "."
    xbmc = MockKodi()
    xbmcgui = None
    xbmcplugin = None
    xbmcvfs = None

# ---------------- CONFIGURAÇÕES ----------------

# Configurações de retry mais conservadoras
MAX_SEGMENT_RETRIES = 3
MAX_MANIFEST_RETRIES = 5 # Mais tentativas para o manifesto, que é crucial
CONNECTION_TIMEOUT = 5.0
READ_TIMEOUT = 15.0

# Configurações de cache
SEGMENT_CACHE_SIZE = 60
SEGMENT_CACHE_TTL = 30
MANIFEST_CACHE_TTL = 3  # Baixo para garantir live atualizado

# Configurações de estabilidade
PREFETCH_ENABLED = True
MAX_PREFETCH_THREADS = 2
CIRCUIT_BREAKER_FAILURE_THRESHOLD = 5   # Falhas consecutivas para abrir o circuito
CIRCUIT_BREAKER_TIMEOUT = 20           # Segundos para esperar antes de tentar de novo
SESSION_TIMEOUT_SECONDS = 120          # Remove sessão após inatividade

DEFAULT_CHUNK_SIZE = 64 * 1024
PROXY_HOST = '127.0.0.1' # Localhost apenas para segurança no Kodi
MAX_PORT_ATTEMPTS = 20
LOG_FILE = "hls_tcp_proxy.log"

# Lista de User-Agens para randomização
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:125.0) Gecko/20100101 Firefox/125.0",
]

# Pacote Nulo MPEG-TS (188 bytes) - Usado para manter o player vivo em falhas críticas
NULL_TS_PACKET = b'\x47\x1f\xff\x10' + (b'\xff' * 184)

warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# ---------------- ESTADO GLOBAL ----------------
MANIFEST_CACHE = {}
SEGMENT_CACHE = {}
SESSION_STORE = {}
STATE_LOCK = threading.Lock()
PREFETCH_EXECUTOR = ThreadPoolExecutor(max_workers=MAX_PREFETCH_THREADS, thread_name_prefix="Prefetch")

# ---------------- UTILS & SETUP ----------------
def _generate_fake_ip():
    """Gera um IP aleatório para header X-Forwarded-For"""
    while True:
        octets = [random.randint(1, 254) for _ in range(4)]
        if (octets[0] == 10 or 
            (octets[0] == 192 and octets[1] == 168) or 
            (octets[0] == 172 and 16 <= octets[1] <= 31) or
            octets[0] == 127 or octets[0] == 0 or octets[0] >= 240):
            continue
        return ".".join(map(str, octets))

def setup_logging():
    try:
        log_dir = xbmc.translatePath('special://logpath') if xbmcgui else "."
        if not os.path.exists(log_dir):
            try: os.makedirs(log_dir)
            except: pass
        
        # Kodi Logger Wrapper
        logging.basicConfig(level=logging.INFO, format='%(message)s')
    except Exception:
        pass

def kodi_log(msg, level=logging.INFO):
    if xbmc:
        x_level = xbmc.LOGINFO if level == logging.INFO else xbmc.LOGERROR
        xbmc.log(f"[HLS-PROXY] {msg}", level=x_level)

# ---------------- GERENCIAMENTO DE SESSÃO ----------------
class SessionManager:
    def __init__(self):
        self._cleanup_thread = threading.Thread(target=self._cleanup_idle_sessions_loop, daemon=True)
        self._cleanup_thread.start()

    def get_session_data(self, session_id):
        with STATE_LOCK:
            if session_id not in SESSION_STORE:
                self._create_new_session_entry(session_id)
            
            SESSION_STORE[session_id]['last_activity_time'] = time.time()
            return SESSION_STORE[session_id]

    def _create_new_session_entry(self, session_id):
        session = requests.Session()
        adapter = HTTPAdapter(
            pool_connections=10,
            pool_maxsize=20,
            max_retries=Retry(
                total=2,
                backoff_factor=0.2,
                status_forcelist=[500, 502, 503, 504]
            )
        )
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        SESSION_STORE[session_id] = {
            'session': session,
            'last_rotation': 0,
            'failure_count': 0,
            'success_count': 0,
            'consecutive_failures': 0,
            'circuit_breaker_open_time': 0,
            'last_activity_time': time.time()
        }
        kodi_log(f"Sessão Iniciada: {session_id}")

    def get_random_headers(self, session_id, referer_host=None):
        """Gera um conjunto de headers aleatórios para contornar DPI."""
        s_data = self.get_session_data(session_id)
        
        # Escolhe um User-Agent aleatório da lista
        user_agent = random.choice(USER_AGENTS)
        
        # Gera um IP falso aleatório
        fake_ip = _generate_fake_ip()
        
        headers = {
            'User-Agent': user_agent,
            'X-Forwarded-For': fake_ip,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': str(random.randint(0, 1)),
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site'
        }
        
        if referer_host:
            headers['Referer'] = f"http://{referer_host}/"
            
        return headers

    def is_circuit_breaker_open(self, session_id):
        with STATE_LOCK:
            if session_id not in SESSION_STORE:
                return False # Se não existe, cria na próxima chamada
            s_data = SESSION_STORE[session_id]
            if s_data['circuit_breaker_open_time'] == 0:
                return False
            if time.time() - s_data['circuit_breaker_open_time'] > CIRCUIT_BREAKER_TIMEOUT:
                kodi_log(f"Circuit Breaker fechando (recuperando) para {session_id}")
                s_data['circuit_breaker_open_time'] = 0
                s_data['consecutive_failures'] = 0
                return False
            return True

    def trip_circuit_breaker(self, session_id):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                SESSION_STORE[session_id]['circuit_breaker_open_time'] = time.time()
                kodi_log(f"Circuit Breaker ABERTO para {session_id}")

    def record_success(self, session_id):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                s_data = SESSION_STORE[session_id]
                s_data['success_count'] += 1
                s_data['consecutive_failures'] = 0
                if s_data['circuit_breaker_open_time'] > 0:
                    s_data['circuit_breaker_open_time'] = 0

    def record_failure(self, session_id):
        with STATE_LOCK:
            if session_id in SESSION_STORE:
                s_data = SESSION_STORE[session_id]
                s_data['failure_count'] += 1
                s_data['consecutive_failures'] += 1
                if s_data['consecutive_failures'] >= CIRCUIT_BREAKER_FAILURE_THRESHOLD:
                    self.trip_circuit_breaker(session_id)

    def rotate_session(self, session_id):
        """Fecha e recria a sessão requests para obter novas conexões."""
        with STATE_LOCK:
            if session_id not in SESSION_STORE:
                return False
                
            s_data = SESSION_STORE[session_id]
            now = time.time()
            
            # Cooldown para não rotacionar excessivamente
            if now - s_data['last_rotation'] < 2: 
                return False
            
            try: 
                s_data['session'].close()
            except: 
                pass
                
            # Cria uma nova sessão e adaptador
            session = requests.Session()
            adapter = HTTPAdapter(
                pool_connections=10, pool_maxsize=20,
                max_retries=Retry(total=1, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
            )
            session.mount('http://', adapter)
            session.mount('https://', adapter)
            
            s_data['session'] = session
            s_data['last_rotation'] = now
                
            # Limpa caches que podem estar obsoletos
            if session_id in MANIFEST_CACHE:
                del MANIFEST_CACHE[session_id]
                
            kodi_log(f"Sessão rotacionada para: {session_id}")
            return True

    def _cleanup_idle_sessions_loop(self):
        while True:
            time.sleep(30)
            with STATE_LOCK:
                now = time.time()
                to_remove = []
                for sid, s_data in SESSION_STORE.items():
                    if now - s_data['last_activity_time'] > SESSION_TIMEOUT_SECONDS:
                        to_remove.append(sid)
                
                for sid in to_remove:
                    try: SESSION_STORE[sid]['session'].close()
                    except: pass
                    del SESSION_STORE[sid]
                    if sid in MANIFEST_CACHE: del MANIFEST_CACHE[sid]
                    if sid in SEGMENT_CACHE: del SEGMENT_CACHE[sid]

session_manager = SessionManager()

# ---------------- CACHE DE SEGMENTOS ----------------
def get_segment_from_cache(segment_url):
    with STATE_LOCK:
        if segment_url in SEGMENT_CACHE:
            timestamp, data = SEGMENT_CACHE[segment_url]
            if time.time() - timestamp < SEGMENT_CACHE_TTL:
                return data
            else:
                del SEGMENT_CACHE[segment_url]
    return None

def cache_segment(segment_url, data):
    with STATE_LOCK:
        SEGMENT_CACHE[segment_url] = (time.time(), data)
        if len(SEGMENT_CACHE) > SEGMENT_CACHE_SIZE:
            # Remove os 10 mais antigos
            oldest_keys = sorted(SEGMENT_CACHE.keys(), key=lambda k: SEGMENT_CACHE[k][0])[:10]
            for key in oldest_keys:
                del SEGMENT_CACHE[key]

def prefetch_segment(session_id, segment_url, host):
    """Função background para pré-buscar segmentos"""
    if not PREFETCH_ENABLED:
        return
    
    if get_segment_from_cache(segment_url):
        return

    try:
        # Usa os headers aleatórios também no prefetch
        headers = session_manager.get_random_headers(session_id, referer_host=host)
        s_data = session_manager.get_session_data(session_id)
        
        # Timeout curto para prefetch não travar threads
        r = s_data['session'].get(segment_url, headers=headers, timeout=5.0, verify=False)
        if r.status_code == 200:
            cache_segment(segment_url, r.content)
    except Exception:
        pass

# ---------------- PROXY HANDLER ----------------
class HLSProxyRequestHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        # Suprimir logs padrão do http.server
        pass

    def do_GET(self):
        try:
            if '?url=' not in self.path:
                self.send_error(404)
                return

            params = urllib.parse.parse_qs(self.path.split('?', 1)[1])
            url = urllib.parse.unquote_plus(params.get('url', [None])[0])
            session_id = params.get('session_id', [f"sess_{int(time.time())}_{random.randint(100,999)}"])[0]
            host_header = params.get('h', [None])[0]

            if not url:
                self.send_error(400)
                return

            # Detecta se é manifesto ou segmento
            parsed = urllib.parse.urlparse(url)
            is_manifest = (
                parsed.path.lower().endswith(('.m3u8', '.m3u')) or
                'manifest' in parsed.query.lower() or
                'type=m3u8' in parsed.query.lower()
            )

            if is_manifest:
                self._handle_manifest(url, session_id)
            else:
                self._handle_segment(url, session_id, host_header)

        except Exception as e:
            kodi_log(f"Erro Crítico Handler: {e}", logging.ERROR)
            try: self.send_error(500)
            except: pass

    def _handle_manifest(self, url, session_id):
        now = time.time()
        with STATE_LOCK:
            cache = MANIFEST_CACHE.get(session_id)
            if cache and (now - cache['timestamp'] < MANIFEST_CACHE_TTL):
                self._send_content(cache['content'], 'application/vnd.apple.mpegurl')
                return

        origin_host = urllib.parse.urlparse(url).netloc
        content = None
        
        # Loop de retentativa robusto para o manifesto
        for attempt in range(MAX_MANIFEST_RETRIES):
            try:
                s_data = session_manager.get_session_data(session_id)
                headers = session_manager.get_random_headers(session_id, referer_host=origin_host)

                r = s_data['session'].get(url, headers=headers, timeout=CONNECTION_TIMEOUT, verify=False)
                
                if r.status_code != 200:
                    r.close()
                    session_manager.record_failure(session_id)
                    if attempt < MAX_MANIFEST_RETRIES - 1:
                        kodi_log(f"Falha no manifesto (tentativa {attempt + 1}), rotacionando sessão...")
                        session_manager.rotate_session(session_id)
                        time.sleep(0.5 * (attempt + 1)) # Backoff exponencial
                        continue
                    else:
                        break # Sai do loop se as tentativas se esgotarem

                # Processamento e Rewrite do Manifesto
                content = r.text
                base_url = r.url # URL final após redirects
                new_lines = []
                lines = content.splitlines()
                prefetch_targets = []

                for line in lines:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        new_lines.append(line)
                        continue
                    
                    # É uma URL de segmento ou playlist variante
                    full_url = urllib.parse.urljoin(base_url, line)
                    enc_url = urllib.parse.quote_plus(full_url)
                    enc_host = urllib.parse.quote_plus(origin_host)
                    
                    # Monta URL local
                    proxy_url = f"http://{self.server.server_address[0]}:{self.server.server_address[1]}/?url={enc_url}&session_id={session_id}&h={enc_host}"
                    new_lines.append(proxy_url)
                    
                    # Se não for playlist variante, adiciona para prefetch
                    if not line.endswith('.m3u8'):
                        prefetch_targets.append(full_url)

                final_content = "\n".join(new_lines).encode('utf-8')

                # Salva no cache
                with STATE_LOCK:
                    MANIFEST_CACHE[session_id] = {'content': final_content, 'timestamp': now}

                # Dispara prefetch
                if PREFETCH_ENABLED and prefetch_targets:
                    targets = prefetch_targets[-2:] if len(prefetch_targets) > 2 else prefetch_targets
                    for target in targets:
                        PREFETCH_EXECUTOR.submit(prefetch_segment, session_id, target, origin_host)

                self._send_content(final_content, 'application/vnd.apple.mpegurl')
                session_manager.record_success(session_id)
                return # Sucesso, sai da função

            except Exception as e:
                kodi_log(f"Erro no manifesto {session_id} (tentativa {attempt + 1}): {e}", logging.ERROR)
                session_manager.record_failure(session_id)
                if attempt < MAX_MANIFEST_RETRIES - 1:
                    time.sleep(0.5 * (attempt + 1))

        # Se todas as tentativas falharem
        kodi_log(f"FALHA TOTAL ao baixar manifesto para {session_id}", logging.ERROR)
        self.send_error(503, "Proxy failed to fetch manifest after multiple retries.")

    def _handle_segment(self, url, session_id, host_header):
        # Verifica Circuit Breaker
        if session_manager.is_circuit_breaker_open(session_id):
            kodi_log(f"Circuit Breaker Aberto: Enviando Null Packets para {session_id}")
            self._send_content(NULL_TS_PACKET * 100, 'video/mp2t')
            return

        # Verifica Cache
        cached = get_segment_from_cache(url)
        if cached:
            self._send_content(cached, 'video/mp2t')
            session_manager.record_success(session_id)
            return

        # Download
        success = False
        for attempt in range(MAX_SEGMENT_RETRIES):
            try:
                s_data = session_manager.get_session_data(session_id)
                headers = session_manager.get_random_headers(session_id, referer_host=host_header)

                r = s_data['session'].get(url, headers=headers, stream=True, timeout=(CONNECTION_TIMEOUT, READ_TIMEOUT), verify=False)
                
                if r.status_code >= 400:
                    r.close()
                    session_manager.record_failure(session_id)
                    if attempt < MAX_SEGMENT_RETRIES - 1:
                        kodi_log(f"Falha no segmento (tentativa {attempt + 1}), rotacionando sessão...")
                        session_manager.rotate_session(session_id)
                        time.sleep(0.2 * (attempt + 1))
                        continue
                    else:
                        break # Sai do loop para enviar fallback

                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()

                data_acc = b''
                for chunk in r.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                            data_acc += chunk
                        except:
                            return # Cliente desconectou

                # Cacheia se for pequeno (segmento típico)
                if len(data_acc) > 0 and len(data_acc) < 5 * 1024 * 1024:
                    cache_segment(url, data_acc)
                
                session_manager.record_success(session_id)
                success = True
                break

            except requests.exceptions.RequestException as e:
                kodi_log(f"Erro de requisição no segmento {session_id} (tentativa {attempt + 1}): {e}", logging.ERROR)
                session_manager.record_failure(session_id)
                if attempt < MAX_SEGMENT_RETRIES - 1:
                    session_manager.rotate_session(session_id)
                    time.sleep(0.2 * (attempt + 1))
                continue
        
        # POLÍTICA "SEMPRE 200 OK": Se todas as tentativas falharem, envia pacotes nulos
        if not success:
            kodi_log(f"FALHA TOTAL no segmento {url[-20:]} para {session_id}. Enviando 200 OK com pacotes nulos.", logging.ERROR)
            try:
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.end_headers()
                # Envia alguns pacotes nulos para manter o player vivo
                self.wfile.write(NULL_TS_PACKET * 50)
            except Exception as e:
                kodi_log(f"Erro ao enviar pacotes nulos: {e}", logging.ERROR)


    def _send_content(self, data, content_type):
        try:
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(data)
        except Exception:
            pass

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class HLSProxyManager:
    def __init__(self):
        self.server = None
        self.thread = None
        self.active_port = None

    def start(self):
        # Tenta portas aleatórias para evitar conflitos
        for _ in range(MAX_PORT_ATTEMPTS):
            port = random.randint(30000, 60000)
            try:
                self.server = ThreadingHTTPServer((PROXY_HOST, port), HLSProxyRequestHandler)
                self.active_port = port
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                kodi_log(f"Proxy HLS v8.3 rodando em {PROXY_HOST}:{port}")
                return True
            except Exception:
                continue
        return False

# ---------------- ADDON INTERFACE ----------------
class HLSAddon:
    def __init__(self, handle):
        self.handle = handle
        self.proxy = HLSProxyManager()

    def play_stream(self, url, stype, title=None):
        setup_logging()
        
        # Inicia o proxy
        if not self.proxy.start():
            kodi_log("Falha ao iniciar servidor proxy", logging.ERROR)
            if xbmcplugin:
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        # Gera ID único para rastrear esta sessão de playback
        session_id = f"play_{int(time.time())}_{random.randint(1000, 9999)}"
        
        # Codifica URL alvo
        enc_url = urllib.parse.quote_plus(url)
        
        # Monta URL local para o Kodi tocar
        proxy_url = f"http://{PROXY_HOST}:{self.proxy.active_port}/?url={enc_url}&session_id={session_id}"
        
        kodi_log(f"Redirecionando Kodi para: {proxy_url}")

        if xbmcgui and xbmcplugin:
            li = xbmcgui.ListItem(label=title or "Stream")
            li.setPath(proxy_url)
            li.setProperty("IsPlayable", "true")
            # MIME type ajuda o Kodi a entender rápido
            if stype == "live":
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setProperty("IsLive", "true")
            else:
                li.setMimeType("application/vnd.apple.mpegurl")
            
            xbmcplugin.setResolvedUrl(self.handle, True, li)

# ---------------- MAIN (TESTING) ----------------
if __name__ == '__main__':
    # Bloco apenas para teste manual fora do Kodi
    setup_logging()
    manager = HLSProxyManager()
    if manager.start():
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            pass