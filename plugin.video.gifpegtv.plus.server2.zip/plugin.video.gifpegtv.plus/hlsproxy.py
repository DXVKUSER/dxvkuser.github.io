# -*- coding: utf-8 -*-
# Servidor Proxy HLS para add-ons Kodi (Versão Otimizada e Refatorada)
# Melhorias: Gerenciador de Contexto, Segurança por Token, Porta Dinâmica, Sem Globais.

import secrets
import time
import threading
import http.server
import socketserver
import urllib.parse
import xbmc
import socket
import errno
import contextlib

# --- Constantes ---
DEFAULT_PORT = 55334
PORT_RANGE_TO_TRY = 10 # Tentará até 10 portas consecutivas se a padrão estiver ocupada
TOKEN_TTL_SECONDS = 3600 # Token válido por 1 hora

class HlsProxy(contextlib.ContextDecorator):
    """
    Um proxy HLS local para o Kodi que funciona como um gerenciador de contexto.
    Uso recomendado (gerenciamento automático de ciclo de vida):
    
    with HlsProxy() as proxy:
        stream_url = proxy.prepare_url("https://example.com/stream.m3u8")
        xbmc.Player().play(stream_url)
        
    O proxy será automaticamente parado ao sair do bloco 'with'.
    """

    def __init__(self, port=DEFAULT_PORT):
        self.port = port
        self._httpd = None
        self._thread = None
        self._is_running = False
        self._auth_token = None
        self._token_expiry = 0
        self._lock = threading.Lock()

    def _generate_token(self):
        """Gera um novo token de autenticação válido por TOKEN_TTL_SECONDS."""
        with self._lock:
            self._auth_token = secrets.token_urlsafe(16)
            self._token_expiry = time.time() + TOKEN_TTL_SECONDS
            xbmc.log(f"[HlsProxy] Novo token de autenticação gerado.", xbmc.LOGDEBUG)

    def _find_available_port(self):
        """Tenta encontrar uma porta disponível na faixa especificada."""
        ports_to_try = [self.port] + list(range(self.port + 1, self.port + PORT_RANGE_TO_TRY))
        for port_to_try in ports_to_try:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(("127.0.0.1", port_to_try))
                    xbmc.log(f"[HlsProxy] Porta {port_to_try} está disponível.", xbmc.LOGDEBUG)
                    return port_to_try
            except socket.error:
                xbmc.log(f"[HlsProxy] Porta {port_to_try} em uso, tentando a próxima...", xbmc.LOGDEBUG)
                continue
        raise OSError(f"[HlsProxy] ERRO: Nenhuma porta disponível na faixa {self.port}-{self.port + PORT_RANGE_TO_TRY - 1}.")

    def __enter__(self):
        """Inicia o servidor ao entrar no contexto 'with'."""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Para o servidor ao sair do contexto 'with'."""
        self.stop()

    def start(self):
        """Inicia o servidor HTTP em uma thread separada."""
        if self._is_running:
            xbmc.log("[HlsProxy] Servidor já está rodando.", xbmc.LOGINFO)
            return

        try:
            chosen_port = self._find_available_port()
            self.port = chosen_port
            
            Handler = self._create_request_handler()
            self._httpd = socketserver.TCPServer(("127.0.0.1", self.port), Handler)
            self._httpd.allow_reuse_address = True
            
            self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
            self._thread.start()
            self._is_running = True
            self._generate_token()
            
            xbmc.log(f"[HlsProxy] Servidor iniciado com sucesso em http://127.0.0.1:{self.port}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[HlsProxy] ERRO FATAL ao iniciar servidor: {e}", xbmc.LOGERROR)
            self.stop()
            raise

    def stop(self):
        """Para o servidor HTTP de forma graciosa."""
        if not self._is_running:
            return
        
        xbmc.log("[HlsProxy] Parando servidor...", xbmc.LOGINFO)
        if self._httpd:
            self._httpd.shutdown()
            self._httpd.server_close()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self._is_running = False
        xbmc.log("[HlsProxy] Servidor parado.", xbmc.LOGINFO)

    def _create_request_handler(self):
        """Fábrica para criar o handler, passando a instância do proxy para ele."""
        proxy_instance = self

        class RequestHandler(http.server.SimpleHTTPRequestHandler):
            def log_message(self, format, *args): 
                """Suprime logs de acesso HTTP no log do Kodi."""
                return

            def do_GET(self):
                """Processa a requisição GET do player (Kodi)."""
                try:
                    query = urllib.parse.urlparse(self.path).query
                    params = urllib.parse.parse_qs(query)
                    original_url = params.get('url', [None])[0]
                    token = params.get('token', [None])[0]

                    if not original_url:
                        self.send_error(400, "Erro: URL do stream não fornecida.")
                        return

                    # Validação de segurança do token
                    if not token or token != proxy_instance._auth_token or time.time() > proxy_instance._token_expiry:
                        xbmc.log(f"[HlsProxy] Acesso negado: token inválido ou expirado.", xbmc.LOGWARNING)
                        self.send_error(403, "Forbidden: Token de acesso inválido.")
                        return

                    xbmc.log(f"[HlsProxy] Redirecionando com sucesso para: {original_url}", xbmc.LOGDEBUG)
                    
                    # Retorna o redirecionamento 302
                    self.send_response(302)
                    self.send_header('Location', original_url)
                    self.end_headers()
                
                except Exception as e:
                    xbmc.log(f"[HlsProxy] Erro ao processar requisição: {e}", xbmc.LOGERROR)
                    self.send_error(500, "Erro interno do servidor proxy.")
        
        return RequestHandler

    @property
    def base_url(self):
        """Retorna a URL base do servidor proxy."""
        if not self._is_running:
            raise RuntimeError("O proxy não está rodando. Inicie-o com .start() ou use o gerenciador de contexto 'with'.")
        return f"http://127.0.0.1:{self.port}"

    def prepare_url(self, url):
        """Prepara a URL do stream para ser processada pelo proxy, com autenticação."""
        if not self._is_running:
            raise RuntimeError("O proxy não está rodando. Inicie-o com .start() ou use o gerenciador de contexto 'with'.")
        
        # Gera um novo token se o atual estiver expirado
        if not self._auth_token or time.time() > self._token_expiry:
            self._generate_token()
            
        return f"{self.base_url}/?url={urllib.parse.quote_plus(url)}&token={self._auth_token}"

# --- Funções de API para COMPATIBILIDADE (obsoletas, mas mantidas para evitar quebras) ---
# Estas funções agora operam em uma instância global singleton para manter compatibilidade
# com código que não usa o gerenciador de contexto.

_GLOBAL_PROXY_INSTANCE = None

def _get_global_instance():
    global _GLOBAL_PROXY_INSTANCE
    if _GLOBAL_PROXY_INSTANCE is None:
        _GLOBAL_PROXY_INSTANCE = HlsProxy()
    return _GLOBAL_PROXY_INSTANCE

def start_server_if_needed():
    """Inicia o servidor global se necessário."""
    instance = _get_global_instance()
    if not instance._is_running:
        instance.start()
    return instance

def prepare_url(url):
    """Prepara a URL usando a instância global do proxy."""
    return _get_global_instance().prepare_url(url)

def check_server():
    """Verifica se o servidor global está ativo."""
    return _get_global_instance()._is_running

# Alias para compatibilidade
mediaserver = HlsProxy